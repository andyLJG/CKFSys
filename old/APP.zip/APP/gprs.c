#include "stm32f10x_conf.h"
#include "hal.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Count.h"
#include "Key.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include "Gprs_online.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_it.h"
#include "string.h"
#include "misc.h"
#include "math.h"
#include "main.h"
#include "Card.h"
#include "MemoryAssign.h"
#include "Do_Task.h"
//write by andyluo in 2010

#define CPU_TD_1	    GPIO_SetBits(GPIOA, GPIO_Pin_9)
#define CPU_TD_0	    GPIO_ResetBits(GPIOA, GPIO_Pin_9)

//@@@@@MU509B-andyluo 2016-03-04 ӡ����ֲ
u8 gg_3G;
u8 R3Gp;
u8 PhoneNo[11];
//@@@@@MU509B-andyluo 2016-03-04 ӡ����ֲ
u8 MU509link_net(void);
void EmptyRcv3G(void);
u8 ReadGsmString(u16 timeout);

////***************************************ASCII ת��Ϊ��BCD********************************************************
unsigned char asic_to_hex(unsigned char rr)
{
  unsigned char c1;

  if(rr<0x3A)
  	c1=rr-0x30;
  else
  	c1=rr-0x37;
  return c1;
}

//andyluo
unsigned char twoasic_to_oenhex(unsigned char *recvgsmproc,u8 ASCII)
{//2///2=1+2=1   1+1=1  36 41 36 44 ==14
  unsigned short i,j;
  unsigned char hex,hex1,hex2,hex3;
  
  //hex3 = 4;
  hex3 = 2;
  j = 0;
  for(i=0;;i++){
  	
    j =i*hex3;	
    if(recvgsmproc[j+1] == '*'){
  		
      recvgsmproc[i+1] = '*';		
      break; 		
    }
  	
    hex = asic_to_hex(recvgsmproc[j+1]);
    hex1 = asic_to_hex(recvgsmproc[j+2]);
    hex = hex<<4;
    hex = hex+hex1;
    hex2 = hex - '9';//31		
	
    if(hex3 == 2){
		
      recvgsmproc[i+1] = hex2;	
      continue;
		
    }
    if(ASCII||(hex2>'F')){

      recvgsmproc[i+1] = hex2;	
      hex3 = 2;	
      j = j/2;
      continue;
		
    }
  	
    hex = asic_to_hex(recvgsmproc[j+3]);
    hex1 = asic_to_hex(recvgsmproc[j+4]);
    hex = hex<<4;
    hex = hex+hex1;
    hex1 = hex-'9';//34	

    hex = asic_to_hex(hex2);
    hex2 = asic_to_hex(hex1);
    hex = hex<<4;
    hex = hex+hex2;
    recvgsmproc[i+1] = hex;		
	
  }
	
  return 1;
}

void open_gprs_power()
{
	if(SYS_MS.G3S ==OFF)return;

	{
#ifdef MU509B
	#ifndef JM3G_UPDATE
		WCDMA_Power_OFF;
		GPRS_Power_OFF; 
	#else
		WCDMA_Power_ON;
		GPRS_Power_ON; 
	#endif
#else
		WCDMA_Power_ON;
		delay(10000);//andyluo2011-02-12
#endif
		delay(10000);//andyluo2011-02-12
	}
	
}


void open_gprs_uart()
{
	 delay(1000);//andyluo2011-02-12
}
void close_uart()
{
	 delay(5);
 }
void close_gprs_power()
{
#ifdef MU509B
	#ifdef JM3G_UPDATE
	WCDMA_Power_OFF;
	GPRS_Power_OFF; 
	#else
	WCDMA_Power_ON;
	GPRS_Power_ON; 
	#endif
#else
	WCDMA_Power_OFF;
	GPRS_Power_OFF; 
#endif
	delay(10000);//andyluo2011-02-12
}


/*----------------------------------------------------------------------
����:    card_modem_configor(void)
����:    �򿪶���ģ���Դ������ʼ������
input:   ��ʱ����
output:  
2������
0x55������
0�ɹ���
------------------------------------------------------------------------*/
u8 Initial_3G(u8 time)
{ 
  u32 timeOut;  
  
  WCDMA_Power_OFF;
  delay(KEYTIMEOUT_1S / 10);
  WCDMA_Power_ON; 
  //�ж�  
  RxCounter =0;   
  f_receiveOK = 0; 
  timeOut=KEYTIMEOUT_1S* time;   // 20s�ȴ�3Gģ���ʼ��
  
  while(--timeOut) 
  {
    IWDG_ReloadCounter(); //ι��
    if(key_flag)
    {
      WCDMA_Power_OFF;
      return 2;  //��������
    }
    
    if(f_receiveOK==1) //�յ��ظ��ȴ�3Gģ���ʼ��
    { 
      f_receiveOK = 0;
      if((RxBuffer[1]=='A')&&(RxBuffer[2]=='A'))  //#AA*�ɹ�
      {break;}              
    }   
  }
  if(timeOut)
  return Link_network();
  else
  {
    WCDMA_Power_OFF;
    return 0x55;
  }
}

/*------------�߱����߹��ܵ�3G��----------------------
//����������u8 open_3G(u8 time)
//2������
//0x55������
//0�ɹ���
//-------------------------------------------------------*/
//u8 open_3G(u8 time)
//{
//  u8 netstate;  

//  netstate=MBto3G_CtlCommmand(1,time);//ֱ�ӻ���3Gģ��  
//  if(key_flag)
//  {
//    WCDMA_Power_OFF;
//    return 2;
//  }  //��������
//  
//  if(netstate)//ʧ��
//  {    
//    netstate=Initial_3G(time);//�Ӷϵ翪ʼ���� 
//    if(key_flag)//
//    { WCDMA_Power_OFF;return 2;}  //��������
//    
//  }  
//  /*�������������*/    
//  return netstate;
//}


//��3g
//void close_3G(u8 type)
//{
//  // �ػ����� *OFF# 
//  if(type==1)
//  {
//    WCDMA_Power_OFF;  
//  }
//  else if(type==2)
//  {
//    WCDMA_Power_OFF;   
//    delayms_keybreak(1000);
//  }
//  else
//  {
//    send_string_3G("*OFF#"); //��������������
//    delayms_keybreak(4000);
//    WCDMA_Power_OFF;  
//  }
//}








u8 rec_gprs(unsigned long delay_wait,unsigned char *shujv,u8 change)//andyluo2011-02-12
{	
  unsigned short i;
  u32 ack_err;       
  RxCounter = 0;
  ack_err = delay_wait *KEYTIMEOUT_1S;
  while(ack_err--){
	  /* ι��*/
	  IWDG_ReloadCounter();//2015-12-23 andyluo
    if(key_flag)
    {
        return 0;           
    }
    
    if(RxBuffer[RxCounter-1] != '*')
        continue;
    if(RxCounter!=300){
        for(i=0;i<RxCounter;i++)
            shujv[i] = RxBuffer[i];
        return 1;
    }
    else{			
        shujv[5]='*';
        return 0;
    }

  }
  return 0;
}
//ʵʱ����RTCʱ�� locs-ʱ��RxBuffer��ʼλ�� 2015-08-08  andyluo
void Update_RTC(u8 locs)
{
u8 timenew[7],timenewH[7],buffer[2],i,j,ckflag;
u32 tln,tlnold,subv;

#ifdef NOUPDATE_RTC
	return;
#endif

	I2C_ReadS_24C(SYS_RTC,buffer,1);//ʱ��ʵʱ���¿��� 1-�� 0-��
	if(locs>30)//��¼ʱ�����ж�
		{
		if(buffer[0]==0)return;//δ����ʵʱ����
		}
	i = locs;
	for(j=0;j<5;j++)
		timenew[4-j] = (asic_to_hex(RxBuffer[i+j*3])<<4)+asic_to_hex(RxBuffer[i+j*3+1]);
	//time[4]-time[0]//YYMMDDHHMM
	ckflag = JD_TIMECK(timenew,1);
	if(ckflag==OK)
		{		
		for(i=0;i<6;i++)
			 timenewH[i] = BCDtoHex(timenew[i]);
//		GetCurrentTime();
		if(timenewH[1]==0)
			tln = 24*60+timenewH[0];
		else
			tln = timenewH[1]*60+timenewH[0];
		if(time1[1]==0)
			tlnold = 24*60+time1[0];
		else
			tlnold = time1[1]*60+time1[0];
		if(tln>tlnold)
			subv = tln-tlnold;
		else
			subv = tlnold-tln;

		ckflag=0;
		if((timenew[4]!=time[4])||(timenew[3]!=time[3])||(timenew[2]!=time[2]))
			ckflag=1;		
		else if(subv>2)//����ʱ�� RTC
			ckflag=1;
		if(ckflag)
			set_current_time(timenew); 			
		}	
	return;
}


uchar rec_gprs_feeYW(uchar delay_wait)
{
    u32 timeOut;
	u16 i;
#ifdef MU509B
	//2�ж���û�з��ɹ�(���Ϳ�����Ҫһ��ʱ��)---------------start-------------------------------------
	//timeout=WAITPCDATATIMES;
		timeOut=40; //10  
		while(timeOut--)
			{ 
			if(ReadGsmString(READWAITTWOTIME))	
			if((RxBuffer[0]==0x4F)&&(RxBuffer[1]=='K'))//OK
				{ 
				break;
				}
			if(key_flag)
			  return 2;
			if(timeOut==1) 
				return 1; //ʧ��
			}
	//2�ж���û�з��ɹ�---------------end-------------------------------------
	//3�����жϺ�̨����--------------------start-------------------------------------
		timeOut= 40;
		EmptyRcv3G();
		IWDG_ReloadCounter();
		while(timeOut)
			{
			if(ReadGsmString(READWAITTWOTIME))
				{//^IPDATA: 
				if((recv_3G[0]=='^')&&(recv_3G[1]=='I')
					&&(recv_3G[3]=='D')&&(recv_3G[7]==':')) 
					{			
					f_receiveOK = NG;
		            for(i=1;i<RxCounter;i++)
						{
						if(i>1000)return 0;
		//#<ErrorCode><AA1501301619005500220864320203300024010499120015020155002208643202033000240104991200AB></ErrorCode>*
		                if((RxBuffer[i-1] == '<') && (RxBuffer[i] == 'E') && (RxBuffer[i + 1] == 'r') && (RxBuffer[i + 2] == 'r') && (RxBuffer[i + 3] == 'o') && (RxBuffer[i + 4] == 'r'))
							{
							f_receiveOK = OK;
							return i + 11;
		                	}
						}
					return 0;
					}	
				} 
			if(key_flag)
				return 2;
			} 
		return 1;  
#endif

    timeOut = delay_wait * KEYTIMEOUT_1S*5;
    while(timeOut--)
		{
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
		if(f_receiveOK == OK)
			{			
			f_receiveOK = NG;
            for(i=1;i<RxCounter;i++)
				{
				if(i>1000)return 0;
//#<ErrorCode><AA1501301619005500220864320203300024010499120015020155002208643202033000240104991200AB></ErrorCode>*
                if((RxBuffer[i-1] == '<') && (RxBuffer[i] == 'E') && (RxBuffer[i + 1] == 'r') && (RxBuffer[i + 2] == 'r') && (RxBuffer[i + 3] == 'o') && (RxBuffer[i + 4] == 'r'))
					{
					f_receiveOK = OK;
					return i + 11;
                	}
				}
			return 0;			 
        }  
	if(key_flag)
		{
		return 0;            
        }
	}
	return 0;
}



//����GPRS��Ӧ��
//#<ErrorCode><0></ErrorCode><Time><2015-07-17|18:25:10></Time>*
uchar rec_gprs_ack(uchar delay_wait)
{
    u32 timeOut;
	u16 i;
#ifdef MU509B
//2�ж���û�з��ɹ�(���Ϳ�����Ҫһ��ʱ��)---------------start-------------------------------------
//timeout=WAITPCDATATIMES;
	timeOut=40; //10  
	while(timeOut--)
		{ 
		if(ReadGsmString(READWAITTWOTIME))	
		if((RxBuffer[0]==0x4F)&&(RxBuffer[1]=='K'))//OK
			{ 
			break;
			}
		if(key_flag)
		  return 2;
		if(timeOut==1) 
			return 1; //ʧ��
		}
//2�ж���û�з��ɹ�---------------end-------------------------------------
//3�����жϺ�̨����--------------------start-------------------------------------
 	timeOut= 40;
	EmptyRcv3G();
	IWDG_ReloadCounter();
	while(timeOut)
		{
		if(ReadGsmString(READWAITTWOTIME))
			{//^IPDATA: 
			if((recv_3G[0]=='^')&&(recv_3G[1]=='I')
				&&(recv_3G[3]=='D')&&(recv_3G[7]==':'))	
				{
				f_receiveOK = NG;
				for(i=1;i<GSML-6;i++)
					{
					if(i>1000)return 1;
					if((recv_3G[i-1] == '<') && (recv_3G[i] == 'E') && 
						(recv_3G[i + 1] == 'r') && (recv_3G[i + 2] == 'r') &&
						(recv_3G[i + 3] == 'o') && (recv_3G[i + 4] == 'r'))
						{
						f_receiveOK = OK;
						memcpy(RxBuffer+i+34,recv_3G+i+34,30);
						//RxBuffer[i+34]-35 37-38 40-41 43-44 46-47
						Update_RTC(i+34);
						return asic_to_hex(recv_3G[i + 11]);
						}
					} 
				}	
			} 
		if(key_flag)
			return 2;
		} 
	return 1;  
#endif
	
    timeOut = delay_wait * KEYTIMEOUT_1S*5;
    while(timeOut--)
		{
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
		if(f_receiveOK == OK)
			{
			f_receiveOK = NG;
            for(i=1;i<RxCounter;i++)
				{
				if(i>1000)return 1;
                if((RxBuffer[i-1] == '<') && (RxBuffer[i] == 'E') && (RxBuffer[i + 1] == 'r') && (RxBuffer[i + 2] == 'r') && (RxBuffer[i + 3] == 'o') && (RxBuffer[i + 4] == 'r'))
					{
					f_receiveOK = OK;
					//RxBuffer[i+34]-35 37-38 40-41 43-44 46-47
					Update_RTC(i+34);
					return asic_to_hex(RxBuffer[i + 11]);
                	}
				}
        }  
	if(key_flag)
		{
		return 1;            
        }
	}
	return 1;
}

uchar rec_IAP(uchar delay_wait,uchar data[])
{
    u32 ack_err,timeOut;
    int i;

#ifdef MU509B
		//2�ж���û�з��ɹ�(���Ϳ�����Ҫһ��ʱ��)---------------start-------------------------------------
		//timeout=WAITPCDATATIMES;
			timeOut=40; //10  
			while(timeOut--)
				{ 
				if(ReadGsmString(READWAITTWOTIME))	
				if((RxBuffer[0]==0x4F)&&(RxBuffer[1]=='K'))//OK
					{ 
					break;
					}
				if(key_flag)
				  return 2;
				if(timeOut==1) 
					return 1; //ʧ��
				}
		//2�ж���û�з��ɹ�---------------end-------------------------------------
		//3�����жϺ�̨����--------------------start-------------------------------------
			timeOut= 40;
			EmptyRcv3G();
			IWDG_ReloadCounter();
			while(timeOut)
				{
				if(ReadGsmString(READWAITTWOTIME))
					{//^IPDATA: 
					if((recv_3G[0]=='^')&&(recv_3G[1]=='I')
						&&(recv_3G[3]=='D')&&(recv_3G[7]==':')) 
						{
			            for(i = 0;i<RxCounter;i++)
			            {
			                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'x' && RxBuffer[i + 3] == 't' )
			                {                   
			                      data[14] = i + 6;
			                      break;
			                }
			            }
			            
			            for(i = RxCounter;i > 0;i--)
			            {
			                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'x' && RxBuffer[i + 3] == 't' )
			                {                   
			                      data[15] = i - 3;
			                      return 1;
			                }
			            }
			                     
			            break;
			        }	
					} 
				if(key_flag)
					return 2;
				} 
			return 1;  
#endif

	
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
        if(f_receiveOK == OK)
        {
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'x' && RxBuffer[i + 3] == 't' )
                {                   
                      data[14] = i + 6;
                      break;
                }
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'x' && RxBuffer[i + 3] == 't' )
                {                   
                      data[15] = i - 3;
                      return 1;
                }
            }
                     
            break;
        }
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x00;
    
    return 0x00;
}


uchar recFreeCom(uchar delay_wait,int data[])
{
    u32 ack_err;
    int i;
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
        if(f_receiveOK == OK)
        {
			f_receiveOK = NG;
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'F' && RxBuffer[i + 1] == 'r' && RxBuffer[i + 2] == 'e' && RxBuffer[i + 3] == 'e' )
                {                   
                      data[0] = i + 6;
					  f_receiveOK = OK;
                      break;
                }
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'F' && RxBuffer[i + 1] == 'r' && RxBuffer[i + 2] == 'e' && RxBuffer[i + 3] == 'e' )
                {                   
                      data[1] = i - 3;
                      return 1;
                }
            }
                     
            break;
        }
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x00;
    
    return 0x00;
}



uchar recTimeData(uchar delay_wait,int data[])
{
    u32 ack_err;
    int i;
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
        if(f_receiveOK == OK)
        {
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'i' && RxBuffer[i + 2] == 'm' && RxBuffer[i + 3] == 'e' )
                {                   
                      data[0] = i + 6;
                      break;
                }
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'i' && RxBuffer[i + 2] == 'm' && RxBuffer[i + 3] == 'e' )
                {                   
                      data[1] = i - 3;
                      return 1;
                }
            }
                     
            break;
        }
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x00;
    
    return 0x00;
}

uchar recFreeData(uchar delay_wait,int data[])
{
    u32 ack_err;
    int i;
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
        if(f_receiveOK == OK)
        {
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'F' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'e')
                {                   
                      data[0] = i + 5;
                      break;
                }
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'F' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'e')
                {                   
                      data[1] = i - 3;
                      return 1;
                }
            }
                     
            break;
        }
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x00;
    
    return 0x00;
}







u8 rec_gprs_L(uchar delay_wait,uchar data[])
{
    u32 ack_err;
    int i;
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
        if(f_receiveOK == OK)
        {
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && (RxBuffer[i] == 'B') && (RxBuffer[i + 1] == 'C') && (RxBuffer[i + 2] == 'C'))
                {
                    for(int j=0;j<2;j++)
                      data[j] = RxBuffer[i + 5 + j];//BCC
                }
                
                if((RxBuffer[i-1] == '<') && (RxBuffer[i] == 'C') && (RxBuffer[i + 1] == 'o') && (RxBuffer[i + 2] == 'u'))
                {
                    for(int j=2;j<6;j++)
                      data[j] = RxBuffer[i + 7 + j - 2];//Count
                }
                
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'N' && RxBuffer[i + 1] == 'i' && RxBuffer[i + 2] == 't' && RxBuffer[i + 3] == 'e' && RxBuffer[i + 4] == 'm')
                {
                    for(int j=6;j<10;j++)
                      data[j] = RxBuffer[i + j + 1];
                }
                
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'h' && RxBuffer[i + 1] == 'm' && RxBuffer[i + 2] == 'd' && RxBuffer[i + 3] == 'S' && RxBuffer[i + 4] == 'e')
                {
                    for(int j=10;j<14;j++)
                      data[j] = RxBuffer[i + j - 2];
                }
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'x' && RxBuffer[i + 3] == 't' )
                {                   
                      data[14] = i + 6;
                      break;
                }
                
                if(key_flag)
                  return 0x00;
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'x' && RxBuffer[i + 3] == 't' )
                {                   
                      data[15] = i - 3;
                      return 1;
                }
                
                if(key_flag)
                  return 0x00;
            }
                     
            break;
        }
        
        if(key_flag)
          return 0x00;
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x03;
    
    return 0x00;
}
////////////////////////////////////////////////////////////////////////////////////////////////
u8 rec_gprs2(unsigned long delay_wait,unsigned char *shujv,u8 change)//andyluo2011-02-12
{
	unsigned short i;
	unsigned char a;
	u32 ack_err;
        
	RxCounter = 0;
	ack_err = delay_wait * KEYTIMEOUT_1S;
	while(ack_err--)  
	{
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
		if(key_flag)
			{
			a = key_scan1();
			if(a == KEY_Cancel)
			{	
			return 0xe7;
			}
			}                  
		if(RxBuffer[RxCounter-1] != '*')
			continue;
		if(RxCounter!=300)
			{
			for(i=0;i<RxCounter;i++)
				shujv[i] = RxBuffer[i];
		
			return 1;
			}
		else
			{			
			shujv[5]='*';
			return 0;
			}

	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////

u8 rec_gprs1(unsigned long delay_wait,unsigned char *shujv)//andyluo2011-02-12
{
 // unsigned char a;
  unsigned long i,ack_err;
  

		RxCounter = 0;
		ack_err = KEYTIMEOUT_1S*delay_wait;
		while(ack_err--)  
			{
				/* ι��*/
				IWDG_ReloadCounter();//2015-12-23 andyluo
                          if((ack_err==1)&&(ack_err==0))
                            return 0;
			if(RxBuffer[RxCounter-1] == 0x0D)
				break;
			}
		for(i=0;i<RxCounter;i++)
			shujv[i] = RxBuffer[i];

			return 1;
}

/*
*<IP><14.154.233.181><PT><7600><APN><"CTNET","CARD","CARD">#
�ϸ�ʽ��
*I0P<121.34.41.198><PT><3333><AN><1,"IP","ctnet">#

*/

//ip:192.168.1.87 ���֣�PaymentDB �û�����sa ���룺316116

//software_sever IP and port.
void send_ip(unsigned char *IP_Add,unsigned char *PORT)
{
u8 buffer[32],i,j,sendip[100];
u8 username[32],userpsd[32];
     //unsigned char sz7[20];
     //unsigned char k,i;//,Comport;

 //   ywcj@jhywcj.vpdn.zj
 //   123456
 //172.16.0.8:9001

#ifdef JY_REALNETTEST
   uart_send_som("*<IP><10.90.21.2><PT><8003><APN><\"3GNET\",\"lsjyxcg01@lsjyxcg.vpdn.zj\",\"123456\">#");
   return;//10.90.21.2:8003 lsjyxcg019lsjyxcg.vpdn.zj,123456
#endif 
#ifdef YW_VPN
	uart_send_som("*<IP><172.16.0.8><PT><9001><APN><\"3GNET\",\"ywcj@jhywcj.vpdn.zj\",\"123456\">#");
	return;
#endif 

	 
	 I2C_ReadS_24C(APNuser_possword,buffer,32);//��IP��
	 for(i=0;i<32;i++)
	 	{
		if(buffer[i] == 0xff)break;
		username[i] = buffer[i];
	 	}
         username[i++] = '\0';
	 for(j=0;i<32;i++)
	 	{
	 	if(buffer[i] == 0xff)break;
		userpsd[j++] = buffer[i];
	 	}
         userpsd[j] = '\0';
	 memset(sendip,0,100);
	 strcat(sendip,"*<IP><");
	 strcat(sendip,IP_Add);
	 strcat(sendip,"><PT><");
	 strcat(sendip,PORT);
	 // 	uart_send_som("<APN><\"3GNET\",\"");
	 //   //uart_send_som(username);
	 //   uart_send_som("CARD");
	 //   uart_send_som("\",\"");
	 //   //uart_send_som(userpsd);
	 //   uart_send_som("CARD");
	 //   uart_send_som("\">#");
	 strcat(sendip,"><APN><\"3GNET\",\"");
	 strcat(sendip,username);
	 strcat(sendip,"\",\"");
	 strcat(sendip,userpsd);	 
	 strcat(sendip,"\">#");
//	 strcat(sendip,"><APN><\"3GNET\",\"CARD\",\"CARD\">#");
//	 uart_send_som(sendip);
	 uart_send_som(sendip);

	 
//	 uart_send_som("*<IP>");
//	 uart_send_som("<");
//	 uart_send_som(IP_Add);
//	 uart_send_som(">");
//	 
//     uart_send_som("<");
//     uart_send_som("PT");
//     uart_send_som(">");
//     
//     uart_send_som("<");
//     uart_send_som(PORT);
//     uart_send_som(">");
//     
//     //uart_send_som("<AN><1,\"IP\",\"ctnet\">#");
//	 
//     uart_send_som("<APN><\"CTNET\",\"");
//	 //uart_send_som(username);
//	 uart_send_som("CARD");
//	 uart_send_som("\",\"");
//	 //uart_send_som(userpsd);
//	 uart_send_som("CARD");
//	 uart_send_som("\">#");
//		 
		 //*<IP><14.154.233.181><PT><7600><APN><"CTNET","CARD","CARD">#
          
         /*
	 for(k=1;k<sz7[0]+1;k++)
	 	{
	 	uart_send(sz7[k]);
		if(sz7[k] == 'P')
			i = k+1;
	 	}
	 uart_send_som(",");
	 for(k=i;k<sz7[0]+1;k++)
	 	uart_send(sz7[k]);
	 uart_send_som("#");
	 
	 return;
         */
}

void send_data(unsigned char *data)
{
    uart_send_som("*0%");
    uart_send_som(data);
    uart_send_som("#");
    
}
void send_apn()
{
     unsigned char sz7[80];
     unsigned int k;
//     unsigned char a,kk;
     unsigned char kk;

      uart_send_som("*APN");     
      kk=0;
	 for(k=0;k<64;k++)     
	 {
            uart_send(sz7[k]);
	    if(sz7[k]=='"')
	        kk=kk+1;
	    if(kk==6)
	        break;
	 }
         uart_send_som("#");         

}
///////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////

u8 Link_DPS(void)
{
	u8 netstate;
	u32 linkacktime;
	delay(KEYTIMEOUT_1S);
	send_DPSip();
	delay(KEYTIMEOUT_1S*2);
	Wakeup__3G_CDMA;	
	netstate = NG;
	linkacktime = KEYTIMEOUT_1S*30;
	while(linkacktime--)
		{
		if((RxBuffer[1] == 'L')&&(RxBuffer[3] == 'k'))
			{
			gprs_user = OK;
			netstate = OK;
			break;	//#Lok*  �����ɹ�	
			}
		}
	if(netstate == OK)
		{
                  
		delay(KEYTIMEOUT_1S/2);
		GPRS_CSQ(Ishide);
		Refresh_SYSallicon();
		delay(KEYTIMEOUT_1S/2);
		}
	return netstate;
	
}
/*  return 0 ���� �˳�
 *  return 1 �ɹ����� �˳�
 *  return 2 ��������ʧ�� �˳�
*/
u8 Link_network(void)
{
unsigned char sz7[100];
unsigned int k,quit_flag = 0;
unsigned short i;
u32 ack_err;	       
      
      read_IP();
      send_ip(IP,PORT);
	  for(i=0;i<RxCounter;i++)
	  	RxBuffer[i] = 0x00;  
	  RxCounter = 0;  
	  f_receiveOK = 0; 
	  ack_err = 8 * KEYTIMEOUT_1S;
	  while(ack_err > 0)
	  	{
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
		if(wake_flag == RFG24_wakeup)return 5;
		ack_err--;
		if(key_flag||key_flagbk)
			{
			quit_flag =1;
			break;
			}
		if(RxBuffer[RxCounter-1] != '*')
			continue;
		if(RxCounter <= 100)
			{
			for(i=0;i<RxCounter;i++)
				sz7[i] = RxBuffer[i];
			quit_flag = 2;
			break;
			}
		else{	
			sz7[5]='*';
			} 
		}
	if(quit_flag == 1)		
		return 0;
	else if(quit_flag == 2)
		{
		//#IP*  �����ɹ�		
		for(k=0;k<100;k++)
			{
			if(sz7[k]=='#')
				{
				if(sz7[k+1]=='I' && sz7[k+2]=='P' && sz7[k+3]=='*')
                    {  
					NETSTATE = NETSTATE_LINK;
					return 1;
					}
				return 2;
				}		
			}		
		return 3;
		}
	else
		{
		return 4;
		}
}
////********************************************
void close_gprs_power1()
{
	close_uart();
	delay(500);
	return;
}

/*  return 0 ���� �˳�
 *  return 1 �ɹ����� �˳�
 *  return 2 ��������ʧ�� �˳�
 */
//Center sever:disconnect      DPS sever: connect        CS.:��DS.:��
u8 open_gprs()
{
u8 loop,sendFlag;
u32 timeOut=0;
//	TMP.rerun = 0xDD;//2016-03-29 andyluo
	TMP.rerun = 0xEE;//2016-03-29 andyluo
	if(TMP.rerun != 0xDD)
		OPEN_EXTI9_5_IRQ(); 
	else
		DISABLE_EXTI9_5_IRQ(); 	
	
	wake_flag = 0;
	OPEN_EXTI15_10_IRQ();	
	key_flagbk = 0;
	key_flag= 0;
	if((wake_flag == RFG24_wakeup)&&(TMP.rerun != 0xDD))return NG;	
	if(SYS_MS.G3S ==OFF)return NG;
	RxCounter =0;	
	f_receiveOK = 0; 
	TMP.BaseFlag = JD_ZJ_MB_SYS();//1-������� 0-�м�(���)
	if(TMP.BaseFlag)
		{//���ϵͳ
		#ifdef	MB_2G4	//�м̴���
		
		return OK;//�����2.4G����
		#endif
		}
	UART1_IRQn_CTL(ON);
//	sendFlag =NETSTATE_FUN("*LK?#");
//	if(sendFlag==NETSTATE_LINK)
//		{
//		NETSTATE = NETSTATE_LINK;
//		return OK;//����δ�Ͽ�
//		}
#ifdef MU509B
	sendFlag = 1;
	if(NETSTATE == NETSTATE_SLEEP)
		{
//		SLEEP_3G_OFF;//��ģ��˯�ߵ�//����ģ��130108
//		delay(10000);
		sendFlag =wake_3G(1);
		}	
	if(sendFlag)
		sendFlag = MU509link_net();
	
	if(sendFlag)//ģ�鲻����������
		{
		//KEYOP_RETURN ERROR3GSTART ERROR3GSTART  
		//ERROR3GSIM  ERROR3GPASSWORD ERROR3GLINK
		NETSTATE = NETSTATE_CLOSE;
		close_gprs_power();
		return 0;
		}
	NETSTATE = NETSTATE_ONLINE;
	return 1;
#endif

	if(NETSTATE == NETSTATE_ONLINE)
		return OK;//����δ�Ͽ�
	else if(NETSTATE == NETSTATE_LINK)
		{
		loop = 1;
		while(loop--)
			{
//			sendFlag =NETSTATE_FUN("*LK?#");
			sendFlag =NETSTATE_FUN("@@@@@*WAKE#");
			if(sendFlag==NETSTATE_LINK)break;
			}
		if(sendFlag == NETSTATE_KEYCL)
			{
			NET_KeyDeal();	
			return NG;
			}			
		else if(NETSTATE != NETSTATE_LINK)
			{
			NETSTATE = NETSTATE_CLOSE;
//			return NG;
			}
		else
			return OK;//����δ�Ͽ�
		}
	if(NETSTATE == NETSTATE_SLEEP)//���紦������״̬
		{//��������--
		loop = 1;
		while(loop--)
			{
//			sendFlag =NETSTATE_FUN("*LK?#");
			sendFlag =NETSTATE_FUN("@@@@@*WAKE#");
			if(sendFlag==NETSTATE_LINK)break;
			}
		if(NETSTATE != NETSTATE_LINK)
			{
			NETSTATE = NETSTATE_CLOSE;
//			return NG;
			}
		else
			return OK;//����δ�Ͽ�
		
		}
	else if(NETSTATE != NETSTATE_CLOSE)
		{
		loop = 1;
		while(loop--)
			{
			sendFlag =NETSTATE_FUN("@@@@@*WAKE#");
			if(sendFlag==NETSTATE_LINK)break;
			}
		if(sendFlag == NETSTATE_KEYCL)
			{
			NET_KeyDeal();	
			return NG;
			}                
		if(NETSTATE != NETSTATE_LINK)
			{
			NETSTATE = NETSTATE_CLOSE;
//			return NG;
			}
		else
			return OK;//����δ�Ͽ�
		}


	
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	close_gprs_power();
	delay(KEYTIMEOUT_1S/10);
	open_gprs_power();
	key_flag= 0;
//	delay(KEYTIMEOUT_1S / 10);         
    while(timeOut < KEYTIMEOUT_1S * 8)
	   {
	   /* ι��*/
	   IWDG_ReloadCounter();//2015-12-23 andyluo
	   if((wake_flag == RFG24_wakeup)&&(TMP.rerun != 0xDD))return NG;  
	   
	   if(key_flag||key_flagbk)
	   	{
		NET_KeyDeal();	
		return NG;
       	}
       timeOut++;
	   if(f_receiveOK==1) //�յ��ظ��ȴ�3Gģ���ʼ��
	   	 { 
		 f_receiveOK = 0;
		 if((RxBuffer[1]=='A')&&(RxBuffer[2]=='A'))  //#AA*�ɹ�
		 	break;	
		 }
	   }	
	if(RxBuffer[1]!='A')
		return 2;		
	 return Link_network();
}

void NET_KeyDeal(void)
{
u8 loop,sendFlag;

//	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_11)==0)//����״̬	
//		return
	key_flag = key_flagbk;
	loop = 3;
	while(loop--)
		{
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
		sendFlag =NETSTATE_FUN("*SLEEP#");
		if(key_flag)break;
		if(sendFlag==NETSTATE_SLEEP)break;
		}
	return;
}

/*
(����?3G ��)��������˵����
? *SLEEP#��  //���� 3G ��-----�ɹ�����#SS*
? @@@@@*WAKE#�� //���� 3G �壬������������-----�ɹ�����#IP*
? *OFF#��   //��������·----�ɹ�����#OK*
? *LK?#��  //��ѯ��������״̬-----����״̬����#IP*�����򷵻� #NOIP*
? *CSQ#��   //��ѯ��ǰ�ź�ֵ-----�������磺 #23*
ǰ�� 2 �������������ߺͻ��� 3G �壬 ���� 3 ����� *OFF#\*LK?#\*CSQ#�����ڵ��ԡ�
*VR#
*/
u8 NETSTATE_FUN(u8* NETFUN)
{

  unsigned char sz7[50],G3ST;
  unsigned int k,quit_flag = 0;
  unsigned short i;
  u32 ack_err;	 
  
  key_flag = 0;
  key_flagbk = 0;

  if((NETFUN[1] == 'S')&&(NETFUN[2] == 'L'))
  	{
	// 1-���� 0-˯��
	G3ST = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_11);
  	if(G3ST==0) 
		{
		NETSTATE = NETSTATE_SLEEP;
		return NETSTATE_SLEEP; 
  		}
  	}
  
  uart_send_som(NETFUN);
	  
  for(i=0;i<RxCounter;i++)RxBuffer[i] = 0x00;	 
  
  RxCounter = 0;   
  f_receiveOK = 0;
	  
  ack_err = 5 * KEYTIMEOUT_1S;
  while(ack_err > 0)
  	{
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	ack_err--;
	if((key_flag)&&(key_flag==key_flagbk))
		{
		quit_flag =1;
		break;	
		}
	if(RxBuffer[RxCounter-1] != '*')
		continue;
	if(RxCounter <= 50)
		{
		for(i=0;i<RxCounter;i++)
			sz7[i] = RxBuffer[i];
		quit_flag = 2;
		break;
		}
	else{ 		
		quit_flag = 2;
		sz7[5]='*';
		} 
	  }
	if(quit_flag == 1)		
		{				
//		NETSTATE = NETSTATE_KEYCL;
		return NETSTATE_KEYCL;	
		}
	else if(quit_flag == 2)
		{
	//#IP*	�����ɹ�	
		for(k=0;k<50;k++)
			{
			if(sz7[k]=='#')
				{
				if(sz7[k+1]=='I' && sz7[k+2]=='P' && sz7[k+3]=='*')
					{				
					NETSTATE = NETSTATE_LINK;
					return NETSTATE_LINK;	
					}
				else if(sz7[k+1]=='s' && sz7[k+2]=='s' && sz7[k+3]=='*')
					{
					NETSTATE = NETSTATE_SLEEP;
					return NETSTATE_SLEEP;				
					}	
				else if(sz7[k+1]=='N' && sz7[k+2]=='O' && sz7[k+5]=='*')
					{
					NETSTATE = NETSTATE_ERR;
					return NETSTATE_ERR;				
					}
				else if(sz7[k+1]=='V' && sz7[k+2]=='R')
					return NETSTATE_VR;
				else
					{
					NETSTATE = NETSTATE_CLOSE;
					return NETSTATE_CLOSE;				
					}
				}
			}
		}
	NETSTATE = NETSTATE_CLOSE;
	return NETSTATE_CLOSE;				
}


/*CDMA����
@@@@@---------MU509B--ģ�������ֲ---------@@@@@
@@@@@---------MU509B--ģ�������ֲ---------@@@@@
andyluo 2016-03-04 ӡ����ֲ
@@@@@---------MU509B--ģ�������ֲ---------@@@@@
@@@@@---------MU509B--ģ�������ֲ---------@@@@@
*/
//�а�������
void delayms_keybreak(u32 t)     //Լ��ʱn��ms��
{
  u32 i;
  while(t--)
  	{
	IWDG_ReloadCounter();
    i=8000;
    while(i--)
		{
		if(key_flag||(wake_flag == RFG24_wakeup))
			return;
		}
	}   
}
//�а�����������������
void delayms_break(u32 t)     //Լ��ʱn��ms��
{
 	delayms_keybreak(t);
}

/*3Gͨ�Žӿڵ�һ�η�������100���ַ�*/
void send_string_3G(u8 *ptr)
{  
  USART_Puts(USART1,ptr);   
}

/***�����3G����********/
void EmptyRcv3G(void)   //
{     
  do
  	{ 
	esflag_3G=0;
	delayms(5);
//	 delay_ms(5); //5ms��ʱ
	}while(esflag_3G);
  s_head_3G=0;
  s_tail_3G=0;
  //����
  recv_3G[0] = 0; 
  RxCounter =0;
  RxBuffer[0]=0;
  RxBuffer[1]=0;
}

/**********************************************************
***********��G3ģ���Ƿ������ݷ��͹���*********************
***********************************************************/
u8 Read3GChar(void)   //�˺����ж��Ƿ������ݴ�����
{       
  
  u16 s_tailc; 

  esflag_3G=0;	
  s_tailc=s_tail_3G;      
  if(s_tailc==s_head_3G)
  	{   
    if(esflag_3G==0) 
		{
		s_tail_3G=s_tailc; 
		return 0;
		}  
	}
  gg_3G=recv_3G[s_tailc];
  s_tailc++;
  if(s_tailc==GSML)  
  	s_tailc=0;          
  s_tail_3G=s_tailc; 
  return 1;
}

u8 ReadGsmString_AMT(u16 timeout) 
{   
  
  RxCounter=0;    
  while(--timeout)
  	{  
	if(Read3GChar())
		{   
		esflag_3G=1;
		RxBuffer[RxCounter]=gg_3G;
		if(RxCounter<(GSML-1))
			{  
			RxCounter++;
			if(gg_3G==0x0A)
				{
				if(RxCounter>5)
					{
					if((RxBuffer[RxCounter-3]==0x0D)&&
            		(RxBuffer[RxCounter-2]==0x0A)&&  
            		(RxBuffer[RxCounter-1]==0x0D)) 
	            		{
						break;
						}
					} 
				}
			}
		}
	else
		{   
	    delayms_keybreak(50);  //500          
	    }
	if(key_flag) 
		return 2;
	}
  RxBuffer[RxCounter]=0;
  if(RxCounter)
  	return 0;
  else
    return 1;
}

u8 ReadGsmString(u16 timeout) 
{  
   while(--timeout)
   	{
	if(OK_flag_3G)
		{
		OK_flag_3G=0;
		RxBuffer[0]='O';
		RxBuffer[1]='K';
		return 1;
		}
	delayms_keybreak(1); 
    IWDG_ReloadCounter();
 	if(key_flag||(wake_flag == RFG24_wakeup))
//	if(key_flag)
		return 2;
	}
   return 0;
}
/*------------------------------------------------------------------------------------------------------------*/
void send_string_ATCMD(u8 *rt)     //����ATָ���
{  
  send_string_3G(rt);
  USART_Putc(USART1,0x0d);//�س�����
  USART_Putc(USART1,0x0a);
}
//MU509�������
/********�򿪻��߹رջ���************/
u8 ATE_G3(u8 onoff)    
{    
  u8 flag;
  char   j=0;
  u32 timeout;
  
  do
  {
    IWDG_ReloadCounter();
    EmptyRcv3G();
    if(onoff==DOUBLEDISPALY3GON)
    //  send_string_ATCMD("ATE1");
        send_string_ATCMD("ATE1");
    else 
      send_string_ATCMD("ATE0"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)    //ATE1  
      {
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))//O0K
        { 
          
          return 0;
        }
        else if( ( RxBuffer[0] == 'E' ) && ( RxBuffer[1] == 'R' ) )
        {        
          break;
        }
        
      }
      else if(flag==2)
        return KEYOP_RETURN;
    //  else
      //  break;
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

/********��ѯ�汾��************
ATI

Manufacturer: huawei
Model: MU509
Revision: 11.813.01.13.00
IMEI: 355897043277102

OK
-------------------------------------*/
u8 ATI_G3(void)  
{  
  u8 flag;  
  char j=0;
  u32 timeout; 
  
   // EmptyRcv3G(); 
  do
  {
    IWDG_ReloadCounter();
    EmptyRcv3G();   
    send_string_ATCMD("ATI");
  //   send_string_ATCMD("AT+CGMM"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {      
      flag=ReadGsmString(READWAITONETIME);
      
    //  flag=ReadGsmString_AMT(READWAITONETIME);  
      if(flag==1)
      {
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
         //   if((RxBuffer[3]=='C')&&(RxBuffer[4]=='G')&&(RxBuffer[5]=='M')&&(RxBuffer[6]=='M'))     
        { 
          return 0;
        }
      }
      else if(flag==2)
        return KEYOP_RETURN;
    //  else
    //    break; 

        
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

/*��ȡSIM ��ǰ�ļ�Ȩ״̬ AT+CPIN?**********************
AT+CPIN? 
+CPIN: READY 
OK
**********************/
u8 CPIN_G3(void)  
{  
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_ATCMD("AT+CPIN?");   
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)        
      {
      //  if((RxBuffer[0]=='+')&&(RxBuffer[4]=='N'))//+CPIN: READY 
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
        { 
          return 0;
        }
       /* else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E'))//+CME ERROR: SIM busy
        {
          delayms_break(1000);//��ʱ
          break;
        }*/
      }
      else if(flag==2)
        return KEYOP_RETURN; 
     /* else
      {
        break;
      } */
    }
    j++; 
  }while(j<=4);
  
  return 1;
}
u8 CPIN_CPBS(void)  
{  
  u8 flag;
  char j=0;
  u32 timeout;
  
  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_ATCMD("AT+CPBS=\"ON\"");   
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)        
      {
      //  if((RxBuffer[0]=='+')&&(RxBuffer[4]=='N'))//+CPIN: READY 
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
        { 
          return 0;
        }
       /* else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E'))//+CME ERROR: SIM busy
        {
          delayms_break(1000);//��ʱ
          break;
        }*/
      }
      else if(flag==2)
        return KEYOP_RETURN; 
     /* else
      {
        break;
      } */
    }
    j++; 
  }while(j<=4);
  
  return 1;
}
u8 CPIN_CPBW(void)  
{  
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_ATCMD("AT+CPBW=1,\"13632823247\",145");   
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)        
      {
      //  if((RxBuffer[0]=='+')&&(RxBuffer[4]=='N'))//+CPIN: READY 
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
        { 
          return 0;
        }
       /* else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E'))//+CME ERROR: SIM busy
        {
          delayms_break(1000);//��ʱ
          break;
        }*/
      }
      else if(flag==2)
        return KEYOP_RETURN; 
     /* else
      {
        break;
      } */
    }
    j++; 
  }while(j<=4);
  
  return 1;
}
u8 CPIN_CNUM(void)  
{  
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_ATCMD("AT+CNUM");   
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)        
      {
      //  if((RxBuffer[0]=='+')&&(RxBuffer[4]=='N'))//+CPIN: READY 
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
        { 
          return 0;
        }
       /* else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E'))//+CME ERROR: SIM busy
        {
          delayms_break(1000);//��ʱ
          break;
        }*/
      }
      else if(flag==2)
        return KEYOP_RETURN; 
     /* else
      {
        break;
      } */
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

u8 SMS_SETREAD(void)
{  
  u8 flag;
  char j=0;
  u32 timeout;  

  do
  { 
	IWDG_ReloadCounter();
	EmptyRcv3G();	 
//	send_string_ATCMD("AT+CMGR=20");	
	send_string_ATCMD("AT+CNMI?");	
	
	timeout=WAITATCMDTIME;
	while(--timeout)
	{
	  flag=ReadGsmString(READWAITONETIME);
	  if(flag==1)		 
	  {
	  //  if((RxBuffer[0]=='+')&&(RxBuffer[4]=='N'))//+CPIN: READY 
		if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
		{ 
		  return 0;
		}
	   /* else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E'))//+CME ERROR: SIM busy
		{
		  delayms_break(1000);//��ʱ
		  break;
		}*/
	  }
	  else if(flag==2)
		return KEYOP_RETURN; 
	 /* else
	  {
		break;
	  } */
	}
	j++; 
  }while(j<=4);
  
  return 1;
}

u8 SMS_SETMODE(void)
{  
  u8 flag;
  char j=0;
  u32 timeout;	

  do
  { 
	IWDG_ReloadCounter();
	EmptyRcv3G();	 
	send_string_ATCMD("AT+CMGF=1");		
	 //����ΪTEXT����Ϣ����0��ΪPDU��ʽ
	timeout=WAITATCMDTIME;
	while(--timeout)
	{
	  flag=ReadGsmString(READWAITONETIME);
	  if(flag==1)		 
	  {
	  //  if((RxBuffer[0]=='+')&&(RxBuffer[4]=='N'))//+CPIN: READY 
		if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
		{ 
		  return 0;
		}
	   /* else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E'))//+CME ERROR: SIM busy
		{
		  delayms_break(1000);//��ʱ
		  break;
		}*/
	  }
	  else if(flag==2)
		return KEYOP_RETURN; 
	 /* else
	  {
		break;
	  } */
	}
	j++; 
  }while(j<=4);
  
  return 1;
}

u8 SMS_SET(void)
{  
  u8 flag;
  char j=0;
  u32 timeout;  

  do
  { 
	IWDG_ReloadCounter();
	EmptyRcv3G();	 
//	send_string_ATCMD("AT+CMGR=20");	
	send_string_ATCMD("AT+CNMI=2,1");	
	
	timeout=WAITATCMDTIME;
	while(--timeout)
	{
	  flag=ReadGsmString(READWAITONETIME);
	  if(flag==1)		 
	  {
	  //  if((RxBuffer[0]=='+')&&(RxBuffer[4]=='N'))//+CPIN: READY 
		if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
		{ 
		  return 0;
		}
	   /* else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E'))//+CME ERROR: SIM busy
		{
		  delayms_break(1000);//��ʱ
		  break;
		}*/
	  }
	  else if(flag==2)
		return KEYOP_RETURN; 
	 /* else
	  {
		break;
	  } */
	}
	j++; 
  }while(j<=4);
  
  return 1;
}
	
u8 SMS_READST(void)
{  
  u8 flag;
  char j=0;
  u32 timeout;  

  do
  { 
	IWDG_ReloadCounter();
	EmptyRcv3G();	 
	send_string_ATCMD("AT+CPMS?");	
	
	timeout=WAITATCMDTIME;
	while(--timeout)
	{
	  flag=ReadGsmString(READWAITONETIME);
	  if(flag==1)		 
	  {
	  //  if((RxBuffer[0]=='+')&&(RxBuffer[4]=='N'))//+CPIN: READY 
		if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
		{ 
		  return 0;
		}
	   /* else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E'))//+CME ERROR: SIM busy
		{
		  delayms_break(1000);//��ʱ
		  break;
		}*/
	  }
	  else if(flag==2)
		return KEYOP_RETURN; 
	 /* else
	  {
		break;
	  } */
	}
	j++; 
  }while(j<=4);
  
  return 1;
}

u8 SMS_SETST(void)
{  
  u8 flag;
  char j=0;
  u32 timeout;  

  do
  { 
	IWDG_ReloadCounter();
	EmptyRcv3G();	 
	send_string_ATCMD("AT+CPMS=SM");	
	//AT+CPMS=SM ��SIM���϶�ȡ��Ϣ
	timeout=WAITATCMDTIME;
	while(--timeout)
	{
	  flag=ReadGsmString(READWAITONETIME);
	  if(flag==1)		 
	  {
	  //  if((RxBuffer[0]=='+')&&(RxBuffer[4]=='N'))//+CPIN: READY 
		if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
		{ 
		  return 0;
		}
	   /* else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E'))//+CME ERROR: SIM busy
		{
		  delayms_break(1000);//��ʱ
		  break;
		}*/
	  }
	  else if(flag==2)
		return KEYOP_RETURN; 
	 /* else
	  {
		break;
	  } */
	}
	j++; 
  }while(j<=4);
  
  return 1;
}


u8 SMS_DELALL(void)
{  
  u8 flag,SMSBUF[16];
  char j=0;
  u32 timeout;  

  

	do
	{ 
	  IWDG_ReloadCounter();
	  EmptyRcv3G();    
  //  send_string_ATCMD("AT+CMGR=20");	  
	  send_string_ATCMD("AT+CMGD=?");   
	  
	  timeout=WAITATCMDTIME;
	  while(--timeout)
	  {
		flag=ReadGsmString(READWAITONETIME);
		if(flag==1) 	   
		{
		if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
		  { 
			return 0;
		  }
		}
		else if(flag==2)
		  return KEYOP_RETURN; 
	   /* else
		{
		  break;
		} */
	  }
	  j++; 
	 }while(j<=4);

  memcpy(SMSBUF,"AT+CMGD=1,4",10);
  SMSBUF[10] = 1;
  SMSBUF[11] = 0;
  j=0;	

  do
  { 
	IWDG_ReloadCounter();
	EmptyRcv3G();	 
//	send_string_ATCMD("AT+CMGR=20");	
//	send_string_ATCMD("AT+CMGD=1,4");	
	send_string_ATCMD(SMSBUF);	
	
	timeout=WAITATCMDTIME;
	while(--timeout)
	{
	  flag=ReadGsmString(READWAITONETIME);
	  if(flag==1)		 
	  {
	  //  if((RxBuffer[0]=='+')&&(RxBuffer[4]=='N'))//+CPIN: READY 
		if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
		{ 
		  return 0;
		}
	   /* else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E'))//+CME ERROR: SIM busy
		{
		  delayms_break(1000);//��ʱ
		  break;
		}*/
	  }
	  else if(flag==2)
		return KEYOP_RETURN; 
	 /* else
	  {
		break;
	  } */
	}
	j++; 
  }while(j<=4);
  
  return 1;
}

u8 SMS_READ(void)
{  
  u8 flag;
  char j=0;
  u32 timeout;
  u8 SMSR[1];
  
  SMS_SETMODE(); 
  SMS_READST();	
  SMS_SETREAD();
  SMS_SET();  
//  SMS_SETST();	
//  SMS_SETREAD();
  SMS_DELALL();
  do
  { 
	IWDG_ReloadCounter();
	EmptyRcv3G();	 
//	send_string_ATCMD("AT+CMGR=4");	
//	
	send_string_ATCMD("AT+CMGL=\"ALL\"");	
	
	timeout=WAITATCMDTIME;
	while(--timeout)
	{
	  flag=ReadGsmString(READWAITONETIME);
	  if(flag==1)		 
	  {
	  //  if((RxBuffer[0]=='+')&&(RxBuffer[4]=='N'))//+CPIN: READY 
		if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
		{ 
		  return 0;
		}
	   /* else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E'))//+CME ERROR: SIM busy
		{
		  delayms_break(1000);//��ʱ
		  break;
		}*/
	  }
	  else if(flag==2)
		return KEYOP_RETURN; 
	 /* else
	  {
		break;
	  } */
	}
	j++; 
  }while(j<=4);
  
  return 1;
}


/*��ѯ�ź�ֵ AT+CSQ**********************
AT+CSQ
+CSQ��20,99 test_mu509c_modem
OK
**********************/
u8 CSQ_G3(void)  
{  
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_ATCMD("AT+CSQ"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)  
      {
       // if((RxBuffer[0]=='+')&&(RxBuffer[1]=='C')&&(RxBuffer[3]=='Q'))//+CPIN: READY 
       if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
        { 
          return 0;
        }
      }
      else if(flag==2)
        return KEYOP_RETURN; 
      else
      {
       // break;
      }      
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

/*//��ѯ��ǰ����ע��״�� AT+CREG? **********************
AT+CREG? 
+CREG: 0,1
OK
**********************/
u8 CREG_G3(void)
{  
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_ATCMD("AT+CREG?"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)
      {
      //  if((RxBuffer[0]=='+')&&(RxBuffer[1]=='C')&&(RxBuffer[4]=='G'))//+CPIN: READY 
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))
        { 
         // if(RxBuffer[9]=='1' || RxBuffer[9]=='5' )
           if(recv_3G[20]=='1' || recv_3G[20]=='5' )
            return 0;
          else
          {
            delayms_break(1000);//��ʱ
            break;
          }
        } 
      }
      else if(flag==2)
        return KEYOP_RETURN; 
    //  else
      //  break;      
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

//AT^IPINIT="3GNET","CARD","CARD"(TCP/UDP��ʼ������һ��CARDΪ�û�����//�ڶ���Ϊ���롣)
//OK����
//+CME ERROR: The network has been opened already
//+CME ERROR: The network has been opened already
u8 USERPASSWORD_G3(void)
{ 
  u8 flag;  
  char j=0;
  u32 timeout;
  
  
  do
  {
    IWDG_ReloadCounter();
    EmptyRcv3G();   
   // send_string_3G("AT^IPINIT=\"3GNET\",\"");
//    send_string_3G("AT^IPINIT=\"mobile.three.com.mo\",\"");
//    send_string_3G(NET.Username);
//    send_string_3G("\",\""); 
//    send_string_3G(NET.Password);  
//    send_string_ATCMD("\"");
//  	 I2C_ReadS_24C(APNuser_possword,buffer,32);//��IP��

    send_string_ATCMD("AT^IPINIT=\"3GNET\",\"CARD\",\"CARD\""); 
    
    timeout=WAITATCMDTIME*10;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITTWOTIME);
      if(flag==1)      
      {
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))//OK
        { 
          return 0;
        } 
        else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E')
                &&(RxBuffer[24]=='h')&&(RxBuffer[33]=='o')
                  )////+CME ERROR: The network has been opened already
        {
          return 0;
        }
      }
      else if(flag==2)
        return KEYOP_RETURN;      
    //  else
      //  break;      
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

//����IP����AT^IPOPEN=1,"TCP","183.15.131.174",7000,2000
//+CME ERROR: The network has not been opened yet
//+CME ERROR: The link has been established already

u8 TCPLink_G3(u8 linkflag)  
{	
  u8 flag;
  char j=0;
  u32 timeout;
  
  
  do
  {
    IWDG_ReloadCounter();
    EmptyRcv3G(); 
    read_IP();
    send_string_3G("AT^IPOPEN=1,\"TCP\",\"");
    send_string_3G(IP);
    send_string_3G("\","); 
    send_string_3G(PORT); 
    send_string_3G(",");
    send_string_ATCMD(PORT);  
    //    send_string_ATCMD("AT^IPOPEN=1,\"TCP\",\"124.172.126.161\",7600,7600"); 
   //   send_string_ATCMD("AT^IPOPEN=1,\"TCP\",\"218.17.233.35\",6000,6000"); 

    timeout=WAITATCMDTIME;
    while(--timeout)
    {      
      flag=ReadGsmString(READWAITTWOTIME);
      if(flag==1)   
      {
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))//OK
        { 
          return 0;
        }  else   if((recv_3G[51]=='E')
                     &&(recv_3G[52]=='R')
                      &&(recv_3G[53]=='R')
                       &&(recv_3G[54]=='O')
                        &&(recv_3G[55]=='R')      
                       )//CME ERROR
        { 
          return 1;
        } 
        else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E')
                &&(RxBuffer[21]=='h')&&(RxBuffer[30]=='e')
                  
                  )////+CME ERROR: The link has been established already
        {
          return 0;
        }
      }
      else if(flag==2) 
        return KEYOP_RETURN;
     // else
       // break;      
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

u8 TCPLink_G3_0(u8 linkflag)  
{	
  u8 flag;
  char j=0;
  u32 timeout;
  
  
  do
  {
    IWDG_ReloadCounter();
    EmptyRcv3G(); 
    
    send_string_3G("AT^IPOPEN=1,\"TCP\",\"");
   // send_string_3G(NET.Address);
    send_string_3G("218.17.233.35");
    send_string_3G("\","); 
   // send_string_3G(NET.Port);
    send_string_3G("9650");
    send_string_3G(",");
    //send_string_ATCMD(NET.Port);  
    send_string_3G("9650");
    //    send_string_ATCMD("AT^IPOPEN=1,\"TCP\",\"124.172.126.161\",7600,7600"); 
   //   send_string_ATCMD("AT^IPOPEN=1,\"TCP\",\"218.17.233.35\",6000,6000"); 

    timeout=WAITATCMDTIME;
    while(--timeout)
    {      
      flag=ReadGsmString(READWAITTWOTIME);
      if(flag==1)   
      {
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))//OK
        { 
          return 0;
        }  else   if((recv_3G[51]=='E')
                     &&(recv_3G[52]=='R')
                      &&(recv_3G[53]=='R')
                       &&(recv_3G[54]=='O')
                        &&(recv_3G[55]=='R')      
                       )//CME ERROR
        { 
          return 1;
        } 
        else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E')
                &&(RxBuffer[21]=='h')&&(RxBuffer[30]=='e')
                  
                  )////+CME ERROR: The link has been established already
        {
          return 0;
        }
      }
      else if(flag==2) 
        return KEYOP_RETURN;
     // else
       // break;      
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

//������
//+CME ERROR: The network has not been opened yet
u8 TCPCLOSE_G3(u8 linkflag)  
{	
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_ATCMD("AT^IPCLOSE=1"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)  
      {
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))//OK
        { 
          return 0;
        }       
      }
      else if(flag==2) 
        return KEYOP_RETURN;
      //else
       // break;       
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

//��ѯ��������״��
//����0-���� ����-����
//^IPCLOSE:1,0,0,0,0
u8 InquireLink_G3(void)  
{	
  u8 flag;
  char j=0;
  u32 timeout;  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_ATCMD("AT^IPCLOSE?"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)
      {
       // if((RxBuffer[1]=='I')&&(RxBuffer[3]=='C')&&(RxBuffer[8]==':'))//OK
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))//OK
        { 
          if(recv_3G[24]=='1')            
            return 0;
          if(recv_3G[24]=='0')            
            return 2;          
        }       
      }
      else  if(flag==2)
        return KEYOP_RETURN;
      else
        break;       
    }
    j++; 
  }while(j<=0);
  
  return 1;
}


//��������^IPSEND:1 OK
u8 DataSend_G3(u8 *str) 
{	
  u8 flag;
  char j=0;
  u32 timeout;
  
 
  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_3G("AT^IPSEND=1,\"");
    send_string_3G(str);    
    send_string_ATCMD("\"");
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      
      flag=ReadGsmString(READWAITTWOTIME);
      if(flag==1)
      {
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))//OK
        { 
          return 0;
        } 
        //        else if((RxBuffer[0]=='+')&&(RxBuffer[5]=='E')
        //                &&(RxBuffer[24]=='h')&&(RxBuffer[33]=='o')
        //                )////+CME ERROR: The network has been opened already
        //        {
        //        return 0;
        //        }
      }
      else if(flag==2)
        return KEYOP_RETURN;
      else
        break; 
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

//^IPSTATE: 1,0,0
//���ܻ��õ���AT����

//1.�򿪻��߹ر������ϱ�����
u8 CURC_G3(u8 open)
{  
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G(); 
    if(open==AUTOREPORT3GOFF)
      send_string_ATCMD("AT^CURC=0"); 
    else
      send_string_ATCMD("AT^CURC=1"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {      
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)
      {
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))//OK
        { 
          return 0;
        }       
      }
      else if(flag==2)
        return KEYOP_RETURN; 
      else
        break;
    }
    j++; 
  }while(j<=4);
  
  return 1;
  
}

//1.�򿪻��߹ر�3G����
u8 CFUN_G3(u8 open)
{  
  
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G(); 
    if(open==CFUN3GON)
      send_string_ATCMD("AT^CFUN=1"); 
    else
      send_string_ATCMD("AT^CFUN=0"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {    
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)
      {
        if((RxBuffer[0]=='O')&&(RxBuffer[1]=='K'))//OK
        { 
          return 0;
        }       
      }
      else if(flag==2)
        return KEYOP_RETURN; 
      
      else
        break;        
    }
    j++; 
  }while(j<=4);
  
  return 1;
  
}


//�����ٴζ���JM3G_UPDATE
/*---------------------------3Gģ�����---------------------------------------*/
//1��3Gģ���ϵ�
void poweron3G_module(void)
{  
  IWDG_ReloadCounter();
  close_gprs_power();
  delayms_break(500);
  open_gprs_power();
  TERMON_3G_0;
  SLEEP_3G_1;
  delayms_break(500);
  //���� 
  TERMON_3G_1;
  delayms_break(600);
  TERMON_3G_0;
  delayms_break(1000);

//  NET.poweron=WCDMAPWRON;
}
//0-���� ����-����
//1��3Gģ��MU509����+CME ERROR: Normal error
u8 MU509link_net(void)
{  
  u8 flag,times;
  u8 firsterror;
 if(InquireLink_G3())
//    if(1)  
  {
  

  //3Gģ���ϵ�
//  Read_IP();  
  poweron3G_module();
//  networkid=1;
  if(key_flag||(wake_flag == RFG24_wakeup))
    return KEYOP_RETURN;
  //��ȡIP��ַ������

  
  //AT����
  delayms_break(1000);  
  flag=ATE_G3(DOUBLEDISPALY3GON);//1

  if(flag==0)
  {
   ;
  }     
  else if(flag==KEYOP_RETURN)
    return KEYOP_RETURN;
  else
  {
    firsterror=ERROR3GSTART;
    return firsterror;
  } 
 delayms_break(1000);
  /*
 flag=ATI_G3();//2
  if(flag==0)
  {;
  }    
  else if(flag==KEYOP_RETURN)
    return KEYOP_RETURN;
  else
  {
    firsterror=ERROR3GSTART; 
    return firsterror;
  }
  
   delayms_break(1000);*/
  flag=CPIN_G3();//3
  if(flag==0)
  {
    ;
  }    
  else if(flag==KEYOP_RETURN)
    return KEYOP_RETURN;
  else
  {
    firsterror=ERROR3GSIM; 
    return ERROR3GSIM;
  }  
  delayms_break(1000);

  
  flag=CSQ_G3();//4
  if(flag==KEYOP_RETURN)
    return KEYOP_RETURN;
//  flag=SMS_READ();
//  if(flag==KEYOP_RETURN)
//    return KEYOP_RETURN;
  
//  if(key_flag||(wake_flag == RFG24_wakeup))
  //ѭ��
  times=0;
  while(key_flag==0)
  	{ 
	delayms_break(1000);
 	if(key_flag||(wake_flag == RFG24_wakeup))
   	 return KEYOP_RETURN;
    flag=CREG_G3(); //5
    if(flag==0)
      break;  
    else if(flag==KEYOP_RETURN)
      return KEYOP_RETURN;
    else
    {
      if(times>=5)
        return ERROR3GCREG;
      times++;
    }
  }
  delayms_break(1000);
  
 //
  /*   flag=CPIN_CPBS();//3
  if(flag==0)
  {
    ;
  }    
  else if(flag==KEYOP_RETURN)
    return KEYOP_RETURN;
  else
  {
    firsterror=ERROR3GSIM; 
    return ERROR3GSIM;
  }  
  
  delayms_break(1000);
  
  
  
      flag=CPIN_CPBW();//3
  if(flag==0)
  {
    ;
  }    
  else if(flag==KEYOP_RETURN)
    return KEYOP_RETURN;
  else
  {
    firsterror=ERROR3GSIM; 
    return ERROR3GSIM;
  }  
  delayms_break(1000);*/
  
  // 22-32 --Ok
  

  
  if (PhoneNo[0]==0x00)
  {
  
  
  flag=CPIN_CNUM();//3
  if(flag==0)
  {
    if((recv_3G[42]==0x4F) &&(recv_3G[43]==0x4B) )
    {

    for(int i = 0; i < 11; i++)
    {
      PhoneNo[i]=recv_3G[i+22];  
    }
    
    }
    else
    {
        PhoneNo[0]=0xF1;
      
    }
     
//      I2C_WriteS_24C(Phone_NO,PhoneNo,11);  
  }    
  else if(flag==KEYOP_RETURN)
    return KEYOP_RETURN;
  else
  {
    firsterror=ERROR3GSIM; 
    return ERROR3GSIM;
  }  
  delayms_break(1000);
  
  }
  
  //
  for(int k = 0; k < 6; k++)
	  {
	  flag=USERPASSWORD_G3(); //6
	  if(flag==0)
		break; 
	  else if(flag==KEYOP_RETURN)
		return KEYOP_RETURN;
	  else
		firsterror=ERROR3GPASSWORD;
	  }
  
 // for(int k = 0; k < 3; k++)
  {
      
    flag=TCPLink_G3(1);
  //  if(flag==0) break;
    
  }
  
  //flag=TCPLink_G3(1);  //7
  
  
      if(flag==0)
      {
         //networkOKflag=1;
         return 0;  
      }
     
  else if(flag==KEYOP_RETURN)
    return KEYOP_RETURN; 
  else
    return ERROR3GLINK;
  
   }
  else
  {
       return 0;  
  }
}

void Delay_ms(unsigned int i)
{
    unsigned int j,k;
	for (k=0;k<12;k++)
	{
	    for(;i>0;i--)
		{
	    	for(j=0;j<220;j++)
	    	{;}
		}
	}
}
//0-�յ� ����-δ�յ�
uchar AT_G31(void)    
{    
u32 operate_loop;


	CPU_TD_1;     //�ȴ򿪷���
	f_receiveOK=0; 
	delayms_break(100);
	send_string_ATCMD("AT");//����ATָ���
	operate_loop=300000;
	while(operate_loop--)
		{
		if(operate_loop<=1) 
			{
			CPU_TD_0;     //�رշ���
			return 2;
			} 
		//�����ӵȴ���ʱ��Ϊ����2��������    
		if(operate_loop==100000) //������,������
			{
			send_string_ATCMD("AT");
			} 
		if(f_receiveOK==1)                               
		  	{ 
			CPU_TD_0;     //�رշ���
			return 0;
			}
		}
    CPU_TD_0;     //�رշ���               
	return 2;
}
/********��ѯ��ǰʱ��************/
void IPINIT_G3(void)    
{    
	char j=0;
	u32 operate_loop;
	
	f_receiveOK=0;
	send_string_ATCMD("AT^IPINIT?");//����ATָ���
	operate_loop=10000000;
	while(operate_loop--)
		{
		if(operate_loop<=1) 
			{  
			j++;
			break;
			}   //�����ӵȴ���ʱ��Ϊ����2��������
		if(f_receiveOK==1)
			{    
			return;
			}
		}
		//}while(j<=4);
	//rtxd("#ERRO*");//���������Ѿ�������
	return;
}

//0-���� ����-�쳣 
unsigned char wake_3G(unsigned char line_number)
{
u8 flag;

	CPU_TD_1;
	SLEEP_3G_OFF;//����ģ��130108
	delayms_break(14000);
	CFUN_G3(CFUN3GON);
	if(f_receiveOK!=1)
		{
//		return 1;
		} 
	delayms_break(1000);
	//ECCLIST_G3();
	//LOCCHD_G3();
	IPINIT_G3();//��ѯ��ǰ�Ƿ��ʼ���Ѿ����
	if(f_receiveOK!=1)
		{
//		return 2;
		} 

	 for(int k = 0; k < 6; k++)
		 {
		 flag=USERPASSWORD_G3(); //6
		 if(flag==0)
		   break; 
		 else if(flag==KEYOP_RETURN)
		   return KEYOP_RETURN;
		 else
		   ;//firsterror=ERROR3GPASSWORD;
		 }
	// for(int k = 0; k < 3; k++)
	 {
		 
	   flag=TCPLink_G3(1);
	 //  if(flag==0) break;
	   
	 }
	 
	 //flag=TCPLink_G3(1);	//7
	 
	 
		 if(flag==0)
		 {
			//networkOKflag=1;
			return 0;  
		 }
		
	 else if(flag==KEYOP_RETURN)
	   return KEYOP_RETURN; 
	 else
	   return ERROR3GLINK;
}


//0-δ���� ����-����
unsigned char sleep_module(void)
{
u8 flag;

	//AT_IPCLOSE();  
	CPU_TD_1;	  //�رշ���
//	Delay_ms(100);
	delayms_break(10);
	CFUN_G3(CFUN3GOFF);
	CPU_TD_0;

	SLEEP_3G_ON;//��ģ��˯�ߵ�//����ģ��130108
	delayms_break(1000);
//	delayms_break();
	SLEEP_3G_OFF;//��ģ��˯�ߵ�//����ģ��130108
	delayms_break(500);
	SLEEP_3G_ON;//��ģ��˯�ߵ�//����ģ��130108
	delayms_break(10);
	//�򿪣��������ݣ��ӵ�û��SLEEP��û�нӵ���SLEEP��
	flag =AT_G31();
	return flag;
}





//while(1)
//  {
//    ATE_G3(DOUBLEDISPALY3GON);
//    delayms(1000);  
//    ATI_G3();
//    delayms(1000);
//    CPIN_G3();
//    delayms(1000);
//    
//    CSQ_G3();
//    delayms(1000);
//    while(1)
//    {
//      if(CREG_G3()==0)
//        break;
//    }
//    delayms(1000);
//    USERPASSWORD_G3();
//    delayms(1000); 
//    InquireLink_G3();
//    delayms(1000);
//    TCPLink_G3(1);
//    delayms(1000); 
//    InquireLink_G3();
//    delayms(1000);
//    DataSend_G3("huangfeng");
//    TCPCLOSE_G3(1);
//    delayms(1000); 
//    InquireLink_G3();
//    delayms(1000); 
//    TCPCLOSE_G3(1);
//    
//  }
//
//^IPSTATE: 1,0,2
//
//^IPSTATE: 7,0,2



////^SYSSTART
////
////^ECCLIST: "911","112"
////
////^ECCLIST: "911","112"
////
////^ECCLIST: "911","112"







//13561876078
