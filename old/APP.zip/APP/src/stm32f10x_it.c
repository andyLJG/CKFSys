/******************** (C) COPYRIGHT 2010 STMicroelectronics ********************
* File Name          : stm32f10x_it.c
* Author             : MCD Application Team
* Version            : V3.1.1
* Date               : 04/07/2010
* Description        : Main Interrupt Service Routines.
*                      This file provides template for all exceptions handler
*                      and peripherals interrupt service routine.
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_wwdg.h"
#include "LCD_12864.h"
#include "hal.h"
#include "KEY.h"
#include "main.h"
#include "St_credit.h"
#include "IapTest.h"
#include "Do_task.h"

extern u8  USART_RX_BUF[];         //���ջ���,���USART_REC_LEN���ֽ�.ĩ�ֽ�Ϊ���з� 
extern u16 USART_RX_STA;         		//����״̬���	
extern u16 USART_RX_CNT;	

extern unsigned char RxBuffer[];
extern u8 RxState;
extern u16 RxCounter;
extern u8 Rxdata;

extern u8 data_flag;
extern BitRateAdaptor UART1_Adaptor;
extern void RecfgBitRate(void);
/* Private variables ---------------------------------------------------------*/
extern  __IO uint16_t ADC1ConvertedValue;


u16 RX_data_len;
__IO uint16_t Index = 0;


/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/*******************************************************************************
* Function Name  : NMI_Handler
* Description    : This function handles NMI exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void NMI_Handler(void)
{
   while (1)
  	{
	   RxBuffer[0] = 2;
	   I2C_WriteS_24C(SYSNG_CODE,RxBuffer,1);  
	//������λһ��
	GenerateSystemReset();
	return;
    }
}

/*******************************************************************************
* Function Name  : HardFault_Handler
* Description    : This function handles Hard Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
    {
    
	RxBuffer[0] = 1;
	I2C_WriteS_24C(SYSNG_CODE,RxBuffer,1);	
	//������λһ��
	GenerateSystemReset();
	return;
    }
}

/*******************************************************************************
* Function Name  : MemManage_Handler
* Description    : This function handles Memory Manage exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
    {    
	  RxBuffer[0] = 3;
	  I2C_WriteS_24C(SYSNG_CODE,RxBuffer,1);  
	//������λһ��
	GenerateSystemReset();
	return;
    }
}

/*******************************************************************************
* Function Name  : BusFault_Handler
* Description    : This function handles Bus Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
    
	RxBuffer[0] = 4;
	I2C_WriteS_24C(SYSNG_CODE,RxBuffer,1);	
	//������λһ��
	GenerateSystemReset();
	return;
    }
}

/*******************************************************************************
* Function Name  : UsageFault_Handler
* Description    : This function handles Usage Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
    
	RxBuffer[0] = 5;
	I2C_WriteS_24C(SYSNG_CODE,RxBuffer,1);	
	//������λһ��
	GenerateSystemReset();
	return;
    }
}

/*******************************************************************************
* Function Name  : SVC_Handler
* Description    : This function handles SVCall exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SVC_Handler(void)
{
  while (1)
  {
    
	RxBuffer[0] = 6;
	I2C_WriteS_24C(SYSNG_CODE,RxBuffer,1);	
	//������λһ��
	GenerateSystemReset();
	return;
    }  
}

/*******************************************************************************
* Function Name  : DebugMon_Handler
* Description    : This function handles Debug Monitor exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void DebugMon_Handler(void)
{
  while (1)
  {
    
	RxBuffer[0] = 7;
	I2C_WriteS_24C(SYSNG_CODE,RxBuffer,1);	
	//������λһ��
	GenerateSystemReset();
	return;
    }  
}

/*******************************************************************************
* Function Name  : PendSV_Handler
* Description    : This function handles PendSVC exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void PendSV_Handler(void)
{
  while (1)
  {
    
	RxBuffer[0] = 8;
	I2C_WriteS_24C(SYSNG_CODE,RxBuffer,1);	
	//������λһ��
	GenerateSystemReset();
	return;
    }  
}

/*******************************************************************************
* Function Name  : SysTick_Handler
* Description    : This function handles SysTick Handler.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SysTick_Handler(void)
{
  while (1)
  {
    
	RxBuffer[0] = 10;
	I2C_WriteS_24C(SYSNG_CODE,RxBuffer,1);	
	//������λһ��
	GenerateSystemReset();
	return;
    }  
}
/**
  * @brief  This function handles WWDG interrupt request.
  * @param  None
  * @retval None
  */
void WWDG_IRQHandler(void)
{
  /* Update WWDG counter */
  WWDG_SetCounter(0x7F);
  /* Clear EWI flag */
  WWDG_ClearFlag();
}

/**
  * @brief  This function handles ADC1 and ADC2 global interrupts requests.
  * @param  None
  * @retval None
  */
void ADC1_2_IRQHandler(void)
{


}
//EXTI15_10_IRQHandler
/*

*/
void KeyScan_Pro(void)	
{
u16 key_num;

#ifdef JY_KEY
	  //delay(KEYTIMEOUT_1S/6000);
	  key_num=GPIO_ReadInputData(GPIOC);//PC 15 14 13 8 
	  key_num=key_num|0x1EFF;//PC 15 14 13 8 
	  switch(key_num)
			 {
			 case 0x7FFF: key_flagbk =1;break;
			 case 0xBFFF: key_flagbk =2;break;
			 case 0xDFFF: key_flagbk =3;break;
			 case 0xFEFF: key_flagbk =4;break;
//			 default: key_flagbk =0;break;
			 }	  
	  if(key_num)
	  	{
		 delay(KEYTIMEOUT_1S/6000);
		 key_num=GPIO_ReadInputData(GPIOC)|(~0xE100);//PC 15 14 13 8 
		 switch(key_num)
		 	{
		 	case 0x7FFF: key_flag =1;break;
			case 0xBFFF: key_flag =2;break;
			case 0xDFFF: key_flag =3;break;
			case 0xFEFF: key_flag =4;break;
			default: key_flag =0;break;
		 	}
	  	}
	  while(1)
	  	{
		key_num=GPIO_ReadInputData(GPIOC);//PC 15 14 13 8 
		key_num=key_num|0x1EFF;
		if(key_num)break;
	  	}
#else
//	  delay(KEYTIMEOUT_1S/6000);
	  key_num=GPIO_ReadInputData(GPIOC);//PC 15 14 13 8 
	  //key_num=GPIO_ReadInputData(GPIOC)|0x1EFF;//PC 15 14 13 8 
	  key_num=key_num&0xE100;//PC 15 14 13 8 
	  switch(key_num)
			 {
			 case 0x0100: key_flagbk =KEY_1;break;
			 case 0x2000: key_flagbk =KEY_2;break;
			 case 0x4000: key_flagbk =KEY_3;break;
			 case 0x8000: key_flagbk =KEY_4;break;
//			 default: key_flagbk =0;break;
			 }	  
	  if(key_num)
	  	{
		 delay(KEYTIMEOUT_1S/6000);
		//key_num=GPIO_ReadInputData(GPIOC)|(~0xE100);//PC 15 14 13 8 
		key_num=key_num&0xE100;//PC 15 14 13 8 
		switch(key_num)
		    {
		    case 0x0100: key_flag =KEY_1;break;
		    case 0x2000: key_flag =KEY_2;break;
		    case 0x4000: key_flag =KEY_3;break;
		    case 0x8000: key_flag =KEY_4;break;
		    default: key_flag =0;break;
		    }
	  	}
	  
	  while(1)
	  	{
		key_num=GPIO_ReadInputData(GPIOC);//PC 15 14 13 8 
		key_num=key_num&0xE100;//PC 15 14 13 8 
		if(!key_num)break;
	  	}
#endif
//	  if(key_flag)key_flagbk = key_flag;
	  return;
}


/*******************************************************************************
	* Function Name  : EXTI9_5_IRQHandler
	* Description	 : This function handles External lines 9 to 5 interrupt request.
	* Input 		 : None
	* Output		 : None
	* Return		 : None
*******************************************************************************/
void EXTI9_5_IRQHandler(void)
{
		NVIC_InitTypeDef NVIC_InitStructure;

		   NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
		   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
		   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
		   NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
		   NVIC_Init(&NVIC_InitStructure);
		   RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, DISABLE);
		   RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
           // Delay(50);
//		NVIC_InitTypeDef NVIC_InitStructure;
		if(EXTI_GetITStatus(EXTI_Line8) != RESET)
			{
			//Delay(300);
			//if(EXTI_GetITStatus(EXTI_Line8) != RESET)
			KeyScan_Pro();
//			key_flag = 1;
		    EXTI_ClearITPendingBit(EXTI_Line8);
		}                
                
		else if(EXTI_GetITStatus(EXTI_Line6) != RESET){
                    key_flag=5;
                    wake_flag=0;
	            EXTI_ClearITPendingBit(EXTI_Line6);
		}
		else if(EXTI_GetITStatus(EXTI_Line7) != RESET){
			if(TMP.BaseFlag==0)
				{
	            wake_flag =RFG24_wakeup;//Coin_wakeup;                    			
		    	EXTI_ClearITPendingBit(EXTI_Line7);
				UART4_IRQn_CTL(ON);
				}
		}	
		else if(EXTI_GetITStatus(EXTI_Line5) != RESET){
			
		    wake_flag = Wakeup_32S;
		    EXTI_ClearITPendingBit(EXTI_Line5);
		}
		else if(EXTI_GetITStatus(EXTI_Line9) != RESET){
                    voltage_flag=1;
		    EXTI_ClearITPendingBit(EXTI_Line9);
		}                

NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;//EXTI9_5_IRQn//;
NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;   
NVIC_Init(&NVIC_InitStructure);
RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE);
}


/*******************************************************************************
	* Function Name  : EXTI15_10_IRQHandler
	* Description	 : This function handles External lines 15 to 10 interrupt request.
	* Input 		 : None
	* Output		 : None
	* Return		 : None
*******************************************************************************/
void EXTI15_10_IRQHandler(void)
	{
	NVIC_InitTypeDef NVIC_InitStructure;
//	u8 key_num;
	
		//Delay(100);
		NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
		NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
		NVIC_Init(&NVIC_InitStructure);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, DISABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
		
		if(EXTI_GetITStatus(EXTI_Line12) != RESET)
			{
		    EXTI_ClearITPendingBit(EXTI_Line12);
			}
		
		else 
			{
			if(EXTI_GetITStatus(EXTI_Line13) != RESET)
				{
				 EXTI_ClearITPendingBit(EXTI_Line13);
				 }
			
		    else
				{
				if(EXTI_GetITStatus(EXTI_Line14) != RESET)
					{
					EXTI_ClearITPendingBit(EXTI_Line14);
					}
				else{
					if(EXTI_GetITStatus(EXTI_Line15) != RESET)
						{
						EXTI_ClearITPendingBit(EXTI_Line15);
						}
					}
				}
			KeyScan_Pro();
			}	  		
			
			EXTI_ClearITPendingBit(EXTI_Line5);
			EXTI_ClearITPendingBit(EXTI_Line6);
			EXTI_ClearITPendingBit(EXTI_Line7);
			NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;//EXTI9_5_IRQn//;
			NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
			NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
			NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;   
			NVIC_Init(&NVIC_InitStructure);
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE);
}


/**
  * @brief  This function handles USART1 global interrupt request.
  * @param  None
  * @retval None
  */
void USART1_IRQHandler(void)
{
  
  if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
  {
    unsigned char Rxdata;  	
    Rxdata = USART_ReceiveData(USART1); 
#ifdef MU509B

    //AT
	if((Rxdata=='A')&&(s_head_3G==0))
		{
		recv_3G[s_head_3G++] = Rxdata; 
		RxBuffer[RxCounter++] = Rxdata; 	
		}
	else if((recv_3G[0]=='A')&&s_head_3G>0)
		{  
		recv_3G[s_head_3G++] = Rxdata;
		RxBuffer[RxCounter++] = Rxdata; 	
		if((s_head_3G>2)&&(recv_3G[s_head_3G-2]=='O')&&(Rxdata=='K'))
			{
			OK_flag_3G=1;
			}
		else if((s_head_3G>3)&&(recv_3G[s_head_3G-3]=='a')&&(recv_3G[s_head_3G-2]=='d')&&(Rxdata=='y'))
			{
			OK_flag_3G=1;
			}
//		else if((recv_3G[s_head_3G-2]=='r')&&(recv_3G[s_head_3G-2]=='o')&&(Rxdata=='r'))
//			{
//			OK_flag_3G=2;
//			}
		else if((s_head_3G>3)&&(recv_3G[s_head_3G-3]=='y')&&(recv_3G[s_head_3G-2]=='e')&&(Rxdata=='t'))
			{
			OK_flag_3G=3;
			}
		
		}     
    //ip 
    else if((Rxdata=='^')&&(s_head_3G==0))
		{
		recv_3G[s_head_3G++] = Rxdata; 
		RxBuffer[RxCounter++] = Rxdata; 	
		}
	else if((Rxdata=='I')&&s_head_3G==1)
		{
		recv_3G[s_head_3G++] = Rxdata; 
		RxBuffer[RxCounter++] = Rxdata; 	
		} 
	else if((recv_3G[0]=='^')&&(s_head_3G>0)&&(recv_3G[1]=='I'))
     	{
		recv_3G[s_head_3G++] = Rxdata; 
		RxBuffer[RxCounter++] = Rxdata; 	
		if(Rxdata=='*')
			{
			OK_flag_3G=1;
			}   
		}
	
	//^SYSSTART
	else if((Rxdata=='S')&&(recv_3G[0]=='^')&&(s_head_3G>0))
		{
		recv_3G[s_head_3G++] = Rxdata; 
		RxBuffer[RxCounter++] = Rxdata; 	
		}
	else if((Rxdata=='Y')&&(recv_3G[0]=='^')&&(s_head_3G>0))
		{
	    if((recv_3G[0]=='^')&&(recv_3G[1]=='S'))
			{
			OK_flag_3G = 'S';
			}
		}
	//^STIN:
	else if((Rxdata=='T')&&(recv_3G[0]=='^')&&(s_head_3G>0))
		{
	    if((recv_3G[0]=='^')&&(recv_3G[1]=='S'))
			{
			OK_flag_3G = 'T';
			}
		}
	
	esflag_3G=1;   
	if(RxCounter>=1450)RxCounter=0;
	if(s_head_3G>=1450)s_head_3G=0;
#else	
    RxBuffer[RxCounter++] = Rxdata;     
	//delay(KEYTIMEOUT_1S*20);
    if(Rxdata == '#')
		{
        RxCounter = 1;
        RxBuffer[0] = '#';
		}
    if((Rxdata == '*')&&(RxBuffer[0] == '#'))
		{
        f_receiveOK=1;
        if((RxBuffer[1]=='L')&&(RxBuffer[3]=='k'))
			{
            f_connectOK=1;
			}
        if((RxBuffer[1]=='C')&&(RxBuffer[2]=='L'))
			{
            f_closeIP=1;
			}    
        else if((RxBuffer[1]=='l')&&(RxBuffer[3]=='r'))
			{
			//    f_connectOK=0;
			}  
		}
	if(RxCounter>=1450)RxCounter=0;
      //RxBuffer[300] = '*';
#endif

  }  
  
  else if (USART_GetFlagStatus(USART1, USART_FLAG_ORE) != RESET)
   {
   USART_ReceiveData(USART1);
   }  
  else if(USART_GetITStatus(USART1, USART_IT_TXE) != RESET)
   {   
    /* Write one byte to the transmit data register */
   //USART_SendData();
   ;;;;;;;;;;;;;;;;;;;;;;;;;
   }    
}


void USART3_IRQHandler(void)
{
  
  if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
  {
    unsigned char Rxdata;
    
    Rxdata = USART_ReceiveData(USART3); 
	RxBuffer[RxCounter++]=Rxdata;

	if(RxCounter==0x05)
		Rxdata = 0xFF;
	
	if(RxCounter>=1999)RxCounter=0;
   
  }
  else if (USART_GetFlagStatus(USART3, USART_FLAG_ORE) != RESET)
   {
   USART_ReceiveData(USART3);
   }  
  else if(USART_GetITStatus(USART3, USART_IT_TXE) != RESET)
   {   
    /* Write one byte to the transmit data register */
   //USART_SendData();
   ;;;;;;;;;;;;;;;;;;;;;;;;;
   }    
}

//�����������ж�  PDA�ر��ж�  andyluo  2015-04-20
/*
֡ͷ	���ݳ���	Ƶ�ʶ�	������	�豸��	����	���У���	֡β
2828CC	7-33	0-255	XX	XXXXXXXX	��Ч����	������+�豸��+��������
��ʼֵ��0xFF	CCCC
�̶�ֵ	��ͷβ�������ĳ���	ͨѶƥ��	���ܼ���	�豸��	�ؼ�����		�̶�ֵ
3	1	1	1	4	0-26	1	2		*/
void UART4_IRQHandler(void)
{
  
  if(USART_GetITStatus(UART4, USART_IT_RXNE) != RESET)
  	{
	unsigned char Rxdata;
	unsigned int Datalen;
    
    Rxdata = USART_ReceiveData(UART4); 
	
	CarBuffer[CarCounter++]=Rxdata;
	
	if((CarBuffer[0]!=0x28)||(CarCounter>550))
		{
		TMP.G24RECflag = OFF;   
		CarCounter = 0;
		}
	else if((CarCounter>2)&&(CarBuffer[2]!=0xCC))
		{
		TMP.G24RECflag = OFF;   
		CarCounter = 0;
		}
	else
		{
		//F0-F5-F6-F7
		if((CarBuffer[5]==0xF0)||(CarBuffer[5]==0xF5)||
		   (CarBuffer[5]==0xF6)||(CarBuffer[5]==0xF7))
			Datalen = CarBuffer[3]+CarBuffer[4]*256+6;
		else if((CarBuffer[5]==0xF1)||(CarBuffer[5]==0xF2)||
			   (CarBuffer[5]==0xF3)||(CarBuffer[5]==0xF4)||
			   (CarBuffer[5]==0xBD))
			Datalen = CarBuffer[3]+6;	
		if((CarCounter>5)&&
			(((CarBuffer[5]&0xf0)!=0xf0)&&(CarBuffer[5]!=0xBD)))
			{
			TMP.G24RECflag = OFF;	
			CarCounter = 0;
			}
		
		if((CarCounter>=Datalen)&&(CarCounter>5))
			{//�����ѽ������		
			TMP.COM4 = OFF;
			UART4_IRQn_CTL(OFF);		
			TMP.G24RECflag = ON;
			}
		}
  	}
  else if (USART_GetFlagStatus(UART4, USART_FLAG_ORE) != RESET)
  	{
	USART_ReceiveData(UART4);
	}  
  else if(USART_GetITStatus(UART4, USART_IT_TXE) != RESET)
  	{   
	/* Write one byte to the transmit data register */
	//USART_SendData();
	;;;;;;;;;;;;;;;;;;;;;;;;;
	}    
}

void UART5_IRQHandler(void)
{

    if(USART_GetITStatus(UART5, USART_IT_RXNE) != RESET)
    {
        unsigned char Rxdata;      
        Rxdata = USART_ReceiveData(UART5); 
        RxBuffer[RxCounter++] = Rxdata; 
               
        if(RxCounter > 3)
        {
            if(RxCounter == (RxBuffer[2] + 5) && (RxBuffer[RxCounter - 1] == 0x03)) 
            {
                    f_receiveOK = 1;                
            }
			
			if(RxCounter>=1999)RxCounter=0;
        }

    }     
	else if (USART_GetFlagStatus(UART5, USART_FLAG_ORE) != RESET)
	 {
	 USART_ReceiveData(UART5);
	 }	
	else if(USART_GetITStatus(UART5, USART_IT_TXE) != RESET)
	 {	 
	  /* Write one byte to the transmit data register */
	 //USART_SendData();
	 ;;;;;;;;;;;;;;;;;;;;;;;;;
	 }	  
}


void TIM1_UP_IRQHandler(void)
{
  
}
/**
  * @brief  This function handles TIM3 global interrupt request.
  * @param  None
  * @retval None
  */
void TIM1_CC_IRQHandler(void)
{ 

}

/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/*******************************************************************************
* Function Name  : PPP_IRQHandler
* Description    : This function handles PPP interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
/*void PPP_IRQHandler(void)
{
}*/

/******************* (C) COPYRIGHT 2010 STMicroelectronics *****END OF FILE****/



void DISABLE_EXTI15_10_IRQ()
{
      NVIC_InitTypeDef NVIC_InitStructure;
      NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
      NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
      NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
      NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
      NVIC_Init(&NVIC_InitStructure);
}

void DISABLE_EXTI9_5_IRQ()
{
      NVIC_InitTypeDef NVIC_InitStructure;
      NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
      NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
      NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
      NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
      NVIC_Init(&NVIC_InitStructure);
}

void OPEN_EXTI15_10_IRQ()
{
      NVIC_InitTypeDef NVIC_InitStructure;
      NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
      NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
      NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
      NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
      NVIC_Init(&NVIC_InitStructure);
	  key_flag = 0;
	  key_flagbk = 0;
}

void OPEN_EXTI9_5_IRQ()
{
//      NVIC_InitTypeDef NVIC_InitStructure;
//      NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
//      NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//      NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
//      NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//      NVIC_Init(&NVIC_InitStructure);
}

void OPEN_EXTI9_5_IRQNEW()
{
      NVIC_InitTypeDef NVIC_InitStructure;
      NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
      NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
      NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
      NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
      NVIC_Init(&NVIC_InitStructure);
}


