#ifndef __des_h__
#define __des_h__

extern union union1
{
    struct desstr
  {      
		unsigned char bufout[64];
		unsigned char kwork[56];
		unsigned char worka[48];
		unsigned char kn[48];
		unsigned char buffer[64];
		unsigned char key[64];
  }des_str;
}u_ram;



extern  unsigned char des(unsigned char *source,unsigned char * dest,unsigned char * inkey, unsigned char flg);
extern  unsigned  char specialdeschk(unsigned char *snr,unsigned char * in,unsigned char * out);

#endif