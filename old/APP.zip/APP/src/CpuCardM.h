#ifndef	_CpuCardM_H
#define	_CpuCardM_H
#include "stm32f10x.h"
#include "stdio.h"
#include "string.h"
#include "stm32f10x_conf.h"
#include "hal.h"
#include "MemoryAssign.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Key.h"
#include "Count.h"
//#include "Coin.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
//#include "Gprs_online.h"
#include "stm32f10x_pwr.h"
#include "stm32f10x_wwdg.h"
#include "main.h"
#include "rate.h"
//#include "loader.h"
#include "spi_flash.h"
#include "fsmc_sram.h"
#include "IC_demo.h"
#include "rate_JM.h"
#include "ir_comm.h"
#include "Record_Select.h"
#include "CarIMG.h"//2015-04-16 andyluo
#include "A_ListProgram.h"//2015-07-03 andyluo

#define YESZBTCARD   0
#define NOZBTCARD    1

#define CPUCARD_OUTTIME  265//8S-530(16S)
#define ICCARD_OUTTIME   KEYTIMEOUT_1S//8S-KEYTIMEOUT_1S * 2(16S)
/*���Ŷ���*/
//IC_RST-PF7
#define IC_RST_H             GPIO_SetBits(GPIOF, GPIO_Pin_9) //GPIO_WriteBit(GPIOF, GPIO_Pin_7, (BitAction)0x01) //GPIOF->BSRR = GPIO_Pin_7
#define IC_RST_L             GPIO_ResetBits(GPIOF, GPIO_Pin_9) //GPIO_WriteBit(GPIOF, GPIO_Pin_7, (BitAction)0x00)//GPIOF->BRR  = GPIO_Pin_7

#define IC_PGM_H               GPIO_SetBits(GPIOF, GPIO_Pin_8) //GPIO_WriteBit(GPIOF, GPIO_Pin_7, (BitAction)0x01) //GPIOF->BSRR = GPIO_Pin_7
#define IC_PGM_L              GPIO_ResetBits(GPIOF, GPIO_Pin_8)

//IC_DATA-PF10
//#define IC_DATA_H             GPIO_SetBits(GPIOF, GPIO_Pin_10)//GPIO_WriteBit(GPIOF, GPIO_Pin_10, (BitAction)0x01)//GPIOF->BSRR = GPIO_Pin_10
//#define IC_DATA_L             GPIO_ResetBits(GPIOF, GPIO_Pin_10)//GPIO_WriteBit(GPIOF, GPIO_Pin_10, (BitAction)0x00)//GPIOF->BRR  = GPIO_Pin_10
#define IC_DATA_read          GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_14)//GPIOF->IDR  & GPIO_Pin_10//
//IC_CLK-PF11
#define IC_CLK_H              GPIO_SetBits(GPIOD, GPIO_Pin_7)//GPIO_WriteBit(GPIOF, GPIO_Pin_11, (BitAction)0x01)//GPIOF->BSRR = GPIO_Pin_11
#define IC_CLK_L              GPIO_ResetBits(GPIOD, GPIO_Pin_7)//GPIO_WriteBit(GPIOF, GPIO_Pin_11, (BitAction)0x00)//GPIOF->BRR  = GPIO_Pin_11
//IC_SWITCH-PG15
#define IC_SWITCH_read        GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_6)//GPIOG->IDR  & GPIO_Pin_15    //������=1�޿�/=0�п�


/*contact��Դ���ƽ�PF6*/
#define Contact_Power_ON       GPIO_ResetBits(GPIOF, GPIO_Pin_10)
#define Contact_Power_OFF      GPIO_SetBits(GPIOF, GPIO_Pin_10)

#define IC_ECLK_H              GPIO_SetBits(GPIOB, GPIO_Pin_9)
#define IC_ECLK_L              GPIO_ResetBits(GPIOB, GPIO_Pin_9)


//�ܲ�ͨ����Ϣ����
typedef struct 
{
  
  unsigned char init_flag;                  //��ʼ����־
  unsigned char cardNO[4];	           //����
  unsigned char head[4];	           //��ͷ  
  unsigned char money[4];	           //�����Ǯ 
  
}TACTCDInfor;
//��һ�β忨��Ϣ����
typedef struct 
{
  unsigned char type;		                   //������ 
  unsigned char space;		                   //������
  unsigned char cardNO[4];	                   //����  
  unsigned char money[4];	                   //�����Ǯ
  unsigned char time_BCD[5];		           //�忨ʱ��
}FirstCardInfor;

extern FirstCardInfor FCardInfor; //��һ�ο�����Ϣ


u8 koufei(void);

extern TACTCDInfor  TCardInfor;

extern void init_contactcard(void);
extern void CCard_GPIOConfig(void);
extern void test_contactcard(void);
extern u8 ICCard_Pay(u8 space,u8 IQFlag);
void read_card_test(u8  carddatatest[13] );

#endif

