

//******IIC********
sbit     SDA=P2^3;
sbit     SCL=P2^2;
//****************
sbit     P12=P1^2;
sbit     P13=P1^3;
sbit     P14=P1^4;

sbit     P11=P1^1;
sbit     P15=P1^5;
sbit     P16=P1^6;
sbit     P17=P1^7;

sbit     P26=P2^6;
sbit     P27=P2^7;

sbit     P30=P3^0;
sbit     P31=P3^1; 
//*******LCD**********
#define LCDBus         P0
sbit	LCD_CS1        = P3^5;
sbit	LCD_RES        = P3^4;
sbit	LCD_RS         = P2^5;
sbit    LCD_WR         = P1^3;
sbit    LCD_RD         = P1^0;
sbit    LCD_light      = P2^4;
//*********************
/**************���̽ӿ�*******************/
sbit P00  = P0^0;
sbit P01  = P0^1;
sbit P02  = P0^2;
sbit P03  = P0^3;
sbit P04  = P0^4;  
sbit P05  = P0^5;  

sbit P20  = P2^0;
sbit P21  = P2^1;
sbit P22  = P2^2;
sbit P23  = P2^3; 

sbit P34  = P3^4;
sbit P36  = P3^6; 
sbit P33  = P3^3; 
//*****************************************
#define  keyset    0x08
#define  close     0x0f

#define  SPACE_4TH    	 		4
#define  SPACE_2ND     	 	2
#define  SPACE_1ST     		1

#define  Com_port_testing     1
#define  Com_port_real    	 0
#define  Ishide         		 1
#define  Isnohide     			 0
#define  changeon     			 1
#define  changeoff     		 0
#define  ONLINE_TIME     		 120//29//15//



#define  KEY_1ST      			0x10//0x20//
#define  KEY_2ND     			0x20//0x40//
#define  KEY_3RD     			0x30//0x0f//
#define  KEY_4TH   			0x40//0x0f//

#define ParkingCard_OPEN       0
#define ParkingCard_CLOSE      1

#define  SG4    	 			4
#define  SG3    	 			3
#define  SG2    	 			2
#define  SG1    	 			1
#define  SG0    	 			0

#define  Software_sever		0
#define  DPS_sever    	 		1

#define  ON						1
#define  OFF    	 			0

#define  Opendisp				1
#define  Closedisp	 			0



#define  OWN_test		//1  �Բ�
//#define  CMY_test		//1  ���Բ�����
//#define  USER_test		//1  �û�����
//#define  USER_use		//1  �û�ʵ��ʹ��
#define SPACE_RE     		SPACE_4TH
//#define SPACE_RE     		SPACE_2ND

#ifdef OWN_test
#define Testdisp			Opendisp
#define Com_port   		Com_port_testing
#define Key_reset   		ON
#endif

#ifdef CMY_test
#define Testdisp			Opendisp
#define Com_port   		Com_port_real
#define Key_reset   		ON
#endif

#ifdef USER_test
#define Testdisp			Closedisp
#define Com_port   		Com_port_real
#define Key_reset   		ON
#endif

#ifdef USER_use
#define Testdisp			Closedisp
#define Com_port   		Com_port_real
#define Key_reset   		OFF
#endif



/*
3Gģ�黽��(*wake#)>>>>>>>>>>>>>>>��������
3Gģ��˯��(sleep)>>>>>>>>>>>>>>>3Gģ�����-----�ӻ�MCU˯��
�ӻ�MCU����>>>>>>>>>>>>���ùܣ��жϿ���
�ӻ�MCU˯��(*mcusleep#)>>>>>>>>>>>>��������
͸����(*entrans#)>>>>>>>>>>>>>>>>>>>��������
͸����(*disentrans#)>>>>>>>>>>>>>>>>>>>��������

ע�⣺
	1���л�IP��ʱ���ȷ�IP Ȼ����
	2����������ʱ���Ȼ����ٷ�����
*/

#define		Wakeup__3G_CDMA				uart_send_som("*wake#");delay(45000)			//3Gģ�黽��
#define		Entrans__3G_CDMA				uart_send_som("*entrans#");delay(45000)		//3G͸����
#define		Disentrans__3G_CDMA			uart_send_som("*disentrans#");delay(45000)	//3G͸����
#define		Sleep__3G_MCU			   		;//uart_send_som("*mcusleep#");delay(45000)		//�ӻ�MCU˯��
#define		Sleep__3G_CDMA		   		uart_send_som("*sleep#");delay(45000)		//�ӻ�MCU˯��

#define		Sleep__3GandMCU_PD	   		uart_send_som("*mcusleep#");delay(15000)		//�ӻ�MCU˯��




//*****************************************
extern unsigned char bdata bdu22;
//----------------------------------------
#define flag      		0X7FF0          //�����ʼ����־��//16
#define rate1     		0X7FE0          //�洢����        //16 ,16+16=32
#define rate     		0X7FD0          //�洢����        //16
#define ip        		0x7fc0          //�洢IP          //16
#define APN       		0x7fa0          //�洢�ֵ��ź�����//1+1+30
#define daytm    		0x7f9c          //          //4
#define daytn     		0x7f98
//#define dayxm     0x7f94
//#define dayxn      0x7f90
#define daycm     		0x7f8c
#define daycn     		0x7f88
#define daymm     		0x7f84
#define daymn     		0x7f80

#define totaltm     	0x7f7c          
#define totaltn     	0x7f78
#define totalcm     	0x7f74
#define totalcn     	0x7f70
//#define saveaddr    	0x7f6c//0x7f5d           
//#define downaddr    	0x7f68//0x7f5a
#define totalmm     	0x7f64
#define totalmn     	0x7f60

#define totalkm     	0x7f5d//0x7f6c
#define totalkn     	0x7f5a//0x7f68
#define clr4kfaddr  	0x7f57             
#define clr4keaddr  	0x7f54 

#define c20         	0x7f52
#define c10         	0x7f50
#define c05         	0x7f4e
#define c02         	0x7f4c
#define c01         	0x7f4a //0x7f60    
 
//#define gprsfaddr   		0x7f48  
//#define gprssaddr   	0x7f46    
//#define gprsnum     	0x7f44
#define tickno      	0x7f43     
#define machineno   	0x7f40
 
#define rtime       	0x7f38
#define ltime       	0x7f30
#define rrtime       	0x7f28
#define lltime       	0x7f20
#define NPN        		0x7f00

//����
#define fee_rate4       		0x7ef0
#define fee_rate3        		0x7ee0
#define fee_rate2        		0x7ed0
#define fee_rate1        		0x7ec0

#define takemoney_time  		0x7ebf
#define  coinsum_now     		0x7ebd
#define  coinsum_setting  	0x7ebb

#define saveaddr   			0x7eb8           
#define downaddr   			0x7eb4
#define gprsfaddr   			0x7eb0  
#define gprssaddr   			0x7eac    
#define gprsnum     			0x7ea8


#define Lpark 					0x7df0
#define LLpark 				0x7de0
#define Rpark      				0x7dd0
#define RRpark 				0x7dc0
#define LLpark1				0x7db0
#define Rpark1 				0x7da0
#define RRpark1 				0x7d90
#define Lpark1 				0x7d80
#define gprsover   			0x7d00 


//#define AcceptAlready 0x7db0
//#define PayOk       0x7db1
//#define TotalLength 0x7db2
//#define clr4kfaddr1 0x7db3
//#define time        0x7db6
//#define chewei      0x7dbB
//#define kahao       0x7dbC   

//---------------------------------------
extern bit  zimo,doint,LV_NS,CIONFULL,day_flag,time_OK,GPRS_LINKing,CLOSE_GPRS,SCR_CK,QL_CK;
extern bit  gprs_user,gprs_busy,f_InitialTime,DPSIP,all_dawnload,addtime;
extern unsigned int idata LimitTime,LimitMoney,LimitMoney_CARD,BaseFee,LeftTime;
//unsigned char loop1,loop2;

extern unsigned char  chewei,jishu,D_PayOk,chewei5,SG_CSQ,BaseTime,FEE_SAT,FEE_END;
extern unsigned char idata time[6],time1[6];//,time2[6];
extern bit LowVoltage_Test();

extern void fault_record(unsigned char FAULT_TYPE);
extern void Set_shoufei();		
void takemny_record(unsigned char * card_no);
void KEY_Program();
void TakeMoney_PRO();
bit Choose_time(unsigned char space,unsigned int *Use_mny_time);
