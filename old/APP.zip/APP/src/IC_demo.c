#include <stdio.h>

#include "IC_demo.h"
#include "Smart_card.h"
#include "Do_Task.h"
#include "Gprs_online.h"
#include "lcd_12864.h"
#include "CpuCardM.h"

//#define DD_DEBUG    //�������Ļ����Ϳ��ٿ���



extern uchar HZ[];  
extern void PWR_EnterSLEEPMode(u32 SysCtrl_Set, u8 PWR_SLEEPEntry);
extern void GPIO_Configuration(void);

void sleepLcd1(void);

ErrorStatus HSEStartUpStatus;

//һ��·�Σ�56 02 21 08 32 28 02 02 20 00 05 04 06 99 12 03 00000305070B0F0600
//����·�Σ�56 02 21 08 32 28 02 02 20 00 05 04 06 99 12 03 0000020305070B0400
//����·�Σ�56 02 21 08 32 28 02 02 20 00 05 04 06 99 12 03 000002020305070200
//��ʼ�����ʲ��� 2015-11-27
void SYSFEE_TESTING(u8 feemode)
{
u8 feetype,i,BCC=0x00;

	feetype = feemode;
	
	if(feetype== 0)//����ģʽ	
		{
		u8 block2_bufferR[32]={0x56,0x02,0x21,0x08,0x32,0x28,0x02,0x02,
							  0x20,0x00,0x05,0x04,0x06,0x99,0x12,0x03};		
		I2C_ReadS_24C(B_startTime_unit_of_hour,block2_bufferR,26);
		I2C_ReadS_24C(back_argument_of_charge,block2_bufferR,26);
		}
	else if(feetype== 1)//����һ��·��
		{
		u8 block2_buffer[32]={0x56,0x02,0x21,0x08,0x32,0x28,0x02,0x02,
							  0x20,0x00,0x05,0x04,0x06,0x99,0x12,0x03};		
		u8 block1_buffer[16]={0x00,0x00,0x03,0x05,0x07,0x0B,0x0F,0x06,0x00};
		for(i=0;i<16;i++)
		  {
		  //block2_buffer[i] = block2_buffer[i + 1];
		  BCC = BCC ^ block2_buffer[i];
		  }
		for(;i<25;i++)
		  {
		  block2_buffer[i] = block1_buffer[i-16];
		  BCC = BCC ^ block2_buffer[i];
		  }
		block2_buffer[25] = BCC;		
		I2C_WriteS_24C(B_startTime_unit_of_hour,block2_buffer,26);
		I2C_WriteS_24C(back_argument_of_charge,block2_buffer,26);
		I2C_WriteS_24C(SYS_NETFEE,block2_buffer,26);
		memset(block2_buffer,0,3);
		I2C_WriteS_24C(SYS_NETFEE+32,block2_buffer,3);
		}
	else if(feetype== 2)//�������·��
		{
#ifdef WZ_MBSYSTEM
//		���ݣ���8��-0�� 2Ԫ/��Сʱ ���4Сʱ��
//		56020008322802042000040406991203 00000305070B0F0600
		u8 block2_buffer2nd[32]={0x56,0x02,0x00,0x08,0x32,0x28,0x02,0x04,
							  0x20,0x00,0x04,0x04,0x06,0x99,0x12,0x03};		
		u8 block1_buffer2nd[16]={0x00,0x00,0x02,0x03,0x05,0x07,0x0B,0x04,0x00};
#elif defined IN_MBSYSTEM
//		ӡ�᣺��8��15��-20��30�ֵ�һСʱRp 3000��֮��ÿСʱRp 1000���24Сʱ��
//		56022008322801062000240206991203 30150305070B0F0600 ���ʶ��ʱX10
		u8 block2_buffer2nd[32]={0x56,0x02,0x20,0x08,0x32,0x28,0x01,0x06,
							  0x20,0x00,0x24,0x02,0x06,0x99,0x12,0x03}; 	
		u8 block1_buffer2nd[16]={0x00,0x00,0x02,0x03,0x05,0x07,0x0B,0x04,0x00};
#else
	u8 block2_buffer2nd[32]={0x56,0x02,0x21,0x08,0x32,0x28,0x02,0x02,
						  0x20,0x00,0x05,0x04,0x06,0x99,0x12,0x03}; 	
	u8 block1_buffer2nd[16]={0x00,0x00,0x02,0x03,0x05,0x07,0x0B,0x04,0x00};
#endif


		for(i=0;i<16;i++)
		  {
		  //block2_buffer[i] = block2_buffer[i + 1];
		  BCC = BCC ^ block2_buffer2nd[i];
		  }
		for(;i<25;i++)
		  {
		  block2_buffer2nd[i] = block1_buffer2nd[i-16];
		  BCC = BCC ^ block2_buffer2nd[i];
		  }
		block2_buffer2nd[25] = BCC;		
		I2C_WriteS_24C(B_startTime_unit_of_hour,block2_buffer2nd,26);
		I2C_WriteS_24C(back_argument_of_charge,block2_buffer2nd,26);
		I2C_WriteS_24C(SYS_NETFEE,block2_buffer2nd,26);
		memset(block2_buffer2nd,0,3);
		I2C_WriteS_24C(SYS_NETFEE+32,block2_buffer2nd,3);
		}
	else if(feetype== 3)//��������·��
		{
		u8 block2_buffer3rd[32]={0x56,0x02,0x21,0x08,0x32,0x28,0x02,0x02,
							  0x20,0x00,0x05,0x04,0x06,0x99,0x12,0x03};		
		u8 block1_buffer3rd[16]={0x00,0x00,0x02,0x02,0x03,0x05,0x07,0x02,0x00};
		for(i=0;i<16;i++)
		  {
		  //block2_buffer[i] = block2_buffer[i + 1];
		  BCC = BCC ^ block2_buffer3rd[i];
		  }
		for(;i<25;i++)
		  {
		  block2_buffer3rd[i] = block1_buffer3rd[i-16];
		  BCC = BCC ^ block2_buffer3rd[i];
		  }
		block2_buffer3rd[25] = BCC;		
		I2C_WriteS_24C(B_startTime_unit_of_hour,block2_buffer3rd,26);
		I2C_WriteS_24C(back_argument_of_charge,block2_buffer3rd,26);	
		I2C_WriteS_24C(SYS_NETFEE,block2_buffer3rd,26);
		memset(block2_buffer3rd,0,3);
		I2C_WriteS_24C(SYS_NETFEE+32,block2_buffer3rd,3);
		}
	else if(feetype== 4)//���Է���
		{
		u8 block2_buffer3rd[32]={0x56,0x02,0x21,0x08,0x0A,0x28,0x01,0x01,
							  0x20,0x00,0x05,0x02,0x06,0x99,0x12,0x03};		
		u8 block1_buffer3rd[16]={0x00,0x00,0x02,0x02,0x03,0x05,0x07,0x02,0x00};
		for(i=0;i<16;i++)
		  {
		  //block2_buffer[i] = block2_buffer[i + 1];
		  BCC = BCC ^ block2_buffer3rd[i];
		  }
		for(;i<25;i++)
		  {
		  block2_buffer3rd[i] = block1_buffer3rd[i-16];
		  BCC = BCC ^ block2_buffer3rd[i];
		  }
		block2_buffer3rd[25] = BCC;		
		I2C_WriteS_24C(B_startTime_unit_of_hour,block2_buffer3rd,26);
		I2C_WriteS_24C(back_argument_of_charge,block2_buffer3rd,26);	
		I2C_WriteS_24C(SYS_NETFEE,block2_buffer3rd,26);
		memset(block2_buffer3rd,0,3);
		I2C_WriteS_24C(SYS_NETFEE+32,block2_buffer3rd,3);
		}
}

//����ԭʼ��¼ 2015-10-09
void test_record_flashandFM256(void)
{
u32 opdata,opadd,orgadd,fsadd,listnumadd,listnum,ChipUniqueID[3];
u16 bagsum,i,k,num,bagbl,STM32_FLASH_SIZE_LEN;
u8 buf[32],listbuf[513];
	

	ChipUniqueID[0] = *(__IO u32 *)(0X1FFFF7F0); // ���ֽ�
	ChipUniqueID[1] = *(__IO u32 *)(0X1FFFF7EC); //
	ChipUniqueID[2] = *(__IO u32 *)(0X1FFFF7E8); // ���ֽ�
	STM32_FLASH_SIZE_LEN= *(u16*)(0x1FFFF7E0);	  //���������Ĵ���	


	u32 oldvalue;	
	oldvalue=EXTI->IMR; //����ԭֵ	
	EXTI->IMR=0;	
#ifndef  TESTEXTI
	TMP.EXTIvalue = oldvalue;
#endif
	UART_DAEL_CODE(OFF);

	SPI_FLASH_Init();
	
	buf[0] = 0x5A;
	buf[1] = 0x00;

	fsadd = hcl(buf,2);
	bagsum = 10;
	
	for(k=0;k<bagsum;k++)
		{		
		for(i=0;i<16;i++)
			{
			opdata=32*i;
			I2C_ReadS_24C(fsadd+opdata+k*512,listbuf+opdata,32);				   
			}
		}
	buf[0] = 0x0D;
	buf[1] = 0x00;
	buf[2] = 0x00;
	fsadd = hcl(buf,3);
	bagsum = 10;
	for(i=0;i<bagsum;i++)
		{
		opdata = 512;			
		opadd = i*512+fsadd;
		SPI_FLASH_BufferRead(listbuf,opadd,opdata);		
		}		

	EXTI->IMR=oldvalue; //��ԭ
	UART_DAEL_CODE(ON);
}



void update_IAP_program(void)
{
		DISABLE_EXTI15_10_IRQ();	  
		DISABLE_EXTI9_5_IRQ();	
		lcd_clear();
		print_XYstr_16_16(1,1,"Updating...");
		IAP_UpData(0xA1);					 
//			IAP_UpData(2);	//�ϵ�����			 
		OPEN_EXTI9_5_IRQ(); 																		 
		OPEN_EXTI15_10_IRQ(); 

}
void Read_EXTIV(void)
{	
u32 EXTIvalue;

	EXTIvalue = EXTI->IMR; //����ԭֵ;
  
	TMP.EXTIvalue = EXTIvalue;
}

void test_flash11(void)
{
	u8 buf1_0[4],nbuf10[4],nbuf30[4];
	  u8 buf1_1[4]; 
	  buf1_0[0]=0xD1;
	  buf1_0[1]=0xD2;
	  buf1_0[2]=0xD3;
	  buf1_0[3]=0xD4;
			
	  SPI_FLASH_Init(); 
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x300000,4);
	  
	  SPI_FLASH_BufferRead(buf1_1,0x100000,4);
	  SPI_FLASH_SectorErase(0x100000);
	   SPI_FLASH_BufferRead(buf1_1,0x100000,4); 
	  SPI_FLASH_BufferWrite(buf1_0, 0x100000, 4);	
	  SPI_FLASH_BufferRead(buf1_1,0x100000,4);
	  
	   buf1_0[0]=0xD5;
	  buf1_0[1]=0xD6;
	  buf1_0[2]=0xD7;
	  buf1_0[3]=0xD8;
	  
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x300000,4);
	  
	  SPI_FLASH_BufferRead(buf1_1,0x300000,4);
	  SPI_FLASH_SectorErase(0x300000);
	  
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x300000,4);
	  
		SPI_FLASH_BufferRead(buf1_1,0x100000,4);
	  SPI_FLASH_BufferRead(buf1_1,0x300000,4);	  
	  SPI_FLASH_BufferWrite(buf1_0, 0x300000, 4);	
	  
	  SPI_FLASH_BufferRead(buf1_1,0x300000,4);	
		SPI_FLASH_BufferRead(buf1_1,0x100000,4);  
	  SPI_FLASH_BufferRead(buf1_1,0x200000,4);
	  
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x300000,4);
          SPI_FLASH_BufferRead(nbuf30,0x300000,4);
	  
}


void test_flash(void)
{
	u8 buf1_0[4],nbuf10[4],nbuf30[4];
	  u8 buf1_1[4]; 
	  buf1_0[0]=0xD1;
	  buf1_0[1]=0xD2;
	  buf1_0[2]=0xD3;
	  buf1_0[3]=0xD4;
			
	  SPI_FLASH_Init(); 
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x700000,4);
	  
	  SPI_FLASH_BufferRead(buf1_1,0x100000,4);
	  SPI_FLASH_SectorErase(0x100000);
	   SPI_FLASH_BufferRead(buf1_1,0x100000,4); 
	  SPI_FLASH_BufferWrite(buf1_0, 0x100000, 4);	
	  SPI_FLASH_BufferRead(buf1_1,0x100000,4);
	  
	   buf1_0[0]=0xD5;
	  buf1_0[1]=0xD6;
	  buf1_0[2]=0xD7;
	  buf1_0[3]=0xD8;
	  
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x700000,4);
	  
	  SPI_FLASH_BufferRead(buf1_1,0x700000,4);
	  SPI_FLASH_SectorErase(0x700000);
	  
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x700000,4);
	  
		SPI_FLASH_BufferRead(buf1_1,0x100000,4);
	  SPI_FLASH_BufferRead(buf1_1,0x700000,4);	  
	  SPI_FLASH_BufferWrite(buf1_0, 0x700000, 4);	
	  
	  SPI_FLASH_BufferRead(buf1_1,0x700000,4);	
		SPI_FLASH_BufferRead(buf1_1,0x100000,4);  
	  SPI_FLASH_BufferRead(buf1_1,0x700000,4);
	  
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x700000,4);
          SPI_FLASH_BufferRead(nbuf30,0x700000,4);
	  
}

void NETSET_INI(u8 mode)
{
//	ÿСʱʵʱ���ͼ�¼			99 04 06 10 02 28 04 04 04 24
//	ʵʱ����ʵʱ���ͼ�¼		99 04 06 10 A2 28 04 04 04 24
//	ÿ2Сʱʵʱ���ͼ�¼ 		99 04 06 20 02 28 04 04 04 24
//	ÿ2Сʱ�����Ų�ַ��ͼ�¼	99 04 06 23 02 28 04 04 04 24
//99 04 06 10 02 28 04 04 04 24 //ÿСʱʵʱ���ͼ�¼
u8 buffer[16];

	buffer[0] = 0x99;
	buffer[1] = 0x04;
	buffer[2] = 0x06;
	buffer[3] = 0x10;
	buffer[4] = 0x05;
	buffer[5] = 0x28;
	buffer[6] = 0x04;
	buffer[7] = 0x04;
	buffer[8] = 0x04;
	buffer[9] = 0x24;
	switch(mode)
		{
		case 0:
			I2C_ReadS_24C(LISTNET_ADD,buffer,16);//0-��־99 1- 2- 3-���ͼ��Ƶ�� 4- 5-Υ��ʱ��
			break;
		case 1:
			buffer[3] = 0x10;
			buffer[4] = 0x02;
			I2C_WriteS_24C(LISTNET_ADD,buffer,16);//0-��־99 1- 2- 3-���ͼ��Ƶ�� 4- 5-Υ��ʱ��
			break;
		case 2:
			buffer[3] = 0x10;
			buffer[4] = 0xA2;
			I2C_WriteS_24C(LISTNET_ADD,buffer,16);//0-��־99 1- 2- 3-���ͼ��Ƶ�� 4- 5-Υ��ʱ��
			break;
		case 3:
			buffer[3] = 0x20;
			buffer[4] = 0x02;
			I2C_WriteS_24C(LISTNET_ADD,buffer,16);//0-��־99 1- 2- 3-���ͼ��Ƶ�� 4- 5-Υ��ʱ��
			break;
		case 4:
			buffer[3] = 0x23;
			buffer[4] = 0x02;
			I2C_WriteS_24C(LISTNET_ADD,buffer,16);//0-��־99 1- 2- 3-���ͼ��Ƶ�� 4- 5-Υ��ʱ��
			break;
		}
	return;
}
void INI_SYSFROM(void)
{
u32 Addr;
u16 i;
u8 flag_buffer[32],buffer[128],BCC;

		///////////////��ʾ ϵͳ��ʼ�� /////////////////////////////
		display_sysytem_init(); 	
		
		buffer[4]= 0x15;	//��			  
		buffer[3]= 0x08;	//��			  
		buffer[2]= 0x08;	//��			  
		buffer[1]= 0x08;	//ʱ			  
		buffer[0]= 0x08;	//��							  
		buffer[5]= mathweek(buffer[4],buffer[3],buffer[2]); 				  
		set_current_time(buffer); 			  
		
		/////////////////�ص�///////////////
		LED1_OFF;
		LED2_OFF;
		LED3_OFF;
		LED4_OFF;
		////////////////////////////////////	   
		INI_SYSLIST();//��ʼ��b1-b8�����洢�� 2015-07-27
		INI_SYSCARIMG();//����ͳ�ʼ��������������� 2015-04-16
		////////////////�������λ״̬��Ϣ//////////////////////
		buffer[0] = 1;
		I2C_WriteS_24C(SYS_RTC,buffer,1);//ʱ��ʵʱ���¿���
		I2C_WriteS_24C(SYS_LOCKCPC,buffer,1);//ʱ��ʵʱ���¿���
		for(i=0;i<16;i++)
		  buffer[i] = 0x00;
		I2C_WriteS_24C(SYS_SN,buffer,4);//��ˮ������
		I2C_WriteS_24C(car1_used_reference_info,buffer,16);//��λ��Ϣ
		I2C_WriteS_24C(car2_used_reference_info,buffer,16);
		I2C_WriteS_24C(car3_used_reference_info,buffer,16);
		I2C_WriteS_24C(car4_used_reference_info,buffer,16);
		
		I2C_WriteS_24C(car1_no_S_flag,buffer,4);
		I2C_WriteS_24C(car2_no_S_flag,buffer,4);
		I2C_WriteS_24C(car3_no_S_flag,buffer,4);
		I2C_WriteS_24C(car4_no_S_flag,buffer,4);
		
		I2C_WriteS_24C(car1_smartCard_momenry,buffer,4); //��λ���
		I2C_WriteS_24C(car2_smartCard_momenry,buffer,4);
		I2C_WriteS_24C(car3_smartCard_momenry,buffer,4);
		I2C_WriteS_24C(car4_smartCard_momenry,buffer,4);
		////////////////////////////////////////////////////////	  
		
		///////////////// FLASH���� ��ʼ����������ַ������/////////////////////////////
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count,buffer,4); //��ʼ��ַ

		I2C_WriteS_24C(SYS_SN,buffer,4);//���˼�¼��ˮ��
		I2C_WriteS_24C(SYS_FEESN,buffer,2);//������ˮ��
		I2C_WriteS_24C(SYS_WARSN,buffer,2);//������ˮ��
		
		buffer[0] = 0x00;
		buffer[1] = 0x0C;
		buffer[2] = 0x35;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count + 4,buffer,4); //������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count + 8,buffer,4); //����������
		///////////////////////////��ʼ�� EEPROM��ַ/////////////////////////////////// ���û��ʹ��
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(EEPROM_last_time_down_addr,buffer,2); //EEPROM �ϴ����ص�ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(addr_of_current_in_EEPROM,buffer,2); //EEPROM ��¼�洢��ǰ��ַ
		/////////////////////////////////FLASH ��ʼ�� ///////////////////////////////// ���ûʹ��
		buffer[0] = 0x00;
		I2C_WriteS_24C(full_of_FLASH_flag,buffer,1); //FLASH ������־
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		I2C_WriteS_24C(clear_4K_of_FLASH_addr,buffer,3); //FLASH 4K������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(FLASH_last_time_down_addr,buffer,3); //FLASH ��¼�ϴ����ص�ַ
		buffer[2] = 0x00;
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		I2C_WriteS_24C(addr_of_current_in_FLASH,buffer,3); //FLASH ��¼�洢��ǰ��ַ 	  

		buffer[0] = 0x12;
		buffer[1] = 0x34;
#if ZJ_MB_SYS
		buffer[2] = 0x00;
#else
		buffer[2] = 0x56;
#endif
		buffer[3] = 0x78;	
		I2C_PageWrite_24C(mibiao_number,buffer,4);//��ʼ������ţ�2015-05-04
		///////////////////////////////������//////////////////////////////////////////
		//55002109643202033000240204991200
		SYSFEE_TESTING(2);//Ĭ�϶���·�� 2015-11-27
		
		//////////////////////////////�ݴ泵λ����/////////////////////////////////////
//		buffer[0] = 0x00;
//		buffer[1] = 0x00;
//		buffer[2] = 0x00;
//		buffer[3] = 0x00;
//		I2C_WriteS_24C(car1_number_temporal,buffer,4);//�ݴ�1�ų�λ���� д������ʱ
//		I2C_WriteS_24C(car2_number_temporal,buffer,4);
//		I2C_WriteS_24C(car3_number_temporal,buffer,4);
//		I2C_WriteS_24C(car4_number_temporal,buffer,4);
		
		///////////////////////��������ļ�¼����///////////////////////////////////////
		buffer[0] = 0x17;
		buffer[1] = 0xE0;
		I2C_WriteS_24C(Con_Fm_Record_112_Start_Addr,buffer,2);//��ʼ��ַ  112
		I2C_WriteS_24C(Con_Fm_Record_112_Cursor,buffer,2);//���¼��ַ�α�
		I2C_WriteS_24C(Con_Fm_Record_112_UDCSR,buffer,2);//GPRS ���ؼ�¼��ַ�α�
		I2C_WriteS_24C(Con_Fm_Record_112_UDCSR_P,buffer,2);//POS�� ���ؼ�¼��ַ�α�
		
		buffer[0] = 0x59;
		buffer[1] = 0x80;
		I2C_WriteS_24C(Con_Fm_Record_112_End_Addr,buffer,2);//������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(Con_Fm_Record_112_Count,buffer,2);//����
		I2C_WriteS_24C(Con_Fm_Record_112_Cursor_F,buffer,1);//�α�Խ���ı�־λ
		
		
		buffer[0] = 0x5A;
		buffer[1] = 0x00;
		I2C_WriteS_24C(Con_Fm_Record_16_Start_Addr,buffer,2);//��ʼ��ַ  16
		I2C_WriteS_24C(Con_Fm_Record_16_Cursor,buffer,2);//���¼��ַ�α�
		I2C_WriteS_24C(Con_Fm_Record_16_UDCSR,buffer,2);//GPRS ���ؼ�¼��ַ�α�
		I2C_WriteS_24C(Con_Fm_Record_16_UDCSR_P,buffer,2);//POS�� ���ؼ�¼��ַ�α�
		
		buffer[0] = 0x7F;
		buffer[1] = 0x80;
		I2C_WriteS_24C(Con_Fm_Record_16_End_Addr,buffer,2);//������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(Con_Fm_Record_16_Count,buffer,2);//����
		I2C_WriteS_24C(Con_Fm_Record_16_Cursor_F,buffer,1);//�α�Խ���ı�־λ
		
		///////////////////////FLASH����ļ�¼����//////////////////////////////////////
		buffer[0] = 0x0D;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		I2C_WriteS_24C(Con_Flash_Record_16_Start_Addr,buffer,3);//��ʼ��ַ	32
		I2C_WriteS_24C(Con_Flash_Record_16_Cursor,buffer,3);//���¼��ַ�α�
		I2C_WriteS_24C(Con_Flash_Record_16_UDCSR,buffer,3);//���ؼ�¼��ַ�α�
		I2C_WriteS_24C(Con_Flash_Record_16_UDCSR_P,buffer,3);//POS ���ؼ�¼��ַ�α�
		
		buffer[0] = 0x19;
		buffer[1] = 0x35;
		buffer[2] = 0x00;
		I2C_WriteS_24C(Con_Flash_Record_16_End_Addr,buffer,3);//������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(Con_Flash_Record_16_Count,buffer,3);//����
		I2C_WriteS_24C(Con_Flash_Record_16_Cursor_F,buffer,1);//�α�Խ���ı�־λ
		
		buffer[0] = 0x1A;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		I2C_WriteS_24C(Con_Flash_Record_112_Start_Addr,buffer,3);//��ʼ��ַ  16
		I2C_WriteS_24C(Con_Flash_Record_112_Cursor,buffer,3);//���¼��ַ�α�
		I2C_WriteS_24C(Con_Flash_Record_112_UDCSR,buffer,3);//���ؼ�¼��ַ�α�
		I2C_WriteS_24C(Con_Flash_Record_112_UDCSR_P,buffer,3);//POS ���ؼ�¼��ַ�α�
		
		buffer[0] = 0x6F;
		buffer[1] = 0x73;
		buffer[2] = 0x00;
		I2C_WriteS_24C(Con_Flash_Record_112_End_Addr,buffer,3);//������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(Con_Flash_Record_112_Count,buffer,3);//����
		I2C_WriteS_24C(Con_Flash_Record_112_Cursor_F,buffer,1);//�α�Խ���ı�־λ
		
		///////////////////////////////δ������¼��ʼ��/////////////////////////////////
		for(uchar i=0;i<8;i++)
		  buffer[i] = 0x00;
		I2C_WriteS_24C(car1_false_record,buffer,8);
		I2C_WriteS_24C(car2_false_record,buffer,8);
		I2C_WriteS_24C(car3_false_record,buffer,8);
		I2C_WriteS_24C(car4_false_record,buffer,8);
	   
		////////////////////////////��Կ��ʼ��//////////////////////////////////
		CMY_MF1A(Cardkey_ALL);
		ini_rpt_info();//������Ϣ��ʼ��
		/////////////////////////////IP��ַ�Ͷ˿ں�/////////////////////////////
		for(i=0;i<6;i++)										
		  buffer[i] = 0x00;
		I2C_WriteS_24C(PSAM_ADRee,buffer,6);//��pasm��

#ifdef  IN_MBSYSTEM		
		memcpy(buffer,"3gnet",5);
		buffer[5] = 0xff;
		memcpy(buffer+6,"card",4);
		buffer[10] = 0xff;
		memcpy(buffer+11,"card",4);
		I2C_WriteS_24C(APNuser_possword,buffer,32);//��IP��
#endif
		
		buffer[0] = 192;
		buffer[1] = 168;
		buffer[2] = 0;
		buffer[3] = 1;
		buffer[4] = 0x80;
		buffer[5] = 0x40;
		I2C_WriteS_24C(IPADrees,buffer,6);//��IP��
		
		//////////////////////////////δ������¼////////////////////////////////
		for(i=0;i<112;i++)									  
		  buffer[i] = 0x00;
		
		I2C_WriteS_24C(car1_false_record,buffer,112);
		I2C_WriteS_24C(car2_false_record,buffer,112);
		I2C_WriteS_24C(car3_false_record,buffer,112);
		I2C_WriteS_24C(car4_false_record,buffer,112);
		
		///////////////////////////���� �������ĳ�ʼ��/////////////////////////  30000��
		buffer[0] = 0x00;
		buffer[1] = 0x70;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count_day,buffer,4);//������������ �׵�ַ
		I2C_WriteS_24C(BackList_Cursor_day,buffer,4);//������������ �α��ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x73;
		buffer[2] = 0xA9;
		buffer[3] = 0x80;
		I2C_WriteS_24C(backList_Addr_and_Count_day + 4,buffer,4);//������������ ������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count_day + 8,buffer,4); //���������� ����   
		
		buffer[0] = 0x00;
		buffer[1] = 0x0C;
		buffer[2] = 0x40;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count_day + 12,buffer,4); //���������� �ڴ濪ʼ��ŵĵ�ַ
		
		///////////////////////////���� �������ĳ�ʼ��///////////////////////// 10960��
		buffer[0] = 0x00;
		buffer[1] = 0x73;
		buffer[2] = 0xA9;
		buffer[3] = 0x80;
		I2C_WriteS_24C(backList_Addr_and_Count_day_reduce,buffer,4);//������������ �׵�ַ
		I2C_WriteS_24C(BackList_Cursor_day_reduce,buffer,4);//������������ �α��ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x77;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count_day_reduce + 4,buffer,4);//������������ ������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count_day_reduce + 8,buffer,4); //���������� ����	 
		
		buffer[0] = 0x00;
		buffer[1] = 0x10;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count_day_reduce + 12,buffer,4); //���������� �ڴ濪ʼ��ŵĵ�ַ 
		
		///////////////////////////////////////////////////////////////////////
		buffer[0] = 0x00;
		I2C_WriteS_24C((car1_value_comd),buffer,1);
		I2C_WriteS_24C((car2_value_comd),buffer,1);
		I2C_WriteS_24C((car3_value_comd),buffer,1);
		I2C_WriteS_24C((car4_value_comd),buffer,1);
		
		I2C_WriteS_24C((car1_write_comd),buffer,1);
		I2C_WriteS_24C((car2_write_comd),buffer,1);
		I2C_WriteS_24C((car3_write_comd),buffer,1);
		I2C_WriteS_24C((car4_write_comd),buffer,1);
		///////////////////////////////////////////////////////////////////////
		
		//////////////////////��� �ͣɣƣ��ңſ���ˢ��ʧ��ʱ��������Ϣ////////
		for(i=0;i<16;i++)
		  buffer[i] = 0x00;
		for(i=1;i<=4;i++)
		  save_mifare_NO(buffer,buffer,i);

		///////////////////////��� ����Flash�ı��////////////////////////////
		buffer[0] = 0x00;
		I2C_WriteS_24C(Flash_erased_sector_32_F,buffer,1);//�� ������ַ���α� ��־
		I2C_WriteS_24C(Flash_erased_sector_112_F,buffer,1);
		
		buffer[0] = 0x66;
		I2C_WriteS_24C(Flash_erased_sector_32_L,buffer,1);//�� ������ַ���α� ��־
		I2C_WriteS_24C(Flash_erased_sector_112_L,buffer,1);
		///////////////////////////////////////////////////////////////////////
							  
		I2C_WriteS_24C(LOW_VOLTAGE_F,buffer,1);//�͵�ѹ������¼ ���� ��1����д�ص�ַ��ȥ
		
		/////////////////////����ʱ������///////////////////////////////////////
		buffer[0] = 0x17;
		buffer[1] = 0x00;
		buffer[2] = 0x06;
		buffer[3] = 0x00;
		I2C_WriteS_24C(BACK_TIME,buffer,4);//���������ʱ��

		for(i=1;i<=4;i++)
		  WriteRecover(i,0);
		
		/////////////////////��¼���ͻ��Ƶ� ����////////////////////////////////ʵʱ����
		buffer[0] = 5;
		buffer[1] = 50;
		buffer[2] = 5;
		buffer[3] = 3;
		buffer[4] = 5;
		I2C_WriteS_24C(SendInterval,buffer,5);
		////////////////////////////////////////////////////////////////////////
			   
		//////////////////////////����ͨ ������������ �ϵ����//////////////////////////////
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(RequitPageCount,buffer,2);//ȫ��
		I2C_WriteS_24C(BackListAllCount,buffer,2);
		
		I2C_WriteS_24C(LNT_BACLK_RequitPage_DAY,buffer,2);//����
		I2C_WriteS_24C(LNT_BACLKALLCount_DAY,buffer,2);
		
		I2C_WriteS_24C(LNT_BACLK_RequitPage_Reduce,buffer,2);//����
		I2C_WriteS_24C(LNT_BACLK_ALLCount_Reduce,buffer,2);
		////////////////////////////////////////////////////////////////////////
		
		//////////////////////////�Է��� ����ʱ �ݴ�����////////////////////////
		buffer[0] = 0x00;																	   
		I2C_WriteS_24C(ReplenMoneryFlag,buffer,1);																		
		I2C_WriteS_24C(ReplenBlockFlag,buffer,1);																	  
		for(i=0;i<8;i++)																	   
		  buffer[i] = 0;																										 
		I2C_WriteS_24C(ReplenishmentNo,buffer,8);																	 
		I2C_WriteS_24C(ReplenishmentMonery,buffer,4);
		////////////////////////////////////////////////////////////////////////
		
		/////////////////////////////�Զ���λ ��ʱ ��¼/////////////////////////
		for(uchar i=0;i<32;i++)
		  buffer[i] = 0x00;
		I2C_WriteS_24C(ResetCar1Flag,buffer,1);
		I2C_WriteS_24C(ResetCar2Flag,buffer,1);
		I2C_WriteS_24C(ResetCar3Flag,buffer,1);
		I2C_WriteS_24C(ResetCar4Flag,buffer,1);
		
		I2C_WriteS_24C(ResetRecordCar1,buffer,32);
		I2C_WriteS_24C(ResetRecordCar2,buffer,32);
		I2C_WriteS_24C(ResetRecordCar3,buffer,32);
		I2C_WriteS_24C(ResetRecordCar4,buffer,32);
		////////////////////////////////////////////////////////////////////////
		
		/////////////////////////////�Է�����������ַ��ʼ��///////////////////// ÿ��4�ֽ�		  
		//�Է��� ������������ 7000��
		buffer[0] = 0x00;
		buffer[1] = 0x0C;
		buffer[2] = 0x35;
		buffer[3] = 0x00;
		I2C_WriteS_24C(MIFARE_BACLK_DAY_ADD_AC,buffer,4); //��ʼ��ַ
		I2C_WriteS_24C(MIFARE_BACLK_Cursor_day,buffer,4);//������������ �α��ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x0C;
		buffer[2] = 0xA2;
		buffer[3] = 0x60;
		I2C_WriteS_24C(MIFARE_BACLK_DAY_ADD_AC + 4,buffer,4); //������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(MIFARE_BACLK_DAY_ADD_AC + 8,buffer,4); //����������
		I2C_WriteS_24C(MIFARE_BACLK_ALLCount_DAY ,buffer,2);
		I2C_WriteS_24C(MIFARE_BACLK_RequitPage_DAY ,buffer,2);
		
		//�Է��� �ռ��������� 5992��
		buffer[0] = 0x00;
		buffer[1] = 0x0C;
		buffer[2] = 0xA2;
		buffer[3] = 0x60;
		I2C_WriteS_24C(MIFARE_BACLK_DAY_REDUC_AC,buffer,4); //��ʼ��ַ
		I2C_WriteS_24C(MIFARE_BACLK_Cursor_day_reduce,buffer,4);//������������ �α��ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x0D;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(MIFARE_BACLK_DAY_REDUC_AC + 4,buffer,4); //������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(MIFARE_BACLK_DAY_REDUC_AC + 8,buffer,4); //����������
		I2C_WriteS_24C(MIFARE_BACLK_ALLCount_Reduce ,buffer,2);
		I2C_WriteS_24C(MIFARE_BACLK_RequitPage_Reduce ,buffer,2);
		
		///////////////////////������ ���ڴ�ĵ�ַ//////////////////////////////
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		
		I2C_WriteS_24C(LNT_BaclkMoneryAddrAll,buffer,4); 
		I2C_WriteS_24C(LNT_BaclkMoneryAddrDay_Add,buffer,4);
		I2C_WriteS_24C(LNT_BaclkMoneryAddrDay_Reduce,buffer,4);
		
		I2C_WriteS_24C(MIFARE_BaclkMoneryAddrDay_Add,buffer,4);
		I2C_WriteS_24C(MIFARE_BaclkMoneryAddrDay_Reduce,buffer,4);		  

		///////////////////////����������� ��flash�ĳ�ʼ��/////////////////////
		buffer[0] = 0x00;
		buffer[1] = 0x75;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(UpdateProgramAddr,buffer,4);//����������� ��ʼ��ַ
		I2C_WriteS_24C(UpdateCoursor,buffer,4);//����������� �����α�
		
		buffer[0] = 0x00;
		buffer[1] = 0x7F;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(UpdateProgramAddr + 4,buffer,4);//����������� ������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(UpdateProgramAddr + 8,buffer,4);//����������� ����
		
		buffer[0] = 0x00;
		buffer[1] = 0x7D;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(UpdateFlagAddr,buffer,4);//������־ ��ַ  ���� 3  ��־ 4
		
		I2C_ReadS_24C(UpdateProgramAddr + 8,flag_buffer,4);
		I2C_ReadS_24C(UpdateFlagAddr,buffer,4);
		Addr = hcl(buffer,4);
		SPI_FLASH_BufferWrite(flag_buffer+1,Addr,3);//д������������
		
		buffer[0] = 0xA2;
		I2C_WriteS_24C(IAPBreakPointResume,buffer,1);//IAP�ϵ����� �ı�־
			   
		for(i=0;i<4;i++)
			{		
			flag_buffer[i] = 0x00;//������־
			}
		SPI_FLASH_BufferWrite(flag_buffer,Addr+3,4);//д������־
		 
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(Update_RequitPage,buffer,2);//��������İ���
		I2C_WriteS_24C(Update_ALLCount,buffer,2);//Ӧ��������ܰ���
		
		buffer[0] = 0xA2;
		I2C_WriteS_24C(IAPUpdataClass,buffer,1);//ѡ���Զ�����
		buffer[0] = 0x04;
		buffer[1] = 0x00;
		I2C_WriteS_24C(IAPUpdataTime,buffer,2);//����ʱ�� 04:00
		
		buffer[0] = 0xA2;
		I2C_WriteS_24C(FreeClass,buffer,1);//����ѡ���Զ�����
		buffer[0] = 0x04;
		buffer[1] = 0x50;
		I2C_WriteS_24C(FreeUpdataTime,buffer,2);//����ʱ�� 04:50
		
		buffer[0] = 0xA2;
		I2C_WriteS_24C(LNTClass,buffer,1);//����ͨ ���������ط�ʽ �Զ�
		I2C_WriteS_24C(MIFAREClass,buffer,1);//�Է��� ���������ط�ʽ �Զ�
		////////////////////////////////////////////////////////////////////////
		NETSET_INI(1);
		INI_IAP_PRO();
		//////////////////////�¿���������־����////////////////////////////////
		buffer[0] = 0x00;
		for(i=0;i<4;i++)
			{
			I2C_WriteS_24C(MonthCarInERRORCar1+i,buffer,1);
			I2C_WriteS_24C(MonthCarOutERRORCar1+i,buffer,1);
			I2C_WriteS_24C(MonthCarCountERRORCar1+i,buffer,1);
			}
		goto_xy(0x02,10);
		print_str_16_16("flash ini...");	  //�汾��
		SPI_FLASH_Init();
		SPI_FLASH_BulkErase();
		//Erased_sector();
		for(i = 0;i< 16;i++)
		  buffer[i] = INIT_FLAG;//д�� �Ѿ���ʼ���� �ı�־
		I2C_WriteS_24C(initialize_EEPROM,buffer,16);
//		//������λһ��
//		GenerateSystemReset();
}

void UART_DAEL_CODE(u8 ON_OFF)
{
	if(TMP.COM4==2)
		return;
	if(ON_OFF)
		{
		if(TMP.COM1)
			UART1_IRQn_CTL(ON);
		if(TMP.COM4==ON)
			UART4_IRQn_CTL(ON);
		if(TMP.COM5)
			UART5_IRQn_CTL(ON);
		}
	else
		{
		UART1_IRQn_CTL(OFF);
		if(TMP.COM4==0)
			UART4_IRQn_CTL(OFF);
		UART5_IRQn_CTL(OFF);
		}
}

void WR_SYSBOOT(void)
{
u8 CRC_CRC[20];

	I2C_ReadS_24C(SYSPRO_JD_APP,CRC_CRC,10); 
	I2C_ReadS_24C(SYSPRO_JD_BOOTLOADER,CRC_CRC+10,10); 

	I2C_WriteS_24C(SYSPRO_JD_APP,"LUO1512",7);		
	CRC_CRC[7] = MATERVERSIONB_;
	CRC_CRC[8] = MATERVERSION;
#ifdef PRT_PRO
	CRC_CRC[9] = MATERVERSIONCRC;//
#else
	CRC_CRC[9] = 'u';//
#endif
	I2C_WriteS_24C(SYSPRO_JD_APP+7,CRC_CRC+7,3); 
	I2C_WriteS_24C(SYSPRO_JD_BOOTLOADER+7,CRC_CRC+7,3); 
	I2C_ReadS_24C(SYSPRO_JD_APP,CRC_CRC,10); 
	I2C_WriteS_24C(SYSPRO_JD_BOOTLOADER,CRC_CRC,10); 
	I2C_ReadS_24C(SYSPRO_JD_APP,CRC_CRC,10); 
	I2C_WriteS_24C(SYSPRO_JD_BOOTLOADER,CRC_CRC,10); 

	I2C_ReadS_24C(SYSPRO_JD_APP,CRC_CRC,10); 
	I2C_ReadS_24C(SYSPRO_JD_BOOTLOADER,CRC_CRC+10,10); 
}

//md_flag: 1-���� 0-����
void disp_md_yes_no(u8 dxx,u8 dyy,u8 md_flag)
{

#ifdef IN_MBSYSTEM //�����ӵ���ʾ 2016-02-22
	dyy = 13;
	if(md_flag==0)
		{
		print_XYstr_16_16(dxx,dyy,"OK");	
		}
	else
		{
		print_XYstr_16_16(dxx,dyy,"NG");	
		}		
#elif defined EN_MBSYSTEM
	dyy = 13;
	if(md_flag==0)
		{
		print_XYstr_16_16(dxx,dyy,"OK");	
		}
	else
		{
		print_XYstr_16_16(dxx,dyy,"NG");	
		}		
							
#else
	if(md_flag==0)
		{
		dispaly(dxx,dyy++,(HZ + zheng));
		dispaly(dxx,dyy++,(HZ + chang));
		}
	else
		{
		dispaly(dxx,dyy++,(HZ + gu));
		dispaly(dxx,dyy++,(HZ + zhang));
		}		
#endif
	
}

    
    


void goto_sleep111(void)
{
   // ADC_InitTypeDef   ADC_InitStructure;
        GPIO_InitTypeDef  GPIO_InitStructure;
 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////          
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,  DISABLE);	
        
        Uart5_Close();
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, DISABLE); //�رմ���1ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, DISABLE); //�رմ���2ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, DISABLE); //�رմ���3ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,  DISABLE); //�رմ���4ʱ��  
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,  DISABLE); //�رմ���5ʱ��         
        
        SPI_Cmd(SPI_FLASH, DISABLE);
        RCC_APB2PeriphClockCmd(SPI_FLASH_CLK | SPI_FLASH_GPIO_CLK | SPI_FLASH_CS_GPIO_CLK, DISABLE);

        ADC_Cmd(ADC1,DISABLE);
        ADC_Cmd(ADC2,DISABLE);//ADC2
        ADC_Cmd(ADC3,DISABLE);//ADC3
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, DISABLE);
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, DISABLE); 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //FSMC_SRAM_DISABLE(); 
        //RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, DISABLE);
        
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;//��?3G??????
//	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;//��?3G??????
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//	GPIO_Init(GPIOA, &GPIO_InitStructure); 
	//	GPIO_Pin_0|��2.4G��Դ
	 GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	 GPIO_Init(GPIOA, &GPIO_InitStructure);
	 GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_10|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;//|GPIO_Pin_9|GPIO_Pin_11(3G����)
	 GPIO_Init(GPIOA, &GPIO_InitStructure);   
	 
	 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	 GPIO_Init(GPIOA, &GPIO_InitStructure); 
	 GPIO_SetBits(GPIOA, GPIO_Pin_9);
        

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
     	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_15;//��?3G??????
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOB, &GPIO_InitStructure);      
        
        
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_5|GPIO_Pin_6;//|GPIO_Pin_7;  //--LED|GPIO_Pin_4
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOC, &GPIO_InitStructure); 
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
        
        
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;////GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_3|-----LED
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOD, &GPIO_InitStructure); 
        GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14| GPIO_Pin_15;  //�Ѿ���Ϊ��ѹ�����
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOD, &GPIO_InitStructure); 
        
        
//////////////////////////////////////////////////////////////////////////////////////////////
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
     	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_15;//|GPIO_Pin_13,GPIO_Pin_15��?3G??????
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOE, &GPIO_InitStructure);    
        
        
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        //////////////////////////////////////////////////////////////////////////////////////////////
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;///|GPIO_Pin_6|GPIO_Pin_7
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOF, &GPIO_InitStructure);
     	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;//GPIO_Pin_8|GPIO_Pin_9|
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOF, &GPIO_InitStructure);   
        
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOG, &GPIO_InitStructure);
	
	if(Judge_MB_MODE()==0)//�м����  
     	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14;//|GPIO_Pin_15|GPIO_Pin_13,|GPIO_Pin_15
	else
		GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;//|GPIO_Pin_13,|GPIO_Pin_15
	//GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_12|GPIO_Pin_14|GPIO_Pin_15;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOG, &GPIO_InitStructure);     
        

//////////////////////////////////////////////////////////////////////////////// 
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, DISABLE);//dis
        
        ADC_Cmd(ADC1, DISABLE);
        ADC_Cmd(ADC2, DISABLE);    
        RCC_APB1PeriphResetCmd(RCC_APB1Periph_DAC, DISABLE);//dis
        RCC_APB1PeriphResetCmd(RCC_APB1Periph_DAC, DISABLE);
        
//        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB 

//                              | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD 
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD 

                              | RCC_APB2Periph_GPIOE | RCC_APB2Periph_GPIOF

                              | RCC_APB2Periph_GPIOG | RCC_APB2Periph_AFIO, DISABLE);//dis


  
  // Disable the Serial Wire Jtag Debug Port SWJ-DP

        //GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, DISABLE); //dis 
        GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE); //dis

//        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;

//        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;

//        GPIO_Init(GPIOA, &GPIO_InitStructure); 
////////////////////////////////////////////////////////////////////////////////
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_SRAM | RCC_AHBPeriph_FLITF, DISABLE);
    
    
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1 | RCC_AHBPeriph_DMA2 | RCC_AHBPeriph_CRC | RCC_AHBPeriph_SDIO, DISABLE);
        
    
}

/*����*/
void goto_sleep(void)
{
  // ADC_InitTypeDef   ADC_InitStructure;
  GPIO_InitTypeDef  GPIO_InitStructure;
  u8 buf[2];
  I2C_ReadS_24C(Base_Disp_SW,buf,1); 
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////          
  //1�ر����д��ڵĽ���       
  Uart5_Close();
  if((Judge_MB_MODE()==0)&&(SYS_MS.night_flag==0)) //�м����	
	 {
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);//�رմ���1ʱ��(3G����)
  	 }
  else
  	{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, DISABLE);//�رմ���1ʱ��(3G����)
  	}
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, DISABLE);//�رմ���2ʱ��
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, DISABLE);//�رմ���3ʱ��
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,  DISABLE);//�رմ���4ʱ��  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,  DISABLE);//�رմ���5ʱ��  
  
  //2FLASH
  SPI_Cmd(SPI_FLASH, DISABLE); 
  RCC_APB2PeriphClockCmd(SPI_FLASH_CLK | SPI_FLASH_GPIO_CLK | SPI_FLASH_CS_GPIO_CLK, DISABLE);
  //3ADC
  ADC_Cmd(ADC1,DISABLE);
  ADC_Cmd(ADC2,DISABLE);
  ADC_Cmd(ADC3,DISABLE);//ADC3
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, DISABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, DISABLE); 
  RCC_APB1PeriphResetCmd(RCC_APB1Periph_DAC, DISABLE);
  //  4FSMC (ע��)
  //  FSMC_SRAM_DISABLE(); 
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, DISABLE);	
  
  //GPIOA���Ž�IO����ΪAIN,�����������--huangfeng.
  //���ñ�׼�Ŀ⺯��,����͹���ģʽ(PWR_EnterSTOPMode��PWR_EnterSTANDBYMode����)
  //  GPIO_Pin_0|��2.4G��Դ
//  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//  GPIO_Init(GPIOA, &GPIO_InitStructure);
//  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_10|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;//|GPIO_Pin_9|GPIO_Pin_11(3G����)
//  GPIO_Init(GPIOA, &GPIO_InitStructure);   
//  if((Judge_MB_MODE()==0)&&(SYS_MS.night_flag==0)) //�м����	
  if((TMP.BaseFlag ==0)&&(SYS_MS.night_flag==0)) //�м����	
	  {
	  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	  GPIO_Init(GPIOA, &GPIO_InitStructure);
	  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_10|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;//|GPIO_Pin_9|GPIO_Pin_11(3G����)
	  GPIO_Init(GPIOA, &GPIO_InitStructure);   
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //
	  GPIO_Init(GPIOA, &GPIO_InitStructure);
	  }
  else
  	 {
	 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;  
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;  
	 GPIO_Init(GPIOA, &GPIO_InitStructure);  
   	 }


  
  //GPIOB���ţ�GPIO_PortSourceGPIOB, GPIO_PinSource5----32_PULES); 
  GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_6|GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_14|GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOB, &GPIO_InitStructure); 
  //GPIOC����	��8��13��14��15������Led4 - PC4  GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_9|GPIO_Pin_9||GPIO_Pin_7|GPIO_Pin_7
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_5|GPIO_Pin_6; 
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOC, &GPIO_InitStructure); 
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12;//GPIO_Pin_12;//GPIO_Pin_10|GPIO_Pin_11|
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOC, &GPIO_InitStructure);     
  
  //GPIOD����(Led3 - PD3)
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
//  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOD, &GPIO_InitStructure); 
  GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14| GPIO_Pin_15;  
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOD, &GPIO_InitStructure); 		
//  //IC_SWITCH-PD6(PG6) //������(=1�޿�/=0�п�)
//  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	//��������
//  GPIO_Init(GPIOD, &GPIO_InitStructure);  
  //GPIOE����
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_All;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOE, &GPIO_InitStructure);
  
  //GPIOF����LED1 - PF6    LED2 - PF7
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOF, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
//  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOF, &GPIO_InitStructure); 
//  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_10;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
//  GPIO_Init(GPIOF, &GPIO_InitStructure); 
  
  //GPIOG���� 
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOG, &GPIO_InitStructure);
  
  if((TMP.BaseFlag ==0)&&(buf[0]!=0))
  	{
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_14;//GPIO_Pin_13||GPIO_Pin_15
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//	GPIO_Init(GPIOG, &GPIO_InitStructure);
  	}
  else if((SYS_MS.G3_MODE==0)&&(SYS_MS.night_flag==0)) //�м����  
 	{
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14;//|GPIO_Pin_15
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOG, &GPIO_InitStructure);
	}
  else
  	{  
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_All;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOG, &GPIO_InitStructure);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG, DISABLE);
  	}
  
  //   RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, DISABLE);
  //	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, DISABLE);	 //����32S
  //	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, DISABLE);	 //����
  //  	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, DISABLE);	 //
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, DISABLE);
  //  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, DISABLE);	 
  //RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG, DISABLE);
  //	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,  DISABLE);	 //�ж�	  
  
  ////////////////////////////////////////////////////////////////////////////////
  
  // Disable the Serial Wire Jtag Debug Port SWJ-DP ����
  GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, DISABLE); // 
  
  
  //////////////////////////////////////////////////////////////////////////////// 
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_SRAM | RCC_AHBPeriph_FLITF, DISABLE);     
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1 | RCC_AHBPeriph_DMA2 | RCC_AHBPeriph_CRC | RCC_AHBPeriph_SDIO, DISABLE);
  //  RCC_APB1PeriphResetCmd(RCC_APB1Periph_ALL, DISABLE); //2014-1-21
  //  RCC_APB2PeriphResetCmd(RCC_APB2Periph_ALL, DISABLE);
  RCC_RTCCLKCmd(DISABLE);
  ////////////////////////////////////////////////////////////////////////////////   
  //RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);//dis     
  
}



void open_usart(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);//�򿪴���1ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);//�򿪴���2ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);//�򿪴���3ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,ENABLE);//�򿪴���4ʱ��  
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,ENABLE);//�򿪴���5ʱ�� 
}

void sleepLcd1(void)
{
 GPIO_InitTypeDef  GPIO_InitStructure;
 LCD_back_OFF;    
 LCD_POWER_OFF; 
 
 GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6;
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
 GPIO_Init(GPIOE, &GPIO_InitStructure);
 
 GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_8 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_11 | GPIO_Pin_12;
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
 GPIO_Init(GPIOG, &GPIO_InitStructure);
 
 GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_15;
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
 GPIO_Init(GPIOB, &GPIO_InitStructure);
 
 GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_1 | GPIO_Pin_1;
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
 GPIO_Init(GPIOC, &GPIO_InitStructure);
 
 db0_1;
 db1_1;
 db2_1;
 db3_1;
 db4_1;
 db5_1;
 db6_1;
 db7_1;
 
 lcd_cs_1;
}


void sleep_lcd(void)
{
 GPIO_InitTypeDef  GPIO_InitStructure;
 LCD_back_OFF;    
 LCD_POWER_OFF; 
 GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_13;
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
 GPIO_Init(GPIOG, &GPIO_InitStructure);
}

/*���Ѻ�����*/
void sleepout1_TaiSun(void)
{    

  GPIO_InitTypeDef  GPIO_InitStructure; 

  GPIO_Configuration();  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);  //ע�����ﲢû�д�PB6\7���ŵĸ���AFIO���ܣ�ģ��I2C
  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 |GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode =GPIO_Mode_Out_OD ;  	//AF
  GPIO_Init(GPIOB, &GPIO_InitStructure);  
 
  LCD_POWER_ON;
  SPI_FLASH_Init();	    //Flash��ʼ��
  //ChipOutHalInit(); 	  //Ƭ��Ӳ����ʼ��  
  Uart1_Configuration(BaudRate_9600);      //���ڲ����ʵȲ�������
  Uart2_Configuration();                   // 115200
  Uart3_Configuration(BaudRate_38400);
  Uart4_Configuration(BaudRate_19200);	   //����ͨ��  ����   ��ӡ��
  Uart5_Configuration();                   //38400
  /* ι��*/
  IWDG_ReloadCounter();//2015-12-23 andyluo
}




void sleepout1(void)
{
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	//GPIO_Configuration();
    //ChipOutHalInit1();
    
//	if((SYS_MS.G3_MODE==0)&&(SYS_MS.night_flag==0)) //�м����	 
	if((TMP.BaseFlag==0)&&(SYS_MS.night_flag==0)) //�м����	 
  	  	ChipHalInit_sleep();
	else
		ChipHalInit();			//Ƭ��Ӳ����ʼ��
    ChipOutHalInit();		//Ƭ��Ӳ����ʼ��
    IWDG_ReloadCounter();
}
//////////////////////////////////////////////////////////////////////////////////
/*----------------------------------------------------------------------
function name:   	unsigned char LowVoltage_Test(void)
describe:    	 	�͵�ѹ��ⷵ��:1Ϊ�� 0Ϊ��
input:   			
output:
date:			andyluo 2010-12-03 14:26:57
------------------------------------------------------------------------*/
unsigned char LowVoltage_Test(void)
{
////////////////////////////////PD4---PB14///////////////////////////////////////////
  GPIO_InitTypeDef GPIO_InitStructure;
  uchar flag;
  /*����MAX884��Դ����������Back batter Ctrl */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;		//��������
	GPIO_Init(GPIOB, &GPIO_InitStructure);

  if((GPIO_ReadInputData(GPIOB)&0x4000)==0x0000)
    {
      Delay(100);
     if((GPIO_ReadInputData(GPIOB)&0x4000)==0x0000)
      {
	 	//fault_record(0x10);
		flag =0;
      }
     else
 	 flag =1;
    }
  else
 	 flag =1;

  //���Ե͵�ѹ 
//  flag =0;

  
  return flag; 
  
}                                                 
         
///////////////////////////////////////////////////////////////////////////////////////

uchar count_Lcd_back()
{
    uchar Begin_Hour;
    uchar Begin_Min;
    uchar End_Hour;
    uchar End_Min;
    uchar buffer[4];
    
    
    //������һ�� Զ������ �����ʱ��
     
     I2C_ReadS_24C(BACK_TIME,buffer,4);//���������ʱ��
     GetCurrentTime();  
    
     Begin_Hour = buffer[0];
     Begin_Min = buffer[1];
     End_Hour = buffer[2];
     End_Min = buffer[3];
     
    if(time[1] > Begin_Hour || time[1] < End_Hour)
      return 1;
    else if(time[1] == Begin_Hour && time[0] >= Begin_Min)
      return 1;
    else if(time[1] == End_Hour && time[0] <= End_Min)
      return 1;
    else
      return 0;
}

void read_IP()
{
    uchar buffer[6];
    
    uchar hundred;
    uchar ten;
    uchar ge;
    
    uchar i = 0;
	
	/**/
	//124.172.126.161 218.17.233.35
	buffer[0] = 218;
	buffer[1] = 17;
	buffer[2] = 233;
	buffer[3] = 35;
	buffer[4] = 0x96;//�Բ�˿�9655��9650-9660��
	buffer[5] = 0x50;//�Բ�˿�
//	buffer[4] = 0x33;//ʵ��˿�6055
//	buffer[5] = 0x66;//��������
//	122.227.45.110:9001 2015-09-22
//	buffer[0] = 122;
//	buffer[1] = 227;
//	buffer[2] = 45;
//	buffer[3] = 110;
//	buffer[4] = 0x90;//9001
//	buffer[5] = 0x01;//�ͻ��˿�
//	buffer[4] = 0x96;//9001
//	buffer[5] = 0x38;//�ͻ��˿�
#ifdef IP_OWN
	I2C_WriteS_24C(IPADrees,buffer,6);//
#endif
//	
//	buffer[0] = 'C';
//	buffer[1] = 'A';
//	buffer[2] = 'R';
//	buffer[3] = 'D';
//	buffer[4] = 0xff;
//	buffer[5] = 'C';
//	buffer[6] = 'A';
//	buffer[7] = 'R';
//	buffer[8] = 'D';
//	buffer[9] = 0xff;
//	I2C_WriteS_24C(APNuser_possword,buffer,32);

	
    I2C_ReadS_24C(IPADrees,buffer,6);//��IP��
    
    hundred = buffer[0] / 100;
    ten = buffer[0] / 10 % 10;
    ge = buffer[0] % 10;
    if(hundred > 0)
    {
        IP[i++] = hex_to_asic(hundred);
        IP[i++] = hex_to_asic(ten);
        
    }
    else if(ten > 0)
    {
        IP[i++] = hex_to_asic(ten);
    }
    else
    {}
    
    IP[i++] = hex_to_asic(ge);
        
    IP[i++] = 46;// .
    
    
    hundred = buffer[1] / 100;
    ten = buffer[1] / 10 % 10;
    ge = buffer[1] % 10;
    if(hundred > 0)
    {
        IP[i++] = hex_to_asic(hundred);
        IP[i++] = hex_to_asic(ten);
        
    }
    else if(ten > 0)
    {
        IP[i++] = hex_to_asic(ten);
    }
    else
    {}
    
    IP[i++] = hex_to_asic(ge);
        
    IP[i++] = 46;// .
    
    
    
    hundred = buffer[2] / 100;
    ten = buffer[2] / 10 % 10;
    ge = buffer[2] % 10;
    if(hundred > 0)
    {
        IP[i++] = hex_to_asic(hundred);
        IP[i++] = hex_to_asic(ten);
        
    }
    else if(ten > 0)
    {
        IP[i++] = hex_to_asic(ten);
    }
    else
    {}
    
    IP[i++] = hex_to_asic(ge);
        
    IP[i++] = 46;// .
    
    
    
    
    hundred = buffer[3] / 100;
    ten = buffer[3] / 10 % 10;
    ge = buffer[3] % 10;
    if(hundred > 0)
    {
        IP[i++] = hex_to_asic(hundred);
        IP[i++] = hex_to_asic(ten);
        
    }
    else if(ten > 0)
    {
        IP[i++] = hex_to_asic(ten);
    }
    else
    {}
    
    IP[i++] = hex_to_asic(ge);
    
    IP[i++] = '\0';
    
    
    
    //�˿ں� ��ȡ
    
    i = 0;
    
    PORT[i++] = hex_to_asic((buffer[4]>>4)&0x0f);
    PORT[i++] = hex_to_asic(buffer[4]&0x0f);
    PORT[i++] = hex_to_asic((buffer[5]>>4)&0x0f);
    PORT[i++] = hex_to_asic(buffer[5]&0x0f);
    
    PORT[i++] = '\0';
    
    
}

/*�������ڵ���������ͣ��ģʽ����֮������ϵͳʱ�ӡ�ʹ��HSE��PLL������
PLL��Ϊϵͳʱ��Դ��*/
void SYSCLKConfig_STOP(void)
{
  ErrorStatus HSEStartUpStatus;
  
  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);
  
  /* Wait till HSE is ready */
  HSEStartUpStatus = RCC_WaitForHSEStartUp();
  
  if(HSEStartUpStatus == SUCCESS)
  {
    
#ifdef STM32F10X_CL
    /* Enable PLL2 */ 
    RCC_PLL2Cmd(ENABLE);
    
    /* Wait till PLL2 is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLL2RDY) == RESET)
    {
    }
#endif
    
    /* Enable PLL */ 
    RCC_PLLCmd(ENABLE);
    
    /* Wait till PLL is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {
    }
    
    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
    
    /* Wait till PLL is used as system clock source */
    while(RCC_GetSYSCLKSource() != 0x08)
    {
    }
  }
}




void SYSCLKConfig_STOPERR(void)
{
  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);

  /* Wait till HSE is ready */
  HSEStartUpStatus = RCC_WaitForHSEStartUp();

  if(HSEStartUpStatus == SUCCESS)
  {

#ifdef STM32F10X_CL
    /* Enable PLL2 */ 
    RCC_PLL2Cmd(ENABLE);

    /* Wait till PLL2 is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLL2RDY) == RESET)
    {
    }
#endif

    /* Enable PLL */ 
    RCC_PLLCmd(ENABLE);

    /* Wait till PLL is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {
    }

    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while(RCC_GetSYSCLKSource() != 0x08)
    {
    }
  }
}

