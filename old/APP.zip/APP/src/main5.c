#include "cwosession.h"
#include "main5.h"
extern unsigned char sz1[];
int main5(void)
{
  
//CDS_RETVAL connectRetVal = CreateSession("gateway.test.caleaccess.com", "50952", 30 /*seconds*/);
/*if(OK != connectRetVal)
{
      //Failed to connect to gateway. Exit!
   return 1;
}*/
//41c94ac8-4cba-4821-ad4a-645220be7381
 //  const unsigned short request_command[] = L"<getCommandListReq terminalGuid=\"41c94ac8-4cba-4821-ad4a-645220be7381\" ver=\"1\"/>";
   const unsigned short request_command[] = L"<getCommandListReq terminalGuid=\"869F9A7A-3DB9-4368-8FF7-281F125D701E\" ver=\"1\"/>";   
//   const unsigned short request_command[] = L"<getCommandListReq terminalGuid=\"9a2db9fb-0dc2-480d-8fbe-ac11870ef876\" ver=\"1\"/>";   
   unsigned short* response = NULL;

   CDS_RETVAL retVal = SendRequestAndGetResponse(request_command, &response, cNoCompression, 45 /*seconds*/);
   if(OK != retVal)
   {
     int i = 0;
      //Failed to send request and get a proper response
   }

   if(NULL != response)
      ReleaseMemory(response);

   CDS_RETVAL destroyRetVal = DestroySession();
   if(OK != destroyRetVal)
   {
      //Failed to send request and get a proper response
   }
 strcpy(sz1,response);
  return 0;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
terminalGuid="869F9A7A-3DB9-4368-8FF7-281F125D701E" TCHGuid="A08140AA-D63A-4f1b-9D12-C682C5EED13A" 
purchaseGuid="00000000-0000-0000-0000-000000000000" purchaseNumber="1" articleId="1" tariffPackageId="1" paymentServiceTypeId="1" units="10" startDateUtc="2010-11-18T12:25:00" endDateUtc="2010-11-18T12:35:00" purchaseDateUtc="2010-11-18T12:25:00" payIntervalStartDateUtc="2010-11-18T12:25:00" payIntervalEndDateUtc="2010-11-18T12:25:00" trigger="0" state="0" description="" payUnitId="1" amount="10.00" currency="EUR" /> 
purchaseGuid="00000000-0000-0000-0000-000000000000" purchaseNumber="2" articleId="1" tariffPackageId="2" paymentServiceTypeId="1" units="5" startDateUtc="2010-11-18T12:35:00" endDateUtc="2010-11-18T12:40:00" purchaseDateUtc="2010-11-18T12:35:00" payIntervalStartDateUtc="2010-11-18T12:35:00" payIntervalEndDateUtc="2010-11-18T12:35:00" trigger="0" state="0" description="">
- <sp:payUnits>
  <sp:payUnit payUnitId="2" amount="20.00" currency="EUR" maskedPAN="423456*7890" bankAuthorizationReference="12423" cardIssuer="VISA" transactionReference="12345678" /> 
  </sp:payUnits>
  </sp:purchase>
  </sp:submitPurchaseListReq>
*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////