#include "stm32f10x_conf.h"
#include "hal.h"
//#include "IRrecei.h"
#include "LCD_12864.h"
//#include "KEY.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_it.h"
#include "misc.h"
//#include "main.h"


/*  PB14-----оƬ��λreset*/
/*  PB15-----оƬ����data*/
/*  PE7-----оƬ��Դ 1�� 0�ر�*/
/*  PB14-----оƬ��Դ���� 0���������� 1 */

/*��������*/
#define audio_power_on  GPIOE->BSRR = 0x00000080
#define audio_power_off  GPIOE->BSRR = 0x00800000

#define audio_reset  GPIOB->BSRR = 0x40000000
#define audio_set  GPIOB->BSRR = 0x00004000

#define audio_data_reset  GPIOB->BSRR = 0x80000000
#define audio_data_set  GPIOB->BSRR = 0x00008000
extern u8 money_h,money_m,money_l;
extern u8 park_hour,park_min;
u32 money;
u8 y_money_h,y_money_m,y_money_l;

void audio (u8 addr);
void audio_data(u8 num);
/*   addr����������¼��оƬ���ݵ�ַ���������pdf�ļ�     */
void audio(u8 addr)
{u8 i;
   //POWER_change_ON;
  audio_power_on;
  delay(14500);
  //card_power_lock;
  audio_reset;
   audio_data_set;
  delay(145000);
  audio_set;
  delay(435000);
  
  audio_data_reset;
  delay(435000);

  
  for(i=0;i<8;i++)
  {
     audio_data_set;
     if(addr&1)
          {
            delay(43500);
            audio_data_reset;
            delay(14500);
                  
          }
     else
          {
            delay(14500);
            audio_data_reset;
            delay(43500);
          }
    addr>>=1;
  }
 audio_data_set; 
    delay(3000000);
}

/*���ַ�����num����Ҫ����������*/
void audio_data(u8 num)
{  u8 data_audio;
    data_audio=num;
 if(data_audio<0x0a)
 	{
   switch (num)
			{ 	  
			  case 0x00:
			     	audio (0x36);
			     	break;
			  case 0x01:
			  	audio (0x37);
			  	break;
			  case 0x02:
			  	audio (0x38);
			  	break;
			  case 0x03:
			  	audio (0x39);
			  	break;
			  case 0x04:
			  	audio (0x3a);
			  	break;
			  case 0x05:
			  	audio (0x3b);
			  	break;
			  case 0x06:
			  	audio (0x3c);
			  	break;
			  case 0x07:
			  	audio (0x3d);
			  	break;
			  case 0x08:
			  	audio (0x3e);
			  	break;
			  case 0x09:
			  	audio (0x3f);
			  	break;
		         default:
		         	break;
			  
			 }
 	}
    delay(3000000);
}

/*
  ���:money_m(ǧ��λ)money_m(ʰ��λ)money_l(��)(10����)
   
*/
void money_audio() 
{	  goto_xy(0x06,0x0e);	
//  print_str_16_16("�������:"); 
  //u32 money=0;
  money=money_h*256*256+money_m*256+money_l;
//  goto_xy(0x8A,0x07);
//  print_str_16_16("���");
//  print_num16_16(money/100000%10);
//  print_num16_16(money/10000%10);
//  print_num16_16(money/1000%10);
//  print_num16_16(money/100%10);
//  print_str_16_16(".");
//  print_num16_16(money/10%10);
//  print_num16_16(money%10);
  
y_money_h=money/100000%10;
y_money_h=y_money_h<<4;
y_money_h=y_money_h+money/10000%10;
 y_money_m=money/1000%10;
y_money_m=y_money_m<<4;
y_money_m=y_money_m+money/100%10;
y_money_l=money/10%10;
y_money_l=y_money_l<<4;
y_money_l=y_money_l+money%10;
IWDG_ReloadCounter();	//ι��
  /*
       u32 money=0;
       u8 y_money_h,y_money_m,y_money_l;
  money=money_h*256*256+money_m*256+money_l;
  
y_money_h=money/100000%10;
y_money_h=y_money_h<<4;
y_money_h=y_money_h+money/10000%10;

 y_money_m=money/1000%10;
y_money_m=y_money_m<<4;
y_money_m=y_money_m+money/100%10;

y_money_l=money/10%10;
y_money_l=y_money_l<<4;
y_money_l=y_money_l+money%10;*/
    goto_xy(0xAA,0x07);
//  print_num16_char(y_money_h);
//  print_num16_char(y_money_m);
//  print_str_16_16(".");
//  print_num16_char(y_money_l);
//  delay(10000000);
	if (y_money_h==0x00)
		{   if(y_money_m==0x00)
			{
				//����
					//audio(0x01);
				audio_data(0x00);
                                IWDG_ReloadCounter();	//ι��
  	  	    			audio(0x43);
			}

  	  	    else//99.99~1.00

  	  	    	{
  	  	    		if(y_money_m/0x10!=0)//99.99~1.00
  	  	    			{audio_data(y_money_m/0x10);
                                        IWDG_ReloadCounter();	//ι��
  	  	    			audio(0x40);
  	  	    			if(y_money_m%0x10!=0)
  	  	    				{
  	  	    			 	audio_data(y_money_m%0x10);
  	  	    				}
  	  	    			audio(0x31);
  	  	    			audio_data(y_money_l/0x10);
                                        IWDG_ReloadCounter();	//ι��
  	  	    			audio_data(y_money_l%0x10);
  	  	    			audio(0x43);
  	  	    			}
  	  	    		else//9.99~1.00
  	  	    			{
  	  	    			audio_data(y_money_m%0x10);
  	  	    			audio(0x31);
                                        IWDG_ReloadCounter();	//ι��
  	  	    			audio_data(y_money_l/0x10);
                                        
  	  	    			audio_data(y_money_l%0x10);
                                        IWDG_ReloadCounter();	//ι��
  	  	    			audio(0x43);
  	  	    			
  	  	    			}
  	  	    	}
		}
	else
		{					
					audio_data(y_money_h%0x10);
                                        IWDG_ReloadCounter();	//ι��
					audio(0x41);
					if(y_money_m==0)
						{
						audio(0x43);
                                                IWDG_ReloadCounter();	//ι��
						audio_data(y_money_l/0x10);
						if(y_money_l/0x10!=0)
							{
							audio(0x40);
							}
						audio_data(y_money_l%0x10);
                                                IWDG_ReloadCounter();	//ι��
						audio(0x45);						
						}
					else
						{audio_data(y_money_m/0x10);
                                                IWDG_ReloadCounter();	//ι��
						if(y_money_m/0x10!=0)
							{
							audio(0x40);
							if(y_money_m%0x10!=0)
								{
                                                                  IWDG_ReloadCounter();	//ι��
								audio_data(y_money_m%0x10);		
								}
							
							}
						else
							{
							if(y_money_m%0x10!=0)
								{
								audio_data(y_money_m%0x10);		
								}
							}
						audio(0x43);
                                                IWDG_ReloadCounter();	//ι��
	  	  	    			audio_data(y_money_l/0x10);
	  	  	    			if(y_money_l/0x10!=0)
	  	  	    				{
	  	  	    				audio(0x40);
	  	  	    				}
	  	  	    			if(y_money_l%0x10!=0)
                                                {
                                                  audio_data(y_money_l%0x10);
	  	  	    			}
                                                IWDG_ReloadCounter();	//ι��
                                                audio(0x45);
			
						
						}


		}

}

/*
   ͣ��ʱ��:park_hour��park_min��ͣ��Сʱ���ͷ�����(10����)
   
*/
void time_audio()
{
audio(0x0c);
delay(3000000);

if(park_hour/10!=0)
  	{	audio_data(park_hour/10);
		audio(0x1f);
		
		if(park_hour%10!=0)
			{	
			audio_data(park_hour%10);			
			}
             audio(0x08);
   		
   	
	}
else
	{audio_data(park_hour%10);
        audio(0x08);
	}
delay(3000000);
if(park_min/10!=0)
		{
		audio_data(park_min/10);
	  	audio(0x1f);
	  	if(park_min%10!=0)
	  		{audio_data(park_min%10);
	  		}
		
		}
else
		{
		
		audio_data(park_min%10);
		}
	audio(0x04);
		
}




