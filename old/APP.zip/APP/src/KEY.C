#include "stm32f10x_conf.h"
#include "stm32f10x_it.h"
#include "hal.h"
#include "LCD_12864.h"
#include "KEY.h"
#include "Do_Task.h"
//#include "audio.h"
#define P_244_ON	        GPIO_ResetBits(GPIOB, GPIO_Pin_2)
#define P_244_OFF	        GPIO_SetBits(GPIOB, GPIO_Pin_2)
u8 key_flag,key_flagbk,wake_flag,voltage_flag;
u8 quit_key_flag;
u8 send_flag,open_gprs_flag;

void Delay(u16 speed);
void JM_keypin_init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    EXTI_InitTypeDef EXTI_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	TMP.BaseFlag = JD_ZJ_MB_SYS();//1-������� 0-�м�(���)
    
	if(TMP.BaseFlag==0)//�м���� 
	    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_7 |GPIO_Pin_8 |GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	else
	    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_8 |GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
#ifdef JY_KEY
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
#else
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;		//��������  2015-01-22
#endif

    GPIO_Init(GPIOC, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;		//��������
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource5);  //32_PULES
	if(TMP.BaseFlag==0)//�м���� 
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource7);  //2.4G int
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource8);  //key8
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource13); //Key13
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource14); //key14
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource15); //Key15

//#define JM4G_UPDATE
#ifdef JY_KEY
    EXTI_InitStructure.EXTI_Line = EXTI_Line5 | EXTI_Line8 | EXTI_Line13 | EXTI_Line14 | EXTI_Line15;        
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
#else
    EXTI_InitStructure.EXTI_Line = EXTI_Line5;        
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
	if(TMP.BaseFlag==0)//�м���� 
		EXTI_InitStructure.EXTI_Line =  EXTI_Line7|EXTI_Line8 | EXTI_Line13 | EXTI_Line14 | EXTI_Line15; 	   
	else
		EXTI_InitStructure.EXTI_Line =EXTI_Line8 | EXTI_Line13 | EXTI_Line14 | EXTI_Line15;        
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;//2015-01-22
#endif    
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    
}



/****************************�жϰ���ɨ�躯��****************************************/ 
unsigned char  key_scan_1(void)
{
  u32 key_num=0;
  u8  key_num1=0;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_AFIO, DISABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
  key1_0;key2_0;key3_0;key4_0;
  Delay(10);
  if((GPIO_ReadInputData(GPIOD)&0xf000)!=0xf000)
      {
        Delay(10);
        if((GPIO_ReadInputData(GPIOD)&0xf000)!=0xf000)
           {
             
              key1_0;key2_1;key3_1;key4_1;
              Delay(10);
              key_num=GPIO_ReadInputData(GPIOD)&0xf000;
              if(key_num!=0xf000)
              {
                  switch(key_flag)
                    {
                      case 1:key_num1=11;break;//f
                      case 2:key_num1=15;break;//confirm
                      case 3:key_num1=10;break;//p
                      case 4:key_num1=16;break;//0
                      default:break;
                    }
              }
              
              key1_1;key2_0;key3_1;key4_1;
              Delay(10);
              key_num=GPIO_ReadInputData(GPIOD)&0xf000;
              if(key_num!=0xf000)
              {  
                  switch(key_flag)
                    {
                      case 1:key_num1=9;break;//9
                      case 2:key_num1=14;break;//dowwm
                      case 3:key_num1=7;break;//7
                      case 4:key_num1=8;break;//8
                      default:break;
                    }
              }
              
              key1_1;key2_1;key3_0;key4_1;
              Delay(10);
              key_num=GPIO_ReadInputData(GPIOD)&0xf000;
              if(key_num!=0xf000)
              {  
                  switch(key_flag)
                    {
                      case 1:key_num1=6;break;//6
                      case 2:key_num1=13;break;//up
                      case 3:key_num1=4;break;//4/
                      case 4:key_num1=5;break;//5
                      default:break;
                    }
              }
              
              key1_1;key2_1;key3_1;key4_0;
              Delay(10);
              key_num=GPIO_ReadInputData(GPIOD)&0xf000;
              if(key_num!=0xf000)
                {
                  switch(key_flag)
                    {
                      case 1:key_num1=3;break;//3/
                      case 2:key_num1=12;break;//cancel
                      case 3:key_num1=1;break;//1/
                      case 4:key_num1=2;break;//2/
                      default:break;
                    }
                }
              
           }
        
     }
        if(key_num1!=0)
        {
	        //goto_xy(0x70,0x00); 	
	        //print_num16_16(key_num1/10%10);
	        //print_num16_16(key_num1%10);
        //return key_num1;
        }
        else 
          key_num1=0;
        key1_0;key2_0;key3_0;key4_0;
        Delay(10);
        Delay(2000);        
        key_flag=0;
        EXTI_ClearITPendingBit(EXTI_Line12);
        EXTI_ClearITPendingBit(EXTI_Line13);
        EXTI_ClearITPendingBit(EXTI_Line14);
        EXTI_ClearITPendingBit(EXTI_Line15);
        Delay(50);
        NVIC_InitTypeDef NVIC_InitStructure;
        NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;   
        NVIC_Init(&NVIC_InitStructure);
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_AFIO, ENABLE);

		delay(2000000);
        return key_num1;
}
/********************************************************************/ 
/********************************************************************/
/****************************�жϰ���ɨ�躯��****************************************/ 
unsigned char  key_scan_2(void)
{
  u32 key_num=0;
  u8  key_num1=0;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_AFIO, DISABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE); 
  if((GPIO_ReadInputData(GPIOC)&0xe100)!=0xe100)
      {
             Delay(1);              
             key_num=GPIO_ReadInputData(GPIOC)&0xe100;
             if(key_num!=0xe100)
             {
                if((key_num&0x0100)!=0x0100)
                    key_num&=0xe000;    // PD6 == 0  Q6 == 0
                else
                {
                    key_num&=0xe000;    // PD6 == 1  Q6 == 1
                    key_num+=0x1000;
                }
                  switch(key_num)
                    {
                      case 0x0000:key_num1=1;break;//f  key1
                      case 0x1000:key_num1=2;break;//confirm
                      case 0x2000:key_num1=3;break;//p
                      case 0x3000:key_num1=4;break;//0
                      case 0x4000:key_num1=5;break;//f
                      case 0x5000:key_num1=6;break;//confirm
                      case 0x6000:key_num1=7;break;//p
                      case 0x7000:key_num1=8;break;//0 
                      
                      case 0x9000:key_num1=9;break;//0  
                      case 0xA000:key_num1=0x0A;break;//0                       
                      default:break;
                    }
               
             }              
         //  }
        
     }
        if(key_num1!=0)
        {

        }
        else 
          key_num1=0;
        Delay(5);        
        key_flag=0;
        EXTI_ClearITPendingBit(EXTI_Line5);
        EXTI_ClearITPendingBit(EXTI_Line6);
        EXTI_ClearITPendingBit(EXTI_Line7);
 //       Delay(50);
  //      Delay(10); 
        Delay(5);         
        NVIC_InitTypeDef NVIC_InitStructure;        
        NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;   
        NVIC_Init(&NVIC_InitStructure);
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_AFIO, ENABLE);
//	delay(2000000);
        return key_num1;
}
/********************************************************************/ 
/********************************************************************/
/********************************************************************/ 
/********************************************************************/
/****************************�жϰ���ɨ�躯��****************************************/ 
unsigned char  key_scan_3(void)
{
  u32 key_num=0;
  u8  key_num1=0;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_AFIO, DISABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
  //HC244CS_1;
  Delay(10);
  if((GPIO_ReadInputData(GPIOD)&0xf000)!=0xf000){
        Delay(10000);
        if((GPIO_ReadInputData(GPIOD)&0xf000)!=0xf000){
              Delay(10000);
              key_num=GPIO_ReadInputData(GPIOD)&0xf000;
              if(key_num!=0xf000){
                  switch(key_num){
                      case 0x0000:key_num1=1;break;//f
                      case 0x1000:key_num1=2;break;//confirm
                      case 0x2000:key_num1=3;break;//p
                      case 0x3000:key_num1=4;break;//0
                      case 0x4000:key_num1=5;break;//f
                      case 0x5000:key_num1=6;break;//confirm
                      case 0x6000:key_num1=7;break;//p
                      case 0x7000:key_num1=8;break;//0                      
                      default:break;
                    
                  }              
              }                        
        }           
  }
  if(key_num1!=0){
        
  }
        else 
        key_num1=0;
 //       Delay(10);
        Delay(2000);        
        key_flag=0;
        EXTI_ClearITPendingBit(EXTI_Line5);
        EXTI_ClearITPendingBit(EXTI_Line6);
        EXTI_ClearITPendingBit(EXTI_Line7);
        Delay(50);
        NVIC_InitTypeDef NVIC_InitStructure;        
        NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;   
        NVIC_Init(&NVIC_InitStructure);
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_AFIO, ENABLE);
//	delay(2000000);
        return key_num1;
}

unsigned char  key_scan(void)
{
	u8  key;

	key = key_scan_1();
	
	while(key_scan_1() );
	
	return key;
	
}
unsigned char  key_scan1(void)
{
	u8  key;

	key = key_scan_2();
	
	while(key_scan_2() );
	
	return key;
	
}
unsigned char  key_scan2(void)
{
	u8  key;

	key = key_scan_3();
	
	while(key_scan_3() );
	
	return key;
	
}

/********************************************************************/ 
