#include "Do_Task.h"
#include "Smart_card.h"
#include "hardware_test.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"


//#define Test_RealCPC //�����ֳ�+���ۿ��쳣���� 2015-10-14andyluo
#define testfeelist //����Ƿ�Ѳ���� 2015-10-10andyluo


//#define DEBUG

#define QUIT_TIME   0 //��ʾ��ʱ�� ���� ���˶�ú�����
#define WAITE_TIME  3

#define RECORD_NULL 0
#define MIFARE_FLAG 1
#define LNT_FLAG 2

#define ADD 1 //����
#define DEC 2 //����


uchar ERRCODE;
uchar Public_BCC;
uchar error_value_0;
uchar error_value_1;
uchar error_value_2;
uchar balckList_flag; //��������־
uchar whiteList_flag; //������������ ��־
uchar error_flag;
uchar flag_NO;                         
uchar flag_Momery;                                 
uchar flag_free;
uchar read_mech_ID_flag;
uchar QuitTime;
uchar QuitFlag;
uchar QuitKey;                 
uchar month_card_free_count;                 
uchar month_card_max_count;
unsigned long F_count_32,F_count_32B;   
unsigned long F_count_112,F_count_112B; 
unsigned long L_count_32,L_count_32B;
unsigned long L_count_112,L_count_112B;
int test_momery;
int add_momery;
	     
uchar carSNR[4],bkno[4],HR_TIME[5],err_1[5],addmny[5],vetime;//HR_TIME д��ʱ��δ�������ֻ���ͬ����ݴ�
uchar select_buffer[4];
uchar CPU_card_number[4];
uchar Mifare_card_number[4];
uchar Frist_buffer[4];
uchar Last_buffer[4];
uchar TAC[4];
s32 bukanmny[5],bushimny[5];

Consumption_Record Consum_R; //���Ͽ� ���Ѽ�¼
MonthCard_Record MCR;//�¿����� ��¼
Rate_reference_ST RR_ST1;

extern uchar HZ[];  
SYSTEM_MS SYS_MS;
temp TMP;//��ʱ��ʾ�ṹ�� 2015-07-28  andyluo 

void disp_NoFeeIMG(u16 feemnyt,u16 feetimet,u16 feelockt);
void CPCCARD_PRO(u8 space,u8 spacestate,CardInfo *YWT);
void BIKECARD_PRO(u8 space,u8 spacestate,CardInfo *YWT);
extern u8 CpuCard_Pay(u8 space,u8 IQFlag,CardInfo *WZT);
unsigned char rev_ack_new(unsigned char buff[]);
uchar card_station_check(uchar car_car);

//������λ�ĳ���
void GenerateSystemReset(void) 
{ 
  __ASM("MOV R0, #1"); 
  __ASM("MSR FAULTMASK, R0"); 
  SCB->AIRCR = 0x05FA0004; 
  for(;;); 
} 

void disp_notsuse_card(void)
{
	Smart_Power_OFF;
	OPEN_EXTI9_5_IRQ(); 	   
	OPEN_EXTI15_10_IRQ();						
	Buzz_0;
	delay(KEYTIMEOUT_1S/10);
	Buzz_1; 			
	no_use_card(0);
	delay(KEYTIMEOUT_1S * 3);
}

//����¼��ȡ----
u8 CardRecrodRead(u8 rdadd,u8 rddata[16*10])
{
u8 RecoverKey[6] = {0x07,0x55,0x83,0x26,0x62,0x36};
u8 timect=3,flag,i;

	while(timect--)
		{
//		flag = testkey_comd(0x0E,0x0b,RecoverKey);
		flag = testkey_comd(0x05,0x0a,RecoverKey);
		if(flag != OK)continue;		
//		flag = read_comd(RDST_ADDR,rddata);
//		if(flag != OK)continue;
		break;
		}		
	for(i=0;i<3;i++)
		flag = read_comd(RDST_ADDR+i,rddata+16*i);
	
	flag = testkey_comd(0x06,0x0a,RecoverKey);
	for(i=4;i<7;i++)
		flag = read_comd(RDST_ADDR+i,rddata+16*(i-1));

	
	flag = testkey_comd(0x07,0x0a,RecoverKey);
	for(i=8;i<11;i++)
		flag = read_comd(RDST_ADDR+i,rddata+16*(i-2));
	
	flag = testkey_comd(0x08,0x0a,RecoverKey);
	i=12;
	flag = read_comd(RDST_ADDR+i,rddata+16*(i-3));
		
 	return flag;	
}


//����¼�洢----����-�洢ʧ�� 1-�洢����
u8 CardRecrodSave(u8 rdadd,u8 rddata[16])
{
u8 RecoverKey[6] = {0x07,0x55,0x83,0x26,0x62,0x36};
u8 timect=3,flag;//,cardrd[160];

	while(timect--)
		{
//		flag = testkey_comd(0x0E,0x0b,RecoverKey);
		flag = testkey_comd(rdadd/4,0x0a,RecoverKey);
		if(flag != OK)continue;		
		flag = write_comd(rdadd,rddata);
		if(flag != OK)continue;
		break;
		}	
//	CardRecrodRead(RDST_ADDR,cardrd);	
 	return flag;	
}
//������ʶ�� 2015-12-03andyluo
//CardType_OWLMF1RD-�����Ͽ� 
//CardType_WLMF1RD--�����¿�
//CardType_ZGMF1RD--����¿� //TMP.cardplace 
u8 CardAddArea(void)
{
u8 RecoverKey[6] = {0x07,0x55,0x83,0x26,0x62,0x36};
//u8 RecoverKeyEmt[6] = {0xff,0xff,0xff,0xff,0xff,0xff};
u8 cpBUF[16],timect=3,retv,flag;

//	if(timect)
//		return 0;
    retv = CardType_OWLMF1RD;//Ĭ��Ϊ�����Ͽ� 
	while(timect--)
		{
//		flag = testkey_comd(0x0E,0x0b,RecoverKey);
		flag = testkey_comd(0x0E,0x0a,RecoverKey);
		if(flag != OK)continue;
		
		flag = read_comd(B0S15_ADDR,cpBUF);
		if(flag != OK)continue;
		if((cpBUF[0]+cpBUF[3]==0xff)&&
			(cpBUF[1]+cpBUF[4]==0xff)&&
			(cpBUF[2]+cpBUF[5]==0xff))//�·���
			{//325000--���ݿ� 2016-01-15CardType_WZMF1RD
			if((cpBUF[0]==0x04)&&(cpBUF[1]==0x01)&&(cpBUF[2]==0x15))
				retv = CardType_INMF1RD;//Ϊӡ���¿� 040115
			else if((cpBUF[0]==0x32)&&(cpBUF[1]==0x50)&&(cpBUF[2]==0x00))
				retv = CardType_WZMF1RD;//Ϊ�����¿� 325000
			else if((cpBUF[0]==0x31)&&(cpBUF[1]==0x75)&&(cpBUF[2]==0x00))
				retv = CardType_WLMF1RD;//Ϊ�����¿� 317500
			else if((cpBUF[0]==0x31)&&(cpBUF[1]==0x75)&&(cpBUF[2]==0x23))
				retv = CardType_ZGMF1RD;//Ϊ����¿� 317523
			else ;//�����Ͽ�
			}
		break;
		}	
	if(timect==0xff)
		{		
		CardInfo YWCardInfotmpp;//��������Ϣ 2015-07-25
//		Smart_Power_OFF;
//		delay(1000);
//		Smart_Power_ON;		
		flag = inquire_card(&YWCardInfotmpp);

		}
 	return retv;	
}

//�����ж� 
u8 RecoverArea(void)
{
u8 RecoverKey[6] = {0x07,0x55,0x83,0x26,0x62,0x36};
u8 RecoverKeyEmt[6] = {0xff,0xff,0xff,0xff,0xff,0xff};
u8 B0S14_BUF[16],timect=3,retv;

	if(timect)
		return 0;

	while(timect--)
		{
		retv = 1;
		if(QuitTime>3)
			error_value_0 = testkey_comd(0x0D,0x0a,RecoverKeyEmt);
		else
			error_value_0 = testkey_comd(0x0D,0x0a,RecoverKey);

		if(error_value_0 != OK)
			continue;
		retv = 2;
		error_value_0 = read_comd(B0S14_ADDR,B0S14_BUF);
		if(error_value_0 != OK)
			continue;
		retv = 0;
		if((B0S14_BUF[2]==0xAA)&&(B0S14_BUF[3]==0xAA))
			retv = 3;
		break;
		}
	if(retv == 1)
		{
		//diplay_error(errcord_1);		
		if(QuitTime == 4)
			{
			no_use_card(5);
			delay(KEYTIMEOUT_1S * 2);	
			}
		//retv = 4;
		}
	else if(retv == 3)
		{
		diplay_error(errcord_2);
		delay(KEYTIMEOUT_1S * 2);
		}
	return retv;	
}

//2015-10-09 andyluo  1-�е��� 0-�޵���
u8 park_ledstate(void)
{
	u8 car_station,i;
    carStation_reference_of_used CS_RF_US;
	for(i=1;i<=4;i++)
		{
	    read_car_reference_of_use_info(&CS_RF_US,i);//����λ״̬��Ϣ  
	    car_station = CS_RF_US.car_stop_way[0];//��λ��ͣ��״̬ 0x66 Ϊ�г�     0x00 Ϊû�г�
		if(car_station)break;
		}
	return car_station;
}

//2015-07-27 andyluo
//��ʾ��ѯ��Ϣ
void disp_IQIMG(CardInfo *IQIMG)
{
    uchar momery_thousand,momery_hundred,momery_ten;
    uchar momery_ge,momery_horn,momery_cents;
    uchar station,i,buffer[8];
	s32 equ;    
    u16 left_value,right_value;
	u32 mnynew = 0,pkmoney,timeOut;

    Buzz_0;
    delay(KEYTIMEOUT_1S/10);
    Buzz_1;              
	OPEN_EXTI9_5_IRQ(); 	   
	OPEN_EXTI15_10_IRQ(); 
//�������ж�˳�� ����--����--ȫ��		
	if(IQIMG->CardType ==2)//CPC
		{
		equ = SelectList_SRAM(IQIMG->YYXLH,ListType_CPCDEL,buffer);
		if(equ<0)
			{//���ڼ�����
			equ = SelectList_SRAM(IQIMG->YYXLH,ListType_CPCADD,buffer);
			if(equ<0)
				{//����������
				equ = SelectList_SRAM(IQIMG->YYXLH,ListType_CPCALL,buffer);
				}
			}
		else
			equ = -1;//����
		}
	else if(IQIMG->CardType ==1)//BIKE
		{
		equ = SelectList_SRAM(IQIMG->YYXLH+4,ListType_BIKEDEL,buffer);
		if(equ<0)
			{//���ڼ�����
			equ = SelectList_SRAM(IQIMG->YYXLH+4,ListType_BIKEADD,buffer);
			if(equ<0)
				{//����������
				equ = SelectList_SRAM(IQIMG->YYXLH+4,ListType_BIKEALL,buffer);
				}			
			}
		else
			equ = -1;//������
		}
	
    lcd_clear();    
	zimo =1;
	if((IQIMG->HMDBS && (IQIMG->CardType ==2))||(equ>=0))
		{
		if(equ<0)
			LCD_display_symbol(1,6,8,1);//'*'��ʾֻ�Ǳ��غڿ� δ�����	2015-08-28	
		dispaly(1,4,(HZ + hei));
		dispaly(1,5,(HZ + ming));
		dispaly(1,6,(HZ + dan));
		dispaly(1,7,(HZ + ka));		
		}
	else if(IQIMG->YWParkInfo.ParkFlag && 
		(IQIMG->YWParkInfo.CardType==0x60)&&
		(IQIMG->YWParkInfo.UpdateFlag==0x88))
		{
		dispaly(1,4,(HZ + bo));
		dispaly(1,5,(HZ + che));
		dispaly(1,6,(HZ + zhong));	

		if(IQIMG->CardType ==2);
		
		else
			{
			zimo =0;
			dispaly(3,2,(HZ + biao));
			dispaly(3,3,(HZ + hao));
			i =0;			
			LCD_display_symbol(3,7,IQIMG->YWParkInfo.ParkMBNO[i+1] / 0x10,0);
			LCD_display_symbol(3,8,IQIMG->YWParkInfo.ParkMBNO[i+1] % 0x10,0); 
			LCD_display_symbol(3,9,IQIMG->YWParkInfo.ParkMBNO[i+2] / 0x10,0);
			LCD_display_symbol(3,10,IQIMG->YWParkInfo.ParkMBNO[i+2] % 0x10,0); 
			LCD_display_symbol(3,11,IQIMG->YWParkInfo.ParkMBNO[i+3] / 0x10,0);
			LCD_display_symbol(3,12,IQIMG->YWParkInfo.ParkMBNO[i+3] % 0x10,0); 
			if(IQIMG->YWParkInfo.Res[6]==0x02)
				dispaly(3,8,(HZ + zuo_1));
			else if(IQIMG->YWParkInfo.Res[6]==0x03)
				dispaly(3,8,(HZ + you_1));
			}
			
		}
	else
		{
		pkmoney = hcl(IQIMG->YWParkInfo.FEEMNY,3);
		if((pkmoney>0)&& 
		(IQIMG->YWParkInfo.CardType==0x60)&&
		(IQIMG->YWParkInfo.UpdateFlag==0x88))			
			{
			mnynew = pkmoney;
			left_value = mnynew/100;
			right_value = mnynew%100;
			momery_thousand = left_value/1000;
			momery_hundred = (left_value%1000)/100;
			momery_ten = (left_value/10)%10;
			momery_ge = left_value%10;
			momery_horn = right_value/10;
			momery_cents = right_value%10;
			dispaly(1,1,(HZ + qian_1));
			dispaly(1,2,(HZ + fei));
			LCD_display_symbol(1,5,1,1);
			station = 6;			
			if(momery_thousand> 0)
				{
				LCD_display_symbol(1,station++,momery_thousand,0);
				LCD_display_symbol(1,station++,momery_hundred,0);
				LCD_display_symbol(1,station++,momery_ten,0);
				}
			else if(momery_hundred > 0)
				{
				LCD_display_symbol(1,station++,momery_hundred,0);		
				LCD_display_symbol(1,station++,momery_ten,0);
				}
			else if(momery_ten > 0)
				LCD_display_symbol(1,station++,momery_ten,0);	
			LCD_display_symbol(1,station++,momery_ge,0);	 
			LCD_display_symbol(1,station++,5,1); // .
			LCD_display_symbol(1,station++,momery_horn,0);
			LCD_display_symbol(1,station++,momery_cents,0);
			if(station%2)
				dispaly(1,station/2+2,(HZ + yuan));
			else
				dispaly(1,station/2+1,(HZ + yuan)); 
			}
		else
			{
			dispaly(1,4,(HZ + zheng));
			dispaly(1,5,(HZ + chang));
			}
		}
	zimo =0;	
	
//    dispaly(2,1,(HZ + ka));
//    dispaly(2,2,(HZ + hao));
//    LCD_display_symbol(2,5,1,1);
//	for(i=0;i<8;i++)
//		LCD_display_no(2,i+1,BCDtoHex(IQIMG->YYXLH[i]));
	mnynew = 0;
	for(i=0;i<4;i++)
		mnynew += (IQIMG->Balance[i]<<(3-i)*8);
    
    left_value = mnynew/100;
    right_value = mnynew%100;
    momery_thousand = left_value/1000;
    momery_hundred = (left_value%1000)/100;
    momery_ten = (left_value/10)%10;
    momery_ge = left_value%10;
    momery_horn = right_value/10;
    momery_cents = right_value%10;

	dispaly(2,1,(HZ + ka));
	dispaly(2,2,(HZ + hao));
	LCD_display_symbol(2,5,1,1);
	if(IQIMG->CardType ==2)
		{
		LCD_display_symbol(2,6,8,1);
		for(i=0;i<5;i++)
			LCD_display_no(2,i+4,BCDtoHex(IQIMG->YYXLH[i+3]));
		}
	else
		{
		i = BCDtoHex(IQIMG->YYXLH[4])&0x0f;
		LCD_display_symbol(2,8,i,0);
		for(i=2;i<5;i++)
			LCD_display_no(2,i+3,BCDtoHex(IQIMG->YYXLH[i+3]));
		}	


	if(IQIMG->CardType ==2)
		{
	    dispaly(3,1,(HZ + yu));
	    dispaly(3,2,(HZ + e));
	    LCD_display_symbol(3,5,1,1);
		station = 6;
		
	    if(momery_thousand> 0)
			{
			LCD_display_symbol(3,station++,momery_thousand,0);
			LCD_display_symbol(3,station++,momery_hundred,0);
			LCD_display_symbol(3,station++,momery_ten,0);
	    	}
		else if(momery_hundred > 0)
			{
			LCD_display_symbol(3,station++,momery_hundred,0);		
			LCD_display_symbol(3,station++,momery_ten,0);
			}
		else if(momery_ten > 0)
			LCD_display_symbol(3,station++,momery_ten,0);	
	    LCD_display_symbol(3,station++,momery_ge,0);     
	    LCD_display_symbol(3,station++,5,1); // .
	    LCD_display_symbol(3,station++,momery_horn,0);
	    LCD_display_symbol(3,station++,momery_cents,0);
		if(station%2)
			dispaly(3,station/2+2,(HZ + yuan));
		else
			dispaly(3,station/2+1,(HZ + yuan));	
		}
    
	dispaly(4,1,(HZ + shang));
	dispaly(4,2,(HZ + ci));
	LCD_display_symbol(4,5,1,1);
//	for(i=0;i<4;i++)
//		LCD_display_no(4,3+i,IQIMG->YWParkInfo.ParkDateTime[i]);

	i =0;
	LCD_display_symbol(4,6,IQIMG->YWParkInfo.ParkDateTime[i] / 0x10,0);
	LCD_display_symbol(4,7,IQIMG->YWParkInfo.ParkDateTime[i] % 0x10,0);
	LCD_display_symbol(4,8,6,1);	
	LCD_display_symbol(4,9,IQIMG->YWParkInfo.ParkDateTime[i+1] / 0x10,0);
	LCD_display_symbol(4,10,IQIMG->YWParkInfo.ParkDateTime[i+1] % 0x10,0); 

	LCD_display_symbol(4,12,IQIMG->YWParkInfo.ParkDateTime[i+2] / 0x10,0);
	LCD_display_symbol(4,13,IQIMG->YWParkInfo.ParkDateTime[i+2] % 0x10,0);
	LCD_display_symbol(4,14,1,1);	
	LCD_display_symbol(4,15,IQIMG->YWParkInfo.ParkDateTime[i+3] / 0x10,0);
	LCD_display_symbol(4,16,IQIMG->YWParkInfo.ParkDateTime[i+3] % 0x10,0);	

	equ = -1;
	if(IQIMG->CardType ==2)
		equ = SelectList_SRAM(IQIMG->snr,ListType_CPCFEE,buffer);
	if(equ>=0)//����Ƿ�Ѽ�¼ 2015-08-31
		pkmoney = hcl(buffer+4,2);
	if((equ>=0)&&(IQIMG->YWParkInfo.ParkFlag && 
		(IQIMG->YWParkInfo.CardType==0x60)&&
		(IQIMG->YWParkInfo.UpdateFlag==0x88))) //����Ƿ�Ѽ�¼ 2015-07-14
		{
		//buffer0-3 ����	4-5Ƿ�ѽ��  6-7δ���������1λ��+���ᱶ����3λ��
		u16 feemny,feelock;//,feeorg;//feetime,

		timeOut = 0;
		while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
			{  
			if(key_flag)
				{
				key_flag = 0;
				delay(KEYTIMEOUT_1S * QUIT_TIME);
				break; 
				} 
			timeOut++; 
			}								
		
		feemny = hcl(buffer+4,2);
		//feetime = (buffer[6]&0xf0)>>4;
		feelock = (buffer[6]&0x0f)<<8;
		feelock += buffer[7];
//		disp_NoFeeIMG(feemny,feetime,feelock);
		disp_NoFeeIMG(feemny,1,feelock);
		timeOut = 0;
		while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
			{  
			if(key_flag)
				{
				key_flag = 0;
				delay(KEYTIMEOUT_1S * QUIT_TIME);
				break; 
				} 
			timeOut++; 
			}								
		}

}
//��ʾMF1Ƿ����Ϣ 2015-07-28
void disp_NoFeeIMG(u16 feemnyt,u16 feetimet,u16 feelockt)
{
    uchar momery_thousand,momery_hundred,momery_ten;
    uchar momery_ge,momery_horn,momery_cents;
    uchar station;
    
    u16 left_value,right_value;
	u32 mnynew = 0;

    lcd_clear();
	mnynew = feemnyt;
    
    left_value = mnynew/100;
    right_value = mnynew%100;
    momery_thousand = left_value/1000;
    momery_hundred = (left_value%1000)/100;
    momery_ten = (left_value/10)%10;
    momery_ge = left_value%10;
    momery_horn = right_value/10;
    momery_cents = right_value%10;
	if(feetimet==0)
		{
		dispaly(1,2,(HZ + wu_2));
		dispaly(1,3,(HZ + qian_1));
		dispaly(1,4,(HZ + fei));
		return;
		}
	dispaly(1,1,(HZ + suo));
	LCD_display_symbol(1,3,1,1);
	LCD_display_no(1,3,feetimet);	
	dispaly(1,4,(HZ + ci));	
	
//	dispaly(2,1,(HZ + suo));
//	LCD_display_symbol(2,3,1,1);
//	LCD_display_no(2,3,feelockt>>8);
//	LCD_display_no(2,4,feelockt);
//	dispaly(2,5,(HZ + shu));		
		
	dispaly(3,1,(HZ + qian_1));
	dispaly(3,2,(HZ + fei));	
	LCD_display_symbol(3,5,1,1);
	station = 6;	
    if(momery_thousand> 0)
		{
		LCD_display_symbol(3,station++,momery_thousand,0);
		LCD_display_symbol(3,station++,momery_hundred,0);
		LCD_display_symbol(3,station++,momery_ten,0);
    	}
	else if(momery_hundred > 0)
		{
		LCD_display_symbol(3,station++,momery_hundred,0);		
		LCD_display_symbol(3,station++,momery_ten,0);
		}
	else if(momery_ten > 0)
		LCD_display_symbol(3,station++,momery_ten,0);	
    LCD_display_symbol(3,station++,momery_ge,0);     
    LCD_display_symbol(3,station++,5,1); // .
    LCD_display_symbol(3,station++,momery_horn,0);
    LCD_display_symbol(3,station++,momery_cents,0);
	if(station%2)
		dispaly(3,station/2+2,(HZ + yuan));
	else
		dispaly(3,station/2+1,(HZ + yuan));		
}

//�����Խ�����ʾ2015-08-12
void disp_cardfee(u8 flag)
{
#ifdef IN_MBSYSTEM //����6  �����ӵ���ʾ 2016-02-22
	if(flag==0x99)//��ʾ��������ͽ��
		{
		uchar momery_thousand,momery_hundred,momery_ten;
		uchar momery_ge,momery_horn,momery_cents;
		uchar station;
		u16 left_value,right_value; 	
		
		left_value = TMP.feemny/100;
		right_value = TMP.feemny%100;
		momery_thousand = left_value/1000;
		momery_hundred = (left_value%1000)/100;
		momery_ten = (left_value/10)%10;
		momery_ge = left_value%10;
		momery_horn = right_value/10;
		momery_cents = right_value%10;
		//LCD_display_no(4,4,TMP.feetime);	
		LCD_display_symbol(4,3,TMP.feetime,0);
		print_XYstr_16_16(4,4,"ps Rp");
		station = 9;	
		if(momery_thousand> 0)
			{
			LCD_display_symbol(4,station++,momery_thousand,0);
			LCD_display_symbol(4,station++,momery_hundred,0);
			LCD_display_symbol(4,station++,momery_ten,0);
			}
		else if(momery_hundred > 0)
			{
			LCD_display_symbol(4,station++,momery_hundred,0);		
			LCD_display_symbol(4,station++,momery_ten,0);
			}
		else if(momery_ten > 0)
			LCD_display_symbol(4,station++,momery_ten,0);	
		LCD_display_symbol(4,station++,momery_ge,0);	 
		LCD_display_symbol(4,station++,5,1); // .
		LCD_display_symbol(4,station++,momery_horn,0);
		LCD_display_symbol(4,station++,momery_cents,0);
		LCD_display_symbol(4,station++,0,0);
		return;
		}
	Buzz_0;
	delay(KEYTIMEOUT_1S/20);
	Buzz_1;
	lcd_clear();
	switch(flag)
		{//bu kuan qing  
		case 0://��ȴ� 		
//		Connecting
//?
//Request supply 
//funds, wait
			print_XYstr_16_16(1,4,"Connecting");
			print_XYstr_16_16(2,1,"Request supply");
			print_XYstr_16_16(3,1,"funds, wait");			
			break;
		case 1:
//			Connect failed
//			?
//			Pls connect again
			print_XYstr_16_16(1,2,"Connect failed");
			print_XYstr_16_16(2,2,"Pls connect");
			print_XYstr_16_16(3,2,"again");
			break;
		case 2:
//			Connect success
//			No reset records
			print_XYstr_16_16(1,1,"Connect success");
			print_XYstr_16_16(3,1,"No reset records");
			Buzz_0;
			delay(KEYTIMEOUT_1S/20);
			Buzz_1;			
			break;
		case 3:
//			Tap card failed
//			Pls re-tap
			print_XYstr_16_16(1,1,"Tap card failed");
			print_XYstr_16_16(3,1,"Pls re-tap");
			break;
		case 4://
		
			dispaly(1,3,(HZ + xu));
			dispaly(1,4,(HZ + xie));
			dispaly(1,5,(HZ + qian_1));
			dispaly(1,6,(HZ + fei));
			zimo =1;
			LCD_display_symbol(2,5,TMP.feemny/10,0);
			LCD_display_symbol(2,6,TMP.feemny%10,0);
			zimo =0;
			dispaly(2,4,(HZ + yuan));
			print_XYstr_16_16(4,1,"L-CH 	  R-CM");
			break;
		case 5://
			dispaly(1,3,(HZ + xu));
			dispaly(1,4,(HZ + xie));
			dispaly(1,5,(HZ + qian_1));
			dispaly(1,6,(HZ + fei));
			LCD_display_symbol(2,5,TMP.feemny/10,0);
			LCD_display_symbol(2,6,TMP.feemny%10,0);
			dispaly(2,4,(HZ + yuan));
			zimo =1;
			dispaly(4,3,(HZ + qing));
			dispaly(4,4,(HZ + shua));
			dispaly(4,5,(HZ + ka));
			zimo =0;		
			break;			
		}
	return;
#elif defined EN_MBSYSTEM
				
			return;
#else
	if(flag==0x99)//��ʾ��������ͽ��
		{
		uchar momery_thousand,momery_hundred,momery_ten;
		uchar momery_ge,momery_horn,momery_cents;
		uchar station;
		u16 left_value,right_value;		
		
		left_value = TMP.feemny/100;
		right_value = TMP.feemny%100;
		momery_thousand = left_value/1000;
		momery_hundred = (left_value%1000)/100;
		momery_ten = (left_value/10)%10;
		momery_ge = left_value%10;
		momery_horn = right_value/10;
		momery_cents = right_value%10;
		//LCD_display_no(4,4,TMP.feetime);	
		LCD_display_symbol(4,6,TMP.feetime,0);
		dispaly(4,4,(HZ + ci)); 
		station = 9;	
		if(momery_thousand> 0)
			{
			LCD_display_symbol(4,station++,momery_thousand,0);
			LCD_display_symbol(4,station++,momery_hundred,0);
			LCD_display_symbol(4,station++,momery_ten,0);
			}
		else if(momery_hundred > 0)
			{
			LCD_display_symbol(4,station++,momery_hundred,0);		
			LCD_display_symbol(4,station++,momery_ten,0);
			}
		else if(momery_ten > 0)
			LCD_display_symbol(4,station++,momery_ten,0);	
		LCD_display_symbol(4,station++,momery_ge,0);	 
		LCD_display_symbol(4,station++,5,1); // .
		LCD_display_symbol(4,station++,momery_horn,0);
		LCD_display_symbol(4,station++,momery_cents,0);
		dispaly(4,8,(HZ + yuan));
		return;
		}
	Buzz_0;
	delay(KEYTIMEOUT_1S/20);
	Buzz_1;
	lcd_clear();
	switch(flag)
		{//bu kuan qing  
		case 0://��ȴ�			
			dispaly(1,3,(HZ + lian_1));
			dispaly(1,4,(HZ + jie_1));
			dispaly(1,5,(HZ + zhong));
			       				
//			zimo = 1;
//			dispaly(2,2,(HZ + zheng));
//			dispaly(2,3,(HZ + zai));
//			dispaly(2,4,(HZ + qing));
//			dispaly(2,5,(HZ + qiu));	
//			dispaly(2,6,(HZ + bu));
//			dispaly(2,7,(HZ + jiao_1));			
//			zimo = 0;
			dispaly(3,2,(HZ + qing));
			dispaly(3,3,(HZ + qiu));	
			dispaly(3,4,(HZ + bu));
			dispaly(3,5,(HZ + jiao_1));			
			dispaly(3,6,(HZ + qing));
			dispaly(3,7,(HZ + shao));
			dispaly(3,8,(HZ + hou));			
			break;
		case 1:
			dispaly(1,3,(HZ + lian));
			dispaly(1,4,(HZ + jie_1));
			dispaly(1,5,(HZ + shi_3));
			dispaly(1,6,(HZ + bai));
			dispaly(3,3,(HZ + qing));
			dispaly(3,4,(HZ + chong));
			dispaly(3,5,(HZ + lian));	
			
			break;
		case 2:
			dispaly(1,3,(HZ + lian));
			dispaly(1,4,(HZ + jie_1));
			dispaly(1,5,(HZ + cheng));
			dispaly(1,6,(HZ + gong_1));
			
			dispaly(3,3,(HZ + wu_2));
			dispaly(3,4,(HZ + fu));
			dispaly(3,5,(HZ + wei_1));
			dispaly(3,6,(HZ + ji));
			dispaly(3,7,(HZ + lu));	
			Buzz_0;
			delay(KEYTIMEOUT_1S/20);
			Buzz_1;
			
			break;
		case 3:
			dispaly(1,3,(HZ + shua));
			dispaly(1,4,(HZ + ka));
			dispaly(1,5,(HZ + shi_3));
			dispaly(1,6,(HZ + bai));
			dispaly(3,3,(HZ + qing));
			dispaly(3,4,(HZ + chong));
			dispaly(3,5,(HZ + shua));			
			break;
		case 4://
			dispaly(1,3,(HZ + xu));
			dispaly(1,4,(HZ + xie));
			dispaly(1,5,(HZ + qian_1));
			dispaly(1,6,(HZ + fei));
			zimo =1;
			LCD_display_symbol(2,5,TMP.feemny/10,0);
			LCD_display_symbol(2,6,TMP.feemny%10,0);
			zimo =0;
			dispaly(2,4,(HZ + yuan));
			print_XYstr_16_16(4,1,"L-CH       R-CM");
			break;
		case 5://
			dispaly(1,3,(HZ + xu));
			dispaly(1,4,(HZ + xie));
			dispaly(1,5,(HZ + qian_1));
			dispaly(1,6,(HZ + fei));
			LCD_display_symbol(2,5,TMP.feemny/10,0);
			LCD_display_symbol(2,6,TMP.feemny%10,0);
			dispaly(2,4,(HZ + yuan));
			zimo =1;
			dispaly(4,3,(HZ + qing));
			dispaly(4,4,(HZ + shua));
			dispaly(4,5,(HZ + ka));
			zimo =0;		
			break;			
		}
#endif
}

void disp_card_fnstate(u8 fnmode,u8 cardkey[16])
{
u8 stloc;//,i,j;

	lcd_clear();

#ifdef IN_MBSYSTEM //����6  �����ӵ���ʾ 2016-02-22
//Parking card     : kartu parkir
//Assist parking card    : pertolongan kartu parkir
//Management card    : kartu manajemen
//Authorized card    : kartu otorisasi
//Clearing card     : kartu kliring
//Communication card   : kartu komunikasi
//Reset card��     : reset kartu
//Checking card     : kartu cek
//Recovering card    : kartu pemulihan
//Test card      : kartu uji
//Working attendance ( shift) card : kartu petugas
//Unknown card     : kartu tidak dikenal
//Invalid card     : kartu tidak sah
	stloc = 3;
	LCD_display_symbol(stloc,10,6,1); // >
	LCD_display_symbol(stloc,7,fnmode/16,0);
	LCD_display_symbol(stloc,8,fnmode%16,0);
	LCD_display_symbol(stloc,10,7,1); // >
	LCD_display_symbol(stloc,11,7,1); // >
	zimo =1;
	if(TMP.cardplace == CardType_INMF1RD)
		print_XYstr_16_16(stloc,13,"IN");
	else if(TMP.cardplace == CardType_WZMF1RD)
		print_XYstr_16_16(stloc,13,"WZ");
	else if(TMP.cardplace == CardType_ZGMF1RD)
		print_XYstr_16_16(stloc,13,"ZG");
	else if(TMP.cardplace == CardType_OWLMF1RD)
		print_XYstr_16_16(stloc,13,"WLO");
	else
		print_XYstr_16_16(stloc,13,"WLN");
	zimo =0;

	stloc = 2;
	switch(fnmode)
		{
		case HLEPPARK_CARD: 
//			print_XYstr_16_16(stloc,1,"pertolongan kartu parkir");
			print_XYstr_16_16(stloc,1,"pe. kartu parkir");
			delay(KEYTIMEOUT_1S*2);
			break;
		case MIFARAE_PARK_CARD: 
			print_XYstr_16_16(stloc,1,"kartu parkir");
			delay(KEYTIMEOUT_1S*2);
			break;
		case OLDMANAGE_CARD: 
			print_XYstr_16_16(stloc,1,"kartu manajemen");
			delay(KEYTIMEOUT_1S*2);
			break;
		case MANAGE_CARD: 
			print_XYstr_16_16(stloc,1,"Nkartu manajemen");
			delay(KEYTIMEOUT_1S*2);
			break;
		case ENCRYPT_CARD: 
			print_XYstr_16_16(stloc,1,"kartu otorisasi");
			delay(KEYTIMEOUT_1S*2);
			break;
		case CLEAR_CARD: 
			print_XYstr_16_16(stloc,1,"kartu kliring");
			delay(KEYTIMEOUT_1S*2);
			break;
		case PDA_CARD_FHP: 
			print_XYstr_16_16(stloc,1,"kartu komunikasi");
			print_XYstr_16_16(4,6,"flash part");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case PDA_CARD_FHA: 
			print_XYstr_16_16(stloc,1,"kartu komunikasi");
			print_XYstr_16_16(4,6,"flash all");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case PDA_CARD_FMP: 
			print_XYstr_16_16(stloc,1,"kartu komunikasi");
			print_XYstr_16_16(4,6,"fm part");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case PDA_CARD_FMA: 
			print_XYstr_16_16(stloc,1,"kartu komunikasi");
			print_XYstr_16_16(4,6,"fm all");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case NETCTRL_CARD: 
			print_XYstr_16_16(stloc,1,"kartu komunikasi");
			print_XYstr_16_16(4,6,"net");			
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case IAP_CARD: 
			print_XYstr_16_16(stloc,1,"kartu komunikasi");
			print_XYstr_16_16(4,6,"iap");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case IP_ADREES: 
			print_XYstr_16_16(stloc,1,"kartu komunikasi");
			print_XYstr_16_16(4,6,"ip");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case SELECT_CARD: 
			print_XYstr_16_16(stloc,1,"kartu cek");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case TEST_CARD: 
			print_XYstr_16_16(stloc,1,"kartu uji");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case RESET_CARD: 
			print_XYstr_16_16(stloc,1,"kartu pemulihan");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case DECEIVE_CARD: 
			print_XYstr_16_16(stloc,1,"kartu petugas");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		default:
			print_XYstr_16_16(stloc,1,"kartu tidak dikenal");
			delay(KEYTIMEOUT_1S*2); 		
			break;	
		}
#ifdef CardKey_LCD	//600310030501
	//		stloc = 1;
	//		for(i=0,j=4;i<6;i++)
	//			{
	//			LCD_display_symbol(stloc,j++,cardkey[i]/16,0);
	//			LCD_display_symbol(stloc,j++,cardkey[i]%16,0);
	//			}
		stloc = 4;
		for(i=0,j=4;i<6;i++)
			{
			LCD_display_symbol(stloc,j++,system0_number[i]/16,0);
			LCD_display_symbol(stloc,j++,system0_number[i]%16,0);
			}
#endif 
	return;
#elif defined EN_MBSYSTEM
				
	return;
#else
	
#ifdef CardKey_LCD	//600310030501
	stloc = 1;
	for(i=0,j=4;i<6;i++)
		{
		LCD_display_symbol(stloc,j++,cardkey[i]/16,0);
		LCD_display_symbol(stloc,j++,cardkey[i]%16,0);
		}
//	stloc = 4;
//	for(i=0,j=4;i<6;i++)
//		{
//		LCD_display_symbol(stloc,j++,system0_number[i]/16,0);
//		LCD_display_symbol(stloc,j++,system0_number[i]%16,0);
//		}
#endif
	
	stloc = 3;
	LCD_display_symbol(stloc,10,6,1); // >
	LCD_display_symbol(stloc,7,fnmode/16,0);
	LCD_display_symbol(stloc,8,fnmode%16,0);
	LCD_display_symbol(stloc,10,7,1); // >
	LCD_display_symbol(stloc,11,7,1); // >
	zimo =1;
	if(TMP.cardplace == CardType_INMF1RD)
		print_XYstr_16_16(stloc,13,"IN");
	else if(TMP.cardplace == CardType_WZMF1RD)
		print_XYstr_16_16(stloc,13,"WZ");
	else if(TMP.cardplace == CardType_ZGMF1RD)
		print_XYstr_16_16(stloc,13,"ZG");
	else if(TMP.cardplace == CardType_OWLMF1RD)
		print_XYstr_16_16(stloc,13,"WLO");
	else
		print_XYstr_16_16(stloc,13,"WLN");
	zimo =0;

	stloc = 2;
	switch(fnmode)
		{
		case HLEPPARK_CARD: 
			dispaly(stloc,3,(HZ + dai));
			dispaly(stloc,4,(HZ + bo));
			dispaly(stloc,5,(HZ + ka));
			delay(KEYTIMEOUT_1S*2);
			break;
		case MIFARAE_PARK_CARD: 
			dispaly(stloc,3,(HZ + bo));
			dispaly(stloc,4,(HZ + che));
			dispaly(stloc,5,(HZ + ka));
			delay(KEYTIMEOUT_1S*2);
			break;
		case OLDMANAGE_CARD: 
			dispaly(stloc,3,(HZ + guan));
			dispaly(stloc,4,(HZ + li));
			dispaly(stloc,5,(HZ + ka));
			delay(KEYTIMEOUT_1S*2);
			break;
		case MANAGE_CARD: 
			dispaly(stloc,2,(HZ + xin));
			dispaly(stloc,3,(HZ + guan));
			dispaly(stloc,4,(HZ + li));
			dispaly(stloc,5,(HZ + ka));
			delay(KEYTIMEOUT_1S*2);
			break;
		case ENCRYPT_CARD: 
			dispaly(stloc,3,(HZ + shou_2));
			dispaly(stloc,4,(HZ + quan));
			dispaly(stloc,5,(HZ + ka));
			delay(KEYTIMEOUT_1S*2);
			break;
		case CLEAR_CARD: 
			dispaly(stloc,3,(HZ + qing_1));
			dispaly(stloc,4,(HZ + chu_2));
			dispaly(stloc,5,(HZ + ka));
			delay(KEYTIMEOUT_1S*2);
			break;
		case PDA_CARD_FHP: 
			dispaly(stloc,3,(HZ + tong_1));
			dispaly(stloc,4,(HZ + xin_1));
			dispaly(stloc,5,(HZ + ka));
			print_XYstr_16_16(4,6,"flash part");
			delay(KEYTIMEOUT_1S*2);			
			break;
		case PDA_CARD_FHA: 
			dispaly(stloc,3,(HZ + tong_1));
			dispaly(stloc,4,(HZ + xin_1));
			dispaly(stloc,5,(HZ + ka));
			print_XYstr_16_16(4,6,"flash all");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case PDA_CARD_FMP: 
			dispaly(stloc,3,(HZ + tong_1));
			dispaly(stloc,4,(HZ + xin_1));
			dispaly(stloc,5,(HZ + ka));
			print_XYstr_16_16(4,6,"fm part");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case PDA_CARD_FMA: 
			dispaly(stloc,3,(HZ + tong_1));
			dispaly(stloc,4,(HZ + xin_1));
			dispaly(stloc,5,(HZ + ka));
			print_XYstr_16_16(4,6,"fm all");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case NETCTRL_CARD: 
			dispaly(stloc,3,(HZ + she));
			dispaly(stloc,4,(HZ + zhi));
			dispaly(stloc,5,(HZ + ka));
			print_XYstr_16_16(4,6,"net");			
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case IAP_CARD: 
			dispaly(stloc,3,(HZ + she));
			dispaly(stloc,4,(HZ + zhi));
			dispaly(stloc,5,(HZ + ka));
			print_XYstr_16_16(4,6,"iap");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case IP_ADREES: 
			dispaly(stloc,3,(HZ + she));
			dispaly(stloc,4,(HZ + zhi));
			dispaly(stloc,5,(HZ + ka));
			print_XYstr_16_16(4,6,"ip");
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case SELECT_CARD: 
			dispaly(stloc,3,(HZ + cha));
			dispaly(stloc,4,(HZ + xun));
			dispaly(stloc,5,(HZ + ka));
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case TEST_CARD: 
			dispaly(stloc,3,(HZ + ce));
			dispaly(stloc,4,(HZ + shi));
			dispaly(stloc,5,(HZ + ka));
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case RESET_CARD: 
			dispaly(stloc,3,(HZ + fu));
			dispaly(stloc,4,(HZ + wei_1));
			dispaly(stloc,5,(HZ + ka));
			delay(KEYTIMEOUT_1S*2); 		
			break;
		case DECEIVE_CARD: 
			dispaly(stloc,3,(HZ + kao));
			dispaly(stloc,4,(HZ + qin));
			dispaly(stloc,5,(HZ + ka));
			delay(KEYTIMEOUT_1S*2); 		
			break;
		default:
			dispaly(stloc,3,(HZ + wei));
			dispaly(stloc,4,(HZ + zhi_1));
			dispaly(stloc,5,(HZ + ka));
			delay(KEYTIMEOUT_1S*2); 		
			break;	
		}
#ifdef CardKey_LCD	//600310030501
//		stloc = 1;
//		for(i=0,j=4;i<6;i++)
//			{
//			LCD_display_symbol(stloc,j++,cardkey[i]/16,0);
//			LCD_display_symbol(stloc,j++,cardkey[i]%16,0);
//			}
		stloc = 4;
		for(i=0,j=4;i<6;i++)
			{
			LCD_display_symbol(stloc,j++,system0_number[i]/16,0);
			LCD_display_symbol(stloc,j++,system0_number[i]%16,0);
			}	
#endif
#endif
}



//�� IC�� ����Ľ��
uchar read_IC_card_amount(uchar car)
{    
    uchar valueFlag,read_IC_card_flag,card_class_flag,read_card_flag;
    unsigned long momery;
    long left_momery;
    unsigned long timeOut;
    uchar momery_buffer[8],left_momery_buffer[8],cardno_err[4],i;
    uchar block0_buffer[32],block1_buffer[32],block2_buffer[32];
    uchar MIFARE_password_buffer[16],card_no_buffer[4];
    uchar start_buffer[4],end_buffer[4],YXRQ[8],buffer[32];
    MIFARE_card_information MIFARE_card_info;
    carStation_reference_of_used CS_RF_US;
	CardInfo YWCardInfo;    
	s32 listret;
	u8 display_ICflag;
	
    Smart_Power_ON;
    read_IC_card_flag = 0;
	display_ICflag = 0;
    get_rate_ref(&RR_ST1);//��ȡ����    
    read_car_reference_of_use_info(&CS_RF_US,car);//����λ״̬��Ϣ
//    delay(KEYTIMEOUT_1S * 0.35);//������ʱ ��Ϊ�� �������� �ϵ�
    delay(KEYTIMEOUT_1S * 0.1);//������ʱ ��Ϊ�� �������� �ϵ�
//    I2C_ReadS_24C(sysytem_public_key,system0_number,7);
//    Public_BCC = 0x00;
//    for(i=0;i<6;i++)
//		{
//        Public_BCC = Public_BCC ^ system0_number[i];
//		}
//    
//    if(Public_BCC != system0_number[6])//��Կ��У�鲻��
//    	{
//        //���»�ȡ��Կ
//        I2C_ReadS_24C(sysytem_public_key_back,system0_number,7);        
//        Public_BCC = 0x00;
//        for(i=0;i<6;i++)
//			{
//			Public_BCC = Public_BCC ^ system0_number[i];
//			}        
//        if(Public_BCC != system0_number[6])//������Կ��У�鲻��
//        	{
//            //��ԭΪ������Կ
//			buffer[0]=0x07;
//			buffer[1]=0x55;
//			buffer[2]=0x83;
//			buffer[3]=0x26;
//			buffer[4]=0x62;
//			buffer[5]=0x36;
//            buffer[6] = buffer[0] ^ buffer[1] ^ buffer[2] ^ buffer[3] ^ buffer[4] ^ buffer[5];
//            I2C_WriteS_24C(sysytem_public_key,buffer,7);  //���ܺ����в�������
//            I2C_WriteS_24C(sysytem_public_key_back,buffer,7);            
//            //������Ҫ������Ȩ
//            }
//		else
//			{
//            //���� �ѱ�����Կд�ص� ԭ����Կ����ȥ��
//            I2C_WriteS_24C(sysytem_public_key,system0_number,7);
//			} 
//		}
	display_select_momery();//��ʾ ����ѯ�Ľ���
        //�ȶ�ID�� ȷ���������ĺû�
#ifndef PSAM_ID
		delay(KEYTIMEOUT_1S);//��psamʱ��ʱ����
		TMP.PSAM = 0;
#else		
		i = 6;
		while(i--)
			{
			TMP.PSAM = read_PSAM();
			if(TMP.PSAM==0)break;
			delay(KEYTIMEOUT_1S/5);
			}
#endif
	#ifdef MACHINE_ID
    timeOut = 0;
	QuitTime=5	;
	key_flagbk = 0;
    read_mech_ID_flag = NO;
    while(timeOut < 3)
		{
        if(read_mech_ID() == 0x00)
			{
            read_mech_ID_flag = OK;
            break;
			}
        else
			{
            //delay(KEYTIMEOUT_1S/20);//������ʱ ��Ϊ�� �������� �ϵ�
        	}        
        timeOut++;
		}    
    if(read_mech_ID_flag != OK)
		{
        Smart_Power_OFF;
        return 0x99;
		}    
#endif        
    if(key_flag != 0)key_flag = 0;
	
	ERRCODE = 0;  
    QuitTime = 4;
    while(QuitTime--)//����ѭ���� 2015-07-24
    	{
		timeOut = 0;  
		while(timeOut < 300)
			{
            card_class_flag = inquire_card(&YWCardInfo);
			if(card_class_flag==CardType_IC)
				{
				Smart_Power_OFF;										
				//��ʾ �ε�											
				Buzz_0;										   
				delay(KEYTIMEOUT_1S/10);											 
				Buzz_1;
				ICCard_Pay(car,IQ_YES);	
				return 0;
				}
			else if(card_class_flag==CardType_CPU)
				{
				//��ʾ �ε� 										
				Buzz_0; 									   
				delay(KEYTIMEOUT_1S/10);											 
				Buzz_1;
				CpuCard_Pay(car,IQ_YES,&YWCardInfo);
				return 0;
				}
			else if(card_class_flag==CardType_CPCLOCK)
				{
				if(timeOut < 40)continue;
				write_card_error(0);
				delay(KEYTIMEOUT_1S*3);
				return 1;
				}
			if((card_class_flag==CardType_MF1)||
				(card_class_flag==CardType_BIKE)||
				(card_class_flag==CardType_CPC))
				{
                read_IC_card_flag = OK;
                break;
				}
            else
				{
                read_IC_card_flag = NO;
				}            
            if(key_flag)
				{
                key_flag = 0;
				return 1;
				}
            timeOut++;
			}		
		if(read_IC_card_flag == NO)
			{
			if(QuitTime!=1)continue;
			//��������ʶ��Ŀ�
			//Ѱ�� ʧ��(����һ��ʱ�� �Զ��˳�)
			Smart_Power_OFF;
			no_use_card(ERRCODE);
			delay(KEYTIMEOUT_1S * 3);
			key_flag = 0;
			return 0;
			}		
		//��������ʱ�� �ر��ն�    
		DISABLE_EXTI15_10_IRQ(); 
		DISABLE_EXTI9_5_IRQ();    
		//����ѯ���� Ҫ�жϺ����� �Ժ��
//		if(card_class_flag == BACLK_LIST)//������
//			{                
//            Smart_Power_OFF;
//            OPEN_EXTI9_5_IRQ();        
//            OPEN_EXTI15_10_IRQ();                
//            Buzz_0;
//            delay(KEYTIMEOUT_1S/10);
//            Buzz_1;                
//            display_backList();
//            delay(KEYTIMEOUT_1S * 3);
//            return 0;
//			}
		if(card_class_flag==CardType_BIKE)
			{
			disp_IQIMG(&YWCardInfo);
			timeOut = 0;
			while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
				{
				if(key_flag)
					{ 
					key_flag = 0; 
					delay(KEYTIMEOUT_1S * QUIT_TIME);
					break;
					} 
				timeOut++;
				} 
			return 0;
			}
		else if(card_class_flag==CardType_CPC)
			{
//��ʾ����-��� -״̬[����-�볡-������]- �ϴ�
			//YWCardInfo.YYXLH
			disp_IQIMG(&YWCardInfo);
			timeOut = 0;
			while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
				{
				if(key_flag)
					{ 
					key_flag = 0; 
					delay(KEYTIMEOUT_1S * QUIT_TIME);
					break;
					} 
				timeOut++;
				} 
			return 0;
			}		
		else if(card_class_flag == CardType_MF1)//MIFARE��������
			{
            read_MIFARE_card(&MIFARE_card_info);  //��ȡmifare������Ϣ

			error_value_0 = RecoverArea();//�����ж�
			if((error_value_0==1)&&(QuitTime==5))
				{
//					QuitTime = 2;
				continue;//������֤������Կ
				}
			if(error_value_0==3)
				return 0;
            
            //���ܺ����в�������
            MF1key_main(MIFARE_card_info.SNR,MIFARE_password_buffer);     //��ȡMIFARE������Կ
            timeOut = 0;
            while(testkey_comd(0x02,0x0a,MIFARE_password_buffer) != OK && timeOut < 3)
            {
				display_ICflag = 0xAA;
                read_card_flag = 0x00;
                card_class_flag = inquire_card(&YWCardInfo);//��� ��������
				if(card_class_flag==CardType_CPCLOCK)
					{
					write_card_error(0);
					delay(KEYTIMEOUT_1S*3);
					return 1;
					}
				if(card_class_flag==CardType_MF1)
					{
					read_IC_card_flag = OK;
					break;
					}
				else
					{
					read_IC_card_flag = NO;
					}			 
            
                if(read_card_flag == OK)    
                {
                    if(card_class_flag == CardType_MF1)
                    {
                        read_MIFARE_card(&MIFARE_card_info);  //��ȡmifare������Ϣ
                        MF1key_main(MIFARE_card_info.SNR,MIFARE_password_buffer);     //��ȡMIFARE������Կ
                    }           
                }
                
                timeOut++;
				if((card_class_flag==CardType_BIKE)||
					(card_class_flag==CardType_CPC))
					break;
            }
			if((card_class_flag==CardType_BIKE)||
				(card_class_flag==CardType_CPC))
				continue;
			
            if(timeOut < 3)
				{
                error_value_0 = read_comd(BLOCK0_ADDR,block0_buffer);
                error_value_1 = read_comd(BLOCK1_ADDR,block1_buffer);
                error_value_2 = read_comd(BLOCK2_ADDR,block2_buffer);
				if(car==3)
					CardRecrodRead(block2_buffer[9],CarBuffer);
                if(error_value_0 == OK && error_value_1 == OK && error_value_2 == OK)
               	 	{
					Smart_Power_OFF;
					OPEN_EXTI9_5_IRQ();
					OPEN_EXTI15_10_IRQ();
                    Buzz_0;
					delay(KEYTIMEOUT_1S/10);
					Buzz_1;
				#ifdef CardKey_LCD
					LCD_back_ON;
					disp_card_fnstate(block2_buffer[0],MIFARE_password_buffer);

                    Buzz_0;
					delay(KEYTIMEOUT_1S/10);
					Buzz_1;
					key_flag=0;
					while(!key_flag);	
					if(block2_buffer[0]!=MIFARAE_PARK_CARD)
						return 0;
				#endif

					if(block2_buffer[0]!=MIFARAE_PARK_CARD)
						{
						//disp_card_fnstate(block2_buffer[0],MIFARE_password_buffer);
						}
						
					
					switch(block2_buffer[0])
						{
						case HLEPPARK_CARD:
						case MIFARAE_PARK_CARD:
							//����Ҫ���� ���������ж�                            
                            for(i=0;i<4;i++)
								{
								carSNR[i] = MIFARE_card_info.SNR[3-i];
                            	}
							//����Ƿ��������ʾ 2015-07-27
							listret = SelectList_SRAM(carSNR,ListType_MF1FEE,buffer);
                            if(block0_buffer[0] + block0_buffer[4] !=0xff || block0_buffer[1] + block0_buffer[5] !=0xff || block0_buffer[2] + block0_buffer[6] !=0xff || block0_buffer[3] + block0_buffer[7] !=0xff)
                            	{
                                //�����쳣
                                Smart_Power_OFF;
								diplay_error(errcord_4);
                                delay(KEYTIMEOUT_1S * 3);
                                return 0;
								} 
							momery = block0_buffer[3] * 0x1000000 + block0_buffer[2] * 0x10000 + block0_buffer[1] * 0x100 + block0_buffer[0];
							if(momery > 100000)
								{
								MoneryException();
								delay(KEYTIMEOUT_1S*2);
								return 0x73;//���� ����
								}
							display_select_result(MIFARE_card_info.SNR[3],MIFARE_card_info.SNR[2],MIFARE_card_info.SNR[1],MIFARE_card_info.SNR[0],momery,block2_buffer[1],0);
							momery = hcl(block2_buffer+7,2);
							//LCD_display_no(3,7,momery>>8);	
							//LCD_display_no(3,8,momery);	
#ifdef IN_MBSYSTEM //����24  �����ӵ���ʾ 2016-02-22
							;
#else
							zimo =1;
//							if(momery/1000)
//								LCD_display_symbol(3,13,momery/1000,0);
//							LCD_display_symbol(3,14,(momery%1000)/100,0);
//							LCD_display_symbol(3,15,(momery%100)/10,0);
//							LCD_display_symbol(3,16,momery%10,0);
							if(TMP.cardplace == CardType_INMF1RD)
								print_XYstr_16_16(3,13,"IN");
							else if(TMP.cardplace == CardType_WZMF1RD)
								print_XYstr_16_16(3,13,"WZ");
							else if(TMP.cardplace == CardType_ZGMF1RD)
								print_XYstr_16_16(3,13,"ZG");
							else if(TMP.cardplace == CardType_OWLMF1RD)
								print_XYstr_16_16(3,13,"WLO");
							else
								print_XYstr_16_16(3,13,"WLN");							
							zimo = 0;
#endif						
							if(car == 3)//��ѯ��¼  2016-02-18
								{	
								u8 j,k,rdsum = block2_buffer[9];
								zimo =1;								
#ifdef IN_MBSYSTEM //����14  �����ӵ���ʾ 2016-02-22
								//Check records 05
								print_XYstr_16_16(4,1,"Check records");
#else
								i=1;
								dispaly(4,i++,(HZ + wang));
								dispaly(4,i++,(HZ + xia));
								dispaly(4,i++,(HZ + cha));
								dispaly(4,i++,(HZ + xun));
								dispaly(4,i++,(HZ + ji));
								dispaly(4,i++,(HZ + lu));	
#endif
								zimo =0;
								LCD_display_symbol(4,15,block2_buffer[9] / 10,0);
								LCD_display_symbol(4,16,block2_buffer[9] % 10,0);	
								
								key_flag = 0;
								delay(KEYTIMEOUT_1S * 1);
								timeOut = KEYTIMEOUT_1S * WAITE_TIME;
								while(timeOut--)
									{  
									if(key_flag)
										{
										break; 
										} 
									} 	
								if(key_flag)
									key_flag = 0;
								else
									break;//δ����ֱ���˳� 2016-02-19
									
//								CardRecrodRead(block2_buffer[9],CarBuffer);
								for(i=0,j=0;i<rdsum;i++)
									{
									//1602191014--1120
									//123456:05.00Ԫ
									if(j==0)
										lcd_clear();
									goto_xy(0xA1+j*2,1);	
									for(k=0;k<5;k++)
										print_num2(CarBuffer[i*16+k]); 
									print_XYstr_16_16(1+j*2,11,"--");
									print_num2(CarBuffer[i*16+6]); 
									print_num2(CarBuffer[i*16+7]); 									

									goto_xy(0xA2+j*2,1);	
									for(k=13;k<16;k++)
										print_num2(CarBuffer[i*16+k]);
									LCD_display_symbol(2+j*2,7,1,1);

									left_momery =CarBuffer[i*16+11]*256+CarBuffer[i*16+12];
#ifdef IN_MBSYSTEM //����14  �����ӵ���ʾ 2016-02-22
									print_XYstr_16_16(2+j*2,8,"Rp");									
									zimo =1;
									left_momery *= 10;
									print_num2(HEX_to_BCD(left_momery/100)); 
									LCD_display_symbol(2+j*2,12,5,1);
									goto_xy(0xA2+j*2,13);
									print_num2(HEX_to_BCD(left_momery%100));									
									print_num1(0);									
									zimo =0;
									#elif defined English_Disp
									
									#else		
									zimo =1;
									goto_xy(0xA2+j*2,10);	
									print_num2(HEX_to_BCD(left_momery/100)); 
									LCD_display_symbol(2+j*2,12,5,1);
									goto_xy(0xA2+j*2,13);
									print_num2(HEX_to_BCD(left_momery%100)); 	
									zimo =0;
									dispaly(2+j*2,8,(HZ + yuan));									
									#endif
									
									j++;
									if(j>1)
										{
										j=0;
										delay(KEYTIMEOUT_1S * 1);
										timeOut = KEYTIMEOUT_1S * WAITE_TIME;
										while(timeOut--)
											{  
											if(key_flag)
												{
												key_flag = 0;
												break; 
												} 
											}
										}									
									}	
								if(rdsum%2)
									{
									delay(KEYTIMEOUT_1S * 1);
									timeOut = KEYTIMEOUT_1S * WAITE_TIME;
									while(timeOut--)
										{  
										if(key_flag)
											{
											key_flag = 0;
											break; 
											} 
										}
									}
								break;
								}
#ifdef IN_MBSYSTEM //����14  �����ӵ���ʾ 2016-02-22
							//Used 11:21,02/21		
							print_XYstr_16_16(4,1,"Used 11:21,02/21");	  
							i =1;
							LCD_display_symbol(4,6,block2_buffer[5-i] / 0x10,0);
							LCD_display_symbol(4,7,block2_buffer[5-i] % 0x10,0);
							LCD_display_symbol(4,8,1,1);	
							LCD_display_symbol(4,9,block2_buffer[6-i] / 0x10,0);
							LCD_display_symbol(4,10,block2_buffer[6-i] % 0x10,0);  
							LCD_display_symbol(4,11,2,1);							
							LCD_display_symbol(4,12,block2_buffer[3-i] / 0x10,0);
							LCD_display_symbol(4,13,block2_buffer[3-i] % 0x10,0);
							LCD_display_symbol(4,14,3,1);	
							LCD_display_symbol(4,15,block2_buffer[4-i] / 0x10,0);
							LCD_display_symbol(4,16,block2_buffer[4-i] % 0x10,0); 							
#elif defined EN_MBSYSTEM
																			
#else
							dispaly(4,1,(HZ + shang));
							dispaly(4,2,(HZ + ci));
							LCD_display_symbol(4,5,1,1);
							i =1;
							LCD_display_symbol(4,6,block2_buffer[3-i] / 0x10,0);
							LCD_display_symbol(4,7,block2_buffer[3-i] % 0x10,0);
							LCD_display_symbol(4,8,6,1);	
							LCD_display_symbol(4,9,block2_buffer[4-i] / 0x10,0);
							LCD_display_symbol(4,10,block2_buffer[4-i] % 0x10,0); 							
							LCD_display_symbol(4,12,block2_buffer[5-i] / 0x10,0);
							LCD_display_symbol(4,13,block2_buffer[5-i] % 0x10,0);
							LCD_display_symbol(4,14,1,1);	
							LCD_display_symbol(4,15,block2_buffer[6-i] / 0x10,0);
							LCD_display_symbol(4,16,block2_buffer[6-i] % 0x10,0);   
#endif							
                            timeOut = 0;
                            while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
								{  
								if(key_flag)
									{
									key_flag = 0;
									delay(KEYTIMEOUT_1S * QUIT_TIME);
									break; 
									} 
								timeOut++; 
								} 
							listret = -1;//����Ƿ��������ʾ 2015-10-27
							if((listret>=0)&&block2_buffer[1]) //����Ƿ�Ѽ�¼ 2015-07-14
								{
								//buffer0-3 ����	4-5Ƿ�ѽ��  6-7δ���������1λ��+���ᱶ����3λ��
								u16 feemny,feetime,feelock;//,feeorg;
								
								feemny = hcl(buffer+4,2);
								feetime = (buffer[6]&0xf0)>>4;
								feelock = (buffer[6]&0x0f)<<8;
								feelock += buffer[7];
								disp_NoFeeIMG(feemny,feetime,feelock);
								timeOut = 0;
								while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
									{  
									if(key_flag)
										{
										key_flag = 0;
										delay(KEYTIMEOUT_1S * QUIT_TIME);
										break; 
										} 
									timeOut++; 
									} 								
								}
							break;
//                              case DECEIVE_CARD:
						  case RESET_CARD:
							  if(validity(block2_buffer,RESET_CARD) != OK)//��λ�� ����Ч���� ���
							  	{
								  //�ص�����ģ��ĵ�Դ Ϊ��ʡ�� 																				 
								  Smart_Power_OFF;																										  
								  OPEN_EXTI9_5_IRQ();																													   
								  OPEN_EXTI15_10_IRQ();
								  
									car_outdate();
									timeOut = 0;
									while(timeOut < KEYTIMEOUT_1S * 1.5)
									{											 
									  if(key_flag){ 											  
										key_flag = 0;		
										delay(KEYTIMEOUT_1S * QUIT_TIME);
										break;											   
									  } 										   
									  timeOut++;
									}
								break;
								}
							  
							  for(i=0;i<4;i++)
								  {
								  TMP.opcardno[i] = MIFARE_card_info.SNR[3-i];
								  }
							#ifdef WZ_MBSYSTEM
								i = 77;
							#else
								i = 3;
							#endif
//							i = 3;
						  	//��˫��---��ʱ ��˫��-����
						  	//if(car ==3)//�ֶ�����---- 
							if(car ==i)//�ֶ�����---- 
						  	//�˹�����λ��˫����ֱ��ѯ�ʺ�̨������Ϣ---����
						  		{									
//*<Long><320></Long><Result><Optype><F1></Optype><Metno><66123456></Metno><spaces><6></spaces><TxnType><EA></TxnType><PosSeq><000000></PosSeq><CardKind><00000000></CardKind><ChildCardKind><00000000></ChildCardKind><BalBef><00000000></BalBef><TxnAmt><00000000></TxnAmt><CardNum><BAC7BFA4></CardNum><TxnDate><2015-08-03></TxnDate><TxnTime><11:50:00></TxnTime><TExnDate><2015-08-03></TExnDate><TExnTime><11:50:00></TExnTime><TxnCounter><000000></TxnCounter><PSAMNO><000000000000></PSAMNO><PSAMSeq><00000000></PSAMSeq><TAC><00000000></TAC><Ptype><0></Ptype></Result># 
//#<ErrorCode><AABAC7BFA413880100320000005C></ErrorCode><Time><2015-08-11|09:21:37></Time><RsDate><150811@150811></RsDate>*
								{
									//���� ��һ�� ȷ�Ͻ��в������
									display_replaymenory(0x03);
								
									
									timeOut = 0;
									while(timeOut < KEYTIMEOUT_1S * 1)
										{
										if(key_flag == 0x02 || key_flag == 0x01)
											{
											key_flag = 0;
											break;
											}
										else if(key_flag == 0x03 || key_flag == 0x04)
											{
											key_flag = 0;
											return 0;
											}											
										else
										  timeOut++;	
										}									
									if(timeOut >= KEYTIMEOUT_1S * 1)
									  return 0;	

									display_please_operation(time1[4],time1[3],time1[2],time1[1],time1[0],0x05);	   
									Smart_Power_ON;
									timeOut = 0;   
									key_flag = 0;
									read_IC_card_flag =NG;
									i = 4;
									while(i--)
									{
									while(timeOut < 300)	   
									{
										card_class_flag = inquire_card(&YWCardInfo);//��� ��������
										if(card_class_flag==CardType_CPCLOCK)
											{
											if(timeOut < 50)continue;
											write_card_error(0);
											delay(KEYTIMEOUT_1S*3);
											return 1;
											}
										if((card_class_flag==CardType_MF1)||
											(card_class_flag==CardType_BIKE)||
											(card_class_flag==CardType_CPC))
											{
											read_IC_card_flag = OK;
											break;
											}
										
										if(key_flag != NO)
										{
										  key_flag = 0;
										  delay(KEYTIMEOUT_1S * QUIT_TIME);
											break;
										}
										
										timeOut++;					
									}
									if(read_IC_card_flag==NG)
										{
										timeOut = 0;	
										if(i>1)continue;
										disp_cardfee(3);
										delay(KEYTIMEOUT_1S*4);
										return 0;
										}
									}
									if(card_class_flag==CardType_CPC)
										{
										memcpy(TMP.cardno+4,YWCardInfo.snr,4);
										TMP.cardtype = CardType_CPCRD;
										}
									else if(card_class_flag==CardType_BIKE)
										{
										memcpy(TMP.cardno,YWCardInfo.YYXLH,8);
										TMP.cardtype = CardType_BIKERD;
										}
									else
										{
										read_MIFARE_card(&MIFARE_card_info);
	//									memcpy(TMP.cardno+4,MIFARE_card_info->snr,4);
										TMP.cardtype = TMP.cardplace;//CardType_MF1RD;
										for(i=0;i<4;i++)
											{
											TMP.cardno[i+4] = MIFARE_card_info.SNR[3-i];
											}
										if((TMP.opcardno[0]==TMP.cardno[4])&&(TMP.opcardno[1]==TMP.cardno[5])&&
											(TMP.opcardno[2]==TMP.cardno[6])&&(TMP.opcardno[3]==TMP.cardno[7]))
											{
											Smart_Power_OFF;
											return 0;
											}
										}
									TMP.car = car;
									disp_cardfee(0);

									Smart_Power_OFF;
									i = Send_CardFeeRecord(1);
									if(i>0)
										{
										disp_cardfee(1);
										delay(KEYTIMEOUT_1S*4);
										return 0;
										}
									if(TMP.feetime==0)
										{
										disp_cardfee(2);
										delay(KEYTIMEOUT_1S*4);
										return 0;
										}		
									memset(TMP.cardno,0xAA,4);
									lcd_clear();//���� ��ʾ ��ˢ��	
									Smart_Power_ON;
									delay(KEYTIMEOUT_1S/10);//������ʱ ��Ϊ�� �������� �ϵ�
									#ifdef MACHINE_ID
									timeOut = 0;
									read_mech_ID_flag = NO;
									while(timeOut < 3)
										{
										if(read_mech_ID() == 0x00)
											{
											read_mech_ID_flag = OK;
											break;
											}										
										timeOut++;
										}
									
									if(read_mech_ID_flag != OK)
										{
										
										Smart_Power_OFF;
										return 0x99;
										}
									#endif										
									
									display_please_operation(time1[4],time1[3],time1[2],time1[1],time1[0],0x13);	   
									disp_cardfee(0x99); 

									timeOut = 0;   
									key_flag = 0;
									i = 4;
									while(i--)
									{
									while(timeOut < 300)	   
									{
										card_class_flag = inquire_card(&YWCardInfo);//��� ��������
										if(card_class_flag==CardType_CPCLOCK)
											{
											if(timeOut < 290)continue;
											write_card_error(0);
											delay(KEYTIMEOUT_1S*3);
											return 1;
											}
										if((card_class_flag==CardType_MF1)||
											(card_class_flag==CardType_BIKE)||
											(card_class_flag==CardType_CPC))
											{
											read_IC_card_flag = OK;
											break;
											}										
										if(key_flag != NO)
										{
										  key_flag = 0;
										  delay(KEYTIMEOUT_1S * QUIT_TIME);
											break;
										}										
										timeOut++;					
									}
									if(read_IC_card_flag==NG)
										{
										timeOut = 0;
										if(i>1)continue;
										disp_cardfee(3);
										delay(KEYTIMEOUT_1S*4);
										return 0;
										}
									break;
									}
									if(read_IC_card_flag == OK)	   
									{								
										if(card_class_flag == CardType_BIKE) 	
											{
											//��� TMP.feetime --
											BIKECARD_PRO(car,0x99,&YWCardInfo);	
											return 0;
											}
										else if(card_class_flag == CardType_CPC) 	
											{
											//��� TMP.feetime --
											CPCCARD_PRO(car,0x99,&YWCardInfo);	
											return 0;
											}
										
										else if(card_class_flag == CardType_MF1)
										{
											uchar flag_buffer[1];
											uchar ReMoneryF;
											uchar ReBlockF;
											uchar select_momery_buffer[4];
											unsigned long select_momery;
											read_MIFARE_card(&MIFARE_card_info);  //��ȡmifare������Ϣ
											  for(i=0;i<4;i++)
												  cardno_err[i] = MIFARE_card_info.SNR[i];
											  //���ܺ����в�������
											MF1key_main(MIFARE_card_info.SNR,MIFARE_password_buffer);	  //��ȡMIFARE������Կ
											timeOut = 0;
											while(testkey_comd(0x02,0x0a,MIFARE_password_buffer) != OK && timeOut < 20)
											{												  
												inquire_card(&YWCardInfo);
												if(card_class_flag==CardType_CPCLOCK)
													{
													write_card_error(0);
													delay(KEYTIMEOUT_1S*3);
													return 1;
													}
												read_MIFARE_card(&MIFARE_card_info);
												timeOut++;
											}
											
											if(timeOut < 20)
											{								
												if(read_comd(BLOCK0_ADDR,left_momery_buffer) == OK && read_comd(BLOCK1_ADDR,block1_buffer) == OK && read_comd(BLOCK2_ADDR,block2_buffer) == OK )
												{
													if((block2_buffer[0] == MIFARAE_PARK_CARD)||(block2_buffer[0] == MONTH_CARD))
													{
													   left_momery = left_momery_buffer[0] + left_momery_buffer[1] * 0x100 + left_momery_buffer[2] * 0x10000 + left_momery_buffer[3] * 0x1000000;
													   if(left_momery > 100000)
														  {
														  return 0x73;//���� ����
														  } 
													   if(left_momery_buffer[0] + left_momery_buffer[4] !=0xff ||
														  left_momery_buffer[1] + left_momery_buffer[5] !=0xff ||
														  left_momery_buffer[2] + left_momery_buffer[6] !=0xff ||
														  left_momery_buffer[3] + left_momery_buffer[7] !=0xff)
														  {
														   //�����쳣
														   Smart_Power_OFF;
														   lcd_clear(); 	
//														   Card abnormal
#ifdef IN_MBSYSTEM //����6  �����ӵ���ʾ 2016-02-22
														   print_XYstr_16_16(2,1,"Kartu tidak sah");
#else														   
														   dispaly(2,3,(HZ + ka));//
														   dispaly(2,4,(HZ + yi_3));//
														   dispaly(2,5,(HZ + chang));// 														   
														   delay(KEYTIMEOUT_1S * 3);
#endif
														   return 0;
														   }
													   
//													   if(TMP.feetime>=block2_buffer[1])//δ���㴦��
//													   		;
													   for(i=0;i<4;i++)
														   MIFARE_card_info.SNR[i] = cardno_err[i];
													   if(block2_buffer[1] >= 0x01)//��δ�������
													   {
														  block1_buffer[0] = 0x00; //��������
															block1_buffer[1] = 0x00;
															block1_buffer[2] = 0x00;
															block1_buffer[3] = 0x00;
															block1_buffer[4] = MIFARE_card_info.SNR[3];
															block1_buffer[5] = MIFARE_card_info.SNR[2];
															block1_buffer[6] = MIFARE_card_info.SNR[1];
															block1_buffer[7] = MIFARE_card_info.SNR[0];
															
															if( ReadReplenishmentNo(block1_buffer) == OK)
															{
																 flag_buffer[0] = 0x00;
																	I2C_WriteS_24C(ReplenMoneryFlag,flag_buffer,1);
																	I2C_WriteS_24C(ReplenBlockFlag,flag_buffer,1);
																	for(uchar i=0;i<8;i++)
																	  block1_buffer[i] = 0; 									 
																	I2C_WriteS_24C(ReplenishmentNo,block1_buffer,8);
																	I2C_WriteS_24C(ReplenishmentMonery,block1_buffer,4);
																	
															}
															I2C_ReadS_24C(ReplenMoneryFlag,flag_buffer,1);
															ReMoneryF = flag_buffer[0];
															
															I2C_ReadS_24C(ReplenBlockFlag,flag_buffer,1);
															ReBlockF = flag_buffer[0];
															
															I2C_ReadS_24C(ReplenishmentMonery,select_momery_buffer,4);
															select_momery = select_momery_buffer[0] + select_momery_buffer[1] * 0x100 + select_momery_buffer[2] * 0x10000 + select_momery_buffer[3] * 0x1000000;																	  
																
															
															if(ReMoneryF == 0 && ReBlockF == 0)//��һ�β��� û���ֹ�����
															{
																valueFlag = 0;
																left_momery = left_momery_buffer[3] * 0x1000000 + left_momery_buffer[2] * 0x10000 + left_momery_buffer[1] * 0x100 + left_momery_buffer[0];
								
															}
															else if(ReMoneryF == 1 && ReBlockF == 0)//�ۿ���� 
															{
																if(select_momery == left_momery)//�ϴ� �ۿ�
																{
																	valueFlag = 0;
																}
																else
																{
																	valueFlag = 1;
																	left_momery = select_momery;
																}
															}
															else if(ReMoneryF == 0 && ReBlockF == 1)//д�� ����
															{
																valueFlag = 1;
																left_momery = select_momery;
															}
															else
															{
																if(select_momery == left_momery)//�ϴ� �ۿ�
																{
																	valueFlag = 0;
																}
																else
																{
																	valueFlag = 1;
																	left_momery = select_momery;
																}
															}
														 
															left_momery_buffer[0] = left_momery % 0x100;
															left_momery_buffer[1] = left_momery / 0x100 % 0x100;
															left_momery_buffer[2] = left_momery / 0x10000 % 0x100;
															left_momery_buffer[3] = left_momery / 0x1000000 % 0x100;
														 
															//1. ���ݿ��� ����������ݣ��ӽ���� ��ֵ															
															fll(TMP.feemny,momery_buffer,4);
//															fll(RR_ST1.Max_Stop_Momery * RR_ST1.Sale_Base,momery_buffer,4);
																	
															if(left_momery < TMP.feemny)
															{
																 for(int i=0;i<4;i++)
																	momery_buffer[i] = left_momery_buffer[3 - i];
															}
																
															if(left_momery >= TMP.feemny)											  
															   momery = TMP.feemny;
															else
															   momery = left_momery;
															
															
															if(valueFlag == 1 || value_comd(0x2d,8,momery) == OK)//�ۿ�ɹ�
															{
																//�ص�����ģ��ĵ�Դ Ϊ��ʡ��												 
												  
												  
																//2. д��������Ϊ����1�Σ�д�뵱ǰ���ڣ���ȥ����λ�����
																//block2_buffer[1] = 0x00;//������־
																if(block2_buffer[0] == MIFARAE_PARK_CARD)																  
																  { 			
																	  //buffer0-3 ����	4-5Ƿ�ѽ��  6-7δ���������1λ��+���ᱶ����3λ��
																	  u16 feelock,feeorg;//feetime,feemny,														  
																	  
																	  feelock = hcl(TMP.unlockmny,2);
																	  if(TMP.feetime)//����δ����	  ���㷽ʽ��ȷ��
																		  {   
																		  if(TMP.feetime>=block2_buffer[1])//δ���㴦��
																			  block2_buffer[1] = 0;
																		  else
																			  block2_buffer[1] -= TMP.feetime;
																		  feeorg = hcl(block2_buffer+7,2);
																		  if((feelock>=feeorg)||(block2_buffer[1]==0))//�����
																			  {
																			  block2_buffer[7] = 0x00;
																			  block2_buffer[8] = 0x00;
																			  }
																		  else
																			  {
																			  feeorg -= feelock;
																			  fll(feeorg,block2_buffer+7,2);
																			  }
																	  	}
																	i =2;
																	block2_buffer[i++] = time[3]; 
																	block2_buffer[i++] = time[2];	
																	block2_buffer[i++] = time[1];
																	block2_buffer[i++] = time[0];  
																	block2_buffer[i++] = 0x88;//time[4];	
																  }
																
																if(write_comd(BLOCK2_ADDR,block2_buffer) == OK)
																{
																	OPEN_EXTI9_5_IRQ();
																	OPEN_EXTI15_10_IRQ();
													  
													  
																	Buzz_0;
																	delay(KEYTIMEOUT_1S/20);
																	Buzz_1;
																	
																	flag_buffer[0] = 0x00;
																	I2C_WriteS_24C(ReplenMoneryFlag,flag_buffer,1);
																	I2C_WriteS_24C(ReplenBlockFlag,flag_buffer,1);
																	for(uchar i=0;i<8;i++)
																	  block1_buffer[i] = 0; 									 
																	I2C_WriteS_24C(ReplenishmentNo,block1_buffer,8);
																	I2C_WriteS_24C(ReplenishmentMonery,block1_buffer,4);
																	
																	Smart_Power_OFF;
																	//2. ����д�� ��ǰͣ��ʱ��																																			
																
																	//4. �油���¼
																	block1_buffer[0] = 0xEE;//��¼ͷ
																	block1_buffer[1] = 0x00; //��������
																	block1_buffer[2] = TMP.feetime;
																	block1_buffer[3] = TMP.unlockmny[0];
																	block1_buffer[4] = TMP.unlockmny[1];
																	block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
																	block1_buffer[6] = MIFARE_card_info.SNR[2];
																	block1_buffer[7] = MIFARE_card_info.SNR[1];
																	block1_buffer[8] = MIFARE_card_info.SNR[0];
																	block1_buffer[9] = time[4];//��
																	block1_buffer[10] = time[3];//��
																	block1_buffer[11] = time[2];//��
																	block1_buffer[12] = time[1];//ʱ
																	block1_buffer[13] = time[0];//��
																	block1_buffer[14] = left_momery_buffer[2];
																	block1_buffer[15] = left_momery_buffer[1];
																	block1_buffer[16] = left_momery_buffer[0];
																	block1_buffer[17] = momery_buffer[2];
																	block1_buffer[18] = momery_buffer[3];
																	block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x07;//���� ��λΪcar
																	
																	block1_buffer[20] = time[4];
																	block1_buffer[21] = time[3];
																	block1_buffer[22] = time[2];
																	block1_buffer[23] = time[1];
																	block1_buffer[24] = time[0];
																
																	block1_buffer[25] = CardType_MF1;
																	
																	for(int i=26;i<32;i++)
																	   block1_buffer[i] = 0xAA; 
																	for(int i=26;i<30;i++)
																	   block1_buffer[i] = TMP.opcardno[i-26]; 
																	
																	Save_Record(block1_buffer,32);
																	
																	//3. ��ʾ������ ������� ����ͣ�� ��ͣʱ��
																	replay_momery(momery,left_momery - momery,1); 
																	timeOut = 0;								
																	while(timeOut < KEYTIMEOUT_1S * WAITE_TIME) 							 
																	{								 
																		if(key_flag){								 
																		  //key_flag = 0;																			  
																		  delay(KEYTIMEOUT_1S * QUIT_TIME);
																		  break;
																		}							   
																		timeOut++;
																	}
																}
																else
																{
																	//�ص�����ģ��ĵ�Դ Ϊ��ʡ��							   
																	Smart_Power_OFF;
																	
																	///////////////////////////////////////////////////////////////
																	//������д������ı�־ �� �� ����  �� �� ���
																	flag_buffer[0] = 0x01;
																	I2C_WriteS_24C(ReplenBlockFlag,flag_buffer,1);
																	
																	block1_buffer[0] = 0x00; //��������
																	block1_buffer[1] = 0x00;
																	block1_buffer[2] = 0x00;
																	block1_buffer[3] = 0x00;
																	block1_buffer[4] = MIFARE_card_info.SNR[3];
																	block1_buffer[5] = MIFARE_card_info.SNR[2];
																	block1_buffer[6] = MIFARE_card_info.SNR[1];
																	block1_buffer[7] = MIFARE_card_info.SNR[0];
																	I2C_WriteS_24C(ReplenishmentNo,block1_buffer,8);
																	
																	I2C_WriteS_24C(ReplenishmentMonery,left_momery_buffer,4);
																	///////////////////////////////////////////////////////////////
																	OPEN_EXTI9_5_IRQ(); 																   
																	OPEN_EXTI15_10_IRQ();
																	write_card_error(0);
																	timeOut = 0;
																	while(timeOut < KEYTIMEOUT_1S * 1.3)
																	{
																	   if(key_flag){
																		  key_flag = 0;
																		  delay(KEYTIMEOUT_1S * QUIT_TIME);
																	   break;
																	   }
																	   timeOut++;
																	}
																}
																													
															}
															else
															{
																//�ۿ�ɹ�
																//��ʾ д������ ������ˢ��
															  /////////////////////////////////////////////////////////
															  //�������ۿ�����ı�־ �� �� ��ǰ���
															  flag_buffer[0] = 0x01;
															  I2C_WriteS_24C(ReplenMoneryFlag,flag_buffer,1);
															  
															  I2C_WriteS_24C(ReplenishmentMonery,left_momery_buffer,4);
															  
															  //////////////////////////////////////////////////////////
																//�ص�����ģ��ĵ�Դ Ϊ��ʡ��							   
																Smart_Power_OFF;
																		
																OPEN_EXTI9_5_IRQ(); 																   
																OPEN_EXTI15_10_IRQ();
																write_card_error(0);
																timeOut = 0;
																while(timeOut < KEYTIMEOUT_1S * 1)
																{
																   if(key_flag){
																	  key_flag = 0;
																	  delay(KEYTIMEOUT_1S * QUIT_TIME);
																   break;
																   }
																   timeOut++;
																}
															
															}
														
														}
														else
														{
															//�ص�����ģ��ĵ�Դ Ϊ��ʡ��							   
															Smart_Power_OFF;
																	
															//////////////////////////////////////////////////////////////
															block1_buffer[0] = 0x00; //��������
															block1_buffer[1] = 0x00;
															block1_buffer[2] = 0x00;
															block1_buffer[3] = 0x00;
															block1_buffer[4] = MIFARE_card_info.SNR[3];
															block1_buffer[5] = MIFARE_card_info.SNR[2];
															block1_buffer[6] = MIFARE_card_info.SNR[1];
															block1_buffer[7] = MIFARE_card_info.SNR[0];
															
															if( ReadReplenishmentNo(block1_buffer) == OK)
															{
																left_momery = left_momery_buffer[0] + left_momery_buffer[1] * 0x100 + left_momery_buffer[2] * 0x10000 + left_momery_buffer[3] * 0x1000000;
																if(left_momery > 100000)
																{
																	return 0x73;//���� ����
																} 
																
																if(left_momery > 0)//��ʾ �ϴοۿ� ���� ������ѽ��
																{
																	momery = RR_ST1.Max_Stop_Momery * RR_ST1.Sale_Base;
																}
																else//��ʾ �ϴοۿ� ���� ��ȫ�����
																{
																	I2C_ReadS_24C(ReplenishmentMonery,left_momery_buffer,4);
																	momery = left_momery_buffer[0] + left_momery_buffer[1] * 0x100 + left_momery_buffer[2] * 0x10000 + left_momery_buffer[3] * 0x1000000;																	   
																}
																
																left_momery = left_momery + momery;
																fll(momery,momery_buffer,4);
																fll(left_momery,left_momery_buffer,4);
																
																Buzz_0;
																delay(KEYTIMEOUT_1S/20);
																Buzz_1;
													  
																Smart_Power_OFF;
																//2. ����д�� ��ǰͣ��ʱ��																																			
																
																flag_buffer[0] = 0x00;
																I2C_WriteS_24C(ReplenMoneryFlag,flag_buffer,1);
																I2C_WriteS_24C(ReplenBlockFlag,flag_buffer,1);
																for(uchar i=0;i<8;i++)
																  block1_buffer[i] = 0; 									 
																I2C_WriteS_24C(ReplenishmentNo,block1_buffer,8);
																I2C_WriteS_24C(ReplenishmentMonery,block1_buffer,4);
																
																//4. �油���¼
																block1_buffer[0] = 0xEE;//��¼ͷ
																block1_buffer[1] = 0x00; //��������
																block1_buffer[2] = TMP.feetime;
																block1_buffer[3] = TMP.unlockmny[0];
																block1_buffer[4] = TMP.unlockmny[1];
																block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
																block1_buffer[6] = MIFARE_card_info.SNR[2];
																block1_buffer[7] = MIFARE_card_info.SNR[1];
																block1_buffer[8] = MIFARE_card_info.SNR[0];
																block1_buffer[9] = time[4];//��
																block1_buffer[10] = time[3];//��
																block1_buffer[11] = time[2];//��
																block1_buffer[12] = time[1];//ʱ
																block1_buffer[13] = time[0];//��
																block1_buffer[14] = left_momery_buffer[1];
																block1_buffer[15] = left_momery_buffer[2];
																block1_buffer[16] = left_momery_buffer[3];
																block1_buffer[17] = momery_buffer[2];
																block1_buffer[18] = momery_buffer[3];
																block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x07;//���� ��λΪcar
																	
																
																block1_buffer[20] = time[4];//��
																block1_buffer[21] = time[3];//��
																block1_buffer[22] = time[2];//��
																block1_buffer[23] = time[1];//ʱ
																block1_buffer[24] = time[0];//��
																
																block1_buffer[25] = CardType_MF1;
																	
																for(int i=26;i<32;i++)
																	block1_buffer[i] = 0xAA;							 
																Save_Record(block1_buffer,32);
																	
																//3. ��ʾ������ ������� ����ͣ�� ��ͣʱ��
																replay_momery(momery,left_momery - momery,1); 
															}
															else
															{
																//û�� δ�������
																display_no_outstanding();
															}
															//////////////////////////////////////////////////////////////
															OPEN_EXTI9_5_IRQ(); 																   
															OPEN_EXTI15_10_IRQ();
															
															timeOut = 0;								
															while(timeOut < KEYTIMEOUT_1S * 3)								
															{								 
															  if(key_flag){ 							   
																key_flag = 0;																			  
																delay(KEYTIMEOUT_1S * QUIT_TIME);
																break;
															  } 							 
															  timeOut++;
															}
														}
														
													}
													else
													{
														//�ص�����ģ��ĵ�Դ Ϊ��ʡ��							   
														Smart_Power_OFF;
																
														OPEN_EXTI9_5_IRQ(); 																   
														OPEN_EXTI15_10_IRQ();
														//�������͵Ŀ�
													  
														//��ʾ �޿�Ч
														no_use_card(0);
														delay(KEYTIMEOUT_1S * 3);
														key_flag = 0;
														return 0;
													}
												}
												else
												{
													//���������ֵ ����
													no_use_card(2);
													delay(KEYTIMEOUT_1S * 3);		 
													key_flag = 0;
													return 0;
												}
											}
											else
											{
												//��Կ����
												no_use_card(1);
												delay(KEYTIMEOUT_1S * 3);		 
												key_flag = 0;
												return 0;
											}										  
										
										}
										
									}
									else
										{
										//û�ҵ��� �Զ��˳�
										//�ص�����ģ��ĵ�Դ Ϊ��ʡ��							   
										Smart_Power_OFF;														  
										OPEN_EXTI9_5_IRQ(); 																   
										OPEN_EXTI15_10_IRQ();
										}								
								}			
								
								return 0;
						  		}	

#ifndef IN_MBSYSTEM

								lcd_clear();
								QuitTime = 0;
								key_flag = 0;//"?????"?
								Smart_Power_ON;
								delay(KEYTIMEOUT_1S * 0.35);//������ʱ ��Ϊ�� �������� �ϵ�
#ifdef CAR
								display_please_swid_card(time1[4],time1[3],time1[2],time1[1],time1[0],car - 1,5 - QuitTime);
#else
								display_please_swid_card(time1[4],time1[3],time1[2],time1[1],time1[0],car,5 - QuitTime);
#endif

								zimo =1;
								
#ifdef IN_MBSYSTEM //����6	�����ӵ���ʾ 2016-02-22
								print_XYstr_16_16(4,1,"Add time");
#else														   
								dispaly(4,1,(HZ + bu));
								dispaly(4,2,(HZ + shi));
								dispaly(4,3,(HZ + zhong));
#endif								
								zimo =0;
								delay(KEYTIMEOUT_1S * 0.35);//������ʱ ��Ϊ�� �������� �ϵ�
								card_class_flag = 0;
								timeOut = 0;
							    while(timeOut < 300)
//								while(timeOut < 180)
									{
									card_class_flag = inquire_card(&YWCardInfo);//��� ��������
									if(card_class_flag==CardType_IC)
										{
										Smart_Power_OFF;										
										//��ʾ �ε� 										
										Buzz_0; 									   
										delay(KEYTIMEOUT_1S/10);											 
										Buzz_1;
										error_flag = ICCard_Pay(car,IQ_BS);	
										return 0;
										}
									else if(card_class_flag==CardType_CPU)
										{
										//��ʾ �ε� 										
										Buzz_0; 									   
										delay(KEYTIMEOUT_1S/10);											 
										Buzz_1;
										
										error_flag = CpuCard_Pay(car,IQ_BS,&YWCardInfo);
										
										Smart_Power_OFF;
										return 0;
										}
									else if(card_class_flag==CardType_CPCLOCK)
										{
										QuitFlag = 1;//����Ѱ��
										if(QuitTime>=4)
											{
											write_card_error(0);
											delay(KEYTIMEOUT_1S*3);
											return 1;
											}
										else
											break;
										}
									if((card_class_flag==CardType_MF1)||
										(card_class_flag==CardType_BIKE)||
										(card_class_flag==CardType_CPC))
										{
//										read_card_flag = OK;
//										break;
										
										}
									else
										{
										read_card_flag = NO;
										}		
									if(key_flag)//���κμ� �˳���ˢ�� ����
										{
										QuitKey = key_flag;
										key_flag = 0;			
										break;
										}
									timeOut++;	  
									}

#else							
                            error_flag = AddTime_Operation(MIFARE_card_info.SNR,car,block1_buffer);
#endif
							if((error_flag == 0x88)||QuitKey)
								{
								return 0;
								}
							else if(error_flag == OK)
								{//��ʾ ����ɹ�
                                replement_success(0);
								}
							else if(error_flag == NO)
								{
                                replement_success(1);
								}  
							else if(error_flag == 0x99)//����������
								{//������������
                                //display_reader_P(NO);
                                i = 3;
								lcd_clear();
								
								#ifdef IN_MBSYSTEM //����6  �����ӵ���ʾ 2016-02-22
								print_XYstr_16_16(2,1,"Fault 1");
								print_XYstr_16_16(4,1,"Contact operator");
								#else														   
                                dispaly(2,i++,(HZ + du));//��
                                dispaly(2,i++,(HZ + ka));
                                dispaly(2,i++,(HZ + qi_1));//��
                                dispaly(2,i++,(HZ + gu));
                                dispaly(2,i++,(HZ + zhang));
								#endif
								}
							else
								{//ȡ�� �˳�
                                return 0;
								}
							timeOut = 0;
                            while(timeOut < KEYTIMEOUT_1S * 1.3)
								{ 
								if(key_flag)
									{    
									key_flag = 0;
									delay(KEYTIMEOUT_1S * QUIT_TIME);
                                	break;  
									} 
								timeOut++;  
								}                                 
                            break;
						case G24_TEST_CARD:
							Smart_Power_OFF;
							//��ʾ �ε�
							Buzz_0;
							delay(KEYTIMEOUT_1S/10);
							Buzz_1;
							
							lcd_clear();
							if(SYS_MS.G24S== ON)
							  {
							  SYS_MS.G24S =OFF;
							  print_XYstr_16_16(2,1,"2G4 close OK");		  
							  }
							else if(SYS_MS.G24S==OFF)
							  {
							  SYS_MS.G24S =ON;	  
							  print_XYstr_16_16(2,1,"2G4 open OK"); 		  
							  }
							//G24 open/close
							delay(KEYTIMEOUT_1S*3);
							break;
						case G3_TEST_CARD:								
							Smart_Power_OFF;
							//��ʾ �ε�
							Buzz_0;
							delay(KEYTIMEOUT_1S/10);
							Buzz_1;
							
							lcd_clear();
							if(SYS_MS.G3S== ON)
							  {
							  SYS_MS.G3S =OFF;
							  print_XYstr_16_16(2,1,"3&4G close OK"); 		  
							  }
							else if(SYS_MS.G3S==OFF)
							  {
							  SYS_MS.G3S =ON; 
							  print_XYstr_16_16(2,1,"3&4G open OK");			  
							  }
							//G3 open/close
							delay(KEYTIMEOUT_1S*3);
							break;
							
						case TEST_ROM:
							Smart_Power_OFF;
							FM24CL256_WR_RD_TESTING();
							break;
						case TEST_TIME:
							Smart_Power_OFF;
							RX8025SA_READ_TEST();
							break;
							
//                              case RESET_CARD:
						case  DECEIVE_CARD:
//								if(validity(block2_buffer,RESET_CARD) == OK)//��λ�� ����Ч���� ���
							if(validity(block2_buffer,DECEIVE_CARD) == OK)//��λ�� ����Ч���� ���
//							if(1)
								{
								//���Ӻ��й��� 2015-07-18  ����A ��¼
                                OPEN_EXTI9_5_IRQ();
                                OPEN_EXTI15_10_IRQ();                                                
                                Smart_Power_OFF;  
                                //1. ����м�¼                                                                                                                   
//                                block1_buffer[0] = 0xEE;//��¼ͷ                                                
                                block1_buffer[1] = 0x00; //��������                                               
                                block1_buffer[2] = 0x00;                                                
                                block1_buffer[3] = 0x00;                                                
                                block1_buffer[4] = 0x00;                                               
                                block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������                                               
                                block1_buffer[6] = MIFARE_card_info.SNR[2];                                               
                                block1_buffer[7] = MIFARE_card_info.SNR[1];                                               
                                block1_buffer[8] = MIFARE_card_info.SNR[0];                                                
//                                block1_buffer[9] = time[4];//��                                                
//                                block1_buffer[10] = time[3];//��                                                
//                                block1_buffer[11] = time[2];//��                                                
//                                block1_buffer[12] = time[1];//ʱ                                                
//                                block1_buffer[13] = time[0];//��                                               
//                                block1_buffer[14] = 0;                                               
//                                block1_buffer[15] = 0;                                               
//                                block1_buffer[16] = 0;                                               
//                                block1_buffer[17] = 0;                                               
//                                block1_buffer[18] = 0;                                                
//                                block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x0A;//���� ��λΪcar 
//                                                                                           
//                                block1_buffer[20] = time[4];                                              
//                                block1_buffer[21] = time[3];                                                
//                                block1_buffer[22] = time[2];                                               
//                                block1_buffer[23] = time[1];                                                
//                                block1_buffer[24] = time[0];
//                                            
//                                block1_buffer[25] = CardType_MF1;//����ͨ��¼��־
//                                for(i=26;i<32;i++)                                                   
//                                  block1_buffer[i] = 0xAA;                                                
//                                Save_Record(block1_buffer,32);
								memcpy(TMP.cardno,block1_buffer+1,8);
								TMP.car = car;
								lcd_clear();	
#ifdef IN_MBSYSTEM //����43  �����ӵ���ʾ 2016-02-22
					print_XYstr_16_16(2,1,"Connecting...");
					print_XYstr_16_16(4,1,"Pls wait...");
					i = Send_CallRecord(1);
//					Connect failed/success
					lcd_clear();									
					if(i>0)
						print_XYstr_16_16(2,1,"Connect failed");
					else
						print_XYstr_16_16(2,1,"Connect success");
																		
#elif defined EN_MBSYSTEM
																		
#else
								dispaly(2,2,(HZ + lian));
								dispaly(2,3,(HZ + xi));
								dispaly(2,4,(HZ + zhong));
								dispaly(4,2,(HZ + qing));
								dispaly(4,3,(HZ + shao));
								dispaly(4,4,(HZ + hou));
								i = Send_CallRecord(1);
								lcd_clear();									
								dispaly(2,3,(HZ + lian));
								dispaly(2,4,(HZ + xi));
								if(i>0)
									{
									dispaly(2,5,(HZ + shi_3));
									dispaly(2,6,(HZ + bai));
									}
								else
									{
									dispaly(2,5,(HZ + cheng));
									dispaly(2,6,(HZ + gong_1));
									}
			
#endif
                                timeOut = 0;  
                                key_flag = 0;
                                while(timeOut < KEYTIMEOUT_1S * 2)                                          
                                {                                                                             
                                  if(key_flag){                                                                                
                                    key_flag = 0;
                                    delay(KEYTIMEOUT_1S * QUIT_TIME);
                                    break;                                                                            
                                  }                                                                             
                                  timeOut++;                         
                                }									
								}
                              else
                              {
                                //�ص�����ģ��ĵ�Դ Ϊ��ʡ��                                                                                  
                                Smart_Power_OFF;
                                                                                                        
                                OPEN_EXTI9_5_IRQ();                                                                                                                      
                                OPEN_EXTI15_10_IRQ();
                                
                                  car_outdate();
                                  timeOut = 0;
                                  while(timeOut < KEYTIMEOUT_1S * 1.5)
                                  {                                            
                                    if(key_flag){                                               
                                      key_flag = 0;       
                                      delay(KEYTIMEOUT_1S * QUIT_TIME);
                                      break;                                             
                                    }                                            
                                    timeOut++;
                                  }
                              }
                              break;
                          case MONTH_CARD:   
                              
                              //����Ҫ���� ���������ж�
                              for(i=0;i<4;i++)
                              {
                                  carSNR[i] = MIFARE_card_info.SNR[3-i];
                              }
                              balckList_flag = select_BlackList_from_Menmory_day(carSNR,MIFARE_FLAG,ADD);   //�жϿ��Ƿ��� ������
                              whiteList_flag = select_BlackList_from_Menmory_day(carSNR,MIFARE_FLAG,DEC); //�ռ��� �жϿ��Ƿ��� ������
                              if(balckList_flag > 0)
                              {
                                  if(whiteList_flag > 0)
                                    balckList_flag = 0;
                              }
                              
                              if(balckList_flag != NO )
                              {                    
                                  block2_buffer[0] = 0xf0;//�������ı�־
                                      
                                  //��׽��������
                                  if(write_comd(BLOCK2_ADDR,block2_buffer) == OK)//��׽�ɹ�
                                  {
                                      display_catch_backList(1);
                                  }
                                  else//��׽ʧ��
                                  {
                                      display_catch_backList(0);
                                  }                                    
                                  
                                  Smart_Power_OFF;
                                  
                                  Buzz_0;
                                  delay(KEYTIMEOUT_1S/10);
                                  Buzz_1;
                                  
                                  delay(KEYTIMEOUT_1S * 3);
                                  return 0;                   
                              }
                              
                              for(i=0;i<4;i++)
                              {
                                  card_no_buffer[i] = MIFARE_card_info.SNR[3 - i];                                                                              
                              }
                              
                              month_card_free_count = block1_buffer[0];               
                              month_card_max_count = block2_buffer[2];
                              
                              start_buffer[0] = block2_buffer[3];
                              start_buffer[1] = block2_buffer[4];
                              start_buffer[2] = block2_buffer[5];
                                  
                              end_buffer[0] = block2_buffer[6];
                              end_buffer[1] = block2_buffer[7];
                              end_buffer[2] = block2_buffer[8];
                                  
							  YXRQ[0] = 0x20;
							  YXRQ[1] = block2_buffer[10];
							  YXRQ[2] = block2_buffer[11];
							  YXRQ[3] = block2_buffer[12];
							  YXRQ[4] = 0x20;
							  YXRQ[5] = block2_buffer[13];
							  YXRQ[6] = block2_buffer[14];
							  YXRQ[7] = block2_buffer[15];

							  
                                  
                              display_month_card_F(card_no_buffer,block1_buffer+11,start_buffer,end_buffer,YXRQ);
                              timeOut = 0;                                                                                  
                              while(timeOut < KEYTIMEOUT_1S * 3)                                                                                
                              {                                
                                  if(key_flag){                                
                                      key_flag = 0;
                                      break;                                 
                                  }                              
                                  timeOut++;                                                 
                              }
                              return 0;
                            break;
							case OLDMANAGE_CARD:
								{
								Buzz_0; 	
								delay(KEYTIMEOUT_1S/10); 
								Buzz_1; 
								Smart_Power_OFF;
								lcd_clear();									
								dispaly(2,4,(HZ + qing));
				//				dispaly(2,4,(HZ + shi_1));
								dispaly(2,5,(HZ + yong));
								dispaly(3,3,(HZ + xin));
				//				dispaly(3,3,(HZ + fa));
								dispaly(3,4,(HZ + guan));
								dispaly(3,5,(HZ + li));
								dispaly(3,6,(HZ + ka));
								delay(KEYTIMEOUT_1S*2);
								OPEN_EXTI9_5_IRQ();
								OPEN_EXTI15_10_IRQ();
								return 0;
								}
                            case MANAGE_CARD:
								if(TMP.cardplace == CardType_ZGMF1RD)//�����
									{
									#ifndef ZG_MBSYSTEM
									disp_notsuse_card();
									return 0;
									#endif
									}
								else//���뿨
									{
									#ifdef ZG_MBSYSTEM
									disp_notsuse_card();
									return 0;
									#endif
									}
								
                              if(validity(block2_buffer,MANAGE_CARD) == OK)//����������Ч���� ���
                              {
								  Buzz_0;	  
								  delay(KEYTIMEOUT_1S/10); 
								  Buzz_1; 
                                  Smart_Power_OFF;
                                  OPEN_EXTI9_5_IRQ();
                                  OPEN_EXTI15_10_IRQ();
                                  uchar BCC = 0x00;
                                  for(i=0;i<16;i++)
								  	{
//									block2_buffer[i] = block2_buffer[i + 1];
									BCC = BCC ^ block2_buffer[i];
									}
                                  for(;i<25;i++)
								  	{
									block2_buffer[i] = block1_buffer[i-16];
									BCC = BCC ^ block2_buffer[i];
									}
								  block2_buffer[25] = BCC;
                                  
                                  I2C_WriteS_24C(B_startTime_unit_of_hour,block2_buffer,26);
                                  I2C_WriteS_24C(back_argument_of_charge,block2_buffer,26);
                                  
                                  
                                  manageCARD_update(); //��ʾ �����������
                                  delay(KEYTIMEOUT_1S * 2);
                              }
                              else
                              {
                                  car_outdate();
                                  delay(KEYTIMEOUT_1S * 2);
                              }
                              return 0;         
                              break;
                           case RECORD_CARD:
                              if(validity(block2_buffer,RECORD_CARD) == OK)//���ܿ�����Ч���� ���
                              {
                                  OPEN_EXTI9_5_IRQ();
                                  OPEN_EXTI15_10_IRQ();
                                  //RecordSendDown();
                                  I2C_WriteS_24C(SendInterval,block1_buffer,4);//���¼���ͻ��ƵĲ���
                                  I2C_WriteS_24C((SendInterval + 4),block1_buffer + 2,1);//���¼���ͻ��ƵĲ���
                                  I2C_WriteS_24C(BACK_TIME,block1_buffer + 4,4);//�汳�� ������ʱ��
                                  displaySendRecord();
                              }
                              else
                              {
                                  car_outdate();
                                  
                              }
                              delay(KEYTIMEOUT_1S * 4);
							  return 0;
                              break;
                            case ENCRYPT_CARD:
                              if(validity(block2_buffer,ENCRYPT_CARD) == OK)//���ܿ�����Ч���� ���
                              {
                                  OPEN_EXTI9_5_IRQ();
                                  OPEN_EXTI15_10_IRQ();
                                 // I2C_WriteS_24C(sysytem_public_key,block1_buffer,6);
                                  KEYCard_Process();
                                  encryptCARD_update(); //��ʾ ϵͳ��Կ�������
                                  delay(KEYTIMEOUT_1S * 2);
                              }
                              else
                              {
                                  car_outdate();
                                  delay(KEYTIMEOUT_1S * 2);
                              }
							  return 0;
                              break;
                           case CLEAR_CARD:
                            if(validity(block2_buffer,CLEAR_CARD) == OK)
                            {
                                OPEN_EXTI9_5_IRQ();
                                OPEN_EXTI15_10_IRQ();
                                Smart_Power_OFF;
                                ChipHalInit();
                                //��ʾ ���������...
                                data_clearing();
                                
                                //delay(KEYTIMEOUT_1S / 2);
                                
                                clear_FM_FLASH_reference();
                                //��ʾ ��¼����ɹ�
                                display_clear_success();
                                delay(KEYTIMEOUT_1S * 2);
                            }
                            else
                            {
                                car_outdate();
                                delay(KEYTIMEOUT_1S * 2);
                            }
                            return 0;
                            break;
						case  NETCTRL_CARD://�������ÿ�
							Smart_Power_OFF;							
							I2C_WriteS_24C(LISTNET_ADD,block2_buffer,16);
//							lcd_clear();
//							print_XYstr_16_16(2,1,"Net set OK!");
							lcd_clear();
#ifdef IN_MBSYSTEM //����24  �����ӵ���ʾ 2016-02-22
							print_XYstr_16_16(1,5,"Success");
#elif defined EN_MBSYSTEM
																					
#else
							dispaly(1,3,(HZ + cheng));
							dispaly(1,4,(HZ + gong_1));
#endif							
							//99 04 06 10 02 28 04 04 04 24
							I2C_ReadS_24C(LISTNET_ADD,buffer,16);//0-��־99 1- 2- 3-���ͼ��Ƶ�� 4- 5-Υ��ʱ��
							print_XYstr_16_16(3,5,"NET-P");
							goto_xy(0xA4,1);
							for(i=0;i<10;i++)
								print_num2(buffer[i]);	
							delay(KEYTIMEOUT_1S*3);
							OPEN_EXTI9_5_IRQ(); 									  
							OPEN_EXTI15_10_IRQ();
							return 0;
							break;
						case  MBNOSET_CARD://��������ÿ�
						case  TIMESET_CARD://ʱ�����ÿ�
							UpRecordFlag = PART_FH_UP;
						case  PDA_CARD_FHP://			 0xaa  //PDAͨ�ſ�flah��������
						case  PDA_CARD_FHA://			 0xab  //PDAͨ�ſ�flashȫ����
						case  PDA_CARD_FMP://			 0xac  //PDAͨ�ſ����粿������
						case  PDA_CARD_FMA://			 0xad  //PDAͨ�ſ�����ȫ����

								for(i=0;i<4;i++)
								  {
								  TMP.opcardno[i] = MIFARE_card_info.SNR[3-i];
								  }					//��˫�����ؿ�-------��δ����
//								if(car ==2)
								if(car ==92)
								{									
									{
										//���� ��һ�� ȷ�Ͻ��в������
										display_replaymenory(0x05);
									
										
										timeOut = 0;
										while(timeOut < KEYTIMEOUT_1S * 1)
											{
											if(key_flag == 0x02 || key_flag == 0x01)
												{
												key_flag = 0;
												break;
												}
											else if(key_flag == 0x03 || key_flag == 0x04)
												{
												key_flag = 0;
												return 0;
												}											
											else
											  timeOut++;	
											}									
										if(timeOut >= KEYTIMEOUT_1S * 1)
										  return 0; 

										Smart_Power_ON;

										display_please_operation(time1[4],time1[3],time1[2],time1[1],time1[0],0x16);	   
										//disp_cardfee(0x99); 
	
										timeOut = 0;   
										key_flag = 0;
										i = 4;
										while(i--)
										{
										while(timeOut < 300)	   
										{
											card_class_flag = inquire_card(&YWCardInfo);//��� ��������
											if(card_class_flag==CardType_CPCLOCK)
												{
												if(timeOut < 290)continue;
												write_card_error(0);
												delay(KEYTIMEOUT_1S*3);
												return 1;
												}
											if((card_class_flag==CardType_MF1)||
												(card_class_flag==CardType_BIKE)||
												(card_class_flag==CardType_CPC))
												{
												read_IC_card_flag = OK;
												break;
												}										
											if(key_flag != NO)
											{
											  key_flag = 0;
											  delay(KEYTIMEOUT_1S * QUIT_TIME);
												break;
											}										
											timeOut++;					
										}
										if(read_IC_card_flag==NG)
											{
											timeOut = 0;
											if(i>1)continue;
											disp_cardfee(3);
											delay(KEYTIMEOUT_1S*4);
											return 0;
											}
										break;
										}
										if(read_IC_card_flag == OK)    
										{								
											if(card_class_flag == CardType_BIKE)	
												{
												//��� TMP.feetime --
												//BIKECARD_PRO(car,0x99,&YWCardInfo); 
												return 0;
												}
											else if(card_class_flag == CardType_CPC)	
												{
												//��� TMP.feetime --
												//CPCCARD_PRO(car,0x99,&YWCardInfo);	
												if(YWCardInfo.YWParkInfo.ParkFlag==0)
													{
													return 0;
													}
												SubMoneyCMD YWTFEE;
												PosRecordInfo YWTFEER;
												u8 mbno[3],equ;
													
													//get_rate_ref(&RR_ST1); 
													//max_stop_time = RR_ST1.Max_Park_Time*60;
													QuitFlag = 0;
													I2C_ReadS_24C(mibiao_number,mbno,3);//�����
												
														YWTFEE.TradeDateTime[0] = 0x20;
														for(i=0;i<5;i++)
															YWTFEE.TradeDateTime[i+1] = time[4-i];
														YWTFEE.TradeDateTime[6] = 0x00;
														memcpy(YWTFEE.QBalance,YWCardInfo.Balance,4);
														memset(YWTFEE.Pays,0,4);
														//YWTFEE.ParkInfo
														YWTFEE.YWParkInfo.CardType = 0x60;
														YWTFEE.YWParkInfo.ParkFlag = 0x00;
														for(i=0;i<4;i++)
															YWTFEE.YWParkInfo.ParkDateTime[i] = time[3-i];//��//��//ʱ//��
														YWTFEE.YWParkInfo.UpdateFlag = 0x88;			
														YWTFEE.YWParkInfo.DongjieMoney[0] = 0x00;
														YWTFEE.YWParkInfo.DongjieMoney[1] = 0x00;//RR_ST1.Max_Stop_Momery;
														memset(YWTFEE.YWParkInfo.Res,0xCC,7);
														YWTFEE.YWParkInfo.Res[6] = car;
														memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ��� 		
														YWTFEE.YWParkInfo.ParkMBNO[0] = 0x66;
														memcpy(YWTFEE.YWParkInfo.ParkMBNO+1,mbno,3);
														YWTFEE.YWParkInfo.ParkInOutTime[0]= 0x20;
														for(i=0;i<5;i++)
															YWTFEE.YWParkInfo.ParkInOutTime[i+1] = time[4-i];//��//��//ʱ//��
														YWTFEE.YWParkInfo.ParkInOutTime[6]= 0x00;			
														YWTFEE.CardType = YWCardInfo.CardType;
														memcpy(YWTFEE.YYXLH,YWCardInfo.YYXLH,10);
												//			YWTFEE.CSDMType//���д�������?
														YWTFEE.CSDMType =2;
														memcpy(YWTFEE.NC,0,2);
														memcpy(YWTFEE.SHDM,0,2);
														YWTFEE.POS[0] = 0x66;
														memcpy(YWTFEE.POS+1,mbno,3);
														equ = YWT_FEE_PRO(&YWTFEE,&YWTFEER);//�۷ѳ���	
 													block1_buffer[0] = 0xEE;//��¼ͷ
													buffer[1] = 0;
													buffer[1] = 0;
													buffer[2] = 1;
													buffer[3] = YWCardInfo.YWParkInfo.DongjieMoney[0];
													buffer[4] = YWCardInfo.YWParkInfo.DongjieMoney[1];
													
												memcpy(buffer+5,YWCardInfo.snr,4);//��������	

												block1_buffer[5] = YWCardInfo.snr[3]; //��������
												block1_buffer[6] = YWCardInfo.snr[2];
												block1_buffer[7] = YWCardInfo.snr[1];
												block1_buffer[8] = YWCardInfo.snr[0];
												block1_buffer[9] = time[4];//��
												block1_buffer[10] = time[3];//��
												block1_buffer[11] = time[2];//��
												block1_buffer[12] = time[1];//ʱ
												block1_buffer[13] = time[0];//��
												block1_buffer[14] = YWCardInfo.Balance[2];
												block1_buffer[15] = YWCardInfo.Balance[1];
												block1_buffer[16] = YWCardInfo.Balance[0];
												block1_buffer[17] = 0;
												block1_buffer[18] = 0;
												block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x0E;//���� ��λΪcar
												
												block1_buffer[20] = time[4];
												block1_buffer[21] = time[3];
												block1_buffer[22] = time[2];
												block1_buffer[23] = time[1];
												block1_buffer[24] = time[0];
												
												block1_buffer[25] = CardType_MF1;
												
												for(int i=26;i<32;i++)
												   block1_buffer[i] = 0xAA; 
												for(int i=26;i<30;i++)
												   block1_buffer[i] = TMP.opcardno[i-26]; 
												
												Save_Record(block1_buffer,32);
												Buzz_0;
												delay(KEYTIMEOUT_1S/20);
												Buzz_1;
												Smart_Power_OFF;
												lcd_clear();
												dispaly(2,5,(HZ + cheng));
												dispaly(2,6,(HZ + gong_1));
												
												timeOut = 0;								
												while(timeOut < KEYTIMEOUT_1S * 2)							 
												{								 
													if(key_flag){								 
													  //key_flag = 0;																			  
													  delay(KEYTIMEOUT_1S * QUIT_TIME);
													  break;
													}							   
													timeOut++;
												}
												
												
												return 0;
												}
											
											else if(card_class_flag == CardType_MF1)
											{
												uchar flag_buffer[1];
												//uchar ReMoneryF;
												//uchar ReBlockF;
												//uchar select_momery_buffer[4];
												//unsigned long select_momery;
												read_MIFARE_card(&MIFARE_card_info);  //��ȡmifare������Ϣ
												  for(i=0;i<4;i++)
													  cardno_err[i] = MIFARE_card_info.SNR[i];
												  //���ܺ����в�������
												MF1key_main(MIFARE_card_info.SNR,MIFARE_password_buffer);	  //��ȡMIFARE������Կ
												timeOut = 0;
												while(testkey_comd(0x02,0x0a,MIFARE_password_buffer) != OK && timeOut < 20)
												{												  
													inquire_card(&YWCardInfo);
													if(card_class_flag==CardType_CPCLOCK)
														{
														write_card_error(0);
														delay(KEYTIMEOUT_1S*3);
														return 1;
														}
													read_MIFARE_card(&MIFARE_card_info);
													timeOut++;
												}
												
												if(timeOut < 20)
												{								
													if(read_comd(BLOCK0_ADDR,left_momery_buffer) == OK && read_comd(BLOCK1_ADDR,block1_buffer) == OK && read_comd(BLOCK2_ADDR,block2_buffer) == OK )
													{
														if((block2_buffer[0] == MIFARAE_PARK_CARD)||(block2_buffer[0] == MONTH_CARD))
														{
														   left_momery = left_momery_buffer[0] + left_momery_buffer[1] * 0x100 + left_momery_buffer[2] * 0x10000 + left_momery_buffer[3] * 0x1000000;
														   if(left_momery > 100000)
															  {
															  return 0x73;//���� ����
															  } 
														   if(left_momery_buffer[0] + left_momery_buffer[4] !=0xff ||
															  left_momery_buffer[1] + left_momery_buffer[5] !=0xff ||
															  left_momery_buffer[2] + left_momery_buffer[6] !=0xff ||
															  left_momery_buffer[3] + left_momery_buffer[7] !=0xff)
															  {
															   //�����쳣
															   Smart_Power_OFF;
															   lcd_clear(); 													   
															   dispaly(2,3,(HZ + ka));//
															   dispaly(2,4,(HZ + yi_3));//
															   dispaly(2,5,(HZ + chang));// 														   
															   delay(KEYTIMEOUT_1S * 3);
															   return 0;
															   }
														   
	//													   if(TMP.feetime>=block2_buffer[1])//δ���㴦��
	//															;
														   for(i=0;i<4;i++)
															   MIFARE_card_info.SNR[i] = cardno_err[i];
														   if(block2_buffer[1] >= 0x01)//��δ�������
														   		{
														   		TMP.feetime = block2_buffer[1];
																TMP.unlockmny[0] = block2_buffer[7];
																TMP.unlockmny[1] = block2_buffer[8];
														   		block2_buffer[1] = 0;
																block2_buffer[7] = 0x00;
																block2_buffer[8] = 0x00;
																i =2;
																block2_buffer[i++] = time[3]; 
																block2_buffer[i++] = time[2];	
																block2_buffer[i++] = time[1];
																block2_buffer[i++] = time[0];  
																block2_buffer[i++] = 0x88;//time[4];		
																if(write_comd(BLOCK2_ADDR,block2_buffer) == OK)
																	{
																		OPEN_EXTI9_5_IRQ();
																		OPEN_EXTI15_10_IRQ();
														  
														  
																		Buzz_0;
																		delay(KEYTIMEOUT_1S/20);
																		Buzz_1;
																		
																		Smart_Power_OFF;
																		//2. ����д�� ��ǰͣ��ʱ��																																			
																	
																		//4. �油���¼
																		block1_buffer[0] = 0xEE;//��¼ͷ
																		block1_buffer[1] = 0x00; //��������
																		block1_buffer[2] = TMP.feetime;
																		block1_buffer[3] = TMP.unlockmny[0];
																		block1_buffer[4] = TMP.unlockmny[1];
																		block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
																		block1_buffer[6] = MIFARE_card_info.SNR[2];
																		block1_buffer[7] = MIFARE_card_info.SNR[1];
																		block1_buffer[8] = MIFARE_card_info.SNR[0];
																		block1_buffer[9] = time[4];//��
																		block1_buffer[10] = time[3];//��
																		block1_buffer[11] = time[2];//��
																		block1_buffer[12] = time[1];//ʱ
																		block1_buffer[13] = time[0];//��
																		block1_buffer[14] = left_momery_buffer[2];
																		block1_buffer[15] = left_momery_buffer[1];
																		block1_buffer[16] = left_momery_buffer[0];
																		block1_buffer[17] = 0;
																		block1_buffer[18] = 0;
																		block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x0E;//���� ��λΪcar
																		
																		block1_buffer[20] = time[4];
																		block1_buffer[21] = time[3];
																		block1_buffer[22] = time[2];
																		block1_buffer[23] = time[1];
																		block1_buffer[24] = time[0];
																	
																		block1_buffer[25] = CardType_MF1;
																		
																		for(int i=26;i<32;i++)
																		   block1_buffer[i] = 0xAA; 
																		for(int i=26;i<30;i++)
																		   block1_buffer[i] = TMP.opcardno[i-26]; 
																		
																		Save_Record(block1_buffer,32);
																		lcd_clear();
																		dispaly(2,5,(HZ + cheng));
																		dispaly(2,6,(HZ + gong_1));

																		timeOut = 0;								
																		while(timeOut < KEYTIMEOUT_1S * 2) 							 
																		{								 
																			if(key_flag){								 
																			  //key_flag = 0;																			  
																			  delay(KEYTIMEOUT_1S * QUIT_TIME);
																			  break;
																			}							   
																			timeOut++;
																		}
																	}
																	
 																
															
															}
															else
															{
																//�ص�����ģ��ĵ�Դ Ϊ��ʡ��							   
																Smart_Power_OFF;
																		
																//////////////////////////////////////////////////////////////
																block1_buffer[0] = 0x00; //��������
																block1_buffer[1] = 0x00;
																block1_buffer[2] = 0x00;
																block1_buffer[3] = 0x00;
																block1_buffer[4] = MIFARE_card_info.SNR[3];
																block1_buffer[5] = MIFARE_card_info.SNR[2];
																block1_buffer[6] = MIFARE_card_info.SNR[1];
																block1_buffer[7] = MIFARE_card_info.SNR[0];
																
																if( ReadReplenishmentNo(block1_buffer) == OK)
																{
																	left_momery = left_momery_buffer[0] + left_momery_buffer[1] * 0x100 + left_momery_buffer[2] * 0x10000 + left_momery_buffer[3] * 0x1000000;
																	if(left_momery > 100000)
																	{
																		return 0x73;//���� ����
																	} 
																	
																	if(left_momery > 0)//��ʾ �ϴοۿ� ���� ������ѽ��
																	{
																		momery = RR_ST1.Max_Stop_Momery * RR_ST1.Sale_Base;
																	}
																	else//��ʾ �ϴοۿ� ���� ��ȫ�����
																	{
																		I2C_ReadS_24C(ReplenishmentMonery,left_momery_buffer,4);
																		momery = left_momery_buffer[0] + left_momery_buffer[1] * 0x100 + left_momery_buffer[2] * 0x10000 + left_momery_buffer[3] * 0x1000000;																	   
																	}
																	
																	left_momery = left_momery + momery;
																	fll(momery,momery_buffer,4);
																	fll(left_momery,left_momery_buffer,4);
																	
																	Buzz_0;
																	delay(KEYTIMEOUT_1S/20);
																	Buzz_1;
														  
																	Smart_Power_OFF;
																	//2. ����д�� ��ǰͣ��ʱ��																																			
																	
																	flag_buffer[0] = 0x00;
																	I2C_WriteS_24C(ReplenMoneryFlag,flag_buffer,1);
																	I2C_WriteS_24C(ReplenBlockFlag,flag_buffer,1);
																	for(uchar i=0;i<8;i++)
																	  block1_buffer[i] = 0; 									 
																	I2C_WriteS_24C(ReplenishmentNo,block1_buffer,8);
																	I2C_WriteS_24C(ReplenishmentMonery,block1_buffer,4);
																	
																	//4. �油���¼
																	block1_buffer[0] = 0xEE;//��¼ͷ
																	block1_buffer[1] = 0x00; //��������
																	block1_buffer[2] = TMP.feetime;
																	block1_buffer[3] = TMP.unlockmny[0];
																	block1_buffer[4] = TMP.unlockmny[1];
																	block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
																	block1_buffer[6] = MIFARE_card_info.SNR[2];
																	block1_buffer[7] = MIFARE_card_info.SNR[1];
																	block1_buffer[8] = MIFARE_card_info.SNR[0];
																	block1_buffer[9] = time[4];//��
																	block1_buffer[10] = time[3];//��
																	block1_buffer[11] = time[2];//��
																	block1_buffer[12] = time[1];//ʱ
																	block1_buffer[13] = time[0];//��
																	block1_buffer[14] = left_momery_buffer[1];
																	block1_buffer[15] = left_momery_buffer[2];
																	block1_buffer[16] = left_momery_buffer[3];
																	block1_buffer[17] = momery_buffer[2];
																	block1_buffer[18] = momery_buffer[3];
																	block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x07;//���� ��λΪcar
																		
																	
																	block1_buffer[20] = time[4];//��
																	block1_buffer[21] = time[3];//��
																	block1_buffer[22] = time[2];//��
																	block1_buffer[23] = time[1];//ʱ
																	block1_buffer[24] = time[0];//��
																	
																	block1_buffer[25] = CardType_MF1;
																		
																	for(int i=26;i<32;i++)
																		block1_buffer[i] = 0xAA;							 
																	Save_Record(block1_buffer,32);
																		
																	//3. ��ʾ������ ������� ����ͣ�� ��ͣʱ��
																	replay_momery(momery,left_momery - momery,1); 
																}
																else
																{
																	//û�� δ�������
																	display_no_outstanding();
																}
																//////////////////////////////////////////////////////////////
																OPEN_EXTI9_5_IRQ(); 																   
																OPEN_EXTI15_10_IRQ();
																
																timeOut = 0;								
																while(timeOut < KEYTIMEOUT_1S * 3)								
																{								 
																  if(key_flag){ 							   
																	key_flag = 0;																			  
																	delay(KEYTIMEOUT_1S * QUIT_TIME);
																	break;
																  } 							 
																  timeOut++;
																}
															}
															
														}
														else
														{
															//�ص�����ģ��ĵ�Դ Ϊ��ʡ��							   
															Smart_Power_OFF;
																	
															OPEN_EXTI9_5_IRQ(); 																   
															OPEN_EXTI15_10_IRQ();
															//�������͵Ŀ�
														  
															//��ʾ �޿�Ч
															no_use_card(0);
															delay(KEYTIMEOUT_1S * 3);
															key_flag = 0;
															return 0;
														}
													}
													else
													{
														//���������ֵ ����
														no_use_card(2);
														delay(KEYTIMEOUT_1S * 3);		 
														key_flag = 0;
														return 0;
													}
												}
												else
												{
													//��Կ����
													no_use_card(1);
													delay(KEYTIMEOUT_1S * 3);		 
													key_flag = 0;
													return 0;
												}										  
											
											}
											
										}
										else
											{
											//û�ҵ��� �Զ��˳�
											//�ص�����ģ��ĵ�Դ Ϊ��ʡ��							   
											Smart_Power_OFF;														  
											OPEN_EXTI9_5_IRQ(); 																   
											OPEN_EXTI15_10_IRQ();
											}								
									}			
																
																return 0;
																}

								
//                              case PDA_CARD:
//                                if(validity(block2_buffer,PDA_CARD) == OK)//ͨ�ſ�����Ч���� ���
							i =1;
							if(i)
						  {
							  OPEN_EXTI9_5_IRQ();										
							  OPEN_EXTI15_10_IRQ();
							  Smart_Power_OFF;	
//							  Car_IMGIQ();
							  if(block2_buffer[0]==PDA_CARD_FHP)
								  UpRecordFlag = PART_FH_UP;
							  else if(block2_buffer[0]==PDA_CARD_FHA)
								  UpRecordFlag = ALL_FH_UP;
							  else if(block2_buffer[0]==PDA_CARD_FMP)
								  UpRecordFlag = PART_FM_UP;
							  else if(block2_buffer[0]==PDA_CARD_FMA)
								  UpRecordFlag = ALL_FM_UP;
							  UART4_IRQn_CTL(OFF);
							  
							  TMP.COM4 = 2;
							  ir_comm(OFF);
							  close_ir_comm();
							  if(Judge_MB_MODE()==0)//�м������2G4��Դ 2015-04-30 andyluo
								  {
								  open_ir_comm();
								  UART4_IRQn_CTL(ON);//�򿪳����������ж� 2015-04-29
								  Set_G24_BaseM();//����2.4Gģ����Ҫ���յĳ�������
								  }
							  return 0;
						  }

                            else
                            {
                                car_outdate();
                                delay(KEYTIMEOUT_1S * 2);
                            }
                            return 0;
                            break;
                            
                          case SELECT_CARD:
                            if(validity(block2_buffer,SELECT_CARD) == OK)//��ѯ������Ч���� ���
                            {
                                Check_System_Status();                                   
                            }
                            else
                            {
                                car_outdate();
                                delay(KEYTIMEOUT_1S * 2);
                            }
							return 0;
                            break;
                            
                          case IP_ADREES:
							  if(validity(block2_buffer,IP_ADREES) == OK)//��ѯ������Ч���� ���
								 {
								 #ifndef IN_MBSYSTEM
 			  					 I2C_WriteS_24C(APNuser_possword,left_momery_buffer,16);//��APN
 			 					 I2C_WriteS_24C(APNuser_possword+16,block1_buffer,16);//��APN
								 #else
								 I2C_WriteS_24C(APNuser_possword,block2_buffer+7,6);//��IP��
								 I2C_WriteS_24C(APNuser_possword+6,left_momery_buffer,16);//��APN
								 I2C_WriteS_24C(APNuser_possword+22,block1_buffer,16);//��APN
								 #endif
								 I2C_WriteS_24C(IPADrees,block2_buffer+1,6);//��IP��
//								 I2C_WriteS_24C(IPADrees,block0_buffer,6);//��IP��  ����
								 ip_setup(1);// IP���سɹ�	
								 u8 ip_buffer[10];
								 memcpy(ip_buffer,block2_buffer+1,6);
								 ip_setup(1);// IP���سɹ�		 
								 LCD_display_symbol(3,1,ip_buffer[0] / 100,0);
								 LCD_display_symbol(3,2,ip_buffer[0] / 10 % 10,0);
								 LCD_display_symbol(3,3,ip_buffer[0] % 10,0);				 
								 LCD_display_symbol(3,4,5,1);				 
								 LCD_display_symbol(3,5,ip_buffer[1] / 100,0);
								 LCD_display_symbol(3,6,ip_buffer[1] / 10 % 10,0);
								 LCD_display_symbol(3,7,ip_buffer[1] % 10,0);				 
								 LCD_display_symbol(3,8,5,1);				 
								 LCD_display_symbol(3,9,ip_buffer[2] / 100,0);
								 LCD_display_symbol(3,10,ip_buffer[2] / 10 % 10,0);
								 LCD_display_symbol(3,11,ip_buffer[2] % 10,0);				 
								 LCD_display_symbol(3,12,5,1);				 
								 LCD_display_symbol(3,13,ip_buffer[3] / 100,0);
								 LCD_display_symbol(3,14,ip_buffer[3] / 10 % 10,0);
								 LCD_display_symbol(3,15,ip_buffer[3] % 10,0);				 
								 goto_xy(0x06,1);
								 print_str_16_16("PORT");	 //�汾��	   
								 LCD_display_symbol(4,5,1,1);
								 LCD_display_symbol(4,7,ip_buffer[4] / 16 % 16,0);
								 LCD_display_symbol(4,8,ip_buffer[4] % 16,0);
								 LCD_display_symbol(4,9,ip_buffer[5] / 16 % 16,0);
								 LCD_display_symbol(4,10,ip_buffer[5] % 16,0);				   
								 }
							  else
								car_outdate();
							  NETSTATE = NETSTATE_CLOSE;								  
							  close_gprs_power();
							  Smart_Power_OFF;						 
							  delay(KEYTIMEOUT_1S * 3);
							  return 0;
							  break;
                          case IAP_CARD:
                              if(validity(block2_buffer,IAP_CARD) == OK)//IP������Ч���� ���
                              {
                                  lcd_clear();
                                  Smart_Power_OFF;
                                  if(block1_buffer[0] == 0x11)
                                  {
                                      //������������ģʽ
                                      dispaly(2,3,(HZ + qi_2));//��
                                      dispaly(2,4,(HZ + dong));
                                      dispaly(2,5,(HZ + sheng));      
                                      dispaly(2,6,(HZ + ji_1));
                                      
                                      DISABLE_EXTI15_10_IRQ();      
                                      DISABLE_EXTI9_5_IRQ();                   
                                      IAP_UpData(1);                   
                                      OPEN_EXTI9_5_IRQ();                                                                          
                                      OPEN_EXTI15_10_IRQ(); 
                                  }
                                  else
                                  {
                                      I2C_WriteS_24C(IAPUpdataClass,block1_buffer+1,3);//��IAP���� ���� 1  ʱ�� 2
                                      I2C_WriteS_24C(FreeClass,block1_buffer+4,3);//���ʸ��²���
                                      
                                      
                                      dispaly(2,3,(HZ + xia)); //��
                                      dispaly(2,4,(HZ + zai_1));//��
                                      dispaly(2,5,(HZ + cheng));//        
                                      dispaly(2,6,(HZ + gong_1));//
                                                                                
                                      delay(KEYTIMEOUT_1S * 3);
                                  }
                                  
                              }
                              else
                              {
                                  car_outdate();
                                  delay(KEYTIMEOUT_1S * 2);
                              }
							  return 0;
                              break;
						  case MOVE_CARD:
						  case TEST_CARD:
						  		Smart_Power_OFF;
								if((block2_buffer[1]==0x01)&&
									(block2_buffer[2]==0xEF)&&
									(block2_buffer[3]==0x11)&&
									(block2_buffer[4]==0xEF)&&
									(block2_buffer[5]==0x14)&&
									(block2_buffer[6]==0xEF))
									Car_IMGIQ();
								return 0;
								break;
                          case SELECT_RECORD_CARD:
                              if(validity(block2_buffer,SELECT_RECORD_CARD) == OK)//��ѯ������Ч���� ���
                              {
                                  Smart_Power_OFF;
                                  //��ʾ ��¼��ѯ �� ��ʾ
                                  #ifdef TWO_CAR
                                    displaySelectRecordAndInfo(2);
                                  #else
                                    displaySelectRecordAndInfo(4);
                                  #endif
                                  
                                  OPEN_EXTI9_5_IRQ();                                                                                  
                                  OPEN_EXTI15_10_IRQ();
                                  
                                  timeOut = 0;  
                                  key_flag = 0x00;
                                  while(timeOut < KEYTIMEOUT_1S * 3)                                         	                                    
                                  {                                            
                                                            
                                     if(key_flag){                                            	                                        
                                        delay(KEYTIMEOUT_1S * QUIT_TIME);                                        	                                        
                                        break;                                             	                                     
                                     }                                            	                                      
                                     timeOut++;                                         	                                    
                                  }
                                      
                                  if(key_flag != 0)
                                  {
                                      if(block2_buffer[1] >= 30)
                                        block2_buffer[1] = 30;
                                      
                                      SelectRecordToPrint1(block2_buffer[1]); 
                                  }
                                                             
                              }
                              else
                              {
                                  car_outdate();
                                  delay(KEYTIMEOUT_1S * 2);
                              }
							return 0;  
                      break;
                     case MIFARE_BACLK_CARD://�Է����ĺ�������
                        Smart_Power_OFF;
                        OPEN_EXTI9_5_IRQ();        
                        OPEN_EXTI15_10_IRQ();
                        
                        Buzz_0;
                        delay(KEYTIMEOUT_1S/10);
                        Buzz_1;
                        
                        display_backList();
                        delay(KEYTIMEOUT_1S * 3);
                        return 0;
                       break;
                
                      default:
					  	ERRCODE = 3;
                        break;                                                      
                     } //END switch    
                } //END read_com
                else
					{
					if(testkey_comd(0x02,0x0a,MIFARE_password_buffer) != OK)
						{
						if(!key_flagbk)
							{
							write_card_error(0);
							delay(KEYTIMEOUT_1S * 4);
							}
						return 0;
						}						
                    //����ʧ��
                    ERRCODE = 2;
					}                
            }
            else
				{		
				if(display_ICflag == 0xAA)//��Կ����  IC������2015-08-22
					{
					if(!key_flagbk)
						{
						write_card_error(0);
						delay(KEYTIMEOUT_1S * 4);
						}
					}
				//��Կ����
				if(!key_flagbk)
					{
					diplay_problem();
					delay(KEYTIMEOUT_1S * 4);
					}
                // ��Կ��ȡ����
                ERRCODE = 1;
				}  
		if(ERRCODE==0)return 0;
        }           
	}
   return 0; 
}

//��� ��ǰIC������Ч���� �Ƿ���� ��ǰʱ��
//���� 1 ����
//���� 0 С��
uchar check_IC_card_validity(u8 *buffer)
{
    uchar year;
    uchar month;
    uchar date;
    
    year = ((buffer[1] >> 4) & 0x0f) * 10 +(buffer[1] & 0x0f);
    month = ((buffer[2] >> 4) & 0x0f) * 10 +(buffer[2] & 0x0f);
    date = ((buffer[3] >> 4) & 0x0f) * 10 +(buffer[3] & 0x0f);
    
    if(year > time1[4])
    {
        return 1;
    }
    else if(year ==time1[4] && month >time1[3])
    {
        return 1;
    }
    else if(year == time1[4] && month == time1[3] && date > time1[2])
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
//����1-������Ѳ��� 0-��1
u8 JD_LOOP_Park(u8 car)
{
u8 flag_buffer[5],loop=0;
//�ж� �Ƿ�������ͣ��
	I2C_ReadS_24C((car1_no_S_flag + (car - 1) * 0x04),flag_buffer,1);											   
	flag_NO = flag_buffer[0];
	I2C_ReadS_24C((car1_no_S_flag + (car - 1) * 0x04) + 1,flag_buffer,1);											  
	flag_Momery = flag_buffer[0]; 
	flag_free = get_current_time(); //��ȡ ��ǰ�Ƿ��� ���ʱ��
	if((flag_NO == OK) && (flag_Momery == OK) && (flag_free == 1))//���ͣ���Ŀ��� �� �ϴ� ͣ���Ŀ�����ͬ
		{
	//	momery = RR_ST1.Frist_Money * RR_ST1.Sale_Base;
		loop = 1;
		}
	return loop;
}

void disp_money_YWT(u8 XX,u8 YY,u32 dispmny)
{
	u8 momery_thousand,momery_hundred,momery_ten;
	u8 momery_ge,momery_horn,momery_cents;
	u8 station;	
	u16 left_value,right_value;
	u32 mnynew = 0;

	mnynew = dispmny;
	
	left_value = mnynew/100;
	right_value = mnynew%100;
	momery_thousand = left_value/1000;
	momery_hundred = (left_value%1000)/100;
	momery_ten = (left_value/10)%10;
	momery_ge = left_value%10;
	momery_horn = right_value/10;
	momery_cents = right_value%10;		
	station = YY;	
	if(momery_thousand> 0)
		{
		LCD_display_symbol(XX,station++,momery_thousand,0);
		LCD_display_symbol(XX,station++,momery_hundred,0);
		LCD_display_symbol(XX,station++,momery_ten,0);
		}
	else if(momery_hundred > 0)
		{
		LCD_display_symbol(XX,station++,momery_hundred,0);		
		LCD_display_symbol(XX,station++,momery_ten,0);
		}
	else if(momery_ten > 0)
		LCD_display_symbol(XX,station++,momery_ten,0);	
	LCD_display_symbol(XX,station++,momery_ge,0);	 
	LCD_display_symbol(XX,station++,5,1); // .
	LCD_display_symbol(XX,station++,momery_horn,0);
	LCD_display_symbol(XX,station++,momery_cents,0);
	if(station%2)
		dispaly(XX,station/2+1,(HZ + yuan));
	else
		dispaly(XX,station/2+1,(HZ + yuan)); 
}
void disp_YWT_IMG(u8 dispflag)
{
u8 i,hour,min;
u32 timeout;

	Smart_Power_OFF;//�ص�����ģ��ĵ�Դ Ϊ��ʡ��
	OPEN_EXTI9_5_IRQ(); 									  
	OPEN_EXTI15_10_IRQ();	
	
	if((TMP.autofee == 1)&&(dispflag!=7))
		{
		;
		}
	else
		{
		Buzz_0;
		delay(KEYTIMEOUT_1S/20);
		Buzz_1;
		}
	lcd_clear();
	switch(dispflag)
		{
		case 0xE0:
		case 0xE1:
		case 0xE2:
		case 0xE3:
		case 0xE4:
		case 0xE5:
			dispaly(1,1,(HZ + ka));
			dispaly(1,2,(HZ + hao));
			LCD_display_symbol(1,5,1,1);
			goto_xy(0xA2,5);
			for(i=0;i<4;i++)
			print_num2(TMP.cardno[i]);
			
			zimo =1;
			switch(dispflag)
				{
//	01	δ����	   (��ʾ��δ����)
//	02	����
//	03	ͣ��	   (��ʾ����ͣ��)
//	04	��������   (��ʾ��������)
//3���жϿ�����������YYYYMMDD(�������������:��ʾ��δ����)
//4���жϿ�����Ч����YYYYMMDD(�������������:��ʾ���ѹ���)
				case 0xE0:
				case 0xE3:
					dispaly(3,3,(HZ + ka));
					dispaly(3,4,(HZ + wei));
					dispaly(3,5,(HZ + qi_2));
					dispaly(3,6,(HZ + yong));
					break;

				case 0xE1:
					dispaly(3,3,(HZ + ka));
					dispaly(3,4,(HZ + yi_2));
					dispaly(3,5,(HZ + ting));
					dispaly(3,6,(HZ + yong));
					break;
					
				case 0xE2:
					dispaly(3,3,(HZ + hei));
					dispaly(3,4,(HZ + ming));
					dispaly(3,5,(HZ + dan));
					dispaly(3,6,(HZ + ka));
					break;

				case 0xE4:
					dispaly(3,3,(HZ + ka));
					dispaly(3,4,(HZ + yi_2));
					dispaly(3,5,(HZ + guo));
					dispaly(3,6,(HZ + qi));
					break;	
					
				case 0xE5:
					dispaly(3,3,(HZ + wu_2));
					dispaly(3,4,(HZ + xiao));
					dispaly(3,5,(HZ + ka));
					break;	
				}
			zimo =0;
			
			dispaly(4,1,(HZ + yu));
			dispaly(4,2,(HZ + e));
			LCD_display_symbol(4,5,1,1);			
			disp_money_YWT(4,7,TMP.cardmny);	
			break;		
		case 1://��ʾ��λռ����
			carStation_using();
			break;
		case 2://����//��ʾ�������ѽ�� ���ۿ�	
			zimo =1;
			dispaly(1,3,(HZ + yu));
			dispaly(1,4,(HZ + e));
			dispaly(1,5,(HZ + bu_1));
			dispaly(1,6,(HZ + zu));
			zimo =0;
			
			dispaly(2,1,(HZ + ka));
			dispaly(2,2,(HZ + hao));
			LCD_display_symbol(2,5,1,1);
			if(TMP.cpc)
				{
				LCD_display_symbol(2,6,8,1);
				for(i=0;i<5;i++)
					LCD_display_no(2,i+4,BCDtoHex(TMP.cardno[i+3]));
				}
			else
				{
				min = BCDtoHex(TMP.cardno[4])&0x0f;
				LCD_display_symbol(2,8,min,0);
				for(i=2;i<5;i++)
					LCD_display_no(2,i+3,BCDtoHex(TMP.cardno[i+3]));
				}	

			dispaly(3,1,(HZ + xu));
			dispaly(3,2,(HZ + shou));
			dispaly(3,3,(HZ + fei));
			LCD_display_symbol(3,7,1,1);			
			disp_money_YWT(3,9,TMP.feemny);			
			dispaly(4,1,(HZ + yu));
			dispaly(4,2,(HZ + e));
			LCD_display_symbol(4,5,1,1);			
			disp_money_YWT(4,7,TMP.cardmny);					
			break;		
		case 3://�۷�ʧ�� 
			dispaly(2,2,(HZ + shou));
			dispaly(2,3,(HZ + fei));
			dispaly(2,4,(HZ + shi_3));
			dispaly(2,5,(HZ + bai));
			
			dispaly(4,2,(HZ + qing));
			dispaly(4,3,(HZ + chong));
			dispaly(4,4,(HZ + xin));	
			dispaly(4,5,(HZ + shua));	
			dispaly(4,6,(HZ + ka));				
			break;
		case 4://��ʾδ���� -�ϴ�ʹ�������ʱ��
			zimo =1;
			dispaly(1,3,(HZ + ka));
			dispaly(1,4,(HZ + wei));
			dispaly(1,5,(HZ + jie));
			dispaly(1,6,(HZ + suan));
			zimo =0;
			
			dispaly(2,1,(HZ + ka));
			dispaly(2,2,(HZ + hao));
			LCD_display_symbol(2,5,1,1);
			if(TMP.cpc)
				{
				LCD_display_symbol(2,6,8,1);
				for(i=0;i<5;i++)
					LCD_display_no(2,i+4,BCDtoHex(TMP.cardno[i+3]));
				}
			else
				{
				min = BCDtoHex(TMP.cardno[4])&0x0f;
				LCD_display_symbol(2,8,min,0);
				for(i=2;i<5;i++)
					LCD_display_no(2,i+3,BCDtoHex(TMP.cardno[i+3]));
				}

			dispaly(3,1,(HZ + shang));
			dispaly(3,2,(HZ + ci));
			LCD_display_symbol(3,5,1,1);			
			dispaly(3,4,(HZ + biao));
			dispaly(3,5,(HZ + hao));
			i =0;			
//			LCD_display_symbol(3,9,TMP.mbno[i] / 0x10,0);
//			LCD_display_symbol(3,10,TMP.mbno[i] % 0x10,0);
			LCD_display_symbol(3,11,TMP.mbno[i+1] / 0x10,0);
			LCD_display_symbol(3,12,TMP.mbno[i+1] % 0x10,0); 
			LCD_display_symbol(3,13,TMP.mbno[i+2] / 0x10,0);
			LCD_display_symbol(3,14,TMP.mbno[i+2] % 0x10,0); 
			LCD_display_symbol(3,15,TMP.mbno[i+3] / 0x10,0);
			LCD_display_symbol(3,16,TMP.mbno[i+3] % 0x10,0); 
			
			if(TMP.mbno[0]==0x02)
				dispaly(4,1,(HZ + zuo_1));
			else if(TMP.mbno[0]==0x03)
				dispaly(4,1,(HZ + you_1));

			i =0;
			LCD_display_symbol(4,6,TMP.time[i] / 0x10,0);
			LCD_display_symbol(4,7,TMP.time[i] % 0x10,0);
			LCD_display_symbol(4,8,6,1);	
			LCD_display_symbol(4,9,TMP.time[i+1] / 0x10,0);
			LCD_display_symbol(4,10,TMP.time[i+1] % 0x10,0); 
			
			LCD_display_symbol(4,12,TMP.time[i+2] / 0x10,0);
			LCD_display_symbol(4,13,TMP.time[i+2] % 0x10,0);
			LCD_display_symbol(4,14,1,1);	
			LCD_display_symbol(4,15,TMP.time[i+3] / 0x10,0);
			LCD_display_symbol(4,16,TMP.time[i+3] % 0x10,0);			
			break;
		case 5://���� ���ֵ
			zimo =1;
			dispaly(1,3,(HZ + yu));
			dispaly(1,4,(HZ + e));
			dispaly(1,5,(HZ + bu_1));
			dispaly(1,6,(HZ + zu));
			zimo =0;
			
			dispaly(2,1,(HZ + ka));
			dispaly(2,2,(HZ + hao));
			LCD_display_symbol(2,5,1,1);
			if(TMP.cpc)
				{
				LCD_display_symbol(2,6,8,1);
				for(i=0;i<5;i++)
					LCD_display_no(2,i+4,BCDtoHex(TMP.cardno[i+3]));
				}
			else
				{
				min = BCDtoHex(TMP.cardno[4])&0x0f;
				LCD_display_symbol(2,8,min,0);
				for(i=2;i<5;i++)
					LCD_display_no(2,i+3,BCDtoHex(TMP.cardno[i+3]));
				}

			
			zimo =1;			
			dispaly(3,3,(HZ + qing));
			dispaly(3,4,(HZ + chong_1));
			dispaly(3,5,(HZ + zhi_1));
			zimo =0;

			dispaly(4,1,(HZ + yu));
			dispaly(4,2,(HZ + e));
			LCD_display_symbol(4,5,1,1);			
			disp_money_YWT(4,7,TMP.cardmny);		
			break;
		case 6://��ʾ����������Ϣ
			dispaly(1,1,(HZ + ka));
			dispaly(1,2,(HZ + hao));
			LCD_display_symbol(1,5,1,1);
			if(TMP.cpc)
				{
				LCD_display_symbol(1,6,8,1);
				for(i=0;i<5;i++)
					LCD_display_no(1,i+4,BCDtoHex(TMP.cardno[i+3]));
				}
			else
				{
				min = BCDtoHex(TMP.cardno[4])&0x0f;
				LCD_display_symbol(1,8,min,0);
				for(i=2;i<5;i++)
					LCD_display_no(1,i+3,BCDtoHex(TMP.cardno[i+3]));
				}
			

			dispaly(2,1,(HZ + ting));
			dispaly(2,2,(HZ + che));
			LCD_display_symbol(2,5,1,1);
			hour = TMP.feetime/60;
			min = TMP.feetime%60;
			i=7;
			LCD_display_symbol(2,i++,hour / 10,0);
			LCD_display_symbol(2,i++,hour % 10,0);
			LCD_display_symbol(2,i++,1,1);
			LCD_display_symbol(2,i++,min / 10,0);
			LCD_display_symbol(2,i++,min % 10,0);
			
			dispaly(3,1,(HZ + shou));
			dispaly(3,2,(HZ + fei));
			LCD_display_symbol(3,5,1,1);			
			disp_money_YWT(3,7,TMP.feemny);	
			
			if(TMP.cpc)
				{
				dispaly(4,1,(HZ + yu));
				dispaly(4,2,(HZ + e));
				LCD_display_symbol(4,5,1,1);			
				disp_money_YWT(4,7,TMP.cardmny);	
				}
			break;		
		case 7://��ʾǷ�����������볡��Ϣ		
		case 8://��ʾ�������볡��Ϣ	
		case 9://��ʾ�볡��Ϣ
		case 10://��ʾ�볡��Ϣ
			dispaly(1,1,(HZ + ka));
			dispaly(1,2,(HZ + hao));
			LCD_display_symbol(1,5,1,1);
			if(TMP.cpc)
				{
				LCD_display_symbol(1,6,8,1);
				for(i=0;i<5;i++)
					LCD_display_no(1,i+4,BCDtoHex(TMP.cardno[i+3]));
				if((dispflag!=7)&&(dispflag!=8))
					{
					dispaly(2,1,(HZ + ke));
					dispaly(2,2,(HZ + ting));
					LCD_display_symbol(2,5,1,1);
					hour = TMP.feetime/60;
					min = TMP.feetime%60;
					i=7;
					LCD_display_symbol(2,i++,hour / 10,0);
					LCD_display_symbol(2,i++,hour % 10,0);
					LCD_display_symbol(2,i++,1,1);
					LCD_display_symbol(2,i++,min / 10,0);
					LCD_display_symbol(2,i++,min % 10,0);
					}
				}
			else
				{
				min = BCDtoHex(TMP.cardno[4])&0x0f;
				LCD_display_symbol(1,8,min,0);
				for(i=2;i<5;i++)
					LCD_display_no(1,i+3,BCDtoHex(TMP.cardno[i+3]));
				dispaly(3,1,(HZ + ke));
				dispaly(3,2,(HZ + ting));
				LCD_display_symbol(3,5,1,1);
				hour = TMP.feetime/60;
				min = TMP.feetime%60;
				i=7;
				LCD_display_symbol(3,i++,hour / 10,0);
				LCD_display_symbol(3,i++,hour % 10,0);
				LCD_display_symbol(3,i++,1,1);
				LCD_display_symbol(3,i++,min / 10,0);
				LCD_display_symbol(3,i++,min % 10,0);
				}

			if((dispflag==7)||(dispflag==8))
				{
				zimo =1;
				dispaly(3,1,(HZ + bu));
				dispaly(3,2,(HZ + kuan));
				LCD_display_symbol(3,5,1,1);			
				disp_money_YWT(3,7,TMP.feemny);	
				zimo =0;
				}	
			
			if(TMP.cpc)
				{
				dispaly(4,1,(HZ + yu));
				dispaly(4,2,(HZ + e));
				LCD_display_symbol(4,5,1,1);			
				disp_money_YWT(4,7,TMP.cardmny);	
				}
			break;
//		case 9:
//		case 10:
//			break;
		case 0xC1:
		case 11://��ʾ��������
			#ifdef IN_MBSYSTEM //����3
			print_XYstr_16_16(1,1,"No.kartu:");
			#else
			dispaly(1,1,(HZ + ka));
			dispaly(1,2,(HZ + hao));
			LCD_display_symbol(1,5,1,1);
			#endif
			if(dispflag==0xC1)
				{
				goto_xy(0xA2,4);
				for(i=0;i<4;i++)
//					LCD_display_no(2,i+4,(TMP.cardno[i]));
				print_num2(TMP.cardno[i]);
				}
			else if(TMP.cpc)
				{
				LCD_display_symbol(1,6,8,1);
				for(i=0;i<5;i++)
					LCD_display_no(1,i+4,BCDtoHex(TMP.cardno[i+3]));
				}
			else
				{
				min = BCDtoHex(TMP.cardno[4])&0x0f;
				LCD_display_symbol(1,8,min,0);
				for(i=2;i<5;i++)
					LCD_display_no(1,i+3,BCDtoHex(TMP.cardno[i+3]));
				}
			//The blacklist card
			
			zimo =1;
			#ifdef IN_MBSYSTEM //����3
			print_XYstr_16_16(3,2,"Blacklist card");
			#else
			dispaly(3,2,(HZ + hei));
			dispaly(3,3,(HZ + ming));
			dispaly(3,4,(HZ + dan));
			dispaly(3,5,(HZ + ka));
			#endif
			zimo =0;
			
			if(TMP.cpc)
				{
				#ifdef IN_MBSYSTEM //����3
				u8 momery_hundred,momery_ten,momery_ge;
				u8 momery_horn,momery_cents,station;
				int left_value,right_value;
				
				print_XYstr_16_16(4,1,"Balance Rp");
				left_value = TMP.cardmny / 100;
				right_value = TMP.cardmny % 100;
				momery_hundred = left_value / 100;
				momery_ten = (left_value / 10) % 10;
				momery_ge = left_value % 10;
				momery_horn = right_value / 10;
				momery_cents = right_value % 10;
				station = 11;
				if(momery_hundred!=0)
					LCD_display_symbol(4,station++,momery_hundred,0);	
				LCD_display_symbol(4,station++,momery_ten,0);
				LCD_display_symbol(4,station++,momery_ge,0);
				 
				LCD_display_symbol(4,station++,5,1); // .
				LCD_display_symbol(4,station++,momery_horn,0);
				LCD_display_symbol(4,station++,momery_cents,0);
				LCD_display_symbol(4,station++,0,0);
//				disp_money_YWT(4,7,TMP.cardmny);	
				#else
				dispaly(4,1,(HZ + yu));
				dispaly(4,2,(HZ + e));
				LCD_display_symbol(4,5,1,1);			
				disp_money_YWT(4,7,TMP.cardmny);	
				#endif
				}
			break;
		case 12:
			dispaly(3,1,(HZ + qing));
			dispaly(3,2,(HZ + lian));
			dispaly(3,3,(HZ + xi));
			dispaly(3,4,(HZ + guan));
			dispaly(3,5,(HZ + li));
			dispaly(3,6,(HZ + gong));
			dispaly(3,7,(HZ + si_1));
			break;
		case 13:
			dispaly(3,3,(HZ + xie));
			dispaly(3,4,(HZ + ka));
			dispaly(3,5,(HZ + cheng));
			dispaly(3,6,(HZ + gong_1));
			break;
		case 0xC5:
		case 14://��ʾ���Ͳ�ʱ-������	
		case 15://��ʾ���Ͳ�ʱ-������			
			zimo =1;
			dispaly(1,4,(HZ + bu));
			if(dispflag==14)
				dispaly(1,5,(HZ + kuan));
			else if((dispflag==15)|(dispflag==0xC5))
				dispaly(1,5,(HZ + shi));			
			dispaly(1,6,(HZ + cheng));
			dispaly(1,7,(HZ + gong_1));
			zimo =0;
			
			dispaly(2,1,(HZ + ka));
			dispaly(2,2,(HZ + hao));
			LCD_display_symbol(2,5,1,1);
			if(TMP.cpc)
				{
				if(dispflag==0xC5)
					{
					for(i=0;i<4;i++)
						LCD_display_no(2,i+4,BCDtoHex(TMP.cardno[i]));
					}
				else
					{
					LCD_display_symbol(2,6,8,1);
					for(i=0;i<5;i++)
						LCD_display_no(2,i+4,BCDtoHex(TMP.cardno[i+3]));
					}
				}
			else
				{
				min = BCDtoHex(TMP.cardno[4])&0x0f;
				LCD_display_symbol(2,8,min,0);
				for(i=2;i<5;i++)
					LCD_display_no(2,i+3,BCDtoHex(TMP.cardno[i+3]));
				}	
		
			dispaly(3,1,(HZ + yi_2));
			dispaly(3,2,(HZ + bu));
			dispaly(3,3,(HZ + kuan));
			LCD_display_symbol(3,7,1,1);			
			disp_money_YWT(3,9,TMP.feemny); 
			
			if(TMP.cpc)
				{
				dispaly(4,1,(HZ + yu));
				dispaly(4,2,(HZ + e));
				LCD_display_symbol(4,5,1,1);			
				disp_money_YWT(4,7,TMP.cardmny);
				}
			break;	
		case 16://���ܲ��� 
			zimo =1;
			dispaly(1,4,(HZ + bu_1));
			dispaly(1,5,(HZ + ke));
			dispaly(1,6,(HZ + bu));
			dispaly(1,7,(HZ + kuan));
			zimo =0;
			
			dispaly(2,1,(HZ + ka));
			dispaly(2,2,(HZ + hao));
			LCD_display_symbol(2,5,1,1);
			if(TMP.cpc)
				{
				LCD_display_symbol(2,6,8,1);
				for(i=0;i<5;i++)
					LCD_display_no(2,i+4,BCDtoHex(TMP.cardno[i+3]));
				}
			else
				{
				min = BCDtoHex(TMP.cardno[4])&0x0f;
				LCD_display_symbol(2,8,min,0);
				for(i=2;i<5;i++)
					LCD_display_no(2,i+3,BCDtoHex(TMP.cardno[i+3]));
				}			

//			dispaly(3,1,(HZ + fu));
//			dispaly(3,2,(HZ + wei_1));			
//			i =0;
//			LCD_display_symbol(3,6,TMP.mbno[i] / 0x10,0);
//			LCD_display_symbol(3,7,TMP.mbno[i] % 0x10,0);
//			LCD_display_symbol(3,8,6,1);	
//			LCD_display_symbol(3,9,TMP.mbno[i+1] / 0x10,0);
//			LCD_display_symbol(3,10,TMP.mbno[i+1] % 0x10,0); 
//			
//			LCD_display_symbol(3,12,TMP.mbno[i+2] / 0x10,0);
//			LCD_display_symbol(3,13,TMP.mbno[i+2] % 0x10,0);
//			LCD_display_symbol(3,14,1,1);	
//			LCD_display_symbol(3,15,TMP.mbno[i+3] / 0x10,0);
//			LCD_display_symbol(3,16,TMP.mbno[i+3] % 0x10,0);	

			dispaly(3,1,(HZ + yu));
			dispaly(3,2,(HZ + e));
			LCD_display_symbol(3,5,1,1);			
			disp_money_YWT(3,7,TMP.cardmny);	

			dispaly(4,1,(HZ + shang));
			dispaly(4,2,(HZ + ci));			
			i =1;
			LCD_display_symbol(4,6,TMP.time[i] / 0x10,0);
			LCD_display_symbol(4,7,TMP.time[i] % 0x10,0);
			LCD_display_symbol(4,8,6,1);	
			LCD_display_symbol(4,9,TMP.time[i+1] / 0x10,0);
			LCD_display_symbol(4,10,TMP.time[i+1] % 0x10,0); 
			
			LCD_display_symbol(4,12,TMP.time[i+2] / 0x10,0);
			LCD_display_symbol(4,13,TMP.time[i+2] % 0x10,0);
			LCD_display_symbol(4,14,1,1);	
			LCD_display_symbol(4,15,TMP.time[i+3] / 0x10,0);
			LCD_display_symbol(4,16,TMP.time[i+3] % 0x10,0);	
			break;	
		case 100:
			print_XYstr_16_16(2,4,"proing...");
			print_XYstr_16_16(4,4,"pls wait...");
			break;
			
		}
	beep(1);
	beep(1);
	timeout = KEYTIMEOUT_1S * 3;
	
	if((TMP.autofee == 1)&&(dispflag==7))
		timeout = KEYTIMEOUT_1S * 1.5;
	
	while(timeout--)
		{
		if(key_flag)
			{
			key_flag = 0;
			delay(KEYTIMEOUT_1S * QUIT_TIME);
			break;
			}
	   }
}

/*
//���񿨲������� 2015-07-18
//space-��λ�� IQflag-˫����ѯ��־
//spacestate;//66-�볡 0- ����  88-��ʱ  99-�˹�����  AA-д�벹����(����)
void CPCCARD_PRO_WLT(u8 space,u8 spacestate,CardInfo *YWT)
{
s32 equ;
u32 cardmoney,pktime=0,jdpktime,pkmoney,pkmnyold,pkmnybk,max_stop_time,snno;
u8 i,car,carst,cardst,feeflag,swipng;//1-ˢ���쳣 0-����
u8 mbno[3],mnybuf[4],buffer[32],record[100];
u8 falseinout;//1(5)-(��)�볡 2(6)-(��)���� 3-������ 
			// 4 -Ƿ���������� 7-δ�ۿ���� F-������¼
SubMoneyCMD YWTFEE;
PosRecordInfo YWTFEER;
carStation_reference_of_used CS_RF_US;
	
	get_rate_ref(&RR_ST1); 
	max_stop_time = RR_ST1.Max_Park_Time*60;
	QuitFlag = 0;
	I2C_ReadS_24C(mibiao_number,mbno,3);//�����
	car = space;//��λ��
	carst = spacestate;//66-�볡 0- ����  88-��ʱ  99-����
	cardst = YWT->YWParkInfo.ParkFlag;	
	if((YWT->YWParkInfo.CardType != 0x60)||
		(YWT->YWParkInfo.UpdateFlag != 0x88))
		cardst = 0;//�¿�Ĭ��Ϊ����ģʽ 2015-08-05	
	cardmoney = hcl(YWT->Balance,4);	
	//д����/�쳣ˢ���ı�־ 2015-08-06
	I2C_ReadS_24C(Car1_SwipNG+car-1,buffer,1);	
	swipng = buffer[0];	
	read_car_reference_of_use_info(&CS_RF_US,car);//����λ״̬��Ϣ	

//	memcpy(YWTFEE.YWParkInfo.ParkMBNO+1,mbno,3);
	if((mbno[0]!=YWT->YWParkInfo.ParkMBNO[1])||
	   (mbno[1]!=YWT->YWParkInfo.ParkMBNO[2])||
	   (mbno[2]!=YWT->YWParkInfo.ParkMBNO[3]))
	   swipng = 0;//�Ǽٽ���ٳ� 2015-09-02


//�������ж�˳�� ����--����--ȫ��
//	equ = SelectList_SRAM(YWT->YYXLH,ListType_CPCDEL,buffer);
//	if(equ<0)
//		{//���ڼ�����
//		equ = SelectList_SRAM(YWT->YYXLH,ListType_CPCADD,buffer);
//		if(equ<0)
//			{//����������
//			equ = SelectList_SRAM(YWT->YYXLH,ListType_CPCALL,buffer);
//			}
//		if((equ>=0)||(YWT->HMDBS))
//			{
//			falseinout = 0x0F;//������¼��־
//			TMP.cardmny = cardmoney;
//			memcpy(TMP.cardno,YWT->YYXLH,8);
//			disp_YWT_IMG(11);//��ʾ��������
//			return;
//			//�������������� 2015-08-24
//			}
//		}		

	TMP.cpc = 1;
	TMP.autofee = 0;
//	cardmoney = 601;

#ifdef Test_RealCPC //F57115BE//ԭ���8.55Ԫ  �����4Ԫ
	TMP.cardmny = 855;//
	cardmoney = 855;
	cardst = 0;	
	pkmoney = 400;//hcl(YWT->YWParkInfo.FEEMNY,3);
	fll(pkmoney,YWT->YWParkInfo.FEEMNY,3);
	
#endif

#ifdef disp_test_YWT
		TMP.cardmny = cardmoney;
		TMP.feemny = 2050;
		memcpy(TMP.cardno,YWT->YYXLH,8);
		disp_YWT_IMG(2);
		disp_YWT_IMG(1);
#endif
#ifdef disp_test_YWTOUT
		carst = 0x66;
		cardst = 1;
		equ = OK;
#define testYWT
#endif
#ifdef disp_test_YWTIN
		carst = 0x00;
		cardst = 0;
		disp_YWT_IMG(4);
#endif
	//���� ��ʱ ���� Ƿ�Ѳ������� 2015-08-11
//=========��λ��ʱ=========
//=========��λ����=========
//=========��λǷ��=========
	if((carst == 0x88)||//��ʱ -7
		(carst == 0x99)||//����  -E
		(carst == 0xAA))//Ƿ�� ����
		{
		if(carst == 0x88)//��ʱ  -E
			{
			if(cardst==1)
				{
				memcpy(TMP.cardno,YWT->YYXLH,8);
				memcpy(TMP.time,YWT->YWParkInfo.ParkDateTime,4);
				memcpy(TMP.mbno,YWT->YWParkInfo.ParkMBNO,4);	
				TMP.mbno[0] = YWT->YWParkInfo.Res[6];
				disp_YWT_IMG(4);
				return;
				}
			}
		else if(carst == 0x99)//����
			{
			//�Ƚ� TMP.time��YWT->YWParkInfo.ParkDateTime�Ĵ�С 
			//����ʱ��С�� ��λʱ�� ���ܲ��� 
			memcpy(buffer+1,YWT->YWParkInfo.ParkDateTime,4);
			buffer[0] = TMP.time[0];
			if(((TMP.time[1]==0x01)&&(buffer[1]==0x12))||//����
				(TMP.time[1]>buffer[1])||//MMDDHHMM
				((TMP.time[1]==buffer[1])||(TMP.time[2]>buffer[2]))||
				((TMP.time[1]==buffer[1])||(TMP.time[2]==buffer[2])||(TMP.time[3]>buffer[3]))||
				((TMP.time[1]==buffer[1])||(TMP.time[2]==buffer[2])||(TMP.time[3]==buffer[3])||(TMP.time[4]>=buffer[4])))
				;
			else//����ʱ��>��λʱ��
				{
				TMP.cardmny = cardmoney;
				memcpy(TMP.cardno,YWT->YYXLH,8);
				memcpy(TMP.time,YWT->YWParkInfo.ParkDateTime,4);
//				memcpy(TMP.mbno,YWT->YWParkInfo.ParkMBNO,4);			
//				memcpy(TMP.mbno,YWT->YWParkInfo.ParkDateTime,4);			
				disp_YWT_IMG(16);//��ʾ���ܲ���
				return;
				}
			}
		falseinout = carst;
#ifdef proing
		disp_YWT_IMG(100);
		return;
#endif		
		pkmoney =TMP.feemny;

	
		if(pkmoney>cardmoney)//����
			{//��ʾ�������ѽ�� ���ۿ�
			TMP.cardmny = cardmoney;
			TMP.feemny = pkmoney;
			memcpy(TMP.cardno,YWT->YYXLH,8);
			disp_YWT_IMG(2);
			return;
			}
		
		if(carst == 0xAA)//δ�ۿ����  Ƿ�Ѳ���
			{
			fll(pkmoney,mnybuf,4);
			memcpy(YWTFEE.YWParkInfo.FEEMNY,mnybuf+1,3);//δ�۷ѳ���		
			pkmoney = 0;
			}
		else
			memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ��� 		

#ifdef testYWTmny
		pkmoney /= 100;//����ʱ�۷�-1
#else
#ifdef testYWTmny_10
		pkmoney /= 10;//����ʱ�۷�-1
#endif
#endif
		fll(pkmoney,mnybuf,4);

		YWTFEE.TradeDateTime[0] = 0x20;
		for(i=0;i<5;i++)
			YWTFEE.TradeDateTime[i+1] = time[4-i];
		YWTFEE.TradeDateTime[6] = 0x00;
		memcpy(YWTFEE.QBalance,YWT->Balance,4);
		memcpy(YWTFEE.Pays,mnybuf,4);
		//YWTFEE.ParkInfo
		YWTFEE.YWParkInfo.CardType = 0x60;
		YWTFEE.YWParkInfo.ParkFlag = 0x00;
		for(i=0;i<4;i++)
			YWTFEE.YWParkInfo.ParkDateTime[i] = time[3-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.UpdateFlag = 0x88;			
		YWTFEE.YWParkInfo.DongjieMoney[0] = 0x00;
		YWTFEE.YWParkInfo.DongjieMoney[1] = 0x00;//RR_ST1.Max_Stop_Momery;
		memset(YWTFEE.YWParkInfo.Res,0xCC,7);
		YWTFEE.YWParkInfo.Res[6] = car;
//		memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ��� 		
		YWTFEE.YWParkInfo.ParkMBNO[0] = 0x66;
		memcpy(YWTFEE.YWParkInfo.ParkMBNO+1,mbno,3);
		YWTFEE.YWParkInfo.ParkInOutTime[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.ParkInOutTime[i+1] = time[4-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.ParkInOutTime[6]= 0x00;			
		YWTFEE.CardType = YWT->CardType;
//		memcpy(YWTFEE.YYXLH,YWT->CSDMType,2);
		memcpy(YWTFEE.YYXLH+2,YWT->YYXLH,8);
//			YWTFEE.CSDMType//���д�������?
		YWTFEE.CSDMType =2;
		memcpy(YWTFEE.NC,0,2);
		memcpy(YWTFEE.SHDM,0,2);
		YWTFEE.POS[0] = 0x66;
		memcpy(YWTFEE.POS+1,mbno,3);
		equ = YWT_FEE_PRO(&YWTFEE,&YWTFEER);//�۷ѳ���	
		if(equ!=1)
			{
//			buffer[0]= 1;
//			//д����/�쳣ˢ���ı�־ 2015-08-06
//			I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
			if(QuitTime>=4)
				{
				disp_YWT_IMG(3);	
				QuitFlag = 0;
				}
			else
				QuitFlag = 1;
			memset(buffer,0,8); 	
			write_momery_to_Fm(buffer,car);
			return;
			}
		if(carst == 0xAA)//δ�ۿ����  Ƿ�Ѳ���
			{
			disp_YWT_IMG(13);
			return;
			}
		//1. �油ʱ-�����¼ 
		buffer[0] = 0xEE;//��¼ͷ
		
		if(carst == 0x99)//����
			{
			buffer[1] = 0;
			buffer[2] = 1;
			buffer[3] = YWT->YWParkInfo.DongjieMoney[0];
			buffer[4] = YWT->YWParkInfo.DongjieMoney[1];
			}			
		else if(carst == 0x88)//��ʱ
			memset(buffer+1,0,4);//�������� 
			
		memcpy(buffer+5,YWT->snr,4);//��������	
//		memcpy(buffer+1,YWT->YYXLH,8);//��������	
//		buffer[9] = time[4];//��
//		memcpy(buffer+10,YWT->YWParkInfo.ParkDateTime,4);//��//��//ʱ//��
		if(carst == 0x99)//����
			{
			for(i=0;i<5;i++)
				buffer[9+i] = time[4-i];
			}
		else if(carst == 0x88)//��ʱ
			{
			for(i=0;i<5;i++)
				buffer[9+i] = TMP.time[4-i];
			}
		buffer[14] = cardmoney>>16;//
		buffer[15] = cardmoney>>8;//
		buffer[16] = cardmoney;//
		buffer[17] = mnybuf[2];
		buffer[18] = mnybuf[3];
		if(carst == 0x99)//����
			{
			buffer[19] = ((car+CAR_CLASS)<<4) + 0x07;//���� ��λΪcar 
			bushimny[car] = 0;   
			bukanmny[car] = 0;	
			TMP.CPC_ckmny[car] = 0;
			}
		else if(carst == 0x88)//��ʱ
			buffer[19] = ((car+CAR_CLASS)<<4) + 0x0E;//��ʱ ��λΪcar 
		for(i=0;i<5;i++)
			buffer[20+i] = time[4-i];
		buffer[25] = CardType_CPC;//CPC��¼��־		
		for(i=26;i<32;i++)buffer[i] = 0xAA;
		for(i=26;i<30;i++)buffer[i] = TMP.opcardno[i-26];
		Save_Record(buffer,32);
		//����ͨ�ļ�¼	�����ļ�¼	
		//���˼�¼-2015-07-30 YWTFEER
		YWTFEER.RecFlag = 0;
		YWTFEER.Monthtype = 0;
		YWTFEER.Monthflag = 0;
		memcpy(YWTFEER.Cardno,YWT->snr,4);//��������
		YWTFEER.FeeFlag = falseinout;//1(5)-(��)�볡 2(6)-(��)���� 3-������ 4 -Ƿ����������
		I2C_ReadS_24C(SYS_SN,buffer,4);
		snno=hcl(buffer,4);
		snno += 1;
		fll(snno,buffer,4);
		I2C_WriteS_24C(SYS_SN,buffer,4);
		memcpy(YWTFEER.Sn,buffer+1,3);//��ˮ�ź�
		memset(YWTFEER.Res,0xff,4);//����		
		memcpy(record,RxBuffer+5,65);
		memcpy(record+65,&YWTFEER.RecFlag,1);
		memcpy(record+66,&YWTFEER.Monthtype,1);
		memcpy(record+67,&YWTFEER.Monthflag,1);
		memcpy(record+68,YWTFEER.Cardno,4);
		memcpy(record+72,&YWTFEER.FeeFlag,1);
		memcpy(record+73,YWTFEER.Sn,3);
		memcpy(record+76,YWTFEER.Res,4);		
		Save_Record(record,80);	
		TMP.cardmny = cardmoney-pkmoney;
		TMP.feemny = pkmoney;
		TMP.feetime = pktime;		
		memcpy(TMP.cardno,YWT->YYXLH,8);
		if(carst == 0x99)//����
			disp_YWT_IMG(14);//����-��ʱ�ɹ�		
		else if(carst == 0x88)//��ʱ
			disp_YWT_IMG(15);//����-��ʱ�ɹ�		
		return;
		}
//=========��λռ��=========
//=========��λռ��=========
//=========��λռ��=========
//=========��λռ��=========
	else if(carst == 0x66)
		{//��λ�Ѳ���		
		falseinout = RecordMode_out;
		if(cardst==0)//������
			{
			equ = campare_card_NO(car,YWT->snr,CPU_CARD,1);
			if(equ!=1)
				{
				disp_YWT_IMG(1);
				return;				
				}
			falseinout = RecordMode_falseout;//�ٳ���
			}		
		//���Ѳ���
#ifndef testYWT
		equ = campare_card_NO(car,YWT->snr,CPU_CARD,1);
#endif
		if(equ == NO)//���Ų���ͬ
			{
			disp_YWT_IMG(1);
			return;
			}
		//��������---2015-07-27
		//1.����ͣ��ʱ���ͣ������		
		pktime = ret_max_24hour(CS_RF_US.start_stopTime,MIFARAE_PARK_CARD);							  
		pkmoney = time_to_momery(CS_RF_US.start_stopTime);
//		pktime = ret_max_24hour(YWT->YWParkInfo.ParkInOutTime+1,CPU_CARD);							 
//		pkmoney = time_to_momery(YWT->YWParkInfo.ParkDateTime);  

		if(pkmoney>cardmoney)//����
			{//��ʾ�������ѽ�� ���ۿ�
//			TMP.cardmny = cardmoney;
//			TMP.feemny = pkmoney;
//			memcpy(TMP.cardno,YWT->YYXLH,8);
//			disp_YWT_IMG(2);
			//�������¼
			falseinout = RecordMode_nofee;//δ�ۿ����
			}
//���񿨲���ܲ��� 2015-08-28
#ifdef CPC_MNY_BK
		falseinout = RecordMode_nofee;//δ�ۿ����
		pkmoney = 500;
#endif

		pkmnyold = pkmoney;
		if(pkmoney==0)//�ж��Ƿ�Ϊ������Ѳ���
			{
			equ = JD_LOOP_Park(car);
			if(equ==1)//��С�շ�
				pkmoney = RR_ST1.Frist_Money * RR_ST1.Sale_Base;
			}
#ifdef testYWTmny
		pkmoney /= 100;//����ʱ�۷�-1
#else
#ifdef testYWTmny_10
		pkmoney /= 10;//����ʱ�۷�-1
#endif
#endif
		if(falseinout == RecordMode_nofee)//δ�ۿ����
			{//pkmoney>cardmoney
			pkmoney -= cardmoney;//δ�۵��Ľ��д�뿨�ڴ��´ο� 2015-12-01
			fll(pkmoney,mnybuf,4);
			memcpy(YWTFEE.YWParkInfo.FEEMNY,mnybuf+1,3);//δ�۷ѳ��� 		
			TMP.feemny = pkmoney;
//			pkmoney = 0;
			pkmoney = cardmoney;//2015-12-01 �����ڽ��۹�
			cardmoney = 0;//����Ϊ0 2015-12-01
			}
		else
			memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ���			

		fll(pkmoney,mnybuf,4);
		YWTFEE.TradeDateTime[0] = 0x20;
		for(i=0;i<5;i++)
			YWTFEE.TradeDateTime[i+1] = time[4-i];
		YWTFEE.TradeDateTime[6] = 0x00;
		memcpy(YWTFEE.QBalance,YWT->Balance,4);
		memcpy(YWTFEE.Pays,mnybuf,4);
		//YWTFEE.ParkInfo
		YWTFEE.YWParkInfo.CardType = 0x60;
		YWTFEE.YWParkInfo.ParkFlag = 0x00;
		for(i=0;i<4;i++)
			YWTFEE.YWParkInfo.ParkDateTime[i] = time[3-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.UpdateFlag = 0x88;			
		YWTFEE.YWParkInfo.DongjieMoney[0] = 0x00;
		YWTFEE.YWParkInfo.DongjieMoney[1] = 0x00;//RR_ST1.Max_Stop_Momery;
		memset(YWTFEE.YWParkInfo.Res,0xCC,7);
		YWTFEE.YWParkInfo.Res[6] = car;
//		memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ���			
		YWTFEE.YWParkInfo.ParkMBNO[0] = 0x66;
		memcpy(YWTFEE.YWParkInfo.ParkMBNO+1,mbno,3);
		YWTFEE.YWParkInfo.ParkInOutTime[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.ParkInOutTime[i+1] = time[4-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.ParkInOutTime[6]= 0x00;			
		YWTFEE.CardType = YWT->CardType;
//		memcpy(YWTFEE.YYXLH,YWT->CSDMType,2);
		memcpy(YWTFEE.YYXLH+2,YWT->YYXLH,8);
//			YWTFEE.CSDMType//���д�������?
		YWTFEE.CSDMType =2;
		memcpy(YWTFEE.NC,0,2);
		memcpy(YWTFEE.SHDM,0,2);
		YWTFEE.POS[0] = 0x66;
		memcpy(YWTFEE.POS+1,mbno,3);
		if(falseinout == RecordMode_falseout)
			equ = 1;//6�ٳ���--7δ�ۿ����
		else
			equ = YWT_FEE_PRO(&YWTFEE,&YWTFEER);//�۷ѳ���
		if(equ!=1)
			{	
			buffer[0]= 1;
			//д����/�쳣ˢ���ı�־ 2015-08-06
			I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
			if(QuitTime>=4)
				{
				disp_YWT_IMG(3);	
				QuitFlag = 0;
				}
			else
				QuitFlag = 1;
			memset(buffer,0,8); 	
			write_momery_to_Fm(buffer,car);
			return;
			}			
		//�����۷Ѽ�¼�Ͷ��˼�¼ 2015-07-28
		buffer[0]= 0;
		//д����/�쳣ˢ���ı�־ 2015-08-06
		I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
		Smart_Power_OFF;//�ص�����ģ��ĵ�Դ Ϊ��ʡ��
		HR_TIME[car] = 0;
		err_1[car] = 0;
		WriteRecover(car,0);
		//3. ��λ����  
		light(car,NO);
		OPEN_EXTI9_5_IRQ();
		OPEN_EXTI15_10_IRQ();							
//		Buzz_0;
//		delay(KEYTIMEOUT_1S/10);
//		Buzz_1; 							
		//3. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ���֣�����ͣ��ʱ�䣩    
		buffer[0] = 0x00; //��λ״̬
		memset(buffer+1,0,4);//�������� 
		memcpy(buffer+5,YWT->snr,4);//��������	
//		memcpy(buffer+1,YWT->YYXLH,8);//��������	
		buffer[9] = time[3]; //��									   
		buffer[10] = time[2]; //��										
		buffer[11] = time[1]; //ʱ										 
		buffer[12] = time[0]; //��										 
		buffer[13] = time[4];//0x00; //�� Ԥ��										 
		buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ									  
		buffer[15] = max_stop_time % 60;																											 
		//д���� ��15���� ����ˢ
		write_car_15_reference(car,buffer,16);	 
		for(i=0;i<16;i++)
			buffer[i] = 0;
		write_car_reference_of_use_info(car,buffer,1);
		//д���ɹ� ��ȷ����
		buffer[0] = 0x00;														  
		I2C_WriteS_24C(car1_write_comd + (car - 1) ,buffer,1);
		//�ۿ�ɹ� ��ȷ����
		buffer[0] = 0x00;
		I2C_WriteS_24C((car1_value_comd + (car - 1)),buffer,1); 
		//1. ��ɷѼ�¼ 
		buffer[0] = 0xEE;//��¼ͷ
		memset(buffer+1,0,4);//��������	
		memcpy(buffer+5,YWT->snr,4);//��������	
//		memcpy(buffer+1,YWT->YYXLH,8);//��������	
		buffer[9] = YWT->YWParkInfo.ParkInOutTime[1];//time[4];//��
		memcpy(buffer+10,YWT->YWParkInfo.ParkDateTime,4);//��//��//ʱ//��
		if(falseinout ==6)
			cardmoney += pkmoney;//�ٳ�������ѿ�
		buffer[14] = cardmoney>>16;//
		buffer[15] = cardmoney>>8;//
		buffer[16] = cardmoney;//
		buffer[17] = mnybuf[2];
		buffer[18] = mnybuf[3];
		buffer[19] = ((car+CAR_CLASS)<<4) + 0x02;//��2��ͣ�� ��λΪcar 
		for(i=0;i<5;i++)
			buffer[20+i] = time[4-i];
		buffer[25] = CardType_CPC;//CPC��¼��־
		for(i=26;i<32;i++)buffer[i] = 0xAA;
		Save_Record(buffer,32);
		save_RPTMNY_record(CardType_CPC,pkmoney);//2015-12-07
		WriteRecord(car,RECORD_NULL);
		Deal_SwipCardIMG(car-1,0);
		
		//���˼�¼-2015-07-30 YWTFEER
		YWTFEER.RecFlag = 0;
		YWTFEER.Monthtype = 0;
		YWTFEER.Monthflag = 0;
		memcpy(YWTFEER.Cardno,YWT->snr,4);//��������
		YWTFEER.FeeFlag = falseinout;//1(5)-(��)�볡 2(6)-(��)���� 3-������ 4 -Ƿ���������� 7-δ�ۿ����
		I2C_ReadS_24C(SYS_SN,buffer,4);
		snno=hcl(buffer,4);
		snno += 1;
		fll(snno,buffer,4);
		I2C_WriteS_24C(SYS_SN,buffer,4);
		memcpy(YWTFEER.Sn,buffer+1,3);//��ˮ�ź�
		memset(YWTFEER.Res,0xff,4);//����		
		memcpy(record,RxBuffer+5,65);
		memcpy(record+65,&YWTFEER.RecFlag,1);
		memcpy(record+66,&YWTFEER.Monthtype,1);
		memcpy(record+67,&YWTFEER.Monthflag,1);
		memcpy(record+68,YWTFEER.Cardno,4);
		memcpy(record+72,&YWTFEER.FeeFlag,1);
		memcpy(record+73,YWTFEER.Sn,3);
		memcpy(record+76,YWTFEER.Res,4);		
		Save_Record(record,80);
		
		//��ʼ ���� ����			
		//�ж� �Ƿ�������ͣ��		
		equ = JD_LOOP_Park(car);
		flag_free = get_current_time(); 									
		if((flag_free == 1)&&(pkmoney==0))  // ͣ��  �շ�ʱ��  ��Ѳ���
			{
			buffer[0] = 0x01;
			buffer[1] = 0x01;
			//д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
			I2C_WriteS_24C((car1_useing + (car - 1)),buffer+1,1);
			//д����ͣ�� �ı�־
			I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04),buffer,1);
			}	
		else if((flag_free == 0)||pkmnyold)
			{
			buffer[0] = 0x00;
			buffer[1] = 0x00;
			//д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
			I2C_WriteS_24C((car1_useing + (car - 1)),buffer+1,1);
			//д����ͣ�� �ı�־
			I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04),buffer,1);
			}
		
		if(falseinout == RecordMode_nofee)
			{			
			TMP.cardmny = cardmoney;
//			TMP.feemny = pkmoney;
			memcpy(TMP.cardno,YWT->YYXLH,8);
			disp_YWT_IMG(2);
			return;//ǰ���Ѿ�������Ӧ����ʾ
			}
		//2. ��ʾͣ��ʱ�䣬ͣ�����ã�����ʣ����
		//cardmoney - pkmoney
		TMP.cardmny = cardmoney-pkmoney;
		TMP.feemny = pkmoney;
		TMP.feetime = pktime;		
		memcpy(TMP.cardno,YWT->YYXLH,8);
		memset(buffer,0,8);		
		write_momery_to_Fm(buffer,car);
		disp_YWT_IMG(6);//��ʾ������Ϣ		
		return;		
		}
//=========��λ����=========
//=========��λ����=========
//=========��λ����=========
//=========��λ����=========
	else
	{
	while(1)//����һ��ѭ���� 2015-09-08 andyluo
		{//��λ����
		falseinout = RecordMode_in;
		pkmoney = 0;
		//�к����� �ȼ���-����-ȫ��
		if(YWT->HMDBS)//��������
			{
			TMP.cardmny = cardmoney;
			memcpy(TMP.cardno,YWT->YYXLH,8);
			disp_YWT_IMG(11);//��ʾ��������		
			return; 	
			}
		
#ifdef testlist
		//32200100000000233227
		u8 listtestbuf[8] = {0x01,0x00,0x00,0x00,0x00,0x23,0x32,0x27};
		memcpy(YWT->YYXLH,listtestbuf,8);
		cardst = 0;
#endif

//�������ж�˳�� ����--����--ȫ��
		equ = SelectList_SRAM(YWT->YYXLH,ListType_CPCDEL,buffer);
		if(equ<0)
			{//���ڼ�����
			equ = SelectList_SRAM(YWT->YYXLH,ListType_CPCADD,buffer);
			if(equ<0)
				{//����������
				equ = SelectList_SRAM(YWT->YYXLH,ListType_CPCALL,buffer);
				}
#ifdef testing_OPEN//���Կ�����־
			equ = 2;
#endif		

			if(equ>=0)
				{
				falseinout = RecordMode_lockcard;//������¼��־
				TMP.cardmny = cardmoney;
				memcpy(TMP.cardno,YWT->YYXLH,8);
				I2C_ReadS_24C(SYS_LOCKCPC,buffer,1);//��������� 1-�� 0-��
#ifndef testing_LOCKCPC//���Կ�����־
				SYS_LIST.dayupflag = 1;//�������
#endif		
				buffer[0] = 0;//�ر���������2015��12��9��
				if(buffer[0]&&SYS_LIST.dayupflag)
					;
				else
					{
					disp_YWT_IMG(11);//��ʾ��������
					return;
					}
//				disp_YWT_IMG(11);//��ʾ��������
//				return;
				//�������������� 2015-08-24
				}
			}		
		
		if(cardst==1)
			{//���Ѳ���----���ٽ��������
			//�ٽ���-ֱ������ -���¼
			falseinout = RecordMode_falsein;
			//�ж����ڳ�λ�Ƿ��Ѿ�����?2015-08-20
			if(car == 2)
				i = 3;
			else if(car == 3)
				i = 2;
			read_car_reference_of_use_info(&CS_RF_US,i);//����λ״̬��Ϣ

			if(CS_RF_US.car_stop_way[0]==0x66)
				{
				equ = campare_card_NO(i,YWT->snr,CPU_CARD,1);
				if(equ==1)
					swipng =0;//�Ѳ����ж�
				}
//#ifndef EMI_ParkJG
//			swipng =1;//���β����ж� 2015-10-12
//#endif
			equ = campare_card_NO(car,YWT->snr,CPU_CARD,1);
			if((equ!=1)||(swipng==0))//ˢ���쳣 2015-08-06	����������
				{//��ʾδ����-
				buffer[0] = time[4];
				memcpy(buffer+1,YWT->YWParkInfo.ParkDateTime,4);
				pktime = ret_max_24hour(buffer,CPU_CARD);			
				I2C_ReadS_24C(LISTNET_ADD,buffer,16);	
				equ = -1;
				jdpktime = buffer[8]*60;
#ifdef testfeelist
				I2C_ReadS_24C(SYS_FEELIST,record,1);//Ƿ���������¿��� 1-�� 0-��
				if(record[0]==0)
					jdpktime = 0;
#endif
				if(pktime>=jdpktime)//�Զ�����
					{
					I2C_ReadS_24C(SYS_FEELIST,record,1);//Ƿ���������¿��� 1-�� 0-��
					if(record[0])
						{
						//�ж�Ƿ������
						//�����Զ�����ʱ������	���һ�β���ʱ��>����ʱ�� 2015-08-13
						equ = SelectList_SRAM(YWT->snr,ListType_CPCFEE,buffer);
						}
					else//Ƿ�������ر� ֱ��ѯ�ʺ�̨���� 2015-10-10
						{
		//================�Զ����ʼ2015-10-10=====================
						//���˹�����һ������
						Smart_Power_OFF;
						disp_cardfee(0);	
						TMP.car = car;
						TMP.cardtype = CardType_CPCRD;
						memcpy(TMP.cardno+4,YWT->snr,4);
						i = Send_CardFeeRecord();
						if(i>0)
							{
							disp_cardfee(1);
							delay(KEYTIMEOUT_1S*4);
							return;
							}
						if(TMP.feetime==0)
							{
							disp_cardfee(2);
							delay(KEYTIMEOUT_1S*4);
							return;
							}		
						//�Ƚ� TMP.time��YWT->YWParkInfo.ParkDateTime�Ĵ�С 
						//����ʱ��С�� ��λʱ�� ���ܲ��� 
						memcpy(buffer+1,YWT->YWParkInfo.ParkDateTime,4);
						buffer[0] = TMP.time[0];
						if(((TMP.time[1]==0x01)&&(buffer[1]==0x12))||//����
							(TMP.time[1]>buffer[1])||//MMDDHHMM
							((TMP.time[1]==buffer[1])||(TMP.time[2]>buffer[2]))||
							((TMP.time[1]==buffer[1])||(TMP.time[2]==buffer[2])||(TMP.time[3]>buffer[3]))||
							((TMP.time[1]==buffer[1])||(TMP.time[2]==buffer[2])||(TMP.time[3]==buffer[3])||(TMP.time[4]>=buffer[4])))
							{
							equ=0;
							SYS_LIST.dayupflag= 66;	
							
							lcd_clear();//���� ��ʾ ��ˢ��	
							Smart_Power_ON;
							delay(KEYTIMEOUT_1S/10);//������ʱ ��Ϊ�� �������� �ϵ�
							display_please_operation(time1[4],time1[3],time1[2],time1[1],time1[0],77);	   
							//TMP.feetime: TMP.feemny
							key_flag = 0;
							i = 4;
							CardInfo YWCardInfo;
							u8 card_class_flag;
							u32 timeOut;
							timeOut = 0;   
							while(i--)
								{
								while(timeOut < 300)
									{
									card_class_flag = inquire_card(&YWCardInfo);//��� ��������
										
									if((card_class_flag==CardType_MF1)||
										(card_class_flag==CardType_BIKE)||
										(card_class_flag==CardType_CPC))
										{
										break;
										}										
									if(key_flag != NO)
										{
										key_flag = 0;
										break;
										}										
									timeOut++;	
									}
								if(card_class_flag!=CardType_CPC)
									{
									timeOut = 0;
									if(i>1)continue;
									disp_cardfee(3);
									delay(KEYTIMEOUT_1S*4);
									return;
									}
								break;
								}
							
							}
						else//����ʱ��>��λʱ��
							{//��ʾδ����-
							memcpy(TMP.cardno,YWT->YYXLH,8);
							memcpy(TMP.time,YWT->YWParkInfo.ParkDateTime,4);
							memcpy(TMP.mbno,YWT->YWParkInfo.ParkMBNO,4);			
							disp_YWT_IMG(4);
							return; 				
							}
						}
					}
				if((equ>=0)&&SYS_LIST.dayupflag)//����Ƿ�Ѽ�¼ 2015-07-14
					{
					//buffer0-3 ����	4-5Ƿ�ѽ��  6-7δ���������1λ��+���ᱶ����3λ��
					if(SYS_LIST.dayupflag == 66)//��̨ѯ�ʲ���
						pkmnybk = TMP.feemny;
					else
						pkmnybk = hcl(buffer+4,2);
					falseinout = RecordMode_listfee;
				  	}		
				else
					{
					memcpy(TMP.cardno,YWT->YYXLH,8);
					memcpy(TMP.time,YWT->YWParkInfo.ParkDateTime,4);
					memcpy(TMP.mbno,YWT->YWParkInfo.ParkMBNO,4);
					TMP.mbno[0] = YWT->YWParkInfo.Res[6];
#ifndef LOOPIN//�������볡				
					disp_YWT_IMG(4);
					return;
#endif
					}
				}
			}
		//������	���߼ٽ���		
		//����-��Ƿ�ѽ���Ƿ�Ϊ0��
	if((YWT->YWParkInfo.CardType == 0x60)&&
		(YWT->YWParkInfo.UpdateFlag== 0x88))
		{
		pkmoney = hcl(YWT->YWParkInfo.FEEMNY,3);
		if(pkmoney>0)//����Ƿ�ѽ�� ֱ�ӿ۳�  ��ɵ�һ�β��� 2015-07-30
			{
			falseinout = RecordMode_cardfee;
			}
		if(falseinout ==RecordMode_listfee)pkmoney =pkmnybk;
#ifndef LOOPIN//�������볡
		if(cardmoney<pkmoney)//���С��Ƿ�ѽ��
			{			
			TMP.cardmny = cardmoney;
			memcpy(TMP.cardno,YWT->YYXLH,8);
			disp_YWT_IMG(5);//���� ���ֵ
			return;
			}
#else 
		pkmoney = 0;
#endif
		}
#ifdef testYWTmny
		pkmoney /= 100;//����ʱ�۷�-1
#else
#ifdef testYWTmny_10
		pkmoney /= 10;//����ʱ�۷�-1
#endif
#endif
		fll(pkmoney,mnybuf,4);
		YWTFEE.TradeDateTime[0] = 0x20;
		for(i=0;i<5;i++)
			YWTFEE.TradeDateTime[i+1] = time[4-i];
		YWTFEE.TradeDateTime[6] = 0x00;
		memcpy(YWTFEE.QBalance,YWT->Balance,4);
		memcpy(YWTFEE.Pays,mnybuf,4);
		//YWTFEE.ParkInfo
		YWTFEE.YWParkInfo.CardType = 0x60;
		//����С����ж� 2015-09-09
		if((falseinout==3)||(falseinout==4))
			{
//			YWTFEE.YWParkInfo.ParkFlag = 0x00;//��������δ�볡��־
			max_stop_time = momery_to_time(cardmoney-pkmoney);	
			if(max_stop_time==0)// Ǯ���� ������ͣ��
				YWTFEE.YWParkInfo.ParkFlag = 0x00;
			else
				YWTFEE.YWParkInfo.ParkFlag = 0x01;//��������δ�볡��־
			}
		else
			YWTFEE.YWParkInfo.ParkFlag = 0x01;//�����볡��־
		for(i=0;i<4;i++)
			YWTFEE.YWParkInfo.ParkDateTime[i] = time[3-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.UpdateFlag = 0x88;			
		YWTFEE.YWParkInfo.DongjieMoney[0] = 0x00;
		YWTFEE.YWParkInfo.DongjieMoney[1] = RR_ST1.Max_Stop_Momery;
		memset(YWTFEE.YWParkInfo.Res,0xCC,7);
		YWTFEE.YWParkInfo.Res[6] = car;
		memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����볡 		
		YWTFEE.YWParkInfo.ParkMBNO[0] = 0x66;
		memcpy(YWTFEE.YWParkInfo.ParkMBNO+1,mbno,3);
		YWTFEE.YWParkInfo.ParkInOutTime[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.ParkInOutTime[i+1] = time[4-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.ParkInOutTime[6]= 0x00;			
		YWTFEE.CardType = YWT->CardType;
//		memcpy(YWTFEE.YYXLH,YWT->CSDMType,2);
		memcpy(YWTFEE.YYXLH+2,YWT->YYXLH,8);
//			YWTFEE.CSDMType//���д�������?
		YWTFEE.CSDMType =2;
		memcpy(YWTFEE.NC,0,2);
		memcpy(YWTFEE.SHDM,0,2);
		YWTFEE.POS[0] = 0x66;
		memcpy(YWTFEE.POS+1,mbno,3);
		//����-���� -���¼
		//1. �ݴ� ����� ��ʹ��״̬����
		write_momery_to_Fm(YWT->Balance,car);
		//����ͣ��		
		//д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
		I2C_ReadS_24C((car1_useing + (car - 1)),&feeflag,1);
		ReadCar_15_Info(car,buffer);
		pktime = ret_max_24hour(buffer+9,SELECT);
		if((pktime>=60)||(feeflag==0x00))
			{
			//�����λ����Ϣ ʹ����ˢ15���Ӻ� �ȽϿ��Ų�ͬ
			for(i=0;i<16;i++)
				buffer[i] = 0;
			write_car_15_reference(car,buffer,16);
			write_car_reference_of_use_info(car,buffer,16);
			}
		//2. ���ݿ������ �������ͣ��ʱ��
		if((falseinout ==RecordMode_listfee)||
			(falseinout ==RecordMode_cardfee))
			max_stop_time = 60;
		else
			max_stop_time = momery_to_time(cardmoney-pkmoney);	
		if(max_stop_time==0)// Ǯ���� ������ͣ��
			{	
				
			if(TMP.autofee == 1)//�Զ������־ 2015-09-08
				{
				TMP.feemny = TMP.feemnybak;
				disp_YWT_IMG(7);//��ʾǷ�����������볡��Ϣ		
				}
			
		//���ͣ��ʱ�� Ϊ 0		
			TMP.cardmny = cardmoney;
			memcpy(TMP.cardno,YWT->YYXLH,8);
			disp_YWT_IMG(5);//���� ���ֵ
			return;
			}
		if(falseinout==RecordMode_lockcard)//����	--������������	
			{
			equ = 1;//������������			
			YWTFEE.POS[0] = 0x88;
			}
        if((TMP.CPC_ckmny[car]!= cardmoney)&&
			TMP.CPC_ckmny[car]&&
			((falseinout ==RecordMode_listfee)||
			(falseinout ==RecordMode_cardfee)))
			{
			equ = 1;	
			cardmoney = TMP.CPC_ckmny[car];
			}
		else if(TMP.autofee == 1)//�Զ�����2015-09-08
			equ = 1;
		else if(falseinout==RecordMode_falsein)//�ٽ���
			equ = 1;
		else
			equ = YWT_FEE_PRO(&YWTFEE,&YWTFEER);//�۷ѳ���
		if(equ != 1)//�ۿ�ɹ�
			{//����Ҫ���ݴ�����//д����ͨ�� ���� �����־
			TMP.CPC_ckmny[car] = hcl(YWT->Balance,4);
			buffer[0] = 0x01;
			I2C_WriteS_24C(car1_LNT_comd + (car - 1),buffer,1);				
			buffer[0] = 0x00; //��λ״̬ 	
			memset(buffer+1,0,4);//�������� 
			memcpy(buffer+5,YWT->snr,4);//��������	
//			memcpy(buffer+1,YWT->YYXLH,8);//��������	
			buffer[9] = time[3]; //��									   
			buffer[10] = time[2]; //��										
			buffer[11] = time[1]; //ʱ										 
			buffer[12] = time[0]; //��										 
			buffer[13] = time[4];//0x00; //�� Ԥ��										 
			buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ 									  
			buffer[15] = max_stop_time % 60; 																											 
			write_car_reference_of_use_info(car,buffer,16);					
			Smart_Power_OFF;//�ص�����ģ��ĵ�Դ 
			OPEN_EXTI9_5_IRQ(); 									  
			OPEN_EXTI15_10_IRQ();
			QuitFlag = 1;
			buffer[0]= 1;
			//д����/�쳣ˢ���ı�־ 2015-08-06
			if(falseinout != 4)//�������
			I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
			memset(buffer,0,8); 	
			write_momery_to_Fm(buffer,car);
			return;
			}
		TMP.CPC_ckmny[car] =0;
		buffer[0]= 0;
		//д����/�쳣ˢ���ı�־ 2015-08-06
		I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
		//�ۿ�ɹ� 
		Smart_Power_OFF;//�ص�����ģ��ĵ�Դ		
		//1. �汾��λ����//�Ѿ�д��
		//���˼�¼-2015-07-30 YWTFEER
		YWTFEER.RecFlag = 0;
		YWTFEER.Monthtype = 0;
		YWTFEER.Monthflag = 0;
		memcpy(YWTFEER.Cardno,YWT->snr,4);//��������
		YWTFEER.FeeFlag = falseinout;//1(5)-(��)�볡 2(6)-(��)���� 3-������ 4 -Ƿ����������
		I2C_ReadS_24C(SYS_SN,buffer,4);
		snno=hcl(buffer,4);
		snno += 1;
		fll(snno,buffer,4);
		I2C_WriteS_24C(SYS_SN,buffer,4);
		memcpy(YWTFEER.Sn,buffer+1,3);//��ˮ�ź�
		memset(YWTFEER.Res,0xff,4);//����		
		memcpy(record,RxBuffer+5,65);
		memcpy(record+65,&YWTFEER.RecFlag,1);
		memcpy(record+66,&YWTFEER.Monthtype,1);
		memcpy(record+67,&YWTFEER.Monthflag,1);
		memcpy(record+68,YWTFEER.Cardno,4);
		memcpy(record+72,&YWTFEER.FeeFlag,1);
		memcpy(record+73,YWTFEER.Sn,3);
		memcpy(record+76,YWTFEER.Res,4);		
		Save_Record(record,80);	
		OPEN_EXTI9_5_IRQ(); 
		OPEN_EXTI15_10_IRQ();
		if(falseinout==RecordMode_lockcard)//�����ɹ���
			{
			disp_YWT_IMG(11);//��ʾ��������
			return;
			}
		
		//����ͨ�ļ�¼	�����ļ�¼	
		
		//2. ��ͣ����¼
		buffer[0] = 0xEE;//��¼ͷ
		if(falseinout==RecordMode_listfee)//����
			{
			buffer[1] = 0;
			buffer[2] = 1;
			buffer[3] = YWT->YWParkInfo.DongjieMoney[0];
			buffer[4] = YWT->YWParkInfo.DongjieMoney[1];
			}	
		else
			memset(buffer+1,0,4);//�������� 
		memcpy(buffer+5,YWT->snr,4);//��������	
//		memcpy(buffer+1,YWT->YYXLH,8);//��������	
		for(i=0;i<5;i++)
			buffer[9+i] = time[4-i];//��//��//��//ʱ//��
		memcpy(buffer+14,YWT->Balance+1,3);
		
		buffer[17] = mnybuf[2];
		buffer[18] = mnybuf[3];
		
		if(falseinout==RecordMode_listfee)
			{
			buffer[19] = ((car+CAR_CLASS)<<4) + 0x07;//������δ����
			bushimny[car] = 0;   
			bukanmny[car] = 0;	
			TMP.CPC_ckmny[car] = 0;
			}
		else if(falseinout==RecordMode_cardfee)
			buffer[19] = ((car+CAR_CLASS)<<4) + 0x03;//����
		else
			{
			buffer[19] = ((car+CAR_CLASS)<<4) + 0x01;//��һ��ͣ�� ��λΪcar 
			bushimny[car] = 0;   
			bukanmny[car] = 0;	
			TMP.CPC_ckmny[car] = 0;
			}
		for(i=0;i<5;i++)
			buffer[20+i] = time[4-i];//��//��//��//ʱ//��
		buffer[25] = CardType_CPC;//����ͨ��¼��־			
		for(i=26;i<32;i++)
			buffer[i] = 0xAA;							   
		Save_Record(buffer,32);		
		save_RPTMNY_record(CardType_CPC,pkmoney);//2015-12-07
		WriteRecord(car,CardType_CPC);//д�� ��¼�ı�־		

		pktime = max_stop_time;
		TMP.cardmny = cardmoney - pkmoney;
		TMP.feemny = pkmoney;
		TMP.feetime= pktime;		
		memcpy(TMP.cardno,YWT->YYXLH,8);
		if(falseinout==RecordMode_listfee)
			{
//			disp_YWT_IMG(7);//��ʾǷ�����������볡��Ϣ		
			//�����λ����Ϣ ʹ����ˢ15���Ӻ� �ȽϿ��Ų�ͬ
			for(i=0;i<16;i++)
				buffer[i] = 0;
			write_car_15_reference(car,buffer,16);
			write_car_reference_of_use_info(car,buffer,16);
			
			TMP.autofee = 1;//2015-09-08
//			QuitFlag = 1;//����Ѱ�� �볡
//			QuitTime--;
			TMP.feemnybak = TMP.feemny; 	
			fll(TMP.cardmny,YWT->Balance,4);
			cardst = 0;
			fll(0,YWT->YWParkInfo.FEEMNY,3);
			cardmoney  = TMP.cardmny;			
			continue;
			}
		else if(falseinout==RecordMode_cardfee)
			{			
//			disp_YWT_IMG(8);//��ʾ�������볡��Ϣ	
			//�����λ����Ϣ ʹ����ˢ15���Ӻ� �ȽϿ��Ų�ͬ
			for(i=0;i<16;i++)
				buffer[i] = 0;
			write_car_15_reference(car,buffer,16);
			write_car_reference_of_use_info(car,buffer,16);

			TMP.autofee = 1;//2015-09-08
//			QuitFlag = 1;//����Ѱ�� �볡
//			QuitTime--;
			TMP.feemnybak = TMP.feemny;		
			fll(TMP.cardmny,YWT->Balance,4);
			cardst = 0;
			fll(0,YWT->YWParkInfo.FEEMNY,3);
			cardmoney  = TMP.cardmny;
			continue;
			//return;
			}
		Deal_SwipCardIMG(car-1,1);
		if(campare_card_NO(car,YWT->snr,CPU_CARD,1))
		  { 
		  buffer[0] = 0x01;
		  I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04) + 1,buffer,1);  
		  } 
		else	  
		  {
		  buffer[0] = 0x00;
		  I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04) + 1,buffer,1);											
		  } 
		//��λ����
		light(car,OK); 		
//		Buzz_0;
//		delay(KEYTIMEOUT_1S/20);
//		Buzz_1;
		//4. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ��������ͣ��ʱ�䣩											
		buffer[0] = 0x66; //��λ״̬ 									  
		memset(buffer+1,0,4);//�������� 
		memcpy(buffer+5,YWT->snr,4);//��������	
//		memcpy(buffer+1,YWT->YYXLH,8);//��������	
		buffer[9] = time[3]; //��									   
		buffer[10] = time[2]; //��										
		buffer[11] = time[1]; //ʱ										 
		buffer[12] = time[0]; //��										 
		buffer[13] = time[4];//��									 
		buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ 									  
		buffer[15] = max_stop_time % 60; 																											 
		memcpy(buffer+16,YWT->Balance,4);
		write_car_reference_of_use_info(car,buffer,16);
		write_momery_to_Fm(YWT->Balance,car);
		//3. ��ʾ��������ǰʱ�䣬��ͣ��ʱ��
		pktime = max_stop_time;
		TMP.cardmny = cardmoney - pkmoney;
		TMP.feemny = pkmoney;
		TMP.feetime= pktime;		
		memcpy(TMP.cardno,YWT->YYXLH,8);
		if(TMP.autofee == 1)//�Զ������־ 2015-09-08
			{
			for(i=0;i<5;i++)
				TMP.CPC_ckmny[i] =0;
			TMP.feemny = TMP.feemnybak;
			disp_YWT_IMG(7);//��ʾǷ�����������볡��Ϣ		
			}
			
		if(falseinout==RecordMode_listfee)
			disp_YWT_IMG(7);//��ʾǷ�����������볡��Ϣ		
		else if(falseinout==RecordMode_cardfee)
			disp_YWT_IMG(8);//��ʾ�������볡��Ϣ		
		else if(falseinout==RecordMode_falsein)
			disp_YWT_IMG(9);//��ʾ���볡��Ϣ		
		else
			disp_YWT_IMG(10);//��ʾ�볡��Ϣ		
		return;		
		}
	}
}
*/



//CPU���������� 2016-03-11
//space-��λ�� IQflag-˫����ѯ��־
//spacestate;//66-�볡 0- ����  88-��ʱ  99-�˹�����  AA-д�벹����(����)
void CPCCARD_PRO(u8 space,u8 spacestate,CardInfo *YWT)
{
s32 equ;
u32 cardmoney,pktime=0,jdpktime,pkmoney,pkmnyold,pkmnybk,max_stop_time,snno;
u8 i,car,carst,cardst,feeflag,swipng;//1-ˢ���쳣 0-����
u8 mbno[3],mnybuf[4],buffer[32],record[100];
u8 falseinout;//1(5)-(��)�볡 2(6)-(��)���� 3-������ 
			// 4 -Ƿ���������� 7-δ�ۿ���� F-������¼
SubMoneyCMD YWTFEE;
PosRecordInfo YWTFEER;
carStation_reference_of_used CS_RF_US;

	
	get_rate_ref(&RR_ST1); 
	max_stop_time = RR_ST1.Max_Park_Time*60;
	QuitFlag = 0;
	I2C_ReadS_24C(mibiao_number,mbno,3);//�����
	car = space;//��λ��
	carst = spacestate;//66-�볡 0- ����  88-��ʱ  99-����
	cardst = YWT->YWParkInfo.ParkFlag;	
	if((YWT->YWParkInfo.CardType != 0x60)||
		(YWT->YWParkInfo.UpdateFlag != 0x88))
		cardst = 0;//�¿�Ĭ��Ϊ����ģʽ 2015-08-05	
	cardmoney = hcl(YWT->Balance,4);	
	//д����/�쳣ˢ���ı�־ 2015-08-06
	I2C_ReadS_24C(Car1_SwipNG+car-1,buffer,1);	
	swipng = buffer[0];	
	read_car_reference_of_use_info(&CS_RF_US,car);//����λ״̬��Ϣ	

//	memcpy(YWTFEE.YWParkInfo.ParkMBNO+1,mbno,3);
	if((mbno[0]!=YWT->YWParkInfo.ParkMBNO[1])||
	   (mbno[1]!=YWT->YWParkInfo.ParkMBNO[2])||
	   (mbno[2]!=YWT->YWParkInfo.ParkMBNO[3]))
	   swipng = 0;//�Ǽٽ���ٳ� 2015-09-02


//�������ж�˳�� ����--����--ȫ��
//	equ = SelectList_SRAM(YWT->YYXLH,ListType_CPCDEL,buffer);
//	if(equ<0)
//		{//���ڼ�����
//		equ = SelectList_SRAM(YWT->YYXLH,ListType_CPCADD,buffer);
//		if(equ<0)
//			{//����������
//			equ = SelectList_SRAM(YWT->YYXLH,ListType_CPCALL,buffer);
//			}
//		if((equ>=0)||(YWT->HMDBS))
//			{
//			falseinout = 0x0F;//������¼��־
//			TMP.cardmny = cardmoney;
//			memcpy(TMP.cardno,YWT->YYXLH,8);
//			disp_YWT_IMG(11);//��ʾ��������
//			return;
//			//�������������� 2015-08-24
//			}
//		}		

	TMP.cpc = 1;//��ʾ�����
//	TMP.cpc = 0;//��ʾ�������� 2016��3��11��
	TMP.autofee = 0;
//	cardmoney = 601;

#ifdef Test_RealCPC //F57115BE//ԭ���8.55Ԫ  �����4Ԫ
	TMP.cardmny = 855;//
	cardmoney = 855;
	cardst = 0;	
	pkmoney = 400;//hcl(YWT->YWParkInfo.FEEMNY,3);
	fll(pkmoney,YWT->YWParkInfo.FEEMNY,3);
	
#endif

#ifdef disp_test_YWT
		TMP.cardmny = cardmoney;
		TMP.feemny = 2050;
		memcpy(TMP.cardno,YWT->YYXLH,8);
		disp_YWT_IMG(2);
		disp_YWT_IMG(1);
#endif
#ifdef disp_test_YWTOUT
		carst = 0x66;
		cardst = 1;
		equ = OK;
#define testYWT
#endif
#ifdef disp_test_YWTIN
		carst = 0x00;
		cardst = 0;
		disp_YWT_IMG(4);
#endif
	//���� ��ʱ ���� Ƿ�Ѳ������� 2015-08-11
//=========��λ��ʱ=========
//=========��λ����=========
//=========��λǷ��=========
	if((carst == 0x88)||//��ʱ -7
		(carst == 0x99)||//����  -E
		(carst == 0xAA))//Ƿ�� ����
		{
		if(carst == 0x88)//��ʱ  -E
			{
			if(cardst==1)
				{
				memcpy(TMP.cardno,YWT->YYXLH,8);
				memcpy(TMP.time,YWT->YWParkInfo.ParkDateTime,4);
				memcpy(TMP.mbno,YWT->YWParkInfo.ParkMBNO,4);	
				TMP.mbno[0] = YWT->YWParkInfo.Res[6];
				disp_YWT_IMG(4);
				return;
				}
			}
		else if(carst == 0x99)//����
			{
			//�Ƚ� TMP.time��YWT->YWParkInfo.ParkDateTime�Ĵ�С 
			//����ʱ��С�� ��λʱ�� ���ܲ��� 
			memcpy(buffer+1,YWT->YWParkInfo.ParkDateTime,4);
			buffer[0] = TMP.time[0];
			if(((TMP.time[1]==0x01)&&(buffer[1]==0x12))||//����
				(TMP.time[1]>buffer[1])||//MMDDHHMM
				((TMP.time[1]==buffer[1])||(TMP.time[2]>buffer[2]))||
				((TMP.time[1]==buffer[1])||(TMP.time[2]==buffer[2])||(TMP.time[3]>buffer[3]))||
				((TMP.time[1]==buffer[1])||(TMP.time[2]==buffer[2])||(TMP.time[3]==buffer[3])||(TMP.time[4]>=buffer[4])))
				;
			else//����ʱ��>��λʱ��
				{
				TMP.cardmny = cardmoney;
				memcpy(TMP.cardno,YWT->YYXLH,8);
				memcpy(TMP.time,YWT->YWParkInfo.ParkDateTime,4);
//				memcpy(TMP.mbno,YWT->YWParkInfo.ParkMBNO,4);			
//				memcpy(TMP.mbno,YWT->YWParkInfo.ParkDateTime,4);			
				disp_YWT_IMG(16);//��ʾ���ܲ���
				return;
				}
			}
		falseinout = carst;
#ifdef proing
		disp_YWT_IMG(100);
		return;
#endif		
		pkmoney =TMP.feemny;

	
		if(pkmoney>cardmoney)//����
			{//��ʾ�������ѽ�� ���ۿ�
			TMP.cardmny = cardmoney;
			TMP.feemny = pkmoney;
			memcpy(TMP.cardno,YWT->YYXLH,8);
			disp_YWT_IMG(2);
			return;
			}
		
		if(carst == 0xAA)//δ�ۿ����  Ƿ�Ѳ���
			{
			fll(pkmoney,mnybuf,4);
			memcpy(YWTFEE.YWParkInfo.FEEMNY,mnybuf+1,3);//δ�۷ѳ���		
			pkmoney = 0;
			}
		else
			memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ��� 		

#ifdef testYWTmny
		pkmoney /= 100;//����ʱ�۷�-1
#else
#ifdef testYWTmny_10
		pkmoney /= 10;//����ʱ�۷�-1
#endif
#endif
		fll(pkmoney,mnybuf,4);

		YWTFEE.TradeDateTime[0] = 0x20;
		for(i=0;i<5;i++)
			YWTFEE.TradeDateTime[i+1] = time[4-i];
		YWTFEE.TradeDateTime[6] = 0x00;
		memcpy(YWTFEE.QBalance,YWT->Balance,4);
		memcpy(YWTFEE.Pays,mnybuf,4);
		//YWTFEE.ParkInfo
		YWTFEE.YWParkInfo.CardType = 0x60;
		YWTFEE.YWParkInfo.ParkFlag = 0x00;
		for(i=0;i<4;i++)
			YWTFEE.YWParkInfo.ParkDateTime[i] = time[3-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.UpdateFlag = 0x88;			
		YWTFEE.YWParkInfo.DongjieMoney[0] = 0x00;
		YWTFEE.YWParkInfo.DongjieMoney[1] = 0x00;//RR_ST1.Max_Stop_Momery;
//		memset(YWTFEE.YWParkInfo.Res,0xCC,7);
//		YWTFEE.YWParkInfo.Res[6] = car;
//		memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ��� 		
//		YWTFEE.YWParkInfo.ParkMBNO[0] = 0x66;
//		memcpy(YWTFEE.YWParkInfo.ParkMBNO+1,mbno,3);
		YWTFEE.YWParkInfo.Res[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.Res[i+1] = time[4-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.Res[6]= 0x00;
			
		memset(YWTFEE.YWParkInfo.FEEMNY,0,2);//�����۷ѳ��� 	
		memcpy(YWTFEE.YWParkInfo.ParkMBNO,mbno,3);
		YWTFEE.YWParkInfo.ParkMBNO[3] = car;

		
		YWTFEE.YWParkInfo.ParkInOutTime[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.ParkInOutTime[i+1] = time[4-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.ParkInOutTime[6]= 0x00;			
		YWTFEE.CardType = YWT->CardType;
//		memcpy(YWTFEE.YYXLH,YWT->CSDMType,2);
		memcpy(YWTFEE.YYXLH,YWT->YYXLH,8);
//			YWTFEE.CSDMType//���д�������?
		YWTFEE.CSDMType =2;
		memcpy(YWTFEE.NC,0,2);
		memcpy(YWTFEE.SHDM,0,2);
		YWTFEE.POS[0] = 0x66;
		memcpy(YWTFEE.POS+1,mbno,3);
		equ = YWT_FEE_PRO(&YWTFEE,&YWTFEER);//�۷ѳ���	
		if(equ!=1)
			{
//			buffer[0]= 1;
//			//д����/�쳣ˢ���ı�־ 2015-08-06
//			I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
			if(QuitTime>=4)
				{
				disp_YWT_IMG(3);	
				QuitFlag = 0;
				}
			else
				QuitFlag = 1;
			memset(buffer,0,8); 	
			write_momery_to_Fm(buffer,car);
			return;
			}
		
//		//��������----2016-03-11
//		memcpy(YWT->YYXLH+4,YWT->snr,4);

		if(carst == 0xAA)//δ�ۿ����  Ƿ�Ѳ���
			{
			disp_YWT_IMG(13);
			return;
			}
		//1. �油ʱ-�����¼ 
		buffer[0] = 0xEE;//��¼ͷ
		
		if(carst == 0x99)//����
			{
			buffer[1] = 0;
			buffer[2] = 1;
			buffer[3] = YWT->YWParkInfo.DongjieMoney[0];
			buffer[4] = YWT->YWParkInfo.DongjieMoney[1];
			}			
		else if(carst == 0x88)//��ʱ
			memset(buffer+1,0,4);//�������� 
			
		memcpy(buffer+5,YWT->snr,4);//��������	
//		memcpy(buffer+1,YWT->YYXLH,8);//��������	
//		buffer[9] = time[4];//��
//		memcpy(buffer+10,YWT->YWParkInfo.ParkDateTime,4);//��//��//ʱ//��
		if(carst == 0x99)//����
			{
			for(i=0;i<5;i++)
				buffer[9+i] = time[4-i];
			}
		else if(carst == 0x88)//��ʱ
			{
			for(i=0;i<5;i++)
				buffer[9+i] = TMP.time[4-i];
			}
		buffer[14] = cardmoney>>16;//
		buffer[15] = cardmoney>>8;//
		buffer[16] = cardmoney;//
		buffer[17] = mnybuf[2];
		buffer[18] = mnybuf[3];
		if(carst == 0x99)//����
			{
			buffer[19] = ((car+CAR_CLASS)<<4) + 0x07;//���� ��λΪcar 
			bushimny[car] = 0;   
			bukanmny[car] = 0;	
			TMP.CPC_ckmny[car] = 0;
			}
		else if(carst == 0x88)//��ʱ
			buffer[19] = ((car+CAR_CLASS)<<4) + 0x0E;//��ʱ ��λΪcar 
		for(i=0;i<5;i++)
			buffer[20+i] = time[4-i];
		buffer[25] = CardType_CPC;//CPC��¼��־		
		for(i=26;i<32;i++)buffer[i] = 0xAA;
		for(i=26;i<30;i++)buffer[i] = TMP.opcardno[i-26];
		Save_Record(buffer,32);
		//����ͨ�ļ�¼	�����ļ�¼	
		//���˼�¼-2015-07-30 YWTFEER
		YWTFEER.RecFlag = 0;
		YWTFEER.Monthtype = 0;
		YWTFEER.Monthflag = 0;
		memcpy(YWTFEER.Cardno,YWT->snr,4);//��������
		YWTFEER.FeeFlag = falseinout;//1(5)-(��)�볡 2(6)-(��)���� 3-������ 4 -Ƿ����������
		I2C_ReadS_24C(SYS_SN,buffer,4);
		snno=hcl(buffer,4);
		snno += 1;
		fll(snno,buffer,4);
		I2C_WriteS_24C(SYS_SN,buffer,4);
		memcpy(YWTFEER.Sn,buffer+1,3);//��ˮ�ź�
		memset(YWTFEER.Res,0xff,4);//����		
		memcpy(record,RxBuffer+5,65);
		memcpy(record+65,&YWTFEER.RecFlag,1);
		memcpy(record+66,&YWTFEER.Monthtype,1);
		memcpy(record+67,&YWTFEER.Monthflag,1);
		memcpy(record+68,YWTFEER.Cardno,4);
		memcpy(record+72,&YWTFEER.FeeFlag,1);
		memcpy(record+73,YWTFEER.Sn,3);
		memcpy(record+76,YWTFEER.Res,4);		
		Save_Record(record,80);	
		TMP.cardmny = cardmoney-pkmoney;
		TMP.feemny = pkmoney;
		TMP.feetime = pktime;		
		memcpy(TMP.cardno,YWT->YYXLH,8);
		
		//��������----2016-03-11
		memcpy(TMP.cardno,YWT->snr,4);
		if(carst == 0x99)//����
			disp_YWT_IMG(14);//����-��ʱ�ɹ�		
		else if(carst == 0x88)//��ʱ
			//disp_YWT_IMG(15);//����-��ʱ�ɹ�		
			disp_YWT_IMG(0xC5);//����-��ʱ�ɹ�		
		return;
		}
//=========��λռ��=========
//=========��λռ��=========
//=========��λռ��=========
//=========��λռ��=========
	else if(carst == 0x66)
		{//��λ�Ѳ���		
		falseinout = RecordMode_out;
		if(cardst==0)//������
			{
			equ = campare_card_NO(car,YWT->snr,CPU_CARD,1);
			if(equ!=1)
				{
				disp_YWT_IMG(1);
				return;				
				}
			falseinout = RecordMode_falseout;//�ٳ���
			}		
		//���Ѳ���
#ifndef testYWT
		equ = campare_card_NO(car,YWT->snr,CPU_CARD,1);
#endif
		if(equ == NO)//���Ų���ͬ
			{
			disp_YWT_IMG(1);
			return;
			}
		//��������---2015-07-27
		//1.����ͣ��ʱ���ͣ������		
		pktime = ret_max_24hour(CS_RF_US.start_stopTime,MIFARAE_PARK_CARD);							  
		pkmoney = time_to_momery(CS_RF_US.start_stopTime);
//		pktime = ret_max_24hour(YWT->YWParkInfo.ParkInOutTime+1,CPU_CARD);							 
//		pkmoney = time_to_momery(YWT->YWParkInfo.ParkDateTime);  

		if(pkmoney>cardmoney)//����
			{//��ʾ�������ѽ�� ���ۿ�
//			TMP.cardmny = cardmoney;
//			TMP.feemny = pkmoney;
//			memcpy(TMP.cardno,YWT->YYXLH,8);
//			disp_YWT_IMG(2);
			//�������¼
			falseinout = RecordMode_nofee;//δ�ۿ����
			}
//���񿨲���ܲ��� 2015-08-28
#ifdef CPC_MNY_BK
		falseinout = RecordMode_nofee;//δ�ۿ����
		pkmoney = 500;
#endif

		pkmnyold = pkmoney;
		if(pkmoney==0)//�ж��Ƿ�Ϊ������Ѳ���
			{
			equ = JD_LOOP_Park(car);
			if(equ==1)//��С�շ�
				pkmoney = RR_ST1.Frist_Money * RR_ST1.Sale_Base;
			}
#ifdef testYWTmny
		pkmoney /= 100;//����ʱ�۷�-1
#else
#ifdef testYWTmny_10
		pkmoney /= 10;//����ʱ�۷�-1
#endif
#endif
		if(falseinout == RecordMode_nofee)//δ�ۿ����
			{//pkmoney>cardmoney
			pkmoney -= cardmoney;//δ�۵��Ľ��д�뿨�ڴ��´ο� 2015-12-01
			fll(pkmoney,mnybuf,4);
			memcpy(YWTFEE.YWParkInfo.FEEMNY,mnybuf+1,3);//δ�۷ѳ��� 		
			TMP.feemny = pkmoney;
//			pkmoney = 0;
			pkmoney = cardmoney;//2015-12-01 �����ڽ��۹�
			cardmoney = 0;//����Ϊ0 2015-12-01
			}
		else
			memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ���			

		fll(pkmoney,mnybuf,4);
		YWTFEE.TradeDateTime[0] = 0x20;
		for(i=0;i<5;i++)
			YWTFEE.TradeDateTime[i+1] = time[4-i];
		YWTFEE.TradeDateTime[6] = 0x00;
		memcpy(YWTFEE.QBalance,YWT->Balance,4);
		memcpy(YWTFEE.Pays,mnybuf,4);
		//YWTFEE.ParkInfo
		YWTFEE.YWParkInfo.CardType = 0x60;
		YWTFEE.YWParkInfo.ParkFlag = 0x00;
		for(i=0;i<4;i++)
			YWTFEE.YWParkInfo.ParkDateTime[i] = time[3-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.UpdateFlag = 0x88;			
		YWTFEE.YWParkInfo.DongjieMoney[0] = 0x00;
		YWTFEE.YWParkInfo.DongjieMoney[1] = 0x00;//RR_ST1.Max_Stop_Momery;
//		memset(YWTFEE.YWParkInfo.Res,0xCC,7);
//		YWTFEE.YWParkInfo.Res[6] = car;
//		memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ��� 		
//		YWTFEE.YWParkInfo.ParkMBNO[0] = 0x66;
//		memcpy(YWTFEE.YWParkInfo.ParkMBNO+1,mbno,3);
		YWTFEE.YWParkInfo.Res[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.Res[i+1] = time[4-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.Res[6]= 0x00;
			
//		memset(YWTFEE.YWParkInfo.FEEMNY,0,2);//�����۷ѳ��� 	
		memcpy(YWTFEE.YWParkInfo.ParkMBNO,mbno,3);
		YWTFEE.YWParkInfo.ParkMBNO[3] = car;
		YWTFEE.YWParkInfo.ParkInOutTime[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.ParkInOutTime[i+1] = time[4-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.ParkInOutTime[6]= 0x00;			
		YWTFEE.CardType = YWT->CardType;
//		memcpy(YWTFEE.YYXLH,YWT->CSDMType,2);
		memcpy(YWTFEE.YYXLH,YWT->YYXLH,8);
//			YWTFEE.CSDMType//���д�������?
		YWTFEE.CSDMType =2;
		memcpy(YWTFEE.NC,0,2);
		memcpy(YWTFEE.SHDM,0,2);
		YWTFEE.POS[0] = 0x66;
		memcpy(YWTFEE.POS+1,mbno,3);
		if(falseinout == RecordMode_falseout)
			equ = 1;//6�ٳ���--7δ�ۿ����
		else
			equ = YWT_FEE_PRO(&YWTFEE,&YWTFEER);//�۷ѳ���
		if(equ!=1)
			{	
			buffer[0]= 1;
			//д����/�쳣ˢ���ı�־ 2015-08-06
			I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
			if(QuitTime>=4)
				{
				disp_YWT_IMG(3);	
				QuitFlag = 0;
				}
			else
				QuitFlag = 1;
			memset(buffer,0,8); 	
			write_momery_to_Fm(buffer,car);
			return;
			}			
		//�����۷Ѽ�¼�Ͷ��˼�¼ 2015-07-28
		buffer[0]= 0;
		//д����/�쳣ˢ���ı�־ 2015-08-06
		I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
		Smart_Power_OFF;//�ص�����ģ��ĵ�Դ Ϊ��ʡ��
		HR_TIME[car] = 0;
		err_1[car] = 0;
		WriteRecover(car,0);
		//3. ��λ����  
		light(car,NO);
		OPEN_EXTI9_5_IRQ();
		OPEN_EXTI15_10_IRQ();							
//		Buzz_0;
//		delay(KEYTIMEOUT_1S/10);
//		Buzz_1; 							
		//3. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ���֣�����ͣ��ʱ�䣩    
		buffer[0] = 0x00; //��λ״̬
		memset(buffer+1,0,4);//�������� 
		memcpy(buffer+5,YWT->snr,4);//��������	
//		memcpy(buffer+1,YWT->YYXLH,8);//��������	
		buffer[9] = time[3]; //��									   
		buffer[10] = time[2]; //��										
		buffer[11] = time[1]; //ʱ										 
		buffer[12] = time[0]; //��										 
		buffer[13] = time[4];//0x00; //�� Ԥ��										 
		buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ									  
		buffer[15] = max_stop_time % 60;																											 
		//д���� ��15���� ����ˢ
		write_car_15_reference(car,buffer,16);	 
		for(i=0;i<16;i++)
			buffer[i] = 0;
		write_car_reference_of_use_info(car,buffer,1);
		//д���ɹ� ��ȷ����
		buffer[0] = 0x00;														  
		I2C_WriteS_24C(car1_write_comd + (car - 1) ,buffer,1);
		//�ۿ�ɹ� ��ȷ����
		buffer[0] = 0x00;
		I2C_WriteS_24C((car1_value_comd + (car - 1)),buffer,1); 
		//1. ��ɷѼ�¼ 
		buffer[0] = 0xEE;//��¼ͷ
		memset(buffer+1,0,4);//��������	
		memcpy(buffer+5,YWT->snr,4);//��������	
//		memcpy(buffer+1,YWT->YYXLH,8);//��������	
		buffer[9] = YWT->YWParkInfo.ParkInOutTime[1];//time[4];//��
		memcpy(buffer+10,YWT->YWParkInfo.ParkDateTime,4);//��//��//ʱ//��
		if(falseinout ==6)
			cardmoney += pkmoney;//�ٳ�������ѿ�
		buffer[14] = cardmoney>>16;//
		buffer[15] = cardmoney>>8;//
		buffer[16] = cardmoney;//
		buffer[17] = mnybuf[2];
		buffer[18] = mnybuf[3];
		buffer[19] = ((car+CAR_CLASS)<<4) + 0x02;//��2��ͣ�� ��λΪcar 
		for(i=0;i<5;i++)
			buffer[20+i] = time[4-i];
		buffer[25] = CardType_CPC;//CPC��¼��־
		for(i=26;i<32;i++)buffer[i] = 0xAA;
		Save_Record(buffer,32);
		save_RPTMNY_record(CardType_CPC,pkmoney);//2015-12-07
		WriteRecord(car,RECORD_NULL);
		Deal_SwipCardIMG(car-1,0);
		
		//���˼�¼-2015-07-30 YWTFEER
		YWTFEER.RecFlag = 0;
		YWTFEER.Monthtype = 0;
		YWTFEER.Monthflag = 0;
		memcpy(YWTFEER.Cardno,YWT->snr,4);//��������
		YWTFEER.FeeFlag = falseinout;//1(5)-(��)�볡 2(6)-(��)���� 3-������ 4 -Ƿ���������� 7-δ�ۿ����
		I2C_ReadS_24C(SYS_SN,buffer,4);
		snno=hcl(buffer,4);
		snno += 1;
		fll(snno,buffer,4);
		I2C_WriteS_24C(SYS_SN,buffer,4);
		memcpy(YWTFEER.Sn,buffer+1,3);//��ˮ�ź�
		memset(YWTFEER.Res,0xff,4);//����		
		memcpy(record,RxBuffer+5,65);
		memcpy(record+65,&YWTFEER.RecFlag,1);
		memcpy(record+66,&YWTFEER.Monthtype,1);
		memcpy(record+67,&YWTFEER.Monthflag,1);
		memcpy(record+68,YWTFEER.Cardno,4);
		memcpy(record+72,&YWTFEER.FeeFlag,1);
		memcpy(record+73,YWTFEER.Sn,3);
		memcpy(record+76,YWTFEER.Res,4);		
		Save_Record(record,80);
		
		//��ʼ ���� ����			
		//�ж� �Ƿ�������ͣ��		
		equ = JD_LOOP_Park(car);
		flag_free = get_current_time(); 									
		if((flag_free == 1)&&(pkmoney==0))  // ͣ��  �շ�ʱ��  ��Ѳ���
			{
			buffer[0] = 0x01;
			buffer[1] = 0x01;
			//д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
			I2C_WriteS_24C((car1_useing + (car - 1)),buffer+1,1);
			//д����ͣ�� �ı�־
			I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04),buffer,1);
			}	
		else if((flag_free == 0)||pkmnyold)
			{
			buffer[0] = 0x00;
			buffer[1] = 0x00;
			//д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
			I2C_WriteS_24C((car1_useing + (car - 1)),buffer+1,1);
			//д����ͣ�� �ı�־
			I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04),buffer,1);
			}
		
		if(falseinout == RecordMode_nofee)
			{			
			TMP.cardmny = cardmoney;
//			TMP.feemny = pkmoney;
			memcpy(TMP.cardno,YWT->YYXLH,8);
			disp_YWT_IMG(2);
			return;//ǰ���Ѿ�������Ӧ����ʾ
			}
		//2. ��ʾͣ��ʱ�䣬ͣ�����ã�����ʣ����
		//cardmoney - pkmoney
		TMP.cardmny = cardmoney-pkmoney;
		TMP.feemny = pkmoney;
		TMP.feetime = pktime;		
		memcpy(TMP.cardno,YWT->YYXLH,8);
		memset(buffer,0,8);		
		write_momery_to_Fm(buffer,car);
		disp_YWT_IMG(6);//��ʾ������Ϣ		
		return;		
		}
//=========��λ����=========
//=========��λ����=========
//=========��λ����=========
//=========��λ����=========
	else
	{
	while(1)//����һ��ѭ���� 2015-09-08 andyluo
		{//��λ����
		falseinout = RecordMode_in;
		pkmoney = 0;
		//�к����� �ȼ���-����-ȫ��
		if(YWT->HMDBS)//��������
			{
			TMP.cardmny = cardmoney;
			memcpy(TMP.cardno,YWT->YYXLH,8);
			disp_YWT_IMG(11);//��ʾ��������		
			return; 	
			}
		
#ifdef testlist
		//32200100000000233227
		u8 listtestbuf[8] = {0x01,0x00,0x00,0x00,0x00,0x23,0x32,0x27};
		memcpy(YWT->YYXLH,listtestbuf,8);
		cardst = 0;
#endif

//�������ж�˳�� ����--����--ȫ��
		equ = SelectList_SRAM(YWT->YYXLH,ListType_CPCDEL,buffer);
		if(equ<0)
			{//���ڼ�����
			equ = SelectList_SRAM(YWT->YYXLH,ListType_CPCADD,buffer);
			if(equ<0)
				{//����������
				equ = SelectList_SRAM(YWT->YYXLH,ListType_CPCALL,buffer);
				}
#ifdef testing_OPEN//���Կ�����־
			equ = 2;
#endif		

			if(equ>=0)
				{
				falseinout = RecordMode_lockcard;//������¼��־
				TMP.cardmny = cardmoney;
				memcpy(TMP.cardno,YWT->YYXLH,8);
				I2C_ReadS_24C(SYS_LOCKCPC,buffer,1);//��������� 1-�� 0-��
#ifndef testing_LOCKCPC//���Կ�����־
				SYS_LIST.dayupflag = 1;//�������
#endif		
				buffer[0] = 0;//�ر���������2015��12��9��
				if(buffer[0]&&SYS_LIST.dayupflag)
					;
				else
					{
					disp_YWT_IMG(11);//��ʾ��������
					return;
					}
//				disp_YWT_IMG(11);//��ʾ��������
//				return;
				//�������������� 2015-08-24
				}
			}		
		
		if(cardst==1)
			{//���Ѳ���----���ٽ��������
			//�ٽ���-ֱ������ -���¼
			falseinout = RecordMode_falsein;
			//�ж����ڳ�λ�Ƿ��Ѿ�����?2015-08-20
			if(car == 2)
				i = 3;
			else if(car == 3)
				i = 2;
			read_car_reference_of_use_info(&CS_RF_US,i);//����λ״̬��Ϣ

			if(CS_RF_US.car_stop_way[0]==0x66)
				{
				equ = campare_card_NO(i,YWT->snr,CPU_CARD,1);
				if(equ==1)
					swipng =0;//�Ѳ����ж�
				}
//#ifndef EMI_ParkJG
//			swipng =1;//���β����ж� 2015-10-12
//#endif
			equ = campare_card_NO(car,YWT->snr,CPU_CARD,1);
			if((equ!=1)||(swipng==0))//ˢ���쳣 2015-08-06	����������
				{//��ʾδ����-
				buffer[0] = time[4];
				memcpy(buffer+1,YWT->YWParkInfo.ParkDateTime,4);
				pktime = ret_max_24hour(buffer,CPU_CARD);			
				I2C_ReadS_24C(LISTNET_ADD,buffer,16);	
				equ = -1;
				jdpktime = buffer[8]*60;
#ifdef testfeelist
				I2C_ReadS_24C(SYS_FEELIST,record,1);//Ƿ���������¿��� 1-�� 0-��
				if(record[0]==0)
					jdpktime = 0;
#endif
				if(pktime>=jdpktime)//�Զ�����
					{
					I2C_ReadS_24C(SYS_FEELIST,record,1);//Ƿ���������¿��� 1-�� 0-��
					if(record[0])
						{
						//�ж�Ƿ������
						//�����Զ�����ʱ������	���һ�β���ʱ��>����ʱ�� 2015-08-13
						equ = SelectList_SRAM(YWT->snr,ListType_CPCFEE,buffer);
						}
					else//Ƿ�������ر� ֱ��ѯ�ʺ�̨���� 2015-10-10
						{
		//================�Զ����ʼ2015-10-10=====================
						//���˹�����һ������
						Smart_Power_OFF;
						disp_cardfee(0);	
						TMP.car = car;
						TMP.cardtype = CardType_CPCRD;
						memcpy(TMP.cardno+4,YWT->snr,4);
						i = Send_CardFeeRecord(1);
						if(i>0)
							{
							disp_cardfee(1);
							delay(KEYTIMEOUT_1S*4);
							return;
							}
						if(TMP.feetime==0)
							{
							disp_cardfee(2);
							delay(KEYTIMEOUT_1S*4);
							return;
							}		
						//�Ƚ� TMP.time��YWT->YWParkInfo.ParkDateTime�Ĵ�С 
						//����ʱ��С�� ��λʱ�� ���ܲ��� 
						memcpy(buffer+1,YWT->YWParkInfo.ParkDateTime,4);
						buffer[0] = TMP.time[0];
						if(((TMP.time[1]==0x01)&&(buffer[1]==0x12))||//����
							(TMP.time[1]>buffer[1])||//MMDDHHMM
							((TMP.time[1]==buffer[1])||(TMP.time[2]>buffer[2]))||
							((TMP.time[1]==buffer[1])||(TMP.time[2]==buffer[2])||(TMP.time[3]>buffer[3]))||
							((TMP.time[1]==buffer[1])||(TMP.time[2]==buffer[2])||(TMP.time[3]==buffer[3])||(TMP.time[4]>=buffer[4])))
							{
							equ=0;
							SYS_LIST.dayupflag= 66;	
							
							lcd_clear();//���� ��ʾ ��ˢ��	
							Smart_Power_ON;
							delay(KEYTIMEOUT_1S/10);//������ʱ ��Ϊ�� �������� �ϵ�
							display_please_operation(time1[4],time1[3],time1[2],time1[1],time1[0],77);	   
							//TMP.feetime: TMP.feemny
							key_flag = 0;
							i = 4;
							CardInfo YWCardInfo;
							u8 card_class_flag;
							u32 timeOut;
							timeOut = 0;   
							while(i--)
								{
								while(timeOut < 300)
									{
									card_class_flag = inquire_card(&YWCardInfo);//��� ��������
										
									if((card_class_flag==CardType_MF1)||
										(card_class_flag==CardType_BIKE)||
										(card_class_flag==CardType_CPC))
										{
										break;
										}										
									if(key_flag != NO)
										{
										key_flag = 0;
										break;
										}										
									timeOut++;	
									}
								if(card_class_flag!=CardType_CPC)
									{
									timeOut = 0;
									if(i>1)continue;
									disp_cardfee(3);
									delay(KEYTIMEOUT_1S*4);
									return;
									}
								break;
								}
							
							}
						else//����ʱ��>��λʱ��
							{//��ʾδ����-
							memcpy(TMP.cardno,YWT->YYXLH,8);
							memcpy(TMP.time,YWT->YWParkInfo.ParkDateTime,4);
							memcpy(TMP.mbno,YWT->YWParkInfo.ParkMBNO,4);			
							disp_YWT_IMG(4);
							return; 				
							}
						}
					}
				if((equ>=0)&&SYS_LIST.dayupflag)//����Ƿ�Ѽ�¼ 2015-07-14
					{
					//buffer0-3 ����	4-5Ƿ�ѽ��  6-7δ���������1λ��+���ᱶ����3λ��
					if(SYS_LIST.dayupflag == 66)//��̨ѯ�ʲ���
						pkmnybk = TMP.feemny;
					else
						pkmnybk = hcl(buffer+4,2);
					falseinout = RecordMode_listfee;
				  	}		
				else
					{
					memcpy(TMP.cardno,YWT->YYXLH,8);
					memcpy(TMP.time,YWT->YWParkInfo.ParkDateTime,4);
					memcpy(TMP.mbno,YWT->YWParkInfo.ParkMBNO,4);
					TMP.mbno[0] = YWT->YWParkInfo.Res[6];
#ifndef LOOPIN//�������볡				
					disp_YWT_IMG(4);
					return;
#endif
					}
				}
			}
		//������	���߼ٽ���		
		//����-��Ƿ�ѽ���Ƿ�Ϊ0��
	if((YWT->YWParkInfo.CardType == 0x60)&&
		(YWT->YWParkInfo.UpdateFlag== 0x88))
		{
		pkmoney = hcl(YWT->YWParkInfo.FEEMNY,3);
		if(pkmoney>0)//����Ƿ�ѽ�� ֱ�ӿ۳�  ��ɵ�һ�β��� 2015-07-30
			{
			falseinout = RecordMode_cardfee;
			}
		if(falseinout ==RecordMode_listfee)pkmoney =pkmnybk;
#ifndef LOOPIN//�������볡
		if(cardmoney<pkmoney)//���С��Ƿ�ѽ��
			{			
			TMP.cardmny = cardmoney;
			memcpy(TMP.cardno,YWT->YYXLH,8);
			disp_YWT_IMG(5);//���� ���ֵ
			return;
			}
#else 
		pkmoney = 0;
#endif
		}
#ifdef testYWTmny
		pkmoney /= 100;//����ʱ�۷�-1
#else
#ifdef testYWTmny_10
		pkmoney /= 10;//����ʱ�۷�-1
#endif
#endif
		fll(pkmoney,mnybuf,4);
		YWTFEE.TradeDateTime[0] = 0x20;
		for(i=0;i<5;i++)
			YWTFEE.TradeDateTime[i+1] = time[4-i];
		YWTFEE.TradeDateTime[6] = 0x00;
		memcpy(YWTFEE.QBalance,YWT->Balance,4);
		memcpy(YWTFEE.Pays,mnybuf,4);
		//YWTFEE.ParkInfo
		YWTFEE.YWParkInfo.CardType = 0x60;
		//����С����ж� 2015-09-09
		if((falseinout==3)||(falseinout==4))
			{
//			YWTFEE.YWParkInfo.ParkFlag = 0x00;//��������δ�볡��־
			max_stop_time = momery_to_time(cardmoney-pkmoney);	
			if(max_stop_time==0)// Ǯ���� ������ͣ��
				YWTFEE.YWParkInfo.ParkFlag = 0x00;
			else
				YWTFEE.YWParkInfo.ParkFlag = 0x01;//��������δ�볡��־
			}
		else
			YWTFEE.YWParkInfo.ParkFlag = 0x01;//�����볡��־
		for(i=0;i<4;i++)
			YWTFEE.YWParkInfo.ParkDateTime[i] = time[3-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.UpdateFlag = 0x88;			
		YWTFEE.YWParkInfo.DongjieMoney[0] = 0x00;
		YWTFEE.YWParkInfo.DongjieMoney[1] = RR_ST1.Max_Stop_Momery;
//		memset(YWTFEE.YWParkInfo.Res,0xCC,7);
//		YWTFEE.YWParkInfo.Res[6] = car;
//		memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ��� 		
//		YWTFEE.YWParkInfo.ParkMBNO[0] = 0x66;
//		memcpy(YWTFEE.YWParkInfo.ParkMBNO+1,mbno,3);
		YWTFEE.YWParkInfo.Res[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.Res[i+1] = time[4-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.Res[6]= 0x00;
			
//		memset(YWTFEE.YWParkInfo.FEEMNY,0,2);//�����۷ѳ��� 	
		memcpy(YWTFEE.YWParkInfo.ParkMBNO,mbno,3);
		YWTFEE.YWParkInfo.ParkMBNO[3] = car;
		
		YWTFEE.YWParkInfo.ParkInOutTime[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.ParkInOutTime[i+1] = time[4-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.ParkInOutTime[6]= 0x00;			
		YWTFEE.CardType = YWT->CardType;
//		memcpy(YWTFEE.YYXLH,YWT->CSDMType,2);
		memcpy(YWTFEE.YYXLH+2,YWT->YYXLH,8);
//			YWTFEE.CSDMType//���д�������?
		YWTFEE.CSDMType =2;
		memcpy(YWTFEE.NC,0,2);
		memcpy(YWTFEE.SHDM,0,2);
		YWTFEE.POS[0] = 0x66;
		memcpy(YWTFEE.POS+1,mbno,3);
		//����-���� -���¼
		//1. �ݴ� ����� ��ʹ��״̬����
		write_momery_to_Fm(YWT->Balance,car);
		//����ͣ��		
		//д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
		I2C_ReadS_24C((car1_useing + (car - 1)),&feeflag,1);
		ReadCar_15_Info(car,buffer);
		pktime = ret_max_24hour(buffer+9,SELECT);
		if((pktime>=60)||(feeflag==0x00))
			{
			//�����λ����Ϣ ʹ����ˢ15���Ӻ� �ȽϿ��Ų�ͬ
			for(i=0;i<16;i++)
				buffer[i] = 0;
			write_car_15_reference(car,buffer,16);
			write_car_reference_of_use_info(car,buffer,16);
			}
		//2. ���ݿ������ �������ͣ��ʱ��
		if((falseinout ==RecordMode_listfee)||
			(falseinout ==RecordMode_cardfee))
			max_stop_time = 60;
		else
			max_stop_time = momery_to_time(cardmoney-pkmoney);	
		if(max_stop_time==0)// Ǯ���� ������ͣ��
			{	
				
			if(TMP.autofee == 1)//�Զ������־ 2015-09-08
				{
				TMP.feemny = TMP.feemnybak;
				disp_YWT_IMG(7);//��ʾǷ�����������볡��Ϣ		
				}
			
		//���ͣ��ʱ�� Ϊ 0		
			TMP.cardmny = cardmoney;
			memcpy(TMP.cardno,YWT->YYXLH,8);
			disp_YWT_IMG(5);//���� ���ֵ
			return;
			}
		if(falseinout==RecordMode_lockcard)//����	--������������	
			{
			equ = 1;//������������			
			YWTFEE.POS[0] = 0x88;
			}
        if((TMP.CPC_ckmny[car]!= cardmoney)&&
			TMP.CPC_ckmny[car]&&
			((falseinout ==RecordMode_listfee)||
			(falseinout ==RecordMode_cardfee)))
			{
			equ = 1;	
			cardmoney = TMP.CPC_ckmny[car];
			}
		else if(TMP.autofee == 1)//�Զ�����2015-09-08
			equ = 1;
		else if(falseinout==RecordMode_falsein)//�ٽ���
			equ = 1;
		else
			equ = YWT_FEE_PRO(&YWTFEE,&YWTFEER);//�۷ѳ���
		if(equ != 1)//�ۿ�ɹ�
			{//����Ҫ���ݴ�����//д����ͨ�� ���� �����־
			TMP.CPC_ckmny[car] = hcl(YWT->Balance,4);
			buffer[0] = 0x01;
			I2C_WriteS_24C(car1_LNT_comd + (car - 1),buffer,1);				
			buffer[0] = 0x00; //��λ״̬ 	
			memset(buffer+1,0,4);//�������� 
			memcpy(buffer+5,YWT->snr,4);//��������	
//			memcpy(buffer+1,YWT->YYXLH,8);//��������	
			buffer[9] = time[3]; //��									   
			buffer[10] = time[2]; //��										
			buffer[11] = time[1]; //ʱ										 
			buffer[12] = time[0]; //��										 
			buffer[13] = time[4];//0x00; //�� Ԥ��										 
			buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ 									  
			buffer[15] = max_stop_time % 60; 																											 
			write_car_reference_of_use_info(car,buffer,16);					
			Smart_Power_OFF;//�ص�����ģ��ĵ�Դ 
			OPEN_EXTI9_5_IRQ(); 									  
			OPEN_EXTI15_10_IRQ();
			QuitFlag = 1;
			buffer[0]= 1;
			//д����/�쳣ˢ���ı�־ 2015-08-06
			if(falseinout != 4)//�������
			I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
			memset(buffer,0,8); 	
			write_momery_to_Fm(buffer,car);
			return;
			}
		TMP.CPC_ckmny[car] =0;
		buffer[0]= 0;
		//д����/�쳣ˢ���ı�־ 2015-08-06
		I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
		//�ۿ�ɹ� 
		Smart_Power_OFF;//�ص�����ģ��ĵ�Դ		
		//1. �汾��λ����//�Ѿ�д��
		//���˼�¼-2015-07-30 YWTFEER
		YWTFEER.RecFlag = 0;
		YWTFEER.Monthtype = 0;
		YWTFEER.Monthflag = 0;
		memcpy(YWTFEER.Cardno,YWT->snr,4);//��������
		YWTFEER.FeeFlag = falseinout;//1(5)-(��)�볡 2(6)-(��)���� 3-������ 4 -Ƿ����������
		I2C_ReadS_24C(SYS_SN,buffer,4);
		snno=hcl(buffer,4);
		snno += 1;
		fll(snno,buffer,4);
		I2C_WriteS_24C(SYS_SN,buffer,4);
		memcpy(YWTFEER.Sn,buffer+1,3);//��ˮ�ź�
		memset(YWTFEER.Res,0xff,4);//����		
		memcpy(record,RxBuffer+5,65);
		memcpy(record+65,&YWTFEER.RecFlag,1);
		memcpy(record+66,&YWTFEER.Monthtype,1);
		memcpy(record+67,&YWTFEER.Monthflag,1);
		memcpy(record+68,YWTFEER.Cardno,4);
		memcpy(record+72,&YWTFEER.FeeFlag,1);
		memcpy(record+73,YWTFEER.Sn,3);
		memcpy(record+76,YWTFEER.Res,4);		
		Save_Record(record,80);	
		OPEN_EXTI9_5_IRQ(); 
		OPEN_EXTI15_10_IRQ();
		if(falseinout==RecordMode_lockcard)//�����ɹ���
			{
			disp_YWT_IMG(11);//��ʾ��������
			return;
			}
		
		//����ͨ�ļ�¼	�����ļ�¼	
		
		//2. ��ͣ����¼
		buffer[0] = 0xEE;//��¼ͷ
		if(falseinout==RecordMode_listfee)//����
			{
			buffer[1] = 0;
			buffer[2] = 1;
			buffer[3] = YWT->YWParkInfo.DongjieMoney[0];
			buffer[4] = YWT->YWParkInfo.DongjieMoney[1];
			}	
		else
			memset(buffer+1,0,4);//�������� 
		memcpy(buffer+5,YWT->snr,4);//��������	
//		memcpy(buffer+1,YWT->YYXLH,8);//��������	
		for(i=0;i<5;i++)
			buffer[9+i] = time[4-i];//��//��//��//ʱ//��
		memcpy(buffer+14,YWT->Balance+1,3);
		
		buffer[17] = mnybuf[2];
		buffer[18] = mnybuf[3];
		
		if(falseinout==RecordMode_listfee)
			{
			buffer[19] = ((car+CAR_CLASS)<<4) + 0x07;//������δ����
			bushimny[car] = 0;   
			bukanmny[car] = 0;	
			TMP.CPC_ckmny[car] = 0;
			}
		else if(falseinout==RecordMode_cardfee)
			buffer[19] = ((car+CAR_CLASS)<<4) + 0x03;//����
		else
			{
			buffer[19] = ((car+CAR_CLASS)<<4) + 0x01;//��һ��ͣ�� ��λΪcar 
			bushimny[car] = 0;   
			bukanmny[car] = 0;	
			TMP.CPC_ckmny[car] = 0;
			}
		for(i=0;i<5;i++)
			buffer[20+i] = time[4-i];//��//��//��//ʱ//��
		buffer[25] = CardType_CPC;//����ͨ��¼��־			
		for(i=26;i<32;i++)
			buffer[i] = 0xAA;							   
		Save_Record(buffer,32);		
		save_RPTMNY_record(CardType_CPC,pkmoney);//2015-12-07
		WriteRecord(car,CardType_CPC);//д�� ��¼�ı�־		

		pktime = max_stop_time;
		TMP.cardmny = cardmoney - pkmoney;
		TMP.feemny = pkmoney;
		TMP.feetime= pktime;		
		memcpy(TMP.cardno,YWT->YYXLH,8);
		if(falseinout==RecordMode_listfee)
			{
//			disp_YWT_IMG(7);//��ʾǷ�����������볡��Ϣ		
			//�����λ����Ϣ ʹ����ˢ15���Ӻ� �ȽϿ��Ų�ͬ
			for(i=0;i<16;i++)
				buffer[i] = 0;
			write_car_15_reference(car,buffer,16);
			write_car_reference_of_use_info(car,buffer,16);
			
			TMP.autofee = 1;//2015-09-08
//			QuitFlag = 1;//����Ѱ�� �볡
//			QuitTime--;
			TMP.feemnybak = TMP.feemny; 	
			fll(TMP.cardmny,YWT->Balance,4);
			cardst = 0;
			fll(0,YWT->YWParkInfo.FEEMNY,3);
			cardmoney  = TMP.cardmny;			
			continue;
			}
		else if(falseinout==RecordMode_cardfee)
			{			
//			disp_YWT_IMG(8);//��ʾ�������볡��Ϣ	
			//�����λ����Ϣ ʹ����ˢ15���Ӻ� �ȽϿ��Ų�ͬ
			for(i=0;i<16;i++)
				buffer[i] = 0;
			write_car_15_reference(car,buffer,16);
			write_car_reference_of_use_info(car,buffer,16);

			TMP.autofee = 1;//2015-09-08
//			QuitFlag = 1;//����Ѱ�� �볡
//			QuitTime--;
			TMP.feemnybak = TMP.feemny;		
			fll(TMP.cardmny,YWT->Balance,4);
			cardst = 0;
			fll(0,YWT->YWParkInfo.FEEMNY,3);
			cardmoney  = TMP.cardmny;
			continue;
			//return;
			}
		Deal_SwipCardIMG(car-1,1);
		if(campare_card_NO(car,YWT->snr,CPU_CARD,1))
		  { 
		  buffer[0] = 0x01;
		  I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04) + 1,buffer,1);  
		  } 
		else	  
		  {
		  buffer[0] = 0x00;
		  I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04) + 1,buffer,1);											
		  } 
		//��λ����
		light(car,OK); 		
//		Buzz_0;
//		delay(KEYTIMEOUT_1S/20);
//		Buzz_1;
		//4. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ��������ͣ��ʱ�䣩											
		buffer[0] = 0x66; //��λ״̬ 									  
		memset(buffer+1,0,4);//�������� 
		memcpy(buffer+5,YWT->snr,4);//��������	
//		memcpy(buffer+1,YWT->YYXLH,8);//��������	
		buffer[9] = time[3]; //��									   
		buffer[10] = time[2]; //��										
		buffer[11] = time[1]; //ʱ										 
		buffer[12] = time[0]; //��										 
		buffer[13] = time[4];//��									 
		buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ 									  
		buffer[15] = max_stop_time % 60; 																											 
		memcpy(buffer+16,YWT->Balance,4);
		write_car_reference_of_use_info(car,buffer,16);
		write_momery_to_Fm(YWT->Balance,car);
		//3. ��ʾ��������ǰʱ�䣬��ͣ��ʱ��
		pktime = max_stop_time;
		TMP.cardmny = cardmoney - pkmoney;
		TMP.feemny = pkmoney;
		TMP.feetime= pktime;		
		memcpy(TMP.cardno,YWT->YYXLH,8);
		if(TMP.autofee == 1)//�Զ������־ 2015-09-08
			{
			for(i=0;i<5;i++)
				TMP.CPC_ckmny[i] =0;
			TMP.feemny = TMP.feemnybak;
			disp_YWT_IMG(7);//��ʾǷ�����������볡��Ϣ		
			}
			
		if(falseinout==RecordMode_listfee)
			disp_YWT_IMG(7);//��ʾǷ�����������볡��Ϣ		
		else if(falseinout==RecordMode_cardfee)
			disp_YWT_IMG(8);//��ʾ�������볡��Ϣ		
		else if(falseinout==RecordMode_falsein)
			disp_YWT_IMG(9);//��ʾ���볡��Ϣ		
		else
			disp_YWT_IMG(10);//��ʾ�볡��Ϣ		
		return;		
		}
	}
}
//���г����������� 2015-07-18
//space-��λ�� IQflag-˫����ѯ��־
void BIKECARD_PRO(u8 space,u8 spacestate,CardInfo *YWT)
{

	return;//�ر����г�������

/*
s32 equ;
u32 cardmoney,pktime,jdpktime,pkmoney,pkmnyold,max_stop_time,timeOut;
u8 i,car,carst,cardst,feeflag,swipng;//1-ˢ���쳣 0-����
u8 mbno[3],mnybuf[4],buffer[32];
u8 falseinout,card_class_flag;//1(5)-(��)�볡 2(6)-(��)���� 3-������ 
			// 4 -Ƿ���������� 7-δ�ۿ���� F-������¼
SubMoneyCMD YWTFEE;
PosRecordInfo YWTFEER;
carStation_reference_of_used CS_RF_US;

	get_rate_ref(&RR_ST1); 
	max_stop_time = RR_ST1.Max_Park_Time*60;
	QuitFlag = 0;
	I2C_ReadS_24C(mibiao_number,mbno,3);//�����
	car = space;//��λ��
	carst = spacestate;//66-�볡 0- ����
	cardst = YWT->YWParkInfo.ParkFlag;	
	if((YWT->YWParkInfo.CardType != 0x60)||
		(YWT->YWParkInfo.UpdateFlag != 0x88))
		cardst = 0;//�¿�Ĭ��Ϊ����ģʽ 2015-08-05
	memset(YWT->Balance,0,4);	
	cardmoney = hcl(YWT->Balance,4);
	cardmoney = 0;
    read_car_reference_of_use_info(&CS_RF_US,car);//����λ״̬��Ϣ  
	
	//д����/�쳣ˢ���ı�־ 2015-08-06
	I2C_ReadS_24C(Car1_SwipNG+car-1,buffer,1);	
	swipng = buffer[0];
	
	TMP.cpc = 0;

//	memcpy(YWTFEE.YWParkInfo.ParkMBNO+1,mbno,3);
	if((mbno[0]!=YWT->YWParkInfo.ParkMBNO[1])||
	   (mbno[1]!=YWT->YWParkInfo.ParkMBNO[2])||
	   (mbno[2]!=YWT->YWParkInfo.ParkMBNO[3]))
	   swipng = 0;//�Ǽٽ���ٳ� 2015-09-02

//�������ж�˳�� ����--����--ȫ��		
//	equ = SelectList_SRAM(YWT->YYXLH+4,ListType_BIKEDEL,buffer);
//	equ = SelectList_SRAM(YWT->YYXLH+4,ListType_BIKEADD,buffer);
//	equ = SelectList_SRAM(YWT->YYXLH+4,ListType_BIKEALL,buffer);
//	if(equ<0)
//		{//���ڼ�����
//		equ = SelectList_SRAM(YWT->YYXLH+4,ListType_BIKEADD,buffer);
//		if(equ<0)
//			{//����������
//			equ = SelectList_SRAM(YWT->YYXLH+4,ListType_BIKEALL,buffer);
//			}
//		if(equ>=0)
//			{
//			falseinout = 0x0F;//������¼��־
//			TMP.cardmny = cardmoney;
//			memcpy(TMP.cardno,YWT->YYXLH,8);
//			disp_YWT_IMG(11);//��ʾ��������
//			return;
//			}
//		}

	//���� ��ʱ ���� Ƿ�Ѳ������� 2015-08-11
//=========��λ��ʱ=========
//=========��λ����=========
//=========��λǷ��=========
while(1)//����һ��ѭ���� 2015-09-08 andyluo
	{
	if((carst == 0x88)||//��ʱ  -E
		(carst == 0x99))//���� -7
		{
		if(carst == 0x88)//��ʱ  -E
			{
			if(cardst==1)
				{
				memcpy(TMP.cardno,YWT->YYXLH,8);
				memcpy(TMP.time,YWT->YWParkInfo.ParkDateTime,4);
				memcpy(TMP.mbno,YWT->YWParkInfo.ParkMBNO,4);			
				disp_YWT_IMG(4);
				return;
				}
			}
		else if(carst == 0x99)//����
			{
			//�Ƚ� TMP.time��YWT->YWParkInfo.ParkDateTime�Ĵ�С 
			//����ʱ��С�� ��λʱ�� ���ܲ��� 
			memcpy(buffer+1,YWT->YWParkInfo.ParkDateTime,4);
			buffer[0] = TMP.time[0];
			if(((TMP.time[1]==0x01)&&(buffer[1]==0x12))||//����
				(TMP.time[1]>buffer[1])||//MMDDHHMM
				((TMP.time[1]==buffer[1])||(TMP.time[2]>buffer[2]))||
				((TMP.time[1]==buffer[1])||(TMP.time[2]==buffer[2])||(TMP.time[3]>buffer[3]))||
				((TMP.time[1]==buffer[1])||(TMP.time[2]==buffer[2])||(TMP.time[3]==buffer[3])||(TMP.time[4]>buffer[4])))
				;
			else//����ʱ��>��λʱ��
				{
				TMP.cardmny = cardmoney;
				memcpy(TMP.cardno,YWT->YYXLH,8);
				memcpy(TMP.time,YWT->YWParkInfo.ParkDateTime,4);
//				memcpy(TMP.mbno,YWT->YWParkInfo.ParkMBNO,4);			
//				memcpy(TMP.mbno,YWT->YWParkInfo.ParkDateTime,4);			
				disp_YWT_IMG(16);//��ʾ���ܲ���
				return;
				}
			}
		falseinout = carst;
#ifdef proing
		disp_YWT_IMG(100);
		return;
#endif		
		pkmoney =TMP.feemny;

		memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ��� 		

#ifdef testYWTmny
		pkmoney /= 100;//����ʱ�۷�-1
#endif
		fll(pkmoney,mnybuf,4);

		YWTFEE.TradeDateTime[0] = 0x20;
		for(i=0;i<5;i++)
			YWTFEE.TradeDateTime[i+1] = time[4-i];
		YWTFEE.TradeDateTime[6] = 0x00;
		memcpy(YWTFEE.QBalance,YWT->Balance,4);
		memcpy(YWTFEE.Pays,mnybuf,4);
		//YWTFEE.ParkInfo
		YWTFEE.YWParkInfo.CardType = 0x60;
		if(TMP.autofee == 1)
			YWTFEE.YWParkInfo.ParkFlag = 0x01;//�Զ������볡
		else
			YWTFEE.YWParkInfo.ParkFlag = 0x00;
		for(i=0;i<4;i++)
			YWTFEE.YWParkInfo.ParkDateTime[i] = time[3-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.UpdateFlag = 0x88;			
		YWTFEE.YWParkInfo.DongjieMoney[0] = 0x00;
		YWTFEE.YWParkInfo.DongjieMoney[1] = 0x00;//RR_ST1.Max_Stop_Momery;
		memset(YWTFEE.YWParkInfo.Res,0xCC,7);
		YWTFEE.YWParkInfo.Res[6] = car;
//		memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ��� 		
		YWTFEE.YWParkInfo.ParkMBNO[0] = 0x66;
		memcpy(YWTFEE.YWParkInfo.ParkMBNO+1,mbno,3);
		YWTFEE.YWParkInfo.ParkInOutTime[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.ParkInOutTime[i+1] = time[4-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.ParkInOutTime[6]= 0x00;			
		YWTFEE.CardType = YWT->CardType;
		memcpy(YWTFEE.YYXLH,YWT->snr,4);
//			YWTFEE.CSDMType//���д�������?
		YWTFEE.CSDMType =2;
		memcpy(YWTFEE.NC,0,2);
		memcpy(YWTFEE.SHDM,0,2);
		YWTFEE.POS[0] = 0x66;
		memcpy(YWTFEE.POS+1,mbno,3);
		equ = YWT_FEE_PRO(&YWTFEE,&YWTFEER);//�۷ѳ���	
		if(equ!=1)
			{
//			buffer[0]= 1;
//			//д����/�쳣ˢ���ı�־ 2015-08-06
//			I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
			disp_YWT_IMG(3);				
			QuitFlag = 1;
			memset(buffer,0,8); 	
			write_momery_to_Fm(buffer,car);
			return;
			}
		
		//1. �油ʱ-�����¼ 
		buffer[0] = 0xEE;//��¼ͷ
		
//		memcpy(buffer+5,YWT->snr,4);//��������	
		memcpy(buffer+1,YWT->YYXLH,8);//��������	
		if(carst == 0x99)//����
			{
			buffer[1] = 0;
			buffer[2] = 1;
			buffer[3] = YWT->YWParkInfo.DongjieMoney[0];
			buffer[4] = YWT->YWParkInfo.DongjieMoney[1];
			}			
		else if(carst == 0x88)//��ʱ
			memset(buffer+1,0,4);//�������� 
			
//		buffer[9] = time[4];//��
//		memcpy(buffer+10,YWT->YWParkInfo.ParkDateTime,4);//��//��//ʱ//��
		if(carst == 0x99)//����
			{
			for(i=0;i<5;i++)
				buffer[9+i] = time[4-i];
			}
		else if(carst == 0x88)//��ʱ
			{
			for(i=0;i<5;i++)
				buffer[9+i] = TMP.time[4-i];
			}
		
		buffer[14] = cardmoney>>16;//
		buffer[15] = cardmoney>>8;//
		buffer[16] = cardmoney;//
		buffer[17] = mnybuf[2];
		buffer[18] = mnybuf[3];
		if(carst == 0x99)//����
			buffer[19] = ((car+CAR_CLASS)<<4) + 0x07;//���� ��λΪcar 
		else if(carst == 0x88)//��ʱ
			buffer[19] = ((car+CAR_CLASS)<<4) + 0x0E;//��ʱ ��λΪcar 
		for(i=0;i<5;i++)
			buffer[20+i] = time[4-i];
		buffer[25] = CardType_BIKE;//CPC��¼��־
		for(i=26;i<32;i++)buffer[i] = 0xAA;
		for(i=26;i<30;i++)buffer[i] = TMP.opcardno[i-26];
		Save_Record(buffer,32);

		TMP.cardmny = cardmoney-pkmoney;
		TMP.feemny = pkmoney;
		TMP.feetime = pktime;		
		memcpy(TMP.cardno,YWT->YYXLH,8);
		if(TMP.rerun)
			{
			TMP.autofee = 1;//2015-09-08
//			QuitFlag = 1;//����Ѱ�� �볡
//			QuitTime--;
			TMP.feemnybak = TMP.feemny; 	
			fll(TMP.cardmny,YWT->Balance,4);
			cardst = 0;
			carst = 0;
			fll(0,YWT->YWParkInfo.FEEMNY,3);
			continue;
			}
		
		if(carst == 0x99)//����
			disp_YWT_IMG(14);//����-��ʱ�ɹ�		
		else if(carst == 0x88)//��ʱ
			disp_YWT_IMG(15);//����-��ʱ�ɹ�		
		return;
		}
//=========��λռ��=========
//=========��λռ��=========
//=========��λռ��=========
//=========��λռ��=========
	else if(carst == 0x66)
		{//��λ�Ѳ���		
		falseinout = 2;
		equ = campare_card_NO(car,YWT->YYXLH+4,CPU_CARD,1);
//		if(swipng)//ˢ���쳣 2015-08-06  ����������
		if(cardst==0)//������
			{
			falseinout = 6;//�ٳ���
			}		
		//���Ѳ���
		if(equ == NO)//���Ų���ͬ
			{
			disp_YWT_IMG(1);
			return;
			}
		//��������---2015-07-27
		//1.����ͣ��ʱ���ͣ������		
		pktime = ret_max_24hour(CS_RF_US.start_stopTime,MIFARAE_PARK_CARD);							  
		pkmoney = time_to_momery(CS_RF_US.start_stopTime);
//		pktime = ret_max_24hour(YWT->YWParkInfo.ParkInOutTime+1,CPU_CARD);							 
//		pkmoney = time_to_momery(YWT->YWParkInfo.ParkDateTime);	 
//		if(pkmoney>cardmoney)//����
//			{//��ʾ�������ѽ�� ���ۿ�
//			TMP.cardmny = cardmoney;
//			TMP.feemny = pkmoney;
//			memcpy(TMP.cardno,YWT->YYXLH,8);
//			disp_YWT_IMG(2);
//			//�������¼
//			falseinout = 7;//δ�ۿ����
//			}
		pkmnyold = pkmoney;
		if(pkmoney==0)//�ж��Ƿ�Ϊ������Ѳ���
			{
			equ = JD_LOOP_Park(car);
			if(equ==1)//��С�շ�
				pkmoney = RR_ST1.Frist_Money * RR_ST1.Sale_Base;
			}
#ifdef testYWTmny
		pkmoney /= 100;//����ʱ�۷�-1
#endif
		if(falseinout == 7)//δ�ۿ����
			{
			fll(pkmoney,mnybuf,4);
			memcpy(YWTFEE.YWParkInfo.FEEMNY,mnybuf+1,3);//δ�۷ѳ��� 		
			pkmoney = 0;
			}
		else
			memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ���			

		fll(pkmoney,mnybuf,4);
		YWTFEE.TradeDateTime[0] = 0x20;
		for(i=0;i<5;i++)
			YWTFEE.TradeDateTime[i+1] = time[4-i];
		YWTFEE.TradeDateTime[6] = 0x00;
		memcpy(YWTFEE.QBalance,YWT->Balance,4);
		memcpy(YWTFEE.Pays,mnybuf,4);
		//YWTFEE.ParkInfo
		YWTFEE.YWParkInfo.CardType = 0x60;
		YWTFEE.YWParkInfo.ParkFlag = 0x00;
		for(i=0;i<4;i++)
			YWTFEE.YWParkInfo.ParkDateTime[i] = time[3-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.UpdateFlag = 0x88;			
		YWTFEE.YWParkInfo.DongjieMoney[0] = 0x00;
		YWTFEE.YWParkInfo.DongjieMoney[1] = 0x00;//RR_ST1.Max_Stop_Momery;
		memset(YWTFEE.YWParkInfo.Res,0xCC,7);
		YWTFEE.YWParkInfo.Res[6] = car;
//		memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ���			
		YWTFEE.YWParkInfo.ParkMBNO[0] = 0x66;
		memcpy(YWTFEE.YWParkInfo.ParkMBNO+1,mbno,3);
		YWTFEE.YWParkInfo.ParkInOutTime[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.ParkInOutTime[i+1] = time[4-i];//��//��//��//ʱ//��
		YWTFEE.YWParkInfo.ParkInOutTime[6]= 0x00;			
		YWTFEE.CardType = YWT->CardType;
		memcpy(YWTFEE.YYXLH,YWT->snr,4);
		memset(YWTFEE.YYXLH+4,0,4);
//			YWTFEE.CSDMType//���д�������?
		YWTFEE.CSDMType =2;
		memcpy(YWTFEE.NC,0,2);
		memcpy(YWTFEE.SHDM,0,2);
		YWTFEE.POS[0] = 0x66;
		memcpy(YWTFEE.POS+1,mbno,3);
		if(falseinout == 6)
			equ = 1;//6�ٳ���--7δ�ۿ����
		else
			equ = YWT_FEE_PRO(&YWTFEE,&YWTFEER);//�۷ѳ���
		if(equ != 1)
			{	
			buffer[0]= 1;
			//д����/�쳣ˢ���ı�־ 2015-08-06
			I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
			disp_YWT_IMG(3);				
			QuitFlag = 1;
			memset(buffer,0,8); 	
			write_momery_to_Fm(buffer,car);
			return;
			}			
		//�����۷Ѽ�¼�Ͷ��˼�¼ 2015-07-28
		buffer[0]= 0;
		//д����/�쳣ˢ���ı�־ 2015-08-06
		I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
		Smart_Power_OFF;//�ص�����ģ��ĵ�Դ Ϊ��ʡ��
		HR_TIME[car] = 0;
		err_1[car] = 0;
		WriteRecover(car,0);
		//3. ��λ����  
		light(car,NO);
		OPEN_EXTI9_5_IRQ();
		OPEN_EXTI15_10_IRQ();							
//		Buzz_0;
//		delay(KEYTIMEOUT_1S/10);
//		Buzz_1; 							
		//3. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ���֣�����ͣ��ʱ�䣩    
		buffer[0] = 0x00; //��λ״̬
		memset(buffer+1,0,4);//�������� 
//		memcpy(buffer+5,YWT->snr,4);//��������	
		memcpy(buffer+1,YWT->YYXLH,8);//��������	
		buffer[9] = time[3]; //��									   
		buffer[10] = time[2]; //��										
		buffer[11] = time[1]; //ʱ										 
		buffer[12] = time[0]; //��										 
		buffer[13] = time[4];//0x00; //�� Ԥ��										 
		buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ									  
		buffer[15] = max_stop_time % 60;																											 
		//д���� ��15���� ����ˢ
		write_car_15_reference(car,buffer,16);	 
		for(i=0;i<16;i++)
			buffer[i] = 0;
		write_car_reference_of_use_info(car,buffer,1);
		//д���ɹ� ��ȷ����
		buffer[0] = 0x00;														  
		I2C_WriteS_24C(car1_write_comd + (car - 1) ,buffer,1);
		//�ۿ�ɹ� ��ȷ����
		buffer[0] = 0x00;
		I2C_WriteS_24C((car1_value_comd + (car - 1)),buffer,1); 
		//1. ��ɷѼ�¼ 
		buffer[0] = 0xEE;//��¼ͷ
		memset(buffer+1,0,4);//��������	
//		memcpy(buffer+5,YWT->snr,4);//��������	
		memcpy(buffer+1,YWT->YYXLH,8);//��������	
		buffer[9] = time[4];//��
		memcpy(buffer+10,YWT->YWParkInfo.ParkDateTime,4);//��//��//ʱ//��
//		if(falseinout ==6)
//			cardmoney += pkmoney;//�ٳ�������ѿ�
		buffer[14] = cardmoney>>16;//
		buffer[15] = cardmoney>>8;//
		buffer[16] = cardmoney;//
		buffer[17] = mnybuf[2];
		buffer[18] = mnybuf[3];
		buffer[19] = ((car+CAR_CLASS)<<4) + 0x02;//��2��ͣ�� ��λΪcar 
		for(i=0;i<5;i++)
			buffer[20+i] = time[4-i];
		buffer[25] = CardType_BIKE;//CPC��¼��־
		for(i=26;i<32;i++)buffer[i] = 0xAA;
		Save_Record(buffer,32);
		WriteRecord(car,RECORD_NULL);
		Deal_SwipCardIMG(car-1,0);			
		//��ʼ ���� ����			
		//�ж� �Ƿ�������ͣ��		
		equ = JD_LOOP_Park(car);
		flag_free = get_current_time(); 									
		if((flag_free == 1)&&(pkmoney==0))  // ͣ��  �շ�ʱ��  ��Ѳ���
			{
			buffer[0] = 0x01;
			buffer[1] = 0x01;
			//д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
			I2C_WriteS_24C((car1_useing + (car - 1)),buffer+1,1);
			//д����ͣ�� �ı�־
			I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04),buffer,1);
			}	
		else if((flag_free == 0)||pkmnyold)
			{
			buffer[0] = 0x00;
			buffer[1] = 0x00;
			//д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
			I2C_WriteS_24C((car1_useing + (car - 1)),buffer+1,1);
			//д����ͣ�� �ı�־
			I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04),buffer,1);
			}
		
		if(falseinout == 7)return;//ǰ���Ѿ�������Ӧ����ʾ
		//2. ��ʾͣ��ʱ�䣬ͣ�����ã�����ʣ����
		//cardmoney - pkmoney
		TMP.cardmny = cardmoney-pkmoney;
		TMP.feemny = pkmoney;
		TMP.feetime= pktime;		
		memcpy(TMP.cardno,YWT->YYXLH,8);
		memset(buffer,0,8);		
		write_momery_to_Fm(buffer,car);
		disp_YWT_IMG(6);//��ʾ������Ϣ		
		return;		
		}
//=========��λ����=========
//=========��λ����=========
//=========��λ����=========
//=========��λ����=========
	else
		{//��λ����
		falseinout = 1;
		//�к����� �ȼ���-����-ȫ��
//		if(YWT->HMDBS)//��������
//			{
//			TMP.cardmny = cardmoney;
//			memcpy(TMP.cardno,YWT->YYXLH,8);
//			disp_YWT_IMG(11);//��ʾ��������		
//			return; 	
//			}
#ifdef testlist
		//32200100000000233227 02126429
//		u8 listtestbuf[8] = {0x01,0x00,0x00,0x00,0x00,0x23,0x32,0x27};
		u8 listtestbuf[8] = {0x00,0x00,0x00,0x00,0x02,0x12,0x64,0x29};
		memcpy(YWT->YYXLH,listtestbuf,8);
		cardst = 0;
#endif

	
//�������ж�˳�� ����--����--ȫ��		
		equ = SelectList_SRAM(YWT->YYXLH+4,ListType_BIKEDEL,buffer);
		if(equ<0)
			{//���ڼ�����
			equ = SelectList_SRAM(YWT->YYXLH+4,ListType_BIKEADD,buffer);
			if(equ<0)
				{//����������
				equ = SelectList_SRAM(YWT->YYXLH+4,ListType_BIKEALL,buffer);
				}
			if(equ>=0)
				{
				falseinout = 0x0F;//������¼��־
				TMP.cardmny = cardmoney;
				memcpy(TMP.cardno,YWT->YYXLH,8);
				disp_YWT_IMG(11);//��ʾ��������
#ifndef LOCKCPC_OPEN//����������־
				return;
#endif
				}
			}	
//		cardst = 0;//2015-09-09 ���Կ���
		if(cardst==1)
			{//���Ѳ���----���ٽ��������
			//�ж��Ƿ�ﵽ��󲴳�ʱ��
			buffer[0] = time[4];
			memcpy(buffer+1,YWT->YWParkInfo.ParkDateTime,4);
			pktime = ret_max_24hour(buffer,CPU_CARD);
			
			//�����Զ�����ʱ������	���һ�β���ʱ��>����ʱ�� 2015-08-13
			I2C_ReadS_24C(LISTNET_ADD,buffer,16);	
			jdpktime = buffer[8]*60;
#ifdef testfeelist
			jdpktime = 1;
#endif
			if(pktime>=24*60)
				{
				//ֱ���볡  ���������¼ 2015-08-14
				memcpy(buffer+1,YWT->YYXLH,8);//��������	
				buffer[0] = 0xEE;//��¼ͷ				
				buffer[1] = 0;
				buffer[2] = 1;
				buffer[3] = YWT->YWParkInfo.DongjieMoney[0];
				buffer[4] = YWT->YWParkInfo.DongjieMoney[1];					
//				memcpy(buffer+5,YWT->snr,4);//��������	
//				buffer[9] = time[4];//��
//				memcpy(buffer+10,YWT->YWParkInfo.ParkDateTime,4);//��//��//ʱ//��
				//����
				for(i=0;i<5;i++)
					buffer[9+i] = time[4-i];
				buffer[14] = cardmoney>>16;//
				buffer[15] = cardmoney>>8;//
				buffer[16] = cardmoney;//
				buffer[17] = 0;//mnybuf[2];
				buffer[18] = 0;//mnybuf[3];
				buffer[19] = ((car+CAR_CLASS)<<4) + 0x07;//���� ��λΪcar 
				for(i=0;i<5;i++)
					buffer[20+i] = time[4-i];
				buffer[25] = CardType_BIKE;//CPC��¼��־
				for(i=26;i<32;i++)buffer[i] = 0xAA;
				Save_Record(buffer,32);				
				}
			else if(pktime>=jdpktime)//�����Զ������Զ��볡���� 2015-10-10
				{
//================�Զ����ʼ2015-10-10=====================
				//���˹�����һ������
				Smart_Power_OFF;
				disp_cardfee(0);	
				TMP.car = car;
				TMP.cardtype = CardType_BIKERD;
				memcpy(TMP.cardno,YWT->YYXLH,8);;
				i = Send_CardFeeRecord();
				TMP.feetime =1;
				if(i>0)
					{
					disp_cardfee(1);
					delay(KEYTIMEOUT_1S*4);
					return;
					}
				if(TMP.feetime==0)
					{
					disp_cardfee(2);
					delay(KEYTIMEOUT_1S*4);
					return;
					}		
				//�Ƚ� TMP.time��YWT->YWParkInfo.ParkDateTime�Ĵ�С 
				//����ʱ��С�� ��λʱ�� ���ܲ��� 
				memcpy(buffer+1,YWT->YWParkInfo.ParkDateTime,4);
				buffer[0] = TMP.time[0];
				if(((TMP.time[1]==0x01)&&(buffer[1]==0x12))||//����
					(TMP.time[1]>buffer[1])||//MMDDHHMM
					((TMP.time[1]==buffer[1])||(TMP.time[2]>buffer[2]))||
					((TMP.time[1]==buffer[1])||(TMP.time[2]==buffer[2])||(TMP.time[3]>buffer[3]))||
					((TMP.time[1]==buffer[1])||(TMP.time[2]==buffer[2])||(TMP.time[3]==buffer[3])||(TMP.time[4]>=buffer[4])))
					{
					TMP.feemnybak = TMP.feemny;
					TMP.autofee = 1;
//					//ֱ���볡	���������¼ 2015-08-14
//					buffer[0] = 0xEE;//��¼ͷ				
//					buffer[1] = 0;
//					buffer[2] = 1;
//					buffer[3] = YWT->YWParkInfo.DongjieMoney[0];
//					buffer[4] = YWT->YWParkInfo.DongjieMoney[1];					
//	//				memcpy(buffer+5,YWT->snr,4);//��������	
//					memcpy(buffer+1,YWT->YYXLH,8);//��������	
//	//				buffer[9] = time[4];//��
//	//				memcpy(buffer+10,YWT->YWParkInfo.ParkDateTime,4);//��//��//ʱ//��
//					//����
//					for(i=0;i<5;i++)
//						buffer[9+i] = time[4-i];
//					buffer[14] = cardmoney>>16;//
//					buffer[15] = cardmoney>>8;//
//					buffer[16] = cardmoney;//
//					buffer[17] = 0;//mnybuf[2];
//					buffer[18] = 0;//mnybuf[3];
//					buffer[19] = ((car+CAR_CLASS)<<4) + 0x07;//���� ��λΪcar 
//					for(i=0;i<5;i++)
//						buffer[20+i] = time[4-i];
//					buffer[25] = CardType_BIKE;//CPC��¼��־
//					for(i=26;i<32;i++)buffer[i] = 0xAA;
//					Save_Record(buffer,32); 
					pktime=24*60;
					lcd_clear();//���� ��ʾ ��ˢ��	
					Smart_Power_ON;
					delay(KEYTIMEOUT_1S/10);//������ʱ ��Ϊ�� �������� �ϵ�
					display_please_operation(time1[4],time1[3],time1[2],time1[1],time1[0],77);	   
					//TMP.feetime: TMP.feemny
					timeOut = 0;   
					key_flag = 0;
					i = 4;
					CardInfo YWCardInfo;
					while(i--)
						{
						while(timeOut < 300)
							{
							card_class_flag = inquire_card(&YWCardInfo);//��� ��������
								
							if((card_class_flag==CardType_MF1)||
								(card_class_flag==CardType_BIKE)||
								(card_class_flag==CardType_CPC))
								{
								break;
								}										
							if(key_flag != NO)
								{
								key_flag = 0;
								break;
								}										
							timeOut++;	
							}
						if(card_class_flag!=CardType_BIKE)
							{
							timeOut = 0;
							if(i>1)continue;
							disp_cardfee(3);
							delay(KEYTIMEOUT_1S*4);
							return;
							}
						break;
						}

					
					}
				else//����ʱ��>��λʱ��
					{//��ʾδ����-
					memcpy(TMP.cardno,YWT->YYXLH,8);
					memcpy(TMP.time,YWT->YWParkInfo.ParkDateTime,4);
					memcpy(TMP.mbno,YWT->YWParkInfo.ParkMBNO,4);			
					disp_YWT_IMG(4);
					return;					
					}
				}
			
			else if(pktime>=buffer[8]*60)
				{
//================�Զ����ʼ2015-08-13=====================
				//���˹�����һ������
				disp_cardfee(0);	
				TMP.car = car;
				TMP.cardtype = CardType_BIKERD;
				memcpy(TMP.cardno,YWT->YYXLH,8);;
				Smart_Power_OFF;
				i = Send_CardFeeRecord();
				if(i>0)
					{
					disp_cardfee(1);
					delay(KEYTIMEOUT_1S*4);
					return;
					}
				if(TMP.feetime==0)
					{
					disp_cardfee(2);
					delay(KEYTIMEOUT_1S*4);
					return;
					}		
				lcd_clear();//���� ��ʾ ��ˢ��	
				Smart_Power_ON;
				delay(KEYTIMEOUT_1S/10);//������ʱ ��Ϊ�� �������� �ϵ�
				display_please_operation(time1[4],time1[3],time1[2],time1[1],time1[0],0x13);	   
				disp_cardfee(0x99);	

				//TMP.feetime: TMP.feemny
				
				timeOut = 0;   
				key_flag = 0;
				i = 4;
				CardInfo YWCardInfo;
				while(i--)
					{
					while(timeOut < 300)
						{
						card_class_flag = inquire_card(&YWCardInfo);//��� ��������
							
						if((card_class_flag==CardType_MF1)||
							(card_class_flag==CardType_BIKE)||
							(card_class_flag==CardType_CPC))
							{
							break;
							}										
						if(key_flag != NO)
							{
							key_flag = 0;
							break;
							}										
						timeOut++;	
						}
					if(card_class_flag!=CardType_BIKE)
						{
						timeOut = 0;
						if(i>1)continue;
						disp_cardfee(3);
						delay(KEYTIMEOUT_1S*4);
						return;
						}
					memset(TMP.opcardno,0xAA,4);
					TMP.rerun =1;
					return;					
					}				
				}
//================�Զ��������2015-08-13=====================			
			if(pktime<RR_ST1.Max_Park_Time*60)
				{
				//�ж����ڳ�λ�Ƿ��Ѿ�����?2015-08-20
				if(car == 2)
					i = 3;
				else if(car == 3)
					i = 2;
				read_car_reference_of_use_info(&CS_RF_US,i);//����λ״̬��Ϣ
				
				if(CS_RF_US.car_stop_way[0]==0x66)
					{
					equ = campare_card_NO(i,YWT->YYXLH+4,CPU_CARD,1);
					if(equ==1)
						swipng =0;//�Ѳ����ж�
					}
				equ = campare_card_NO(car,YWT->YYXLH+4,CPU_CARD,1);
				if((equ!=1)||(swipng==0))//ˢ���쳣 2015-08-06  ����������
					{//��ʾδ����-
					memcpy(TMP.cardno,YWT->YYXLH,8);
					memcpy(TMP.time,YWT->YWParkInfo.ParkDateTime,4);
					memcpy(TMP.mbno,YWT->YWParkInfo.ParkMBNO,4);			
					disp_YWT_IMG(4);
					return;					
					}
				else
					{
					//�ٽ���-ֱ������ -���¼
					falseinout = 5;
					}
				}
			}
		//������	���߼ٽ���		
		pkmoney = 0;

		fll(pkmoney,mnybuf,4);
		YWTFEE.TradeDateTime[0] = 0x20;
		for(i=0;i<5;i++)
			YWTFEE.TradeDateTime[i+1] = time[4-i];
		YWTFEE.TradeDateTime[6] = 0x00;
		memcpy(YWTFEE.QBalance,YWT->Balance,4);
		memcpy(YWTFEE.Pays,mnybuf,4);
		//YWTFEE.ParkInfo
		YWTFEE.YWParkInfo.CardType = 0x60;
		if((falseinout==3)||(falseinout==4))
			YWTFEE.YWParkInfo.ParkFlag = 0x00;//��������δ�볡��־
		else
			YWTFEE.YWParkInfo.ParkFlag = 0x01;//�����볡��־
		for(i=0;i<4;i++)
			YWTFEE.YWParkInfo.ParkDateTime[i] = time[3-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.UpdateFlag = 0x88;			
		YWTFEE.YWParkInfo.DongjieMoney[0] = 0x00;
		YWTFEE.YWParkInfo.DongjieMoney[1] = RR_ST1.Max_Stop_Momery;
		memset(YWTFEE.YWParkInfo.Res,0xCC,7);
		YWTFEE.YWParkInfo.Res[6] = car;
		memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����볡 		
		YWTFEE.YWParkInfo.ParkMBNO[0] = 0x66;
		memcpy(YWTFEE.YWParkInfo.ParkMBNO+1,mbno,3);
		YWTFEE.YWParkInfo.ParkInOutTime[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.ParkInOutTime[i+1] = time[4-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.ParkInOutTime[6]= 0x00;			
		YWTFEE.CardType = YWT->CardType;
//		memcpy(YWTFEE.YYXLH,YWT->YYXLH,8);
		memcpy(YWTFEE.YYXLH,YWT->snr,4);
		memset(YWTFEE.YYXLH+4,0,4);
//			YWTFEE.CSDMType//���д�������?
		YWTFEE.CSDMType =2;
		memcpy(YWTFEE.NC,0,2);
		memcpy(YWTFEE.SHDM,0,2);
		YWTFEE.POS[0] = 0x66;
		memcpy(YWTFEE.POS+1,mbno,3);
		//����-���� -���¼
		//1. �ݴ� ����� ��ʹ��״̬����
		write_momery_to_Fm(YWT->Balance,car);
		//����ͣ��		
		//д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
		I2C_ReadS_24C((car1_useing + (car - 1)),&feeflag,1);
		ReadCar_15_Info(car,buffer);
		pktime = ret_max_24hour(buffer+9,SELECT);
		if((pktime>=60)||(feeflag==0x00))
			{
			//�����λ����Ϣ ʹ����ˢ15���Ӻ� �ȽϿ��Ų�ͬ
			for(i=0;i<16;i++)
				buffer[i] = 0;
			write_car_15_reference(car,buffer,16);
			write_car_reference_of_use_info(car,buffer,16);
			}
		//2. ���ݿ������ �������ͣ��ʱ��
		max_stop_time = momery_to_time(cardmoney-pkmoney);	
		max_stop_time = RR_ST1.Max_Park_Time*60;
		if(max_stop_time==0)// Ǯ���� ������ͣ��
			{	
			//���ͣ��ʱ�� Ϊ 0		
			disp_YWT_IMG(5);//���� ���ֵ
			return;
			}
		
//		falseinout = RecordMode_falsein;//���� 2015-09-09
		
		if(falseinout==0x0F)//����	--������������		
			equ = 1;//������������
//		if(TMP.autofee == 1)
//			equ = 1;//�Զ������볡 2015-09-08
		else if(falseinout==5)//�ٽ���
			equ = 1;
		else
			equ = YWT_FEE_PRO(&YWTFEE,&YWTFEER);//�۷ѳ���
		if(equ != 1)//�ۿ�ɹ�
			{//����Ҫ���ݴ�����//д����ͨ�� ���� �����־
			buffer[0] = 0x01;
			I2C_WriteS_24C(car1_LNT_comd + (car - 1),buffer,1);				
			buffer[0] = 0x00; //��λ״̬ 	
			memset(buffer+1,0,4);//�������� 
//			memcpy(buffer+5,YWT->snr,4);//��������	
			memcpy(buffer+1,YWT->YYXLH,8);//��������	
			buffer[9] = time[3]; //��									   
			buffer[10] = time[2]; //��										
			buffer[11] = time[1]; //ʱ										 
			buffer[12] = time[0]; //��										 
			buffer[13] = time[4];//0x00; //�� Ԥ��										 
			buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ 									  
			buffer[15] = max_stop_time % 60; 																											 
			write_car_reference_of_use_info(car,buffer,16);					
			Smart_Power_OFF;//�ص�����ģ��ĵ�Դ 
			OPEN_EXTI9_5_IRQ(); 									  
			OPEN_EXTI15_10_IRQ();
			QuitFlag = 1;
			buffer[0]= 1;
			//д����/�쳣ˢ���ı�־ 2015-08-06
			I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
			return;
			}
		buffer[0]= 0;
		//д����/�쳣ˢ���ı�־ 2015-08-06
		I2C_WriteS_24C(Car1_SwipNG+car-1,buffer,1);
		//�ۿ�ɹ� 
		Smart_Power_OFF;//�ص�����ģ��ĵ�Դ		
		//��λ����
		light(car,OK); 
		//1. �汾��λ����//�Ѿ�д��
		if(campare_card_NO(car,YWT->YYXLH+4,CPU_CARD,1))
		  { 
		  buffer[0] = 0x01;
		  I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04) + 1,buffer,1);  
		  } 
		else	  
		  {
		  buffer[0] = 0x00;
		  I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04) + 1,buffer,1);											
		  } 

		if(TMP.autofee == 1)
			{
			//ֱ���볡	���������¼ 2015-08-14
			buffer[0] = 0xEE;//��¼ͷ				
			memcpy(buffer+1,YWT->YYXLH,8);//��������	
			buffer[1] = 0;
			buffer[2] = 1;
			buffer[3] = YWT->YWParkInfo.DongjieMoney[0];
			buffer[4] = YWT->YWParkInfo.DongjieMoney[1];					
		//				memcpy(buffer+5,YWT->snr,4);//��������	
		//				buffer[9] = time[4];//��
		//				memcpy(buffer+10,YWT->YWParkInfo.ParkDateTime,4);//��//��//ʱ//��
			//����
//			for(i=0;i<5;i++)
//				buffer[9+i] = time[4-i];
			buffer[9] = time[4];//��
			memcpy(buffer+10,YWTFEE.YWParkInfo.ParkDateTime,4);//��//��//ʱ//��
			buffer[14] = cardmoney>>16;//
			buffer[15] = cardmoney>>8;//
			buffer[16] = cardmoney;//
//			TMP.feemnybak;
			buffer[17] = TMP.feemnybak>>8;//mnybuf[2];
			buffer[18] = TMP.feemnybak;//mnybuf[3];
			buffer[19] = ((car+CAR_CLASS)<<4) + 0x07;//���� ��λΪcar 
			for(i=0;i<5;i++)
				buffer[20+i] = time[4-i];
			buffer[25] = CardType_BIKE;//CPC��¼��־
			for(i=26;i<32;i++)buffer[i] = 0xAA;
			Save_Record(buffer,32); 
			}
		
		//2. ��ͣ����¼
		buffer[0] = 0xEE;//��¼ͷ
		memset(buffer+1,0,4);//�������� 
//		memcpy(buffer+5,YWT->snr,4);//��������	
		memcpy(buffer+1,YWT->YYXLH,8);//��������	
//		for(i=0;i<5;i++)
//			buffer[9+i] = time[4-i];//��//��//��//ʱ//��
		buffer[9] = time[4];//��
		memcpy(buffer+10,YWTFEE.YWParkInfo.ParkDateTime,4);//��//��//ʱ//��

		memcpy(buffer+14,YWT->Balance+1,3);
		buffer[17] = 0x00;
		buffer[18] = 0x00;											
		buffer[19] = ((car+CAR_CLASS)<<4) + 0x01;//��һ��ͣ�� ��λΪcar 
		for(i=0;i<5;i++)
			buffer[20+i] = time[4-i];//��//��//��//ʱ//��
		buffer[25] = CardType_BIKE;//����ͨ��¼��־			
		for(i=26;i<32;i++)
			buffer[i] = 0xAA;							   
		Save_Record(buffer,32);
		WriteRecord(car,CardType_BIKE);//д�� ��¼�ı�־		
		Deal_SwipCardIMG(car-1,1);
		
		OPEN_EXTI9_5_IRQ(); 
		OPEN_EXTI15_10_IRQ();
//		Buzz_0;
//		delay(KEYTIMEOUT_1S/20);
//		Buzz_1;
		//4. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ��������ͣ��ʱ�䣩											
		buffer[0] = 0x66; //��λ״̬ 									  
		memset(buffer+1,0,4);//�������� 
//		memcpy(buffer+5,YWT->snr,4);//��������	
		memcpy(buffer+1,YWT->YYXLH,8);//��������	
		buffer[9] = time[3]; //��									   
		buffer[10] = time[2]; //��										
		buffer[11] = time[1]; //ʱ										 
		buffer[12] = time[0]; //��										 
		buffer[13] = time[4];//��									 
		buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ 									  
		buffer[15] = max_stop_time % 60; 																											 
		memcpy(buffer+16,YWT->Balance,4);
		write_car_reference_of_use_info(car,buffer,16);
		write_momery_to_Fm(YWT->Balance,car);
		//3. ��ʾ��������ǰʱ�䣬��ͣ��ʱ��
		pktime = max_stop_time;
		TMP.cardmny = cardmoney - pkmoney;
		TMP.feemny = pkmoney;
		TMP.feetime= pktime;		
		memcpy(TMP.cardno,YWT->YYXLH,8);

		if(TMP.autofee == 1)//�Զ������־ 2015-09-08
			{
			TMP.feemny = TMP.feemnybak;
			disp_YWT_IMG(7);//��ʾǷ�����������볡��Ϣ		
			}
		
		if(falseinout==4)
			disp_YWT_IMG(7);//��ʾǷ�����������볡��Ϣ		
		else if(falseinout==3)
			disp_YWT_IMG(8);//��ʾ�������볡��Ϣ		
		else if(falseinout==5)
			disp_YWT_IMG(9);//��ʾ���볡��Ϣ		
		else
			disp_YWT_IMG(10);//��ʾ�볡��Ϣ		
		return;		
		}
	}
*/
}
//��һ��ˢ�� ������
uchar card_station_check(uchar car_car)
{
    Smart_Power_ON;//ÿһ�� ˢ�� ��Ҫ �ϵ�
    
    uchar card_free_count,car,testmnydisp=0,i;
    uchar hour,min,car_station;
    uchar read_card_flag,display_ICflag; //������־  �Ƿ������
    uchar card_class_flag;//�����ͱ�־    
    uchar buffer[16],Now_time,writetime;//,B0S14_BUF[16];
    uchar block1_buffer[32],block2_buffer[32];
    uchar momery_buffer[16],NEWmomery_buffer[16];    
    uchar MIFARE_password_buffer[6];    
    uchar Card_No[8],flag,mnyb[4];
    uchar value_buffer[4],write_buffer[4],flag_buffer[4]; 
    uchar display_flag;//��ʾ �Ƿ� ͣ����Ϣ�ı�־    
    uchar MonthCarUsingCount,MonthCarAllCount;    
    u32  momery,lockmny,mnyold,mnyorg;
    u16 max_stop_time;//���ͣ��ʱ��    
    long left_momery,new_submny;
    unsigned long timeOut;
	s32 listret;
    
    MIFARE_card_information MIFARE_card_info;
    carStation_reference_of_used CS_RF_US;
    CardInfo YWCardInfo;

	TMP.autofee = 0;//2015-09-08
    QuitTime = 0;
    QuitFlag = 1;
	key_flagbk = 0;
	key_flag = 0;
	QuitKey = 0;
    car = car_car;//��ȡ ��λ��     
    
    read_car_reference_of_use_info(&CS_RF_US,car);//����λ״̬��Ϣ  
    car_station = CS_RF_US.car_stop_way[0];//��λ��ͣ��״̬ 0x66 Ϊ�г�     0x00 Ϊû�г�

//	if((CS_RF_US.car_stop_way[0] == 0x66)&&
//		(CS_RF_US.smartCard_SNR[0]== PreBuyflag)) //��ʱ//Ԥ���־PreBuyflag
//		{//������--����---ʣ��--
		lockmny= ret_max_24hour(CS_RF_US.start_stopTime,PARK_CARD);//ʵ�ʲ���ʱ��
		max_stop_time = CS_RF_US.max_stopTime_hour[0]*60+CS_RF_US.max_stopTime_min[0];
		if(max_stop_time<lockmny)
			max_stop_time =0;
		else
			max_stop_time -= lockmny;
//		display_prebuy_menu(CS_RF_US.smartCard_SNR+4,0,0,max_stop_time,0,0,PreBuyDisp_A0);  
//		timeOut = 0;
//		delay(KEYTIMEOUT_1S * 1);
//		key_flag = 0;
//		timeOut =KEYTIMEOUT_1S * 2;
//		while(timeOut--)
//			{
//			if(key_flag)
//				{ 
//				key_flag = 0;
//				break;
//				}	
//			}
//		return 0;
//		}

	GetCurrentTime();      
    get_rate_ref(&RR_ST1);//��ȡ����        
	display_flag = 0;	
	display_ICflag = 0;
//	delay(KEYTIMEOUT_1S * 0.4);//������ʱ ��Ϊ�� �������� �ϵ�
	delay(KEYTIMEOUT_1S * 0.1);//������ʱ ��Ϊ�� �������� �ϵ�
    while(QuitTime < 5 && QuitFlag == 1)
		{
	    Smart_Power_ON;//ÿһ�� ˢ�� ��Ҫ �ϵ�
	    
//	    #ifdef CPUINCARD_SYS
//		CCard_GPIOConfig();
//		Contact_Power_ON;
//		#endif
		
	    QuitFlag = 0;
	    read_card_flag = NO;
	    balckList_flag = 0;//��ʾ���Ǻ�����
            
//	    Public_BCC = 0x00;
//	    I2C_ReadS_24C(sysytem_public_key,system0_number,7);
//	    for(uchar i=0;i<6;i++)
//			{
//	        Public_BCC = Public_BCC ^ system0_number[i];
//			}	    
//	    if(Public_BCC != system0_number[6])//��Կ��У�鲻��
//	    	{
//	        //���»�ȡ��Կ
//	        I2C_ReadS_24C(sysytem_public_key_back,system0_number,7);	        
//	        Public_BCC = 0x00;
//	        for(uchar i=0;i<6;i++)
//				{
//	            Public_BCC = Public_BCC ^ system0_number[i];
//				}	        
//	        if(Public_BCC != system0_number[6])//������Կ��У�鲻��
//	        	{
//	            //��ԭΪ������Կ	         
//				buffer[0]=0x07;
//				buffer[1]=0x55;
//				buffer[2]=0x83;
//				buffer[3]=0x26;
//				buffer[4]=0x62;
//				buffer[5]=0x36;
//	            buffer[6] = buffer[0] ^ buffer[1] ^ buffer[2] ^ buffer[3] ^ buffer[4] ^ buffer[5];
//	            I2C_WriteS_24C(sysytem_public_key,buffer,7);  //���ܺ����в�������
//	            I2C_WriteS_24C(sysytem_public_key_back,buffer,7);
//	        	}
//	        else
//				{
//	            //���� �ѱ�����Կд�ص� ԭ����Կ����ȥ��
//	            I2C_WriteS_24C(sysytem_public_key,system0_number,7);
//				}
//			}    
	lcd_clear(); 
	if((CS_RF_US.car_stop_way[0] == 0x66)&&
		(CS_RF_US.smartCard_SNR[0]== PreBuyflag)) //��ʱ//Ԥ���־PreBuyflag
		{	
		I2C_ReadS_24C(CardNo1_CPU+(car-1)*16,buffer,8);
		if((buffer[0]!=0xAA)&&
			(buffer[2]!=0xAA)&&
			(buffer[4]!=0xAA)&&
			(buffer[6]!=0xAA))
			{
			memcpy(CS_RF_US.smartCard_SNR,buffer,8);
			}				
		#ifdef CAR
		display_prebuy_menu(CS_RF_US.smartCard_SNR+4,car-1,0,max_stop_time,5 - QuitTime,lockmny,PreBuyDisp_A0);	
		#else
		display_prebuy_menu(CS_RF_US.smartCard_SNR+4,car,car,max_stop_time,5 - QuitTime,lockmny,PreBuyDisp_A0);	
		#endif
		}	 
	else
		{
		#ifdef CAR
		display_please_swid_card(time1[4],time1[3],time1[2],time1[1],time1[0],car - 1,5 - QuitTime);
		#else
		display_please_swid_card(time1[4],time1[3],time1[2],time1[1],time1[0],car,5 - QuitTime);
		#endif
		}
#ifndef PSAM_ID
		delay(KEYTIMEOUT_1S);//��psamʱ��ʱ����
		TMP.PSAM = 0;
#else		
		i = 6;
		while(i--)
			{
			TMP.PSAM = read_PSAM();
			if(TMP.PSAM==0)break;
			delay(KEYTIMEOUT_1S/5);
			}
#endif
#ifdef MACHINE_ID
	    //��� �������ĺû�
	    timeOut = 0;
	    read_mech_ID_flag = NO;
	    while(timeOut < 3)
			{
	        if(read_mech_ID() == 0x00)
				{
	            read_mech_ID_flag = OK;
	            break;
				}
	        timeOut++;
			}	    
	    if(read_mech_ID_flag != OK)
			{
			Smart_Power_OFF;
	        return 0x99;
			}
#endif
	    
            
	    OPEN_EXTI9_5_IRQ();        
        OPEN_EXTI15_10_IRQ();            
	    QuitTime++;
	    if(key_flag != 0)key_flag = 0;
	    
	    card_class_flag = 0;
	    timeOut = 0;
	   // while(timeOut < 300)
		while(timeOut < 180)
			{
			card_class_flag = inquire_card(&YWCardInfo);//��� ��������
			if(card_class_flag==CardType_IC)
				{
				Smart_Power_OFF;										
				//��ʾ �ε�											
				Buzz_0;										   
				delay(KEYTIMEOUT_1S/10);											 
				Buzz_1;
#ifdef IN_MBSYSTEM		
				write_card_error(0);
				delay(KEYTIMEOUT_1S*3);
#else		
				ICCard_Pay(car,IQ_NO);	
#endif
				return 0;
				}
			else if(card_class_flag==CardType_CPU)
				{
				//��ʾ �ε� 										
				Buzz_0; 									   
				delay(KEYTIMEOUT_1S/10);											 
				Buzz_1;
#ifdef IN_MBSYSTEM		
				write_card_error(0);
				delay(KEYTIMEOUT_1S*3);
#else		
				
				flag = 0;
				#ifdef two_spmode
				flag = 1;
				#endif
				
				if(flag)
					CPCCARD_PRO(car,car_station,&YWCardInfo);
				else
					CpuCard_Pay(car,IQ_NO,&YWCardInfo);
#endif				
				Smart_Power_OFF;
				return 0;
				}
			else if(card_class_flag==CardType_CPCLOCK)
				{
				QuitFlag = 1;//����Ѱ��
				if(QuitTime>=4)
					{
					write_card_error(0);
					delay(KEYTIMEOUT_1S*3);
					return 1;
					}
				else
					break;
				}
			if((card_class_flag==CardType_MF1)||
				(card_class_flag==CardType_BIKE)||
				(card_class_flag==CardType_CPC))
				{
                read_card_flag = OK;
                break;
				}
            else
				{
                read_card_flag = NO;
				}       
	        if(key_flag)//���κμ� �˳���ˢ�� ����
	        	{
	            QuitKey = key_flag;
	            key_flag = 0;           
	            break;
				}
			timeOut++;    
			}
		if(read_card_flag == OK)
			{	
//			#ifdef CPUINCARD_SYS
//			Contact_Power_OFF;
//			#endif
			
	        DISABLE_EXTI15_10_IRQ();//�ȹر��ж� ���ж�������
	        DISABLE_EXTI9_5_IRQ();	
            u8 flagBuf[1],temp;
			flagBuf[0] = 0x00;
			I2C_WriteS_24C(ResetCar1Flag + car - 1,flagBuf,1);                
	        temp = card_class_flag;
	        switch(temp)
				{ 				
				case CardType_CPC://���񿨵�����
					{
					CPCCARD_PRO(car,car_station,&YWCardInfo);
					if(QuitFlag==1)continue;
					return 0;
					break;
					}
				case CardType_BIKE://���г���������
					{
					TMP.rerun = 0;
					BIKECARD_PRO(car,car_station,&YWCardInfo);
					if(TMP.rerun)
						BIKECARD_PRO(car,0x99,&YWCardInfo);	
					if(QuitFlag==1)continue;
					return 0;
					break;
					}		 
				case CardType_MF1://MF1��
					read_MIFARE_card(&MIFARE_card_info);  //��ȡmifare������Ϣ       
		            MF1key_main(MIFARE_card_info.SNR,MIFARE_password_buffer);     //��ȡMIFARE������Կ
		            break;
				default:
					Smart_Power_OFF;
		            OPEN_EXTI9_5_IRQ();        
		            OPEN_EXTI15_10_IRQ();		                
		            Buzz_0;
		            delay(KEYTIMEOUT_1S/10);
		            Buzz_1;	            
		            no_use_card(0);
		            delay(KEYTIMEOUT_1S * 3);
		            return 0;
		            break;
				} 
			}
		else
			{
            //�������ɹ� ����Ҫ���� �鿴 ͣ����Ϣ
            display_flag = 1;
            }   
		
	    if(read_card_flag == OK)
			{//�˴���ΪMF1��	  
//			if(card_class_flag == CardType_MF1)
            uchar timeOut_quit = 0;
			uchar MonthCount_Flag = 0,left_momery_buffer[16]; 
            uchar MaterBuf[3],Error_Buf[1],YXRQ[4];
			
            while(timeOut_quit < 3)
				{
				error_value_0 = RecoverArea();	
				if(error_value_0==1)
					{
					timeOut_quit++;
					QuitFlag = 1;			
					display_flag = 2;
					continue;
					}
			if(error_value_0==3)return 0;	
			error_value_0 = testkey_comd(0x02,0x0a,MIFARE_password_buffer);
      		if(error_value_0 == OK)
				{
				error_value_1 = read_comd(BLOCK1_ADDR,block1_buffer);
                error_value_2 = read_comd(BLOCK2_ADDR,block2_buffer);
                error_value_0 = read_comd(BLOCK0_ADDR,left_momery_buffer);           
                if(error_value_1 == OK && error_value_2 == OK && error_value_0 == OK)
					{
				month_card_free_count = 0;
				month_card_max_count = 1;  
				switch(block2_buffer[0])
					{
				case MONTH_CARD://�¿�   
					{
                      YXRQ[0] = 0x20;
                      YXRQ[1] = block2_buffer[13];
                      YXRQ[2] = block2_buffer[14];
                      YXRQ[3] = block2_buffer[15];		                      
                      I2C_ReadS_24C(mibiao_number,MaterBuf,3);//�����
              //����Ҫ���� ���������ж�
                  for(i=0;i<4;i++)
                    carSNR[i] = MIFARE_card_info.SNR[3-i];
                  balckList_flag = select_BlackList_from_Menmory_day(carSNR,MIFARE_FLAG,ADD);   //�ж�CPU���Ƿ��� ������
                  whiteList_flag = select_BlackList_from_Menmory_day(carSNR,MIFARE_FLAG,DEC); //�ռ��� �ж�CPU���Ƿ��� ������
                  if(balckList_flag > 0)
                  {
                      if(whiteList_flag > 0)
                        balckList_flag = 0;
                  }
                  
                  if(balckList_flag != NO )
                  {                    
                      block2_buffer[0] = 0xf0;//�������ı�־
                          
                      //��׽��������
                      if(write_comd(BLOCK2_ADDR,block2_buffer) == OK)//��׽�ɹ�
                      {
                          display_catch_backList(1);
                      }
                      else//��׽ʧ��
                      {
                          display_catch_backList(0);
                      }                                    
                      
                      Smart_Power_OFF;
                      
                      Buzz_0;
                      delay(KEYTIMEOUT_1S/10);
                      Buzz_1;
                      
                      delay(KEYTIMEOUT_1S * 3);
                      return 0;                   
                  }
              if(mibiao_check(block2_buffer) == OK)//����ŵļ��
              {
                  //�ѿ��ź�block1����������߱����������Է���block2ȫдΪ0��ʱ�� �ָ�
                  save_mifare_NO(MIFARE_card_info.SNR,block1_buffer,car);
      
                      MonthCarUsingCount = block1_buffer[0];
                      MonthCarAllCount = block2_buffer[2];
                  
                      if(car_station == 0x66)//��ʾ�����λ ����ʹ��
                      {
                          if(campare_card_NO(car,MIFARE_card_info.SNR,MIFARE_CARD,1) == OK)//������ͬ
                          {
                              I2C_ReadS_24C(MonthCarOutERRORCar1 + (car-1),Error_Buf,1);
                              if(Error_Buf[0] == 0x01)//�ϴν����г��� ˢ��������ʱ��
                              {
                                    //��������Ƿ�һ��
                                    for(char i =0;i<3;i++)
                                    {
                                        if(block1_buffer[i+1] != MaterBuf[i])
                                        {
                                            MonthCount_Flag = 0x01;
                                            break;
                                        }
                                    }
                                    
                                    if(MonthCount_Flag == 0x00 && ( car!= block1_buffer[8] || block1_buffer[9] != 2 ))
                                      MonthCount_Flag = 0x01;
                                    //��ʱ���Ƿ�һ�� ������1����                                                
                                    
                               }
                                
                               if(MonthCarUsingCount > 0)
                               {
                                    if(Error_Buf[0] == 0x01)
                                    {
                                        if(MonthCount_Flag == 0x01)
                                          MonthCarUsingCount--;
                                        else
                                        {
                                            I2C_ReadS_24C(MonthCarCountERRORCar1 + (car-1),Error_Buf,1);
                                            if(Error_Buf[0] == block1_buffer[0])
                                                MonthCarUsingCount--;
                                        }
                                    }
                                    else
                                    {
                                         MonthCarUsingCount--;
                                    }
                                   
                                    block1_buffer[0] = MonthCarUsingCount;
                                    block1_buffer[1] = MaterBuf[0];
                                    block1_buffer[2] = MaterBuf[1];
                                    block1_buffer[3] = MaterBuf[2];
                                    //block1_buffer[4] = time[3];
                                    //block1_buffer[5] = time[2];
                                    //block1_buffer[6] = time[1];
                                    //block1_buffer[7] = time[0];
                                    block1_buffer[8] = car;
                                    block1_buffer[9] = 2;//������־
                                    
                                  
                               }
							   
							   block1_buffer[11] = 0x00;
							   block1_buffer[12] =	time[3];
							   block1_buffer[13] =	time[2];
							   block1_buffer[14] =	time[1];
							   block1_buffer[15] =	time[0];
                              
                              if(write_comd(BLOCK1_ADDR,block1_buffer) == OK)
                              {
                                  hour = ret_max_24hour(CS_RF_US.start_stopTime,SELECT) / 60;
                                  min = ret_max_24hour(CS_RF_US.start_stopTime,SELECT) % 60;
                                  if(hour > 24)
                                    hour = 0;
                                
                                  Smart_Power_OFF;
                                
                              //��λ����
                              light(car,NO);
                              //��ʾ �ε�                                           
                              Buzz_0;                                          
                              delay(KEYTIMEOUT_1S/10);                                           
                              Buzz_1;
                                                                             
                              OPEN_EXTI9_5_IRQ();                                          
                              OPEN_EXTI15_10_IRQ();
                              
                              //д ��λ״̬��ϢΪ��
                              for(uchar i=0;i<16;i++)
                                block1_buffer[i] = 0x00;
                              write_car_reference_of_use_info(car,block1_buffer,16);
                                  
                                  for(int i=0;i<4;i++)                                             
                                momery_buffer[i] = 0x00;                              
                                  // 1. ��� �ݴ濨���                                             
                                  write_momery_to_Fm(momery_buffer,car);
                              
                              //���¼
                              block1_buffer[0] = 0xEE;//��¼ͷ
                              block1_buffer[1] = 0x00;
                              block1_buffer[2] = 0x00; //��������
                              block1_buffer[3] = 0x00; //��������
                              block1_buffer[4] = 0x00; //��������
                              block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
                              block1_buffer[6] = MIFARE_card_info.SNR[2];
                              block1_buffer[7] = MIFARE_card_info.SNR[1];
                              block1_buffer[8] = MIFARE_card_info.SNR[0];
							  block1_buffer[9] = CS_RF_US.start_stopTime[4];//time[4];//��
                              block1_buffer[10] = CS_RF_US.start_stopTime[0];//��
                              block1_buffer[11] = CS_RF_US.start_stopTime[1];//��
                              block1_buffer[12] = CS_RF_US.start_stopTime[2];//ʱ
                              block1_buffer[13] = CS_RF_US.start_stopTime[3];//��
                              block1_buffer[14] = 0x00;
                              block1_buffer[15] = 0x00;
                              block1_buffer[16] = 0x00;
                              block1_buffer[17] = 0x00;
                              block1_buffer[18] = 0x00;
                              block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x02;//�ڶ���ͣ�� ��λΪcar 
                                    
                              block1_buffer[20] = time[4];
                              block1_buffer[21] = time[3];
                              block1_buffer[22] = time[2];
                              block1_buffer[23] = time[1];
                              block1_buffer[24] = time[0];
                                   
                               block1_buffer[25] = CardType_MF1;//����ͨ��¼��־
                                  
                               for(i=26;i<32;i++)                                             
                                 block1_buffer[i] = 0xAA;
                              Save_Record(block1_buffer,32);
                              TMP.ckflag[car] = 0;    
                              WriteRecord(car,RECORD_NULL);//д�� ��¼�ı�־    
							  Deal_SwipCardIMG(car-1,0);
                              
                                  //д����д������ ��־
                                   Error_Buf[0] = 0;
                                   I2C_WriteS_24C(MonthCarOutERRORCar1 + (car-1),Error_Buf,1);
                                        
                                   Error_Buf[0] = 0;
                                   I2C_WriteS_24C(MonthCarCountERRORCar1 + (car-1),Error_Buf,1);
                                        
                                   MonthCount_Flag = 0;
                                   
                               //��ʾ�������
                               lcd_clear();                                           
                               uchar card_no[4];
                               for(uchar i=0;i<4;i++)                                           
                               {                                             
                                 card_no[i] = MIFARE_card_info.SNR[3 - i];                                         
                               }                                          
                               display_second_time(card_no,hour,min,0x00,MonthCarAllCount - MonthCarUsingCount,YXRQ);
                                    
                               timeOut = 0;                                           
                               while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)                                           
                               {                                          
                                 if(key_flag){                                          
                                   key_flag = 0; 
                                   delay(KEYTIMEOUT_1S * QUIT_TIME);
                                       return 0;
                                   //break;                                              
                                 }                                             
                                 timeOut++;                                          
                               }  
                              }
                              else//�¿�����ˢ������
                              {
                                  //��ʾ������ˢ��
                                  //д����д������ ��־
                                  Error_Buf[0] = 1;
                                  I2C_WriteS_24C(MonthCarOutERRORCar1 + (car-1),Error_Buf,1);
                                
                                  Error_Buf[0] = MonthCarUsingCount+1;
                                  I2C_WriteS_24C(MonthCarCountERRORCar1 + (car-1),Error_Buf,1);
                                  
                                  QuitFlag = 1;
                               }
                              
                              if(validity(block2_buffer,MONTH_CARD) != OK)//�¿�����Ч���� ���
                              {
                                   //��ʾ �ε�
                                   Buzz_0;
                                   delay(KEYTIMEOUT_1S/15);
                                   Buzz_1;
                                   delay(KEYTIMEOUT_1S/15);
                                   Buzz_0;
                                   delay(KEYTIMEOUT_1S/15);
                                   Buzz_1;
                                    
                                   //������Ч����
                                   car_outdate();
                                   timeOut = 0;
                                   while(timeOut < KEYTIMEOUT_1S * 2)
                                   {                                            
                                       if(key_flag){                                               
                                          key_flag = 0;      
                                          delay(KEYTIMEOUT_1S * QUIT_TIME);
                                          break;                                             
                                        }                                            
                                        timeOut++;
                                    }
                               }
                          }
                          else//���Ų�ͬ
                          {
                              //��ʾ ��λռ����
                          carStation_using();
                          delay(KEYTIMEOUT_1S * 3);
                          }
                      }
                      else //��ʾ�����λ û����ʹ��
                      {
                          if(validity(block2_buffer,MONTH_CARD) == OK)//�¿�����Ч���� ���
                          {
						  	//���Ӽٽ����ж� 2015-05-19		
						  	u8 false_in = 0;
							if(campare_card_NO(car,MIFARE_card_info.SNR,MIFARE_CARD,1) == OK)//������ͬ
								false_in = 1;

							if((block1_buffer[11]==0x5A)&&(false_in==0))
								{
								Smart_Power_OFF;
								lcd_clear();					
								//��ʾ �ε�
								Buzz_0;
								delay(KEYTIMEOUT_1S/15);
								Buzz_1;
								delay(KEYTIMEOUT_1S/15);
								Buzz_0;
								delay(KEYTIMEOUT_1S/15);
								Buzz_1;
								
								dispaly(2,3,(HZ + wei));//
								dispaly(2,4,(HZ + jie));//
								dispaly(2,5,(HZ + suan));//

								dispaly(4,2,(HZ + qing));
								dispaly(4,3,(HZ + lian));
								dispaly(4,4,(HZ + xi));
								dispaly(4,5,(HZ + guan));
								dispaly(4,6,(HZ + li));
								dispaly(4,7,(HZ + gong));
								dispaly(4,8,(HZ + si_1));
								  
								timeOut = 0;
								while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
									{
									if(key_flag){
										key_flag = 0;
										delay(KEYTIMEOUT_1S * QUIT_TIME);
										break;
										}
									timeOut++;
									}
								return 0;
						  		}
//                                              //���ж��Ƿ��� ����
//                                              if(block1_buffer[5] == time[2] && block1_buffer[4] == time[3])//��ͬһ��
//                                              {
//                                                  //1. �ж�ͣ���������ܷ��ٴ�ͣ��
//                                                  if( MonthCarUsingCount < MonthCarAllCount )
//                                                  {
//                                                      if(Error_Buf[0] == 0x01)
//                                                      {                                                           
//                                                          if(MonthCount_Flag == 0x01)                                                             
//                                                              MonthCarUsingCount++;
//                                                          else
//                                                          {
//                                                              I2C_ReadS_24C(MonthCarCountERRORCar1 + (car-1),Error_Buf,1);
//                                                              if(Error_Buf[0] == block1_buffer[0])                                                                 
//                                                                  MonthCarUsingCount++;
//                                                          }
//                                                       }
//                                                       else
//                                                       {
//                                                           MonthCarUsingCount++;
//                                                       }
//                                                  }
//                                                  else if(MonthCarUsingCount > MonthCarAllCount)//���������쳣
//                                                  {
//                                                      //���������쳣
//                                                      Smart_Power_OFF;
//                                                      lcd_clear();
//                          
//                                                      //��ʾ �ε�
//                                                      Buzz_0;
//                                                      delay(KEYTIMEOUT_1S/15);
//                                                      Buzz_1;
//                                                      delay(KEYTIMEOUT_1S/15);
//                                                      Buzz_0;
//                                                      delay(KEYTIMEOUT_1S/15);
//                                                      Buzz_1;
//                                                            
//                                                      dispaly(2,3,(HZ + ka));//
//                                                      dispaly(2,4,(HZ + yi_3));//
//                                                      dispaly(2,5,(HZ + chang));//
//                                                        
//                                                      timeOut = 0;
//                                                      while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
//                                                      {
//                                                             if(key_flag){
//                                                                  key_flag = 0;
//                                                                  delay(KEYTIMEOUT_1S * QUIT_TIME);
//                                                                 break;
//                                                              }
//                                                              timeOut++;
//                                                      }
//                                                      return 0;
//                                                  }
//                                                  else//�Ѵ���󲴳�����
//                                                  {
//                                                      //��ʾ �ε�
//                                                      Buzz_0;
//                                                      delay(KEYTIMEOUT_1S/15);
//                                                      Buzz_1;
//                                                      delay(KEYTIMEOUT_1S/15);
//                                                      Buzz_0;
//                                                      delay(KEYTIMEOUT_1S/15);
//                                                      Buzz_1;
//                                                        
//                                                      OPEN_EXTI9_5_IRQ();
//                                                      OPEN_EXTI15_10_IRQ();
//                                                        
//                                                      display_max_park_count();
//                                                      timeOut = 0;
//                                                      while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
//                                                      {
//                                                             if(key_flag){
//                                                                  key_flag = 0;
//                                                                  delay(KEYTIMEOUT_1S * QUIT_TIME);
//                                                                 break;
//                                                              }
//                                                              timeOut++;
//                                                      }
//                                                      return 0;
//                                                  }
//                                              }
//                                              else//����ͬ1��
//                                              {
//                                                  //��λͣ������������ͣ��
//                                                  MonthCarUsingCount = 1;//��ʼͣ�� 1 ����λ
//                                              }

//											  
							  //����λ״̬����
							 block1_buffer[0] = 0x00; //��λ״̬
							 block1_buffer[1] = 0x00;//MIFARE_card_info.SNR[3];
							 block1_buffer[2] = 0x00;//MIFARE_card_info.SNR[2]; //��������
							 block1_buffer[3] = 0x00;//MIFARE_card_info.SNR[1]; //��������
							 block1_buffer[4] = 0x00;//MIFARE_card_info.SNR[0]; //��������
							 block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
							 block1_buffer[6] = MIFARE_card_info.SNR[2];
							 block1_buffer[7] = MIFARE_card_info.SNR[1];
							 block1_buffer[8] = MIFARE_card_info.SNR[0];
							 block1_buffer[9] = time[3]; //��
							 block1_buffer[10] = time[2]; //��
							 block1_buffer[11] = time[1]; //ʱ
							 block1_buffer[12] = time[0]; //��
							 block1_buffer[13] = time[4]; //�� Ԥ��
							 block1_buffer[14] = 24; //����ͣ��ʱ�� 24Сʱ
							 block1_buffer[15] = 0;
							 write_car_reference_of_use_info(car,block1_buffer,16);
							 
                              block1_buffer[0] = MonthCarUsingCount;
                              block1_buffer[1] = MaterBuf[0];
                              block1_buffer[2] = MaterBuf[1];
                              block1_buffer[3] = MaterBuf[2];
                              block1_buffer[4] = time[3];
                              block1_buffer[5] = time[2];
                              block1_buffer[6] = time[1];
                              block1_buffer[7] = time[0];
                              block1_buffer[8] = car;
                              block1_buffer[9] = 1;
                              block1_buffer[10] = 0x00;
                              block1_buffer[11] = 0x5A;
                              block1_buffer[12] =  time[3];
                              block1_buffer[13] =  time[2];
                              block1_buffer[14] =  time[1];
                              block1_buffer[15] =  time[0];
							  writetime =write_comd(BLOCK1_ADDR,block1_buffer);
                              if(writetime == OK)
                              {
                                  Smart_Power_OFF;
                                    
                                  //��λ���� 
                                  light(car,OK);
								  addmny[car] = NO;
								  vetime = 0;
								  HR_TIME[car] = 0;
								  err_1[car]=0;
                                  //����λ״̬����
                                  block1_buffer[0] = 0x66; //��λ״̬
                                  block1_buffer[1] = 0x00;//MIFARE_card_info.SNR[3];
                                  block1_buffer[2] = 0x00;//MIFARE_card_info.SNR[2]; //��������
                                  block1_buffer[3] = 0x00;//MIFARE_card_info.SNR[1]; //��������
                                  block1_buffer[4] = 0x00;//MIFARE_card_info.SNR[0]; //��������
                                  block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
                                  block1_buffer[6] = MIFARE_card_info.SNR[2];
                                  block1_buffer[7] = MIFARE_card_info.SNR[1];
                                  block1_buffer[8] = MIFARE_card_info.SNR[0];
                                  block1_buffer[9] = time[3]; //��
                                  block1_buffer[10] = time[2]; //��
                                  block1_buffer[11] = time[1]; //ʱ
                                  block1_buffer[12] = time[0]; //��
                                  block1_buffer[13] = time[4]; //�� Ԥ��
                                  block1_buffer[14] = 24; //����ͣ��ʱ�� 24Сʱ
                                  block1_buffer[15] = 0;
								  memcpy(block1_buffer+16,momery_buffer,4);
								  write_car_reference_of_use_info(car,block1_buffer,16);
                                        
//                                      for(int i=0;i<4;i++)                                             
//                                         momery_buffer[i] = 0x00;                              
                                  // 1. ��� �ݴ濨���                                             
                                  write_momery_to_Fm(momery_buffer,car);
                                            
                                  OPEN_EXTI9_5_IRQ();
                                  OPEN_EXTI15_10_IRQ();
                              
                                  //��ʾ �ε�
                                  Buzz_0;
                                  delay(KEYTIMEOUT_1S/10);
                                  Buzz_1;
                                        
                                        
                                  //���¼
                                            
                                  block1_buffer[0] = 0xEE;//��¼ͷ
                                  block1_buffer[1] = 0x00; //��������
                                  block1_buffer[2] = 0x00;
                                  block1_buffer[3] = 0x00;
                                  block1_buffer[4] = 0x00;
                                  block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
                                  block1_buffer[6] = MIFARE_card_info.SNR[2];
                                  block1_buffer[7] = MIFARE_card_info.SNR[1];
                                  block1_buffer[8] = MIFARE_card_info.SNR[0];
                                  block1_buffer[9] = time[4];//��
                                  block1_buffer[10] = time[3];//��
                                  block1_buffer[11] = time[2];//��
                                  block1_buffer[12] = time[1];//ʱ
                                  block1_buffer[13] = time[0];//��
                                  block1_buffer[14] = 0x00;
                                  block1_buffer[15] = 0x00;
                                  block1_buffer[16] = 0x00;
                                  block1_buffer[17] = 0x00;
                                  block1_buffer[18] = 0x00;
                                  block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x01;//��һ��ͣ�� ��λΪcar 
								  bushimny[car] = 0;   
								  bukanmny[car] = 0;  
								  TMP.CPC_ckmny[car] = 0;
                                  block1_buffer[20] = 0x13;
                                  block1_buffer[21] = 0x06;
                                  block1_buffer[22] = 0x10;
                                  block1_buffer[23] = 0x12;
                                  block1_buffer[24] = 0x00;
                                            
                                  block1_buffer[25] = CardType_MF1;//����ͨ��¼��־
                                            
                                  for(int i=26;i<32;i++)
                                     block1_buffer[i] = 0xAA;
                                  Save_Record(block1_buffer,32);
                                            
								  WriteRecord(car,TMP.cardplace);//д�� ��¼�ı�־ 
								  //WriteRecord(car,CardType_MF1);//д�� ��¼�ı�־ 

								  Deal_SwipCardIMG(car-1,1);
                                  //д����д������ ��־
                                  Error_Buf[0] = 0;
                                  I2C_WriteS_24C(MonthCarInERRORCar1 + (car-1),Error_Buf,1);
                                            
                                  Error_Buf[0] = 0;
                                  I2C_WriteS_24C(MonthCarCountERRORCar1 + (car-1),Error_Buf,1);
                                            
                                  MonthCount_Flag = 0;
                                            
                                  //��ʾ��ʼͣ������
                                  lcd_clear();
                                  uchar card_no[4];
                                  for(uchar i=0;i<4;i++)
                                  {
                                       card_no[i] = MIFARE_card_info.SNR[3 - i];
                                  }
                                  display_frist_time(card_no,24,0,MonthCarAllCount - MonthCarUsingCount,YXRQ);
                                  display_flag = 0;
                                            
                                  timeOut = 0;
                                  while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
                                  {
                                        if(key_flag){
                                             key_flag = 0;
                                             delay(KEYTIMEOUT_1S * QUIT_TIME);
                                             return 0;                                                
                                        }
                                        timeOut++;
                                   } 
                              }
                              else
                              {
                                  //д����д������ ��־
                                  Error_Buf[0] = 1;
                                  I2C_WriteS_24C(MonthCarInERRORCar1 + (car-1),Error_Buf,1);
                                            
                                  Error_Buf[0] = MonthCarUsingCount-1;                                               
                                  I2C_WriteS_24C(MonthCarCountERRORCar1 + (car-1),Error_Buf,1);
                                            
                                  //��ʾ������ˢ��
                                  QuitFlag = 1;
                              }
                          }
                          else//��ʾ������Ч��
                          {
                              //��ʾ �ε�
                              Buzz_0;
                              delay(KEYTIMEOUT_1S/10);
                              Buzz_1;
                                  
                              //������Ч����
                              car_outdate();
                              timeOut = 0;
                              while(timeOut < KEYTIMEOUT_1S * 2)
                              {                                            
                                   if(key_flag){                                               
                                      key_flag = 0;      
                                      delay(KEYTIMEOUT_1S * QUIT_TIME);
                                      break;                                             
                                   }                                            
                                   timeOut++;
                              }
                          }
                      }
                    
              }
              else
              {
                      //��ʾ �ε�
                      Buzz_0;
                      delay(KEYTIMEOUT_1S/10);
                      Buzz_1;
                      
                  //������� �����¿���Χ��
                  mibiao_error();
                  timeOut = 0;
                  while(timeOut < KEYTIMEOUT_1S * 2)
                  {                                            
                    if(key_flag){                                               
                      key_flag = 0;                
                      delay(KEYTIMEOUT_1S * QUIT_TIME);
                      break;                                             
                    }                                            
                    timeOut++;
                  }
               }                  
			break;
			} //�¿�����                                     
			  
		  case G24_TEST_CARD:
		  	{
			Smart_Power_OFF;
			//��ʾ �ε�
			Buzz_0;
			delay(KEYTIMEOUT_1S/10);
			Buzz_1;
			lcd_clear();
			if(SYS_MS.G24S== ON)
				{
				SYS_MS.G24S =OFF;
				print_XYstr_16_16(2,1,"2G4 close OK");			
				}
			else if(SYS_MS.G24S==OFF)
				{
				SYS_MS.G24S =ON;	
				print_XYstr_16_16(2,1,"2G4 open OK");			
				}
			//G24 open/close
			delay(KEYTIMEOUT_1S*3);
			break;
		  	} //2.4G ģ�鿪��/�ر�
		  case G3_TEST_CARD:	
		  	{
			Smart_Power_OFF;
			//��ʾ �ε�
			Buzz_0;
			delay(KEYTIMEOUT_1S/10);
			Buzz_1;
			lcd_clear();
			if(SYS_MS.G3S== ON)
				{
				SYS_MS.G3S =OFF;
				print_XYstr_16_16(2,1,"3&4G close OK"); 		
				}
			else if(SYS_MS.G3S==OFF)
				{
				SYS_MS.G3S =ON; 
				print_XYstr_16_16(2,1,"3&4G open OK");				
				}
			//G3 open/close
			delay(KEYTIMEOUT_1S*3);
			break;
		  	} //3Gģ�鿪��/�ر�
		case TEST_ROM:
			{
			Smart_Power_OFF;
			OPEN_EXTI9_5_IRQ();
			OPEN_EXTI15_10_IRQ();
			FM24CL256_WR_RD_TESTING();				
			break;
			} //������Կ�
		case TEST_TIME:
			{
			Smart_Power_OFF;
			OPEN_EXTI9_5_IRQ();
			OPEN_EXTI15_10_IRQ();
			RX8025SA_READ_TEST();
			break;
			} //ʱ�Ӳ��Կ�
		case RESET_CARD:
			{
			if(validity(block2_buffer,RESET_CARD) == OK)//��λ�� ����Ч���� ���
          		{
                Smart_Power_OFF;
                if(car_station == 0x66)
					{
					//��ʾ �ε�
					Buzz_0;
					delay(KEYTIMEOUT_1S/10);
					Buzz_1;
                    int max_stop_time;
                    max_stop_time = ret_max_24hour(CS_RF_US.start_stopTime,PARK_CARD);
					momery = time_to_momery(CS_RF_US.start_stopTime);
//					if(max_stop_time==0)momery=0;//2015-12-29
					read_momery_to_Fm(mnyb,car);
					mnyorg = hcl(mnyb,4);
					if((mnyorg<=momery)&&mnyorg)//���г�����λ��������2015-10-13
						momery = mnyorg;
					momery_buffer[0] = 0x00;												   
					momery_buffer[1] = 0x00;	
					#ifndef IN_MBSYSTEM
					momery=0;
					#endif
					momery_buffer[2] = momery / 256;												   
					momery_buffer[3] = momery % 256;
					get_rate_ref(&RR_ST1);										  
					block1_buffer[0] = 0xEE;//��¼ͷ								
					block1_buffer[1] = 0;
					block1_buffer[2] = 1;
					fll(RR_ST1.Max_Stop_Momery,block1_buffer+3,2);
//						block1_buffer[1] = CS_RF_US.smartCard_SNR[0];  //��������
//                      block1_buffer[2] = CS_RF_US.smartCard_SNR[1]; 
//                      block1_buffer[3] = CS_RF_US.smartCard_SNR[2]; 
//                      block1_buffer[4] = CS_RF_US.smartCard_SNR[3]; 
                    block1_buffer[5] = CS_RF_US.smartCard_SNR[4]; //��������
                    block1_buffer[6] = CS_RF_US.smartCard_SNR[5];
                    block1_buffer[7] = CS_RF_US.smartCard_SNR[6];
                    block1_buffer[8] = CS_RF_US.smartCard_SNR[7];
					block1_buffer[9] = CS_RF_US.start_stopTime[4];//time[4];//��
                    block1_buffer[10] = CS_RF_US.start_stopTime[0];//�� //�볡ʱ��
                    block1_buffer[11] = CS_RF_US.start_stopTime[1];//��
                    block1_buffer[12] = CS_RF_US.start_stopTime[2];//ʱ
                    block1_buffer[13] = CS_RF_US.start_stopTime[3];//��
                    block1_buffer[14] = CS_RF_US.smartCard_momenry[1];
                    block1_buffer[15] = CS_RF_US.smartCard_momenry[2];
                    block1_buffer[16] = CS_RF_US.smartCard_momenry[3];
                    block1_buffer[17] = momery_buffer[2];//0x00;
                    block1_buffer[18] = momery_buffer[3];//0x00;
                    block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x04;//�˹���λ ��λΪcar 
//                        block1_buffer[17] = 0x00;
//                        block1_buffer[18] = 0x01;
//                        block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x04;//�˹���λ ��λΪcar 
                    block1_buffer[20] = time[4];
                    block1_buffer[21] = time[3];
                    block1_buffer[22] = time[2];
                    block1_buffer[23] = time[1];
                    block1_buffer[24] = time[0];

                    block1_buffer[25] = ReadRecord(car);//����ͨ��¼��־
                     
					block1_buffer[26] = MIFARE_card_info.SNR[3]; //��������
					block1_buffer[27] = MIFARE_card_info.SNR[2];
					block1_buffer[28] = MIFARE_card_info.SNR[1];
					block1_buffer[29] = MIFARE_card_info.SNR[0];
					//2015-04-03 ���Ӳ���Ա���ź͸�λʱ�Ľ����� andyluo
                    for(i=30;i<32;i++)
						block1_buffer[i] = 0xAA;
					Save_Record(block1_buffer,32);						 
                    Deal_SwipCardIMG(car-1,0); 
				#ifdef TWO_CAR  
					resetCarstation_success(CS_RF_US.smartCard_SNR,CS_RF_US.start_stopTime,max_stop_time,car - 1); //��ʾ car��λ ��λ�ɹ�
                #else
					resetCarstation_success(CS_RF_US.smartCard_SNR,CS_RF_US.start_stopTime,max_stop_time,car); //��ʾ car��λ ��λ�ɹ�
                #endif
					light(car,NO);
					reset_carStation(car); //��λ car��λ ״̬
					delay(KEYTIMEOUT_1S * 5);   
					}
				else
					{//��ʾ ����λû����ʹ�ã�����Ҫ��λ
					display_no_reset();
					delay(KEYTIMEOUT_1S * 3.5); 					
					}
				return 1;
				}
			else
				{
				car_outdate();
				delay(KEYTIMEOUT_1S * 2);
				}	
			break;
			} //��λ��
		case RECORDTEST_FHCARD1://flash��¼���Կ�
		case RECORDTEST_FHCARD://flash��¼���Կ�
		case RECORDTEST_FMCARD://�����¼���Կ�
        case DECEIVE_CARD://���ڿ�
        	{
			if(validity(block2_buffer,DECEIVE_CARD) == OK)//����������Ч���� ���
              {
			  timeOut = 0;
			  Smart_Power_OFF;
			  //�濼�ڼ�¼
              block1_buffer[0] = 0xEE;//��¼ͷ
              block1_buffer[1] = 0x00; //��������
              block1_buffer[2] = 0x00;
              block1_buffer[3] = 0x00;
              block1_buffer[4] = 0x00;
              block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
              block1_buffer[6] = MIFARE_card_info.SNR[2];
              block1_buffer[7] = MIFARE_card_info.SNR[1];
              block1_buffer[8] = MIFARE_card_info.SNR[0];
              block1_buffer[9] = time[4];//��
              block1_buffer[10] = time[3];//��
              block1_buffer[11] = time[2];//��
              block1_buffer[12] = time[1];//ʱ
              block1_buffer[13] = time[0];//��
              block1_buffer[14] = 0x00;
              block1_buffer[15] = 0x00;
              block1_buffer[16] = 0x00;
              block1_buffer[17] = 0x00;
              block1_buffer[18] = 0x00;
              block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x09;//���� ��λΪcar   
              block1_buffer[20] = time[4];
              block1_buffer[21] = time[3];
              block1_buffer[22] = time[2];
              block1_buffer[23] = time[1];
              block1_buffer[24] = time[0];
			  block1_buffer[25] = MIFARE_FLAG;//����ͨ��¼��־
			  for(i=26;i<32;i++)
			  	block1_buffer[i] = 0xAA;
			  //�������ݲ��Թ���---2015-04-03 andyluo
			  lcd_clear();
			  dispaly(3,2,(HZ + qing));
			  dispaly(3,3,(HZ + shao));//��
			  dispaly(3,4,(HZ + hou));//��	  
			  LCD_display_symbol(3,9,5,1);//...
			  LCD_display_symbol(3,10,5,1);
			  LCD_display_symbol(3,11,5,1);
			  if(block2_buffer[0]==RECORDTEST_FHCARD1)
			  	timeOut = 5000;
			  else if(block2_buffer[0]==RECORDTEST_FHCARD)
			  	timeOut = 2000;
			  else if(block2_buffer[0]==RECORDTEST_FMCARD)
			  	timeOut = 200;
			  else
		#ifdef OURTEST
			  timeOut = 10000;	
		#else
			  timeOut = 1;	  
		#endif
			  while(timeOut --)
			  	{
				delay(10);
				Save_Record(block1_buffer,32);
				}
			  //��ʾ ���ڴ򿨳ɹ�
			  //��ʾ �ε�
			  Buzz_0;
			  delay(KEYTIMEOUT_1S/10);
			  Buzz_1;
			  lcd_clear();
			  for(i=0;i<4;i++)
			  	{
				Card_No[i] = MIFARE_card_info.SNR[3 - i];
				}
			  timecard_OK(Card_No);
			  delay(KEYTIMEOUT_1S * 4);
			  return 1;                         
              }
			else
			  {
			  car_outdate();
			  delay(KEYTIMEOUT_1S * 2);
			  return 1;   
              }
			break;
        	} //���ڿ� ����¼���Կ�
        case HLEPPARK_CARD://������ 2016-02-18   ȡ����ˢ����
        	TMP.cardplace = CardType_HLEPCARDRD;
        case MIFARAE_PARK_CARD:	  
			{
			Now_time = block2_buffer[1];	
			I2C_ReadS_24C((car1_value_comd + (car - 1)),value_buffer,1);//������� �ı�־	                      
            I2C_ReadS_24C((car1_write_comd + (car - 1)),write_buffer,1);//������� �ı�־	                      
            //�ѿ��ź�block2����������߱����������Է���block2ȫдΪ0��ʱ�� �ָ�	                      
            save_mifare_NO(MIFARE_card_info.SNR,block2_buffer,car);	                              
            //����Ҫ���� ���������ж�
            for(i=0;i<4;i++)
				carSNR[i] = MIFARE_card_info.SNR[3-i];


			//i = value_comd(0x2B,8,5200);
			if(left_momery_buffer[0] + left_momery_buffer[4] !=0xff || left_momery_buffer[1] + left_momery_buffer[5] !=0xff || left_momery_buffer[2] + left_momery_buffer[6] !=0xff || left_momery_buffer[3] + left_momery_buffer[7] !=0xff)
                {				
				if(QuitTime>=4)
					QuitFlag = 0;
				else
					{
					QuitFlag = 1;
					continue;
					}
				//Mifare_RecoverV0(MIFARE_card_info.SNR,car);
				//�����쳣
				Smart_Power_OFF;	
				diplay_error(errcord_3);
				delay(KEYTIMEOUT_1S * 2);
				return 0;
				}
			save_mifare_v0(MIFARE_card_info.SNR,left_momery_buffer,car);
            left_momery = left_momery_buffer[0] + left_momery_buffer[1] * 0x100 + left_momery_buffer[2] * 0x10000 + left_momery_buffer[3] * 0x1000000;
			if(left_momery > 100000)
				{
				if(QuitTime>=4)
					QuitFlag = 0;
				else
					{
					QuitFlag = 1;
					continue;
					}
				MoneryException();
				delay(KEYTIMEOUT_1S*2);
				return 0x73;//���� ����
				}

			//�������ж�˳�� ����--����--ȫ��
			  memset(buffer,0,4);  
			  memcpy(buffer+4,carSNR,4);	
			  listret = SelectList_SRAM(buffer,ListType_CPCDEL,buffer);
			  if(listret<0)
				  {//���ڼ�����
				  listret = SelectList_SRAM(buffer,ListType_CPCADD,buffer);
				  if(listret<0)
					  {//����������
					  listret = SelectList_SRAM(buffer,ListType_CPCALL,buffer);
					  }
				  if(listret>=0)
					  {
					  TMP.cardmny = left_momery;
					  memcpy(TMP.cardno,carSNR,4);
			//		  disp_YWT_IMG(11);//��ʾ��������
					  disp_YWT_IMG(0xC1);//��ʾ��������
					  return 1;
					  }
				  }
			if((left_momery<=0)&&(car_station != 0x66))
				{//add 2014-03-11
				//��ʾ ���㣬���ֵ
//				if(QuitTime>=4)
//					QuitFlag = 0;
//				else
//					{
//					QuitFlag = 1;
//					continue;
//					}
				Smart_Power_OFF;//�ص�����ģ��ĵ�Դ 
				OPEN_EXTI9_5_IRQ();	
				OPEN_EXTI15_10_IRQ();
				no_momery(left_momery);
				timeOut = 0;
				while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
					{	
					if(key_flag)
						{ 
						key_flag = 0;
						delay(KEYTIMEOUT_1S * QUIT_TIME);
						break;
						}	
					timeOut++;  
					}
				return 0;
				}
			if(car_station == 0x66)//��ʾ�����λ ����ʹ��
				{
				flag = campare_card_NO(car,MIFARE_card_info.SNR,MIFARE_CARD,1);
				if(flag == OK)//�����Ƿ���ͬ
					{
					//1.����ͣ��ʱ���ͣ������
					max_stop_time = ret_max_24hour(CS_RF_US.start_stopTime,MIFARAE_PARK_CARD);                            
                    momery = time_to_momery(CS_RF_US.start_stopTime);
					mnyold = momery;
					if(momery > 0)
						{
						card_free_count = 0x00;
						u8 OVERDRAFT_F =0;
					#ifdef OVERDRAFT 
						OVERDRAFT_F = 1;
					#endif
//									if((left_momery > momery)||(left_momery <= momery))//2015-04-14 16:44:01
						if((left_momery > momery)||OVERDRAFT_F)
							{ 
							momery_buffer[0] = 0x00;   
							momery_buffer[1] = 0x00;   
							momery_buffer[2] = momery / 256;
							momery_buffer[3] = momery % 256;
							}  
						else    
							{
							momery = left_momery;
							momery_buffer[0] = left_momery_buffer[3];    
							momery_buffer[1] = left_momery_buffer[2];
							momery_buffer[2] = left_momery_buffer[1]; 
							momery_buffer[3] = left_momery_buffer[0];  
							}
						}
					else
						{
						card_free_count = 0x00;
						//�ж� �Ƿ�������ͣ��                                             	                                      
                        momery_buffer[0] = 0x00;
                        momery_buffer[1] = 0x00;
                        momery_buffer[2] = 0x00;
                        momery_buffer[3] = 0x00;
						//�ж� �Ƿ�������ͣ��
                        I2C_ReadS_24C((car1_no_S_flag + (car - 1) * 0x04),flag_buffer,1);                                              
                        flag_NO = flag_buffer[0];
						I2C_ReadS_24C((car1_no_S_flag + (car - 1) * 0x04) + 1,flag_buffer,1);                                             
                        flag_Momery = flag_buffer[0]; 
						flag_free = get_current_time(); //��ȡ ��ǰ�Ƿ��� ���ʱ��
						if(block2_buffer[0]==HLEPPARK_CARD)
							flag_Momery = 0;//������ȡ����ˢ���� 2016-02-18
                        if((flag_NO == OK) && (flag_Momery == OK) && (flag_free == 1))//���ͣ���Ŀ��� �� �ϴ� ͣ���Ŀ�����ͬ
                        	{
							momery = RR_ST1.Frist_Money* RR_ST1.Sale_Base;
							u8 OVERDRAFT_F =0;
						#ifdef OVERDRAFT 
							OVERDRAFT_F = 1;
						#endif
							if((momery>left_momery)&&(!OVERDRAFT_F)&&left_momery)
								momery = left_momery;   
							momery_buffer[0] = 0x00;
							momery_buffer[1] = 0x00;
							momery_buffer[2] = momery / 256;
							momery_buffer[3] = momery % 256;
							} 
						else  // ͣ��     
							{
							}
						}                           
                      //�Ƚ������ϴο۴�Ǯ����� �Ƿ�һ��
                      read_momery_to_Fm(select_buffer,car);  
					  test_momery = hcl(select_buffer,4);
					  if((!test_momery)||(!err_1[car])) //2015-09-11 
						  {
						  NEWmomery_buffer[0] = left_momery_buffer[3]; 												
						  NEWmomery_buffer[1] = left_momery_buffer[2]; 												 
						  NEWmomery_buffer[2] = left_momery_buffer[1]; 											   
						  NEWmomery_buffer[3] = left_momery_buffer[0]; 											  
						  write_momery_to_Fm(NEWmomery_buffer,car);
						  read_momery_to_Fm(select_buffer,car);  
						  test_momery = hcl(select_buffer,4);									  
						  }						  
                      if(test_momery == left_momery)
					  	  value_buffer[0] = 0x01;
					  else
					  	{
					  	value_buffer[0] = 0x01;
						if(momery==left_momery)
							{
							momery = test_momery-left_momery;
							momery_buffer[0] = 0x00;
							momery_buffer[1] = 0x00;
							momery_buffer[2] = momery / 256;
							momery_buffer[3] = momery % 256;		  
							}							
					  	}
					  if(momery&&((!err_1[car])||value_buffer[0]))
					  	{
					  	if((!addmny[car])&&(left_momery!=test_momery-momery))
					  		{
					  		vetime ++;
							addmny[car] = value_comd(0x2d,8,momery); 
							if(addmny[car])
								{addmny[car] += 0x10;
								new_submny = RxBuffer[6] + RxBuffer[5] * 0x100 + RxBuffer[4] * 0x10000 + RxBuffer[3] * 0x1000000;
								left_momery = new_submny;
								}										
					  		}
						else
							addmny[car] +=OK;
						if(test_momery&&(left_momery!=test_momery-momery))
							{
							if((test_momery ==left_momery)||
								(test_momery - momery > left_momery))
								{
								testmnydisp +=0xb0;
								if(test_momery ==left_momery)
									add_momery = momery;
								else
									add_momery = (test_momery - momery) - left_momery;
//								value_comd(0x2b,8,add_momery);
								}
							else
								{
								testmnydisp +=0xd0;
								add_momery = left_momery - (test_momery - momery);
								value_comd(0x2d,8,add_momery);
								}
							}							
						//testmnydisp +=0x10;
						if(addmny[car])
							testmnydisp++;
					  	}
					  else addmny[car] += OK+OK;						  
					  value_buffer[0] = 0x00;						  
                      if((momery==0)|| addmny[car])//�ۿ�ɹ�
                      	{                                   
                        //2. д��������Ϊ����1�Σ�д�뵱ǰ���ڣ���ȥ����λ�����
						if(block2_buffer[0]==HLEPPARK_CARD)
							block2_buffer[0] = HLEPPARK_CARD;
						else
							block2_buffer[0] = 0x60;
                        //block2_buffer[1] = 0x00;//������־  
                        if(block2_buffer[1])block2_buffer[1] --;//������־
                        if(err_1[car]&&HR_TIME[car]) block2_buffer[1]= HR_TIME[car]-1;
					  	i =2;
//									  block2_buffer[i++] = time[4]; 
						block2_buffer[i++] = time[3]; 
						block2_buffer[i++] = time[2]; 	
						block2_buffer[i++] = time[1];
						block2_buffer[i++] = time[0];  
						block2_buffer[i++] = 0x88;//time[4]; 	
						lockmny = hcl(block2_buffer+7,2);//�ⶳ ����
						if((lockmny>RR_ST1.Max_Stop_Momery)&&block2_buffer[1])
							{
							if(err_1[car]&&HR_TIME[car])
								;//�Ѿ��ٳ��� 2015-08-19  �Ѿ���������
							else
								lockmny -= RR_ST1.Max_Stop_Momery;
							}
						else
							lockmny = 0;							
						fll(lockmny,block2_buffer+7,2);
						
						lockmny = block2_buffer[1]*RR_ST1.Max_Stop_Momery;//2015-10-27
						fll(lockmny,block2_buffer+7,2);//2015-10-27
						
//                            block2_buffer[7] = 0x00;
//                            block2_buffer[8] = block2_buffer[1]*RR_ST1.Max_Stop_Momery;
						if(block2_buffer[12]!=0xAA)
							{
							block2_buffer[9] = 0x01;
							block2_buffer[10] = RDST_ADDR;
							}
						else
							{
							if(block2_buffer[9]<10)
								block2_buffer[9]++;
	                        block2_buffer[10]++;
							if((block2_buffer[10]-RDBK_SUM)%4);
							else block2_buffer[10]++;
							if(block2_buffer[10]>RDEND_ADDR)
								block2_buffer[10] = RDST_ADDR;
							}
                        block2_buffer[11] = card_free_count;
                        block2_buffer[12] = 0xAA;
                        block2_buffer[13] = 0x00;
                        block2_buffer[14] = 0x00;
                        block2_buffer[15] = 0x00;
						writetime =write_comd(BLOCK2_ADDR,block2_buffer); 
                        if(writetime== OK)
							{
//                            Smart_Power_OFF;//�ص�����ģ��ĵ�Դ Ϊ��ʡ��
//                            HR_TIME[car] = 0;
//                            err_1[car] = 0;
//							WriteRecover(car,0);
//							//3. ��λ����  
//							light(car,NO);
//							OPEN_EXTI9_5_IRQ();
//							OPEN_EXTI15_10_IRQ();							
//                            Buzz_0;
//                            delay(KEYTIMEOUT_1S/10);
//                            Buzz_1;								
                            //3. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ���֣�����ͣ��ʱ�䣩    
                            block1_buffer[0] = 0x00; //��λ״̬
                            block1_buffer[1] = 0x00;
                            block1_buffer[2] = 0x00; //��������
                            block1_buffer[3] = 0x00; //��������
                            block1_buffer[4] = 0x00; //��������
                            block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
                            block1_buffer[6] = MIFARE_card_info.SNR[2];
                            block1_buffer[7] = MIFARE_card_info.SNR[1];
                            block1_buffer[8] = MIFARE_card_info.SNR[0];
                            block1_buffer[9] = time[3]; //��
                            block1_buffer[10] = time[2]; //��
                            block1_buffer[11] = time[1]; //ʱ
                            block1_buffer[12] = time[0]; //��
                            block1_buffer[13] = time[4]; //�� Ԥ��
                            block1_buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ
                            block1_buffer[15] = max_stop_time % 60;      
                                //д���� ��15���� ����ˢ
                            write_car_15_reference(car,block1_buffer,16);    
                            for( i=0;i<16;i++)
								block1_buffer[i] = 0;
							write_car_reference_of_use_info(car,block1_buffer,16);
                            //д���ɹ� ��ȷ����
                            flag_buffer[0] = 0x00;                                                        
                            I2C_WriteS_24C(car1_write_comd + (car - 1) ,flag_buffer,1);
                            //�ۿ�ɹ� ��ȷ����
                            flag_buffer[0] = 0x00;
                            I2C_WriteS_24C((car1_value_comd + (car - 1)),flag_buffer,1); 
                            //1. ��ɷѼ�¼                                                                     
                             block1_buffer[0] = 0xEE;//��¼ͷ
                             block1_buffer[1] = 0x00; //��������
                             block1_buffer[2] = 0x00;
                             block1_buffer[3] = 0x00;
                             block1_buffer[4] = 0x00;
                             block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
                             block1_buffer[6] = MIFARE_card_info.SNR[2];
                             block1_buffer[7] = MIFARE_card_info.SNR[1];
                             block1_buffer[8] = MIFARE_card_info.SNR[0];
                             block1_buffer[9] = CS_RF_US.start_stopTime[4];//time[4];//��
                             block1_buffer[10] = CS_RF_US.start_stopTime[0];//��
                             block1_buffer[11] = CS_RF_US.start_stopTime[1];//��
                             block1_buffer[12] = CS_RF_US.start_stopTime[2];//ʱ
                             block1_buffer[13] = CS_RF_US.start_stopTime[3];//��
                             block1_buffer[14] = test_momery>>16;//left_momery_buffer[2];
                             block1_buffer[15] = test_momery>>8;//left_momery_buffer[1];
                             block1_buffer[16] = test_momery;//left_momery_buffer[0];
                             block1_buffer[17] = momery_buffer[2];
                             block1_buffer[18] = momery_buffer[3];
                             block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x02;//��2��ͣ�� ��λΪcar 
                             block1_buffer[20] = time[4];
                             block1_buffer[21] = time[3];
                             block1_buffer[22] = time[2];
                             block1_buffer[23] = time[1];
                             block1_buffer[24] = time[0];
                             block1_buffer[25] = CardType_MF1;//����ͨ��¼��־
                             for(i=26;i<32;i++)block1_buffer[i] = 0xAA;
							 Save_Record(block1_buffer,32);
							 save_RPTMNY_record(CardType_MF1,momery);//2015-12-07
							 TMP.ckflag[car] = 0;
							 //���Ӽ�¼д������2016-02-18
							 flag = block2_buffer[10];
							 for(i=0;i<5;i++)
							 	block2_buffer[i] = block1_buffer[9+i];
                             block2_buffer[i++] = time[2];
                             block2_buffer[i++] = time[1];
                             block2_buffer[i++] = time[0];
                             block2_buffer[i++] = test_momery>>16;//left_momery_buffer[2];
                             block2_buffer[i++] = test_momery>>8;//left_momery_buffer[1];
                             block2_buffer[i++] = test_momery;//left_momery_buffer[0];
                             block2_buffer[i++] = momery_buffer[2];
                             block2_buffer[i++] = momery_buffer[3];
							 I2C_ReadS_24C(mibiao_number,buffer,3);//�����
                             block2_buffer[i++] = buffer[0];
                             block2_buffer[i++] = buffer[1];
                             block2_buffer[i++] = buffer[2];							 
							 writetime =CardRecrodSave(flag,block2_buffer); 

							 Smart_Power_OFF;//�ص�����ģ��ĵ�Դ Ϊ��ʡ��
							 WriteRecord(car,RECORD_NULL);
							 Deal_SwipCardIMG(car-1,0);
							 HR_TIME[car] = 0;
							 err_1[car] = 0;
							 WriteRecover(car,0);
							 //3. ��λ����	
							 light(car,NO);
							 OPEN_EXTI9_5_IRQ();
							 OPEN_EXTI15_10_IRQ();							 
							 Buzz_0;
							 delay(KEYTIMEOUT_1S/10);
							 Buzz_1;			 
							 //��ʼ ���� ����                                                         
                             if((card_free_count >= 0x01 && card_free_count <= 0x05) || momery > 0)//��� ͣ��
                             	{	                                       
                                //д����ͣ�� �ı�־
                                flag_buffer[0] = 0x00;
                                //I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04),flag_buffer,1);
                                //д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
                                flag_buffer[0] = 0x00;
//                                I2C_WriteS_24C((car1_useing + (car - 1)),flag_buffer,1);
                            	}                                  
                             else
							 	{                                   
                                    //�ж� �Ƿ�������ͣ��                                                      	                                                      
                                I2C_ReadS_24C((car1_no_S_flag + (car - 1) * 0x04),flag_buffer,1);                                              
                                flag_NO = flag_buffer[0];                                             
                                I2C_ReadS_24C((car1_no_S_flag + (car - 1) * 0x04) + 1,flag_buffer,1);                                             
                                flag_Momery = flag_buffer[0];//����ͣ��
                                flag_free = get_current_time();	                                    
                                if((flag_NO == OK) && (flag_Momery == OK) && (flag_free == 1))//���ͣ���Ŀ��� �� �ϴ� ͣ���Ŀ�����ͬ
                                   	{
									flag_buffer[0] = 0x00;
									I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04),flag_buffer,1);
                                    //д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
                                    flag_buffer[0] = 0x00;
                                    I2C_WriteS_24C((car1_useing + (car - 1)),flag_buffer,1);
                                    } 
								else if(flag_free == 1)  // ͣ��   
									{
									//д����ͣ�� �ı�־
									flag_buffer[0] = 0x01;
                                    I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04),flag_buffer,1);   
                                    //д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
                                    flag_buffer[0] = 0x01;
                                    I2C_WriteS_24C((car1_useing + (car - 1)),flag_buffer,1);                                            
                                	} 
								else
                                    {
									flag_buffer[0] = 0x00;
                                    I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04),flag_buffer,1);
                                    //д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
                                    flag_buffer[0] = 0x00;
                                    I2C_WriteS_24C((car1_useing + (car - 1)),flag_buffer,1);
                                    }
								}     
							  if(mnyold>0)//2015-08-24����
							  	{
								flag_buffer[0] = 0x00;
                                I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04),flag_buffer,1);
                                //д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
                                flag_buffer[0] = 0x00;
                                I2C_WriteS_24C((car1_useing + (car - 1)),flag_buffer,1);
                                }
							  
                              //2. ��ʾͣ��ʱ�䣬ͣ�����ã�����ʣ����
                              left_momery = left_momery_buffer[0] + left_momery_buffer[1] * 0x100 + left_momery_buffer[2] * 0x10000 + left_momery_buffer[3] * 0x1000000;                                             
                              for(i=0;i<4;i++) 
							  	{                                              
                                Card_No[i] = MIFARE_card_info.SNR[3 - i];                                             
                              	}                                             
//                                          if(momery >= left_momery)                                            
//                                            momery = left_momery;

							  read_momery_to_Fm(select_buffer,car);  
							  test_momery = hcl(select_buffer,4);
							  if(!left_momery)	  
								  display_2(Card_No,max_stop_time / 60, max_stop_time % 60,left_momery,momery,MIFARAE_PARK_CARD); 
                              if(!test_momery)                                                     
                                display_2(Card_No,max_stop_time / 60, max_stop_time % 60,left_momery- momery,momery,MIFARAE_PARK_CARD);       
                              else
							   	display_2(Card_No,max_stop_time / 60, max_stop_time % 60,test_momery - momery,momery,MIFARAE_PARK_CARD); 
								  //LCD_display_symbol(4,12,(addmny[car]>>4)&0x0f,0);
								  //LCD_display_symbol(4,13,addmny[car]&0x0f,0);
								  //LCD_display_symbol(4,15,(testmnydisp>>4)&0x0f,0);
								  //LCD_display_symbol(4,16,testmnydisp&0x0f,0);
							  addmny[car] = NO;
							  for(i=0;i<4;i++)momery_buffer[i] = 0x00;								
							  // 1. ��� �ݴ濨��� 											
							  write_momery_to_Fm(momery_buffer,car); 
							  timeOut = 0;                                             
                              while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)                                              
                              	{                                                
                                if(key_flag)
									{ 
									key_flag = 0; 
									delay(KEYTIMEOUT_1S * QUIT_TIME);
                                  	break;                                                 
                                	}
								timeOut++;  
								}
							  LeaveBlessing();
							  return 0;//add 2014-03-06 andyluo
							  }
						else
							{ 
							//4. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ��������ͣ��ʱ�䣩
							block1_buffer[0] = 0x66; //��λ״̬
							block1_buffer[1] = Now_time;
							block1_buffer[2] = 0x00; //��������
							block1_buffer[3] = 0x00; //��������
							block1_buffer[4] = 0x00; //��������
							block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
							block1_buffer[6] = MIFARE_card_info.SNR[2];
							block1_buffer[7] = MIFARE_card_info.SNR[1];
							block1_buffer[8] = MIFARE_card_info.SNR[0];
							block1_buffer[9] = time[3]; //��
							block1_buffer[10] = time[2]; //��
							block1_buffer[11] = time[1]; //ʱ
							block1_buffer[12] = time[0]; //��
							block1_buffer[13] = time[4]; //�� Ԥ��
							block1_buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ
							block1_buffer[15] = max_stop_time % 60; 
							
							if(!err_1[car])
								{
								HR_TIME[car] = Now_time;
								err_1[car] =1;
								write_car_reference_of_use_info(car,block1_buffer,9);//����д����ʱ��
								}
                                //��Ǯʱ  ȫ�� ��Ϊ 0Ԫ�� �����
                                WriteRecover(car,1);
                                
                            //�ݴ����� �ۿ�ɹ� ��д��ʧ��
                            //�ۿ�ɹ� ��д��ʧ�ܣ������´οۿ��ʱ��Ҫ�ȱȽ������ܿ۶�Ǯ
                            flag_buffer[0] = 0x01;
                            I2C_WriteS_24C((car1_value_comd + (car - 1)),flag_buffer,1);   
                          	                                      
                            //�ۿ����                                           
                            //Smart_Power_OFF;//�ص�����ģ��ĵ�Դ Ϊ��ʡ��
                            OPEN_EXTI9_5_IRQ();
                            OPEN_EXTI15_10_IRQ();
                            //д���������ó�����־λ                                           
                            //���濨�ź�д��ǰ�Ĺ�������                                                   
                            //��ʾ д������ ������ˢ��                                           
                            QuitFlag = 1;                                                
                            display_flag = 2;
							}     
						}                                            
                      else    
					  	{
						//��Ǯʱ  ȫ�� ��Ϊ 0Ԫ�� �����
						WriteRecover(car,1);                                    
                        //�ۿ����                                           
                        //Smart_Power_OFF;//�ص�����ģ��ĵ�Դ Ϊ��ʡ��
                        OPEN_EXTI9_5_IRQ();
                        OPEN_EXTI15_10_IRQ();
                        //д���������ó�����־λ                                           
                        //���濨�ź�д��ǰ�Ĺ�������                                                   
                        //��ʾ д������ ������ˢ��                                           
                        //write_card_error(0);                                           
                        /*
                        timeOut = 0;
                        while(timeOut < KEYTIMEOUT_1S * 3)
                        {
                           if(key_flag){
                              //key_flag = 0;
                             delay(KEYTIMEOUT_1S * QUIT_TIME);
                           break;
                           }
                           timeOut++;
                        }
                        */                                
                        #ifdef DEBUG
                            //�鿴DEBUG��Ϣ
                            display_debug_infornation(RxBuffer,RxCounter);
                            delay(KEYTIMEOUT_1S * 2);
                            #endif                                
                        QuitFlag = 1;   
						display_flag = 2;
						err_1[car] = 1;
						} 
					  }
				else //���Ų���ͬ
					{
                    Smart_Power_OFF;
					OPEN_EXTI9_5_IRQ();
                    OPEN_EXTI15_10_IRQ();
                    //��ʾ ��λռ���� ������ѡ��λ
                    carStation_using();
                    delay(KEYTIMEOUT_1S * 3);
					return 0;
					}
				break;
				}
              else//��ʾ �����λû����ʹ��
              	{
				//�볡�ж����----ǰ������--�ٽ���
				flag = campare_card_NO(car,MIFARE_card_info.SNR,MIFARE_CARD,1);
				if(flag == OK)//�����Ƿ���ͬ//������ͬ �ϴμٽ���
//				if(campare_card_NO(car,MIFARE_card_info.SNR,MIFARE_CARD,1) == OK )
                  { //������ͬ �ϴμٽ���
                  //if((block2_buffer[1] <= HR_TIME)||(!HR_TIME)||(!block2_buffer[1]))
//				  if(block2_buffer[1]==0)//2016-05-01 �����쳣�ж� ��д���ɹ�
                  if(err_1[car]&&(block2_buffer[1]==0))
				  	{				  	
					// 3. д����ʹ�ñ�־��д�뵱ǰ���ڣ���λ�����	
					if(block2_buffer[0]==HLEPPARK_CARD)
						block2_buffer[0] = HLEPPARK_CARD;
					else
						block2_buffer[0] = 0x60;
					block2_buffer[1]= HR_TIME[car]+1;
					i =2;
//									  block2_buffer[i++] = time[4];	
					block2_buffer[i++] = time[3];
					block2_buffer[i++] = time[2];
					block2_buffer[i++] = time[1];
					block2_buffer[i++] = time[0];
					block2_buffer[i++] = 0x88;//time[4];	
					//if(block2_buffer[1]== HR_TIME[car])
						//{
						//lockmny = hcl(block2_buffer+7,2)+RR_ST1.Max_Stop_Momery;
						//fll(lockmny,block2_buffer+7,2);						
						//}
					lockmny = block2_buffer[1]*RR_ST1.Max_Stop_Momery;//2015-10-27
					fll(lockmny,block2_buffer+7,2);//2015-10-27
//					lockmny = hcl(block2_buffer+7,2)+RR_ST1.Max_Stop_Momery;
//					fll(lockmny,block2_buffer+7,2);
//						block2_buffer[7] = 0x00;
//						block2_buffer[8] = block2_buffer[1]*RR_ST1.Max_Stop_Momery;
//					block2_buffer[9] = 0x00;
//					block2_buffer[10] = 0x00;
					block2_buffer[11] = card_free_count;
//					block2_buffer[12] = 0x00;
					block2_buffer[13] = 0x00;
					block2_buffer[14] = 0x00;
					block2_buffer[15] = 0xAA;
					flag = write_comd(BLOCK2_ADDR,block2_buffer);
					if(flag != OK)
						break;		
					}
				  if(TMP.ckflag[car])
				  	{
					TMP.ckflag[car] = 0;
					//4. �油���¼
					block1_buffer[0] = 0xEE;//��¼ͷ
					block1_buffer[1] = 0x00; //��������
//					block1_buffer[2] = TMP.cktime;
//					fll(TMP.ckmny,block1_buffer+3,2);
					
					block1_buffer[2] = TMP.feetime;
					memcpy(block1_buffer+3,TMP.unlockmny,2);				
//									block1_buffer[3] = 0x00;
//									block1_buffer[4] = 0x00;
					block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
					block1_buffer[6] = MIFARE_card_info.SNR[2];
					block1_buffer[7] = MIFARE_card_info.SNR[1];
					block1_buffer[8] = MIFARE_card_info.SNR[0];
					for(i=0;i<5;i++)
						block1_buffer[9+i] = time[4-i];//������ʱ��
					block1_buffer[14] = TMP.bmny[2];
					block1_buffer[15] = TMP.bmny[1];
					block1_buffer[16] = TMP.bmny[0];
					block1_buffer[17] = TMP.fmny[0];
					block1_buffer[18] = TMP.fmny[1];
					block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x07;//������δ���� ��λΪcar
					bushimny[car] = 0;	 
					bukanmny[car] = 0;	
					TMP.CPC_ckmny[car] = 0;
					for(i=0;i<5;i++)
						block1_buffer[20+i] = time[4-i];//������ʱ��
					block1_buffer[25] = CardType_MF1;//����ͨ��¼��־
					for(i=26;i<32;i++)								 
						block1_buffer[i] = 0xAA;
					Save_Record(block1_buffer,32);	
					momery = hcl(TMP.fmny,2);
					save_RPTMNY_record(CardType_MF1,momery);//2015-12-07
					WriteRecord(car,RECORD_NULL);
				  	}
				  //����ʱ  ȥ�� ��Ϊ0Ԫ�ı��
				  WriteRecover(car,0);  
				  //��ʼ ���� ����    
				  for(i=0;i<4;i++)    
				  	momery_buffer[i] = left_momery_buffer[3 - i];
                    
                  // 1. �ݴ濨��� ��ʹ��״̬����                                            
                  //write_momery_to_Fm(momery_buffer,car);      
                  // 2. ���ݿ��� ������� �������ͣ��ʱ��   
				  lockmny = hcl(block2_buffer+7,2)*100;//���ᱶ��--���
				  if(((left_momery <=lockmny)&&lockmny)||(err_1[car]))
				  	lockmny -= RR_ST1.Max_Stop_Momery*100;
				  err_1[car] =0;
				  HR_TIME[car] = 0;
				  if(left_momery >lockmny)
					max_stop_time = momery_to_time(left_momery - lockmny);//���ͣ��ʱ��
				  else
				  	{
					if((block2_buffer[1]>=1)&&(!err_1[car]))
						{
						max_stop_time = 0;
						Smart_Power_OFF;
						display_max_park_count();
						timeOut = 0;
						while(timeOut < KEYTIMEOUT_1S * 2.2)
							{
							if(key_flag)
								{
								key_flag = 0;
								break;
								}
							timeOut++;
							}
						return 0;
						}
					else
						max_stop_time = momery_to_time(left_momery);//���ͣ��ʱ��
				  	}
                  //4. ��λ����  
                  light(car,OK);   
				  addmny[car] = NO;
				  vetime = 0;
				  HR_TIME[car] = 0;
				  err_1[car]=0;
				  //���� �ε�                                                                                          
                  OPEN_EXTI9_5_IRQ();  
				  OPEN_EXTI15_10_IRQ();
				  Buzz_0;    
				  delay(KEYTIMEOUT_1S/10); 
				  Buzz_1;
				  if(campare_card_NO(car,MIFARE_card_info.SNR,MIFARE_CARD,2))
				  	{ 
					flag_buffer[0] = 0x01;
					I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04) + 1,flag_buffer,1);  
					} 
				  else      
				  	{
					flag_buffer[0] = 0x00;
					I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04) + 1,flag_buffer,1);                                            
                    } 
				  //д���ɹ� ��ȷ����
				  flag_buffer[0] = 0x00; 
				  I2C_WriteS_24C(car1_write_comd + (car - 1) ,flag_buffer,1);
                  //4. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ��������ͣ��ʱ�䣩
                  block1_buffer[0] = 0x66; //��λ״̬
                  block1_buffer[1] = 0x00;
                  block1_buffer[2] = 0x00; //��������
                  block1_buffer[3] = 0x00; //��������
                  block1_buffer[4] = 0x00; //��������
                  block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
                  block1_buffer[6] = MIFARE_card_info.SNR[2];
                  block1_buffer[7] = MIFARE_card_info.SNR[1];
                  block1_buffer[8] = MIFARE_card_info.SNR[0];
                  block1_buffer[9] = time[3]; //��
                  block1_buffer[10] = time[2]; //��
                  block1_buffer[11] = time[1]; //ʱ
                  block1_buffer[12] = time[0]; //��
                  block1_buffer[13] = time[4]; //�� Ԥ��
                  block1_buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ
                  block1_buffer[15] = max_stop_time % 60;				  
				  memcpy(block1_buffer+16,momery_buffer,4);
                  write_car_reference_of_use_info(car,block1_buffer,16);
                  //1. �汾��λ����
                  //�Ѿ�д��
                  //2. ��ͣ����¼
                  write_momery_to_Fm(momery_buffer,car);              
                  block1_buffer[0] = 0xEE;//��¼ͷ                                            
                  block1_buffer[1] = 0x00; //��������                                           
                  block1_buffer[2] = 0x00;                                            
                  block1_buffer[3] = 0x00;                                            
                  block1_buffer[4] = 0x00;                                            
                  block1_buffer[5] = MIFARE_card_info.SNR[3];                                           
                  block1_buffer[6] = MIFARE_card_info.SNR[2];                                           
                  block1_buffer[7] = MIFARE_card_info.SNR[1];                                            
                  block1_buffer[8] = MIFARE_card_info.SNR[0];                                          
                  block1_buffer[9] = time[4];//��                                           
                  block1_buffer[10] = time[3];//��                                           
                  block1_buffer[11] = time[2];//��                                          
                  block1_buffer[12] = time[1];//ʱ                                          
                  block1_buffer[13] = time[0];//��                                          
                  block1_buffer[14] = momery_buffer[1];                                          
                  block1_buffer[15] = momery_buffer[2];                                           
                  block1_buffer[16] = momery_buffer[3];                                           
                  block1_buffer[17] = 0x00;                                          
                  block1_buffer[18] = 0x00;                                         
                  block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x01;//��һ��ͣ�� ��λΪcar                                              
				  bushimny[car] = 0;   
				  bukanmny[car] = 0;  
				  TMP.CPC_ckmny[car] = 0;
                  block1_buffer[20] = time[4];                                           
                  block1_buffer[21] = time[3];                                          
                  block1_buffer[22] = time[2];                                          
                  block1_buffer[23] = time[1];                                          
                  block1_buffer[24] = time[0];                                            
                  block1_buffer[25] = CardType_MF1;//����ͨ��¼��־
                  for(i=26;i<32;i++)                                             
                    block1_buffer[i] = 0xAA;                                                                            
                  Save_Record(block1_buffer,32);
                  WriteRecord(car,TMP.cardplace);
				  Deal_SwipCardIMG(car-1,1);
                  //3. ��ʾ  ����  ������� ��ͣ��ʱ��
                  lcd_clear();
                  for(i=0;i<4;i++)   
				  	{                                              
                    Card_No[i] = MIFARE_card_info.SNR[3 - i];                                            
                  	}                                              
                  display_1(Card_No,max_stop_time / 60,max_stop_time % 60,left_momery,MIFARAE_PARK_CARD,block2_buffer[1]);                                             
                  timeOut = 0;
				  while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
				  	{   
					if(key_flag)
						{  
						key_flag = 0; 
						delay(KEYTIMEOUT_1S * QUIT_TIME);
						break;  
						} 
					timeOut++;   
					}
				  display_flag = 0;
				  read_momery_to_Fm(momery_buffer,car);  
				  left_momery= hcl(momery_buffer,4);	
				  
				  return 0;
				  break;	                                  
                  }
//					else if(block2_buffer[1]&&(ret_max_24hour(block2_buffer,MIFARAE_PARK_CARD_new) >= (24 * 60)))//�ϴ�ͣ�� ����24Сʱ
				else if(block2_buffer[1]&&(block2_buffer[0]!=HLEPPARK_CARD))//��δ���� - ���Ȳ���- �ٴ�ˢ������
                  {
				  u8 OVERDRAFT_F =0;
				#ifdef OVERDRAFT 
				  OVERDRAFT_F = 1;
				#endif
				  max_stop_time=0;
				listret=0;
				
		  SYS_LIST.dayupflag =1;
//#ifdef 		WL_MBSYSTEM			
		  u8 cardupflag,WJS_time;
		  cardupflag = block2_buffer[6];
		  WJS_time= block2_buffer[1];
		  if((cardupflag !=0x88)||(WJS_time>1))
		  	{
			listret=1;
			SYS_LIST.dayupflag =77;
			TMP.feemny = WJS_time*RR_ST1.Sale_Base*RR_ST1.Max_Stop_Momery;
			TMP.feetime = WJS_time;
			TMP.unlockmny[0] = 0;
			TMP.unlockmny[1] = 0;			
		  	}
//#endif
				  
				  lockmny = hcl(block2_buffer+7,2)*100;;
				  //���һ��ˢ��ʱ�䵽���ڵ�ʱ�� 2015-07-17
//				  if((ret_max_24hour(block2_buffer,MIFARAE_PARK_CARD_new) >= (RR_ST1.Max_Park_Time* 60))
//				  		||(block2_buffer[1]>=0x06)||(left_momery <lockmny+RR_ST1.Frist_Money*RR_ST1.Sale_Base))
				  u32 parktime_r,feetime_r;
				  parktime_r = ret_max_24hour(block2_buffer,MIFARAE_PARK_CARD_new);//ʵ�ʲ���ʱ��
				  if(listret==1)
				  	feetime_r = parkfeetime_count(block2_buffer+4,time1);//�շѲ���ʱ��
				  else
					feetime_r = RR_ST1.Max_Park_Time* 60;//Ĭ�Ͽ�������2015-12-14
				  if(SYS_LIST.dayupflag ==77)
				  	{
					if((parktime_r>=24*60)||
						(feetime_r >= RR_ST1.Max_Park_Time* 60))
						listret=0;
					else
						listret = -1;
				  	}
				  else if((parktime_r>=24*60)||
				  	(feetime_r >= RR_ST1.Max_Park_Time* 60))
				  	{
					I2C_ReadS_24C(SYS_FEELIST,flag_buffer,1);//Ƿ���������¿��� 1-�� 0-��
					if(flag_buffer[0])
						listret = SelectList_SRAM(carSNR,ListType_MF1FEE,buffer);
					else
						listret = -1;
#ifndef BIG_LIST2000	
					if(listret<0)
						{
						TMP.cardtype = TMP.cardplace;//CardType_MF1RD;
//						read_MIFARE_card(&MIFARE_card_info);
//									memcpy(TMP.cardno+4,MIFARE_card_info->snr,4);
						for(i=0;i<4;i++)
							{
							TMP.cardno[i+4] = MIFARE_card_info.SNR[3-i];
							}
						TMP.car = car;
						Smart_Power_OFF;
						disp_cardfee(0);
						i = Send_CardFeeRecord(1);
						//buffer0-3 ����  4-5Ƿ�ѽ��  6-7δ���������1λ��+���ᱶ����3λ��
						if(i>0)
							{
							disp_cardfee(1);
							delay(KEYTIMEOUT_1S*4);
							return 0;
							}
						if(TMP.feetime==0)
							{
							disp_cardfee(2);
							delay(KEYTIMEOUT_1S*4);
							return 0;
							}		

						listret=0;
						SYS_LIST.dayupflag =77;
						
						}
#endif				

				  	}
				  else
				  	listret = -1;
//				  listret = 1;//������� ʵ�ʹرմ���� 2015-07-20
//                  SYS_LIST.dayupflag =1;//������� ʵ�ʹرմ���� 2015-10-13
				  if((listret>=0)&&SYS_LIST.dayupflag) //����Ƿ�Ѽ�¼ 2015-07-14
					{
					//buffer0-3 ����  4-5Ƿ�ѽ��  6-7δ���������1λ��+���ᱶ����3λ��
					u16 feemny,feetime,feelock,feeorg;
					if(SYS_LIST.dayupflag == 77)
						{
						feemny = TMP.feemny;
						feetime = TMP.feetime;
						feelock = TMP.unlockmny[0]<<8;
						feelock += TMP.unlockmny[1];
						}
					else
						{
						feemny = hcl(buffer+4,2);
						feetime = (buffer[6]&0xf0)>>4;
						feelock = (buffer[6]&0x0f)<<8;
						feelock += buffer[7];
						}
					
					if(feetime)//����δ����     ���㷽ʽ��ȷ��
						{	
						if(feetime>=block2_buffer[1]) //δ���㴦��
							block2_buffer[1] = 0;
						else
							block2_buffer[1] -= feetime;
						feeorg = hcl(block2_buffer+7,2);
						if((feelock>=feeorg)||(block2_buffer[1]==0))//�����
							{
							block2_buffer[7] = 0x00;
							block2_buffer[8] = 0x00;
							feeorg = 0;
							}
						else
							{
							feeorg -= feelock;
							fll(feeorg,block2_buffer+7,2);
							}
						
						if((left_momery < feemny)&&(!OVERDRAFT_F))
							{
							card_free_count = 0x00;
							for(i=0;i<4;i++)
								momery_buffer[i] = left_momery_buffer[3 - i];  
							momery = left_momery;
							}
						else
							{
							card_free_count = 0x00;
							fll(feemny,momery_buffer,4);
							momery = feemny;
							}
											
						if(!bukanmny[car])
							bukanmny[car] = left_momery;
						else//�жϿ����Ƿ���ͬ?	
							{
							if((bkno[0]!=carSNR[0])||
							   (bkno[1]!=carSNR[1])||
							   (bkno[2]!=carSNR[2])||
							   (bkno[3]!=carSNR[3]))
							   bukanmny[car] = left_momery;
							}
						
						TMP.cktime = block2_buffer[1]+1;
						TMP.ckmny = feeorg+RR_ST1.Max_Stop_Momery;		
						lockmny = feeorg;
						u8 errtime =4;						
						if(SYS_LIST.dayupflag != 77)
							 errtime =1;
				while(errtime--)	
					{
					if(SYS_LIST.dayupflag == 77)
						{
						lcd_clear();//���� ��ʾ ��ˢ��	
						Smart_Power_ON;
						delay(KEYTIMEOUT_1S/10);//������ʱ ��Ϊ�� �������� �ϵ�
						display_please_operation(time1[4],time1[3],time1[2],time1[1],time1[0],77);	   
						//TMP.feetime: TMP.feemny
						key_flag = 0;
						i = 4;
						CardInfo YWCardInfo;
						u8 card_class_flag;
						u32 timeOut;
						uchar MIFARE_password_buffer[6];
						
						timeOut = 0;   
						while(i--)
							{
							while(timeOut < 300)
								{
								card_class_flag = inquire_card(&YWCardInfo);//��� ��������
									
								if((card_class_flag==CardType_MF1)||
									(card_class_flag==CardType_BIKE)||
									(card_class_flag==CardType_CPC))
									{
									break;
									}										
								if(key_flag != NO)
									{
									key_flag = 0;
									break;
									}										
								timeOut++;	
								}
							if(card_class_flag!=CardType_MF1)
								{
								timeOut = 0;
								if(i>1)continue;
								disp_cardfee(3);
								delay(KEYTIMEOUT_1S*4);
								return 1;
								}
							read_MIFARE_card(&MIFARE_card_info);  //��ȡmifare������Ϣ			  
							MF1key_main(MIFARE_card_info.SNR,MIFARE_password_buffer);	  //��ȡMIFARE������Կ
							//�ж��Ƿ���ͬһ�ſ����� 2016-05-03
							if((TMP.cardno[4]!=MIFARE_card_info.SNR[3])||
								(TMP.cardno[5]!=MIFARE_card_info.SNR[2])||
								(TMP.cardno[6]!=MIFARE_card_info.SNR[1])||
								(TMP.cardno[7]!=MIFARE_card_info.SNR[0]))
								{
								if(i>1)
									{
//									print_XYstr_16_16(4,4,"ps Rp");
//									print_XYstr_16_16(4,4,"ps Rp");
									continue;
									}
								disp_cardfee(3);
								delay(KEYTIMEOUT_1S*4);
								return 1;								
								}
							error_value_0 = testkey_comd(0x02,0x0a,MIFARE_password_buffer);
							if(error_value_0==OK)
								{
								u8 buff[16];
								error_value_2 = read_comd(BLOCK2_ADDR,buff);
								error_value_0 = read_comd(BLOCK0_ADDR,left_momery_buffer);			 
								if((error_value_0==OK)&&(error_value_2==OK)&&
									(buff[0]==MIFARAE_PARK_CARD))
									{
									left_momery = left_momery_buffer[0] + left_momery_buffer[1] * 0x100 + left_momery_buffer[2] * 0x10000 + left_momery_buffer[3] * 0x1000000;											   
									break;
									}
								timeOut = 0;
								if(i>1)continue;
								disp_cardfee(3);
								delay(KEYTIMEOUT_1S*4);
								return 1;								
								}
							}
						if(error_value_0!=OK)
							{
							disp_cardfee(3);
							delay(KEYTIMEOUT_1S*4);
							return 1;								
							}
						}
						i = OK;
						if(bukanmny[car] == left_momery)
							i = value_comd(0x2d,8,momery);
						if(i == OK)//�ۿ�ɹ�
							{
							//�ص�����ģ��ĵ�Դ Ϊ��ʡ�� 
							//2. д��������Ϊ����1�Σ�д�뵱ǰ���ڣ���ȥ����λ�����
							if(block2_buffer[0]==HLEPPARK_CARD)
								block2_buffer[0] = HLEPPARK_CARD;
							else
								block2_buffer[0] = 0x60;
							
//								block2_buffer[1] = 0x00;//������־
							i =2;
//								block2_buffer[i++] = time[4];											
							block2_buffer[i++] = time[3];										   
							block2_buffer[i++] = time[2];										   
							block2_buffer[i++] = time[1];										   
							block2_buffer[i++] = time[0]; 
							block2_buffer[i++] = 0x88;//time[4];  
//								block2_buffer[7] = 0x00;
//								block2_buffer[8] = 0x00;

							//�Զ���������  2015-09-09
//							lockmny = hcl(block2_buffer+7,2)*100;
//							lockmny = TMP.ckmny-RR_ST1.Max_Stop_Momery;feeorg
							if(left_momery-momery >TMP.ckmny*100)
								{
								if(block2_buffer[1]==0)
									{
									max_stop_time = momery_to_time(left_momery-momery);//���ͣ��ʱ��
//									if(max_stop_time==0)
//										{
//										block2_buffer[1] =0;
//										lockmny = 0;
//										fll(lockmny,block2_buffer+7,2);
//										}
									}
								else			
									{
									max_stop_time = 0;
									if(left_momery>lockmny*100)
										max_stop_time = momery_to_time(left_momery-lockmny*100);//���ͣ��ʱ��
									}
								}
							else
								max_stop_time = momery_to_time((left_momery-momery)%(RR_ST1.Max_Stop_Momery*100));
							
							if(max_stop_time > 0)
								{
								lockmny = TMP.ckmny;
//								lockmny += RR_ST1.Max_Stop_Momery;
								fll(lockmny,block2_buffer+7,2);
//								block2_buffer[1]++;
								block2_buffer[1] = TMP.cktime;
								}
							//�Զ���������  2015-09-09

//							block2_buffer[9] = 0x00;
//							block2_buffer[10] = 0x00;
							block2_buffer[11] = card_free_count;
//							block2_buffer[12] = 0x00;
							block2_buffer[13] = 0x00;
							block2_buffer[14] = 0x00;
							block2_buffer[15] = 0x00; 
							writetime = write_comd(BLOCK2_ADDR,block2_buffer);
							if(writetime == OK)
								{
								left_momery = bukanmny[car];									
								bukanmny[car] = 0;
								OPEN_EXTI9_5_IRQ();
								OPEN_EXTI15_10_IRQ();
								Buzz_0;
								delay(KEYTIMEOUT_1S/20);
								Buzz_1;		
								Smart_Power_OFF;
								//2. ����д�� ��ǰͣ��ʱ��
								//3. ��ʾ������ ������� ����ͣ�� ��ͣʱ��
//								replay_momery(momery,left_momery - momery,1);
//								delay(KEYTIMEOUT_1S * 6);
								//4. �油���¼
								block1_buffer[0] = 0xEE;//��¼ͷ
								block1_buffer[1] = 0x00; //��������
								block1_buffer[2] = feetime;
								fll(feelock,block1_buffer+3,2);
//									block1_buffer[3] = 0x00;
//									block1_buffer[4] = 0x00;
								block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
								block1_buffer[6] = MIFARE_card_info.SNR[2];
								block1_buffer[7] = MIFARE_card_info.SNR[1];
								block1_buffer[8] = MIFARE_card_info.SNR[0];
								for(i=0;i<5;i++)
									block1_buffer[9+i] = time[4-i];//������ʱ��
								block1_buffer[14] = left_momery>>16;//left_momery_buffer[2];
								block1_buffer[15] = left_momery>>8;//left_momery_buffer[1];
								block1_buffer[16] = left_momery>>0;//left_momery_buffer[0];
								block1_buffer[17] = momery_buffer[2];
								block1_buffer[18] = momery_buffer[3];
								memcpy(TMP.bmny,block1_buffer+14,3);
								memcpy(TMP.fmny,momery_buffer+2,2);
								block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x07;//������δ���� ��λΪcar
								bushimny[car] = 0;	 
								bukanmny[car] = 0;	
								TMP.CPC_ckmny[car] = 0;
								for(i=0;i<5;i++)
									block1_buffer[20+i] = time[4-i];//������ʱ��
								block1_buffer[25] = CardType_MF1;//����ͨ��¼��־
								for(i=26;i<32;i++)								 
									block1_buffer[i] = 0xAA;
								Save_Record(block1_buffer,32);								
								save_RPTMNY_record(CardType_MF1,momery);//2015-12-07
								WriteRecord(car,RECORD_NULL);
								for(i=0;i<16;i++)
									buffer[i] = 0;
								write_car_reference_of_use_info(car,buffer,16);
								TMP.autofee = 1;//2015-09-09 ��ʶ�Զ������ �Զ��볡
								TMP.feemnybak = momery;
								left_momery -= momery;
								left_momery_buffer[3] = left_momery>>24;
								left_momery_buffer[2] = left_momery>>16;
								left_momery_buffer[1] = left_momery>>8;
								left_momery_buffer[0] = left_momery>>0;
//								block2_buffer[1] = 1;
//								replay_momery(TMP.feemnybak,left_momery,1);
//								delay(KEYTIMEOUT_1S * 6);
//								return 0;								
								err_1[car] = 0;
								HR_TIME[car] = 0;
								break;
								}
							else//д�����ɹ�
								{
								//��ʾ д������ ������ˢ��
								Smart_Power_OFF;
								OPEN_EXTI9_5_IRQ();
								OPEN_EXTI15_10_IRQ();
								if(errtime==1)
									{
									//���ݴ�����
									//д�����ɹ� �������
									flag_buffer[0] = 0x01;														  
									I2C_WriteS_24C(car1_write_comd + (car - 1) ,flag_buffer,1);
									//4. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ��������ͣ��ʱ�䣩
									block1_buffer[0] = 0x00; //��λ״̬
									block1_buffer[1] = TMP.cktime;
									block1_buffer[2] = 0x00; //��������
									block1_buffer[3] = 0x00; //��������
									block1_buffer[4] = 0x00; //��������
									block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
									block1_buffer[6] = MIFARE_card_info.SNR[2];
									block1_buffer[7] = MIFARE_card_info.SNR[1];
									block1_buffer[8] = MIFARE_card_info.SNR[0];
									block1_buffer[9] = time[3]; //��
									block1_buffer[10] = time[2]; //��
									block1_buffer[11] = time[1]; //ʱ
									block1_buffer[12] = time[0]; //��
									block1_buffer[13] = time[4]; //�� Ԥ��
									block1_buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ
									block1_buffer[15] = max_stop_time % 60; 	 
									if(!err_1[car])
										{	
										HR_TIME[car] = TMP.cktime-1;
										err_1[car] =1;
										write_car_reference_of_use_info(car,block1_buffer,9);
										}
									if(SYS_LIST.dayupflag != 77)
										{
										QuitFlag = 1;
										display_flag = 2;
										continue;
										}
									TMP.ckflag[car] = 1;
//									memcpy(TMP.bmny,left_momery_buffer,3);
//									memcpy(TMP.fmny,momery_buffer+2,2);
									left_momery = bukanmny[car];		
									memcpy(bkno,carSNR,4);
									block1_buffer[16] = left_momery>>16;//left_momery_buffer[2];
									block1_buffer[15] = left_momery>>8;//left_momery_buffer[1];
									block1_buffer[14] = left_momery>>0;//left_momery_buffer[0];
									block1_buffer[17] = momery_buffer[2];
									block1_buffer[18] = momery_buffer[3];
									memcpy(TMP.bmny,block1_buffer+14,3);
									memcpy(TMP.fmny,momery_buffer+2,2);									
									write_card_error(0);
									delay(KEYTIMEOUT_1S * 3);
									return 0;
									}
								continue;
								//����ۿ�ɹ��ˣ������������۵Ŀ� ���д���
								} 	
							}
						else//�ۿ�ɹ�
							{							
							TMP.ckflag[car] = 1;
							memcpy(TMP.bmny,left_momery_buffer,3);
							memcpy(TMP.fmny,momery_buffer+2,2);
							//��ʾ д������ ������ˢ��
							Smart_Power_OFF;			
							OPEN_EXTI9_5_IRQ();
							OPEN_EXTI15_10_IRQ();	
							if(SYS_LIST.dayupflag != 77)
								{
								QuitFlag = 1;
								display_flag = 2;
								continue;
								}
							if(errtime==1)
								{
                                write_card_error(0);
                                delay(KEYTIMEOUT_1S * 3);
                                return 0;
								}
							continue;
							}
						}
					}
				} 
//				  else if(block2_buffer[1]>=0x06)
				  else if(block2_buffer[1]>=0x01)
				  	{
					//������Ƿ������---�жϺ�̨�Ƿ����Ƿ������ 2015-07-15
					//���һ��ˢ��ʱ���Ƿ��Ѵ�Ƿ�������ĸ���ʱ��

					Smart_Power_OFF;
					display_max_park_count();
					timeOut = 0;
					while(timeOut < KEYTIMEOUT_1S * 2.2)
						{
						/* ι��*/
						IWDG_ReloadCounter();//2015-12-23 andyluo
						if(key_flag)
							{
							key_flag = 0;
							delay(KEYTIMEOUT_1S * QUIT_TIME);
							break;
							}
						timeOut++;
						}
					return 0;
					}                                 	                                
                  }	    
				else
					max_stop_time = 0;
              }
			TMP.ckflag[car] = 0;
			error_flag = 0; 					
            //д ����ˢ 15�����ڵı�־ ��Ϊ�ϴ�ͣ������Ǯ �����´�ͣ�� 15�����ڲ���Ǯ ��Ȼ����һ��
            I2C_ReadS_24C((car1_useing + (car - 1)),flag_buffer,1);
            ReadCar_15_Info(car,buffer);
			if(ret_max_24hour(buffer + 9,SELECT) >= 60)
				{
				//�����λ����Ϣ ʹ����ˢ15���Ӻ� �ȽϿ��Ų�ͬ
				for(i=0;i<16;i++)
					buffer[i] = 0;
				write_car_15_reference(car,buffer,16);
				}
			else
				{
				if(flag_buffer[0] == 0x00)//��һ��ͣ�� ����Ǯ ���Խ��µ�15������ ���ÿ�Ǯ
					{
					//�����λ����Ϣ ʹ����ˢ15������ �ȽϿ��Ų�ͬ
					for(i=0;i<16;i++)
						buffer[i] = 0;
					write_car_15_reference(car,buffer,16);
					}
				}
			//��ʼ ���� ����  
			// 1. �ݴ濨��� ��ʹ��״̬����    
			//write_momery_to_Fm(momery_buffer,car);         
			// 2. ���ݿ��� ������� �������ͣ��ʱ��  				
			for(i=0;i<4;i++)
				momery_buffer[i] = left_momery_buffer[3 - i];  
			
			
			lockmny = hcl(block2_buffer+7,2)*100;//���ᱶ��--���
			if(TMP.autofee==1)//2015-09-09
				{
				//if(lockmny>=RR_ST1.Max_Stop_Momery*100)//������������0���ж� 2015-10-12
					//lockmny -= RR_ST1.Max_Stop_Momery*100;
				if(max_stop_time==0)lockmny=left_momery+1;
				else lockmny=0;    
				}
			if(left_momery >lockmny)
				{
				if(max_stop_time==0)
					max_stop_time = momery_to_time(left_momery-lockmny);//���ͣ��ʱ��
                }
			else
				if((block2_buffer[1]>=1)&&(block2_buffer[0]!=HLEPPARK_CARD))
					{
					if(TMP.autofee==1)
						{
						replay_momery(TMP.feemnybak,left_momery,1);
						delay(KEYTIMEOUT_1S * 4);
						}
					max_stop_time = 0;
					Smart_Power_OFF;
					display_max_park_count();
					timeOut = 0;
					while(timeOut < KEYTIMEOUT_1S * 2.2)
						{
						if(key_flag)
							{
							key_flag = 0;
							break;
							}
						timeOut++;
						}
					return 0;
					}
				else
					max_stop_time = momery_to_time(left_momery);//���ͣ��ʱ��
			if(max_stop_time > 0)
				{ 
				// 3. д����ʹ�ñ�־��д�뵱ǰ���ڣ���λ�����                                              
				if(block2_buffer[0]==HLEPPARK_CARD)
					block2_buffer[0] = HLEPPARK_CARD;
				else
					block2_buffer[0] = 0x60;
				//block2_buffer[1] = 0x01;//������־  
				block2_buffer[1] ++;//������־   
				if(err_1[car]) block2_buffer[1]= HR_TIME[car]+1;
				i =2;
//					block2_buffer[i++] = time[4];
				block2_buffer[i++] = time[3];	
				block2_buffer[i++] = time[2];
				block2_buffer[i++] = time[1];
				block2_buffer[i++] = time[0];  
				block2_buffer[i++] = 0x88;//time[4]; 
//				lockmny = hcl(block2_buffer+7,2)+RR_ST1.Max_Stop_Momery;
				lockmny = RR_ST1.Max_Stop_Momery;//ȡ�����Ͳ������� 2015-12-04
				fll(lockmny,block2_buffer+7,2);
//				block2_buffer[9] = 0x00;
//				block2_buffer[10] = 0x00;
				block2_buffer[11] = card_free_count;
//				block2_buffer[12] = 0x00;
				block2_buffer[13] = 0x00;
				block2_buffer[14] = 0x00;
				block2_buffer[15] = 0xAA; 
				if(TMP.autofee==1)
					flag = OK;
				else
					flag = write_comd(BLOCK2_ADDR,block2_buffer);
					
				if(flag == OK)
					{
					HR_TIME[car] = 0;
					err_1[car]=0;
					//��Ǯʱ  ȫ�� ��Ϊ 0Ԫ�� �����
					WriteRecover(car,0);
					Smart_Power_OFF;
					//4. ��λ����  
					light(car,OK);  
					//���� �ε�  
					OPEN_EXTI9_5_IRQ(); 
					OPEN_EXTI15_10_IRQ();
					light(car,OK);
					addmny[car] = NO;
					vetime = 0;
					HR_TIME[car] = 0;
					err_1[car]=0;
					Buzz_0;     
					delay(KEYTIMEOUT_1S/10); 
					Buzz_1; 
					if(campare_card_NO(car,MIFARE_card_info.SNR,MIFARE_CARD,2)) 
						{ 
						flag_buffer[0] = 0x01;
						} 
					else   
						{
						flag_buffer[0] = 0x00;
						}
					I2C_WriteS_24C((car1_no_S_flag + (car - 1) * 0x04) + 1,flag_buffer,1);
					//д���ɹ� ��ȷ����
					flag_buffer[0] = 0x00;   
					I2C_WriteS_24C(car1_write_comd + (car - 1) ,flag_buffer,1);
                    //4. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ��������ͣ��ʱ�䣩
                    block1_buffer[0] = 0x66; //��λ״̬
                    block1_buffer[1] = 0x00;
					block1_buffer[2] = 0x00; //��������
					block1_buffer[3] = 0x00; //��������
					block1_buffer[4] = 0x00; //��������
					block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
					block1_buffer[6] = MIFARE_card_info.SNR[2];
					block1_buffer[7] = MIFARE_card_info.SNR[1];
					block1_buffer[8] = MIFARE_card_info.SNR[0];
					block1_buffer[9] = time[3]; //��
					block1_buffer[10] = time[2]; //��
					block1_buffer[11] = time[1]; //ʱ
					block1_buffer[12] = time[0]; //��
					block1_buffer[13] = time[4]; //�� Ԥ��
					block1_buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ
					block1_buffer[15] = max_stop_time % 60;          
					memcpy(block1_buffer+16,momery_buffer,4);
					write_car_reference_of_use_info(car,block1_buffer,16);
					read_car_reference_of_use_info(&CS_RF_US,car);//����λ״̬��Ϣ  
					//1. �汾��λ����//�Ѿ�д��
					//2. ��ͣ����¼
					block1_buffer[0] = 0xEE;//��¼ͷ      
					block1_buffer[1] = 0x00; //��������      
					block1_buffer[2] = 0x00;    
					block1_buffer[3] = 0x00;   
					block1_buffer[4] = 0x00;      
					block1_buffer[5] = MIFARE_card_info.SNR[3]; 
					block1_buffer[6] = MIFARE_card_info.SNR[2];   
					block1_buffer[7] = MIFARE_card_info.SNR[1];   
					block1_buffer[8] = MIFARE_card_info.SNR[0];   
					for(i=0;i<5;i++)
						block1_buffer[9+i] = time[4-i];//������ʱ��
					block1_buffer[14] = momery_buffer[1];  
					block1_buffer[15] = momery_buffer[2];  
					block1_buffer[16] = momery_buffer[3];   
					block1_buffer[17] = 0x00;
					block1_buffer[18] = 0x00; 
					block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x01;//��һ��ͣ�� ��λΪcar                                              
					bushimny[car] = 0;	 
					bukanmny[car] = 0;	
					TMP.CPC_ckmny[car] = 0;
					for(i=0;i<5;i++)
						block1_buffer[20+i] = time[4-i];//������ʱ��
					block1_buffer[25] = CardType_MF1;//����ͨ��¼��־
                    for(i=26;i<32;i++)   
						block1_buffer[i] = 0xAA;
					Save_Record(block1_buffer,32);
					WriteRecord(car,TMP.cardplace);
					Deal_SwipCardIMG(car-1,1);
					TMP.ckflag[car] = 0;
					if(TMP.autofee==1)
						{
						replay_momery(TMP.feemnybak,left_momery,1);
						delay(KEYTIMEOUT_1S * 4);
						block2_buffer[1]--;
						}
					
					//3. ��ʾ  ����  ������� ��ͣ��ʱ��
					lcd_clear();
					for(i=0;i<4;i++) 
						{  
						Card_No[i] = MIFARE_card_info.SNR[3 - i];                                            
                        }    
					display_1(Card_No,max_stop_time / 60,max_stop_time % 60,left_momery,MIFARAE_PARK_CARD,block2_buffer[1]);
					timeOut = 0;
					while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
						{   
						if(key_flag)
							{ 
							key_flag = 0; 
							delay(KEYTIMEOUT_1S * QUIT_TIME);
							break;   
							}  
						timeOut++;   
						}
					fll(left_momery,momery_buffer,4);
					write_momery_to_Fm(momery_buffer,car);
					read_momery_to_Fm(momery_buffer,car);  
					left_momery= hcl(momery_buffer,4);	  
					display_flag = 0;
					return 0;
					}
				else//д�� ���ɹ�
					{
					//���ݴ�����
					//д�����ɹ� �������
					flag_buffer[0] = 0x01;                                                        
                    I2C_WriteS_24C(car1_write_comd + (car - 1) ,flag_buffer,1);
                    //4. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ��������ͣ��ʱ�䣩
                    block1_buffer[0] = 0x00; //��λ״̬
                    block1_buffer[1] = Now_time;
					block1_buffer[2] = 0x00; //��������
					block1_buffer[3] = 0x00; //��������
					block1_buffer[4] = 0x00; //��������
                    block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������
                    block1_buffer[6] = MIFARE_card_info.SNR[2];
                    block1_buffer[7] = MIFARE_card_info.SNR[1];
                    block1_buffer[8] = MIFARE_card_info.SNR[0];
                    block1_buffer[9] = time[3]; //��
                    block1_buffer[10] = time[2]; //��
                    block1_buffer[11] = time[1]; //ʱ
                    block1_buffer[12] = time[0]; //��
                    block1_buffer[13] = time[4]; //�� Ԥ��
                    block1_buffer[14] = max_stop_time / 60; //����ͣ��ʱ�� 24Сʱ
                    block1_buffer[15] = max_stop_time % 60;      
					if(!err_1[car])
						{	
						HR_TIME[car] = Now_time;
						err_1[car] =1;
						write_car_reference_of_use_info(car,block1_buffer,9);
						}
					//��ʾ д������ ������ˢ��
					Smart_Power_OFF;
					OPEN_EXTI9_5_IRQ();
					OPEN_EXTI15_10_IRQ();
				#ifdef DEBUG          
					//�鿴DEBUG��Ϣ
					display_debug_infornation(RxBuffer,RxCounter);
					delay(KEYTIMEOUT_1S * 2);
				#endif  
					QuitFlag = 1;
					display_flag = 2;
					} 
				}   
			else//��ʾ ��ͣ��ʱ�� Ϊ 0
				{
				if(TMP.autofee==1)
					{
					replay_momery(TMP.feemnybak,left_momery,1);
					delay(KEYTIMEOUT_1S * 4);
						}
				//��ʾ�Ѵ��������� 2015-05-21	
				//��ʾ ���㣬���ֵ
				Smart_Power_OFF;//�ص�����ģ��ĵ�Դ 
				OPEN_EXTI9_5_IRQ();          
				OPEN_EXTI15_10_IRQ();
				if(block2_buffer[1]==0)
					no_momery(left_momery);
				else
					display_max_park_count();
				timeOut = 0;
				while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
					{ 
					if(key_flag)
						{    
						key_flag = 0; 
						delay(KEYTIMEOUT_1S * QUIT_TIME);
                        break; 
						}  
					timeOut++;   
					}
				return 0;
				}  
				break;
				}
			case OLDMANAGE_CARD:
				{
				Buzz_0;     
				delay(KEYTIMEOUT_1S/10); 
				Buzz_1; 
				Smart_Power_OFF;
				lcd_clear();									
				dispaly(2,4,(HZ + qing));
//				dispaly(2,4,(HZ + shi_1));
				dispaly(2,5,(HZ + yong));
				dispaly(3,3,(HZ + xin));
//				dispaly(3,3,(HZ + fa));
				dispaly(3,4,(HZ + guan));
				dispaly(3,5,(HZ + li));
				dispaly(3,6,(HZ + ka));
				delay(KEYTIMEOUT_1S*2);
				OPEN_EXTI9_5_IRQ();
				OPEN_EXTI15_10_IRQ();
				return 0;
				}
            case MANAGE_CARD:
				if(TMP.cardplace == CardType_ZGMF1RD)//�����
					{
					#ifndef ZG_MBSYSTEM
					disp_notsuse_card();
					return 0;
					#endif
					}
				else//���뿨
					{
					#ifdef ZG_MBSYSTEM
					disp_notsuse_card();
					return 0;
					#endif
					}
				
              if(validity(block2_buffer,MANAGE_CARD) == OK)//����������Ч���� ���
				  {
                      Smart_Power_OFF;
                      OPEN_EXTI9_5_IRQ();
                      OPEN_EXTI15_10_IRQ();
                      uchar BCC = 0x00;
                      for(i=0;i<16;i++)
					  	{
//						block2_buffer[i] = block2_buffer[i + 1];
						BCC = BCC ^ block2_buffer[i];
						}
                      for(;i<25;i++)
					  	{
						block2_buffer[i] = block1_buffer[i-16];
						BCC = BCC ^ block2_buffer[i];
						}
					  block2_buffer[25] = BCC;
                      
                      I2C_WriteS_24C(B_startTime_unit_of_hour,block2_buffer,26);
                      I2C_WriteS_24C(back_argument_of_charge,block2_buffer,26);
                      
                      
                      manageCARD_update(); //��ʾ �����������
                      delay(KEYTIMEOUT_1S * 2);
                  }
              else
              {
                  car_outdate();
                  delay(KEYTIMEOUT_1S * 2);
              }
              return 0;        
              break;
            case RECORD_CARD:
              if(validity(block2_buffer,RECORD_CARD) == OK)//���ܿ�����Ч���� ���
              {
                  OPEN_EXTI9_5_IRQ();
                  OPEN_EXTI15_10_IRQ();
                      RecordSendDown();
              }
              else
              {
                  car_outdate();
                  delay(KEYTIMEOUT_1S * 2);
              }
			  return 0;
              break;
            case ENCRYPT_CARD:
              if(validity(block2_buffer,ENCRYPT_CARD) == OK)//���ܿ�����Ч���� ���
              {
                  OPEN_EXTI9_5_IRQ();
                  OPEN_EXTI15_10_IRQ();
                 // I2C_WriteS_24C(sysytem_public_key,block1_buffer,6);
                  KEYCard_Process();
                  encryptCARD_update(); //��ʾ ϵͳ��Կ�������
                  delay(KEYTIMEOUT_1S * 2);
              }
              else
              {
                  car_outdate();
                  delay(KEYTIMEOUT_1S * 2);
              }
			  return 0;
              break;
            case CLEAR_CARD:
              if(validity(block2_buffer,CLEAR_CARD) == OK)
              {
                  OPEN_EXTI9_5_IRQ();
                  OPEN_EXTI15_10_IRQ();
                  Smart_Power_OFF;
                  ChipHalInit();	
                  //��ʾ ���������...
                  data_clearing();
                  
                  //delay(KEYTIMEOUT_1S / 2);
                  
                  clear_FM_FLASH_reference();
                  //��ʾ ��¼����ɹ�
                  display_clear_success();
                  delay(KEYTIMEOUT_1S * 2);
              }
              else
              {
                  car_outdate();
                  delay(KEYTIMEOUT_1S * 2);
              }
              return 0;
              break;
			case  NETCTRL_CARD://�������ÿ�
				Smart_Power_OFF;  							
				I2C_WriteS_24C(LISTNET_ADD,block2_buffer,16);
//				lcd_clear();
//				print_XYstr_16_16(2,1,"Net set OK!");
				lcd_clear();		
#ifdef IN_MBSYSTEM //����24  �����ӵ���ʾ 2016-02-22
				print_XYstr_16_16(1,5,"Success");
#elif defined EN_MBSYSTEM
																		
#else
				dispaly(1,3,(HZ + cheng));
				dispaly(1,4,(HZ + gong_1));
#endif				
				//99 04 06 10 02 28 04 04 04 24
				I2C_ReadS_24C(LISTNET_ADD,buffer,16);//0-��־99 1- 2- 3-���ͼ��Ƶ�� 4- 5-Υ��ʱ��
				print_XYstr_16_16(3,5,"NET-P");
				goto_xy(0xA4,1);
				for(i=0;i<10;i++)
					print_num2(buffer[i]);	
				delay(KEYTIMEOUT_1S*3);
				OPEN_EXTI9_5_IRQ(); 									  
				OPEN_EXTI15_10_IRQ();
				return 0;
				break;
				
		    case  MBNOSET_CARD://��������ÿ�
		    case  TIMESET_CARD://ʱ�����ÿ�
				UpRecordFlag = PART_FH_UP;
			case  PDA_CARD_FHP://            0xaa  //PDAͨ�ſ�flah��������
			case  PDA_CARD_FHA://            0xab  //PDAͨ�ſ�flashȫ����
			case  PDA_CARD_FMP://            0xac  //PDAͨ�ſ����粿������
			case  PDA_CARD_FMA://            0xad  //PDAͨ�ſ�����ȫ����
            //case PDA_CARD:
//				if(validity(block2_buffer,PDA_CARD) == OK)//ͨ�ſ�����Ч���� ���
                              i=1;
			if(i)//ͨ�ſ�����Ч���� ���
              {
                  OPEN_EXTI9_5_IRQ();	                                    
                  OPEN_EXTI15_10_IRQ();
                  Smart_Power_OFF;	
				  
				  if(block2_buffer[0]==PDA_CARD_FHP)
					  UpRecordFlag = PART_FH_UP;
				  else if(block2_buffer[0]==PDA_CARD_FHA)
					  UpRecordFlag = ALL_FH_UP;
				  else if(block2_buffer[0]==PDA_CARD_FMP)
					  UpRecordFlag = PART_FM_UP;
				  else if(block2_buffer[0]==PDA_CARD_FMA)
					  UpRecordFlag = ALL_FM_UP;
				  
				  UART4_IRQn_CTL(OFF);
				  TMP.COM4 = 2;
				  ir_comm(OFF);
				  close_ir_comm();
				  if(Judge_MB_MODE()==0)//�м������2G4��Դ 2015-04-30 andyluo
					  {
					  open_ir_comm();
					  UART4_IRQn_CTL(ON);//�򿪳����������ж� 2015-04-29
					  Set_G24_BaseM();//����2.4Gģ����Ҫ���յĳ�������
					  }
              }
              else
              {
                  car_outdate();
                  delay(KEYTIMEOUT_1S * 2);
              }
              return 0;
              break;
              
            case SELECT_CARD:
              if(validity(block2_buffer,SELECT_CARD) == OK)//��ѯ������Ч���� ���
              {
                  Check_System_Status();                          
              }
              else
              {
                  car_outdate();
                  delay(KEYTIMEOUT_1S * 2);
              }
			  return 0;
              break;
//		  case	MBNOSET_CARD://��������ÿ�
//		  case	TIMESET_CARD://ʱ�����ÿ�
		  case MOVE_CARD:
		  case TEST_CARD:
				Smart_Power_OFF;
				//EF 01 EF 11 EF 14 EF
				if((block2_buffer[1]==0x01)&&
					(block2_buffer[2]==0xEF)&&
					(block2_buffer[3]==0x11)&&
					(block2_buffer[4]==0xEF)&&
					(block2_buffer[5]==0x14)&&
					(block2_buffer[6]==0xEF))
					{
					OPEN_EXTI9_5_IRQ();
					OPEN_EXTI15_10_IRQ();
					beep(1);
					beep(1);
					if(car==2)
						SysIQ_MENU();
					else
						Check_System_Status(); 
//					lcd_clear();
//					print_XYstr_16_16(2,4,"Pls choose");
//					print_XYstr_16_16(4,1,"U-base");
//					print_XYstr_16_16(4,9,"U-meter");
//					key_flag= 0;
//					timeOut = KEYTIMEOUT_1S *4; 		
//					while(timeOut--)
//						{ 
//						if(key_flag)
//							break;
//						}	
//		
//					switch(key_flag)
//						{
//						case 2:
//							lcd_clear();
//							print_XYstr_16_16(1,1,"Linking...");
//							print_XYstr_16_16(3,1,"Pls wait...");
//							i = Sync_MtoB_Info(G24_Mode_BE,NULL,NULL);
//							if(i==0)
//								print_XYstr_16_16(2,1,"Link ok");
//							else
//								print_XYstr_16_16(2,1,"Link ng");
//							delay(KEYTIMEOUT_1S * 3);
//							break;
//						case 3:
//							update_IAP_program();
//							break;
//						default:
//							update_IAP_program();
//							break;
//						}
//					Car_IMGIQ();
					}
				return 0;
				break;
            case SELECT_RECORD_CARD:
              if(validity(block2_buffer,SELECT_RECORD_CARD) == OK)//��ѯ������Ч���� ���
              {
                      Smart_Power_OFF;
                      //��ʾ ��¼��ѯ �� ��ʾ
                      #ifdef TWO_CAR
                        displaySelectRecordAndInfo(2);
                      #else
                        displaySelectRecordAndInfo(4);
                      #endif
                      
                      OPEN_EXTI9_5_IRQ();                                                                                  
                      OPEN_EXTI15_10_IRQ();
                      
                      timeOut = 0;  
                      key_flag = 0x00;
                      while(timeOut < KEYTIMEOUT_1S * 3)                                         	                                    
                      {                                            
                                                
                         if(key_flag){                                            	                                        
                            delay(KEYTIMEOUT_1S * QUIT_TIME);                                        	                                        
                            break;                                             	                                     
                         }                                            	                                      
                         timeOut++;                                         	                                    
                      }
                          
                      if(key_flag != 0)
                      {
                          if(block2_buffer[1] >= 30)
                              block2_buffer[1] = 30;
                              
                           SelectRecordToPrint1(block2_buffer[1]); 
                      }                          
              }
              else
              {
                  car_outdate();
                  delay(KEYTIMEOUT_1S * 2);
              }
			  return 0;
              break;
            case IP_ADREES:
              if(validity(block2_buffer,IP_ADREES) == OK)//��ѯ������Ч���� ���
             	 {
#ifndef IN_MBSYSTEM
				 I2C_WriteS_24C(APNuser_possword,left_momery_buffer,16);//��APN
				 I2C_WriteS_24C(APNuser_possword+16,block1_buffer,16);//��APN
#else
				 I2C_WriteS_24C(APNuser_possword,block2_buffer+7,6);//��IP��
				 I2C_WriteS_24C(APNuser_possword+6,left_momery_buffer,16);//��APN
				 I2C_WriteS_24C(APNuser_possword+22,block1_buffer,16);//��APN
#endif
				 I2C_WriteS_24C(IPADrees,block2_buffer+1,6);//��IP��
//				 I2C_WriteS_24C(IPADrees,left_momery_buffer,6);//��IP��
				 u8 ip_buffer[10];
				 memcpy(ip_buffer,block2_buffer+1,6);
                 ip_setup(1);// IP���سɹ�       
				 LCD_display_symbol(3,1,ip_buffer[0] / 100,0);
				 LCD_display_symbol(3,2,ip_buffer[0] / 10 % 10,0);
				 LCD_display_symbol(3,3,ip_buffer[0] % 10,0);				 
				 LCD_display_symbol(3,4,5,1);				 
				 LCD_display_symbol(3,5,ip_buffer[1] / 100,0);
				 LCD_display_symbol(3,6,ip_buffer[1] / 10 % 10,0);
				 LCD_display_symbol(3,7,ip_buffer[1] % 10,0);				 
				 LCD_display_symbol(3,8,5,1);				 
				 LCD_display_symbol(3,9,ip_buffer[2] / 100,0);
				 LCD_display_symbol(3,10,ip_buffer[2] / 10 % 10,0);
				 LCD_display_symbol(3,11,ip_buffer[2] % 10,0);				 
				 LCD_display_symbol(3,12,5,1);				 
				 LCD_display_symbol(3,13,ip_buffer[3] / 100,0);
				 LCD_display_symbol(3,14,ip_buffer[3] / 10 % 10,0);
				 LCD_display_symbol(3,15,ip_buffer[3] % 10,0);				 
				 goto_xy(0x06,1);
				 print_str_16_16("PORT");	 //�汾��	   
				 LCD_display_symbol(4,5,1,1);
				 LCD_display_symbol(4,7,ip_buffer[4] / 16 % 16,0);
				 LCD_display_symbol(4,8,ip_buffer[4] % 16,0);
				 LCD_display_symbol(4,9,ip_buffer[5] / 16 % 16,0);
				 LCD_display_symbol(4,10,ip_buffer[5] % 16,0);                 
				 }
			  else
			  	car_outdate();
			  NETSTATE = NETSTATE_CLOSE;
			  close_gprs_power();
			  Smart_Power_OFF;						 
			  delay(KEYTIMEOUT_1S * 3);
			  return 1;
              break;
                case IAP_CARD:
                      if(validity(block2_buffer,IAP_CARD) == OK)//IP������Ч���� ���
                      {
                          lcd_clear();
                          Smart_Power_OFF;
                          if(block1_buffer[0] == 0x11)
                          {
                              //������������ģʽ
                              dispaly(2,3,(HZ + qi_2));//��
                              dispaly(2,4,(HZ + dong));
                              dispaly(2,5,(HZ + sheng));      
                              dispaly(2,6,(HZ + ji_1));
                              
                              DISABLE_EXTI15_10_IRQ();      
                              DISABLE_EXTI9_5_IRQ();                   
                              IAP_UpData(1);                   
                              OPEN_EXTI9_5_IRQ();                                                                          
                              OPEN_EXTI15_10_IRQ(); 
                          }
                          else
                          {
                              I2C_WriteS_24C(IAPUpdataClass,block1_buffer+1,3);//��IAP���� ���� 1  ʱ�� 2
                              I2C_WriteS_24C(FreeClass,block1_buffer+4,3);//���ʸ��²���
                                                                       
                              dispaly(2,3,(HZ + xia)); //��
                              dispaly(2,4,(HZ + zai_1));//��
                              dispaly(2,5,(HZ + cheng));//        
                              dispaly(2,6,(HZ + gong_1));//   
                              
                              delay(KEYTIMEOUT_1S * 3);
                          }
                                      
                      }
                      else
                      {
                          car_outdate();
                          delay(KEYTIMEOUT_1S * 2);
                      }
					  return 0;
                      break;
//                case MIFARE_BACLK_CARD://�Է����ĺ�������
//                  Smart_Power_OFF;
//                  OPEN_EXTI9_5_IRQ();        
//                  OPEN_EXTI15_10_IRQ();
//                  
//                  Buzz_0;
//                  delay(KEYTIMEOUT_1S/10);
//                  Buzz_1;
//                  
//                  display_backList();
//                  delay(KEYTIMEOUT_1S * 3);
//                  return 0;
//                break;
                
            default:
				//��ʱ�Ȳ����ӿ��쳣����� andyluo 2016-05-01
			  flag = campare_card_NO(car,MIFARE_card_info.SNR,MIFARE_CARD,1);
			  if(flag == OK)//�����Ƿ���ͬ//������ͬ �ϴμٽ���
				Mifare_Recover(MIFARE_card_info.SNR,car);
			  
              //�������ж� һ���Ƿ��а������Ŀ� д���ģ��еĻ�����������ָ�����	                      
              flag = NG;// Mifare_Recover(MIFARE_card_info.SNR,car);
              Smart_Power_OFF;//�ص�����ģ��ĵ�Դ Ϊ��ʡ��                                            
              if(flag == OK)
			  	{
				//��ʾ д������ ������ˢ��
				write_card_error(0);  
				}
			  else
			  	{
				//��ʾ ����1 ����ϵ������˾
				if(!key_flagbk)
				  {
				  diplay_problem();
				  delay(KEYTIMEOUT_1S * 4);
				  }
				}              
              OPEN_EXTI9_5_IRQ();                                            
              OPEN_EXTI15_10_IRQ();
              timeOut = 0;                                     
              while(timeOut < KEYTIMEOUT_1S * 2) 
			  	{ 
				if(key_flag)
					{  
					key_flag = 0; 
					delay(KEYTIMEOUT_1S * QUIT_TIME);
					break;
					}                                           
                 timeOut++;
				 }	                      
              return 0;
              break;
        }
        break;
      }
      else//����ʧ��
      	  {
          //��ʾ����ʧ��
          //display_operation_false();
          //delay(KEYTIMEOUT_1S * 3);
          //return 0;
          QuitFlag = 1;
		  display_flag = 2;  
		  }
    }
        else//��Կʧ��
        {
           display_ICflag = 0xAA;
            timeOut_quit++;
            read_card_flag = 0x00;
            card_class_flag = inquire_card(&YWCardInfo);//��� ��������
			if(card_class_flag==CardType_CPCLOCK)
				{
				write_card_error(0);
				delay(KEYTIMEOUT_1S*3);
				return 1;
				}
			if((card_class_flag==CardType_MF1)||
				(card_class_flag==CardType_BIKE)||
				(card_class_flag==CardType_CPC))
				{
                read_card_flag = OK;
                break;
				}
            else
				{
                read_card_flag = NO;
				}       

			if((card_class_flag==CardType_BIKE)||
				(card_class_flag==CardType_CPC))
                break;
            if(read_card_flag == OK) 
				{  
                DISABLE_EXTI15_10_IRQ();
                DISABLE_EXTI9_5_IRQ();
                if(card_class_flag == CardType_MF1)
	                {
					read_MIFARE_card(&MIFARE_card_info);  //��ȡmifare������Ϣ
	                MF1key_main(MIFARE_card_info.SNR,MIFARE_password_buffer);     //��ȡMIFARE������Կ
	                }  
            	}			
        }	            
    }        
	if((card_class_flag==CardType_BIKE)||
		(card_class_flag==CardType_CPC))
        continue;
    if(timeOut_quit >= 3)
		{  
		//display_operation_false(); 
		//delay(KEYTIMEOUT_1S * 3);
		QuitFlag = 1;
		display_flag = 2;
		}
		}		
	else
		{
        //û������
        if(timeOut >= 300 || QuitKey != 0)
			QuitFlag = 0;
		else
			QuitFlag = 1;
		if(QuitFlag&&(QuitTime<5))continue;
		 //������ �����ϴ����Զ���λ�� ��λ��ʾ
		 uchar flagBuf[1],RecordBuf[32],nowTimeBuf[4];
		 u16 OvertimeMonery,Monery;
		 int OverTime;
		 I2C_ReadS_24C(ResetCar1Flag + car - 1,flagBuf,1);
		 if(flagBuf[0] == 1)
		 	{
            //flagBuf[0] = 0x00;
            //I2C_WriteS_24C(ResetCar1Flag + car - 1,flagBuf,1);
            GetCurrentTime();
			for(uchar i=0;i<4;i++)
				nowTimeBuf[i] = time[3-i];
			I2C_ReadS_24C(ResetRecordCar1 + (car - 1)*32,RecordBuf,32);
            OvertimeMonery = time_to_momery(RecordBuf+10);
            Monery = hcl(flagBuf+14,3);
            OvertimeMonery = OvertimeMonery - Monery;
            OverTime = CalcalateStopTime(RecordBuf + 21,nowTimeBuf);
			
			I2C_ReadS_24C(CardNo1_CPU+(car-1)*16,buffer,8);
			if((buffer[0]!=0xAA)&&
				(buffer[2]!=0xAA)&&
				(buffer[4]!=0xAA)&&
				(buffer[6]!=0xAA))
				{
				memcpy(RecordBuf+1,buffer,8);
				}				
			
            displayResetInfo(RecordBuf+1,RecordBuf+10,OverTime,OvertimeMonery);
            delay(KEYTIMEOUT_1S * 3);			
			QuitKey = 0;
            }
		 }
	}   
    
    
    OPEN_EXTI9_5_IRQ();                                   
    OPEN_EXTI15_10_IRQ();    
    LCD_back_OFF; 
    Smart_Power_OFF;    
    if(display_flag == 1 && read_card_flag != OK)
//	if(display_flag == 1 && QuitTime < 2 && read_card_flag != OK)
		{
        read_car_reference_of_use_info(&CS_RF_US,car);
        car_station = CS_RF_US.car_stop_way[0];
        timeOut = 0;
        key_flag = 0;
		if((CS_RF_US.car_stop_way[0] == 0x66)&&
			(CS_RF_US.smartCard_SNR[0]== PreBuyflag)) //��ʱ//Ԥ���־PreBuyflag
			{//2016-02-26
			OPEN_EXTI9_5_IRQ(); 								  
			OPEN_EXTI15_10_IRQ();	 
			lcd_clear();
			LCD_POWER_OFF;
			lcd_res_0;			 
			LCD_back_OFF; 
			Smart_Power_OFF;	   
			return 0;	   
			}
		if(car_station == 0x66)//��ʾ�����λ ����ʹ�� �鿴ͣ����Ϣ
        	{
			if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����
              LCD_back_ON;
            else
              LCD_back_OFF;            
            hour = ret_max_24hour(CS_RF_US.start_stopTime,SELECT) / 60;
            min = ret_max_24hour(CS_RF_US.start_stopTime,SELECT) % 60;
            momery = time_to_momery(CS_RF_US.start_stopTime);
            lcd_clear();
			
			I2C_ReadS_24C(CardNo1_CPU+(car-1)*16,buffer,8);
			if((buffer[0]!=0xAA)&&
				(buffer[2]!=0xAA)&&
				(buffer[4]!=0xAA)&&
				(buffer[6]!=0xAA))
				{
				memcpy(CS_RF_US.smartCard_SNR,buffer,8);
				}				
            display_car_statue(CS_RF_US.smartCard_SNR[4],CS_RF_US.smartCard_SNR[5],CS_RF_US.smartCard_SNR[6],CS_RF_US.smartCard_SNR[7],hour,min,momery);
            while(timeOut < KEYTIMEOUT_1S * 2)
				{
                if(key_flag)
					{
                    key_flag = 0;
                    delay(KEYTIMEOUT_1S * QUIT_TIME);
                    break;
					}
                timeOut++;
				}			
			QuitKey = 0;
			
#ifdef ZG_MBSYSTEM	//������					
			MBtoBase_Card(1);//2015-12-18����
#endif
			
			OPEN_EXTI9_5_IRQ(); 								  
			OPEN_EXTI15_10_IRQ();	 
			lcd_clear();
			LCD_POWER_OFF;
			lcd_res_0;			 
			LCD_back_OFF; 
			Smart_Power_OFF;	   
			return 0;	   
			}
		}
	else if(display_flag == 2)
		{
        if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����                
          LCD_back_ON;              
        else                
          LCD_back_OFF;
        write_card_error(0);                                    
        delay(KEYTIMEOUT_1S * 4);
		} 
	else if(display_ICflag == 0xAA)//��Կ����  IC������2015-08-22
		{
		if(!key_flagbk)
			{
			write_card_error(0);
			delay(KEYTIMEOUT_1S * 4);
			}
		}
	else
		{
		if(!key_flagbk)
			{
			diplay_problem();
			delay(KEYTIMEOUT_1S * 4);
			}
		}
	
#ifdef ZG_MBSYSTEM	//������					
	MBtoBase_Card(1);//2015-12-18����
#endif

    //��������¼�ķ��ͻ���
    //1. �Ѷ���ģ�� LCD��Դ�ر� ��GPRSģ���Դ
    OPEN_EXTI9_5_IRQ();                                   
    OPEN_EXTI15_10_IRQ();    
    lcd_clear();
    LCD_POWER_OFF;
    lcd_res_0;           
    LCD_back_OFF; 
    Smart_Power_OFF;       
    return 0;      
}


//�ѳ�λʹ�ò�����Ϣ д�� FM24L256 ȥ
uchar write_car_reference_of_use_info(uchar car,uchar buffer[],uchar count)
{
  
    switch(car)
    {
      case car1:
      I2C_WriteS_24C(car1_used_reference_info,buffer,count);
      break;
      
      case car2:
      I2C_WriteS_24C(car2_used_reference_info,buffer,count);
      break;
      
      case car3:
      I2C_WriteS_24C(car3_used_reference_info,buffer,count);
      break;
      
      case car4:
      I2C_WriteS_24C(car4_used_reference_info,buffer,count);
      break;
      
      default:break;
    }
    return 0;
}

//�ѳ�λʹ�ò�����Ϣ д�� FM24L256 ȥ
uchar write_car_15_reference(uchar car,uchar buffer[],uchar count)
{
  
    switch(car)
    {
      case car1:
      I2C_WriteS_24C(car1_15Min,buffer,count);
      break;
      
      case car2:
      I2C_WriteS_24C(car2_15Min,buffer,count);
      break;
      
      case car3:
      I2C_WriteS_24C(car3_15Min,buffer,count);
      break;
      
      case car4:
      I2C_WriteS_24C(car4_15Min,buffer,count);
      break;
      
      default:break;
    }
    return 0;
}

void ReadCar_15_Info(uchar car,uchar *buffer)
{
    switch(car)
    {
      case car1:
      I2C_ReadS_24C(car1_15Min,buffer,16);
      break;
      
      case car2:
      I2C_ReadS_24C(car2_15Min,buffer,16);
      break;
      
      case car3:
      I2C_ReadS_24C(car3_15Min,buffer,16);
      break;
      
      case car4:
      I2C_ReadS_24C(car4_15Min,buffer,16);
      break;
      
      default:break;
    }
}
//����λʹ�ò�����Ϣ
//��������
//son ��λʹ�ò��� �ṹ��
//car �ھͳ�λ 1 2 3 4
void read_car_reference_of_use_info(carStation_reference_of_used* son,uchar car)
{
    uchar buffer[16];
    uchar momery_buffer[3];
    int i,station=0;
    station = 0;
    
    switch(car)
    {
      case car1:
      I2C_ReadS_24C(car1_used_reference_info,buffer,16);
      I2C_ReadS_24C(car1_smartCard_momenry,momery_buffer,4);
      break;
      
      case car2:
      I2C_ReadS_24C(car2_used_reference_info,buffer,16);
      I2C_ReadS_24C(car2_smartCard_momenry,momery_buffer,4);
      break;
      
      case car3:
      I2C_ReadS_24C(car3_used_reference_info,buffer,16);
      I2C_ReadS_24C(car3_smartCard_momenry,momery_buffer,4);
      break;
      
      case car4:
      I2C_ReadS_24C(car4_used_reference_info,buffer,16);
      I2C_ReadS_24C(car4_smartCard_momenry,momery_buffer,4);
      break;
      
      default:break;
    }
    
    son->car_stop_way[0] = buffer[station];
    
    station = station + 1;
    for(i=0;i<8;i++)
      son->smartCard_SNR[i] = buffer[station + i];
    
    station = station + 8;
    for(i=0;i<5;i++)
      son->start_stopTime[i] = buffer[station + i];
    
    station = station + 5;
    for(i=0;i<1;i++)
      son->max_stopTime_hour[i] = buffer[station + i];

    station = station + 1;
    for(i=0;i<1;i++)
      son->max_stopTime_min[i] = buffer[station + i];
    
    for(i=0;i<4;i++)
      son->smartCard_momenry[i] = momery_buffer[i];
}

uchar validity(uchar data[],uchar card)
{
    uchar year;
    uchar month;
    uchar date;
    
    uchar get_year_B;
    uchar get_month_B;
    uchar get_date_B;
    uchar get_year_E;
    uchar get_month_E;
    uchar get_date_E;
    
    switch(card)
    {
    case MONTH_CARD:
      get_year_B = data[10];
      get_year_E = data[13];
      get_month_B = data[11];
      get_month_E = data[14];
      get_date_B = data[12];
      get_date_E = data[15];
      break;
    case MANAGE_CARD:
	case RESET_CARD:
	case DECEIVE_CARD:
      get_year_B = 0;
      get_year_E = data[13];
      get_month_B = 0;
      get_month_E = data[14];
      get_date_B = 0;
      get_date_E = data[15];
      break;
    case ENCRYPT_CARD:
    case PDA_CARD:
    case MIFARAE_PARK_CARD:
    case CLEAR_CARD:
    case SELECT_CARD:
    case IP_ADREES:
    case RECORD_CARD:
    case SELECT_RECORD_CARD:
    case IAP_CARD:
      
      get_year_B = 0;
      get_year_E = data[13];
      get_month_B = 1;
      get_month_E = data[14];
      get_date_B = 1;
      get_date_E = 0x31;
      break;
  
    default:break;
    }
    
    GetCurrentTime();
    
    year = time[4];
    month = time[3];
    date = time[2];
    if(year > get_year_B && year < get_year_E)
    {
        return OK;
    }
    else if(year == get_year_B && year == get_year_E)
    {
        if(month > get_month_B && month < get_month_E)
        {
          return OK;
        }
        else if(month == get_month_B && month < get_month_E)
        {
            if(date >= get_date_B)
              return OK;
            else
              return NO;
        }
        else if(month > get_month_B && month == get_month_E)
        {
            if(date <= get_date_E)
              return OK;
            else
              return NO;
        }
        else if(month == get_month_B && month == get_month_E)
        {
            if(date >= get_date_B && date <= get_date_E)
              return OK;
            else 
              return NO;
        }
        else
          return NO;
        
    }
    else if(year == get_year_B && year < get_year_E)
    {
        if(month > get_month_B)
          return OK;
        else if(month == get_month_B)
        {
            if(date >= get_date_B)
              return OK;
            else
              return NO;
        }
        else
          return NO;
        
    }
    else if(year == get_year_E && year > get_year_B)
    {
        if(month < get_month_E)
          return OK;
        else if(month == get_month_E)
        {
            if(date <= get_date_E)
              return OK;
            else
              return NO;
        }
        else
          return NO;
    }
    else
      return NO;
    
}

uchar mibiao_check(uchar data[])
{

    
    long mibiao_no = 0;
    long get_miao_no_s = 0;
    long get_miao_no_e = 0;
    
    get_miao_no_s = data[3] * 0x10000 + data[4] * 0x100 + data[5];
    get_miao_no_e = data[6] * 0x10000 + data[7] * 0x100 + data[8];
    
    
    uchar buffer[4];
    I2C_ReadS_24C(mibiao_number,buffer,4);

    mibiao_no = buffer[0] * 0x10000 + buffer[1] * 0x100 + buffer[2];
    
    if(mibiao_no <= get_miao_no_e && mibiao_no >=get_miao_no_s)
    {
        return OK;
    }
    else
    {
        return NO;
    }
}

void light(uchar car,uchar flag)
{
    if(flag == OK)
    {
        switch(car)
        {
        case car1:
        #ifdef CAR
          
        #else
          LED1_ON;
        #endif
          break;
        case car2:
        #ifdef CAR
          LED1_ON;
        #else
          LED2_ON;
        #endif
          break;
        case car3:
        #ifdef CAR
          LED4_ON;
        #else
          LED3_ON;
        #endif
          break;
        case car4:
        #ifdef CAR
          
        #else
          LED4_ON;
        #endif
          break;
        default:break;
        }
    }
    else
    {
        switch(car)
        {
        case car1:
        #ifdef CAR
          
        #else
          LED1_OFF;
        #endif
          break;
        case car2:
        #ifdef CAR
          LED1_OFF;
        #else
          LED2_OFF;
        #endif
          break;
        case car3:
        #ifdef CAR
          LED4_OFF;
        #else
          LED3_OFF;
        #endif
          break;
        case car4:
        #ifdef CAR
          
        #else
          LED4_OFF;
        #endif
          break;
        default:break;
        }
    }
}

//����ÿ���µ����һ���Ƕ���
int ret_end_month(uchar month)
{
    int year = 2000;
    switch(month)
    {
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
      return 31;
      break;
    case 4:
    case 6:
    case 9:
    case 11:
      return 30;
      break;
    case 2:
      GetCurrentTime();
      year = year + time1[4];
      if(year % 4 == 0)
        return 29;
      else
        return 28;
      break;
    default:break;
    }
    
    return 0;
}
//buffer ����Ĳ���
//falg ��ʾʲô��
int ret_max_24hour(uchar buffer[],uchar flag)
{
    uchar year,month,date,terr=0;
    int hour,min;
    
    uchar get_year;
    uchar get_month;
    uchar get_date;
    uchar get_hour;
    int get_min;
    
    uchar last_month;
    
    GetCurrentTime();
    year = time1[4];
    month = time1[3];
    date = time1[2];
    hour = time1[1];
    min = time1[0];
    switch(flag)
    {
        case MONTH_CARD:
          get_year = ((buffer[14]>>4)&0x0f)*10 + (buffer[14]&0x0f);
          get_month = ((buffer[10]>>4)&0x0f)*10 + (buffer[10]&0x0f);
          get_date = ((buffer[11]>>4)&0x0f)*10 + (buffer[11]&0x0f);
          get_hour = ((buffer[12]>>4)&0x0f)*10 + (buffer[12]&0x0f);
          get_min = ((buffer[13]>>4)&0x0f)*10 + (buffer[13]&0x0f);
          break;
        case SELECT:                
        case PARK_CARD:
		case MIFARAE_PARK_CARD:
		case HLEPPARK_CARD:
         get_month = ((buffer[0]>>4)&0x0f)*10 + (buffer[0]&0x0f);
         get_date = ((buffer[1]>>4)&0x0f)*10 + (buffer[1]&0x0f);
         get_hour = ((buffer[2]>>4)&0x0f)*10 + (buffer[2]&0x0f);
         get_min = ((buffer[3]>>4)&0x0f)*10 + (buffer[3]&0x0f);
         get_year = ((buffer[4]>>4)&0x0f)*10 + (buffer[4]&0x0f);
             break;
	    case CPC_CARD:
		case CPU_CARD:
         get_year = ((buffer[0]>>4)&0x0f)*10 + (buffer[0]&0x0f);
         get_month = ((buffer[1]>>4)&0x0f)*10 + (buffer[1]&0x0f);
         get_date = ((buffer[2]>>4)&0x0f)*10 + (buffer[2]&0x0f);
         get_hour = ((buffer[3]>>4)&0x0f)*10 + (buffer[3]&0x0f);
         get_min = ((buffer[4]>>4)&0x0f)*10 + (buffer[4]&0x0f);
         break;
       case MIFARAE_PARK_CARD_new:
		   get_year = year;//((buffer[2]>>4)&0x0f)*10 + (buffer[2]&0x0f);
		   get_month = ((buffer[2]>>4)&0x0f)*10 + (buffer[2]&0x0f);
		   get_date = ((buffer[3]>>4)&0x0f)*10 + (buffer[3]&0x0f);
		   get_hour = ((buffer[4]>>4)&0x0f)*10 + (buffer[4]&0x0f);
		   get_min = ((buffer[5]>>4)&0x0f)*10 + (buffer[5]&0x0f);
//		   get_year = ((buffer[2]>>4)&0x0f)*10 + (buffer[2]&0x0f);
//		   get_month = ((buffer[3]>>4)&0x0f)*10 + (buffer[3]&0x0f);
//		   get_date = ((buffer[4]>>4)&0x0f)*10 + (buffer[4]&0x0f);
//		   get_hour = ((buffer[5]>>4)&0x0f)*10 + (buffer[5]&0x0f);
//		   get_min = ((buffer[6]>>4)&0x0f)*10 + (buffer[6]&0x0f);
         break;
       case MATER_RUN_TIME://OK
         
          get_year = ((buffer[4]>>4)&0x0f)*10 + (buffer[4]&0x0f);
          
          get_month = ((buffer[3]>>4)&0x0f)*10 + (buffer[3]&0x0f);
          get_date = ((buffer[2]>>4)&0x0f)*10 + (buffer[2]&0x0f);
          get_hour = ((buffer[1]>>4)&0x0f)*10 + (buffer[1]&0x0f);
          get_min = ((buffer[0]>>4)&0x0f)*10 + (buffer[0]&0x0f);
         break;  
         
    default:break;
         
    }
	if((get_year>year)||
	((get_year==year)&&(get_month>month))||
	((get_year==year)&&(get_month==month)&&(get_date>date))||
	((get_year==year)&&(get_month==month)&&(get_date>date))||
	((get_year==year)&&(get_month==month)&&(get_date==date)&&(get_hour>hour))||
	((get_year==year)&&(get_month==month)&&(get_date==date)&&(get_hour==hour)&&(get_min>min)))
		{
		terr=1;
		}
   
    year = year - get_year;
    if(year == 1)//����
    {
        month = month + (12 - get_month);
        if(month > 0) //ͣ��ʱ�� ����
        {   
            last_month = ret_end_month(get_month);
            date = (month - 1)*30 + (last_month - get_date) + date; //�������31 �϶��������
            if(date > 0) //ͣ��ʱ�� ����
            {
                hour = (date - 1)*24 + (24-get_hour) + hour;
                if(hour > 0)
                {
                    min = (hour-1)*60 + (60 - get_min) + min;
                }
                else
                {
                    min = min - get_min;
                }
            }
            else
            {
                hour = hour - get_hour;
                if(hour > 0)
                {
                    min = (hour-1)*60 +(60 - get_min) + min;
                }
                else
                {
                    min = min - get_min;
                }
            }
        }
        else
        {
            date = date - get_date;
            if(date > 0) //ͣ��ʱ�� ����
            {
                hour = (date - 1)*24 + (24-get_hour) + hour;
                if(hour > 0)
                {
                    min = (hour-1)*60 + (60 - get_min) + min;
                }
                else
                {
                    min = min - get_min;
                }
            }
            else
            {
                hour = hour - get_hour;
                if(hour > 0)
                {
                    min = (hour-1)*60 + (60 - get_min) + min;
                }
                else
                {
                    min = min - get_min;
                }
            }
        }
        
    }
    else//û�п���
    {
        if(month >= get_month)
			month = month - get_month;
        else
			{
			month = (month+12) - get_month;
        	}
        if(month > 0) //ͣ��ʱ�� ����
        {   
            last_month = ret_end_month(get_month);
            date = (month - 1)*30 + (last_month - get_date) + date; //�������31 �϶��������
            if(date > 0) //ͣ��ʱ�� ����
            {
                hour = (date - 1)*24 + (24-get_hour) + hour;
                if(hour > 0)
                {
                    min = (hour-1)*60 + (60 - get_min) + min;
                }
                else
                {
                    min = min - get_min;
                }
            }
            else
            {
                hour = hour - get_hour;
                if(hour > 0)
                {
                    min = (hour-1)*60 +(60 - get_min) + min;
                }
                else
                {
                    min = min - get_min;
                }
            }
        }
        else
        {
            date = date - get_date;
            if(date > 0) //ͣ��ʱ�� ����
            {
                hour = (date - 1)*24 + (24-get_hour) + hour;
                if(hour > 0)
                {
                    min = (hour-1)*60 + (60 - get_min) + min;
                }
                else
                {
                    min = min - get_min;
                }
            }
            else
            {
                hour = hour - get_hour;
                if(hour > 0)
                {
                    min = (hour-1)*60 + (60 - get_min) + min;
                }
                else
                {
                    min = min - get_min;
                }
            }
        }
       
      }
    if((min<0)&&(flag !=CPC_CARD))
		min=0;
	if(terr)
		min=0;
    return min;
}


//�Ƚ� �����Ƿ� �� ��λͣ���Ŀ�����ͬ
uchar campare_card_NO(uchar car,uchar buffer[],uchar card_class,uchar DataFrom)
{
    uchar i;
    int data;
    uchar card_NO_buffer[9];
    if(DataFrom == 1)
      data = 0x0000;
    else if(DataFrom == 2)
      data = 0x0410;
    switch(car)
    {
      case car1:
      I2C_ReadS_24C((car1_used_reference_info + data),card_NO_buffer,9);
      break;
      case car2:
      I2C_ReadS_24C((car2_used_reference_info + data),card_NO_buffer,9);
      break;
      case car3:
      I2C_ReadS_24C((car3_used_reference_info + data),card_NO_buffer,9);
      break;
      case car4:
      I2C_ReadS_24C((car4_used_reference_info + data),card_NO_buffer,9);
      break;
    default:break;
      
    }
    //HR_TIME = card_NO_buffer[1];
    if(card_class == CPU_CARD)
    {
      for(i=0;i<4;i++)
      {
          if(card_NO_buffer[i+5] != buffer[i])
          break;
      }
        
      
      if(i>=4)
        return OK;
      else
        return NO;
    }
    else if(card_class == MIFARE_CARD)
    {
        for(i=0;i<4;i++)
        {
            if(card_NO_buffer[i+5] != buffer[3 - i])
              break;
        }
        
      
      if(i>=4)
        return OK;
      else
        return NO;
    }
    else 
      return NO;
}

int calculate_park_time(uchar buffer[],uchar card_flag)//����ͣ��ʱ��
{
    //uchar year; //����
    uchar month;
    uchar date;
    uchar hour;
    uchar min;
    //uchar second;
    
    GetCurrentTime();
    //year = time1[4];
    month = time[3];
    date = time[2];
    hour = time[1];
    min = time[0];
    
    switch(card_flag)
    {
      case MONTH_CARD:
        if(month > buffer[5])
        {
            month = month - buffer[5];
            date = (month-1)*31 + (31-buffer[4]) + date;
            if(date > 0)
            {
                hour = (date-1)*24 + (24-buffer[6]) + hour;
                if(hour > 0)
                {
                    min = (hour-1)*60 + (60-buffer[7]) + min;
                }
                else
                {
                    min = min - buffer[7];
                }
            }
            else
            {
                hour = hour - buffer[6];
                if(hour > 0)
                {
                    min = (hour-1)*60 + (60-buffer[7]) + min;
                }
                else
                {
                    min = min - buffer[7];
                }
            }
              
        }
        else
        {
            date = date - buffer[4];
            if(date > 0)
            {
                hour = (date-1)*24 + (24-buffer[6]) + hour;
                if(hour > 0)
                {
                    min = (hour-1)*60 + (60-buffer[7]) + min;
                }
                else
                {
                    min = min - buffer[7];
                }
            }
            else
            {
                hour = hour - buffer[6];
                if(hour > 0)
                {
                    min = (hour-1)*60 + (60-buffer[7]) + min;
                }
                else
                {
                    min = min - buffer[7];
                }
            }
        }
           return min;      
      break;
    default:break;
    }
    return 0;
}

//��λ car��λ ״̬
void reset_carStation(uchar car) 
{
    uchar buffer[16];
   // uchar buf[16];
    //���������������ͬ�ĳ�λ��Ϣ
    
    for(int i=0;i<16;i++)
      buffer[i] = 0;
        switch(car)
    {
        case car1:   
            I2C_WriteS_24C(car1_used_reference_info,buffer,16);
            I2C_WriteS_24C(car1_smartCard_momenry,buffer,4);
            I2C_WriteS_24C(car1_15Min,buffer,16);
          break;
        case car2:
            I2C_WriteS_24C(car2_used_reference_info,buffer,16);
            I2C_WriteS_24C(car2_smartCard_momenry,buffer,4);
            I2C_WriteS_24C(car2_15Min,buffer,16);
          break;
        case car3:
            I2C_WriteS_24C(car3_used_reference_info,buffer,16);
            I2C_WriteS_24C(car3_smartCard_momenry,buffer,4);
            I2C_WriteS_24C(car3_15Min,buffer,16);
          break;
        case car4:
            I2C_WriteS_24C(car4_used_reference_info,buffer,16);
            I2C_WriteS_24C(car4_smartCard_momenry,buffer,4);
            I2C_WriteS_24C(car4_15Min,buffer,16);
          break;
        default:break;
    }
}


//�� �� ���
void read_momery_to_Fm(uchar momery_buffer[],uchar car)
{
    switch(car)
    {
      case car1:
        I2C_ReadS_24C(car1_smartCard_momenry,momery_buffer,4);
        break;
      case car2:
        I2C_ReadS_24C(car2_smartCard_momenry,momery_buffer,4);
        break;
      case car3:
        I2C_ReadS_24C(car3_smartCard_momenry,momery_buffer,4);
        break;
      case car4:
        I2C_ReadS_24C(car4_smartCard_momenry,momery_buffer,4);
        break;
    default:break;
    }
}

//�ݴ� �� ���
void write_momery_to_Fm(uchar momery_buffer[],uchar car)
{
    switch(car)
    {
      case car1:
        I2C_WriteS_24C(car1_smartCard_momenry,momery_buffer,4);
        break;
      case car2:
        I2C_WriteS_24C(car2_smartCard_momenry,momery_buffer,4);
        break;
      case car3:
        I2C_WriteS_24C(car3_smartCard_momenry,momery_buffer,4);
        break;
      case car4:
        I2C_WriteS_24C(car4_smartCard_momenry,momery_buffer,4);
        break;
    default:break;
    }
}

//������������ E
void send_command(uchar flag)
{
    unsigned char  sz3[4];
    I2C_ReadS_24C(mibiao_number,sz3,3);//�����
    uart_send_som("*0%");
    
    uart_send_som("<Long><137></Long><Result><Optype><E");
    uart_send(hex_to_asic(flag));
    uart_send_som("></Optype>");
    
    uart_send_som("<Metno><66");   
    SEND_asic_2th(sz3[0]);
    SEND_asic_2th(sz3[1]);
    SEND_asic_2th(sz3[2]);
    uart_send_som("></Metno>");
    
    uart_send_som("</Result>#");
}

//�����Ƿ���� ���ʵ�����
void sendFreeCom(uchar flag)
{
    uchar sz3[4],ftrun,i;
    uchar FreeBuf[32],buff[16];
	u32 runtime;
	ftrun = flag;
	if(flag>=60)flag=6;
    I2C_ReadS_24C(mibiao_number,sz3,3);//�����
//    FreeBuf[0] = 0x55;
//    FreeBuf[12] = 0x00;
//    FreeBuf[13] = 0x99;
//    FreeBuf[14] = 0x12;
//    FreeBuf[15] = 0x01;
    I2C_ReadS_24C(B_startTime_unit_of_hour,FreeBuf,26);
#ifdef MU509B
	//MUPֱ�ӿ���3Gģ��
	EmptyRcv3G();	 
	send_string_3G("AT^IPSEND=1,\"");  
	uart_send_som("*<Long><0196></Long><Result>");
#else	
	uart_send_som("*0%<Long><0196></Long><Result>");
#endif

	Send_Segtime();

    uart_send_som("<Optype><F");

	uart_send(hex_to_asic(flag));
    uart_send_som("></Optype>");

    uart_send_som("<Metno><66");   
    SEND_asic_2th(sz3[0]);
    SEND_asic_2th(sz3[1]);
    SEND_asic_2th(sz3[2]);
    uart_send_som("></Metno>");
    
    uart_send_som("<Free><"); 
    for(i=0;i<26;i++)
      SEND_asic_2th(FreeBuf[i]);
    uart_send_som("></Free>");


    I2C_ReadS_24C(sysytem_public_key,buff,6);
    I2C_ReadS_24C(sysytem_public_ZGkey,buff+6,6);
    uart_send_som("<PSD><"); 
    for(i=0;i<2;i++)
      SEND_asic_2th(buff[i*6+5]);
	SEND_asic_2th(buff[1]);
    for(i=0;i<2;i++)
      SEND_asic_2th(buff[i*6+2]);
	SEND_asic_2th(buff[7]);
    for(i=0;i<2;i++)
      SEND_asic_2th(buff[i*6+1]);
	SEND_asic_2th(buff[4]);
    for(i=0;i<2;i++)
      SEND_asic_2th(buff[i*6+4]);
	SEND_asic_2th(buff[9]);
    for(i=0;i<2;i++)
      SEND_asic_2th(buff[i*6+3]);
	SEND_asic_2th(buff[0]);
    for(i=0;i<2;i++)
      SEND_asic_2th(buff[i*6+0]);	
	SEND_asic_2th(buff[14]);
    uart_send_som("></PSD>");
	
	//if(ftrun>=60)
		{
		if(ftrun==70)
			uart_send_som("RTCV");
		else if(ftrun==60)
			uart_send_som("RUNV");
		else if(ftrun==6)
			uart_send_som("FEEV");
		
		FreeBuf[0]= MATERVERSIONB_+'0';	
		FreeBuf[1]= '.';
		FreeBuf[2]= MATERVERSION+'0';
		I2C_ReadS_24C(MaterRunTime,buff,5);		
		runtime = ret_max_24hour(buff,MATER_RUN_TIME);
		ftrun = (runtime/1440)%100;
		i=3;
		memcpy(FreeBuf+i,MATERVERSIONTIME,10);
		i += 10;
		FreeBuf[i++]= '_'; 
		FreeBuf[i++]= 'T'; 
		FreeBuf[i++]= (ftrun/10)+'0'; 
		FreeBuf[i++]= (ftrun%10)+'0'; 
		FreeBuf[i++]= 'D'; 
		ftrun = (runtime%1440)/60;
		FreeBuf[i++]= (ftrun/10)+'0'; 
		FreeBuf[i++]= (ftrun%10)+'0'; 
		FreeBuf[i++]= 'H'; 
		ftrun = (runtime%1440)%60;
		FreeBuf[i++]= (ftrun/10)+'0'; 
		FreeBuf[i++]= (ftrun%10)+'0'; 
		FreeBuf[i++]= 'M'; 		
		FreeBuf[i++]= '\0';
		uart_send_som(FreeBuf);	
		I2C_ReadS_24C(BATRunTime,buff,5);		
		runtime = ret_max_24hour(buff,MATER_RUN_TIME);
		ftrun = (runtime/1440)%100;
		i=0;
		FreeBuf[i++]= '_'; 
		FreeBuf[i++]= 'B'; 
		FreeBuf[i++]= (ftrun/10)+'0'; 
		FreeBuf[i++]= (ftrun%10)+'0'; 
		FreeBuf[i++]= 'D'; 
		ftrun = (runtime%1440)/60;
		FreeBuf[i++]= (ftrun/10)+'0'; 
		FreeBuf[i++]= (ftrun%10)+'0'; 
		FreeBuf[i++]= 'H'; 
		ftrun = (runtime%1440)%60;
		FreeBuf[i++]= (ftrun/10)+'0'; 
		FreeBuf[i++]= (ftrun%10)+'0'; 
		FreeBuf[i++]= 'M'; 		
		FreeBuf[i++]= '\0';		
	    uart_send_som(FreeBuf);	
		I2C_ReadS_24C(SYSNG_CODE,buff,1);		
		if(buff[0])
			{
			i=0;
			FreeBuf[i++]= '_'; 
			FreeBuf[i++]= 'N'; 
			FreeBuf[i++]= 'G'; 
			FreeBuf[i++]= (buff[0]/10)+'0'; 
			FreeBuf[i++]= (buff[0]%10)+'0'; 
			FreeBuf[i++]= '\0';		
		    uart_send_som(FreeBuf);			
			}
		}
    
    uart_send_som("</Result>#");
#ifdef MU509B
	USART_Putc(USART1,'"');
	USART_Putc(USART1,0x0d);//�س�����
	USART_Putc(USART1,0x0a);		
#endif
}

//����ʱ�������
void sendCommand(uchar flag)
{
    uchar sz3[4];
    I2C_ReadS_24C(mibiao_number,sz3,3);//�����
#ifdef MU509B
	//MUPֱ�ӿ���3Gģ��
	EmptyRcv3G();	 
	send_string_3G("AT^IPSEND=1,\"");  
	uart_send_som("*<Long><0196></Long><Result>");
#else	
	uart_send_som("*0%<Long><0196></Long><Result>");
#endif
	Send_Segtime();

    uart_send_som("<Optype><F");
    uart_send(hex_to_asic(flag));
    uart_send_som("></Optype>");

    uart_send_som("<Metno><66");   
    SEND_asic_2th(sz3[0]);
    SEND_asic_2th(sz3[1]);
    SEND_asic_2th(sz3[2]);
    uart_send_som("></Metno>");
    
    uart_send_som("</Result>#");
#ifdef MU509B
	USART_Putc(USART1,'"');
	USART_Putc(USART1,0x0d);//�س�����
	USART_Putc(USART1,0x0a);		
#endif
}


void sendUpdateData(u16 bag,uchar type)
{
    uchar sz3[4];
    uchar carbuf[1];
    I2C_ReadS_24C(mibiao_number,sz3,3);//�����
    I2C_ReadS_24C(MATER_CAR,carbuf,1);   
    
#ifdef MU509B
	//MUPֱ�ӿ���3Gģ��
	EmptyRcv3G();	 
	send_string_3G("AT^IPSEND=1,\"");  
	uart_send_som("*<Long><0196></Long><Result>");
#else	
	uart_send_som("*0%<Long><0196></Long><Result>");
#endif

	Send_Segtime();
    uart_send_som("<Optype><F9></Optype><Nitem><88888></Nitem><F3></Optype>");
    
    uart_send_som("<hmdSeq><"); 
    uart_send(hex_to_asic(bag / 1000));
    uart_send(hex_to_asic(bag / 100 % 10));
    uart_send(hex_to_asic(bag / 10 % 10));
    uart_send(hex_to_asic(bag % 10));
    uart_send_som("></hmdSeq>");
    
    uart_send_som("<Metno><");   
    SEND_asic_2th(sz3[0]);
    SEND_asic_2th(sz3[1]);
    SEND_asic_2th(sz3[2]);
    uart_send_som("></Metno>");
    
    uart_send_som("<CarClass><");
    SEND_asic_2th(carbuf[0]);
    uart_send_som("></CarClass>");
    
    uart_send_som("<Ptype><");
    SEND_asic_2th(type);
    uart_send_som("></Ptype>");
    
    uart_send_som("</Result>#");
#ifdef MU509B
	USART_Putc(USART1,'"');
	USART_Putc(USART1,0x0d);//�س�����
	USART_Putc(USART1,0x0a);		
#endif
}
//*<Long><320></Long><Result><Optype><F1></Optype><Metno><66123456></Metno><spaces><6></spaces><TxnType><EA></TxnType><PosSeq><000000></PosSeq><CardKind><00000000></CardKind><ChildCardKind><00000000></ChildCardKind><BalBef><00000000></BalBef><TxnAmt><00000000></TxnAmt><CardNum><BAC7BFA4></CardNum><TxnDate><2015-08-03></TxnDate><TxnTime><11:50:00></TxnTime><TExnDate><2015-08-03></TExnDate><TExnTime><11:50:00></TExnTime><TxnCounter><000000></TxnCounter><PSAMNO><000000000000></PSAMNO><PSAMSeq><00000000></PSAMSeq><TAC><00000000></TAC><Ptype><0></Ptype></Result># 
void Send_CardFeeR(u8 ownflag)
{
    uchar sz3[4];
    //uchar carbuf[1];
	
    I2C_ReadS_24C(mibiao_number,sz3,3);//�����
//	uart_send_som("*0%<Long><320></Long><Result><Optype><F1></Optype><Metno><66123456></Metno><spaces><6></spaces><TxnType><EA></TxnType><PosSeq><000000></PosSeq><CardKind><00000000></CardKind><ChildCardKind><00000000></ChildCardKind><BalBef><00000000></BalBef><TxnAmt><00000000></TxnAmt><CardNum><D97A08B6></CardNum><TxnDate><2015-08-09></TxnDate><TxnTime><11:44:00></TxnTime><TExnDate><2015-08-11></TExnDate><TExnTime><11:44:00></TExnTime><TxnCounter><000000></TxnCounter><PSAMNO><000000000000></PSAMNO><PSAMSeq><00000000></PSAMSeq><TAC><00000000></TAC><Ptype><A></Ptype></Result>#");
#ifdef MU509B
	//MUPֱ�ӿ���3Gģ��
	EmptyRcv3G();	 
	send_string_3G("AT^IPSEND=1,\"");  
	uart_send_som("*<Long><320></Long><Result><Optype><F1></Optype><Metno><66");
#else	
	uart_send_som("*0%<Long><320></Long><Result><Optype><F1></Optype><Metno><66");
#endif

//	uart_send_som("66123456");
	SEND_asic_2th(sz3[0]);
    SEND_asic_2th(sz3[1]);
	
	if(ownflag)
		SEND_asic_2th(sz3[2]);
	else
		SEND_asic_2th(TMP.mbno[2]);
	uart_send_som("></Metno><spaces><");
//	uart_send_som("6");
	SEND_asic_2th(TMP.car+CAR_CLASS); 	
	uart_send_som("></spaces><TxnType><");
	TMP.cardtype = 0;
	SEND_asic_2th(TMP.cardtype);
	uart_send_som("></TxnType><PosSeq><000000></PosSeq><CardKind><00000000></CardKind><ChildCardKind><00000000></ChildCardKind><BalBef><00000000></BalBef><TxnAmt><00000000></TxnAmt><CardNum><");

//	uart_send_som("D97A08B6");	
	SEND_asic_2th(TMP.cardno[4]);
	SEND_asic_2th(TMP.cardno[5]);
	SEND_asic_2th(TMP.cardno[6]);
	SEND_asic_2th(TMP.cardno[7]);
	uart_send_som("></CardNum><TxnDate><20");
//	uart_send_som("2015-08-09");
	SEND_asic_2th(time[4]);
	uart_send_som("-");
	SEND_asic_2th(time[3]);
	uart_send_som("-");
	SEND_asic_2th(time[2]);
	uart_send_som("></TxnDate><TxnTime><");
//	uart_send_som("11:44");
	SEND_asic_2th(time[1]);
	uart_send_som(":");
	SEND_asic_2th(time[0]);
	uart_send_som(":00></TxnTime><TExnDate><20");
//	uart_send_som("2015-08-11");
	SEND_asic_2th(time[4]);
	uart_send_som("-");
	SEND_asic_2th(time[3]);
	uart_send_som("-");
	SEND_asic_2th(time[2]);
	uart_send_som("></TExnDate><TExnTime><");
//	uart_send_som("11:44");
	SEND_asic_2th(time[1]);
	uart_send_som(":");
	SEND_asic_2th(time[0]);
	uart_send_som(":00></TExnTime><TxnCounter><000000></TxnCounter><PSAMNO><000000000000></PSAMNO><PSAMSeq><00000000></PSAMSeq><TAC><00000000></TAC><Ptype><0></Ptype></Result>#");
#ifdef MU509B
	USART_Putc(USART1,'"');
	USART_Putc(USART1,0x0d);//�س�����
	USART_Putc(USART1,0x0a);		
#endif
}
//*<Long><320></Long><Result><Optype><F1></Optype><Metno><66123456></Metno><spaces><6></spaces><TxnType><EA></TxnType><PosSeq><000000></PosSeq><CardKind><00000000></CardKind><ChildCardKind><00000000></ChildCardKind><BalBef><00000000></BalBef><TxnAmt><00000000></TxnAmt><CardNum><D97A08B6></CardNum><TxnDate><2015-08-09></TxnDate><TxnTime><11:44:00></TxnTime><TExnDate><2015-08-11></TExnDate><TExnTime><11:44:00></TExnTime><TxnCounter><000000></TxnCounter><PSAMNO><000000000000></PSAMNO><PSAMSeq><00000000></PSAMSeq><TAC><00000000></TAC><Ptype><A></Ptype></Result>#
void Send_CallR(u8 ownflag)
{
    uchar sz3[4];
    //uchar carbuf[1];
	
    I2C_ReadS_24C(mibiao_number,sz3,3);//�����
//	uart_send_som("*0%<Long><320></Long><Result><Optype><F1></Optype><Metno><66123456></Metno><spaces><6></spaces><TxnType><EA></TxnType><PosSeq><000000></PosSeq><CardKind><00000000></CardKind><ChildCardKind><00000000></ChildCardKind><BalBef><00000000></BalBef><TxnAmt><00000000></TxnAmt><CardNum><D97A08B6></CardNum><TxnDate><2015-08-09></TxnDate><TxnTime><11:44:00></TxnTime><TExnDate><2015-08-11></TExnDate><TExnTime><11:44:00></TExnTime><TxnCounter><000000></TxnCounter><PSAMNO><000000000000></PSAMNO><PSAMSeq><00000000></PSAMSeq><TAC><00000000></TAC><Ptype><A></Ptype></Result>#");
#ifdef MU509B
	//MUPֱ�ӿ���3Gģ��
	EmptyRcv3G();	 
	send_string_3G("AT^IPSEND=1,\"");  
	uart_send_som("*<Long><320></Long><Result><Optype><F1></Optype><Metno><66");
#else	
	uart_send_som("*0%<Long><320></Long><Result><Optype><F1></Optype><Metno><66");
#endif
//	uart_send_som("66123456");
	SEND_asic_2th(sz3[0]);
    SEND_asic_2th(sz3[1]);
	if(ownflag)
		SEND_asic_2th(sz3[2]);
	else
		SEND_asic_2th(TMP.mbno[2]);
		
	uart_send_som("></Metno><spaces><");
//	uart_send_som("6");
    SEND_asic_2th(TMP.car+CAR_CLASS);		
	uart_send_som("></spaces><TxnType><EA></TxnType><PosSeq><000000></PosSeq><CardKind><00000000></CardKind><ChildCardKind><00000000></ChildCardKind><BalBef><00000000></BalBef><TxnAmt><00000000></TxnAmt><CardNum><");
//	uart_send_som("D97A08B6");	
	SEND_asic_2th(TMP.cardno[4]);
	SEND_asic_2th(TMP.cardno[5]);
	SEND_asic_2th(TMP.cardno[6]);
	SEND_asic_2th(TMP.cardno[7]);
	uart_send_som("></CardNum><TxnDate><20");
//	uart_send_som("2015-08-09");
	SEND_asic_2th(time[4]);
	uart_send_som("-");
	SEND_asic_2th(time[3]);
	uart_send_som("-");
	SEND_asic_2th(time[2]);
	uart_send_som("></TxnDate><TxnTime><");
//	uart_send_som("11:44");
	SEND_asic_2th(time[1]);
	uart_send_som(":");
	SEND_asic_2th(time[0]);
	uart_send_som(":00></TxnTime><TExnDate><20");
//	uart_send_som("2015-08-11");
	SEND_asic_2th(time[4]);
	uart_send_som("-");
	SEND_asic_2th(time[3]);
	uart_send_som("-");
	SEND_asic_2th(time[2]);
	uart_send_som("></TExnDate><TExnTime><");
//	uart_send_som("11:44");
	SEND_asic_2th(time[1]);
	uart_send_som(":");
	SEND_asic_2th(time[0]);
	uart_send_som(":00></TExnTime><TxnCounter><000000></TxnCounter><PSAMNO><000000000000></PSAMNO><PSAMSeq><00000000></PSAMSeq><TAC><00000000></TAC><Ptype><A></Ptype></Result>#");
#ifdef MU509B
	USART_Putc(USART1,'"');
	USART_Putc(USART1,0x0d);//�س�����
	USART_Putc(USART1,0x0a);		
#endif
}
	
//���м�¼���� 2015-08-10   andyluo  0-�ɹ� ����-ʧ��
u8 Send_CallRecord(u8 ownflag)
{
u16 timeOut,i;

	UART1_IRQn_CTL(ON);
	timeOut = 1;
	while(timeOut--)
		{
		if(open_gprs() == OK)
			{  			
			if(TMP.BaseFlag)
				{
				i =Sync_MtoB_Info(G24_Mode_D2,NULL,NULL);
				if(i==0)
					f_receiveOK=1;
				else
					f_receiveOK=0;
				}			
			else
				{
				Send_CallR(ownflag);
				//�������֮ǰ���յ�����
				for(i=0;i<RxCounter;i++)
				   RxBuffer[i]=0x00;		   
				RxCounter = 0;
				f_receiveOK = 0;
				rec_gprs_ack(3);
				}
			if(key_flag)
				{
				NET_KeyDeal();	
				break;
				}
			else if(f_receiveOK)//2014-06-19 09:12:11 ����
				{
				UART1_IRQn_CTL(ON);
				return 0;
				}		
			break;
			}
		else
			{
			GPRS_Power_OFF;
			}
		}
		GPRS_Power_OFF;

		UART1_IRQn_CTL(ON);
		return 1;		
}


//���������¼���� 2015-08-10 andyluo 0-�ɹ� ����-ʧ��
u8 Send_CardFeeRecord(u8 ownflag)
{
u8 buffer[32],LRC;
u16 timeOut,j,k,i;
	
	UART1_IRQn_CTL(ON);
	timeOut = 1;
	while(timeOut--)
		{
		if(open_gprs() == OK)
			{  
			if(TMP.BaseFlag)
				{
				i =Sync_MtoB_Info(G24_Mode_D1,NULL,NULL);
//				if(i==0)
//					return 0;
//				else
					return i;
				//return f_receiveOK;
				}			
			else
				{
				Send_CardFeeR(ownflag);
				//�������֮ǰ���յ�����
				for(i=0;i<RxCounter;i++)
				   RxBuffer[i]=0x00;		   
				RxCounter = 0;
				f_receiveOK = 0;				  
				for(i=0;i<16;i++)
					buffer[i] = 0x00;		
				i = rec_gprs_feeYW(8);//AABAC7BFA413880100320000005C
				}
			if(key_flag)
				{
				NET_KeyDeal();	
				UART1_IRQn_CTL(OFF);
				return 1;	
				}
			else if(f_receiveOK)//2014-06-19 09:12:11 ����
				{//AABAC7BFA413880100320000005C		
				for(k=0,j=i;k<14;k++,j++,j++)
					buffer[k] = (asic_to_hex(RxBuffer[j])<<4)+asic_to_hex(RxBuffer[j+1]);
				LRC = buffer[0];
				for(i=1;i<13;i++)
					LRC += buffer[i];
				if(LRC != buffer[13])
					{
					GPRS_Power_OFF;
					UART1_IRQn_CTL(OFF);
					return 1;		
					}
				memcpy(TMP.cardno,buffer+1,4);
				TMP.feemny = hcl(buffer+5,2);
				TMP.feetime = buffer[7];
				memcpy(TMP.unlockmny,buffer+8,2);				
				memcpy(TMP.time,buffer+8,5);//��ʱ��������һ�θ�λʱ�� 2015-08-14				
				UART1_IRQn_CTL(OFF);
				
				Buzz_0;
				delay(KEYTIMEOUT_1S/20);
				Buzz_1;
				
				return 0;
				}		
			break;
			}
		else
			{
			GPRS_Power_OFF;
			UART1_IRQn_CTL(OFF);
			return 1;		
			}
		}
		GPRS_Power_OFF;
		UART1_IRQn_CTL(OFF);
		return 1;		
}



//�͵�ѹ����
//EE0001020304050607 1401020917 000000 0000 2F 1401020917 01 AAAAAAAAAAAA ��ѹ��
//*1010110001EE00000000C3F8CCE41403071034000A28000041130610120001AAAAAAAAAAAA#
void Send_LowVoltageR(void)
{
	u8 WaringRe[16],ii,mbno[3];
	
    I2C_ReadS_24C(mibiao_number,mbno,3);//�����
	WaringRe[0] = 0xEA;
	for(ii=0;ii<3;ii++)
		WaringRe[1+ii] = mbno[ii];	
	WaringRe[4] = 0x00;
	for(ii=0;ii<5;ii++)
		WaringRe[5+ii] = time[4-ii];						
	WaringRe[10] = 0x6F; 					
	for(ii=0;ii<4;ii++)
		WaringRe[11+ii] = 0x00;
	WaringRe[15] = 0xDD;						
	IWDG_ReloadCounter();
//	sendFlag = open_gprs();
//	if(sendFlag != OK)return 1;//�������ɹ�
	if(TMP.BaseFlag)
		{
#ifdef	MB_2G4	//�м̴���
		f_receiveOK = SenRecord_2G4(WaringRe,16,16);
		//�����2.4G����
		return;
#endif
		}
	SendCar16Record(WaringRe,16,16);
//	rec_gprs_ack(3);
//	if(key_flag)//�����˳�
//		{
//		NET_KeyDeal();	
//		}
//	if(f_receiveOK)//���ճɹ�
//		{	
//		loop = 3;
//		while(loop--)
//			{
//			sendFlag =NETSTATE_FUN("*SLEEP#");
//			if(sendFlag!=NETSTATE_SLEEP)continue;
//			}
//		}

}

void Send_LowVoltageRBAK(void)
{

    unsigned char  sz3[4],block1_buffer[32],i;

	block1_buffer[0] = 0xEE;//��¼ͷ										   
	block1_buffer[1] = 0x00;										   
	block1_buffer[2] = 0x01; //�������� 										 
	block1_buffer[3] = 0x02; //�������� 									   
	block1_buffer[4] = 0x03; //�������� 									   
	block1_buffer[5] = 0x04; //�������� 									 
	block1_buffer[6] = 0x05;									  
	block1_buffer[7] = 0x06;									 
	block1_buffer[8] = 0x07;									  
	block1_buffer[9] = time[4];//�� 									
	block1_buffer[10] = time[3];//��									  
	block1_buffer[11] = time[2];//��									  
	block1_buffer[12] = time[1];//ʱ									
	block1_buffer[13] = time[0];//��									 
	block1_buffer[14] = 0x00;										
	block1_buffer[15] = 0x00;									  
	block1_buffer[16] = 0x00;									 
	block1_buffer[17] = 0x00;									 
	block1_buffer[18] = 0x00;									
	block1_buffer[19] = 0x2F;//�͵�ѹ���� ��λΪ2 						   
						   
	block1_buffer[20] = time[4];										   
	block1_buffer[21] = time[3];											
	block1_buffer[22] = time[2];											
	block1_buffer[23] = time[1];											
	block1_buffer[24] = time[0];
						 
	block1_buffer[25] = 0x01;					  
	for(i=26;i<32;i++)												
	  block1_buffer[i] = 0xAA;					  
	
    I2C_ReadS_24C(mibiao_number,sz3,3);//�����
    uart_send_som("*0%");
    
    SEND_asic_2th(sz3[0]);//����� 3�ֽ�
    SEND_asic_2th(sz3[1]);
    SEND_asic_2th(sz3[2]);
    
    SEND_asic_2th(0x00);// �������� 2�ֽ� Hex
    SEND_asic_2th(0x01);
	
    for(i=0;i<32;i++)
      SEND_asic_2th(block1_buffer[i]);    
    
    uart_send_som("#");
}

//LVT- 1 �͵�ѹ 0 ����
void Send_LowVoltage_Record(u8 LVT)
{
u8 timeOut,flag_buffer[4],SDflag,LVflag,lvtf,rsd=0;

	lvtf = LVT;
	I2C_ReadS_24C(LOW_VOLTAGE_F,flag_buffer,1);
	LVflag = flag_buffer[0]&0x0f;//�͵�ѹ���� ����Ϊ0 ���3
	SDflag = flag_buffer[0]&0xf0;//�͵�ѹ����״̬/����	����Ϊ0 ���6
	if(lvtf)//��ǰΪ�͵�ѹ
		{
		if(LVflag<2)
			{
			flag_buffer[0] += 1;
			I2C_WriteS_24C(LOW_VOLTAGE_F,flag_buffer,1);//�͵�ѹ������¼ ���� ��1����д�ص�ַ��ȥ
			}
		else if(SDflag<0x60)//����ʧ�ܴ���С��6��
			{
			rsd = 1;//��Ҫ����
			}
		else
			{
			SYS_MS.LOWBT = 2;//�����쳣
			}
		}
	else//��ѹ����
		{
		if(flag_buffer[0])
			{
			flag_buffer[0] = 0x00;
			I2C_WriteS_24C(LOW_VOLTAGE_F,flag_buffer,1);//�͵�ѹ������¼ ���� ��1����д�ص�ַ��ȥ
			}
		}		

	if(rsd)	
		{
		timeOut = 3;
		while(timeOut--)
			{
			/* ι��*/
			IWDG_ReloadCounter();//2015-12-23 andyluo
			if(open_gprs() == OK)
				{  
				Send_LowVoltageR();
				if(TMP.BaseFlag)
					{
					#ifdef	MB_2G4	//�м̴���
					//�����2.4G����
					#endif
					}
				else
					rec_gprs_ack(3);
				if(key_flag)
					{
					NET_KeyDeal();	
					break;
					}
				else if(f_receiveOK)//2014-06-19 09:12:11 ����
					{
					SYS_MS.LOWBT = 1;//�͵�ѹ�ѷ��ͳɹ� 2015-09-22
//					flag_buffer[0] &= 0x0F;
					flag_buffer[0] |= 0x60;					
					I2C_WriteS_24C(LOW_VOLTAGE_F,flag_buffer,1);//�͵�ѹ������¼ ���� ��1����д�ص�ַ��ȥ
					break;
					}
				else
					{
					if(flag_buffer[0]<0x60)
						flag_buffer[0] += 0x10;
					I2C_WriteS_24C(LOW_VOLTAGE_F,flag_buffer,1);//�͵�ѹ������¼ ���� ��1����д�ص�ַ��ȥ
					}
				
				
				}
			else
				{
				GPRS_Power_OFF;
				}
			}
		GPRS_Power_OFF;
		if(!timeOut)//����ʧ��
			{			
			if(flag_buffer[0]<0x60)
				flag_buffer[0] += 0x10;
			I2C_WriteS_24C(LOW_VOLTAGE_F,flag_buffer,1);//�͵�ѹ������¼ ���� ��1����д�ص�ַ��ȥ
			}
		}
}


//���������� bagΪ����С type ��������
void send_BackList_requestCommand(u16 bag,uchar type)
{
    uchar sz3[4];
    uchar carbuf[1];
    I2C_ReadS_24C(mibiao_number,sz3,3);//�����
    I2C_ReadS_24C(MATER_CAR,carbuf,1);
    uart_send_som("*0%");
 
    uart_send_som("<Long><137></Long><Result><Optype><F3></Optype><Nitem><88888></Nitem><F3></Optype>");
    
    uart_send_som("<hmdSeq><"); 
    uart_send(hex_to_asic(bag / 1000));
    uart_send(hex_to_asic(bag / 100 % 10));
    uart_send(hex_to_asic(bag / 10 % 10));
    uart_send(hex_to_asic(bag % 10));
    uart_send_som("></hmdSeq>");
    
    uart_send_som("<Metno><");   
    SEND_asic_2th(sz3[0]);
    SEND_asic_2th(sz3[1]);
    SEND_asic_2th(sz3[2]);
    uart_send_som("></Metno>");
    
    uart_send_som("<Ptype><");
    SEND_asic_2th(type);
    uart_send_som("></Ptype>");
    
    uart_send_som("</Result>#");
}

//����һ�� 16�ֽڵ����Ѽ�¼
void send_consumption_16_record(uchar record[])
{
    unsigned char  sz3[4];
    I2C_ReadS_24C(mibiao_number,sz3,3);//�����
    uart_send_som("*0%");
    
    uart_send_som("<Optype><EA></Optype>");
    
    uart_send_som("<CardNo><");//����
    SEND_asic_2th(record[1]);
    SEND_asic_2th(record[2]);
    SEND_asic_2th(record[3]);
    SEND_asic_2th(record[4]);
    SEND_asic_2th(record[5]);
    SEND_asic_2th(record[6]);
    SEND_asic_2th(record[7]);
    SEND_asic_2th(record[8]);
    uart_send_som("></CardNo>");
    
    uart_send_som("<Time><");//��������ʱ��
    SEND_asic_2th(0x20);
    SEND_asic_2th(record[9]);
    uart_send_som("-");
    SEND_asic_2th(record[10]);
    uart_send_som("-");
    SEND_asic_2th(record[11]);
    uart_send_som(" ");
    SEND_asic_2th(record[12]);
    uart_send_som(":");
    SEND_asic_2th(record[13]);
    uart_send_som(":");
    SEND_asic_2th(0x00);
    uart_send_som("></Time>");
    
    uart_send_som("<STime><");//�����뿪ʱ��
    SEND_asic_2th(0x20);
    SEND_asic_2th(record[20]);
    uart_send_som("-");
    SEND_asic_2th(record[21]);
    uart_send_som("-");
    SEND_asic_2th(record[22]);
    uart_send_som(" ");
    SEND_asic_2th(record[23]);
    uart_send_som(":");
    SEND_asic_2th(record[24]);
    uart_send_som(":");
    SEND_asic_2th(0x00);
    uart_send_som("></STime>");
    
    uart_send_som("<Money><");//������ԭ�н��
    SEND_asic_2th(record[14]);
    SEND_asic_2th(record[15]);
    SEND_asic_2th(record[16]);
    uart_send_som("></Money>");
    
    uart_send_som("<StopMoney><");//���ν��׽��
    SEND_asic_2th(record[17]);
    SEND_asic_2th(record[18]);
    uart_send_som("></StopMoney>");
    
    uart_send_som("<Flag><");//��־λ
    SEND_asic_2th(record[19]);
    uart_send_som("></Flag>");
    
    uart_send_som("<Metno><");//�����
    SEND_asic_2th(sz3[0]);
    SEND_asic_2th(sz3[1]);
    SEND_asic_2th(sz3[2]);
    uart_send_som("></Metno>");
    
    uart_send_som("<RecordFlag><");//��¼��־λ
    SEND_asic_2th(record[25]);
    uart_send_som("></RecordFlag>");
    
    uart_send_som("#");
}

//����һ�� ���Ѽ�¼
void send_consumption_record(uchar record[])
{ 
    unsigned char  sz3[4];
    I2C_ReadS_24C(mibiao_number,sz3,3);//�����
    uart_send_som("*0%");
    
    uart_send_som("<Long><320></Long><Result><Optype><F1></Optype>");
    
    uart_send_som("<Metno><");//�����
    SEND_asic_2th(sz3[0]);
    SEND_asic_2th(sz3[1]);
    SEND_asic_2th(sz3[2]);
    uart_send_som("></Metno>");
    
    uart_send_som("<CardType><");//��¼����
    SEND_asic_2th(record[0]);
    uart_send_som("></CardType>");
    
    uart_send_som("<CityCode><");//��Ƭ����
    SEND_asic_2th(record[1]);
    uart_send_som("></CityCode>");
    
    uart_send_som("<CardCode><");//������
    SEND_asic_2th(record[2]);
    SEND_asic_2th(record[3]);
    uart_send_som("></CardCode>");
    
    uart_send_som("<Citycardtype><");//��������
    SEND_asic_2th(record[4]);
    SEND_asic_2th(record[5]);
    uart_send_som("></Citycardtype>");
    
    uart_send_som("<LineCode><");//��·����  
    SEND_asic_2th(record[6]);
    SEND_asic_2th(record[7]);
    SEND_asic_2th(record[8]);
    uart_send_som("></LineCode>");
    
    uart_send_som("<CarCode><");//��������
    SEND_asic_2th(record[9]);
    SEND_asic_2th(record[10]);
    SEND_asic_2th(record[11]);
    uart_send_som("></CarCode>");
    
    uart_send_som("<OpManCode><");//˾������
    SEND_asic_2th(record[12]);
    SEND_asic_2th(record[13]);
    SEND_asic_2th(record[14]);
    SEND_asic_2th(record[15]);
    uart_send_som("></OpManCode>");
    
    uart_send_som("<MetreCode><");//���ν����豸��
    SEND_asic_2th(record[16]);
    SEND_asic_2th(record[17]);
    SEND_asic_2th(record[18]);
    SEND_asic_2th(record[19]);
    SEND_asic_2th(record[20]);
    SEND_asic_2th(record[21]);
    uart_send_som("></MetreCode>");
    
    uart_send_som("<spaces><");//��λ��   
    SEND_asic_2th(record[106]);
    uart_send_som("></spaces>");
    
    uart_send_som("<SerialNo><");//������ˮ��
    SEND_asic_2th(record[22]);
    SEND_asic_2th(record[23]);
    SEND_asic_2th(record[24]);
    SEND_asic_2th(record[25]);
    uart_send_som("></SerialNo>");
    
    uart_send_som("<HoroadRCtime><");//��������ʱ��
    SEND_asic_2th(0x20);
    SEND_asic_2th(record[84]);
    uart_send_som("-");
    SEND_asic_2th(record[85]);
    uart_send_som("-");
    SEND_asic_2th(record[86]);
    uart_send_som(" ");
    SEND_asic_2th(record[87]);
    uart_send_som(":");
    SEND_asic_2th(record[88]);
    uart_send_som(":");
    SEND_asic_2th(0x00);
    uart_send_som("></HoroadRCtime>");
    
    uart_send_som("<RCtime><");//����ʱ�䣨ˢ����
    SEND_asic_2th(record[26]);
    SEND_asic_2th(record[27]);
    uart_send_som("-");
    SEND_asic_2th(record[28]);
    uart_send_som("-");
    SEND_asic_2th(record[29]);
    uart_send_som(" ");
    SEND_asic_2th(record[30]);
    uart_send_som(":");
    SEND_asic_2th(record[31]);
    uart_send_som(":");
    SEND_asic_2th(record[32]);
    uart_send_som("></RCtime>");
    
    uart_send_som("<CardID><");//Ʊ/���߼���
    SEND_asic_2th(record[33]);
    SEND_asic_2th(record[34]);
    SEND_asic_2th(record[35]);
    SEND_asic_2th(record[36]);
    SEND_asic_2th(record[37]);
    SEND_asic_2th(record[38]);
    SEND_asic_2th(record[39]);
    SEND_asic_2th(record[40]);
    uart_send_som("></CardID>");
    
    uart_send_som("<CardNO><");//Ʊ/���߿���
    SEND_asic_2th(record[41]);
    SEND_asic_2th(record[42]);
    SEND_asic_2th(record[43]);
    SEND_asic_2th(record[44]);
    SEND_asic_2th(record[45]);
    SEND_asic_2th(record[46]);
    SEND_asic_2th(record[47]);
    SEND_asic_2th(record[48]);
    uart_send_som("></CardNO>");
    
    uart_send_som("<StopMoney><");//���׽��
    SEND_asic_2th(record[49]);
    SEND_asic_2th(record[50]);
    SEND_asic_2th(record[51]);
    SEND_asic_2th(record[52]);
    uart_send_som("></StopMoney>");
    
    uart_send_som("<Fee><");//Ʊ��
    SEND_asic_2th(record[53]);
    SEND_asic_2th(record[54]);
    SEND_asic_2th(record[55]);
    SEND_asic_2th(record[56]);
    uart_send_som("></Fee>");
    
    uart_send_som("<LeftMoney><");//���׺���
    SEND_asic_2th(record[57]);
    SEND_asic_2th(record[58]);
    SEND_asic_2th(record[59]);
    SEND_asic_2th(record[60]);
    uart_send_som("></LeftMoney>");
    
    uart_send_som("<RCtype><");//��������  
    SEND_asic_2th(record[61]);
    uart_send_som("></RCtype>");
    
    uart_send_som("<ExRCtype><");//���ӽ�������  
    SEND_asic_2th(record[62]);
    uart_send_som("></ExRCtype>");
    
    uart_send_som("<ChargeCount><");//Ʊ����ֵ���׼���  
    SEND_asic_2th(record[63]);
    SEND_asic_2th(record[64]);
    uart_send_som("></ChargeCount>");
    
    uart_send_som("<ConsumeCount><");//Ʊ�����ѽ��׼���  
    SEND_asic_2th(record[65]);
    SEND_asic_2th(record[66]);
    uart_send_som("></ConsumeCount>");
    
    uart_send_som("<PrevMetreCode><");//�ϴν����豸��ţ������
    SEND_asic_2th(record[67]);
    SEND_asic_2th(record[68]);
    SEND_asic_2th(record[69]);
    SEND_asic_2th(record[70]);
    SEND_asic_2th(record[71]);
    SEND_asic_2th(record[72]);
    uart_send_som("></PrevMetreCode>");
    
    uart_send_som("<PrevRCtime><");//�ϴν�������ʱ��
    SEND_asic_2th(record[73]);
    SEND_asic_2th(record[74]);
    uart_send_som("-");
    SEND_asic_2th(record[75]);
    uart_send_som("-");
    SEND_asic_2th(record[76]);
    uart_send_som(" ");
    SEND_asic_2th(record[77]);
    uart_send_som(":");
    SEND_asic_2th(record[78]);
    uart_send_som(":");
    SEND_asic_2th(record[79]);
    uart_send_som("></PrevRCtime>");
    
    uart_send_som("<TAC><");//TAC
    SEND_asic_2th(record[80]);
    SEND_asic_2th(record[81]);
    SEND_asic_2th(record[82]);
    SEND_asic_2th(record[83]);
    uart_send_som("></TAC>");
    
    uart_send_som("<remark1><");//����
    SEND_asic_2th(0);
    uart_send_som("></remark1>");
    
    uart_send_som("<remark2><");//����
    SEND_asic_2th(0);
    uart_send_som("></remark2>");
    
    uart_send_som("<Ptype><");//����·�����ͣ���¼����2     1��2��3���4��λ
    SEND_asic_2th(record[105]);
    uart_send_som("></Ptype>");
    
    uart_send_som("<Stopetype><");//����·�����ͣ�֧������     1 IC��2.��Ƶ��
    SEND_asic_2th(1);
    uart_send_som("></Stopetype>");
    
    uart_send_som("#");  
    
}

//���� ��ʼ��������Ϣ 2015-12-07
void ini_rpt_info(void)
{
u8 rptimg[32];

//	I2C_ReadS_24C(SYSPRO_JD_APP,rptimg,16);	
//	I2C_ReadS_24C(SYSPRO_JD_BOOTLOADER,rptimg+16,16);	
	memset(rptimg,0x00,24);
	
	I2C_WriteS_24C(RPT_ADD,rptimg,24);	
	I2C_WriteS_24C(RPT_ADD+24,rptimg,24);	
	
	I2C_ReadS_24C(SYSPRO_JD_APP,rptimg,16);	
	I2C_ReadS_24C(SYSPRO_JD_BOOTLOADER,rptimg+16,16);	
//		{
//		//strcat(rptimg,"LUO151210P");
//		I2C_WriteS_24C(SYSPRO_JD_APP,"LUO151210P",10);	
//		I2C_WriteS_24C(SYSPRO_JD_BOOTLOADER,"LUO151210P",10);	
//		}
	
}
	
//���� �洢������Ϣ 2015-12-07
void deal_rpt_info(void)
{
	u8 flag,RPT_RD[3],isum,mon,day,week,rptimg[80],timeOut;
//	u16 RPTADD;
	u32 RDSUM,mny;
	
	

	isum = 3;
	//��48�ֽ�
	rptimg[0] = 0x0D;//1-����  2-����(����) 3-����(���)D-������Ϣ���ݶ���
	I2C_ReadS_24C(RPT_MF1_DAY_INFO,rptimg+1,24);	
	I2C_ReadS_24C(RPT_MF1_DAY_INFO+24,rptimg+25,24);	
	RDSUM = ReturnRecordCount();
	fll(RDSUM,rptimg+49,2);

	Smart_Power_ON;
	delay(KEYTIMEOUT_1S / 2);
	//4.���������
	timeOut = 3;
	while(timeOut--)
		{
		Smart_Power_ON;
		flag = Read_ReaderVer();
		if(flag==0)break;		
		}
	if(flag!=0)RPT_RD[0] =0x55;
	else RPT_RD[0] =0x00;
	memcpy(rptimg+51,RPT_RD,1);
//	memcpy(rptimg+51,RxBuffer+3,5);
	
	timeOut = 0;
	 //5.PSAM�����
	 timeOut = 0;
	 RPT_RD[0] = 0x55;
	 while(timeOut < 4)
		{
		if(read_PSAM() == 0x00)
			{
			RPT_RD[0] = 0;
			break;
			}
		timeOut++;
		}	 
	Smart_Power_OFF;	
	memcpy(rptimg+52,RPT_RD,1);
	RPT_RD[0] = LowVoltage_Test();
	if(RPT_RD[0])RPT_RD[0]=0;
	else RPT_RD[0] = 0x55;
	memcpy(rptimg+53,RPT_RD,1);
	I2C_ReadS_24C(LISTNET_ADD,rptimg+54,10);	
	//rptimg+71-
    I2C_ReadS_24C(Con_Flash_Record_16_UDCSR,rptimg+64,3);//���͵��α�        
    I2C_ReadS_24C(Con_Flash_Record_16_Cursor,rptimg+67,3);//���¼���α�
    I2C_ReadS_24C(Con_Flash_Record_112_UDCSR,rptimg+70,3);//���͵��α�        
    I2C_ReadS_24C(Con_Flash_Record_112_Cursor,rptimg+73,3);//���¼���α�
//	memset(rptimg+76,0xDD,4);
	I2C_ReadS_24C(SYS_1STRUN,rptimg+76,2);	
	I2C_ReadS_24C(SYS_LOCKCPC,rptimg+78,2);	
	
		
	Save_Record(rptimg,80); //��ʱ���� 2016-04-06
	
	mon = BCDtoHex(time[3]);
	day = BCDtoHex(time[2]);	
	week = mathweek(time[4],time[3],time[2]); 
	mny = 0;
	fll(mny,RPT_RD,isum);
	if((mon ==1)&&(day ==1))
		{
		I2C_WriteS_24C(RPT_MF1_YEAR_INFO,RPT_RD,isum);	
		I2C_WriteS_24C(RPT_CPC_YEAR_INFO,RPT_RD,isum);	
		}
	if(((mon%3) ==0)&&(day ==1))
		{
		I2C_WriteS_24C(RPT_MF1_QTY_INFO,RPT_RD,isum);	
		I2C_WriteS_24C(RPT_CPC_QTY_INFO,RPT_RD,isum);	
		}
	if(day ==1)
		{
		I2C_WriteS_24C(RPT_MF1_MON_INFO,RPT_RD,isum);	
		I2C_WriteS_24C(RPT_CPC_MON_INFO,RPT_RD,isum);	
		}
	if(week ==1)
		{
		I2C_WriteS_24C(RPT_MF1_WEEK_INFO,RPT_RD,isum);	
		I2C_WriteS_24C(RPT_CPC_WEEK_INFO,RPT_RD,isum);	
		}	
	I2C_WriteS_24C(RPT_MF1_DAY_INFO,RPT_RD,isum);	
	I2C_WriteS_24C(RPT_CPC_DAY_INFO,RPT_RD,isum);	
	
	
}
//�շѱ��� 2015-12-07 save_RPTMNY_record(CardType_MF1,);
void save_RPTMNY_record(u8 rpts,u16 feemoney)
{
u8 flag,RPT_RD[3],isum,ydfalg;
//u16 RPTADD;
u32 RDSUM;
	
	isum = 3;
	flag = rpts;
	if(flag==CardType_MF1)
		{
		I2C_ReadS_24C(RPT_MF1_DAY_INFO,RPT_RD,isum);
		RDSUM = hcl(RPT_RD,isum);	
		RDSUM += feemoney;
		fll(RDSUM,RPT_RD,isum);
		I2C_WriteS_24C(RPT_MF1_DAY_INFO,RPT_RD,isum);
		I2C_ReadS_24C(RPT_MF1_WEEK_INFO,RPT_RD,isum);
		RDSUM = hcl(RPT_RD,isum);	
		RDSUM += feemoney;
		fll(RDSUM,RPT_RD,isum);
		I2C_WriteS_24C(RPT_MF1_WEEK_INFO,RPT_RD,isum);
		I2C_ReadS_24C(RPT_MF1_MON_INFO,RPT_RD,isum);
		RDSUM = hcl(RPT_RD,isum);	
		RDSUM += feemoney;
		fll(RDSUM,RPT_RD,isum);
		I2C_WriteS_24C(RPT_MF1_MON_INFO,RPT_RD,isum);
		
		ydfalg =0;
#ifdef  ZG_MBSYSTEM
		ydfalg = 1;
#endif
		if(((TMP.cardplace == CardType_ZGMF1RD)&&(ydfalg != 1))||
			((TMP.cardplace != CardType_ZGMF1RD)&&(ydfalg == 1)))
			{
			I2C_ReadS_24C(RPT_MF1_QTY_INFO,RPT_RD,isum);//������Ϊ��ؿ�ʹ�� 2015-12-19
			RDSUM = hcl(RPT_RD,isum);	
			RDSUM += feemoney;
			fll(RDSUM,RPT_RD,isum);
			I2C_WriteS_24C(RPT_MF1_QTY_INFO,RPT_RD,isum);
			}
		
		I2C_ReadS_24C(RPT_MF1_YEAR_INFO,RPT_RD,isum);
		RDSUM = hcl(RPT_RD,isum);	
		RDSUM += feemoney;
		fll(RDSUM,RPT_RD,isum);
		I2C_WriteS_24C(RPT_MF1_YEAR_INFO,RPT_RD,isum);	
		}
	else
		{
		I2C_ReadS_24C(RPT_CPC_DAY_INFO,RPT_RD,isum);
		RDSUM = hcl(RPT_RD,isum);	
		RDSUM += feemoney;
		fll(RDSUM,RPT_RD,isum);
		I2C_WriteS_24C(RPT_CPC_DAY_INFO,RPT_RD,isum);
		I2C_ReadS_24C(RPT_CPC_WEEK_INFO,RPT_RD,isum);
		RDSUM = hcl(RPT_RD,isum);	
		RDSUM += feemoney;
		fll(RDSUM,RPT_RD,isum);
		I2C_WriteS_24C(RPT_CPC_WEEK_INFO,RPT_RD,isum);
		I2C_ReadS_24C(RPT_CPC_MON_INFO,RPT_RD,isum);
		RDSUM = hcl(RPT_RD,isum);	
		RDSUM += feemoney;
		fll(RDSUM,RPT_RD,isum);
		I2C_WriteS_24C(RPT_CPC_MON_INFO,RPT_RD,isum);
		I2C_ReadS_24C(RPT_CPC_QTY_INFO,RPT_RD,isum);
		RDSUM = hcl(RPT_RD,isum);	
		RDSUM += feemoney;
		fll(RDSUM,RPT_RD,isum);
		I2C_WriteS_24C(RPT_CPC_QTY_INFO,RPT_RD,isum);
		I2C_ReadS_24C(RPT_CPC_YEAR_INFO,RPT_RD,isum);
		RDSUM = hcl(RPT_RD,isum);	
		RDSUM += feemoney;
		fll(RDSUM,RPT_RD,isum);
		I2C_WriteS_24C(RPT_CPC_YEAR_INFO,RPT_RD,isum);	
		}
}


//�������� 2015-12-07
void save_RPT_record(u8 rpts)
{
u8 flag,RPT_RD[3],isum;
u16 RPTADD;
u32 RDSUM;
	
	isum = 1;
	flag = rpts;
	switch(flag)
		{
		case 0x01: RPTADD = RPT_MF1_DAYTM1_INFO;isum = 2;break;
		case 0x02: RPTADD = RPT_MF1_DAYTM2_INFO;isum = 2;break;
		case 0x03: RPTADD = RPT_MF1_DAYTM3_INFO;isum = 1;break;
		case 0x04: RPTADD = RPT_MF1_DAYTM4_INFO;isum = 1;break;
		case 0x05: RPTADD = RPT_MF1_DAYTM5_INFO;isum = 1;break;
		case 0x06: RPTADD = RPT_MF1_DAYTM6_INFO;isum = 1;break;
		case 0x07: RPTADD = RPT_MF1_DAYTM7_INFO;isum = 1;break;
		case 0x09: RPTADD = RPT_MF1_DAYTM9_INFO;isum = 1;break;
		case 0x0e: RPTADD = RPT_MF1_DAYTME_INFO;isum = 1;break;
		case 0xc1: RPTADD = RPT_FEERD_DAY_INFO;isum = 2;break;
		case 0xc2: RPTADD = RPT_ACTRD_DAY_INFO;isum = 2;break;	
		}
	
	I2C_ReadS_24C(RPTADD,RPT_RD,isum);
	RDSUM = hcl(RPT_RD,isum);	
	RDSUM++;
	fll(RDSUM,RPT_RD,isum);
	I2C_WriteS_24C(RPT_MF1_DAYTM1_INFO,RPT_RD,isum);
}


// �м̴����洢�����¼
void Save_Record_MbtoBase(uchar buffer[],uchar count)
{
  uchar flash_buf[112],Fm_buffer[112];  
  uchar flash_count_buf[2],Fm_count_buf[2];  
  uchar flash_start_buf[4],fm_start_buf[4];  
  uchar flash_end_buf[4],fm_end_buf[4];  
  uchar buf[2];  
  unsigned long f1,f2,Fm_count,Flash_count;  
  unsigned long flash_end_count,fm_end_count;  
  u8 kkk,mbno[4];;//

  if(count == 32)//��������ֽ�������¼��ˮ�� 2015-08-07
  	{
//	save_RPT_record(buffer[19]);	
//	save_RPT_record(0xc1);	
	I2C_ReadS_24C(Con_Flash_Record_16_Cursor,flash_buf,3);  //�� FLASH �ĵ�ַ
  	I2C_ReadS_24C(Con_Flash_Record_16_Count,flash_count_buf,2);  //�� FLASH ������
  	I2C_ReadS_24C(Con_Flash_Record_16_End_Addr,flash_end_buf,3);  //�� FLASH �Ľ�����ַ
  	I2C_ReadS_24C(Con_Flash_Record_16_Start_Addr,flash_start_buf,3);  //�� FLASH �Ŀ�ʼ��ַ
  
  	I2C_ReadS_24C(Con_Fm_Record_16_Cursor,Fm_buffer,2);  //�� ���� �ĵ�ַ
  	I2C_ReadS_24C(Con_Fm_Record_16_Count,Fm_count_buf,2);  //�� ���� ������
  	I2C_ReadS_24C(Con_Fm_Record_16_End_Addr,fm_end_buf,2);  //�� ���� �Ľ�����ַ
  	I2C_ReadS_24C(Con_Fm_Record_16_Start_Addr,fm_start_buf,2);  //�� ���� �Ŀ�ʼ��ַ
  	}
  else if(count == 80)
  	{	
//	save_RPT_record(0xc2);	
	I2C_ReadS_24C(Con_Flash_Record_112_Cursor,flash_buf,3);  //�� FLASH �ĵ�ַ
	I2C_ReadS_24C(Con_Flash_Record_112_Count,flash_count_buf,2);  //�� FLASH ������
    I2C_ReadS_24C(Con_Flash_Record_112_End_Addr,flash_end_buf,3);  //�� FLASH �Ľ�����ַ
    I2C_ReadS_24C(Con_Flash_Record_112_Start_Addr,flash_start_buf,3);  //�� FLASH �Ŀ�ʼ��ַ
  
    I2C_ReadS_24C(Con_Fm_Record_112_Cursor,Fm_buffer,2);  //�� ���� �ĵ�ַ
    I2C_ReadS_24C(Con_Fm_Record_112_Count,Fm_count_buf,2);  //�� ���� ������
    I2C_ReadS_24C(Con_Fm_Record_112_End_Addr,fm_end_buf,2);  //�� ���� �Ľ�����ַ
    I2C_ReadS_24C(Con_Fm_Record_112_Start_Addr,fm_start_buf,2);  //�� ���� �Ŀ�ʼ��ַ
 	}
  else
  	{
	}
  
  f1 = hcl(flash_buf,3);  
  f2 = hcl(Fm_buffer,2);
  
  flash_end_count = hcl(flash_end_buf,3);//������ַ
  fm_end_count = hcl(fm_end_buf,2);
  
  Fm_count = hcl(Fm_count_buf,2);//����
  Flash_count = hcl(flash_count_buf,2);
  
  if(f1 >= flash_end_count)
  	{
	f1 = hcl(flash_start_buf,3); //�ӿ�ʼ��ַ ��ʼ��
      
    //д���� ��ַ��־λ
    buf[0] = 0x01;
	if(count == 32)
		{
		I2C_WriteS_24C(Con_Flash_Record_16_Cursor_F,buf,1);
		}
	else if(count == 80)
	  	{
		I2C_WriteS_24C(Con_Flash_Record_112_Cursor_F,buf,1);
		}
	else
	  	{
		}  
	}  
  if(f2 >= fm_end_count)
  	{
	f2 = hcl(fm_start_buf,2); //�ӿ�ʼ��ַ ��ʼ��   
    //д���� ��ַ��־λ
    buf[0] = 0x01;
	if(count == 32)
		{
		I2C_WriteS_24C(Con_Fm_Record_16_Cursor_F,buf,1);
		}
	else if(count == 80)
		{
		I2C_WriteS_24C(Con_Fm_Record_112_Cursor_F,buf,1);
		}
	else
		{
		} 
	}   
  SPI_FLASH_Init();
  SPI_FLASH_BufferRead(flash_buf,f1,count);
  xxxx=0;
  for(kkk=0;kkk<count;kkk++)
  	{
	if(flash_buf[kkk]!=0xff)
		{
		xxxx=1;
		break;
		}
	}
  if(xxxx)
  	SPI_FLASH_SectorErase(f1);
  //Erased_sector();
  //SPI_FLASH_Init();
  SPI_FLASH_BufferWrite(buffer,f1,count);
  SPI_FLASH_BufferRead(flash_buf,f1,count);
////////////////////////////////////////////////////////////////////////////////  
  xxxx=0;
  for(kkk=0;kkk<count;kkk++)
  	{
	if(buffer[kkk]!=flash_buf[kkk])
		{
		xxxx=1;
		break;
		}
	}                
  I2C_WriteS_24C(f2,buffer,count);  
  I2C_ReadS_24C(f2,Fm_buffer,count);
  //////////////////////////////////
  xxxx=0;
  for(kkk=0;kkk<count;kkk++)
  	{
	if(buffer[kkk]!=Fm_buffer[kkk])
		{
		xxxx=1;
		break;
		}
	}  
  f1 = f1 + count;
  f2 = f2 + count;
  fll(f1,flash_buf,3);
  fll(f2,Fm_buffer,2);
  
  Fm_count++;
  Flash_count++;
  
  if(Fm_count >= 0xffff)//(0X7F80-0X5A00)/32
    Fm_count = 0x0000;
  
  if(Flash_count >= 0xffff)//(0X193500-0X0D0000)/32
    Flash_count = 0x0000;
  
  fll(Fm_count,Fm_count_buf,2);
  fll(Flash_count,flash_count_buf,2);
  if(count == 32)
  	{
	I2C_WriteS_24C(Con_Flash_Record_16_Cursor,flash_buf,3);  //д FLASH �ĵ�ַ
    I2C_WriteS_24C(Con_Flash_Record_16_Count,flash_count_buf,2);  //д FLASH ������
      
    I2C_WriteS_24C(Con_Fm_Record_16_Cursor,Fm_buffer,2);  //д ���� �ĵ�ַ
    I2C_WriteS_24C(Con_Fm_Record_16_Count,Fm_count_buf,2);  //д ���� ������
  	}
  else if(count == 80)
  	{
    I2C_WriteS_24C(Con_Flash_Record_112_Cursor,flash_buf,3);  //д FLASH �ĵ�ַ
    I2C_WriteS_24C(Con_Flash_Record_112_Count,flash_count_buf,2);  //�� FLASH ������
      
    I2C_WriteS_24C(Con_Fm_Record_112_Cursor,Fm_buffer,2);  //д ���� �ĵ�ַ
    I2C_WriteS_24C(Con_Fm_Record_112_Count,Fm_count_buf,2);  //д ���� ������
  	}
  else
  	{
	}  
}



// ��һ������������Ҫ���
void Save_Record(uchar buffer[],uchar count)
{
  uchar flash_buf[112],Fm_buffer[112];
  
  uchar flash_count_buf[2],Fm_count_buf[2];
  
  uchar flash_start_buf[4],fm_start_buf[4];
  
  uchar flash_end_buf[4],fm_end_buf[4];
  
  uchar buf[2];
  
  unsigned long f1,f2;
  unsigned long Fm_count,Flash_count;
  
  unsigned long flash_end_count,fm_end_count;
  uchar kkk,mbno[4];;//

//�̶�λ�ò�������� 2015-04-15 10:49:16 andyluo
  I2C_ReadS_24C(mibiao_number,mbno,3);
//  buffer[1] = 0x00;
//  buffer[2] = mbno[0];
//  buffer[3] = mbno[1];
//  buffer[4] = mbno[2];
  

  
  if(count == 32)//��������ֽ�������¼��ˮ�� 2015-08-07
  	{
	save_RPT_record(buffer[19]);	
	save_RPT_record(0xc1);	
	
//#ifdef ZG_MBSYSTEM
//	buffer[1] = ZGMBADD_CODE;
//#else
//	{
//#ifdef WL_MBSYSTEM
//	buffer[1] = WLMBADD_CODE;
//#else
//	buffer[1] = LOCALMBADD_CODE;
//#endif
//	}
//#endif
	buffer[1] = mbno[2];

	switch(buffer[25])
		{
	//		case CardType_MF1: buffer[25] = CardType_MF1RD;break;
		case CardType_IC:  break;
		case CardType_CPU: break;
		case CardType_MF1: buffer[25] = TMP.cardplace;break;
		case CardType_BIKE: buffer[25] = CardType_BIKERD;break;
		case CardType_CPC: buffer[25] = CardType_CPCRD;break;
		default: buffer[25] = TMP.cardplace;break;
	  	}
	
#ifdef WZ_MBSYSTEM
	if(buffer[25]==CardType_MF1)
		buffer[25] = CardType_MF1RD;
#elif defined IN_MBSYSTEM
	buffer[25] = CardType_MF1RD;
#endif

	I2C_ReadS_24C(SYS_FEESN,buf,2);
	f1=hcl(buf,2);
	f1 += 1;
	fll(f1,buf,2);
	I2C_WriteS_24C(SYS_FEESN,buf,2);
	memcpy(buffer+30,buf,2);

	I2C_ReadS_24C(Con_Flash_Record_16_Cursor,flash_buf,3);  //�� FLASH �ĵ�ַ
  	I2C_ReadS_24C(Con_Flash_Record_16_Count,flash_count_buf,2);  //�� FLASH ������
  	I2C_ReadS_24C(Con_Flash_Record_16_End_Addr,flash_end_buf,3);  //�� FLASH �Ľ�����ַ
  	I2C_ReadS_24C(Con_Flash_Record_16_Start_Addr,flash_start_buf,3);  //�� FLASH �Ŀ�ʼ��ַ
  
  	I2C_ReadS_24C(Con_Fm_Record_16_Cursor,Fm_buffer,2);  //�� ���� �ĵ�ַ
  	I2C_ReadS_24C(Con_Fm_Record_16_Count,Fm_count_buf,2);  //�� ���� ������
  	I2C_ReadS_24C(Con_Fm_Record_16_End_Addr,fm_end_buf,2);  //�� ���� �Ľ�����ַ
  	I2C_ReadS_24C(Con_Fm_Record_16_Start_Addr,fm_start_buf,2);  //�� ���� �Ŀ�ʼ��ַ
  	}
  else if(count == 80)
  	{
	
	save_RPT_record(0xc2);	
//CardType;  //1-����  2-����(����) 3-����(���)D-������Ϣ���ݶ���
//WL_MBSYSTEM �������
//ZG_MBSYSTEM ������
	  if(buffer[0] != 0x0D)//������Ϣ  2015-12-07
		{
#ifdef ZG_MBSYSTEM
		buffer[0] = 0x03;
#else
		buffer[0] = 0x02;
#endif
		}
      I2C_ReadS_24C(Con_Flash_Record_112_Cursor,flash_buf,3);  //�� FLASH �ĵ�ַ
      I2C_ReadS_24C(Con_Flash_Record_112_Count,flash_count_buf,2);  //�� FLASH ������
      I2C_ReadS_24C(Con_Flash_Record_112_End_Addr,flash_end_buf,3);  //�� FLASH �Ľ�����ַ
      I2C_ReadS_24C(Con_Flash_Record_112_Start_Addr,flash_start_buf,3);  //�� FLASH �Ŀ�ʼ��ַ
      
      I2C_ReadS_24C(Con_Fm_Record_112_Cursor,Fm_buffer,2);  //�� ���� �ĵ�ַ
      I2C_ReadS_24C(Con_Fm_Record_112_Count,Fm_count_buf,2);  //�� ���� ������
      I2C_ReadS_24C(Con_Fm_Record_112_End_Addr,fm_end_buf,2);  //�� ���� �Ľ�����ַ
      I2C_ReadS_24C(Con_Fm_Record_112_Start_Addr,fm_start_buf,2);  //�� ���� �Ŀ�ʼ��ַ
 	}
  else
  {
      
  }
  
  f1 = hcl(flash_buf,3);  
  f2 = hcl(Fm_buffer,2);
  
  flash_end_count = hcl(flash_end_buf,3);//������ַ
  fm_end_count = hcl(fm_end_buf,2);
  
  Fm_count = hcl(Fm_count_buf,2);//����
  Flash_count = hcl(flash_count_buf,2);
  
  if(f1 >= flash_end_count)
  {
      f1 = hcl(flash_start_buf,3); //�ӿ�ʼ��ַ ��ʼ��
      
      //д���� ��ַ��־λ
      buf[0] = 0x01;
      if(count == 32)
      {
          I2C_WriteS_24C(Con_Flash_Record_16_Cursor_F,buf,1);
      }
      else if(count == 80)
      {
          I2C_WriteS_24C(Con_Flash_Record_112_Cursor_F,buf,1);
      }
      else
      {
          
      }     
  }
  
  if(f2 >= fm_end_count)
  {
      f2 = hcl(fm_start_buf,2); //�ӿ�ʼ��ַ ��ʼ��
      
      //д���� ��ַ��־λ
      buf[0] = 0x01;
      if(count == 32)
      {
          I2C_WriteS_24C(Con_Fm_Record_16_Cursor_F,buf,1);
      }
      else if(count == 80)
      {
          I2C_WriteS_24C(Con_Fm_Record_112_Cursor_F,buf,1);
      }
      else
      {
          
      }     
  } 
  
  SPI_FLASH_Init();
  SPI_FLASH_BufferRead(flash_buf,f1,count);
  xxxx=0;
  for(kkk=0;kkk<count;kkk++)
  	{
	if(flash_buf[kkk]!=0xff)
		{
		xxxx=1;
		break;
		}
	}
  if(xxxx)
  	SPI_FLASH_SectorErase(f1);
  //Erased_sector();
  //SPI_FLASH_Init();
  SPI_FLASH_BufferWrite(buffer,f1,count);
  SPI_FLASH_BufferRead(flash_buf,f1,count);
////////////////////////////////////////////////////////////////////////////////  
  xxxx=0;
  for(kkk=0;kkk<count;kkk++)
  	{
	if(buffer[kkk]!=flash_buf[kkk])
		{
		xxxx=1;
		break;
		}
	}
                
  I2C_WriteS_24C(f2,buffer,count);  
  I2C_ReadS_24C(f2,Fm_buffer,count);
  //////////////////////////////////
  xxxx=0;
  for(kkk=0;kkk<count;kkk++)
  	{
	if(buffer[kkk]!=Fm_buffer[kkk])
		{
		xxxx=1;
		break;
		}
	}
  
  f1 = f1 + count;
  f2 = f2 + count;
  fll(f1,flash_buf,3);
  fll(f2,Fm_buffer,2);
  
  Fm_count++;
  Flash_count++;
  
  if(Fm_count >= 0xffff)//(0X7F80-0X5A00)/32
    Fm_count = 0x0000;
  
  if(Flash_count >= 0xffff)//(0X193500-0X0D0000)/32
    Flash_count = 0x0000;
  
  fll(Fm_count,Fm_count_buf,2);
  fll(Flash_count,flash_count_buf,2);
  if(count == 32)
  {
      I2C_WriteS_24C(Con_Flash_Record_16_Cursor,flash_buf,3);  //д FLASH �ĵ�ַ
      I2C_WriteS_24C(Con_Flash_Record_16_Count,flash_count_buf,2);  //д FLASH ������
      
      I2C_WriteS_24C(Con_Fm_Record_16_Cursor,Fm_buffer,2);  //д ���� �ĵ�ַ
      I2C_WriteS_24C(Con_Fm_Record_16_Count,Fm_count_buf,2);  //д ���� ������
  }
  else if(count == 80)
  {
      I2C_WriteS_24C(Con_Flash_Record_112_Cursor,flash_buf,3);  //д FLASH �ĵ�ַ
      I2C_WriteS_24C(Con_Flash_Record_112_Count,flash_count_buf,2);  //�� FLASH ������
      
      I2C_WriteS_24C(Con_Fm_Record_112_Cursor,Fm_buffer,2);  //д ���� �ĵ�ַ
      I2C_WriteS_24C(Con_Fm_Record_112_Count,Fm_count_buf,2);  //д ���� ������
  }
  else
  {
      
  }
  
}



//�Է���ÿ�µ�һ������ǰ�� ��ʼ��
void InitMifareParameter(void)
{
    uchar buffer_1[4];
    uint32_t SectorAddr;
    
    SectorAddr =0x0C0000;
    SPI_FLASH_Init();
    SPI_FLASH_SectorErase(SectorAddr);

    
    //������Ҫ�� ������ �ռ������������� �� ��ַ�ĳ�ʼ��
    
    /////////////////////////////�Է�����������ַ��ʼ��/////////////////////10000�� ÿ��4�ֽ�        
    //�Է��� ������������ 7000��
    buffer_1[0] = 0x00;
    buffer_1[1] = 0x0C;
    buffer_1[2] = 0x35;
    buffer_1[3] = 0x00;
    I2C_WriteS_24C(MIFARE_BACLK_DAY_ADD_AC,buffer_1,4); //��ʼ��ַ
    I2C_WriteS_24C(MIFARE_BACLK_Cursor_day,buffer_1,4);//������������ �α��ַ
        
    buffer_1[0] = 0x00;
    buffer_1[1] = 0x0C;
    buffer_1[2] = 0xA2;
    buffer_1[3] = 0x60;
    I2C_WriteS_24C(MIFARE_BACLK_DAY_ADD_AC + 4,buffer_1,4); //������ַ
        
    buffer_1[0] = 0x00;
    buffer_1[1] = 0x00;
    buffer_1[2] = 0x00;
    buffer_1[3] = 0x00;
    I2C_WriteS_24C(MIFARE_BACLK_DAY_ADD_AC + 8,buffer_1,4); //����������
    I2C_WriteS_24C(MIFARE_BACLK_ALLCount_DAY ,buffer_1,2);
    I2C_WriteS_24C(MIFARE_BACLK_RequitPage_DAY ,buffer_1,2);
        
    //�Է��� �ռ��������� 5992��
    buffer_1[0] = 0x00;
    buffer_1[1] = 0x0C;
    buffer_1[2] = 0xA2;
    buffer_1[3] = 0x60;
    I2C_WriteS_24C(MIFARE_BACLK_DAY_REDUC_AC,buffer_1,4); //��ʼ��ַ
    I2C_WriteS_24C(MIFARE_BACLK_Cursor_day_reduce,buffer_1,4);//������������ �α��ַ
        
    buffer_1[0] = 0x00;
    buffer_1[1] = 0x0D;
    buffer_1[2] = 0x00;
    buffer_1[3] = 0x00;
    I2C_WriteS_24C(MIFARE_BACLK_DAY_REDUC_AC + 4,buffer_1,4); //������ַ
        
    buffer_1[0] = 0x00;
    buffer_1[1] = 0x00;
    buffer_1[2] = 0x00;
    buffer_1[3] = 0x00;
    I2C_WriteS_24C(MIFARE_BACLK_DAY_REDUC_AC + 8,buffer_1,4); //����������  
    I2C_WriteS_24C(MIFARE_BACLK_ALLCount_Reduce ,buffer_1,2);
    I2C_WriteS_24C(MIFARE_BACLK_RequitPage_Reduce ,buffer_1,2);
    ////////////////////////////////////////////////////////////////////////
}


//ȫ�����غ�����
void Download_backList_All(u16 DownCount,uchar ClassFlag)
{
    uchar LosePage;
    uchar delay_time;
    uchar TimeRequit;
    uchar BCC;
    u16 CodeCount;
    uchar TestBcc;
    u16 backList_count;
    uchar buffer[16];
    uchar BL_Addr_buf[4];
    uchar BL_End_Addr_buf[4];
    uchar BL_Count_buf[4];
    uchar RequitPage[2];
    uint32_t SectorAddr;
    unsigned long BL_Addr;
    unsigned long BL_End_addr;
    unsigned long BL_Count;
    unsigned long AllBackListCount;
    uchar BL_buffer[64 * 8];
    uchar Test_buf[64 * 8];
    int count;
    uchar timeOut;
    uchar buffer_1[16];        
    count = 64 * 8;
    
    SPI_FLASH_Init();
    if(DownCount == 1 && ClassFlag == LNT_ALL)//��1������ �����ʼ��
    {
        SectorAddr =0x000000;    
        while(SectorAddr < 0x0C0000) //����flash���� ����ͨȫ��������// �Է��� ���� �ռ��������� 
        {
            SPI_FLASH_SectorErase(SectorAddr);
            SectorAddr = SectorAddr + 0x010000;
        }   
        SectorAddr = 0x700000;
        while(SectorAddr < 0x750000) //����flash���� ����ͨ ���� �ռ��������� 
        {
            SPI_FLASH_SectorErase(SectorAddr);
            SectorAddr = SectorAddr + 0x010000;
        }
        
        //������Ҫ�� ������ �ռ������������� �� ��ַ�ĳ�ʼ��    
///////////////////////////////����ͨ��������////////////////////////////////////////  
        //////////////////////////// ȫ���������ĳ�ʼ�� ///////////////////////////////
        buffer_1[0] = 0x00;
        buffer_1[1] = 0x00;
        buffer_1[2] = 0x00;
        buffer_1[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count,buffer_1,4); //��ʼ��ַ
        I2C_WriteS_24C(BackList_Cursor,buffer_1,4);//д���������α��ַ
            
        buffer_1[0] = 0x00;
        buffer_1[1] = 0x0C;
        buffer_1[2] = 0x35;
        buffer_1[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count + 4,buffer_1,4); //������ַ
            
        buffer_1[0] = 0x00;
        buffer_1[1] = 0x00;
        buffer_1[2] = 0x00;
        buffer_1[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count + 8,buffer_1,4); //����������
        ///////////////////////////////////////////////////////////////////////////////
    
    
        ///////////////////////////���� �������ĳ�ʼ��/////////////////////////  30000��
        buffer_1[0] = 0x00;
        buffer_1[1] = 0x70;
        buffer_1[2] = 0x00;
        buffer_1[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count_day,buffer_1,4);//������������ �׵�ַ
        I2C_WriteS_24C(BackList_Cursor_day,buffer_1,4);//������������ �α��ַ
            
        buffer_1[0] = 0x00;
        buffer_1[1] = 0x73;
        buffer_1[2] = 0xA9;
        buffer_1[3] = 0x80;
        I2C_WriteS_24C(backList_Addr_and_Count_day + 4,buffer_1,4);//������������ ������ַ
            
        buffer_1[0] = 0x00;
        buffer_1[1] = 0x00;
        buffer_1[2] = 0x00;
        buffer_1[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count_day + 8,buffer_1,4); //���������� ����       
        ///////////////////////////////////////////////////////////////////////
                
        ///////////////////////////���� �������ĳ�ʼ��///////////////////////// 10960��
        buffer_1[0] = 0x00;
        buffer_1[1] = 0x73;
        buffer_1[2] = 0xA9;
        buffer_1[3] = 0x80;
        I2C_WriteS_24C(backList_Addr_and_Count_day_reduce,buffer_1,4);//������������ �׵�ַ
        I2C_WriteS_24C(BackList_Cursor_day_reduce,buffer_1,4);//������������ �α��ַ
            
        buffer_1[0] = 0x00;
        buffer_1[1] = 0x75;
        buffer_1[2] = 0x00;
        buffer_1[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count_day_reduce + 4,buffer_1,4);//������������ ������ַ
            
        buffer_1[0] = 0x00;
        buffer_1[1] = 0x00;
        buffer_1[2] = 0x00;
        buffer_1[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count_day_reduce + 8,buffer_1,4); //���������� ����        
        ///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
    
        //////////////////// ����ͨ������ �ϵ����������� ///////////////////////    
        buffer_1[0] = 0x00;
        buffer_1[1] = 0x00;
        //1.ȫ��
        I2C_WriteS_24C(RequitPageCount,buffer_1,2);
        I2C_WriteS_24C(BackListAllCount,buffer_1,2);
        
        //2.����
        I2C_WriteS_24C(LNT_BACLK_RequitPage_DAY,buffer_1,2);
        I2C_WriteS_24C(LNT_BACLKALLCount_DAY,buffer_1,2);
        
        //2.����
        I2C_WriteS_24C(LNT_BACLK_RequitPage_Reduce,buffer_1,2);
        I2C_WriteS_24C(LNT_BACLK_ALLCount_Reduce,buffer_1,2);
        //////////////////////////////////////////////////////////////////////
    }
    
    
    
    timeOut = 0;
    backList_count = DownCount;
 
    while(timeOut < 4)
    {
      delay_time = 12;      
      if(open_gprs() == 1)
      {       
         TimeRequit = 10;
         do
          {
                LosePage = 1;
              
                //��� ����֮ǰ���յ�����
                for(int i=0;i<RxCounter;i++)
                   RxBuffer[i]=0x00;                
                RxCounter = 0;
                f_receiveOK = 0;
                    
                for(int i=0;i<512;i++)
                   BL_buffer[i] = 0x00;
                    
                send_BackList_requestCommand(backList_count,ClassFlag);//ȫ���ķ�ʽ ����
                    
                for(int i=0;i<16;i++)
                   buffer[i] = 0x00;
                                                    
                error_flag = rec_gprs_L(delay_time,buffer);
                if(error_flag == NO)//���մ���
                   break;
                else if(error_flag == 0x03)//����
                  LosePage = 0;
                    
                //��Asic�� ת���� Hex
                for(int i=0;i<14;i++)
                   buffer[i] = asic_to_hex(buffer[i]);
                count = (buffer[15] - buffer[14]) / 2;
                   
                BCC = buffer[0] * 0x10 +buffer[1];
                CodeCount = buffer[2]*1000 + buffer[3]*100 + buffer[4]*10 + buffer[5];
                
                if(TimeRequit == 0)
                  break;
                
                if(CodeCount != count)//�������������� ���Ȳ�һ�£��������� �˰�
                {
                    TimeRequit--;
                    continue;
                }
                
                TestBcc = 0x00;
                for(int i=0;i< count;i++)
                {
                    BL_buffer[i] = asic_to_hex( RxBuffer[i * 2 + buffer[14] ])* 0x10 + asic_to_hex( RxBuffer[i * 2 + buffer[14] + 1]);
                    TestBcc = TestBcc ^ BL_buffer[i];
                }
                      
                if(BCC != TestBcc)//��������������BCCУ���� ��ͨ������������ �˰�
                {
                    TimeRequit--;
                    continue;
                }   
                    
                if(ClassFlag == LNT_ALL)
                {
                        I2C_ReadS_24C(BackList_Cursor,BL_Addr_buf,4);//��ַ�α�
                        I2C_ReadS_24C(backList_Addr_and_Count + 4,BL_End_Addr_buf,4);//������ַ
                        I2C_ReadS_24C(backList_Addr_and_Count + 8,BL_Count_buf,4);//����
                }      
                else if(ClassFlag == LNT_ADD)
                {
                        I2C_ReadS_24C(BackList_Cursor_day,BL_Addr_buf,4);//��ַ�α�
                        I2C_ReadS_24C(backList_Addr_and_Count_day + 4,BL_End_Addr_buf,4);//������ַ
                        I2C_ReadS_24C(backList_Addr_and_Count_day + 8,BL_Count_buf,4);//����
                }     
                else if(ClassFlag == LNT_DEC)
                {
                        I2C_ReadS_24C(BackList_Cursor_day_reduce,BL_Addr_buf,4);//��ַ�α�
                        I2C_ReadS_24C(backList_Addr_and_Count_day_reduce + 4,BL_End_Addr_buf,4);//������ַ
                        I2C_ReadS_24C(backList_Addr_and_Count_day_reduce + 8,BL_Count_buf,4);//����
                } 
                else if(ClassFlag == MIFARE_ADD || ClassFlag == MIFARE_ALL)//�Է��� ����
                {
                        I2C_ReadS_24C(MIFARE_BACLK_Cursor_day,BL_Addr_buf,4);//��ַ�α�
                        I2C_ReadS_24C(MIFARE_BACLK_DAY_ADD_AC + 4,BL_End_Addr_buf,4);//������ַ
                        I2C_ReadS_24C(MIFARE_BACLK_DAY_ADD_AC + 8,BL_Count_buf,4);//����
                } 
                else if(ClassFlag == MIFARE_DEC)//�Է��� ����
                {
                        I2C_ReadS_24C(MIFARE_BACLK_Cursor_day_reduce,BL_Addr_buf,4);//��ַ�α�
                        I2C_ReadS_24C(MIFARE_BACLK_DAY_REDUC_AC + 4,BL_End_Addr_buf,4);//������ַ
                        I2C_ReadS_24C(MIFARE_BACLK_DAY_REDUC_AC + 8,BL_Count_buf,4);//����
                } 
                else 
                  break;                  
                                                  
                BL_Addr = hcl(BL_Addr_buf,4);
                BL_End_addr = hcl(BL_End_Addr_buf,4);
                BL_Count = hcl(BL_Count_buf,4);
                    
                //����ַ����ı�����ʩ
                if(BL_Addr >= BL_End_addr)
                {
                    timeOut = 4;
                    GPRS_Power_OFF;
                    break;
                }
                   
                    
                SPI_FLASH_Init();
                if(BL_Addr + count >= BL_End_addr)
                {
                    count = BL_End_addr - BL_Addr;
                }
                SPI_FLASH_BufferWrite(BL_buffer,BL_Addr,count);
                SPI_FLASH_BufferRead(Test_buf,BL_Addr,count);
    
                if(count != 0)
                {
                        uchar CountUint;
                        
                        TimeRequit = 10;
                        BL_Addr = BL_Addr + count;
                        if(ClassFlag == LNT_ALL || ClassFlag == LNT_ADD || ClassFlag == LNT_DEC)
                          CountUint = 8;
                        else if(ClassFlag == MIFARE_DEC || ClassFlag == MIFARE_ADD || ClassFlag == MIFARE_ALL)
                          CountUint = 4;
                        BL_Count = BL_Count + count / CountUint;
                }
                    
                fll(BL_Addr,BL_Addr_buf,4);
                fll(BL_Count,BL_Count_buf,4);
                    
                    
                if(ClassFlag == LNT_ALL)//ȫ��
                {
                        I2C_WriteS_24C(BackList_Cursor,BL_Addr_buf,4);//д���������α��ַ
                        I2C_WriteS_24C(backList_Addr_and_Count + 8,BL_Count_buf,4);//д������������
                }      
                else if(ClassFlag == LNT_ADD)//����
                {
                        I2C_WriteS_24C(BackList_Cursor_day,BL_Addr_buf,4);//д���������α��ַ
                        I2C_WriteS_24C(backList_Addr_and_Count_day + 8,BL_Count_buf,4);//д������������
                }     
                else if(ClassFlag == LNT_DEC)//����
                {
                        I2C_WriteS_24C(BackList_Cursor_day_reduce,BL_Addr_buf,4);//д���������α��ַ
                        I2C_WriteS_24C(backList_Addr_and_Count_day_reduce + 8,BL_Count_buf,4);//д������������ 
                }   
                else if(ClassFlag == MIFARE_ADD || ClassFlag == MIFARE_ALL)//����
                {
                        I2C_WriteS_24C(MIFARE_BACLK_Cursor_day,BL_Addr_buf,4);//д���������α��ַ
                        I2C_WriteS_24C(MIFARE_BACLK_DAY_ADD_AC + 8,BL_Count_buf,4);//д������������ 
                } 
                else if(ClassFlag == MIFARE_DEC)//����
                {
                        I2C_WriteS_24C(MIFARE_BACLK_Cursor_day_reduce,BL_Addr_buf,4);//д���������α��ַ
                        I2C_WriteS_24C(MIFARE_BACLK_DAY_REDUC_AC + 8,BL_Count_buf,4);//д������������ 
                } 
                else 
                   break;            
                    
                AllBackListCount = buffer[6] * 0x1000 +buffer[7] * 0x100 + buffer[8] * 0x10 + buffer[9];

    #if 0
                if(ClassFlag == LNT_ALL || ClassFlag == MIFARE_ALL)//ȫ��
                      dispaly(1,3,(HZ + quan_1));
                else if(ClassFlag == LNT_ADD || ClassFlag == MIFARE_ADD )
                      dispaly(1,3,(HZ + zeng));
                else if(ClassFlag == LNT_DEC || ClassFlag == LNT_DEC)
                      dispaly(1,3,(HZ + jian_3));
                dispaly(1,4,(HZ + liang)); //
                dispaly(1,5,(HZ + xia)); //��
                dispaly(1,6,(HZ + zai_1));//��
                
                if(timeOut > 0)
                  LCD_display_symbol(1,16,4-timeOut,0);
                    
                lcd_clear_h(3);
                LCD_display_symbol(3,5,backList_count/1000%10,0);
                LCD_display_symbol(3,6,backList_count/100%10,0);
                LCD_display_symbol(3,7,backList_count/10%10,0);
                LCD_display_symbol(3,8,backList_count%10,0);
                    
                LCD_display_symbol(3,9,3,1);//  /
                
                LCD_display_symbol(3,10,AllBackListCount/1000%10,0);
                LCD_display_symbol(3,11,AllBackListCount/100%10,0);
                LCD_display_symbol(3,12,AllBackListCount/10%10,0);
                LCD_display_symbol(3,13,AllBackListCount%10,0);
    #endif
                                       
               //����Ҫ�� ��ʱ���󵽵İ��� ��������
               fll(backList_count,RequitPage,2);                
               if(count != 0)
               {
                 backList_count++;
               }                    
                    
               //�Ѻ�����������������������
               fll(AllBackListCount,BL_buffer,2);
               if(ClassFlag == LNT_ALL)//ȫ��
               {
                 I2C_WriteS_24C(RequitPageCount,RequitPage,2);
                 I2C_WriteS_24C(BackListAllCount,BL_buffer,2);//д�������� ȫ������
               }
               else if(ClassFlag == LNT_ADD)
               {
                 I2C_WriteS_24C(LNT_BACLK_RequitPage_DAY,RequitPage,2);
                 I2C_WriteS_24C(LNT_BACLKALLCount_DAY,BL_buffer,2);//д�������� ȫ������
               }
               else if(ClassFlag == LNT_DEC)
               {
                 I2C_WriteS_24C(LNT_BACLK_RequitPage_Reduce,RequitPage,2);
                 I2C_WriteS_24C(LNT_BACLK_ALLCount_Reduce,BL_buffer,2);//д�������� ȫ������
               }
               else if(ClassFlag == MIFARE_ADD || ClassFlag == MIFARE_ALL)
               {
                 I2C_WriteS_24C(MIFARE_BACLK_RequitPage_DAY,RequitPage,2);
                 I2C_WriteS_24C(MIFARE_BACLK_ALLCount_DAY,BL_buffer,2);//д�������� ȫ������
               }
               else if(ClassFlag == MIFARE_DEC)
               {
                 I2C_WriteS_24C(MIFARE_BACLK_RequitPage_Reduce,RequitPage,2);
                 I2C_WriteS_24C(MIFARE_BACLK_ALLCount_Reduce,BL_buffer,2);//д�������� ȫ������
               }
               else 
                 break;
               
          }
          while(backList_count <= AllBackListCount);
           
         GPRS_Power_OFF;
         if(LosePage == 0x00)//����
            timeOut++;
         else
            break;
                 
      }   
      else
      {
          GPRS_Power_OFF;
          timeOut++;
          timeOut++;
      }
      
     
    }
     
}

//2015-08-10  ���������ϱ�Э�� 
//ʱ��ͷ��ʵ� Զ������
//#<ErrorCode><AA1501301619005500220864320203300024010499120015020155002208643202033000240104991200AB></ErrorCode>*
//����˵��:
//AA	���ݱ�ʶ [1]
//150130161900  ������ʱ����[6]
//55002208643202033000240104991200  ��ǰ���ʲ���(�����������һ��)[16] 
//150201        �·�������������(���·�����дȫ00)[3]
//55002208643202033000240104991200  �·��ʲ���(�����������һ��)[16] 
//AB  У���루����������ȫ�����к�У�飩[1]	
//firstrun 1-�ϵ�ͬ�� 0-�Զ�ͬ��
void DownloadTimeAndFree(u8 firstrun)
{
	uchar delay_time;
	uchar BL_buffer[512],buffer[64],CarRstBuf[40];
	//int count;
	uchar timeOut,data[32],i,j,k,BCC;
	
	//count = 64 * 8; 	 
	timeOut = 0;
 
	while(timeOut < 2)
	{				 
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	  if(open_gprs() == OK)
	  	{ 		
		  //�������ʲ������趨
		  //�������֮ǰ���յ�����
		  RxCounter = 0;
		  f_receiveOK = 0;					
		  for(i=0;i<16;i++)
			  buffer[i] = 0x00;		  
		  delay_time = 8;
		  if(firstrun==2)
			  sendFreeCom(70);//�����ȷ�����������Ƿ����·��� ����
		  else if(firstrun==1)
			  sendFreeCom(60);//�����ȷ�����������Ƿ����·��� ����
		  else
		  	  sendFreeCom(6);//�����ȷ�����������Ƿ����·��� ����
		  i = rec_gprs_feeYW(delay_time);		  
		  if(i> 0)
		  	{
			BL_buffer[0] = RxBuffer[i];
			if(BL_buffer[0] != 'A')
				return;
			for(k=0,j=i;k<63;k++,j++,j++)
				BL_buffer[k] = (asic_to_hex(RxBuffer[j])<<4)+asic_to_hex(RxBuffer[j+1]);
//AA150130161900 55002208643202033000240104991200 150201 55002208643202033000240104991200AB
//			IAP_Night = 0;
//			IAP_Night = 1;//
			memcpy(CarRstBuf,RxBuffer+j,35);
			if((CarRstBuf[14]=='C')&& //<CarRST><OFF></CarRST>
			   (CarRstBuf[15]=='a')&&
			   (CarRstBuf[22]=='O')&&
			   (CarRstBuf[23]=='N'))
			   CarRstBuf[39]=ON;
			else
			   CarRstBuf[39]=OFF;
			I2C_ReadS_24C(SYS_CarRST,CarRstBuf+38,1);
			if(CarRstBuf[38]!=CarRstBuf[39])
				I2C_WriteS_24C(SYS_CarRST,CarRstBuf+39,1);//���ó��߸�λ���� 2015-10-17
			I2C_ReadS_24C(SYS_CarRST,CarRstBuf+38,1);

			LIST_UD[11] = 0;
			for(k=0;k<5;k++)
				data[4-k] = BL_buffer[k+1];
			set_current_time(data);
			I2C_WriteS_24C(SYS_NETFEE,BL_buffer+7,26);
			I2C_WriteS_24C(SYS_NETFEE+32,BL_buffer+33,3);
			I2C_WriteS_24C(SYS_NETFEE+35,BL_buffer+36,26);
//			if(k>=15)return;//������ʱ��
			if((BL_buffer[33]==0)||(BL_buffer[34]==0)||(BL_buffer[35]==0))
				memcpy(buffer,BL_buffer+7,26);//���·�������
			else if((time[4]>BL_buffer[33])||
				((BL_buffer[33]==time[4])&&(time[3]>BL_buffer[34]))||
				((BL_buffer[33]==time[4])&&(BL_buffer[34]==time[3])&&(time[2]>=BL_buffer[35])))
				memcpy(buffer,BL_buffer+36,26);
			else
				memcpy(buffer,BL_buffer+7,26);
			I2C_ReadS_24C(B_startTime_unit_of_hour,data,26);
			for(i=0,k=0;i<25;i++)
				{
				if(buffer[i]==data[i])
					k++;					
				}
			if(k>=26)return;//������ʱ��
			memcpy(data,buffer,26);
			
			BCC = 0x00;
			for(i=0;i<25;i++)
			  BCC = BCC ^ data[i];
			data[25] = BCC;			 
			
			I2C_WriteS_24C(B_startTime_unit_of_hour,data,26);
			I2C_WriteS_24C(back_argument_of_charge,data,26);

			//AA150130161900 55002208643202033000240104991200 150201 55002208643202033000240104991200AB
//			I2C_ReadS_24C(SYS_NETFEE,buffer+7,16);
//			I2C_ReadS_24C(SYS_NETFEE+16,buffer+23,3);
//			I2C_ReadS_24C(SYS_NETFEE+19,buffer+26,16);
			I2C_ReadS_24C(SYS_NETFEE,buffer+7,26);
			I2C_ReadS_24C(SYS_NETFEE+32,buffer+33,3);
			I2C_ReadS_24C(SYS_NETFEE+35,buffer+36,26);
			//������ʱ��
			if((buffer[33]>time[4])||
				((buffer[33]==time[4])&&(time[3]>buffer[34]))||
				((buffer[33]==time[4])&&(buffer[34]==time[3])&&(time[2]>=buffer[35])))
				memcpy(data,buffer+36,26);
			else
				memcpy(data,buffer+7,26);
			BCC = 0x00;
			for(i=0;i<25;i++)
			  BCC = BCC ^ data[i];
			data[25] = BCC;			 			
			I2C_WriteS_24C(B_startTime_unit_of_hour,data,16);
			I2C_WriteS_24C(back_argument_of_charge,data,16);			
			}  		   
		  break;
	  }
	  else
	  {
		  timeOut++;
	  }
	}	      
	 
}


//2015-08-10 ���� 
void DownloadTimeAndFreeBAK(void)
{
    uchar delay_time;
    int buffer[16];
    uchar BL_buffer[64 * 8];
    int count;
    uchar timeOut;
    uchar data[16];
    
    count = 64 * 8;      
    timeOut = 0;
 
    while(timeOut < 2)
    {
                 
      if(open_gprs() == OK)
      {                  
          //����ʱ��������趨
          //�������֮ǰ���յ�����
          for(int i=0;i<RxCounter;i++)
             RxBuffer[i]=0x00; 
          
          RxCounter = 0;
          f_receiveOK = 0;
                
          for(int i=0;i<16;i++)
              buffer[i] = 0x00;
          
          delay_time = 8;
          sendCommand(4);          
          error_flag = recTimeData(delay_time,buffer);
                
          if(error_flag == OK)//������ȷ
          {
              count = (buffer[1] - buffer[0]) / 2;
              if(count == 7)
              {
                  for(int i=0;i< count;i++)
                    BL_buffer[i] = asic_to_hex( RxBuffer[i * 2 + buffer[0] ])* 0x10 + asic_to_hex( RxBuffer[i * 2 + buffer[0] + 1]);
              
                  GetCurrentTime();
                  if(time[4] != BL_buffer[1] || time[3] != BL_buffer[2] || time[2] != BL_buffer[3] || time[1] != BL_buffer[4])
                  {
                      data[4]=BL_buffer[1];	  //��				
                      data[3]=BL_buffer[2];	  //��				
                      data[2]=BL_buffer[3];	  //��				
                      data[1]=BL_buffer[4];	  //ʱ				
                      data[0]=BL_buffer[5];	  //��								
                      data[5]=mathweek(BL_buffer[1],BL_buffer[2],BL_buffer[3]);					
                      set_current_time(data);				
                  }
                  else
                  {
                      if(BL_buffer[5] > time[0])
                      {
                          if(BL_buffer[5] - time[0] > 5)
                          {
                              data[4]=BL_buffer[1];	  //��				
                              data[3]=BL_buffer[2];	  //��				
                              data[2]=BL_buffer[3];	  //��				
                              data[1]=BL_buffer[4];	  //ʱ				
                              data[0]=BL_buffer[5];	  //��								
                              data[5]=mathweek(BL_buffer[1],BL_buffer[2],BL_buffer[3]);					
                              set_current_time(data);
                          }
                      }
                      else
                      {
                          if(time[0] - BL_buffer[5] > 5)
                          {
                              data[4]=BL_buffer[1];	  //��				
                              data[3]=BL_buffer[2];	  //��				
                              data[2]=BL_buffer[3];	  //��				
                              data[1]=BL_buffer[4];	  //ʱ				
                              data[0]=BL_buffer[5];	  //��								
                              data[5] = mathweek(BL_buffer[1],BL_buffer[2],BL_buffer[3]);					
                              set_current_time(data);
                          }
                      }
                  } 
              }                              
                
          }
                
          //�������ʲ������趨
          //�������֮ǰ���յ�����
          for(int i=0;i<RxCounter;i++)
             RxBuffer[i]=0x00;           
          RxCounter = 0;
          f_receiveOK = 0;
                    
          for(int i=0;i<16;i++)
              buffer[i] = 0x00;
          
          delay_time = 8;
          sendFreeCom(6);//�����ȷ�����������Ƿ����·��� ����
          error_flag = recFreeCom(delay_time,buffer);
          
          if(error_flag == OK)
          {
              count = buffer[1] - buffer[0];
              if(count == 2)
              {
                  if(RxBuffer[buffer[0]] == 'N' && RxBuffer[buffer[0]+1] == 'O')
                  {                    
                      for(int i=0;i<RxCounter;i++)
                         RxBuffer[i]=0x00; 
                      
                      RxCounter = 0;
                      f_receiveOK = 0;
                      
                      for(int i=0;i<16;i++)
                          buffer[i] = 0x00;
                      
                      delay_time = 8;
                      sendCommand(5);//�����з��ʲ��� ������                      
                      error_flag = recFreeData(delay_time,buffer);
                            
                      if(error_flag == OK)//������ȷ
                      {
                          count = (buffer[1] - buffer[0]) / 2;
                          if(count != 16 )
                            break;//���յķ��� ������������
                                                        
                          for(int i=0;i< count;i++)
                              BL_buffer[i] = asic_to_hex( RxBuffer[i * 2 + buffer[0] ])* 0x10 + asic_to_hex( RxBuffer[i * 2 + buffer[0] + 1]);

                          if(BL_buffer[0] != 0x55)
                          {
                              error_flag = 0;
                          }
                          
                          if(BL_buffer[1] >= 0x24 || BL_buffer[2] >= 0x60 || BL_buffer[3] >= 0x24 || BL_buffer[4] >= 0x60 || (BL_buffer[3] < BL_buffer[1]))
                          {
                              error_flag = 0;
                          }
                          
                          if(BL_buffer[5] > 0x64 || BL_buffer[7] > 0x60 || BL_buffer[11] > 0x24)
                          {
                              error_flag = 0;
                          }
                          
                          if(BL_buffer[7] == 0x60 || BL_buffer[7] == 0x30)
                          {
                              uchar TimeUnit = 0x60 / BL_buffer[7];
                              if(BL_buffer[8] * TimeUnit * 5 != BL_buffer[6])
                                 error_flag = 0;
                          }
                          else
                            error_flag = 0;
                          error_flag = OK;
                          if(error_flag == OK)
                          {
                              I2C_ReadS_24C(B_startTime_unit_of_hour,data,16);
                          
                              uchar i;
                              uchar BCC;
    
                              BCC = 0;
                              for(i=0;i<15;i++)
                              {
                                  data[i] = BL_buffer[i+1];
                                  BCC = BCC ^ data[i];
                              }
                              
                              data[15] = BCC;
                        
                              I2C_WriteS_24C(B_startTime_unit_of_hour,data,16);
                              I2C_WriteS_24C(back_argument_of_charge,data,16);
                          }
                          
                      
                      }
                    
                  }
              }
          }
           
          break;
      }
      else
      {
          timeOut++;
      }
    }      
   
     
}



//���ͣУӣ��Ϳ����������̨
void SendPSAM(void)
{
    uchar timeOut;
    uchar Reader;
    uchar PSAM;
    Smart_Power_ON;
    delay(KEYTIMEOUT_1S / 2);
    //4.���������
    timeOut = 0;
    Reader = NO;
    while(timeOut < 4)
    {
            if(read_mech_ID() == 0x00)
            {
                Reader = OK;
                break;
            }
            
            timeOut++;
     }
         
     //5.PSAM�����
     timeOut = 0;
     PSAM = NO;
     while(timeOut < 4)
     {
            if(read_PSAM() == 0x00)
            {
                PSAM = OK;
                break;
            }
            
            timeOut++;
      }  
     Smart_Power_OFF;
     
       
     if(Reader == NO || PSAM == NO)  
     {
        timeOut = 0;
        while(timeOut < 2)
        {
            if(open_gprs() == OK)
            {
                
                
                if(Reader == NO)
                {
                    sendCommand(8);
                    rec_gprs_ack(3);
                }                 
                
                if(PSAM == NO)
                {
                    sendCommand(9);
                    rec_gprs_ack(3);
                }                 
                break;
            }
            else
            {
                GPRS_Power_OFF;
            }
            timeOut++;
        }
        GPRS_Power_OFF;
          
     }

      
}




//׼ʱ���ͼ�¼
void send_Record_time(uchar record[],uchar count)
{
   
        if(count == 32)
        {
            send_consumption_16_record(record);           
        }
        else if(count == 80)
        {                     
            send_consumption_record(record);     
        }
        else
        {
            
        }
   
}


// ��ʱ �������  ----ѡʱ����  δˢ���������
uchar AddTime_Operation(uchar CardNO[],uchar car,uchar block1_buffer[])
{
   
    uchar hour = 0,TimeCount = 0;
    uchar min = 0; 
    int Time_count;
    int momery = 0;  
    uchar card_class_flag;
    uchar momery_buffer[4];
    u16 cttime;
    
    CardInfo YWCardInfo;
     MIFARE_card_information MIFARE_card_info;
    //carStation_reference_of_used CS_RF_US;
    display_replayMent(hour,min,momery);                              
    unsigned long timeOut = 0;   
    int timeOut_1 = 0; 
    uchar frist_key_flag = 0;
    //uchar read_card_flag = 0;
    Time_count = 0;
    uchar quit = 0;    

    GetCurrentTime();
    
    get_rate_ref(&RR_ST1);
    
    display_replaymenory(0x04);                                    
    timeOut = 0;  
    
    while(timeOut < KEYTIMEOUT_1S * 1)                                     
    {                                          
      if(key_flag == 0x02 || key_flag == 0x01)                                         
      {                                              
        key_flag = 0;                                             
        break;                                         
      }                                         
      else if(key_flag == 0x03 || key_flag == 0x04)                                        
      {                                           
        key_flag = 0;                                           
        return 2;                                      
      }                                                                                   
      else                                       
        timeOut++;                                                                                
    }
                                                                          
    if(timeOut >= KEYTIMEOUT_1S * 1)                                       
      return 2;//����һ��ʱ�� û�н���ѡ�� �Զ��˳�
    
    lcd_clear();
    display_replayMent(hour,min,momery); 
    timeOut = 0;  
    while(timeOut < KEYTIMEOUT_1S * 2 && quit == 0) 
		{         
        frist_key_flag = 0;
        if(key_flag)  
			{ 
			//key_flag = 0;
			delay(10000);
			// if(key_flag)
			{
			frist_key_flag = key_flag; 
			key_flag = 0;
			} 
		} 
	switch(frist_key_flag)   
		{ 
		case car1://����1��2��λ ��ʱ    
		case car2:
			Time_count = Time_count + 60;  
			
			if(Time_count >= RR_ST1.Max_Park_Time*60)//2015-12-19 ����ʱ��
				Time_count = RR_ST1.Max_Park_Time*60;
			
			hour = Time_count/RR_ST1.Min_Charge_Time;
			switch(hour)
				  {
				  case 0:			  
				  case 1:
//				  case 2://1Сʱ���ڣ���1Сʱ��
					  momery = RR_ST1.f1;
					  break;
//				  case 3://1Сʱ-1.5Сʱ����1.5Сʱ��
//					  momery = RR_ST1.f2;
//					  break;
//				  case 4://1.5Сʱ-2Сʱ����2Сʱ��
//					  momery = RR_ST1.f3;
//					  break;
//				  case 5://2Сʱ-2.5Сʱ����2.5Сʱ��
//					  momery = RR_ST1.f4;
//					  break;
//				  case 6://2.5Сʱ-3Сʱ����3Сʱ��
//					  momery = RR_ST1.f5;
//					  break;				  
				  default://3Сʱ���� 
					  momery = RR_ST1.f1+RR_ST1.f2*(hour-1);
	  //			  if(park_memory>RR_ST.Max_Stop_Momery)
	  //				  park_memory = RR_ST.Max_Stop_Momery;
					  break;	  
				  }

		  momery *= RR_ST1.Sale_Base;	
		  
		  hour = Time_count / 60;
		  min = Time_count % 60;
            
          //�����ʱ��� ���      
          display_replayMent(hour,min,momery);
            
          delay(KEYTIMEOUT_1S / 2 ); 
          timeOut = 0;  
          frist_key_flag = 0;          
          break;
        
          case car3://����3��4��λ ȷ��      
          case car4:  
            
            cttime = time1[1]*60+time1[0];
		    if(cttime<Time_count)
				cttime += 24*60;			
			cttime =cttime -Time_count;
			TMP.time[4] = time[4]; //��
			TMP.time[3] = time[3]; //�� 
			TMP.time[2] = time[3]; //�� 			
			TMP.time[1] = HEX_to_BCD(cttime/60);
			TMP.time[0] = HEX_to_BCD(cttime%60);	
			Smart_Power_ON;
            delay(KEYTIMEOUT_1S * 0.35);//������ʱ ��Ϊ�� �������� �ϵ�
#if 1
          lcd_clear();//���� ��ʾ ��ˢ��  
          
          display_please_operation(time1[4],time1[3],time1[2],time1[1],time1[0],0x04);       
          
          #ifdef MACHINE_ID
              
              read_mech_ID_flag = NO;
              while(TimeCount < 3)
              {
                  if(read_mech_ID() == 0x00)
                  {
                      read_mech_ID_flag = OK;
                      break;
                  }
                  
                  TimeCount++;
              }
              
              if(read_mech_ID_flag != OK)
              {
                  Smart_Power_OFF;
                  return 0x99;
              }              
          #endif
          
          timeOut_1 = 0;       
          while(timeOut_1 < 300)       
          {
              card_class_flag = inquire_card(&YWCardInfo);//��� ��������
			  if(card_class_flag==CardType_CPCLOCK)
				  {
				  if(timeOut_1<100)continue;
				  write_card_error(0);
				  delay(KEYTIMEOUT_1S*3);
				  return 1;
				  }
			 if((card_class_flag==CardType_MF1)||
			 (card_class_flag==CardType_BIKE)||
			 (card_class_flag==CardType_CPC)||
			 (card_class_flag==CardType_CPU)||
			 (card_class_flag==CardType_IC))
			 	break;
              if(key_flag)
              {                                                                                
                key_flag = 0;        
                delay(KEYTIMEOUT_1S * QUIT_TIME);
                break;                                                                                                      
              }
              timeOut_1++;                  
          }

          if(timeOut_1 < 300)       
          {
              if(card_class_flag == CardType_BIKE)     
			  	{
//				disp_YWT_IMG(12);	
				TMP.feemny = momery;
				BIKECARD_PRO(car,0x88,&YWCardInfo);	
				return 0x88;
              	}        
              else if(card_class_flag == CardType_IC)
			  	{
				TMP.feemny = momery;
				ICCard_Pay(car,0x88);
				return 0x88;
              	}
              else if(card_class_flag == CardType_CPU)          
//				  else if(card_class_flag == CardType_CPC)			
			//momery
                {
				TMP.feemny = momery;
			  	CPCCARD_PRO(car,0x88,&YWCardInfo);	
				return 0x88;
              	}
              else if(card_class_flag == CardType_MF1)//MIFARE_CARD�ۿ�
              {
                
                  Smart_Power_ON;
                  //��ѯ���
                  uchar left_momery_buffer[4],i;
                  uchar block1_buffer[32];
                  uchar block2_buffer[32];
                  long left_momery;
                  uchar MIFARE_password_buffer[6];
                  read_MIFARE_card(&MIFARE_card_info);  //��ȡmifare������Ϣ                  
                  MF1key_main(MIFARE_card_info.SNR,MIFARE_password_buffer);
                                                    
                  if(testkey_comd(0x02,0x0a,MIFARE_password_buffer) == OK)                                    
                  {  
                    if(read_comd(BLOCK1_ADDR,block1_buffer) == OK && read_comd(BLOCK2_ADDR,block2_buffer) == OK)
                    {
                        if(block2_buffer[0] == MIFARAE_PARK_CARD)
                        {
                            read_comd(BLOCK0_ADDR,left_momery_buffer);
                            left_momery = left_momery_buffer[0] + left_momery_buffer[1] * 0x100 + left_momery_buffer[2] * 0x10000 + left_momery_buffer[3] * 0x1000000;
	                    if(left_momery > 100000)
                            {
                                MoneryException();
                                delay(KEYTIMEOUT_1S*2);
                                return 0x00;//���� ����
                            }
						if(left_momery<=0)
						   {//add 2014-03-11
						   //��ʾ ���㣬���ֵ
						   Smart_Power_OFF;//�ص�����ģ��ĵ�Դ 
						   OPEN_EXTI9_5_IRQ();											 
						   OPEN_EXTI15_10_IRQ();
						   no_momery(left_momery);
						   timeOut = 0;
						   while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)
							   {											 
							   if(key_flag)
								   { 
								   key_flag = 0;
								   delay(KEYTIMEOUT_1S * QUIT_TIME);
								   break;
								   }  
							   timeOut++;  
							   }
						   break;
						   }
							
                        if(block2_buffer[1] >= 0x00)
                            {
                   			   u8 OVERDRAFT_F =0;
							   u32 lockmny;
							   #ifdef OVERDRAFT 
							   OVERDRAFT_F = 1;
							   #endif                                         
                                left_momery = left_momery_buffer[0] + left_momery_buffer[1] * 0x100 + left_momery_buffer[2] * 0x10000 + left_momery_buffer[3] * 0x1000000;
                                //1.�۳�ͣ������     
								lockmny = hcl(block2_buffer+7,2)*100;//���ᱶ��--���
                                
                                if((left_momery > lockmny) && ((left_momery >= momery)||OVERDRAFT_F))                                            
//								if((left_momery > (block2_buffer[1]*RR_ST1.Max_Stop_Momery* RR_ST1.Sale_Base)) && ((left_momery >= momery)||OVERDRAFT_F))											 
                                {    
								   if((left_momery > momery)||OVERDRAFT_F)
                                    {                                                
                                      momery_buffer[0] = 0x00;                                                
                                      momery_buffer[1] = 0x00;                                              
                                      momery_buffer[2] = momery / 256;                                             
                                      momery_buffer[3] = momery % 256;                                              
                                    }                                               
                                    else                                               
                                    {                                                   
                                      momery_buffer[0] = left_momery_buffer[3];                                                  
                                      momery_buffer[1] = left_momery_buffer[2];                                                  
                                      momery_buffer[2] = left_momery_buffer[1];                                                  
                                      momery_buffer[3] = left_momery_buffer[0];                                               
                                    }
                                                     
                                } 
                                else//����
                                {
                                    //��ʾ ���� ���㱾�ο۷�
                                    Smart_Power_OFF;
                                    //��ʾ ���� ����ͣ��  
                                    OPEN_EXTI9_5_IRQ();
                                                        
                                    OPEN_EXTI15_10_IRQ();
                                    no_momery(left_momery);                                             
                                    timeOut = 0;
                                                              
                                    while(timeOut < KEYTIMEOUT_1S * 2)                                          
                                    {                                                                             
                                      if(key_flag){                                                                                
                                        key_flag = 0; 
                                        delay(KEYTIMEOUT_1S * QUIT_TIME);
                                        break;                                                                            
                                      }                                                                             
                                      timeOut++;                       
                                                                         
                                    }
                                    return 0;
                                }

                                
                                if((momery >= left_momery)&&(!OVERDRAFT_F))                                               
                                   momery = left_momery;
								if(!bushimny[car])
									bushimny[car] = left_momery;
								i = OK;
								if(bushimny[car] == left_momery)
									i = value_comd(0x2d,8,momery); 								  
                                if(i == OK)//�ۿ�ɹ�
                                {
                                    Buzz_0;                                                  
                                    delay(KEYTIMEOUT_1S/10);                                                
                                    Buzz_1;                                               
									left_momery = bushimny[car];   
									bushimny[car] = 0;
                                    OPEN_EXTI9_5_IRQ();
                                    OPEN_EXTI15_10_IRQ();
                                                
                                    Smart_Power_OFF;
                                    replay_momery(momery,left_momery - momery,0);//����ʾ �ϴ���δ����
                                    fll(left_momery,block1_buffer,3);  
									for(i=0;i<3;i++)
										left_momery_buffer[i] = block1_buffer[2-i];
                                                 
                                    //1. ��ɷѼ�¼                                                                                                                   
                                    block1_buffer[0] = 0xEE;//��¼ͷ                                                
                                    block1_buffer[1] = 0x00; //��������                                               
                                    block1_buffer[2] = 0x00;                                                
                                    block1_buffer[3] = 0x00;                                                
                                    block1_buffer[4] = 0x00;                                               
                                    block1_buffer[5] = MIFARE_card_info.SNR[3]; //��������                                               
                                    block1_buffer[6] = MIFARE_card_info.SNR[2];                                               
                                    block1_buffer[7] = MIFARE_card_info.SNR[1];                                               
                                    block1_buffer[8] = MIFARE_card_info.SNR[0];                                                
                                    block1_buffer[9] = TMP.time[4];//��                                                
                                    block1_buffer[10] = TMP.time[3];//��                                                
                                    block1_buffer[11] = TMP.time[2];//��                                                
                                    block1_buffer[12] = TMP.time[1];//ʱ                                                
                                    block1_buffer[13] = TMP.time[0];//��                                               
                                    block1_buffer[14] = left_momery_buffer[2];                                               
                                    block1_buffer[15] = left_momery_buffer[1];                                               
                                    block1_buffer[16] = left_momery_buffer[0];                                               
                                    block1_buffer[17] = momery_buffer[2];                                               
                                    block1_buffer[18] = momery_buffer[3];                                                
                                    block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x0E;//��ʱ ��λΪcar 
                                                                                               
                                    block1_buffer[20] = time[4];                                              
                                    block1_buffer[21] = time[3];                                                
                                    block1_buffer[22] = time[2];                                               
                                    block1_buffer[23] = time[1];                                                
                                    block1_buffer[24] = time[0];
                                                
                                    block1_buffer[25] = CardType_MF1;//����ͨ��¼��־
                                    block1_buffer[26] = CardNO[3]; //��������
								    block1_buffer[27] = CardNO[2];
								    block1_buffer[28] = CardNO[1];
								    block1_buffer[29] = CardNO[0];
                                    for(int i=30;i<32;i++)                                                   
                                      block1_buffer[i] = 0xAA;                                                
                                    Save_Record(block1_buffer,32);
									save_RPTMNY_record(CardType_MF1,momery);//2015-12-07
                                    timeOut = 0;  
                                    key_flag = 0;
                                    while(timeOut < KEYTIMEOUT_1S * 2)                                          
                                    {                                                                             
                                      if(key_flag){                                                                                
                                        key_flag = 0;
                                        delay(KEYTIMEOUT_1S * QUIT_TIME);
                                        break;                                                                            
                                      }                                                                             
                                      timeOut++;                       
                                                                         
                                    }
                                    
                                    return 1;
                                }
                                else//��ʾ �ۿ����
                                {
									bushimny[car] = left_momery; //2015-08-22  andyluo
                                    //��ʾ�ۿ����
                                    Smart_Power_OFF;
                                    OPEN_EXTI9_5_IRQ();
                                    OPEN_EXTI15_10_IRQ();
                                    
                                    write_card_error(0);
                                    delay(KEYTIMEOUT_1S * 3);
                                    return 0;
                                }
                            }
                            else//��δ������� ��ʾ���Ȳ���
                            {
                                //��ʾ��δ������� ���Ȳ���
                                Smart_Power_OFF;
                                OPEN_EXTI9_5_IRQ();                                    
                                OPEN_EXTI15_10_IRQ();
                                
                                display_outstanding();
                                timeOut = 0;                                                  
                                while(timeOut < KEYTIMEOUT_1S * 2)                                          
                                {                                                                             
                                      if(key_flag){                                                                                
                                        key_flag = 0; 
                                        delay(KEYTIMEOUT_1S * QUIT_TIME);
                                        break;                                                                            
                                      }                                                                             
                                      timeOut++;                       
                                                                         
                                }
                                return 0;
                            }
                            
                        }
                        else//������
                        {
                            //��ʾ �޿�Ч
                            Smart_Power_OFF;
                            OPEN_EXTI9_5_IRQ();
                            OPEN_EXTI15_10_IRQ();
                            
                            no_use_card(0);
                            delay(KEYTIMEOUT_1S * 3);
                            return 0;
                        }
                    }
                    else
                    {
                        //���� ����
                    }
                 
                  }
                  else
                  {
                        //����Կ����
                  }
              }
              
              else
              {
                  //������
                  //��ʾ �޿�Ч                            
                  Smart_Power_OFF;                            
                  OPEN_EXTI9_5_IRQ();                            
                  OPEN_EXTI15_10_IRQ();
                                                          
                  no_use_card(3);                            
                  delay(KEYTIMEOUT_1S * 3);                            
                  return 0;
              }
          }
        hour = 0;
        min = 0;
        
        frist_key_flag = 0;      
        
        quit = 1;
#endif
        break;
        
        default:break;
        
      }      
      timeOut++;
    } 
    return 0;

}


//����Ϊ δ���� ��¼
void save_full_record(uchar buffer[],uchar car)
{
    switch(car)
    {
    case car1:
      I2C_WriteS_24C(car1_false_record,buffer,112);
      break;
    case car2:
      I2C_WriteS_24C(car2_false_record,buffer,112);
      break;
    case car3:
      I2C_WriteS_24C(car3_false_record,buffer,112);
      break;
    case car4:
      I2C_WriteS_24C(car4_false_record,buffer,112);
      break;
    default:break;
    }
}




//��� �Ƿ���Ϊ������¼�ĺ���
//bufferΪ ����Ŀ���     car Ϊ��λ
uchar false_record(uchar buffer[],uchar car)
{
    switch(car)
    {
    case car1:
      I2C_ReadS_24C(car1_false_record,buffer,112);
      break;
    case car2:
      I2C_ReadS_24C(car2_false_record,buffer,112);
      break;
    case car3:
      I2C_ReadS_24C(car3_false_record,buffer,112);
      break;
    case car4:
      I2C_ReadS_24C(car4_false_record,buffer,112);
      break;
    default:break;
    }
    
    for(uchar i=0;i<112;i++)
    {
        if(buffer[i] != 0x00)
          return 1;
    }
    
    return 0;
}


 

void clear_FM_FLASH_reference(void)
{
    uchar buffer[256];
    u32 SectorAddr;        
        
        ini_rpt_info();//���������Ϣ 2015-12-19 
        /////////////////////////////////FLASH ��ʼ�� /////////////////////////////////
        buffer[0] = 0x00;
        I2C_WriteS_24C(full_of_FLASH_flag,buffer,1); //FLASH ������־
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        I2C_WriteS_24C(clear_4K_of_FLASH_addr,buffer,3); //FLASH 4K������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        I2C_WriteS_24C(FLASH_last_time_down_addr,buffer,3); //FLASH ��¼�ϴ����ص�ַ
        buffer[2] = 0x00;
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        I2C_WriteS_24C(addr_of_current_in_FLASH,buffer,3); //FLASH ��¼�洢��ǰ��ַ       
        ///////////////////////////////////////////////////////////////////////////////       
             
        
        ///////////////////////��������ļ�¼����///////////////////////////////////////
        buffer[0] = 0x17;
        buffer[1] = 0xE0;
        I2C_WriteS_24C(Con_Fm_Record_112_Start_Addr,buffer,2);//��ʼ��ַ  112
        I2C_WriteS_24C(Con_Fm_Record_112_Cursor,buffer,2);//���¼��ַ�α�
        I2C_WriteS_24C(Con_Fm_Record_112_UDCSR,buffer,2);//GPRS ���ؼ�¼��ַ�α�
        I2C_WriteS_24C(Con_Fm_Record_112_UDCSR_P,buffer,2);//POS�� ���ؼ�¼��ַ�α�
        
        buffer[0] = 0x59;
        buffer[1] = 0x80;
        I2C_WriteS_24C(Con_Fm_Record_112_End_Addr,buffer,2);//������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        I2C_WriteS_24C(Con_Fm_Record_112_Count,buffer,2);//����
        I2C_WriteS_24C(Con_Fm_Record_112_Cursor_F,buffer,2);//�α�Խ���ı�־λ
        
        
        buffer[0] = 0x5A;
        buffer[1] = 0x00;
        I2C_WriteS_24C(Con_Fm_Record_16_Start_Addr,buffer,2);//��ʼ��ַ  16
        I2C_WriteS_24C(Con_Fm_Record_16_Cursor,buffer,2);//���¼��ַ�α�
        I2C_WriteS_24C(Con_Fm_Record_16_UDCSR,buffer,2);//GPRS ���ؼ�¼��ַ�α�
        I2C_WriteS_24C(Con_Fm_Record_16_UDCSR_P,buffer,2);//POS�� ���ؼ�¼��ַ�α�
        
        buffer[0] = 0x7F;
        buffer[1] = 0x80;
        I2C_WriteS_24C(Con_Fm_Record_16_End_Addr,buffer,2);//������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        I2C_WriteS_24C(Con_Fm_Record_16_Count,buffer,2);//����
        I2C_WriteS_24C(Con_Fm_Record_16_Cursor_F,buffer,2);//�α�Խ���ı�־λ
        ////////////////////////////////////////////////////////////////////////////////
        
        
        ///////////////////////FLASH����ļ�¼����//////////////////////////////////////
        buffer[0] = 0x0D;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        I2C_WriteS_24C(Con_Flash_Record_16_Start_Addr,buffer,3);//��ʼ��ַ  116
        I2C_WriteS_24C(Con_Flash_Record_16_Cursor,buffer,3);//���¼��ַ�α�
        I2C_WriteS_24C(Con_Flash_Record_16_UDCSR,buffer,3);//���ؼ�¼��ַ�α�
        I2C_WriteS_24C(Con_Flash_Record_16_UDCSR_P,buffer,3);//POS ���ؼ�¼��ַ�α�
        
        buffer[0] = 0x19;
        buffer[1] = 0x35;
        buffer[2] = 0x00;
        I2C_WriteS_24C(Con_Flash_Record_16_End_Addr,buffer,3);//������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        I2C_WriteS_24C(Con_Flash_Record_16_Count,buffer,3);//����
        I2C_WriteS_24C(Con_Flash_Record_16_Cursor_F,buffer,3);//�α�Խ���ı�־λ
        
        
        
        buffer[0] = 0x1A;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        I2C_WriteS_24C(Con_Flash_Record_112_Start_Addr,buffer,3);//��ʼ��ַ  16
        I2C_WriteS_24C(Con_Flash_Record_112_Cursor,buffer,3);//���¼��ַ�α�
        I2C_WriteS_24C(Con_Flash_Record_112_UDCSR,buffer,3);//���ؼ�¼��ַ�α�
        I2C_WriteS_24C(Con_Flash_Record_112_UDCSR_P,buffer,3);//POS ���ؼ�¼��ַ�α�
        
        buffer[0] = 0x6F;
        buffer[1] = 0x73;
        buffer[2] = 0x00;
        I2C_WriteS_24C(Con_Flash_Record_112_End_Addr,buffer,3);//������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        I2C_WriteS_24C(Con_Flash_Record_112_Count,buffer,3);//����
        I2C_WriteS_24C(Con_Flash_Record_112_Cursor_F,buffer,3);//�α�Խ���ı�־λ
        ////////////////////////////////////////////////////////////////////////////////                 
        
        ///////////////////////��� ����Flash�ı��////////////////////////////
        buffer[0] = 0x00;
        I2C_WriteS_24C(Flash_erased_sector_32_F,buffer,1);//�� ������ַ���α� ��־
        I2C_WriteS_24C(Flash_erased_sector_112_F,buffer,1);
        
        buffer[0] = 0x66;
        I2C_WriteS_24C(Flash_erased_sector_32_L,buffer,1);//�� ������ַ���α� ��־
        I2C_WriteS_24C(Flash_erased_sector_112_L,buffer,1);
        ///////////////////////////////////////////////////////////////////////
        
        SPI_FLASH_Init();                      
        
        SectorAddr =0x0D0000;
        while(SectorAddr <0x800000) //����flash���� ������
        {
            SPI_FLASH_SectorErase(SectorAddr);
            SectorAddr = SectorAddr + 0x010000;
        }
       INI_IAP_PRO(); 
}

uchar compare_NO_time(uchar old_card_no[],uchar new_old_card_no[],uchar flag)
{
  if(flag ==MIFARE_CARD)
  {
      for(uchar i=0;i<4;i++)
      {
        if(old_card_no[i] != new_old_card_no[i])
          return 0;
      }
    return 1;
  }
  else if(flag ==CPU_CARD)
  {
      for(uchar i=0;i<4;i++)
      {
        if(old_card_no[i] != new_old_card_no[i])
          return 0;
      }
    return 1;
  }
  else
  {
      return 0;
  }
    
}



/*1�����ܿ�����
 ���ܣ�M1��ϵͳ��Կ����
*/


u8 KEYCard_Process(void)
{
   u8 b;
   u8 readcard_data[16];
   uchar BCC;
   BCC = 0x00;
   b=read_comd(0x08,readcard_data);	//������   
   if(b == 0)return 0;
   Smart_Power_OFF;	  //ʡ��
   for(b=0;b<6;b++)
	   {
	   system0_number[b]=readcard_data[b];
	   BCC = BCC ^ readcard_data[b];
	   } 
   
   readcard_data[b] = BCC;
   if(TMP.cardplace == CardType_ZGMF1RD)//�����
	   {
	   I2C_WriteS_24C(sysytem_public_ZGkey,readcard_data,7);  //���ܺ����в�������
	   I2C_WriteS_24C(sysytem_public_ZGkey_back,readcard_data,7);
	   }
   else//���뿨
	   {
	   I2C_WriteS_24C(sysytem_public_key,readcard_data,7);  //���ܺ����в�������
	   I2C_WriteS_24C(sysytem_public_key_back,readcard_data,7);  //���ܺ����� ������Կ ��������
	   }
   return 1;

}

// IP ���ĵ�ַ����
void ip_download()
{
    uchar block1_buffer[16];
    if(read_comd(BLOCK1_ADDR,block1_buffer) == OK)
    {
        I2C_WriteS_24C(IPADrees,block1_buffer,6);//��IP��
        //��ʾ IP���óɹ�
        ip_setup(OK);
        
    }
    else
    {
        //��ʾ IP����ʧ��
        ip_setup(NO);
    }
    delay(KEYTIMEOUT_1S * 3);
    // delay
}


void RecordSendDown(void)
{
    uchar block1_buffer[16];
    if(read_comd(BLOCK1_ADDR,block1_buffer) == OK)
    {
        I2C_WriteS_24C(SendInterval,block1_buffer,4);//���¼���ͻ��ƵĲ���
        I2C_WriteS_24C((SendInterval + 4),block1_buffer + 2,1);//���¼���ͻ��ƵĲ���
        I2C_WriteS_24C(BACK_TIME,block1_buffer + 4,4);//�汳�� ������ʱ��
        displaySendRecord();
    }
    else
    {
        write_card_error(0);
    }
    Smart_Power_OFF;
    delay(KEYTIMEOUT_1S * 4);
}


//������� car��λ��Ϊ������ ��λ�Ľ�������־
void clear_other_flag(uchar car)
{
    uchar buffer[4];
    buffer[0] = 0x00;
    
    for(uchar i=1;i <= 4;i++)
    {
        if(i != car)
        {
            I2C_WriteS_24C(car1_LNT_comd + (car - 1),buffer,1);  //����ͨ ���� �����־
            I2C_WriteS_24C(car1_LNT_V_comd + (car - 1),buffer,1);//����ͨ ���� �����־
            I2C_WriteS_24C(car1_write_comd + (car - 1),buffer,1);//�Է��� ���� �����־
            I2C_WriteS_24C(car1_value_comd + (car - 1),buffer,1);//�Է��� ���� �����־
        }
    }
}

//����������λ ��λ��ʹ���� �� ������һ����
uchar return_other_useing(uchar card_no[],uchar car,uchar card_class)
{
    uchar buffer[16];
    for(uchar i=1;i<=4;i++)
    {
        if(i != car)
        {
            switch(i)
            {
              case car1:
              I2C_ReadS_24C(car1_used_reference_info,buffer,16);
              break;             
              case car2:
              I2C_ReadS_24C(car2_used_reference_info,buffer,16);
              break;              
              case car3:
              I2C_ReadS_24C(car3_used_reference_info,buffer,16);
              break;              
              case car4:
              I2C_ReadS_24C(car4_used_reference_info,buffer,16);
              break;             
              default:break;              
            }
            
            if(buffer[0] == 0x66)
            {
                uchar j;
                
                if(card_class == CPU_CARD)
                {
                  for(j=0;j<8;j++)
                  {
                      if(buffer[j+1] != card_no[j])
                        break;
                  }
                
                  if(j >= 8)
                    return OK;
                    
                }
                else if(card_class == MIFARE_CARD)
                {
                  for(j=0;j<4;j++)
                  {
                       if(buffer[j+5] != card_no[3 - j])
                          break;
                  }
                
                  if(j >= 4)
                    return OK;
                }
                
            }
        }
    }
    
    return NO;
}



void SendPage_Record(void)
{
	u16 Page;
	u16 sendPage;
	
//	  uchar ReceiveFlag;
	uchar buffer[1024],sendBuf[13];    
	
	//2. ����32�ֽڵļ�¼ �� 112 �ֽڵļ�¼�����������ʱ��ˢ������ͨ��
	
	uchar over_32_buffer[4],over_112_buffer[4];
	
	uchar Start_16_buffer[4],End_16_buffer[4];
	
	uchar Start_112_buffer[4],End_112_buffer[4];
	
	unsigned long F_Start_16_count,F_End_16_count;
	
	unsigned long F_Start_112_count,F_End_112_count;
	u8 rectime = 3;
	
	I2C_ReadS_24C(Con_Flash_Record_16_Cursor_F,over_32_buffer,1);
	I2C_ReadS_24C(Con_Flash_Record_112_Cursor_F,over_112_buffer,1);
	
	key_flag = 0;	
#ifdef TWO_CAR
	DISABLE_EXTI9_5_IRQ();	
#endif
	I2C_ReadS_24C(Con_Flash_Record_16_UDCSR,Frist_buffer,3);//���ص��α�		   
	I2C_ReadS_24C(Con_Flash_Record_16_Cursor,Last_buffer,3);//���¼���α�
	I2C_ReadS_24C(Con_Flash_Record_16_Start_Addr,Start_16_buffer,3);
	I2C_ReadS_24C(Con_Flash_Record_16_End_Addr,End_16_buffer,3);
					   
	F_count_32 = hcl(Frist_buffer,3);			  
	L_count_32 = hcl(Last_buffer,3);	
	F_Start_16_count = hcl(Start_16_buffer,3);			   
	F_End_16_count = hcl(End_16_buffer,3); 
	
	I2C_ReadS_24C(Con_Flash_Record_112_UDCSR,Frist_buffer,3);//���ص��α�			
	I2C_ReadS_24C(Con_Flash_Record_112_Cursor,Last_buffer,3);//���¼���α�
	I2C_ReadS_24C(Con_Flash_Record_112_Start_Addr,Start_112_buffer,3);
	I2C_ReadS_24C(Con_Flash_Record_112_End_Addr,End_112_buffer,3);
	
	F_count_112 = hcl(Frist_buffer,3);			   
	L_count_112 = hcl(Last_buffer,3); 
	F_Start_112_count = hcl(Start_112_buffer,3);			 
	F_End_112_count = hcl(End_112_buffer,3);
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
   
	if(((F_count_32 < L_count_32 || over_32_buffer[0] == 0x01) || (F_count_112 < L_count_112 ||over_112_buffer[0] == 0x01) ) && key_flag == 0)
	{
		I2C_ReadS_24C(LinkNetWorkCount,sendBuf,13);
		if((sendBuf[12] >= SEND_ALLERROR_COUNT) || 
			(sendBuf[time1[1]/2] >= SEND_HOUR_COUNT))//ÿ�쳬����������������
			  return;
                Page=open_gprs();
		if(Page == OK)
			{
				while((F_count_112 < L_count_112 || over_112_buffer[0] == 0x01) && key_flag == 0)
				{
					rectime -- ;
					/* ι��*/
					IWDG_ReloadCounter();//2015-12-23 andyluo
				  
					if(F_count_112 >= F_End_112_count)
					{
						F_count_112 = F_Start_112_count;
						over_112_buffer[0] = 0x00;
						I2C_WriteS_24C(Con_Flash_Record_112_Cursor_F,over_112_buffer,1);
					}
					else
					{
						if(over_112_buffer[0] == 0x01)
						{
							Page = (F_End_112_count - F_count_112) / 80;
						}
						else
						{
							Page = (L_count_112 - F_count_112) / 80;										 
						}
					}
										
					if(Page >= 5)
					  sendPage = 5 * 80;
					else
					{
						if(over_112_buffer[0] == 0x01)
						{
							sendPage = F_End_112_count - F_count_112;
						}
						else
						{
							sendPage = L_count_112 - F_count_112;
						}
					}
					  
				u32 oldvalue;   
				oldvalue=EXTI->IMR; //����ԭֵ  
				EXTI->IMR=0;	  
#ifndef  TESTEXTI
			    TMP.EXTIvalue = oldvalue;
#endif
				UART_DAEL_CODE(OFF);

					SPI_FLASH_Init();
					SPI_FLASH_BufferRead(buffer,F_count_112,sendPage);

				EXTI->IMR=oldvalue; //��ԭ
				UART_DAEL_CODE(ON);

					for(int i=0;i<RxCounter;i++)
					  RxBuffer[i] = 0x00;
					f_receiveOK =0;
					RxCounter =0;					
					L_count_112B = L_count_112;
					F_count_112B = F_count_112;
					L_count_112= F_count_112;
					F_count_112 = F_count_112 + sendPage; 	
					
					TMP.BaseFlag = JD_ZJ_MB_SYS();//1-������� 0-�м�(���)
					if(TMP.BaseFlag)
						{//���ϵͳ
#ifdef	MB_2G4	//�м̴���
						f_receiveOK = SenRecord_2G4(buffer,sendPage,80);
						//�����2.4G����
#else
						SendCon32Record(buffer,sendPage,80);
						rec_gprs_ack(3);				
#endif					
						}
					else
						{
						SendCon32Record(buffer,sendPage,80);
						rec_gprs_ack(3);	
						}

					
					if(key_flag)
					{
					  break;
					}
					else if(f_receiveOK)//2014-06-19 09:12:11 ����
						{
						L_count_112 = L_count_112B;							
						fll(F_count_112,Frist_buffer,3);						
						I2C_WriteS_24C(Con_Flash_Record_112_UDCSR,Frist_buffer,3);//д���ص��α�
						//��������ͻ���
						for(char i=0;i<13;i++)
						  sendBuf[i] = 0x00;
						I2C_WriteS_24C(LinkNetWorkCount,sendBuf,13);
						}	 
					else
						{
						L_count_112 = L_count_112B; 						
						F_count_112 = F_count_112B; 						
						if(rectime)continue;
						if(time1[1]/2 == 0)
							{
							sendBuf[11] = 0x00;
							}
						
						else
							{
							for(uchar i=0;i<time1[1]/2;i++)
								sendBuf[i] = 0x00;
							}
						sendBuf[time1[1]/2]++;
						if((time1[1] == 12) && (sendBuf[time1[1]/2] >= SEND_HOUR_COUNT))
						  sendBuf[12] = 0;//����Ϊ0
						else
						  sendBuf[12]++;//�����Ӽ�
						I2C_WriteS_24C(LinkNetWorkCount,sendBuf,13);
						GPRS_Power_OFF;
						break;
						}
					
				}				
				
				while((F_count_32 < L_count_32 || over_32_buffer[0] == 0x01)&& key_flag == 0)
				{
					/* ι��*/
					IWDG_ReloadCounter();//2015-12-23 andyluo
					rectime -- ;
					if(F_count_32 >= F_End_16_count)
					{
						F_count_32 = F_Start_16_count;
						over_32_buffer[0] = 0x00;
						I2C_WriteS_24C(Con_Flash_Record_16_Cursor_F,over_32_buffer,1);
					}
					else
					{
						if(over_32_buffer[0] == 0x01)
						{
							Page = (F_End_16_count - F_count_32) / 32;
						}
						else
						{
							Page = (L_count_32 - F_count_32) / 32;										  
						}
						
						if(Page >= 10)
						  sendPage = 10 * 32;
						else
						{
							if(over_32_buffer[0] == 0x01)
							{
								sendPage = F_End_16_count - F_count_32;
							}
							else
							{
								sendPage = L_count_32 - F_count_32;
							}
						}
						  
					u32 oldvalue;   
					oldvalue=EXTI->IMR; //����ԭֵ  
					EXTI->IMR=0;		
#ifndef  TESTEXTI
					TMP.EXTIvalue = oldvalue;
#endif
					UART_DAEL_CODE(OFF);
					SPI_FLASH_Init();
					SPI_FLASH_BufferRead(buffer,F_count_32,sendPage);
					EXTI->IMR=oldvalue; //��ԭ
					UART_DAEL_CODE(ON);
					for(int i=0;i<RxCounter;i++)
						RxBuffer[i] = 0x00;
					f_receiveOK =0;
					RxCounter =0;
					L_count_32B = L_count_32;
					F_count_32B = F_count_32;
					L_count_32= F_count_32;
					F_count_32 = F_count_32 + sendPage; 
					TMP.BaseFlag = JD_ZJ_MB_SYS();//1-������� 0-�м�(���)
					if(TMP.BaseFlag)
						{//���ϵͳ
						#ifdef	MB_2G4	//�м̴���
						f_receiveOK = SenRecord_2G4(buffer,sendPage,32);
						//�����2.4G����
						#else
						SendCon32Record(buffer,sendPage,32);
						rec_gprs_ack(3);					 
						#endif					
						}
					else
						{
						SendCon32Record(buffer,sendPage,32);
						rec_gprs_ack(3);
						}
						//if(ReceiveFlag != 0)
						  //break;
						
						if(key_flag)
						{
						  break;
						}
						else if(f_receiveOK)//2014-07-22 11:13:44����
							{
							L_count_32 = L_count_32B;
//							F_count_32 = F_count_32 + sendPage;							
							fll(F_count_32,Frist_buffer,3);					
							I2C_WriteS_24C(Con_Flash_Record_16_UDCSR,Frist_buffer,3);//д���ص��α�							 
							//��������ͻ���
							for(char i=0;i<13;i++)
							  sendBuf[i] = 0x00;
							I2C_WriteS_24C(LinkNetWorkCount,sendBuf,13);
							}
						else//2015-06-04 andyluo���� 
							{							
							L_count_32 = L_count_32B;
							F_count_32 = F_count_32B;
							if(rectime)continue;
							if(time1[1]/2 == 0)
								{
								sendBuf[11] = 0x00;
								}
							
							else
								{
								for(uchar i=0;i<time1[1]/2;i++)
									sendBuf[i] = 0x00;
								}
							sendBuf[time1[1]/2]++;
							if(time1[1] == 12 && sendBuf[time1[1]/2] >= SEND_HOUR_COUNT)
							  sendBuf[12] = 0;//����Ϊ0
							else
							  sendBuf[12]++;//�����Ӽ�
							I2C_WriteS_24C(LinkNetWorkCount,sendBuf,13);
							GPRS_Power_OFF;
							break;
							}
					}			
				}				
			}
		else
			{
			GPRS_Power_OFF;
			if(time1[1]/2 == 0)
				{
				sendBuf[11] = 0x00;
				}				
			else
				{
				for(uchar i=0;i<time1[1]/2;i++)
					sendBuf[i] = 0x00;
				}
			sendBuf[time1[1]/2]++;
			if(time1[1] == 12 && sendBuf[time1[1]/2] >= SEND_HOUR_COUNT)
				sendBuf[12] = 0;//����Ϊ0
			else
				sendBuf[12]++;//�����Ӽ�
			I2C_WriteS_24C(LinkNetWorkCount,sendBuf,13);
			}		
	}
	else
	{
								
	
	}
	////////////////////////////////////////////////////////////////////////////
}


//���� mifare���� ���ź� block2
void save_mifare_NO(uchar No[],uchar block2[],uchar car)
{
 
    switch(car)
    {
    case car1:
      I2C_WriteS_24C(car1_No,No,4);
      I2C_WriteS_24C(car1_block2,block2,16);
      break;
    case car2:
      I2C_WriteS_24C(car2_No,No,4);
      I2C_WriteS_24C(car2_block2,block2,16);
      break;
    case car3:
      I2C_WriteS_24C(car3_No,No,4);
      I2C_WriteS_24C(car3_block2,block2,16);
      break;
    case car4:
      I2C_WriteS_24C(car4_No,No,4);
      I2C_WriteS_24C(car4_block2,block2,16);
      break;
    default:break;
    }
}

//���� mifare���� ���ź� block2
void save_mifare_v0(uchar No[],uchar block0[],uchar car)
{
 
    switch(car)
    {
    case car1:
      I2C_WriteS_24C(car1_block0,block0,16);
      break;
    case car2:
      I2C_WriteS_24C(car2_block0,block0,16);
      break;
    case car3:
      I2C_WriteS_24C(car3_block0,block0,16);
      break;
    case car4:
      I2C_WriteS_24C(car4_block0,block0,16);
      break;
    default:break;
    }
}

//�ָ�����
uchar Mifare_RecoverV0(uchar No[],uchar car)
{
    uchar Mifare_NO[4];
    uchar block2_buffer[16];
    uchar i;
    uchar write_addr;
    switch(car)
    {
    case car1:
        I2C_ReadS_24C(car1_No,Mifare_NO,4);
        I2C_ReadS_24C(car1_block0,block2_buffer,16);               
        break;
        
        case car2:
		I2C_ReadS_24C(car2_No,Mifare_NO,4);
        I2C_ReadS_24C(car2_block0,block2_buffer,16);
        break;
        
        case car3:
		I2C_ReadS_24C(car3_No,Mifare_NO,4);
        I2C_ReadS_24C(car3_block0,block2_buffer,16);
        break;
        
        case car4:
		I2C_ReadS_24C(car4_No,Mifare_NO,4);
        I2C_ReadS_24C(car4_block0,block2_buffer,16);
        break;
        
    default:
      return 0;
      break;
    }
    
    for(i=0;i<4;i++)
    {
            if(Mifare_NO[i] != No[i])
              break;
    }
        
      
    if(i>=4)
    {
            
           write_addr = BLOCK0_ADDR;
            
        if(write_comd(write_addr,block2_buffer) == OK)
           return OK;//��ʾˢ��ʧ�ܣ�������ˢ��
        else
           return OK;
     }        
     else
        return NO;//��ʾ ����1
}


//�ָ�����
uchar Mifare_Recover(uchar No[],uchar car)
{
    uchar Mifare_NO[4];
    uchar block2_buffer[16];
    uchar i;
    uchar write_addr;
    switch(car)
    {
    case car1:
        I2C_ReadS_24C(car1_No,Mifare_NO,4);
        I2C_ReadS_24C(car1_block2,block2_buffer,16);               
        break;
        
        case car2:
        I2C_ReadS_24C(car2_No,Mifare_NO,4);
        I2C_ReadS_24C(car2_block2,block2_buffer,16);
        break;
        
        case car3:
        I2C_ReadS_24C(car3_No,Mifare_NO,4);
        I2C_ReadS_24C(car3_block2,block2_buffer,16);
        break;
        
        case car4:
        I2C_ReadS_24C(car4_No,Mifare_NO,4);
        I2C_ReadS_24C(car4_block2,block2_buffer,16);
        break;
        
    default:
      return 0;
      break;
    }
    
    for(i=0;i<4;i++)
    {
            if(Mifare_NO[i] != No[i])
              break;
    }
        
      
    if(i>=4)
    {
            
        if((block2_buffer[0] == MIFARAE_PARK_CARD)||
			(block2_buffer[0] == HLEPPARK_CARD))
           write_addr = BLOCK2_ADDR;
        else
           write_addr = BLOCK1_ADDR;
            
        if(write_comd(write_addr,block2_buffer) == OK)
           return OK;//��ʾˢ��ʧ�ܣ�������ˢ��
        else
           return OK;
     }        
     else
        return NO;//��ʾ ����1
}



//���� ����λ  ��λ ��ʹ���� �� ������һ����
uchar return_using(uchar card_no[],uchar car,uchar card_class)
{
  uchar buffer[16];
    switch(car)
            {
              case car1:
              I2C_ReadS_24C(car1_used_reference_info,buffer,16);
              break;             
              case car2:
              I2C_ReadS_24C(car2_used_reference_info,buffer,16);
              break;              
              case car3:
              I2C_ReadS_24C(car3_used_reference_info,buffer,16);
              break;              
              case car4:
              I2C_ReadS_24C(car4_used_reference_info,buffer,16);
              break;             
              default:break;              
            }
            
            if(buffer[0] == 0x66)
            {
                uchar j;
                
                if(card_class == CPU_CARD)
                {
                  for(j=0;j<8;j++)
                  {
                      if(buffer[j+1] != card_no[j])
                        break;
                  }
                
                  if(j >= 8)
                    return OK;
                    
                }
                else if(card_class == MIFARE_CARD)
                {
                  for(j=0;j<4;j++)
                  {
                       if(buffer[j+5] != card_no[3 - j])
                          break;
                  }
                
                  if(j >= 4)
                    return OK;
                }
                
            }   
    
              return NO;
      
}

//���� ����λ  ��λ ��ʹ���� �� ������һ����
uchar return_NO_using(uchar card_no[],uchar car,uchar card_class)
{
  uchar buffer[16];
    switch(car)
            {
              case car1:
              I2C_ReadS_24C(car1_used_reference_info,buffer,16);
              break;             
              case car2:
              I2C_ReadS_24C(car2_used_reference_info,buffer,16);
              break;              
              case car3:
              I2C_ReadS_24C(car3_used_reference_info,buffer,16);
              break;              
              case car4:
              I2C_ReadS_24C(car4_used_reference_info,buffer,16);
              break;             
              default:break;              
            }
            
            if(buffer[0] == 0x00)
            {
                uchar j;
                
                if(card_class == CPU_CARD)
                {
                  for(j=0;j<8;j++)
                  {
                      if(buffer[j+1] != card_no[j])
                        break;
                  }
                
                  if(j >= 8)
                    return OK;
                    
                }
                else if(card_class == MIFARE_CARD)
                {
                  for(j=0;j<4;j++)
                  {
                       if(buffer[j+5] != card_no[3 - j])
                          break;
                  }
                
                  if(j >= 4)
                    return OK;
                }
                
            }   
    
              return NO;
      
}

//����Flash���������
void Erased_sector()
{
    //000000H --> 0C3500H  ������ 10���� ÿ��8�ֽ�
    //0D0000H --> 193500H  2.5������¼ ÿ��32�ֽ�
    //1A0000H --> 6F7300H  5������¼ ÿ��112�ֽ�
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
    
    //�����ȹر� �����ж�
    DISABLE_EXTI15_10_IRQ();
    DISABLE_EXTI9_5_IRQ();
    
    
    
    SPI_FLASH_Init();
    
    uchar Cursor_buffer[3];
    uchar erased_flag_buf_F[1];
    uchar erased_flag_buf_L[1];
    
    unsigned long Cursor_addr;
    unsigned long Cursor_erased_addr;
    
    I2C_ReadS_24C(Con_Flash_Record_16_Cursor,Cursor_buffer,3);//�� ��¼���α�
    I2C_ReadS_24C(Flash_erased_sector_32_F,erased_flag_buf_F,1);//�� ������ַ���α� ��־
    I2C_ReadS_24C(Flash_erased_sector_32_L,erased_flag_buf_L,1);//�� ������ַ���α� ��־
                       
    Cursor_addr = hcl(Cursor_buffer,3);    
    
    if(Cursor_addr >= 0x130000 && erased_flag_buf_F[0] == 0x66)
    {
        Cursor_erased_addr = 0x0D0000;
        while(Cursor_erased_addr < 0x120000)
        {
            SPI_FLASH_SectorErase(Cursor_erased_addr);
            Cursor_erased_addr = Cursor_erased_addr + 0x010000;
        }
        
        Cursor_erased_addr = 0x190000;
        SPI_FLASH_SectorErase(Cursor_erased_addr);
        
        erased_flag_buf_F[0] = 0x00;
        I2C_WriteS_24C(Flash_erased_sector_32_F,erased_flag_buf_F,1);//�� ������ַ���α� ��־
        
        
        
        erased_flag_buf_L[0] = 0x66;
        I2C_WriteS_24C(Flash_erased_sector_32_L,erased_flag_buf_L,1);//�� ������ַ���α� ��־
    }
    else if(Cursor_addr < 0x130000 && erased_flag_buf_L[0] == 0x66)
    {
        Cursor_erased_addr = 0x120000;
        while(Cursor_erased_addr < 0x190000)
        {
            SPI_FLASH_SectorErase(Cursor_erased_addr);
            Cursor_erased_addr = Cursor_erased_addr + 0x010000;
        }
        
        erased_flag_buf_L[0] = 0x00;
        I2C_WriteS_24C(Flash_erased_sector_32_L,erased_flag_buf_L,1);//�� ������ַ���α� ��־
        
        
        erased_flag_buf_F[0] = 0x66;
        I2C_WriteS_24C(Flash_erased_sector_32_F,erased_flag_buf_F,1);//�� ������ַ���α� ��־
    }
    
    
    
    
    
    I2C_ReadS_24C(Con_Flash_Record_112_Cursor,Cursor_buffer,3);//�� ��¼���α�
    I2C_ReadS_24C(Flash_erased_sector_112_F,erased_flag_buf_F,1);//�� ������ַ���α� ��־
    I2C_ReadS_24C(Flash_erased_sector_112_L,erased_flag_buf_L,1);//�� ������ַ���α� ��־
                       
    Cursor_addr = hcl(Cursor_buffer,3);    
    
    if(Cursor_addr >= 0x450000 && erased_flag_buf_F[0] == 0x66)
    {
        Cursor_erased_addr = 0x1A0000;
        while(Cursor_erased_addr < 0x440000)
        {
            SPI_FLASH_SectorErase(Cursor_erased_addr);
            Cursor_erased_addr = Cursor_erased_addr + 0x010000;
        }
        
        Cursor_erased_addr = 0x6F0000;
        SPI_FLASH_SectorErase(Cursor_erased_addr);
        
        erased_flag_buf_F[0] = 0x00;
        I2C_WriteS_24C(Flash_erased_sector_112_F,erased_flag_buf_F,1);//�� ������ַ���α� ��־
        
        
        
        erased_flag_buf_L[0] = 0x66;
        I2C_WriteS_24C(Flash_erased_sector_112_L,erased_flag_buf_L,1);//�� ������ַ���α� ��־
    }
    else if(Cursor_addr < 0x450000 && erased_flag_buf_L[0] == 0x66)
    {
        Cursor_erased_addr = 0x440000;
        while(Cursor_erased_addr < 0x6F0000)
        {
            SPI_FLASH_SectorErase(Cursor_erased_addr);
            Cursor_erased_addr = Cursor_erased_addr + 0x010000;
        }
        
        erased_flag_buf_L[0] = 0x00;
        I2C_WriteS_24C(Flash_erased_sector_112_L,erased_flag_buf_L,1);//�� ������ַ���α� ��־
        
        
        erased_flag_buf_F[0] = 0x66;
        I2C_WriteS_24C(Flash_erased_sector_112_F,erased_flag_buf_F,1);//�� ������ַ���α� ��־
    }

    //�� ���� �ж�
    OPEN_EXTI9_5_IRQ();                                                      
    OPEN_EXTI15_10_IRQ();
    
    lcd_clear();
    LCD_POWER_OFF;
    lcd_res_0;           
    LCD_back_OFF; 
}

unsigned char mathweek(unsigned char niana,unsigned char yuea, unsigned char ria)
{
  unsigned int  mathday;
  unsigned char loop6,ww;
  ww=((niana>>4)&0x0f)*10;
  niana=ww+(niana&0x0f);
  ww=((yuea>>4)&0x0f)*10;
  yuea=ww+(yue&0x0f);
  ww=((ria>>4)&0x0f)*10;
  ria=ww+(ria&0x0f);
  mathday=0;
  for(loop6=6;loop6<niana;loop6++)
  {
	if(loop6%4==0)
	{
	 mathday=mathday+366;
	}
	else
	{
	 mathday=mathday+365;
	}
  }
  for(loop6=1;loop6<yuea;loop6++)
  {
      if(loop6==2)
	  {
	   if(niana%4==0)
		{
		 mathday=mathday+29;
		}
		else
		{
		 mathday=mathday+28;
		}
	  }
	  else
	  {
	    if((loop6==4)||(loop6==6)||(loop6==9)||(loop6==11))
		{
		  mathday=mathday+30;
		}
		else
		{
		 mathday=mathday+31;
		}
	  }    
  }
  mathday=mathday+(ria-1);
  ww=mathday%7;
  return ww;
}



//unsigned char mathweek(unsigned char year,unsigned char month, unsigned char date)
//{
//  unsigned int  mathday;
//  unsigned char loop6,ww;
//  ww=((year>>4)&0x0f)*10;
//  year=ww+(year&0x0f);
//  ww=((yue>>4)&0x0f)*10;
//  month=ww+(month&0x0f);
//  ww=((date>>4)&0x0f)*10;
//  date=ww+(date&0x0f);
//  mathday=0;
//  for(loop6=6;loop6<year;loop6++)
//  {
//	if(loop6%4==0)
//	{
//	 mathday=mathday+366;
//	}
//	else
//	{
//	 mathday=mathday+365;
//	}
//  }
//  for(loop6=1;loop6<yue;loop6++)
//  {
//      if(loop6==2)
//	  {
//	   if(year%4==0)
//		{
//		 mathday=mathday+29;
//		}
//		else
//		{
//		 mathday=mathday+28;
//		}
//	  }
//	  else
//	  {
//	    if((loop6==4)||(loop6==6)||(loop6==9)||(loop6==11))
//		{
//		  mathday=mathday+30;
//		}
//		else
//		{
//		 mathday=mathday+31;
//		}
//	  }    
//  }
//  mathday=mathday+(ri-1);
//  ww=mathday%7;
//  return ww;
//}	

void Check_System_Status(void)
{
    
    long timeOut;
 
    
    Smart_Power_OFF;
                                    
    OPEN_EXTI9_5_IRQ();                                                                                  
    OPEN_EXTI15_10_IRQ();
                                                                        
    check_card();//��ʾ ��⵽��ϵͳ����                                    
    timeOut = 0;                                                                                       
                                   
    while(timeOut < KEYTIMEOUT_1S * 2)                                                                                     
    {                                                                                                                              
      if(key_flag){                                                                                                                              
//        key_flag = 0; 
//        if(key_flag == 0x01 || key_flag == 0x02)
//        {
//            key_flag = 0x00;
//        }
//        delay(KEYTIMEOUT_1S * QUIT_TIME);                                                                                                                     
        break;                                                                                                                         
      }                                                                                                                          
      timeOut++;                                                                                                                        
    }
                                    
                                    
    //������ ��ʾ����
                                    
    display_rate();   
	key_flag = 0x00;
    timeOut = 0;                                                                                                                           
    while(timeOut < KEYTIMEOUT_1S * 1.5)                                                                                                                         
    {                                                                                                                              
      if(key_flag){                                                                                                                                
//         if(key_flag == 0x01 || key_flag == 0x02)
//         {
//            key_flag = 0x00;
//         }                                                                                    
//        delay(KEYTIMEOUT_1S * QUIT_TIME);                                                                                 
        break;                                                                                                                                  
      }                                                                                                                            
      timeOut++;                                                                                     
    }
                                        
    /*
    //������ʾ�Է���������������   
    I2C_ReadS_24C(MIFARE_BACLK_DAY_ADD_AC + 8,Buffer,4); //��FLASH����������� ����
    Inc_Count = hcl(Buffer,4);
    memset(Buffer,0,4);
        
    I2C_ReadS_24C(MIFARE_BACLK_DAY_REDUC_AC + 8,Buffer,4); //��FLASH����������� ����
    Dec_Count = hcl(Buffer,4);    
   
    if(key_flag == 0x00)
      DisplayMIFAREBcakList(Inc_Count,Dec_Count);
    
    timeOut = 0;                                                                                                                           
    while(timeOut < KEYTIMEOUT_1S * 2)                                                                                                                         
    {                                                                                                                              
      if(key_flag){                                                                                                                                
         if(key_flag == 0x01 || key_flag == 0x02)
        {
            key_flag = 0x00;
        }                                                                                   
        delay(KEYTIMEOUT_1S * QUIT_TIME);                                                                                 
        break;                                                                                                                                  
      }                                                                                                                            
      timeOut++;                                                                                     
    }
    
    
    if(key_flag == 0x00)
      displaySendRecord();
    timeOut = 0;                                                                                                                           
    while(timeOut < KEYTIMEOUT_1S * 2)                                                                                                                         
    {                                                                                                                              
      if(key_flag){                                                                                                                                
         if(key_flag == 0x01 || key_flag == 0x02)
        {
            key_flag = 0x00;
        }                                                                                 
        delay(KEYTIMEOUT_1S * QUIT_TIME);                                                                                 
        break;                                                                                                                                  
      }                                                                                                                            
      timeOut++;                                                                                     
    }*/
  	key_flag = 0x00;  
    if(key_flag == 0x00)
      displayIAP();
    timeOut = 0;    
	key_flag = 0x00;
    while(timeOut < KEYTIMEOUT_1S * 2)                                                                                                                         
    {                                                                                                                              
      if(key_flag){                                                                                                                                
//         if(key_flag == 0x01 || key_flag == 0x02)
//        {
//            key_flag = 0x00;
//        }                                                                                   
//        delay(KEYTIMEOUT_1S * QUIT_TIME);                                                                                 
        break;                                                                                                                                  
      }                                                                                                                            
      timeOut++;                                                                                     
    }
    /*
    if(key_flag == 0x00)
      displayLNT_BackList();
    timeOut = 0;                                                                                                                           
    while(timeOut < KEYTIMEOUT_1S * 2)                                                                                                                         
    {                                                                                                                              
      if(key_flag){                                                                                                                                
         if(key_flag == 0x01 || key_flag == 0x02)
        {
            key_flag = 0x00;
        }                                                                                   
        delay(KEYTIMEOUT_1S * QUIT_TIME);                                                                                 
        break;                                                                                                                                  
      }                                                                                                                            
      timeOut++;                                                                                     
    }
    */
    key_flag = 0x00;
}


//����PSAM���ĳ��� ÿ��5���ϵ� �µ�һ��
uchar Test_PSAM(void)
{
    uchar timeOut;
    uchar read_mech_ID_flag;
    
    //4.���������
        timeOut = 0;
        read_mech_ID_flag = NO;
        while(timeOut < 4)
        {
            if(read_mech_ID() == 0x00)
            {
                read_mech_ID_flag = OK;
                break;
            }
            
            timeOut++;
        }
        
        if(read_mech_ID_flag == OK)
        {
            //������ ����
            display_reader_P(1,2);
        }
        else
        {
            //������ ����
            display_reader_P(0,2);
        }
        delay(KEYTIMEOUT_1S * 0.5);
        //5.PSAM�����
        timeOut = 0;
        read_mech_ID_flag = NO;
        while(timeOut < 4)
        {
            if(read_PSAM() == 0x00)
            {
                read_mech_ID_flag = OK;
                break;
            }
            
            timeOut++;
        }
        
        if(read_mech_ID_flag == OK)
        {
            //PSAM�� ����
            display_PSAM(0x01,2);
            delay(KEYTIMEOUT_1S * 1);
            return 1;
            
        }
        else
        {
            //PSAM�� ����
            display_PSAM(0x00,2);
            delay(KEYTIMEOUT_1S * 1);
            return 0;
        }
        
}

void WriteRecover(uchar car,uchar value)
{
    uchar buffer[1];
    buffer[0] = value;
    switch(car)
    {
        case car1:              
          I2C_WriteS_24C(car1_Recover,buffer,1);             
        break;  
        
        case car2:              
          I2C_WriteS_24C(car2_Recover,buffer,1);             
        break;
        
        case car3:              
          I2C_WriteS_24C(car3_Recover,buffer,1);             
        break;
        
        case car4:              
          I2C_WriteS_24C(car4_Recover,buffer,1);             
        break;
        
    default:break;
    }
}

uchar ReadRecover(uchar car)
{
    uchar buffer[1];
    switch(car)
    {
        case car1:              
          I2C_ReadS_24C(car1_Recover,buffer,1);             
        break;  
        
        case car2:              
          I2C_ReadS_24C(car2_Recover,buffer,1);             
        break;
        
        case car3:              
          I2C_ReadS_24C(car3_Recover,buffer,1);             
        break;
        
        case car4:              
          I2C_ReadS_24C(car4_Recover,buffer,1);             
        break;
        
    default:break;
    }
    
    return buffer[0];
}

void WriteRecord(uchar car,uchar value)
{
    uchar buffer[1];
    buffer[0] = value;
//    buffer[0] = TMP.cardplace;
    switch(car)
    {
        case car1:              
          I2C_WriteS_24C(Car1_RecordFlag,buffer,1);             
        break;  
        
        case car2:              
          I2C_WriteS_24C(Car2_RecordFlag,buffer,1);             
        break;
        
        case car3:              
          I2C_WriteS_24C(Car3_RecordFlag,buffer,1);             
        break;
        
        case car4:              
          I2C_WriteS_24C(Car4_RecordFlag,buffer,1);             
        break;
        
    default:break;
    }
}

uchar ReadRecord(uchar car)
{
    uchar buffer[1];
    switch(car)
    {
        case car1:              
          I2C_ReadS_24C(Car1_RecordFlag,buffer,1);             
        break;  
        
        case car2:              
          I2C_ReadS_24C(Car2_RecordFlag,buffer,1);             
        break;
        
        case car3:              
          I2C_ReadS_24C(Car3_RecordFlag,buffer,1);             
        break;
        
        case car4:              
          I2C_ReadS_24C(Car4_RecordFlag,buffer,1);             
        break;
        
    default:break;
    }
    TMP.cardplace = buffer[0];
    return buffer[0];
}

//����һ�� 16�ֽڵ����Ѽ�¼
/*************************
record ��¼����
RecordPage ��¼����
RecordCount ��¼��С 32 �� 112
*************************/
//void OldSendCon32Record(uchar record[],int RecordPage,uchar RecordCount1)
//{

//    unsigned char  sz3[4];
//    I2C_ReadS_24C(mibiao_number,sz3,3);//�����
//    uart_send_som("*0%");
//    
//    SEND_asic_2th(sz3[0]);//����� 3�ֽ�
//    SEND_asic_2th(sz3[1]);
//    SEND_asic_2th(sz3[2]);
//    
//    SEND_asic_2th((RecordPage / RecordCount1) / 256);// �������� 2�ֽ� Hex
//    SEND_asic_2th((RecordPage / RecordCount1) % 256);
//    
//    for(int i=0;i < RecordPage;i++)
//      SEND_asic_2th(record[i]);    
//    
//    uart_send_som("#");
//}



//<Time><2015-07-17|18:25:10></Time>  2015-08-08
void Send_Segtime(void)
{
#ifndef CPUSN
	u32 ChipUniqueID[3];
	u16 STM32_FLASH_SIZE_LEN,i;
	
	ChipUniqueID[0] = *(__IO u32 *)(0X1FFFF7F0); // ���ֽ�
	ChipUniqueID[1] = *(__IO u32 *)(0X1FFFF7EC); //
	ChipUniqueID[2] = *(__IO u32 *)(0X1FFFF7E8); // ���ֽ�
	STM32_FLASH_SIZE_LEN= *(u16*)(0x1FFFF7E0);	  //���������Ĵ���	
	
	uart_send_som("<CSN><");  //ʱ�� 
	SEND_asic_2th(STM32_FLASH_SIZE_LEN>>8);
	SEND_asic_2th(STM32_FLASH_SIZE_LEN);
	uart_send_som(":");
	for(i=0;i<4;i++)
		SEND_asic_2th(ChipUniqueID[0]>>(8*(3-i)));
	uart_send_som("-");
	for(i=0;i<4;i++)
		SEND_asic_2th(ChipUniqueID[1]>>(8*(3-i)));
	uart_send_som("-");
	for(i=0;i<4;i++)
		SEND_asic_2th(ChipUniqueID[2]>>(8*(3-i)));	
	uart_send_som("></CSN>");
#endif	
	uart_send_som("<Time><20");  //ʱ�� 
	SEND_asic_2th(time[4]);
	uart_send_som("-");
	SEND_asic_2th(time[3]);
	uart_send_som("-");
	SEND_asic_2th(time[2]);
	uart_send_som("|");
	SEND_asic_2th(time[1]);
	uart_send_som(":");
	SEND_asic_2th(time[0]);
	uart_send_som(":");
	SEND_asic_2th(0);  
	uart_send_som("></Time>");
}
/*
2828CC XX 01 FX 12345678 DATA XOR CCCC
F0-�м������ F5-�м����м� F6-�������� F7-�ȴ��ظ�
�������Ϊ30����ʾ�ŵ���ռ��
2-1-1��������¼
�����֣�	F0
���ģ�		A1+�����м̺š�4��+��/��ǰ���š�2+2��+16/32*N�ֽڼ�¼��N<=14/7��
*/

//���ͷ���1-�ɹ� 0-ʧ��
u8 SenRecord_2G4(uchar record[],u16 RecordPage,uchar RecordCount1)
{
//28 28 CC 29 00 F0 12 34 01 02 A3 12 34 01 01 00 01 00 01 
u8 const rdbuf[64]={0x28,0x28,0xCC,0x29,0x00,0xF0,0x12,0x34,0x01,0x02,
				0xA3,0x12,0x34,0x01,0x01,0x00,0x01,0x00,0x01};
u8 xor=0xff,mbno[4],rcmd,ret;
u16 i,j,leng,sendsn,recsn;

	//DISABLE_EXTI9_5_IRQ();	
	memcpy(CarBuffer,rdbuf,19);
    I2C_ReadS_24C(mibiao_number,mbno,3);//�����
	memcpy(CarBuffer+6,mbno,3);
	
	if(RecordCount1==32)
		{
		CarBuffer[10] = G24_Mode_A1;
		//CarBuffer[15-16];��¼��ˮ�� 2016-04-08
		I2C_ReadS_24C(SYS_FEESN,CarBuffer+15,2);	
		sendsn = hcl(CarBuffer+15,2);
		}
	else if(RecordCount1==16)
		CarBuffer[10] = G24_Mode_A2;
	else if(RecordCount1==80)
		CarBuffer[10] = G24_Mode_A3;
	
	mbno[2] = 0;	
	mbno[3] = 0;	
	memcpy(CarBuffer+11,mbno,4);	
//	CarBuffer[15] = time[1];
//	CarBuffer[16] = time[0];
//	CarBuffer[17] = time[1];
//	CarBuffer[18] = time[0]
	CarBuffer[14] = L_count_32>>16;
//	CarBuffer[15] = L_count_32>>8;
//	CarBuffer[16] = L_count_32>>0;
	CarBuffer[17] = L_count_32>>8;
	CarBuffer[18] = L_count_32>>0;
	leng = RecordPage;//*RecordCount1;
	i=19;//��Ч���ݿ�ʼ
	memcpy(CarBuffer+i,record,leng);
	for(j=5;j<i+leng;j++)
		xor ^= CarBuffer[j];
	//�޸�У���㷨
	xor = 0xff-xor;
	xor += 0x15;
	CarBuffer[j++] = xor;
	CarBuffer[j++] = 0xCC;
	CarBuffer[j++] = 0xCC;
	leng = j-6;
	CarBuffer[3] = leng;
	CarBuffer[4] = leng>>8;	
	
	IWDG_ReloadCounter();
	TMP.COM4 = OFF;
	UART4_IRQn_CTL(OFF);

	open_ir_comm(); 
	delay_key(KEYTIMEOUT_1S);
	Uart4_Configuration(BaudRate_19200);
//	irDA_pdamode_ON;
	key_flag = 0;
	ret= 0;
	i=1;
    I2C_ReadS_24C(mibiao_number,mbno,3);//�����
	while(i--)
		{
		#ifdef TWO_CAR4
		OPEN_EXTI9_5_IRQNEW(); 	
		#endif
		delay_key(KEYTIMEOUT_1S/100);
		IWDG_ReloadCounter();
		USART_SendDataPacket(UART4 ,j,CarBuffer);
		RxBuffer[0] = 0x55;
		RxBuffer[1] = 0x55;
//		delay(KEYTIMEOUT_1S/100);
		rcmd = rev_ack_new(RxBuffer);//������		
		IWDG_ReloadCounter();
		if(key_flag)break;
		//rdbuf[5];//������ rdbuf[14-15];OK//��������
		if((mbno[0]!=RxBuffer[0])||
			(mbno[1]!=RxBuffer[1])||
			(mbno[2]!=RxBuffer[2]))
			{
//			rcmd = Sync_MtoB_Info(G24_Mode_C2,NULL,NULL);
			continue;
			}
		if((rcmd==0xF0)&&(RxBuffer[13]=='O')&&(RxBuffer[14]=='K'))
			{			
			if(RecordCount1==32)
				{
				recsn = hcl(RxBuffer+9,2);
				if(sendsn!=recsn)break;
				}
			//rdbuf[15-19]//time
//			memcpy(rdbuf,rdbuf+15,5);
//			rdbuf[5]=mathweek(rdbuf[2],rdbuf[3],rdbuf[4]);				  
//			set_current_time(rdbuf);	
			ret=1;
			break;
			}	
		}
	close_ir_comm(); 
	//memset(CarBuffer,0,j);	
	return ret;
}


//�´��Э��
void SendCon32Record(uchar record[],u16 RecordPage,uchar RecordCount1)
{
/*
*<Long><0196></Long><Result><Optype><EEEE></Optype><Metno><000063></Metno><Bagsum><0020></Bagsum><Record><���Ѵ����¼></Record></Result># 
���Ѵ����¼ÿ����¼˵����
ÿ����32�ֽڹ��ɣ���<Metno><000063></Metno>�˴������ֻ������������ţ���������¼��������ţ���¼�������������ÿ��32�ֽ��С���
EE��1�ֽ�-�̶���־��+����š�4�ֽڣ����ǵ��������������ʱ�Դ������Ϊ��׼��+���š�4�ֽڡ�+�볡ʱ�䡾5�ֽڡ�+ԭ��3�ֽڡ�+���ѽ�2�ֽڡ�+���Ѽ�¼��־��1�ֽڡ�+����ʱ�䡾5�ֽڡ�+�����͡�1�ֽ�-Ĭ��Ϊ1��+���á�6�ֽ�-�̶�AA��*/

u8  crc1,crc2,sz3[4],crcorg[16];
u16 crc,i;
	if(RecordPage==0)return;//2015-12-21
#ifdef MU509B
	//MUPֱ�ӿ���3Gģ��
	EmptyRcv3G();	 
	send_string_3G("AT^IPSEND=1,\"");  
	uart_send_som("*<Long><0196></Long><Result>");
#else	
	uart_send_som("*0%<Long><0196></Long><Result>");
#endif
	Send_Segtime();
    I2C_ReadS_24C(mibiao_number,sz3,3);//�����
    if(RecordCount1>32)
		uart_send_som("<Optype><EDED></Optype><Metno><");
	else
		uart_send_som("<Optype><EEEE></Optype><Metno><");
    SEND_asic_2th(0x66);    
    SEND_asic_2th(sz3[0]);//����� 3�ֽ�
    SEND_asic_2th(sz3[1]);
    SEND_asic_2th(sz3[2]);
	
    uart_send_som("></Metno><Add><");
    SEND_asic_2th(L_count_32>>16);
    SEND_asic_2th(L_count_32>>8);
    SEND_asic_2th(L_count_32>>0);
    uart_send_som("--");
    SEND_asic_2th(F_count_32>>16);
    SEND_asic_2th(F_count_32>>8);
    SEND_asic_2th(F_count_32>>0);
    uart_send_som("></Add><Bagsum><");
    SEND_asic_2th((RecordPage / RecordCount1) / 256);// �������� 2�ֽ� Hex
    SEND_asic_2th((RecordPage / RecordCount1) % 256);
    uart_send_som("></Bagsum><Record><");
    
    for(i=0;i < RecordPage;i++)
      SEND_asic_2th(record[i]);    
    if(RecordCount1>32)
		uart_send_som("></Record></Result>#");
	else
		{
		uart_send_som("></Record><Crc><");
		memcpy(crcorg,record,32);
		crc1 = crcorg[0];
		for(i=1;i<32;i++)
			crc1 ^= crcorg[i];//���У��
		crc2 = crcorg[5];
		for(i=6;i<9;i++)
			crc2 ^= crcorg[i];//���У��
		crc = crc1 - crc2;	  //����	
		crc += 'L';			  //����
		crc += 'U';			  //����
		crc += 'O';			  //����
		crc = 0xffff-crc;	  //ȡ��
		crc1 = crc>>8;
		crc2 = crc;		
		if(crc1)
			SEND_asic_2th(crc1);	 
		SEND_asic_2th(crc2);	 
		uart_send_som("></Crc></Result>#");	
		crc1 = crc>>16;
		crc2 = crc;		
		}
#ifdef MU509B
		USART_Putc(USART1,'"');
		USART_Putc(USART1,0x0d);//�س�����
		USART_Putc(USART1,0x0a);		
#endif
}
// ���� Ϊ����32�ֽڼ�¼������
int ReturnRecordCount()
{
    int Count;
    unsigned long StartCount;//��ʼ��ַ
    unsigned long EndCount;//������ַ
    unsigned long SendCount;//���͵�ַ
    unsigned long SaveRecordCount;//���¼���α��ַ
    unsigned long count_32;//32�ֽڵļ�¼����
         
    uchar Start_buf[3];
    uchar End_buf[3]; 
    uchar Send_buf[3];
    uchar SaveRecord_buf[3];
    uchar Flag_buf[1];
    
    I2C_ReadS_24C(Con_Flash_Record_16_Start_Addr,Start_buf,3);//��¼�Ŀ�ʼ��ַ
    I2C_ReadS_24C(Con_Flash_Record_16_End_Addr,End_buf,3);//��¼�Ľ�����ַ
    I2C_ReadS_24C(Con_Flash_Record_16_UDCSR,Send_buf,3);//���͵��α�        
    I2C_ReadS_24C(Con_Flash_Record_16_Cursor,SaveRecord_buf,3);//���¼���α�
    
    
    I2C_ReadS_24C(Con_Flash_Record_16_Cursor_F,Flag_buf,1);//���ζ��е� ��־
    
    SendCount = hcl(Send_buf,3);
    SaveRecordCount = hcl(SaveRecord_buf,3);
    
    if(Flag_buf[0] == 1)//���� ���
    {
        StartCount = hcl(Start_buf,3);
        EndCount = hcl(End_buf,3);
        
        count_32 = (SaveRecordCount - StartCount) + (EndCount - SendCount);                
    }
    else
    {
        count_32 = SaveRecordCount - SendCount; 
    }
    
    Count = count_32 / 32;
    
    
    return Count;
}
void RecordSendingMechanism(void)
{
    uchar Hour;
    uchar Minute,netmin;
    uchar SendTime;
    uchar falseEndTimes;
    uchar falseTime;
    uchar NSRCount;
    uchar falseEndTimesBack;
    
    uchar buffer[16];
    uchar MaterBuf[3];
    int NoSendRecordCount;
    
    
    GetCurrentTime();
    Hour = time1[1];
    Minute = time1[0];
    
    I2C_ReadS_24C(SendInterval,buffer,1);//��ȡ ���ͼ��ʱ��
    SendTime = buffer[0];
    I2C_ReadS_24C(RecordCount,buffer,1);//��ȡ δ���ͼ�¼������
    NSRCount = buffer[0];
    I2C_ReadS_24C(ResidueDegree,buffer,1);//��ȡ ����ʧ�ܺ�� ����ʣ�����
    falseEndTimes = buffer[0];
    I2C_ReadS_24C(FalseInterval,buffer,1);//��ȡ ����ʧ�ܺ�� ���͵ļ��
    falseTime = buffer[0];
    
    I2C_ReadS_24C(ResidueDegreeBack,buffer,1);//��ȡ ����ʧ�ܺ�� ����ʣ�����
    falseEndTimesBack = buffer[0];

//99 04 06 10 02 28 04 04 04 24
//-3H�շ�ʱ�η���¼���Сʱ(��ǰʱ��/N�����������)
//-3LÿСʱ����¼ģʽ:0/1/X=ʵʱ/��ʮ����/�������ŷ�15����
//-4H��λ=Aȫ��ʵʱ����¼
	I2C_ReadS_24C(LISTNET_ADD,buffer,16);//0-��־99 1- 2- 3-���ͼ��Ƶ�� 4- 5-Υ��ʱ��
	SendTime = (buffer[3]&0xf0)>>4;
	netmin = buffer[3]&0x0f;
 	if(netmin == 0)
		;
	else if(netmin <6)
		netmin = 60-netmin*10;
	else if(netmin >=6)
		netmin = 50;
	if((((buffer[4]&0xf0)>>4)==0x0A)||(SendTime==0)) //ʵʱ���ͼ�¼
		{
		SendTime = 1;
		netmin = 0;
		}
	
    NoSendRecordCount = ReturnRecordCount();
    if(NoSendRecordCount > 0)//�м�¼ δ����
    	{
        if(NoSendRecordCount >= NSRCount)//�ﵽ ���δ���ͼ�¼
        	{
            SendPage_Record();//���ͼ�¼
            }
        else if((Hour >= 6)&&(Hour%SendTime) == 0)
			{
			if(Minute >= netmin)
				SendPage_Record();//���ͼ�¼
        	}
//            {
//			if(falseEndTimes > 0)//���ͼ�¼ʱ�����ͻ����˼����˳��Ժ��ʣ�� ����
//                {
//				I2C_ReadS_24C(mibiao_number,MaterBuf,3); // �����
//                MaterBuf[2] = MaterBuf[2] % 60;
//				if(Minute >= MaterBuf[2])
//					{
//					Minute = Minute - MaterBuf[2];
//					if((Minute <= falseEndTimesBack * falseTime) && (Minute % falseTime == 0))
//                        {
//						SendPage_Record();
//						if(key_flag)
//							{
//							falseEndTimes--;
//							buffer[0] = falseEndTimes;
//							I2C_WriteS_24C(ResidueDegree,buffer,1);
//                            }
//						}
//					}
//				}
//			else
//				{
//				I2C_ReadS_24C(ResidueDegreeBack,buffer,1);
//                I2C_WriteS_24C(ResidueDegree,buffer,1);
//                }
//			}
    }
     
}

void WriteReplenishmentNo_Monery(uchar *NoBuf,uchar *MoneryBuf)
{
    I2C_WriteS_24C(ReplenishmentNo,NoBuf,8);
    I2C_WriteS_24C(ReplenishmentMonery,MoneryBuf,4);
    
}

uchar ReadReplenishmentNo(uchar *NoBuf)
{
    uchar i;
    uchar buffer1[8];
    I2C_ReadS_24C(ReplenishmentNo,buffer1,8);
    for(i=0;i<8;i++)
    {
        if(buffer1[i] != NoBuf[i])
          break;
    }
    
    if(i >= 8)
      return 1;
    else
      return 0;
}



uchar IsOutRecord(uchar *buffer)
{
    uchar flag;
    flag = buffer[19];
    flag = flag&0x0F;
    
    if(flag == 0x02)
      return 1;
    else
      return 0;
    
    
}

int CalcalateStopTime(uchar StartTime[],uchar StopTime[])
{
    uchar get_month;
    uchar get_date;
    uchar get_hour;
    int get_min;
    
    uchar month;
    uchar date;
    int hour;
    int min;
    
    uchar last_month;
       
    get_month = ((StartTime[0]>>4)&0x0f) * 10 + (StartTime[0]&0x0f);
    get_date = ((StartTime[1]>>4)&0x0f) * 10 + (StartTime[1]&0x0f);
    get_hour = ((StartTime[2]>>4)&0x0f) * 10 + (StartTime[2]&0x0f);   
    get_min =   ((StartTime[3]>>4)&0x0f) * 10 + (StartTime[3]&0x0f);
    
    month = ((StopTime[0]>>4)&0x0f) * 10 + (StopTime[0]&0x0f);
    date = ((StopTime[1]>>4)&0x0f) * 10 + (StopTime[1]&0x0f);
    hour = ((StopTime[2]>>4)&0x0f) * 10 + (StopTime[2]&0x0f);
    min = ((StopTime[3]>>4)&0x0f) * 10 + (StopTime[3]&0x0f);
    
    month = month - get_month;
    if(month > 0) //ͣ��ʱ�� ����
    {   
          last_month = ret_end_month(get_month);
          date = (month - 1)*30 + (last_month - get_date) + date; //�������31 �϶��������
          if(date > 0) //ͣ��ʱ�� ����
          {
              hour = (date - 1)*24 + (24-get_hour) + hour;
              if(hour > 0)
              {
                  min = (hour-1)*60 + (60 - get_min) + min;
              }
              else
              {
                  min = min - get_min;
              }
          }
          else
          {
              hour = hour - get_hour;
              if(hour > 0)
              {
                  min = (hour-1)*60 +(60 - get_min) + min;
              }
              else
              {
                  min = min - get_min;
              }
          }
      }
      else
      {
          date = date - get_date;
          if(date > 0) //ͣ��ʱ�� ����
          {
              hour = (date - 1)*24 + (24-get_hour) + hour;
              if(hour > 0)
              {
                  min = (hour-1)*60 + (60 - get_min) + min;
              }
              else
              {
                  min = min - get_min;
              }
          }
          else
          {
              hour = hour - get_hour;
              if(hour > 0)
              {
                  min = (hour-1)*60 + (60 - get_min) + min;
              }
              else
              {
                  min = min - get_min;
              }
          }
      }
    
    return min;
}
//iniflag: 00-C+E  C-C E-E
void CMY_MF1A(u8 iniflag)
{
u8 buffer[8];

	buffer[0]=0x07;
	buffer[1]=0x55;
	buffer[2]=0x83;
	buffer[3]=0x26;
	buffer[4]=0x62;
	buffer[5]=0x36;
	buffer[6] = buffer[0] ^ buffer[1] ^ buffer[2] ^ buffer[3] ^ buffer[4] ^ buffer[5];
	if((iniflag==Cardkey_ALL)||(iniflag==Cardkey_WL))
		{
		I2C_WriteS_24C(sysytem_public_key,buffer,7);  //���ܺ����в�������
		I2C_WriteS_24C(sysytem_public_key_back,buffer,7);
		}
	if((iniflag==Cardkey_ALL)||(iniflag==Cardkey_ZG))
		{
		I2C_WriteS_24C(sysytem_public_ZGkey,buffer,7);  //���ܺ����в�������
		I2C_WriteS_24C(sysytem_public_ZGkey_back,buffer,7);
		}
}
void CST_MF1A(void)
{
u8 buffer[8];
	
	buffer[0]=0x13;
	buffer[1]=0x30;
	buffer[2]=0x10;
	buffer[3]=0x50;
	buffer[4]=0x09;
	buffer[5]=0x31;
	buffer[6] = buffer[0] ^ buffer[1] ^ buffer[2] ^ buffer[3] ^ buffer[4] ^ buffer[5];
	I2C_WriteS_24C(sysytem_public_key,buffer,7);  //���ܺ����в�������
	I2C_WriteS_24C(sysytem_public_key_back,buffer,7);
}

//�������ÿ�������ѯ
void NET_Card_IQ(void)
{
u8 buffer[16],i;
u32 timeOut;

	//99 04 06 10 02 28 04 04 04 24
	I2C_ReadS_24C(LISTNET_ADD,buffer,16);//0-��־99 1- 2- 3-���ͼ��Ƶ�� 4- 5-Υ��ʱ��
	lcd_clear();
	print_XYstr_16_16(1,5,"NET-P");
	goto_xy(0xA2,1);
	for(i=0;i<10;i++)
		print_num2(buffer[i]);	
	I2C_ReadS_24C(SYS_LISTTIME,buffer,5);
	print_XYstr_16_16(4,1,"List:");
	goto_xy(0xA4,6);
	for(i=0;i<5;i++)
		print_num2(buffer[i]);	
	
	timeOut = KEYTIMEOUT_1S *3;  
	while(timeOut--)
		{ 
		if(key_flag)
			{
			if(key_flag==0x03)return;//ֱ���˳�
			else break;
			}
		if(timeOut==1)return;
		}				 
	

}

//���񿨲���-2015-08-12 andyluo
void CPC_Card_Test(void)
{
u8 card_class_flag,i,read_IC_card_flag;
u32 timeOut,feemny;
CardInfo YWCardInfo;   
	feemny = 1;
	while(1)
		{
		TMP.feemny = feemny;
		disp_cardfee(4);
		key_flag = 0;
		timeOut = KEYTIMEOUT_1S *3;  
		while(timeOut--)
			{ 
			if(key_flag)
				{
				if(key_flag==0x02)
					{
					feemny ++;
					if(feemny>50)feemny = 50;
					break;
					}
				if(key_flag==0x03)break;//ֱ��ȷ��
				}
			if(timeOut==1)return;
			}		
		if(key_flag==0x03)break;//ֱ��ȷ��
		}
	disp_cardfee(5);
	TMP.feemny *= 100;
	key_flag = 0;
	Smart_Power_ON;
	read_IC_card_flag =NG;
	i = 4;
	while(i--)
		{
		while(timeOut < 300)
			{
			card_class_flag = inquire_card(&YWCardInfo);//��� ��������
			if(card_class_flag==CardType_CPCLOCK)
				{
				if(timeOut < 100)continue;
				write_card_error(0);
				delay(KEYTIMEOUT_1S*3);
				return;
				}
			if((card_class_flag==CardType_MF1)||
			(card_class_flag==CardType_BIKE)||
			(card_class_flag==CardType_CPC))
				{
				read_IC_card_flag = OK;
				break;
				}
			if(key_flag != NO)
				{
				key_flag = 0;
				break;
				}
			timeOut++;	
			}
		if(read_IC_card_flag==NG)
			{
			timeOut = 0;	
			if(i>1)continue;
			disp_cardfee(3);
			delay(KEYTIMEOUT_1S*4);
			return;
			}
		}	
	CPCCARD_PRO(2,0xAA,&YWCardInfo);
	Smart_Power_OFF;	
	return;
}

