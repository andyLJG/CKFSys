
#include "STM32Lib\\stm32f10x.h"
#include "stm32f10x_conf.h"
#include "hal.h"
#include "MemoryAssign.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Key.h"
#include "Count.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include "Gprs_online.h"
#include "MemoryAssign.h"
#include "rate.h"
#include "Smart_card.h"
#include "stm32f10x_usart.h"
#include "Do_Task.h"
#include "CpuCardM.h"

uchar *Smart_card_RX_data;
uchar U5_rx_data[];
unsigned long timeOut;

CardInfo YWCardInfo;//��������Ϣ 2015-07-25
SubMoneyCMD YWSubMoneyCMD;//�۷����� 2015-07-25
PosRecordInfo YWPosRecordInfo;//�۷Ѽ�¼ 2015-07-25

#ifdef WL_CARDMODE
u8 system_number[16]={0x31,0x33,0x30,0x37,0x31,0x38,0x35,0x35};//���� 2015-12-03
#else
u8 system_number[16]={0x31,0x36,0x34,0x35,0x32,0x34,0x30,0x33}; //����-����
#endif

u8 system0_number[16]={0x13,0x30,0x10,0x50,0x09,0x31}; //   ����

unsigned char  temp1[8],temp2[8],temp3[8],temp4[4];
unsigned char  xdata2[8];
unsigned char  xdata1[8];  /*�����������룬ȡǰ6���ֽ�*/
unsigned char  len;
unsigned char  bdata1;		//2013.5.9

u8  data2[]={0x39,0x31,0x29,0x21,0x19,0x11,0x09,0x01,
                                  0x3b,0x33,0x2b,0x23,0x1b,0x13,0x0b,0x03,
                                  0x3d,0x35,0x2d,0x25,0x1d,0x15,0x0d,0x05,
                                  0x3f,0x37,0x2f,0x27,0x1f,0x17,0x0f,0x07,
                                  0x38,0x30,0x28,0x20,0x18,0x10,0x08,0x00,
                                  0x3a,0x32,0x2a,0x22,0x1a,0x12,0x0a,0x02,
                                  0x3c,0x34,0x2c,0x24,0x1c,0x14,0x0c,0x04,
                                  0x3e,0x36,0x2e,0x26,0x1e,0x16,0x0e,0x06};

     u8  data4[]={0x38,0x30,0x28,0x20,0x18,0x10,0x08,0x00,
                                  0x39,0x31,0x29,0x21,0x19,0x11,0x09,0x01,
                                  0x3a,0x32,0x2a,0x22,0x1a,0x12,0x0a,0x02,
                                  0x3b,0x33,0x2b,0x23,0x3e,0x36,0x2e,0x26,
                                  0x1e,0x16,0x0e,0x06,0x3d,0x35,0x2d,0x25,
                                  0x1d,0x15,0x0d,0x05,0x3c,0x34,0x2c,0x24,
                                  0x1c,0x14,0x0c,0x04,0x1b,0x13,0x0b,0x03};

     u8  data7[]={0x0d,0x10,0x0a,0x17,0x00,0x04,0x02,0x1b,        /*65c2*/
                                  0x0e,0x05,0x14,0x09,0x16,0x12,0x0b,0x03,
                                  0x19,0x07,0x0f,0x06,0x1a,0x13,0x0c,0x01,
                                  0x28,0x33,0x1e,0x24,0x2e,0x36,0x1d,0x27,
                                  0x32,0x2c,0x20,0x2f,0x2b,0x30,0x26,0x37,
                                  0x21,0x34,0x2d,0x29,0x31,0x23,0x1c,0x1f};

     u8  data8[]={0x1f,0x00,0x01,0x02,0x03,0x04,0x03,0x04,        /*6592*/
                                  0x05,0x06,0x07,0x08,0x07,0x08,0x09,0x0a,
                                  0x0b,0x0c,0x0b,0x0c,0x0d,0x0e,0x0f,0x10,
                                  0x0f,0x10,0x11,0x12,0x13,0x14,0x13,0x14,
                                  0x15,0x16,0x17,0x18,0x17,0x18,0x19,0x1a,
                                  0x1b,0x1c,0x1b,0x1c,0x1d,0x1e,0x1f,0x00};

     u8  data10[]={0x0f,0x06,0x13,0x14,0x1c,0x0b,0x1b,0x10,        /*65f2*/
                                  0x00,0x0e,0x16,0x19,0x04,0x11,0x1e,0x09,
                                  0x01,0x07,0x17,0x0d,0x1f,0x1a,0x02,0x08,
                                  0x12,0x0c,0x1d,0x05,0x15,0x0a,0x03,0x18};

     u8  data11[]={0x27,0x07,0x2f,0x0f,0x37,0x17,0x3f,0x1f,       /*651a*/
                                  0x26,0x06,0x2e,0x0e,0x36,0x16,0x3e,0x1e,
                                  0x25,0x05,0x2d,0x0d,0x35,0x15,0x3d,0x1d,
                                  0x24,0x04,0x2c,0x0c,0x34,0x14,0x3c,0x1c,
                                  0x23,0x03,0x2b,0x0b,0x33,0x13,0x3b,0x1b,
                                  0x22,0x02,0x2a,0x0a,0x32,0x12,0x3a,0x1a,
                                  0x21,0x01,0x29,0x09,0x31,0x11,0x39,0x19,
                                  0x20,0x00,0x28,0x08,0x30,0x10,0x38,0x18};

     u8  data9[]={0x0e,0x04,0x0d,0x01,0x02,0x0f,0x0b,0x08,        /*6612*/
                                  0x03,0x0a,0x06,0x0c,0x05,0x09,0x00,0x07,       /*0010*/
                                  0x00,0x0f,0x07,0x04,0x0e,0x02,0x0d,0x01,      /*0018*/
                                  0x0a,0x06,0x0c,0x0b,0x09,0x05,0x03,0x08,      /*0020*/
                                  0x04,0x01,0x0e,0x08,0x0d,0x06,0x02,0x0b,      /*0028*/
                                  0x0f,0x0c,0x09,0x07,0x03,0x0a,0x05,0x00,      /*0030*/
                                  0x0f,0x0c,0x08,0x02,0x04,0x09,0x01,0x07,      /*0038*/
                                  0x05,0x0b,0x03,0x0e,0x0a,0x00,0x06,0x0d,      /*0040*/
                                  0x0f,0x01,0x08,0x0e,0x06,0x0b,0x03,0x04,      /*0048*/
                                  0x09,0x07,0x02,0x0d,0x0c,0x00,0x05,0x0a,      /*0050*/
                                  0x03,0x0d,0x04,0x07,0x0f,0x02,0x08,0x0e,      /*0058*/
                                  0x0c,0x00,0x01,0x0a,0x06,0x09,0x0b,0x05,      /*0060*/
                                  0x00,0x0e,0x07,0x0b,0x0a,0x04,0x0d,0x01,      /*0068*/
                                  0x05,0x08,0x0c,0x06,0x09,0x03,0x02,0x0f,      /*0070*/
                                  0x0d,0x08,0x0a,0x01,0x03,0x0f,0x04,0x02,      /*0078*/
                                  0x0b,0x06,0x07,0x0c,0x00,0x05,0x0e,0x09,      /*0080*/
                                  0x0a,0x00,0x09,0x0e,0x06,0x03,0x0f,0x05,      /*0088*/
                                  0x01,0x0d,0x0c,0x07,0x0b,0x04,0x02,0x08,      /*0090*/
                                  0x0d,0x07,0x00,0x09,0x03,0x04,0x06,0x0a,      /*0098*/
                                  0x02,0x08,0x05,0x0e,0x0c,0x0b,0x0f,0x01,      /*00a0*/
                                  0x0d,0x06,0x04,0x09,0x08,0x0f,0x03,0x00,      /*00a8*/
                                  0x0b,0x01,0x02,0x0c,0x05,0x0a,0x0e,0x07,      /*00b0*/
                                  0x01,0x0a,0x0d,0x00,0x06,0x09,0x08,0x07,      /*00b8*/
                                  0x04,0x0f,0x0e,0x03,0x0b,0x05,0x02,0x0c,      /*00c0*/
                                  0x07,0x0d,0x0e,0x03,0x00,0x06,0x09,0x0a,      /*00c8*/
                                  0x01,0x02,0x08,0x05,0x0b,0x0c,0x04,0x0f,      /*00d0*/
                                  0x0d,0x08,0x0b,0x05,0x06,0x0f,0x00,0x03,      /*00d8*/
                                  0x04,0x07,0x02,0x0c,0x01,0x0a,0x0e,0x09,      /*00e0*/
                                  0x0a,0x06,0x09,0x00,0x0c,0x0b,0x07,0x0d,      /*00e8*/
                                  0x0f,0x01,0x03,0x0e,0x05,0x02,0x08,0x04,      /*00f0*/
                                  0x03,0x0f,0x00,0x06,0x0a,0x01,0x0d,0x08,      /*00f8*/
                                  0x09,0x04,0x05,0x0b,0x0c,0x07,0x02,0x0e,      /*0100*/
                                  0x02,0x0c,0x04,0x01,0x07,0x0a,0x0b,0x06,      /*0108*/
                                  0x08,0x05,0x03,0x0f,0x0d,0x00,0x0e,0x09,      /*0110*/
                                  0x0e,0x0b,0x02,0x0c,0x04,0x07,0x0d,0x01,      /*0118*/
                                  0x05,0x00,0x0f,0x0a,0x03,0x09,0x08,0x06,      /*0120*/
                                  0x04,0x02,0x01,0x0b,0x0a,0x0d,0x07,0x08,      /*0130*/
                                  0x0f,0x09,0x0c,0x05,0x06,0x03,0x00,0x0e,      /*0138*/
                                  0x0b,0x08,0x0c,0x07,0x01,0x0e,0x02,0x0d,      /*0140*/
                                  0x06,0x0f,0x00,0x09,0x0a,0x04,0x05,0x03,      /*0148*/
                                  0x0c,0x01,0x0a,0x0f,0x09,0x02,0x06,0x08,      /*0150*/
                                  0x00,0x0d,0x03,0x04,0x0e,0x07,0x05,0x0b,      /*0158*/
                                  0x0a,0x0f,0x04,0x02,0x07,0x0c,0x09,0x05,      /*0160*/
                                  0x06,0x01,0x0d,0x0e,0x00,0x0b,0x03,0x08,      /*0168*/
                                  0x09,0x0e,0x0f,0x05,0x02,0x08,0x0c,0x03,      /*0170*/
                                  0x07,0x00,0x04,0x0a,0x01,0x0d,0x0b,0x06,      /*0178*/
                                  0x04,0x03,0x02,0x0c,0x09,0x05,0x0f,0x0a,      /*0180*/
                                  0x0b,0x0e,0x01,0x07,0x06,0x00,0x08,0x0d,      /*0008*/
                                  0x04,0x0b,0x02,0x0e,0x0f,0x00,0x08,0x0d,      /*0008*/
                                  0x03,0x0c,0x09,0x07,0x05,0x0a,0x06,0x01,      /*0008*/
                                  0x0d,0x00,0x0b,0x07,0x04,0x09,0x01,0x0a,      /*0008*/
                                  0x0e,0x03,0x05,0x0c,0x02,0x0f,0x08,0x06,      /*0008*/
                                  0x01,0x04,0x0b,0x0d,0x0c,0x03,0x07,0x0e,      /*0008*/
                                  0x0a,0x0f,0x06,0x08,0x00,0x05,0x09,0x02,      /*0008*/
                                  0x06,0x0b,0x0d,0x08,0x01,0x04,0x0a,0x07,      /*0008*/
                                  0x09,0x05,0x00,0x0f,0x0e,0x02,0x03,0x0c,      /*0008*/
                                  0x0d,0x02,0x08,0x04,0x06,0x0f,0x0b,0x01,      /*0008*/
                                  0x0a,0x09,0x03,0x0e,0x05,0x00,0x0c,0x07,      /*0008*/
                                  0x01,0x0f,0x0d,0x08,0x0a,0x03,0x07,0x04,      /*0008*/
                                  0x0c,0x05,0x06,0x0b,0x00,0x0e,0x09,0x02,      /*0008*/
                                  0x07,0x0b,0x04,0x01,0x09,0x0c,0x0e,0x02,      /*0008*/
                                  0x00,0x06,0x0a,0x0d,0x0f,0x03,0x05,0x08,      /*0008*/
                                  0x02,0x01,0x0e,0x07,0x04,0x0a,0x08,0x0d,      /*0008*/
                                  0x0f,0x0c,0x09,0x00,0x03,0x05,0x06,0x0b};     /*0008*/

     u8  data5[]={0x01,0x01,0x02,0x02,0x02,0x02,0x02,0x02,
                                  0x01,0x02,0x02,0x02,0x02,0x02,0x02,0x01};

     u8  data6[]={0x00,0x01,0x02,0x02,0x02,0x02,0x02,0x02,
                                  0x01,0x02,0x02,0x02,0x02,0x02,0x02,0x01};
void TX_smart_card(uchar *data);


u8 _cror_(u8 a,u8 i) 
{
	u8 temp;
	
	temp=a<<(8-i);
	a=a>>i;
	a=a|temp;
	return a;
}

void Open_Smart_Card_Power(void)
{
  Smart_card_opend;
}
void Close_Smart_Card_Power(void)
{
  Smart_card_close;
}


void sent_smart_data(uchar x)
{	
    USART_SendData(UART5,x);
    while(USART_GetFlagStatus(UART5, USART_FLAG_TXE) == RESET)
    {
    }  
}


void TX_smart_card(uchar *data)
{
    while(*data != '\0')
    {
        sent_smart_data(*data);
        data++;
    }
}


void TX_Smart_Command(uchar STX,uchar ID,uchar LEN,uchar CMD,uchar DATA[],uchar BCC,uchar ETX)
{
u8 znk[200];
u16 leng,i;
	
	BCC = 0x00;
//	sent_smart_data(STX);
//	sent_smart_data(ID);
//	sent_smart_data(LEN);
//	sent_smart_data(CMD);
	leng=0;
	znk[leng++] = STX;
	znk[leng++] = ID;
	znk[leng++] = LEN;
	znk[leng++] = CMD;
	BCC = ID ^ LEN ^ CMD;
	if(LEN>1)
		{
		for(i = 0 ;i < LEN - 1;i++)
			{
//			sent_smart_data(DATA[i]);
			BCC = BCC ^ DATA[i];			
			znk[leng++] = DATA[i];
			}
		}
//	sent_smart_data(BCC);
//	sent_smart_data(ETX);
	znk[leng++] = BCC;
	znk[leng++] = ETX;
	
	for(i =0;i < leng;i++)
		{
		sent_smart_data(znk[i]);
		}
}
//{
//    BCC = 0x00;
//    sent_smart_data(STX);
//    sent_smart_data(ID);
//    sent_smart_data(LEN);
//    sent_smart_data(CMD);
//    BCC = ID ^ LEN ^ CMD;
//    if(LEN>1)
//    {
//        for(int i = 0 ;i < LEN - 1;i++)
//        {
//            sent_smart_data(DATA[i]);
//            BCC = BCC ^ DATA[i];
//        }
//          
//    }
//    sent_smart_data(BCC);
//    sent_smart_data(ETX);
//}



uchar read_card(uchar STX,uchar ID,uchar LEN,uchar CMD,uchar DATA[],uchar BCC,uchar ETX,uchar FLAG)
{
    IWDG_ReloadCounter();
    RxCounter = 0;  
    f_receiveOK = 0;
    TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
    timeOut = 0;
    
    delay(KEYTIMEOUT_1S / 1 );
    while(USART_GetITStatus(UART5, USART_IT_RXNE) != RESET);   
    return read_card_is_OK(STX,LEN,CMD,ETX,FLAG);    
}

void read_MIFARE_card(MIFARE_card_information* CC)
{
  int i,station;
  u8 Public_BCC;
  
  station = 0;
  
  station = station +4;
   // CC = smart_newTable;
    
    CC->STATE[0] = RxBuffer[station];   
    station =station + 1;
    
    for(i=0;i<4;i++)
        CC->SNR[i] = RxBuffer[station + i];       
    station =station + 4;
    
    CC->ATS = RxBuffer[station + 1];
    
    CC->TT = RxBuffer[station + 2];



	TMP.cardplace = CardAddArea();//�ж��Է����ĵ����� 2015-12-03
	if(TMP.cardplace == CardType_ZGMF1RD)//�����
		{
		Public_BCC = 0x00;
		I2C_ReadS_24C(sysytem_public_ZGkey,system0_number,7);
		for(i=0;i<6;i++)
			{
			Public_BCC = Public_BCC ^ system0_number[i];
			}		
		if(Public_BCC != system0_number[6])//��Կ��У�鲻��
			{
			//���»�ȡ��Կ
			I2C_ReadS_24C(sysytem_public_ZGkey_back,system0_number,7);			
			Public_BCC = 0x00;
			for(i=0;i<6;i++)
				{
				Public_BCC = Public_BCC ^ system0_number[i];
				}			
			if(Public_BCC != system0_number[6])//������Կ��У�鲻��
				{
				//��ԭΪ������Կ	
				CMY_MF1A(Cardkey_ZG);
				}
			else
				{
				//���� �ѱ�����Կд�ص� ԭ����Կ����ȥ��
				I2C_WriteS_24C(sysytem_public_key,system0_number,7);
				}
			}
		}
	else //if((TMP.cardplace == CardType_WLMF1RD)||
		//(TMP.cardplace == CardType_OWLMF1RD))
		//�����Ͽ����¿�
		{
		Public_BCC = 0x00;
		I2C_ReadS_24C(sysytem_public_key,system0_number,7);
		for(i=0;i<6;i++)
			{
			Public_BCC = Public_BCC ^ system0_number[i];
			}		
		if(Public_BCC != system0_number[6])//��Կ��У�鲻��
			{
			//���»�ȡ��Կ
			I2C_ReadS_24C(sysytem_public_key_back,system0_number,7);			
			Public_BCC = 0x00;
			for(i=0;i<6;i++)
				{
				Public_BCC = Public_BCC ^ system0_number[i];
				}			
			if(Public_BCC != system0_number[6])//������Կ��У�鲻��
				{
				//��ԭΪ������Կ	
				CMY_MF1A(Cardkey_WL);
				}
			else
				{
				//���� �ѱ�����Կд�ص� ԭ����Կ����ȥ��
				I2C_WriteS_24C(sysytem_public_key,system0_number,7);
				}
			}
		}
	
}

void read_JM_CPU_card(JM_CPU_card_information* CC)
{
    int i,station;
    station = 0;
    
    station = station +4;
    
    CC->STATE[0] = RxBuffer[station];   
    station =station + 1;
    
    CC->CardType[0] = RxBuffer[station];   
    station =station + 1;
    
    for(i=0;i<8;i++)
        CC->CardID[i] = RxBuffer[station + i];       
    station =station + 8;
    
    for(i=0;i<8;i++)
        CC->CardNO[i] = RxBuffer[station + i];
    station =station + 8;
    
    for(i=0;i<4;i++)
        CC->LeftMoney[i] = RxBuffer[station + i];
    station =station + 4;
    
    for(i=0;i<2;i++)
        CC->CardCount[i] = RxBuffer[station + i];
    station =station + 2;
    
    for(i=0;i<2;i++)
        CC->CardClass[i] = RxBuffer[station + i];
    station =station + 2;
    
    for(i=0;i<1;i++)
        CC->MomeryDown[i] = RxBuffer[station + i];
    station =station + 1;
    
    for(i=0;i<3;i++)
        CC->MomeryUp[i] = RxBuffer[station + i];
    station =station + 3;
    
    for(i=0;i<4;i++)
        CC->CardPledge[i] = RxBuffer[station + i];
    station =station + 4;
    
    for(i=0;i<1;i++)
        CC->SAK[i] = RxBuffer[station + i];
    station =station + 1;
    
    for(i=0;i<2;i++)
        CC->ATQA[i] = RxBuffer[station + i];       
    station =station + 2;
    
    for(i=0;i<1;i++)
        CC->CityCode[i] = RxBuffer[station + i];
    station =station + 1;
    
    for(i=0;i<8;i++)
        CC->CityCardNo[i] = RxBuffer[station + i];
    station =station + 8;
    
    for(i=0;i<2;i++)
        CC->CityCardCalss[i] = RxBuffer[station + i];
    station =station + 2;
    
    for(i=0;i<4;i++)
        CC->CityCardClassValidity[i] = RxBuffer[station + i];
    station =station + 4;
    
    for(i=0;i<1;i++)
        CC->CitySonCode[i] = RxBuffer[station + i];
    station =station + 1;
    
    for(i=0;i<1;i++)
        CC->OutInState[i] = RxBuffer[station + i];       
    station =station + 1;
    
    for(i=0;i<2;i++)
        CC->ServiceOperatorsCode[i] = RxBuffer[station + i];
    station =station + 2;
    
    for(i=0;i<4;i++)
        CC->TerminalNo[i] = RxBuffer[station + i];
    station =station + 4;
    
    for(i=0;i<5;i++)
        CC->Time[i] = RxBuffer[station + i];
    station =station + 5;
    
}
void read_CPU_card(CPU_card_information* CC)
{
  int i,station;
  station = 0;
  
  station = station +4;
   // CC = smart_newTable;
    
    CC->STATE[0] = RxBuffer[station];   
    station =station + 1;
    
    for(i=0;i<4;i++)
        CC->SNR[i] = RxBuffer[station + i];       
    station =station + 4;
    
    for(i=0;i<4;i++)
        CC->FKFDM[i] = RxBuffer[station + i];
    station =station + 4;
    
    for(i=0;i<2;i++)
        CC->HYDM[i] = RxBuffer[station + i];
    station =station + 2;
    
    for(i=0;i<2;i++)
        CC->RUF[i] = RxBuffer[station + i];
    station =station + 2;
    
    for(i=0;i<1;i++)
        CC->QYBS[i] = RxBuffer[station + i];
    station =station + 1;
    
    for(i=0;i<1;i++)
        CC->KLXBS[i] = RxBuffer[station + i];
    station =station + 1;
    
    for(i=0;i<10;i++)
        CC->YYXLH[i] = RxBuffer[station + i];
    station =station + 10;
    
    for(i=0;i<4;i++)
        CC->QYRQ[i] = RxBuffer[station + i];
    station =station + 4;
    
    for(i=0;i<4;i++)
        CC->YXRQ[i] = RxBuffer[station + i];
    station =station + 4;
    
    for(i=0;i<1;i++)
        CC->FCI1[i] = RxBuffer[station + i];
    station =station + 1;
    
    for(i=0;i<1;i++)
        CC->FCI2[i] = RxBuffer[station + i];
    station =station + 1;
    
    for(i=0;i<4;i++)
        CC->Balance[i] = RxBuffer[station + i];
    station =station + 4;
    
    for(i=0;i<1;i++)
        CC->HMDBS[i] = RxBuffer[station + i];
    station =station + 1;
    
    for(i=0;i<2;i++)
        CC->TradeId[i] = RxBuffer[station + i];
    station =station + 2;
    
    for(i=0;i<3;i++)
        CC->TXXE[i] = RxBuffer[station + i];
    station =station + 3;
    
    for(i=0;i<4;i++)
        CC->JYJE[i] = RxBuffer[station + i];
    station =station + 4;
    
    for(i=0;i<1;i++)
        CC->JYLX[i] = RxBuffer[station + i];
    station =station + 1;
    
    for(i=0;i<6;i++)
        CC->ZDJBH[i] = RxBuffer[station + i];
    station =station + 6;
    
    for(i=0;i<7;i++)
        CC->JYRQ[i] = RxBuffer[station + i];
    station =station + 7;
    
    for(i=0;i<32;i++)
        CC->Info[i] = RxBuffer[station + i];
    
   // return CC;
    
              
              
              
}



//����  ���� 1 ��ʾ������ 
//     ���� 0 ��ʾ��ȡʧ��
uchar read_card_is_OK(uchar STX,uchar LEN,uchar CMD,uchar ETX,uchar Flag)
{
    if(Flag == 1)
    {
        if(RxBuffer[2] == 0x42  &&  RxBuffer[3] == CMD && RxBuffer[4] == 0x00 && RxBuffer[RxCounter - 1] == ETX){
          //lcd_clear();
          //goto_xy(2,0x00);
          //print_str_16_16("OK!");
          Buzz_0;
          return 1;
        }
        else{
          //lcd_clear();
          //goto_xy(2,0x00);
          //print_str_16_16("NO!");
          Buzz_1;
          return 0;
        }
    }
    else
    {
        if( (RxBuffer[2] == 0x02 )  &&  RxBuffer[3] == CMD && RxBuffer[4] == 0x00 && RxBuffer[RxCounter - 1] == ETX){
          //lcd_clear();
          //goto_xy(2,0x00);
          //print_str_16_16("OK!");
         // Buzz_0;
          return 1;
        }
        else{
          //lcd_clear();
          //goto_xy(2,0x00);
          //print_str_16_16("NO!");
         // Buzz_1;
          return 0;
        }
    }
    

}
//Ѱ���ɹ����ȡ
//2016-03-22 andyluo   ���ݶ�CPU����¼
uchar inquire_card_record(u8 RDNO[1],u8 RDBUF[])
{
    uchar STX,ID,LEN,CMD,DATA[2],BCC,ETX;
    u16 i;
		
    STX = 0x02;
    ID = 0x01;
    LEN = 0x03;
    CMD = 0xb8;    
    DATA[0] = RDNO[0];    
    DATA[1] = 0x32;    
    BCC = 0x00;
    ETX = 0x03;
     
    DATA[0] = 0;
	for(i=0;i<RxCounter;i++)
		RxBuffer[i] = 0x00;
	RxCounter = 0;
	f_receiveOK = 0;
    
    TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
    timeOut = 0;
    while(timeOut < KEYTIMEOUT_1S / 5)
		{
		if((TMP.cpc == Disp_ICBS)||(TMP.cpc == Disp_IC))//�忨ģʽ 2016-03-09
			{
			#ifdef CPUINCARD_SYS
			if(IC_SWITCH_read==YESZBTCARD)
				return CardType_IC;
			#endif
			}
        if(f_receiveOK == OK)
          break;
        timeOut++;
		}
    if(f_receiveOK != OK)
		{
        return CardType_E1;
		}  
//RxBuffer[0-1]:02 01	
	if((RxBuffer[3]!=0xB8)||(RxBuffer[RxCounter-1]!=ETX))
		{
//�����쳣 2015-07-24 andyluo
		return CardType_E2; // û�ſ�
		}
//�����󷵻� 2015-09-01 	02 01 09 B1 02 0F 4A 35 A5 28 04 00 42 03 
	if((RxBuffer[2]==0x09)&&(RxBuffer[4]==0x02))
		{
		return CardType_CPCLOCK; // ��������Ͽ�  CPU��
//		return 11; // ��������Ͽ�
		}
	if((RxBuffer[2]==0x0F)&&(RxBuffer[4]==0x01))
		{
//mifare ��
//mifare1 RxBuffer[2-4]:0F B1 01
		return CardType_MF1;
		}
	if((RxBuffer[3]==0xb8)&&(RxBuffer[4]==0x00))
		{
		memcpy(RDBUF,RxBuffer+5,50);
		return 0;
		}	
	else if((RxBuffer[2]==0x02)&&(RxBuffer[4]==0xF0))
		{//02 01 02 B1 F0 42 03 �޿�
//PSAM���쳣
//PSAM RxBuffer[2-4]:02 B1 F0
		return CardType_E5;
		}	
	else
		{
//�����쳣
		return CardType_E4;
		}	
}


//2015-11-27 andyluo   ����&���7-��������Ͽ�
uchar inquire_card(CardInfo *YWT)
{
    uchar STX,ID,LEN,CMD,DATA[1],BCC,ETX;
    u16 i;
		
    STX = 0x02;
    ID = 0x01;
    LEN = 0x01;
    CMD = 0xb1;    
    BCC = 0x00;
    ETX = 0x03;
     
    DATA[0] = 0;
	for(i=0;i<RxCounter;i++)
		RxBuffer[i] = 0x00;
	RxCounter = 0;
	f_receiveOK = 0;
    
    TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
    timeOut = 0;
    while(timeOut < KEYTIMEOUT_1S / 5)
		{
		if((TMP.cpc == Disp_ICBS)||(TMP.cpc == Disp_IC))//�忨ģʽ 2016-03-09
			{
			#ifdef CPUINCARD_SYS
			if(IC_SWITCH_read==YESZBTCARD)
				return CardType_IC;
			#endif
			}
        if(f_receiveOK == OK)
          break;
        timeOut++;
		}
    if(f_receiveOK != OK)
		{
        return CardType_E1;
		}  
//RxBuffer[0-1]:02 01	
	if((RxBuffer[3]!=0xB1)||(RxBuffer[RxCounter-1]!=ETX))
		{
//�����쳣 2015-07-24 andyluo
		return CardType_E2; // û�ſ�
		}
//�����󷵻� 2015-09-01 	02 01 09 B1 02 0F 4A 35 A5 28 04 00 42 03 
	if((RxBuffer[2]==0x09)&&(RxBuffer[4]==0x02))
		{
		return CardType_CPCLOCK; // ��������Ͽ�  CPU��
//		return 11; // ��������Ͽ�
		}
	if((RxBuffer[2]==0x0F)&&(RxBuffer[4]==0x01))
		{
//mifare ��
//mifare1 RxBuffer[2-4]:0F B1 01
		return CardType_MF1;
		}
	if((RxBuffer[2]==0x5C)&&(RxBuffer[4]==0x00))
		{
		YWT->CardType = RxBuffer[5];
		memcpy(YWT->snr,RxBuffer+6,4);
//		memcpy(YWT->CSDM,RxBuffer+10,2);
		memcpy(YWT->FKFBS,RxBuffer+10,8);
		YWT->QYBS = RxBuffer[18];
		YWT->KLXBS = RxBuffer[19];
		memcpy(YWT->YYXLH,RxBuffer+20,8);
		memcpy(YWT->YYQYRQ,RxBuffer+28,4);
		memcpy(YWT->YYYXRQ,RxBuffer+32,4);		
		YWT->FCI1 = RxBuffer[36]; 
		YWT->FCI2 = RxBuffer[37]; 
		memcpy(YWT->NC,RxBuffer+38,2);
		memcpy(YWT->Balance,RxBuffer+40,4);			
		memcpy(YWT->KRZM,RxBuffer+44,4);		
		YWT->KLX= RxBuffer[48]; 
		YWT->QYBS1 = RxBuffer[49];
		YWT->BBH = RxBuffer[50];
		
		memcpy(YWT->FKRQ,RxBuffer+51,4);
		memcpy(YWT->YXRQ,RxBuffer+55,4);
		memcpy(YWT->QYRQ,RxBuffer+59,4);
		YWT->HMDBS = RxBuffer[63]; 
		YWT->YWParkInfo.CardType = RxBuffer[64]; 
		YWT->YWParkInfo.ParkFlag= RxBuffer[65]; 
		memcpy(YWT->YWParkInfo.ParkDateTime,RxBuffer+66,4);
		YWT->YWParkInfo.UpdateFlag= RxBuffer[70]; 
		memcpy(YWT->YWParkInfo.DongjieMoney,RxBuffer+71,2);
		memcpy(YWT->YWParkInfo.Res,RxBuffer+73,7);
		memcpy(YWT->YWParkInfo.FEEMNY,RxBuffer+80,3);
		memcpy(YWT->YWParkInfo.ParkMBNO,RxBuffer+83,4);
		memcpy(YWT->YWParkInfo.ParkInOutTime,RxBuffer+87,7);		
		YWT->LockApp = RxBuffer[94]; 
//���г� ��
//���г��� RxBuffer[2-4]:44 B1 00 01
		if(YWT->CardType == 0x01)
			return CardType_BIKE;
//���� ��
//���� RxBuffer[2-4]:44 B1 00 02
		else if(YWT->CardType == 0x02)
			return CardType_CPU;//CardType_CPC;
		else
			return CardType_E3;//�������쳣
		}
	
/*����ͨ 2016-03-08
{
		YWT->CardType = RxBuffer[5];
		memcpy(YWT->snr,RxBuffer+6,4);
//		memcpy(YWT->CSDM,RxBuffer+10,2);
		memcpy(YWT->FKFBS,RxBuffer+10,8);
		YWT->QYBS = RxBuffer[18];
		memcpy(YWT->CSDMType,RxBuffer+19,2);
		memcpy(YWT->YYXLH,RxBuffer+21,8);
		YWT->ZKLXM = RxBuffer[29]; 
		YWT->ZKLXS = RxBuffer[30]; 
		memcpy(YWT->QYRQ,RxBuffer+31,4);
		memcpy(YWT->YXRQ,RxBuffer+35,4);
		memcpy(YWT->Balance,RxBuffer+39,4);	
		YWT->YYLX = RxBuffer[43]; 
		YWT->YYBBH = RxBuffer[44]; 
		memcpy(YWT->YYQYRQ,RxBuffer+45,4);
		memcpy(YWT->YYYXRQ,RxBuffer+49,4);
		YWT->HMDBS = RxBuffer[53]; 
		YWT->SBHMDBS = RxBuffer[54]; 
		YWT->YWParkInfo.CardType = RxBuffer[55]; 
		YWT->YWParkInfo.ParkFlag= RxBuffer[56]; 
		memcpy(YWT->YWParkInfo.ParkDateTime,RxBuffer+57,4);
		YWT->YWParkInfo.UpdateFlag= RxBuffer[61]; 
		memcpy(YWT->YWParkInfo.DongjieMoney,RxBuffer+62,2);
		memcpy(YWT->YWParkInfo.Res,RxBuffer+64,7);
		memcpy(YWT->YWParkInfo.FEEMNY,RxBuffer+71,3);
		memcpy(YWT->YWParkInfo.ParkMBNO,RxBuffer+74,4);
		memcpy(YWT->YWParkInfo.ParkInOutTime,RxBuffer+78,7);		
		YWT->LockApp = RxBuffer[85]; 
//���г� ��
//���г��� RxBuffer[2-4]:44 B1 00 01
		if(YWT->CardType == 0x01)
			return CardType_BIKE;
//���� ��
//���� RxBuffer[2-4]:44 B1 00 02
		else if(YWT->CardType == 0x02)
			return CardType_CPC;
		else
			return 5;//�������쳣
		}

*/
	else if((RxBuffer[2]==0x02)&&(RxBuffer[4]==0xF0))
		{//02 01 02 B1 F0 42 03 �޿�
//PSAM���쳣
//PSAM RxBuffer[2-4]:02 B1 F0
		return CardType_E5;
		}	
	else
		{
//�����쳣
		return CardType_E4;
		}	
}



//��������
//020102b100ff03
//020144b10002b0b063cd3220010000000045364201002020010120150101202001010000c350000000000000000000000000000000000000000000000000000000000000000000dd03
//020140b2201507241110000000c350000000000100000000000000000000000000000000000000000000000000000000000201000000004536420200000000000000004603    
//020143b2000220150724111000322001000000004536420000c350000000000000c35000020932200100000400000001776ea9bf010020200101201501012020010100000000e103

//020102b100ff03
//020144b10002b0b063cd3220010000000045364201002020010120150101202001010000c350000001000000000000000000000000000000000000000000000000000000000000dc03

//020140b2201507241110000000c350000000000000000000000000000000000000000000000000000000000000000000000201000000004536420200000000000000004703
//020143b2000220150724111000322001000000004536420000c350000000000000c350000309322001000004000000021cb927b4010020200101201501012020010100000000da03

//2015-07-25 andyluo  7-��������Ͽ�
uchar inquire_card_YW(CardInfo *YWT)
{
    uchar STX,ID,LEN,CMD,DATA[1],BCC,ETX;
    u16 i;
		
    STX = 0x02;
    ID = 0x01;
    LEN = 0x01;
    CMD = 0xb1;    
    BCC = 0x00;
    ETX = 0x03;
     
    DATA[0] = 0;
	for(i=0;i<RxCounter;i++)
		RxBuffer[i] = 0x00;
	RxCounter = 0;
	f_receiveOK = 0;
    
    TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
    timeOut = 0;
    while(timeOut < KEYTIMEOUT_1S / 5)
		{
        if(f_receiveOK == OK)
          break;
        timeOut++;
		}
    if(f_receiveOK != OK)
		{
        return 0;
		}  
//RxBuffer[0-1]:02 01	
	if((RxBuffer[3]!=0xB1)||(RxBuffer[RxCounter-1]!=ETX))
		{
//�����쳣 2015-07-24 andyluo
		return 4; // û�ſ�
		}
//�����󷵻� 2015-09-01 	02 01 09 B1 02 0F 4A 35 A5 28 04 00 42 03 
	if((RxBuffer[2]==0x09)&&(RxBuffer[4]==0x02))
		{
		return CardType_CPCLOCK; // ��������Ͽ�
//		return 11; // ��������Ͽ�
		}
	if((RxBuffer[2]==0x0F)&&(RxBuffer[4]==0x01))
		{
//mifare ��
//mifare1 RxBuffer[2-4]:0F B1 01
		return CardType_MF1;
		}
	if((RxBuffer[2]==0x44)&&(RxBuffer[4]==0x00))
		{
		YWT->CardType = RxBuffer[5];
		memcpy(YWT->snr,RxBuffer+6,4);
//		memcpy(YWT->CSDMType,RxBuffer+10,2);
		memcpy(YWT->YYXLH,RxBuffer+12,8);
//		YWT->ZKLXM = RxBuffer[20]; 
//		YWT->ZKLXS = RxBuffer[21]; 
		memcpy(YWT->YXRQ,RxBuffer+22,4);
		memcpy(YWT->YYQYRQ,RxBuffer+26,4);
		memcpy(YWT->YYYXRQ,RxBuffer+30,4);
		memcpy(YWT->Balance,RxBuffer+34,4);
		YWT->HMDBS = RxBuffer[38]; 
//		YWT->SBHMDBS = RxBuffer[39]; 
		YWT->YWParkInfo.CardType = RxBuffer[40]; 
		YWT->YWParkInfo.ParkFlag= RxBuffer[41]; 
		memcpy(YWT->YWParkInfo.ParkDateTime,RxBuffer+42,4);
		YWT->YWParkInfo.UpdateFlag= RxBuffer[46]; 
		memcpy(YWT->YWParkInfo.DongjieMoney,RxBuffer+47,2);
		memcpy(YWT->YWParkInfo.Res,RxBuffer+49,7);
		memcpy(YWT->YWParkInfo.FEEMNY,RxBuffer+56,3);
		memcpy(YWT->YWParkInfo.ParkMBNO,RxBuffer+59,4);
		memcpy(YWT->YWParkInfo.ParkInOutTime,RxBuffer+63,7);		
		YWT->LockApp = RxBuffer[70]; 
//���г� ��
//���г��� RxBuffer[2-4]:44 B1 00 01
		if(YWT->CardType == 0x01)
			return CardType_BIKE;
//���� ��
//���� RxBuffer[2-4]:44 B1 00 02
		else if(YWT->CardType == 0x02)
			return CardType_CPC;
		else
			return 5;//�������쳣
		}
	else if((RxBuffer[2]==0x02)&&(RxBuffer[4]==0xF0))
		{
//PSAM���쳣
//PSAM RxBuffer[2-4]:02 B1 F0
		return 6;
		}	
	else
		{
//�����쳣
		return 10;
		}	
}

//020140b2201507241110000000c350000000000000000000000000000000000000000000000000000000000000000000000201000000004536420200000000000000004703
//020143b2000220150724111000322001000000004536420000c350000000000000c350000309322001000004000000021cb927b4010020200101201501012020010100000000da03
//����CPU���Ŀۿ����
//STX	ID	LEN	CMD/STATUS	DATA	BCC 	ETX
//0x02	0x01	0x40	0xb2	��������		0x03
uchar YWT_FEE_PRO(SubMoneyCMD *YWT,PosRecordInfo *YWTR)
{
    uchar STX,ID,LEN,CMD,BCC,ETX;
    uchar DATA[63];
	u16 i;
	
#ifdef Test_RealCPC
	return 1;
#endif

    STX = 0x02;
    ID  = 0x01;
//    LEN = 0x40;
    LEN = 0x39;
	if(YWT->POS[0] == 0xb9)
		{
		YWT->POS[0] = 0x66;
		CMD = 0xb9;
		}
	else if(YWT->POS[0] == 0x88)
		{
		YWT->POS[0] = 0x66;
		CMD = 0xb4;
		}
	else
		CMD = 0xb2;

	memcpy(DATA,YWT->TradeDateTime,7);
	memcpy(DATA+7,YWT->QBalance,4);
	memcpy(DATA+11,YWT->Pays,4);
//	memcpy(DATA+15,YWT->ParkInfo,30);
	memcpy(DATA+15,&YWT->YWParkInfo.CardType,1);
	memcpy(DATA+16,&YWT->YWParkInfo.ParkFlag,1);
	memcpy(DATA+17,YWT->YWParkInfo.ParkDateTime,4);
	memcpy(DATA+21,&YWT->YWParkInfo.UpdateFlag,1);
	memcpy(DATA+22,YWT->YWParkInfo.DongjieMoney,2);
	memcpy(DATA+24,YWT->YWParkInfo.Res,7);
	memcpy(DATA+31,YWT->YWParkInfo.FEEMNY+1,2);
	memcpy(DATA+33,YWT->YWParkInfo.ParkMBNO,4);
	memcpy(DATA+37,YWT->YWParkInfo.ParkInOutTime,7);	
	memcpy(DATA+45,&YWT->CardType,1);
	memcpy(DATA+46,YWT->YYXLH,10);
//	memcpy(DATA+54,&YWT->CSDMType,1);
//	memcpy(DATA+55,YWT->NC,2);
//	memcpy(DATA+57,YWT->SHDM,2);
//	memcpy(DATA+59,YWT->POS,4);
	
    BCC = 0x00;
    ETX = 0x03;
     
    for(i=0;i<RxCounter;i++)
		RxBuffer[i] = 0x00;
    RxCounter = 0; 
    f_receiveOK = 0;
    
    TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
    timeOut = 0;
    //delay(KEYTIMEOUT_1S * 1.5);
    while(timeOut < KEYTIMEOUT_1S / 5)
		{
        if(f_receiveOK == OK)
          break;
        timeOut++;
		}
    
    //delay(KEYTIMEOUT_1S * 1.5);
    if(f_receiveOK != OK)
		return CardType_E1;
	
//		STX	ID	LEN	STATUS	DATA	BCC	ETX
//�ɹ�	0x02	0x01		0xb2+0x00+���Ѽ�¼		03
//		0x02	0x01	0x03	0xb2+����״̬+������Ϣ		03

//�������� 2015-09-01
//02 01 43 B4 00 02 20 15 09 11 15 57 55 32 20 01 00 00 00 00 31 34 43 00 00 C3 38 00 00 00 00 00 00 C3 38 00 00 00 32 20 01 00 00 05 00 00 00 00 00 00 00 00 01 00 20 20 01 01 20 16 01 01 20 25 01 01 00 00 00 00 BF 03 

//    if(RxBuffer[3]==0xb4 && RxBuffer[4] == 0x00)
//		{
//		
//		return 1;
//    	}
	else if(RxBuffer[3]==0xb9)
		{
		if(RxBuffer[4] == 0x00)
			return 1;
		else
			return 0xb9;
		}		
    else if(((RxBuffer[3]==0xb2)||(RxBuffer[3]==0xb4)) && (RxBuffer[4] == 0x00))
		{      
//		if(RxBuffer[2] == 0x43)//�������� 2015-07-28 ����
//		if(RxBuffer[2] == 0x45)//�������� 2015-11-30 ����
		if(RxBuffer[2] == 0x42)//�������� 2016-03-09 ����
        	{
			memcpy(&YWTR->CardType,RxBuffer+5,1);
			memcpy(YWTR->TradeDateTime,RxBuffer+6,7);
//			memcpy(YWTR->CSDM,RxBuffer+13,2);
//			memcpy(YWTR->YYXLH,RxBuffer+15,8);
			memcpy(YWTR->YYXLH,RxBuffer+13,10);
			memcpy(YWTR->QBalance,RxBuffer+23,4);
			memcpy(YWTR->Pays,RxBuffer+27,4);
			memcpy(YWTR->Balance,RxBuffer+31,4);
			memcpy(YWTR->TradeId,RxBuffer+35,2);
			memcpy(&YWTR->JYLX,RxBuffer+37,1);
			memcpy(YWTR->PSAMCode,RxBuffer+38,6);
			memcpy(YWTR->PSAMJYXH,RxBuffer+44,4);
			memcpy(YWTR->TAC,RxBuffer+48,4);
			memcpy(&YWTR->ZKLXM,RxBuffer+52,1);
			memcpy(&YWTR->ZKLXS,RxBuffer+53,1);
			memcpy(&YWTR->PSAMVer,RxBuffer+54,1);//new 2015-11-30
			memcpy(&YWTR->KeyIndex,RxBuffer+55,1);//new 2015-11-30
			memcpy(YWTR->YXRQ,RxBuffer+56,4);
			memcpy(YWTR->YYQYRQ,RxBuffer+60,4);
			memcpy(YWTR->YYYXRQ,RxBuffer+64,4);
			memcpy(YWTR->RecMAC,RxBuffer+68,4);	
			for(i=0;i<16;i++)
				RxBuffer[54+i] = RxBuffer[54+i+2];//2015-12-16
//����CPU���洢��¼2016-03-22  andyluo
//			�ɹ�	0x02	0x01		0xb2+0x00+���Ѽ�¼
//�ۿ�ɹ���дѭ���ļ�ʧ��	0x02	0x01		0xb2+0x01+���Ѽ�¼
			if(RxBuffer[4] == 0x01)
				return 0xb9;			
#ifdef     flase_test//���Լٽ��� 2015��8��27��			
            return 2;
#endif 
            return 1;
        	}
        else if(RxBuffer[2] == 0x02)	
            return 6;
        else 
            return 5;
		}
    else if(RxBuffer[3]==0xb2 && RxBuffer[4] == 0x01)
		return CardType_E2; //B5�ɹ�,B6ʧ��
    else if(RxBuffer[3]==0xb2 && RxBuffer[4] == 0xf0 && RxBuffer[2] == 0x5E)	   
        return CardType_E3; 
    else if(RxBuffer[3]==0xb2 && RxBuffer[4] == 0xf0 && RxBuffer[2] == 0x04)	   
        return CardType_E4; 
    else if(RxBuffer[3]==0xb2 && RxBuffer[4] == 0xE2)	   
        return CardType_E6; 
    else
		return CardType_E7;//ʧ��
    
}



//���뿨�� card_number[0]  ��  card_number[3]
//��� ��Կ  mimakey[0] --mimakey[5]
void MF1key_main(uchar card_number[],uchar mimakey[])
{   
unsigned char  i,k10,k11,k12,k13,k14,m;
unsigned int   mm;


     for(i=0;i<4;i++)
         xdata1[i]=card_number[i] | 0x33;
     for(i=0;i<4;i++)
         xdata1[i+4]=card_number[i];

     for(i=0;i<8;i++)
         xdata2[i]=system_number[i];

     len=8;
     pro(xdata1,data2,temp1,len);
     for(i=0;i<8;i++)
         temp3[i]=temp1[i];
     len=7;
     pro(xdata2,data4,temp2,len);          /*b840 ���浽59ca:*/

     k14=0;k11=0;

     /*5a2e*/
     for(k14=0;k14<0x10;k14++)
     {
             k11=0;
     while(1)
     {
         if(k11<data5[k14])
         {
             k12=temp2[3] & 0x08;
             k10=0x07;
             /*5a45*/
             for(;k10>0;k10--)
             {
                k13=temp2[k10-1] & 0x80;
                temp2[k10-1]=temp2[k10-1]+temp2[k10-1];
                if(k12!=0)  temp2[k10-1]=temp2[k10-1] | 0x01;
                k12=k13;
             }
             if(k12!=0) temp2[3]=temp2[3] | 0x10;
             else       temp2[3]=temp2[3] & 0xef;

             k11++;
        }
        else break;
     }
     /*5a82*/
     len=0x06;
     pro(temp2,data7,xdata1,len);
     len=0x06;
     for(i=0;i<4;i++)  temp4[i]=temp3[i+4];
     pro(temp4,data8,temp1,len);
     for(i=0;i<4;i++)  temp3[i+4]=temp4[i];
     /*5ad3*/
     k10=0;
     for(i=0;i<6;i++)  temp1[i]=xdata1[i] ^ temp1[i];
     xdata1[0]=(temp1[0]>>2) & 0x3f;

     xdata1[1]=(_cror_((temp1[0] & 0x03),4)) | (_cror_(temp1[1],4) & 0x0f);
     xdata1[2]=((temp1[1] & 0x0f) * 4) | ((_cror_(temp1[2],4)>>2)&0x03);
     xdata1[3]=temp1[2] & 0x3f;
     xdata1[4]=(temp1[3]>>2) & 0x3f;
     xdata1[5]=(_cror_((temp1[3]&0x03),4)&0xf0) | (_cror_(temp1[4],4)&0x0f);
     xdata1[6]=((temp1[4]&0x0f)*4) | ((_cror_(temp1[5],4)>>2)&0x03);
     xdata1[7]=temp1[5]&0x3f;

     k10=0;
     /*5ba0*/
     for(k10=0;k10<8;k10++)
     {
         bdata1=xdata1[k10];

         if(bdata1&0x20) xdata1[k10]= xdata1[k10]^0x60;	  	  //2013.5.9
         bdata1=xdata1[k10];
   
		 if(bdata1&0x01) xdata1[k10]= xdata1[k10] | 0x20;	 //2013.5.9
         xdata1[k10]=xdata1[k10]>>1;
     }
     k10=0;
     /*5c1e*/
     for(k10=0;k10<8;k10++)
     {
       mm=0x40*k10+xdata1[k10];
       xdata1[k10]=data9[mm];
     }
     for(k10=0;k10<8;)
     {
        m=k10>>1;
        xdata1[m]=(xdata1[k10+1]) | (_cror_(xdata1[k10],4) & 0xf0);
        k10=k10+2;
     }
     len=4;
     pro(xdata1,data10,temp1,len);
     for(k10=0;k10<4;k10++)
     {
         temp1[k10]=temp1[k10] ^ temp3[k10];
         temp3[k10]=temp3[k10+4];
         temp3[k10+4]=temp1[k10];
     }
     }
     for(k10=0;k10<4;k10++)
     {
         temp1[k10]=temp3[k10+4];
         temp1[k10+4]=temp3[k10];
     }
     len=8;
     pro(temp1,data11,xdata1,len);
     len=9;
     for (i=0;i<6;i++)
     {
        xdata1[i]+=system0_number[i];
     }
		 
     for (i=0;i<6;i++)
     {
        mimakey[i] =xdata1[i];
     }
}

// 10.��������֤
//sector            ������:   0x00 - 0x0f
//password_class    �������: 0x0a keyA��֤   0x0b keyB��֤
//password          ���룺    6�ֽ�
unsigned char testkey_comd(uchar sector,uchar password_class,uchar* password)
{
    uchar STX;
    uchar ID;
    uchar LEN;
    uchar CMD;
    uchar DATA[8];
    uchar BCC;
    uchar ETX;
    
     STX = 0x02;
     ID  = 0x01;
     LEN = 0x09;
     CMD = 0x6c;
     DATA[0] = sector;
     DATA[1] = password_class;
     DATA[2] = password[0];
     DATA[3] = password[1];
     DATA[4] = password[2];
     DATA[5] = password[3];
     DATA[6] = password[4];
     DATA[7] = password[5];
     BCC = 0x00;
     ETX = 0x03;
     
     for(u16 i=0;i<RxCounter;i++)
          RxBuffer[i] = 0x00;
     
    RxCounter = 0;   
    f_receiveOK = 0;
    TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
    
    while(timeOut < KEYTIMEOUT_1S / 2)
    {
        if(f_receiveOK == OK)
          break;
        timeOut++;
    }
    if(f_receiveOK != OK)
        return 0;
    
    if(RxBuffer[0] == STX  && RxBuffer[2] == 0x01 && RxBuffer[3] == 0x4c  && RxBuffer[RxCounter - 1] == ETX){     
      return 1; //success
    }
    else if(RxBuffer[0] == STX  && RxBuffer[2] == 0x01 && RxBuffer[3] == 0x4e  && RxBuffer[RxCounter - 1] == ETX)
    {
      return 2; // �޿�
    }
    else if(RxBuffer[0] == STX  && RxBuffer[2] == 0x01 && RxBuffer[3] == 0x45  && RxBuffer[RxCounter - 1] == ETX)
    {
      return 3;//���벻��
    }
    else 
    {
        return 4;//��֤����
    }
}

//11.����������
//block ���  0x00 - 0x3f
//read_data[] ����������
uchar read_comd(unsigned char block,u8 read_data[])//��� ��0x00~0x3f�� ��64��
{
    uchar STX;
    uchar ID;
    uchar LEN;
    uchar CMD;
    uchar DATA[1];
    uchar BCC;
    uchar ETX;
    
     STX = 0x02;
     ID  = 0x01;
     LEN = 0x02;
     CMD = 0x72;
     DATA[0] = block;
     
     BCC = 0x00;
     ETX = 0x03;
     
     for(u16 i=0;i<RxCounter;i++)
          RxBuffer[i] = 0x00;
     
    RxCounter = 0;   
    f_receiveOK = 0;
    TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
    //delay(KEYTIMEOUT_1S/5);
    while(timeOut < KEYTIMEOUT_1S )
    {
        if(f_receiveOK == OK)
          break;
        timeOut++;
    }
    if(f_receiveOK != OK)
    {
        return 0;
    }
    
    if(RxBuffer[2] == 0x10 ){
          for(int i=0;i<16;i++)				        
          {
            read_data[i]=RxBuffer[i+3];
          }//������
          return 1; //���������ݳɹ�
        }
        else
        {
          return 0;//��ȡʧ��
        }
    
}

/*----------------------------------------------------------------------
����:    д��
����:    ����ѡ��ͨ����֤��д��һ��16�ֽڵĿ�
input:   block�����ַ
         write_data ��16�ֽ�����
output:  ����
------------------------------------------------------------------------*/
uchar write_comd(u8 block,u8 write_data[])
{
    uchar STX;
    uchar ID;
    uchar LEN;
    uchar CMD;
    uchar DATA[17];
    uchar BCC;
    uchar ETX;
    u16 i,k;
		
     STX = 0x02;
     ID  = 0x01;
     LEN = 0x12;
     CMD = 0x77;
     DATA[0] = block;
     
     for(i=0;i<RxCounter;i++)
          RxBuffer[i] = 0x00;
     
      for(k=0;k<16;k++)
       {DATA[k+1]=write_data[k];}   //huangfeng Ҫд���16���ֽ�����
     
     BCC = 0x00;
     ETX = 0x03;
	 RxCounter = 0;   
	 f_receiveOK = 0;
	 TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
	 //delay(KEYTIMEOUT_1S/5);
	 while(timeOut < KEYTIMEOUT_1S * 2)
	 	{
		if(f_receiveOK == OK)
			break;
		timeOut++;
		}
	 if(f_receiveOK != OK)
	 	{
		return 0;
		}
    
	if(RxBuffer[2] == 0x10)
		{
		for(i=0;i<16;i++)
			{
			if(DATA[i+1] != RxBuffer[i+3])
				break;
			}
		if(i==16)
			return 1; //д�������ݳɹ�
		else
			return 0; //д��ʧ��
		}
	else if(RxBuffer[3] == 0x4e)
		{
		return 2;//�޿�
		}
    else if(RxBuffer[3] == 0x45)
		{
        return 3;//���벻��
        }
    else if(RxBuffer[3] == 0x46)
		{
        return 4;//д����
        }
    else if(RxBuffer[3] == 0x55)
		{
        return 5;//������
        }
    else
		{
		return 0;//д��ʧ��
		}
}



/*----------------------------------------------------------------------
����:    14.��ֵOR��ֵ	   �̶���04�����
����:    �Կ����ڵ�ĳһ����мӡ�������,�ÿ����Ϊֵ���ʽ,��֧���Զ����͡�
input:   add_sub:         0x2b ��ֵ
         add_sub:         0x2d ��ֵ
         block_value��    ���
         park_mny��       4�ֽڽ��
output:  ״ֵ̬��MI_OK��MI_QUIT��SPI_ERR����������80~87         
------------------------------------------------------------------------*/
unsigned char value_comd(u8 add_sub,u8 block_value, u16 park_mny)
{
    uchar STX;
    uchar ID;
    uchar LEN;
    uchar CMD;
    uchar DATA[10];
    uchar BCC;
    uchar ETX;
    
     STX = 0x02;
     ID  = 0x01;
     LEN = 0x06;
     CMD = add_sub; //2b +      2d -
     DATA[0] = block_value;
     DATA[1]=0x00;
     DATA[2]=0x00;
     DATA[3]=(u8)(park_mny>>8);
     DATA[4]=(u8)park_mny;  
     BCC = 0x00;
     ETX = 0x03;
    RxCounter = 0;   
    f_receiveOK = 0;
    TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
    //delay(KEYTIMEOUT_1S/5);
    while(timeOut < KEYTIMEOUT_1S * 2)
    {
        if(f_receiveOK == OK)
          break;
        timeOut++;
    }
    
    if(RxBuffer[2] == 0x04 ){
        return 1; //success
    }
    else
    {
        return 0;//false
    }
}

//��CPU�����������
void read_CPU_data(uchar data[])
{
    for(int i=0;i<16;i++)
    {
        data[i] = RxBuffer[4 + i];
    }
}

//CPU�� ������
unsigned char read_CPUcard(uchar Catalog[],uchar FileId,uchar Addr,uchar Length)
{
    uchar i;
    uchar STX;
    uchar ID;
    uchar LEN;
    uchar CMD;
    uchar DATA[10];
    uchar BCC;
    uchar ETX;
    
     STX = 0x02;
     ID  = 0x01;
     LEN = 0x06;
     CMD = 0xb9; 
     for(i=0;i<2;i++)
       DATA[i] = Catalog[i];
     DATA[4] = FileId;
     DATA[5] = Addr;
     DATA[6] = Length;
     
     BCC = 0x00;
     ETX = 0x03;
    RxCounter = 0;   
    f_receiveOK = 0;
    TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
    delay(KEYTIMEOUT_1S/5);
 //   while(timeOut < KEYTIMEOUT_1S * 2)
    {
  //      if(f_receiveOK == OK)
   //       break;
   //     timeOut++;
    }
    
    if(RxBuffer[4] == 0x00 && RxBuffer[3] == 0xb9 ){
        return 1; //success
    }
    else
    {
        return 0;//false
    }
}

/*CPU����������----------huangfeng------2013.5.8------*/
unsigned char write_CPUcard(char CardId[],uchar FiledId,uchar Addr,uchar Length,uchar write_data[])
{
      uchar i;
      uchar STX;
      uchar ID;
      uchar LEN;
      uchar CMD;
      uchar DATA[40];
      uchar BCC;
      uchar ETX;
    
     STX = 0x02;
     ID  = 0x01;
     LEN = 0x18;
     CMD = 0xb5; 
     for(i=0;i<4;i++)
       DATA[i] = CardId[i];
     DATA[4] = FiledId;
     DATA[5] = Addr;
     DATA[6] = Length;
     for(i=0;i<Length;i++)
       DATA[7 + i] = write_data[i];
     
     BCC = 0x00;
     ETX = 0x03;
    RxCounter = 0;
    f_receiveOK = 0;
    TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
 //   delay(KEYTIMEOUT_1S/5);
    
    while(timeOut < KEYTIMEOUT_1S * 2)
    {
      if(f_receiveOK)
      {
        if(RxBuffer[4] == 0x00 && RxBuffer[3] == 0xb5 ){
            return 1; //success
        }
        else
        {
            return 0;//false
        }
      }
      
      timeOut++;
    }
    
    return 0;
    
}

//����CPU���Ŀۿ����
uchar JM_value_CPUcard(uchar Momery[],uchar Time[])
{
    uchar i;
    uchar STX;
    uchar ID;
    uchar LEN;
    uchar CMD;
    uchar DATA[16];
    uchar BCC;
    uchar ETX;
    
     STX = 0x02;
     ID  = 0x01;
     LEN = 0x0e;
     CMD = 0xb2;
    
    for(i=0;i<4;i++)
       DATA[i] = Momery[i];
    
    DATA[4] = 0x20;
    
    for(i=0;i<5;i++)
      DATA[5+i] = Time[i];
    DATA[10] = 0x00;
    
    DATA[11] = 0x00;
    DATA[12] = 0x12;
    
    BCC = 0x00;
     ETX = 0x03;
     
    for(u16 i=0;i<RxCounter;i++)
      RxBuffer[i] = 0x00;
    RxCounter = 0; 
    f_receiveOK = 0;
    
    TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
    timeOut = 0;
    //delay(KEYTIMEOUT_1S * 1.5);
    while(timeOut < KEYTIMEOUT_1S / 5)
    {
        if(f_receiveOK == OK)
          break;
        timeOut++;
    }
    
    //delay(KEYTIMEOUT_1S * 1.5);
    if(f_receiveOK != OK)
      return 0;
    
    //if(RxBuffer[3]==0xb2 && RxBuffer[4] == 0x00 &&   ((RxBuffer[2] == 0x60) || (RxBuffer[2] == 0x02) ))	
    if(RxBuffer[3]==0xb2 && RxBuffer[4] == 0x00)	
    {      
        if( RxBuffer[2] == 0x60)
            return 1;
        else if(RxBuffer[2] == 0x02)	
            return 1;
        else 
            return 4;
    }
    else if(RxBuffer[3]==0xb2 && RxBuffer[4] == 0x01)	   
       return 2; //B5�ɹ�,B6ʧ��
    else if(RxBuffer[3]==0xb2 && RxBuffer[4] == 0xf0 && RxBuffer[2] == 0x5E)	   
       return 3; 
    else if(RxBuffer[3]==0xb2 && RxBuffer[4] == 0xf0 && RxBuffer[2] == 0x04)	   
       return 4; 
    else
        return 0;//ʧ��
    
}

//CPU������ۿ����
unsigned char value_CPUcard(uchar YearH,uchar Year,uchar Month,uchar Date,uchar Hour,uchar Min,uchar Second,uchar QBalance[],uchar Pays[],uchar CardId[])
{
    uchar i;
    uchar STX;
    uchar ID;
    uchar LEN;
    uchar CMD;
    uchar DATA[50];
    uchar BCC;
    uchar ETX;
    
     STX = 0x02;
     ID  = 0x01;
     LEN = 0x14;
     CMD = 0xb2; 
     
     DATA[0] = YearH;
     DATA[1] = Year;
     DATA[2] = Month;
     DATA[3] = Date;
     DATA[4] = Hour;
     DATA[5] = Min;
     DATA[6] = Second;
     
     for(i=0;i<4;i++)
       DATA[i + 7] = QBalance[i];
     
     for(i=0;i<4;i++)
       DATA[i + 11] = Pays[i];
     
     for(i=0;i<4;i++)
       DATA[i + 15] = CardId[i];
          
     BCC = 0x00;
     ETX = 0x03;
    RxCounter = 0;   
    f_receiveOK = 0;
    TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
    delay(KEYTIMEOUT_1S * 1.5);
   // while(timeOut < KEYTIMEOUT_1S * 2)
    {
  //      if(f_receiveOK == OK)
   //       break;
   //     timeOut++;
    }
    
    if((RxBuffer[2] == 0x2f)&&(RxBuffer[3] == 0xb2))	 		  
      return 0; //�ɹ� 		
    else		   
      return 1;
}


void pro(unsigned char * dat1,unsigned char * dat2,unsigned char * dat3,unsigned char length)
{
  unsigned char  i,j,m,n,k1,k2;
  //for(i=0;i<len;i++)
 for(i=0;i<length;i++)
  {
      dat3[i]=0;
      for(j=0;j<8;j++)
      {
          m  = dat2[i*8+j];
          n  = (m>>3) & 0x1f;//&��λ������;>>����
          k1 = dat1[n];
          m  = m & 0x07;
          m++;
          k2 = 0x80;
          while((--m)!=0) k2=k2>>1;
          k1 = k1 & k2;
          if(k1!=0)
          {
              m = dat3[i];
              n = j;
              k2= 0x80;
              n++;
              while((--n)!=0)
                    k2=k2>>1;
              k2=k2 | m;//��λ������
              dat3[i]=k2;
          }

      }
  }
}



//����ͨ�� ���� ������
uchar catch_BaclkList()
{
    //uchar i;
    uchar STX;
    uchar ID;
    uchar LEN;
    uchar CMD;
    uchar DATA[50];
    uchar BCC;
    uchar ETX;
    
     STX = 0x02;
     ID  = 0x01;
     LEN = 0x01;
     CMD = 0xb8; 
     BCC = 0x00;
     ETX = 0x03;
     
    for(u16 i=0;i<RxCounter;i++)
      RxBuffer[i] = 0x00;
    RxCounter = 0; 
    f_receiveOK = 0;
    
    TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
    timeOut = 0;
    //delay(KEYTIMEOUT_1S * 1.5);
    while(timeOut < KEYTIMEOUT_1S / 1)
    {
        if(f_receiveOK == OK)
          break;
        timeOut++;
    }

    
    if((RxBuffer[3] == 0xb8)&&(RxBuffer[4] == 0x00))	 		  
      return 0; //�ɹ� 		
    else		   
      return 1;
}


/*δ�������״�����CMD=0xb7
//02 01 1b b7 ����(�߼�����8+��������8+Ʊ�����׼�����2+���׽��4+�������4) b1 03
//���أ�02 01 LEN  b7 00 +����+BCC 03*/
unsigned char Faildeal_CPUcard(u8 data[],uchar TAC[])  //26��
{
    uchar i;
    uchar STX;
    uchar ID;
    uchar LEN;
    uchar CMD;
    uchar DATA[30];
    uchar BCC;
    uchar ETX;
    
	STX = 0x02;
	ID = 0x01;
	LEN = 0x1b; //27			
	CMD = 0xb7;
	for(i=0;i<26;i++)
          DATA[i]=data[i];   //�߼�����8+��������8+Ʊ�����׼�����2+���׽��4+�������4
	BCC = 0x00;
        ETX = 0x03;   
        
        for(u16 i=0;i<RxCounter;i++)
          RxBuffer[i] = 0x00;
        RxCounter = 0;   
        f_receiveOK = 0;
        TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
        while(timeOut < KEYTIMEOUT_1S)
        {
            if(f_receiveOK == OK)
              break;
            timeOut++;
        }
    
	if((RxBuffer[3] == 0xb7)&&(RxBuffer[4] == 0x00))		 
        {
	    //������֤��TAC 4
	    TAC[0]=RxBuffer[5];
            TAC[1]=RxBuffer[6];		 
            TAC[2]=RxBuffer[7];		 
            TAC[3]=RxBuffer[8];
            return 0; 	 //�ɹ�		 
        } 	
        else 	    
          return 1; 	 //ʧ��


}

//���汾
u8 Read_ReaderVer(void)
{
	u16 i;
	u32 timeOut;
		
	for(i=0;i<RxCounter;i++)
		RxBuffer[i] = 0x00;
	RxCounter = 0;	
	f_receiveOK = 0;
    sent_smart_data(0x02);
    sent_smart_data(0x01);
    sent_smart_data(0x01);
    sent_smart_data(0x01);
    sent_smart_data(0x01);
    sent_smart_data(0x03);
	
	timeOut = 0;
	while(timeOut < KEYTIMEOUT_1S / 5)
		{
			/* ι��*/
			IWDG_ReloadCounter();//2015-12-23 andyluo
			if(f_receiveOK == OK)
			  break;
			timeOut++;
		}
	if(f_receiveOK != OK)
		{
		return 1;
		}
//02 01 05 01 02 02 00 02 07 03
	if((RxBuffer[3] == 0x01)&&(RxBuffer[RxCounter - 1] == 0x03))		 
		{
		return 0;	 //�ɹ� 	 
		}
	else if((RxBuffer[3] == 0xff)&&(RxBuffer[RxCounter - 1] == 0x03))		
		return 1; 	 //ʧ��
	else
		return 2; 	 //ʧ��
}



//������ID
uchar read_mech_ID()
{
    //uchar i;
    uchar STX;
    uchar ID;
    uchar LEN;
    uchar CMD;
    uchar DATA[1];
    uchar BCC;
    uchar ETX;
    
	STX = 0x02;
	ID = 0xff;
	LEN = 0x01; //27			
	CMD = 0x67;
	BCC = 0x00;
        ETX = 0x03;   
        
        for(u16 i=0;i<RxCounter;i++)
          RxBuffer[i] = 0x00;
        RxCounter = 0;   
        f_receiveOK = 0;
        TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
        
        timeOut = 0;
        while(timeOut < KEYTIMEOUT_1S / 5)
        {
			/* ι��*/
			IWDG_ReloadCounter();//2015-12-23 andyluo
            if(f_receiveOK == OK)
              break;
            timeOut++;
        }
        
        if(f_receiveOK != OK)
        {
            return 1;
        }
    
	if((RxBuffer[3] == 0x00)&&(RxBuffer[RxCounter - 1] == 0x03))		 
        {
            return 0; 	 //�ɹ�		 
        } 	
        else if((RxBuffer[3] == 0xff)&&(RxBuffer[RxCounter - 1] == 0x03))	    
          return 1; 	 //ʧ��
        else
          return 2;      //ʧ��
}


//������PSAM
uchar read_PSAM()
{
    //uchar i;
    uchar STX;
    uchar ID;
    uchar LEN;
    uchar CMD;
    uchar DATA[1];
    uchar BCC;
    uchar ETX;
    
	STX = 0x02;
	ID = 0x01;
	LEN = 0x01; //27			
	CMD = 0xb0;
	BCC = 0xb0;
        ETX = 0x03;   
        
        for(u16 i=0;i<RxCounter;i++)
          RxBuffer[i] = 0x00;
        RxCounter = 0;   
        f_receiveOK = 0;
        TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
        
        timeOut = 0;
        while(timeOut < KEYTIMEOUT_1S / 5)
        {
			/* ι��*/
			IWDG_ReloadCounter();//2015-12-23 andyluo
            if(f_receiveOK == OK)
              break;
            timeOut++;
        }
    
	if(RxBuffer[3] == 0xb0 && RxBuffer[4] == 0x00 && RxBuffer[RxCounter - 1] == 0x03)		 
        {
            return 0; 	 //�ɹ�		 
        } 	
        else if(RxBuffer[3] == 0xb0 && RxBuffer[4] == 0xFF && RxBuffer[RxCounter - 1] == 0x03)	    
          return 1; 	 //ʧ��
        else
          return 2;      //ʧ��
}

//������ ��������
uchar recover_back_list()
{
    //uchar i;
    uchar STX;
    uchar ID;
    uchar LEN;
    uchar CMD;
    uchar DATA[1];
    uchar BCC;
    uchar ETX;
    
	STX = 0x02;
	ID = 0x01;
	LEN = 0x01; //27			
	CMD = 0xb9;
	BCC = 0xb9;
        ETX = 0x03;   
        
        for(u16 i=0;i<RxCounter;i++)
          RxBuffer[i] = 0x00;
        RxCounter = 0;   
        f_receiveOK = 0;
        TX_Smart_Command(STX,ID,LEN,CMD,DATA,BCC,ETX);
        
        timeOut = 0;
        while(timeOut < KEYTIMEOUT_1S / 20)
        {
            if(f_receiveOK == OK)
              break;
            timeOut++;
        }
    
	if((RxBuffer[3] == 0xB9) &&(RxBuffer[4] == 0x00) && (RxBuffer[RxCounter - 1] == 0x03))		 
        {
            return 1; 	 //�ɹ�		 
        } 	
        else 	    
          return 0; 	 //ʧ��

}
