/**************************************************************
 ADC PB1_ADC9 
 
***************************************************************/

#define ADCCTRL_0		GPIO_ResetBits(GPIOC, GPIO_Pin_2)
#define ADCCTRL_1	    GPIO_SetBits(GPIOC, GPIO_Pin_2)


//#include "stm32f10x_conf.h"
//#include "stm32f10x_it.h"
#include "Stm32f10x_adc.h"
//#include "St_credit.h"
#include "hal.h"


void ADC_Configuration(void)
{
	ADC_InitTypeDef   ADC_InitStructure;
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, ENABLE);        
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE);

	/* PB1*/
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
    /* adcctrl - PC2 */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);	

	/* ADC1 */
	ADC_InitStructure.ADC_Mode               = ADC_Mode_Independent;		//����ģʽ
	ADC_InitStructure.ADC_ScanConvMode       = ENABLE;						//������ͨ��ģʽ
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;						//����ת��
	ADC_InitStructure.ADC_ExternalTrigConv   = ADC_ExternalTrigConv_None;	//ת������������
	ADC_InitStructure.ADC_DataAlign          = ADC_DataAlign_Right;			//�Ҷ���
	ADC_InitStructure.ADC_NbrOfChannel       = 1;							//ɨ��ͨ����
	ADC_Init(ADC1, &ADC_InitStructure);
	
	/* ADC1 Regular Channel3 Configuration                                      */
	ADC_RegularChannelConfig(ADC1, ADC_Channel_13, 1, ADC_SampleTime_55Cycles5);	//ͨ��X,����ʱ��Ϊ55.5����,1��������ͨ����1��
	
	ADC_Cmd   (ADC1, ENABLE);             /* Enable ADC1                        */
	ADC_SoftwareStartConvCmd(ADC1,ENABLE);/* Start ADC1 Software Conversion     */ //ʹ��ת����ʼ
//	/* ADC2 */
//	ADC_InitStructure.ADC_Mode               = ADC_Mode_Independent;		//����ģʽ
//	ADC_InitStructure.ADC_ScanConvMode       = ENABLE;						//������ͨ��ģʽ
//	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;						//����ת��
//	ADC_InitStructure.ADC_ExternalTrigConv   = ADC_ExternalTrigConv_None;	//ת������������
//	ADC_InitStructure.ADC_DataAlign          = ADC_DataAlign_Right;			//�Ҷ���
//	ADC_InitStructure.ADC_NbrOfChannel       = 1;							//ɨ��ͨ����
//	ADC_Init(ADC2, &ADC_InitStructure);
//	
//	/* ADC1 Regular Channel1 Configuration                                      */
//	ADC_RegularChannelConfig(ADC2, ADC_Channel_12, 1, ADC_SampleTime_55Cycles5);	//ͨ��X,����ʱ��Ϊ55.5����,1��������ͨ����1��
//	
//	ADC_Cmd   (ADC2, ENABLE);             /* Enable ADC1                        */
//	ADC_SoftwareStartConvCmd(ADC2,ENABLE);/* Start ADC1 Software Conversion     */ //ʹ��ת����ʼ        
}



u16 TestAdc(void)
{
	u16 adc;
	ADC_Configuration();
	ADCCTRL_1;      
	delay(1000);
	if(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC)==SET)
		{
		adc=ADC_GetConversionValue(ADC1);
		}
	adc=adc*3300/4096;
	ADCCTRL_0;      
	//X1=j+j*(100*98)/(27*102);
	//X2=j+j*(100*102)/(27*98);
	
	return adc;
}


u16  BT_Check(u16 BT_V[2])
{
	u16 BTV ;
	u32 BTVF;
	
	BTV = TestAdc();
	BTVF = BTV * (10000+ 990000/33 );//old -/27
	BT_V[0] = BTVF/100000+10;
	BTVF = BTV * (10000+ 1010000/33);
	BT_V[1] = BTVF/100000+10;
        
	BTVF = BTV * (10000+ 1000000/33);
	BTV = BTVF/100000+10;
        
	return BTV;	
}
u16  BT_Check1(void)
{
	u16 BTV ;
// 	ADC_InitTypeDef   ADC_InitStructure;
//	GPIO_InitTypeDef  GPIO_InitStructure;              
//	u32 BTVF;
	
	BTV = TestAdc();
        BTV =BTV*10000*105/(3300*95)+BTV;
//        BTVF=
 /////////////////////////////////////////// 
        ADC_Cmd(ADC2, DISABLE);
        ADC_Cmd(ADC1, DISABLE); 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, DISABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, DISABLE);        
//////////////////////////////////////////////  
/////////////////////////////////////////////////////////////////////////////////             
/////////////////////////////////////////////////////////////////////////////////        
	return BTV;	
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
u16 TestAdc1(void)
{
	u16 adc;
	ADC_Configuration();
	ADCCTRL_0;      
	delay(1000);
	if(ADC_GetFlagStatus(ADC2, ADC_FLAG_EOC)==SET)
		{
		adc=ADC_GetConversionValue(ADC2);
		}
	adc=adc*33/4096; 
	ADCCTRL_1;             
	return adc;
}
