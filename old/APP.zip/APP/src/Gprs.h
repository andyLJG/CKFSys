
#ifndef	_Gprs_H
#define		_Gprs_H			    

unsigned char asic_to_hex(unsigned char rr);
void open_gprs_uart();
void close_uart();
void open_gprs_power();
void close_gprs_power();
void close_gprs_power1();
//void send_apn();
void send_ip(unsigned char IP_Addr[],unsigned char PORT[]);
void send_DPSip();
u8 open_gprs11();
u8 open_gprs();
u8 open_DPS();
u8 Link_network(void);
unsigned char rec_gprs_lin(unsigned long timeout);
unsigned char twoasic_to_oenhex(unsigned char *recvgsmproc,u8 ASCII);
//void CDMA_sleep();
//void CDMA_wake();
void Link_ServerIP(void);
u8 rec_gprs1(unsigned long delay_wait,unsigned char *shujv);//andyluo2011-02-12
u8 rec_gprs(unsigned long delay_wait,unsigned char *shujv,u8 change);//andyluo2011-02-12
u8 rec_gprs2(unsigned long delay_wait,unsigned char *shujv,u8 change);//andyluo2011-02-12

u8 rec_gprs_L(uchar delay_wait,uchar data[]);

uchar rec_gprs_ack(uchar delay_wait);

void open_gprs_power();
void open_gprs_uart();
void close_uart();
void close_gprs_power();

uchar recTimeData(uchar delay_wait,int data[]);
uchar recFreeCom(uchar delay_wait,int data[]);
uchar recFreeData(uchar delay_wait,int data[]);
uchar rec_IAP(uchar delay_wait,uchar data[]);
u8 NETSTATE_FUN(u8* NETFUN);
void NET_KeyDeal(void);
void Update_RTC(u8 locs);
uchar rec_gprs_feeYW(uchar delay_wait);


//@@@@@MU509B-andyluo 2016-03-04 ӡ����ֲ
#define  GSML   2000
//����ģ���ϵ�
#define TERMON_3G_1   GPIO_SetBits(GPIOA, GPIO_Pin_11)  
#define TERMON_3G_0   GPIO_ResetBits(GPIOA, GPIO_Pin_11)
//���߽�
#define SLEEP_3G_1    GPIO_SetBits(GPIOA, GPIO_Pin_12)
#define SLEEP_3G_0    GPIO_ResetBits(GPIOA, GPIO_Pin_12) 
//���߽�
#define SLEEP_3G_ON    GPIO_ResetBits(GPIOC, GPIO_Pin_5)
#define SLEEP_3G_OFF   GPIO_SetBits(GPIOC, GPIO_Pin_5) 

#define WAITPCDATATIMES   3
#define WAITATCMDTIME_Re  10000000
//#define WAITATCMDTIME  10
//#define READWAITONETIME  100
//#define READWAITTWOTIME  200
#define WAITATCMDTIME  2
#define READWAITONETIME  1*8500000
#define READWAITTWOTIME  5*8500000
 
#define DOUBLEDISPALY3GON   1
#define DOUBLEDISPALY3GOFF   0
#define AUTOREPORT3GON      1
#define AUTOREPORT3GOFF     0
#define CFUN3GON      1
#define CFUN3GOFF     0
//3Gģ����Ͽ�����
#define ERROR3GSTART  1
#define ERROR3GSIM    2
#define ERROR3GCREG   3
#define ERROR3GPASSWORD   4
#define ERROR3GLINK   5
#define KEYOP_RETURN 0X10

//3Gģ��״̬
#define  UNKNOWN           0    /*GPRS�嵱ǰ״̬----δ֪״̬*/
#define  RW_OK             1    /*GPRS�嵱ǰ״̬----GPRSģ��ɶ�д*/
#define  RegGprs_OK        2    /*GPRS�嵱ǰ״̬----ע��gprs���ɹ�*/
#define  TCPLink_OK        3    /*GPRS�嵱ǰ״̬----TCPLink�ɹ�*/
u8 MU509link_net(void);
void EmptyRcv3G(void);
void send_string_3G(u8 *ptr);
void USART_Putc(USART_TypeDef* USARTx,unsigned char c);
unsigned char sleep_module(void);
unsigned char wake_3G(unsigned char line_number);
void USART_Puts(USART_TypeDef* USARTx,unsigned char * str);

//@@@@@MU509B-andyluo 2016-03-04 ӡ����ֲ



#endif


