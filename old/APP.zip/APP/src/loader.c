#include	"loader.h"
#include "MemoryAssign.h"

//uint32_t FlashDestination = BackUpMemAddress; /* Flash user program offset */
uint32_t FlashDestination = ApplicationAddress; /* Flash user program offset */
uint16_t PageSize = PAGE_SIZE;
uint32_t EraseCounter = 0x00;
uint32_t NbrOfPage = 0;
FLASH_Status FLASHStatus = FLASH_COMPLETE;
uint32_t RamSource;
extern uint8_t tab_1024[1024];




#define	FIFO_DATA_MAX_SIZE		(FIFO_BLOCK_SIZE*FIFO_BLOCK_NUM)
#define	FIFO_BLOCK_ALMOST_FULL		(FIFO_BLOCK_NUM-1)
#define	FIFO_BLOCK_ALMOST_EMPTY		1

#define	FIFO_BLOCK_SWITCH(block)		if(block >= FIFO_BLOCK_NUM) block = 0
#define	SET_FIFO_POINTER(ptr,block)		FIFO_BLOCK_SWITCH(block); \
										(ptr)= &FIFO.buf[block*FIFO_BLOCK_SIZE]



typedef struct
{
	u32 left_block;		/*The data left in the FIFO*/
	u32 wr_block;			/*The data write into the FIFO current block number*/
	u32 rd_block;			/*The data read out of the FIFO current block number*/

	u8* wr_pt;
	u8* rd_pt;
	u8 buf[FIFO_DATA_MAX_SIZE];

}FIFO_TypeDef;


static FIFO_TypeDef FIFO;
/*
size:  bin file size;
num: bin file packs
*/
///////////////////////////////////////////////////////////////////////////////////////////////
/**
  * @brief  Print a character on the HyperTerminal
  * @param  c: The character to be printed
  * @retval None
  */
void SerialPutChar(uint8_t c)
{
  USART_SendData(USART1, c);
  while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET)
  {
  }
}

/**
  * @brief  Print a string on the HyperTerminal
  * @param  s: The string to be printed
  * @retval None
  */
void Serial_PutString(uint8_t *s)
{
  while (*s != '\0')
  {
    SerialPutChar(*s);
    s++;
  }
}

///////////////////////////////////////////////////////////////////////////////////////////////
void Dly1(u16 n)
{
	u8 i;
	while(n--){
		for(i=50;i>0;i--);
	}
}
static void FifoInit(void)
{
	/*FIFO init*/
	FIFO.left_block = 0;
	FIFO.rd_block = 0;
	FIFO.wr_block = 0;
	FIFO.rd_pt = &FIFO.buf[0];
	FIFO.wr_pt = &FIFO.buf[0];
}

FIFO_InfoDef FIFO_write(u8* src)
{
	if(FIFO.left_block < FIFO_BLOCK_NUM){
		
		SET_FIFO_POINTER(FIFO.wr_pt, FIFO.wr_block);
              memcpy(FIFO.wr_pt, src, FIFO_BLOCK_SIZE);
			  
		FIFO.left_block++;
		FIFO.wr_block++;
		
		if(FIFO.left_block < FIFO_BLOCK_ALMOST_FULL)
			return FifoWriteOK;
		else
			return FifoAlmostFull;
	}
	else
		return FifoFull;
}

static FIFO_InfoDef FIFO_pop(void)
{
	if(FIFO.left_block > 0){
		FIFO.rd_block++;
		SET_FIFO_POINTER(FIFO.rd_pt, FIFO.rd_block);
		FIFO.left_block--;
		
		if(FIFO.left_block <= FIFO_BLOCK_ALMOST_EMPTY)
			return FifoReadOK;
		else
			return FifoAlmostEmpty;
	}
	else
		return FifoEmpty;
}


u32 FIFO_Status(void)
{
	return(FIFO.left_block);
}

/**
  * @brief  Calculate the number of pages
  * @param  Size: The image size
  * @retval The number of pages
  */
uint32_t FLASH_PagesMask(__IO uint32_t Size)
{
  uint32_t pagenumber = 0x0;
  uint32_t size = Size;

  if ((size % PAGE_SIZE) != 0)
  {
    pagenumber = (size / PAGE_SIZE) + 1;
  }
  else
  {
    pagenumber = size / PAGE_SIZE;
  }
  return pagenumber;

}
void LoaderInit(void)
{
	FLASH_Unlock();
	
	/* Erase the needed pages where the user application will be loaded */
	/* Define the number of page to be erased */
	NbrOfPage = FLASH_PagesMask(BackupMemorySize);

	/* Erase the FLASH pages */
	for (EraseCounter = 0; (EraseCounter < NbrOfPage) && (FLASHStatus == FLASH_COMPLETE); EraseCounter++)
	{
	FLASHStatus = FLASH_ErasePage(FlashDestination +AppMemorySize+ (PageSize * EraseCounter));
	//FLASHStatus = FLASH_ErasePage(FlashDestination+(PageSize * EraseCounter));        
	}

	// FifoInit();
	
}

ErrorStatus BackupProgram(void)
{
        uint32_t i;
        uint32_t Begin;
        uint32_t End;
        uint32_t Count;
        
        uint32_t data;
        
        u8 Begin_buf[4];
        u8 End_buf[4];
        u8 Count_buf[4];
        
        I2C_ReadS_24C(UpdateProgramAddr,Begin_buf,4);//��ʼ��ַ
        I2C_ReadS_24C(UpdateProgramAddr + 4,End_buf,4);//������ַ
        I2C_ReadS_24C(UpdateProgramAddr + 8,Count_buf,4);//����
        
        Begin = hcl(Begin_buf,4);
        End = hcl(End_buf,4);
        Count = hcl(Count_buf,4);
        
        SPI_FLASH_Init();
        
        FLASH_Unlock();
        LoaderInit();
        
        FlashDestination = BackUpMemAddress;
        
        for (i = 0;(i < Count) && (FlashDestination <  BackUpMemAddress + BackupMemorySize) && (i < Count);i += 4)
        {
                SPI_FLASH_BufferRead(Begin_buf,Begin,4);
                data = hcl(Begin_buf,4);
                /* Program the data received into STM32F10x Flash */
                FLASH_ProgramWord(FlashDestination, data);  
                
		if (*(uint32_t*)FlashDestination!= data)                  
			return ERROR;
                
                FlashDestination += 4;
                Begin += 4;
                i += 4;
        }
        
        return SUCCESS;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
static u32 SoucePt;


static ErrorStatus ProgramCode(void)
{
	u32 j;
	SoucePt = BackUpMemAddress;
	
	/* Erase the needed pages where the user application will be loaded */
	/* Define the number of page to be erased */
	NbrOfPage = FLASH_PagesMask(AppMemorySize);

	/* Erase the FLASH pages */
	for (EraseCounter = 0; (EraseCounter < NbrOfPage) && (FLASHStatus == FLASH_COMPLETE); EraseCounter++)
	{
	  FLASHStatus = FLASH_ErasePage(FlashDestination + (PageSize * EraseCounter));
	}

	FlashDestination = ApplicationAddress;
	
	for (j = 0;(j < AppMemorySize) && (FlashDestination <  BackUpMemAddress);j += 4)
	{
		/* Program the data received into STM32F10x Flash */
		FLASH_ProgramWord(FlashDestination, *(u32*)SoucePt);

		if (*(u32*)FlashDestination != *(u32*)SoucePt)
			return ERROR;
		
		FlashDestination += 4;
		SoucePt += 4;
	}
	
	return SUCCESS;
}

void IapUpdata(void)
{
	if(ProgramCode() != SUCCESS);
		ProgramCode();

}

