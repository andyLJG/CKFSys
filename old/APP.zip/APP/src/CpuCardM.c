#include "Do_Task.h"
#include "Smart_card.h"
#include "hardware_test.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include <intrinsics.h>
#include "CpuCardM.h"

#define _nop_() __no_operation()

TACTCDInfor  TCardInfor;
//���鶨��
u8  carddata[13];    //13���ֽ����� 
u8  oldcarddata[13]; //��һ�ζ�������
u8  newcarddata[13]; //�ڶ��ζ�������
FirstCardInfor FCardInfor;   //��һ�ο�����Ϣ

/* �����ܲ�ͨ������������ ��7��������*/
void CCard_GPIOConfig(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure; 
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOF|RCC_APB2Periph_GPIOG, ENABLE);  
  
  //IC_SWITCH-PD6(PG6) //������(=1�޿�/=0�п�)
  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	//��������
  GPIO_Init(GPIOD, &GPIO_InitStructure);  
  //IC_POWER -PF10(PF6) //power switcher for ic-card(=0--�����ϵ�/=1--�����ϵ�)
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOF, &GPIO_InitStructure);
  //IC_RST-PF9(PF7)  //ic-card's rst-pin(IC_RST),or data-card's /reset-pin
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOF, &GPIO_InitStructure);
  //IC_PGM-PF8(PF8) //ic-card's pgm-pin(IC_PGM),or data-card's si-pin(�Ȳ���)
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOF, &GPIO_InitStructure);
  //IC_ECLK_EN-PB9(PF9)  �ⲿʱ��ʹ��,��IC_ECLK_EN=1��IC_CLK_H,��Ƭʱ��ʹ���ⲿʱ��
  //��IC_ECLK_EN=0,��IC_CLK(P1.7)��Ϊ��д��Ƭ���ݵ�ʱ��  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  //IC_DATA-PF10,IC_CLK-PF11  // IC���� I/O(IC_DATA)ic-card's clock-pin(IC_CLK)
//  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_10 |GPIO_Pin_11;
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
//  GPIO_Init(GPIOF, &GPIO_InitStructure);
  //PG14(PF10)
  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_14;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	//��������
  GPIO_Init(GPIOG, &GPIO_InitStructure); 
  //PD7(PF11)
  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	//���
  GPIO_Init(GPIOD, &GPIO_InitStructure);     
}

/*ʱ��*/
void delayus1(void)
{
  u8 i;
  for(i=0;i<40;i++)
//  for(i=0;i<80;i++)
  {  
    _nop_();
    _nop_();
    _nop_();
    _nop_();
  }
}

void delayus2(void)
{
  u8 i;
//  for(i=0;i<80;i++)
  for(i=0;i<40;i++)
  {   
    _nop_();
    _nop_();
    _nop_();
    _nop_();
    _nop_();
    _nop_();
    _nop_();
    _nop_();
    _nop_();
    _nop_();
    _nop_();
    _nop_();
  }
}


/*��λʱ��*/
void rst_card(void)
{
  IC_RST_H;
  delayus2();    //time_2
  IC_CLK_H;
  delayus2();    //time_2	
  IC_CLK_L;
  delayus2();    //time_2
  IC_RST_L;
  delayus2();    //time_2
}

  

/*1��������----------------------------------------------------*/
/*******************************************************************
****�������ƣ�inbyt
****�������ã���EEPROM��������, ��λ��ǰ
****�����������
****����ֵ��  ���յ����ֽ�
*******************************************************************/
u8 read_onebyte(void)
{
  u8 i;
  u8 ReceiveByte=0;
    				
  for(i=0;i<8;i++)					 
  { 
    ReceiveByte<<=1;         //���ݴӸ�λ����λ
    if(IC_DATA_read)//MODIFY
    {
      ReceiveByte|=0x01;
    }    
    IC_CLK_H;
    delayus2();
    IC_CLK_L;
    delayus1();	
  }  
  return ReceiveByte;   
}

//13����ַ��ֵ
void read_cpucard(void)
{
  u8 i;  
  rst_card();   //����λ
  //��13���ֽ�����
  for(i=0;i<13;i++)
  {carddata[i]=read_onebyte(); } //����һ���ֽ�����    
  
}
void read_card_test(u8  carddatatest[13] )
{
  u8 i;  
  rst_card();   //����λ
  //��13���ֽ�����
  for(i=0;i<13;i++)
  {carddatatest[i]=read_onebyte(); } //����һ���ֽ�����    
  
}


/*���ݱ���*/
void copy_data(u8 first_second)
{
  u8 i; 
  if(first_second==1) //��һ�ζ�ȡ���ݱ���
  {  
    for(i=0;i<13;i++)
    {oldcarddata[i]=carddata[i];}
  }
  else
  {
    for(i=0;i<13;i++)
    {newcarddata[i]=carddata[i];} //�ڶ��ζ�ȡ���ݱ���
  }
}

void makeup_cardinfor(void)
{
  u8 i, one;
  u8 money_data;
  u32 money;
  /*������ϢE9 30 73 75   25 8E 0E   64   00 00 00 00 00*/
  //�ܲ�ͨ��ͷ---------------------------------------------------
//  e8 28 06 57 10 4c 8a c8 00 07 3f 1f 00
//  91 56 30 57 08 69 9a 28 00 01 7f 00 00
//  91 56 30 57 0e ef cd a8 00 01 7f 03 0f
  TCardInfor.head[0]=carddata[0];
  TCardInfor.head[1]=carddata[1];
  TCardInfor.head[2]=carddata[2];
  TCardInfor.head[3]=carddata[3];
  //����--------4���ֽڿ���------------------------------------------------ 			
  TCardInfor.cardNO[0]=0;
  TCardInfor.cardNO[1]=carddata[4];
  TCardInfor.cardNO[2]=carddata[5];
  TCardInfor.cardNO[3]=carddata[6]; 
 //���б�־
// TCardInfor.init_flag=carddata[7];	  
 TCardInfor.init_flag=carddata[8];	  
  //1�����Ľ��-----------------start-----------------
  money=0;
  money_data=carddata[12];
  if(money_data)
  {   
    for(i=0;i<8;i++)
    {
      one=money_data&0x01;
      if(one)
        money+=1; //
      money_data>>=1;         //����1
    }
  }
  money_data=carddata[11];
   if(money_data)
  {   
    for(i=0;i<8;i++)
    {
      one=money_data&0x01;
      if(one)
        money+=8; //
      money_data>>=1;         //����1
    }
  }
  
  money_data=carddata[10];
   if(money_data)
  {   
    for(i=0;i<8;i++)
    {
      one=money_data&0x01;
      if(one)
        money+=64; //
      money_data>>=1;         //����1
    }
  }
  
   money_data=carddata[9];
   if(money_data)
  {   
    for(i=0;i<8;i++)
    {
      one=money_data&0x01;
      if(one)
        money+=512; //
      money_data>>=1;         //����1
    }
  }
  
//  money_data=carddata[8]&0x1f;
//   if(money_data)
//  {   
//    for(i=0;i<5;i++)
//    {
//      one=money_data&0x01;
//      if(one)
//        money+=4096; //
//      money_data>>=1;         //����1
//    }
//  }

//   money=money*100;//ת��
   money=money*10;//ת��
    //��ԭ��
  TCardInfor.money[0]=(money>>24)&0xff;      //��ԭ�huangfeng  ��ʵ����ֽ�һ��Ϊ0��
  TCardInfor.money[1]=(money>>16)&0xff;
  TCardInfor.money[2]=(money>>8)&0xff;
  TCardInfor.money[3]=money&0xff;	
  
//  Display_money(0,10,money);
//  delayms(20);
 //1�����Ľ��-----------------end-----------------
  
  
}


/*1��������--------------------end------------------------------*/


/*2��д����--------------------start------------------------------*/
void BIT_write0(void)  //λд0����
{
  delayus1();    //time_1
  IC_RST_H;
  delayus2();    //time_2
  delayus2();    //time_2
  delayus2();    //time_2
  IC_RST_L;
  delayus1();    //time_1
  IC_CLK_H;
  delayms(40*80);    //time_3 //ע��
  IC_CLK_L;
}


u8 write_card(uchar a,uchar b)  //aΪ��Ҫд0���ֽڣ�bΪ��Ҫд0��λ
{
  uchar wc_i;
//  uchar wc_q;			   /*(����)д0����֮ǰ��ȷ��*/
  uchar f,read_data;
  uchar wc_NG=0; 
  
  rst_card();   //����λ

  for(wc_i = 0; wc_i < 13; wc_i++)
  {    
    read_data=0x00;  /*(����)д0����֮ǰ��ȷ��*/
    for(f = 0; f < 8; f++)
    { 
   /*(����)д0����֮ǰ��ȷ��*/
  if(wc_i==a && f==b-1 && wc_NG==0)
  {   
    if(wc_i !=8 && read_data != 0x00 )              //������ֽ�����жϵ�ǰ��ֵ�Ƿ�Ϊ0x00
    {wc_NG=1; return 1;}    
    if(IC_DATA_read==0)   
    {
      wc_NG=1; 
      return 1;
    }
    if(wc_NG==0)      
    {
      BIT_write0();  //λд0����
      a=a+1;
      b=1;
      if(wc_i!=12)
      {
        BIT_write0();  //λд0����
      }
      delayus1();    //time_1
    } 
  } 
      //      IC_DATA=1;
      read_data <<= 1;
      if(IC_DATA_read)
      {read_data|=0x01;}
      IC_CLK_H;
      delayus2();    //time_2
      IC_CLK_L;
      delayus1();    //time_1     
    }          
    carddata[wc_i]=read_data; //����һ���ֽ�����
    
  }
  return 0;
}

/*2��д����--------------------end------------------------------*/

/*3���۷�-------------------------------------------------*/
//���ݱȽ�
u8 card_new(void)   //bijiao_data1
{  
  uchar i;
  for(i=0;i<13;i++)
  { 
    if(carddata[i] != newcarddata[i])
    {return 1;} 
  }
  return 0;
}

u8 old_new(void)
{  
  uchar i;
  for(i=0;i<13;i++)
  { 
    if(oldcarddata[i] != newcarddata[i])
    {return 1;} 
  }
  return 0;  
}
//������һλ
uchar jisuan(uchar a)
{    
  uchar b;
  if     (a>0x7F){b=1;}
  else if(a>0x3F){b=2;}
  else if(a>0x1F){b=3;}
  else if(a>0x0F){b=4;}
  else if(a>0x07){b=5;}
  else if(a>0x03){b=6;}
  else if(a>0x01){b=7;}
  else           {b=8;}
  return b;
}
//�۷�
u8 koufei(void)
{
   uchar a;
   uchar z_i,z_j,ab_k,z_a,k,z_x,z_y;  //jΪ��Ҫ��λ(д0)���ֽ�
   u8 wcard_OK; //д���ɹ���־
   
   /*�ж���û��Ǯ---------------------start----------*/
//   a=oldcarddata[8]&0x1f;   
//  
//  if((a!=0)||(oldcarddata[9]!=0)||(oldcarddata[10]!=0)||(oldcarddata[11]!=0)
//	||(oldcarddata[12]!=0));//��Ǯ	
  if((oldcarddata[9]!=0)||(oldcarddata[10]!=0)||(oldcarddata[11]!=0)
	||(oldcarddata[12]!=0));//��Ǯ	
   else
   {return 2; } //ûǮ   
   /*�ж���û��Ǯ---------------------end----------*/
   
   //��Ǯ----------------------------- 
     if(oldcarddata[12]==0)
     {
       if(oldcarddata[11]==0)
       {
         if(oldcarddata[10]==0)
         {
           if(oldcarddata[9]==0)
           {
             z_j=8;
             z_i=oldcarddata[8]&0x1f;
           }//oldcarddata[9]==0-------end----------------
           else
           {
             z_j=9;
             z_i=oldcarddata[9];      
           }
         }//oldcarddata[10]==0-------end----------------
         else
         {
           z_j=10;
           z_i=oldcarddata[10];
         }  
       }//oldcarddata[11]==0-------end----------------
       else
       {
         z_j=11;
         z_i=oldcarddata[11];
       }               
     }
    //oldcarddata[12]==0-------end----------------
     
    //oldcarddata[12]==1-------start---------------- 
     else
     {
       z_j=12;
       z_i=oldcarddata[12];
     }
   //oldcarddata[12]==1-------end----------------
     
     ab_k=z_i;
     z_i=jisuan(ab_k);  //�������Ҫ��λ(д0)�ֽڵ�λ
    
     //����۷Ѻ��µ������Ƕ���--------
     if     (z_i==1){
       z_a=newcarddata[z_j]-0x80;
       newcarddata[z_j]=z_a;
     }
     else if(z_i==2){
       z_a=newcarddata[z_j]-0x40;
       newcarddata[z_j]=z_a;
     }
     else if(z_i==3){
       z_a=newcarddata[z_j]-0x20;
       newcarddata[z_j]=z_a;
     }
     else if(z_i==4){
       z_a=newcarddata[z_j]-0x10;
       newcarddata[z_j]=z_a;
     }
     else if(z_i==5){
       z_a=newcarddata[z_j]-0x08;
       newcarddata[z_j]=z_a;
     }
     else if(z_i==6){
       z_a=newcarddata[z_j]-0x04;
       newcarddata[z_j]=z_a;
     }
     else if(z_i==7){
       z_a=newcarddata[z_j]-0x02;
       newcarddata[z_j]=z_a;
     }
     else          {
       z_a=newcarddata[z_j]-0x01;
       newcarddata[z_j]=z_a;
     }
     /*--------------------------*/
     if(z_j!=12)
     {
       for(k = z_j+1; k<13; k++)
       {newcarddata[k]=0x7F;}       
     }
     //		  display_datanew();//���ݷ��ͳ���
     /*----�۷Ѳ�����������������---*/
     z_x=z_j;  
     z_y=z_i;
     
     wcard_OK=write_card(z_x,z_y);  //д������ 
     return wcard_OK;
//     if(wcard_OK==0)
//     {     
//       //�Ƚ�д����ֵ�Ƿ��Ԥ��ֵ���
//       if(card_new()==0) //���
//       { 
//         //       PrintASCII(10,0,"OK"); 
//         return 0;
//       }  //��Ǯ�ɹ�
//       else
//       {
//         //       PrintASCII(10,0,"fail");
//         return 2; 
//       } //��Ǯʧ��
//     }
//     else
//     {
//       //       PrintASCII(10,0,"NG");
//       return 1; 
//     } 
      
   //��Ǯ---------------end--------------   
}   



/*huangfeng ����*/
void init_contactcard(void)
{
//  Contact_Power_OFF;
  Contact_Power_ON;
  IC_RST_L;
  IC_CLK_L;
  IC_PGM_L;
  IC_ECLK_L;
}

/*�ж��ǲ����ܲ�ͨ��E9 30 73 75  25 8E 0E  64  00 00 00 00 00*/
//1102644-91563057   0978893-91563057         0009915-E8280657
//E8313F  E82806  915630  ���ϴ���57
unsigned char jd_zhoubotong(void)
{ 
if(
	(TCardInfor.head[0]==0xE9)&&
	(TCardInfor.head[1]==0x30)&&
	(TCardInfor.head[2]==0x73)&&
	(TCardInfor.head[3]==0x75))
	{
	return 0;
//	return 1;
	}
else if(
	(TCardInfor.head[0]==0x91)&&
	(TCardInfor.head[1]==0x56)&&
	(TCardInfor.head[2]==0x30)&&
	(TCardInfor.head[3]==0x57))
	{
	return 1;
	}
else if(
	(TCardInfor.head[0]==0xE8)&&
	(TCardInfor.head[1]==0x28)&&
	(TCardInfor.head[2]==0x06)&&
	(TCardInfor.head[3]==0x57))
	{
	return 1;
	}
else if(
	(TCardInfor.head[0]==0xE8)&&
	(TCardInfor.head[1]==0x31)&&
	(TCardInfor.head[2]==0x3F)&&
	(TCardInfor.head[3]==0x57))//E8313F
	{
	return 1;
	}
else
	return 0;	 //���ܲ�ͨ��
}

//�ж�ͬһ�ſ�
unsigned char jd_sameCCard(void)
{ 
if((TCardInfor.cardNO[1]!=carddata[4])||(TCardInfor.cardNO[2]!=carddata[5])||(TCardInfor.cardNO[3]!=carddata[6]))
{return 0;}
else
return 1;	 //ͬһ�ſ�
}

/*��д��һ�β忨����Ϣ----------start-------------------
void ReadFCardInf(void)  //����Ϣ
{
  u8 buffer[6];
  
 // I2C_ReadS_24C(FirstCardAddr,buffer,6);   //������  
  
  FCardInfor.type=buffer[0];	
  FCardInfor.cardNO[0]=buffer[1];
  FCardInfor.cardNO[1]=buffer[2];
  FCardInfor.cardNO[2]=buffer[3];
  FCardInfor.cardNO[3]=buffer[4];
  FCardInfor.space=buffer[5]; 
  
}*/

//void WriteFCardInf(u8 type)  //д��Ϣ
//{
//  u8 buffer[6];
//  
//  if(type==NO_CONTACTPAY) //mifare��
//  { 
//    
//    buffer[0]=NO_CONTACTPAY;//������
//    buffer[1]=CardInfor.cardNO[0];//����
//    buffer[2]=CardInfor.cardNO[1];//
//    buffer[3]=CardInfor.cardNO[2];//
//    buffer[4]=CardInfor.cardNO[3];//
//    buffer[5]=space_HEX;//
//  }
//  else if(type==CONTACTPAY) //�ܲ�ͨ��
//  {
//    buffer[0]=CONTACTPAY;//������
//    buffer[1]=TCardInfor.cardNO[0];//����
//    buffer[2]=TCardInfor.cardNO[1];//
//    buffer[3]=TCardInfor.cardNO[2];//
//    buffer[4]=TCardInfor.cardNO[3];//
//    buffer[5]=space_HEX;//
//  }  
//  else //���
//  {
//    buffer[0]=0;//������
//    buffer[1]=0;//����
//    buffer[2]=0;//
//    buffer[3]=0;//
//    buffer[4]=0;//
//    buffer[5]=0;//    
//  }   
//  I2C_WriteS_24C(FirstCardAddr,buffer,6);   //д����    
//}
/*��д��һ�β忨����Ϣ----------end-------------------*/

u8 CpuCard_Pay(u8 space,u8 IQFlag,CardInfo *WZT)
{
u8 cflag=0,i,flag=0,car,addf,nrtime,swng=1,swok=1,mnyerr=0,cardpno[8];
u8 success=0,mbno[4],endtime[5],intime[5],iccardno[4],buffer[50],mnybuf[4];
u16 parkfee_time,parkalltime;
u32 ymoney,oldymoney,submny,cpufmny,ngmny=0,ngtime;//  //��� 
u32 maxtimeout,feetime,feetimereal,feetimeold,feetimeall,feemny; 
s32 equ;
Rate_reference_ST RR_STtmp;
carStation_reference_of_used spacest;
CardInfo YWCardInfo;
SubMoneyCMD YWTFEE;
PosRecordInfo YWTFEER;  
//  inquire_card_record(1,buffer);
//  inquire_card_record(2,buffer);

  I2C_ReadS_24C(CardNo1_CPU+(space-1)*16,cardpno,8);
  for(i=0;i<8;i++)
  	cardpno[i] = WZT->YYXLH[i];
  
  
  ymoney=hcl(WZT->Balance,4);//�ϲ�
  flag = WZT->QYBS;
  if(flag!=0x02)
	  {
	  TMP.cardmny = ymoney;
	  memcpy(TMP.cardno,cardpno+4,4);	
	  if(flag==0x01)
	  	{
	  	disp_YWT_IMG(0xE0);//��ʾ��δ����
	  	}
	  else if(flag==0x03)
	  	{
	  	disp_YWT_IMG(0xE1);//��ʾ����ͣ��
	  	}
	  else if(flag==0x04)
	  	{
	  	disp_YWT_IMG(0xE2);//��ʾ��������
	  	}
	  else //if(flag==0x01)
	  	{
	  	disp_YWT_IMG(0xE5);//��ʾ��Ч��
	  	}
	  return 1;
	  }
  if((WZT->YYQYRQ[1] > time[4])||
	 ((WZT->YYQYRQ[1] == time[4])
	 &&(WZT->YYQYRQ[2] > time[3]))||
	 ((WZT->YYQYRQ[1] == time[4])
	 &&(WZT->YYQYRQ[2] == time[3])
	 &&(WZT->YYQYRQ[3] > time[2])))
	  {
	  TMP.cardmny = ymoney;
	  memcpy(TMP.cardno,cardpno+4,4);	
	  disp_YWT_IMG(0xE3);//��ʾ��δ����
	  return 1;
	  }
  if((WZT->YYYXRQ[1] < time[4])||
	 ((WZT->YYYXRQ[1] == time[4])
	 &&(WZT->YYYXRQ[2] < time[3]))||
	 ((WZT->YYYXRQ[1] == time[4])
	 &&(WZT->YYYXRQ[2] == time[3])
	 &&(WZT->YYYXRQ[3] < time[2])))
	  {
	  TMP.cardmny = ymoney;
	  memcpy(TMP.cardno,cardpno+4,4);	
	  disp_YWT_IMG(0xE4);//��ʾ���ѹ���
	  return 1;
	  }

  TMP.pktime = 0;
  get_rate_ref(&RR_STtmp);
  I2C_ReadS_24C(mibiao_number,mbno,3);
  car = space;
  if(IQFlag==0x88) 
  	TMP.cpc = Disp_CPUBS;//IC����ʱ��ʾ 2016-03-09
  else
	TMP.cpc = Disp_CPU;//CPU����ʾ 2016-03-09  
  Contact_Power_OFF;									  
//  cflag = inquire_card(&YWCardInfo);//��� ��������
  i=10;
  read_car_reference_of_use_info(&spacest,car);  
  if((spacest.car_stop_way[0] == 0x66)&&(IQFlag==IQ_NO))//��ʱ
  	{
	flag = PreBuyDisp_A1;
	cflag = 0;
	feetimeold = spacest.max_stopTime_hour[0]*60+spacest.max_stopTime_min[0];
	feetimeall = spacest.smartCard_SNR[1]*60+spacest.smartCard_SNR[2];
	if(feetimeold>=feetimeall)
		{
		flag = PreBuyDisp_A2;
		cflag = 1;
		}
#ifndef PreBuy_Add
	cflag = 1;
#endif
	if(cflag == 1)
		{
		//spacest.smartCard_SNR[0]//Ԥ���־PreBuyflag
		feetimeold= ret_max_24hour(spacest.start_stopTime,PARK_CARD);//ʵ�ʲ���ʱ��
		feetimeall = spacest.max_stopTime_hour[0]*60+spacest.max_stopTime_min[0];
		feetimeall -= feetimeold;
		lcd_clear();
	    #ifdef CAR
		display_prebuy_menu(spacest.smartCard_SNR+4,car-1,0,feetimeall,0,feetimeold,flag);	
	    #else
		display_prebuy_menu(spacest.smartCard_SNR+4,car,car,feetimeall,0,feetimeold,flag);	
	    #endif
		Contact_Power_OFF; 
		key_flag = 0;
		maxtimeout = KEYTIMEOUT_1S * 2; 										   
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
		while(maxtimeout--)
		  { 
		  if(key_flag)
			  {   
			  key_flag = 0;
			  return 0;
			  }  
		  }
		return PreBuyDisp_A0;
		}
	
	addf =1;
	time[3] = spacest.start_stopTime[0];//��
	time[2] = spacest.start_stopTime[1];//��
	time[1] = spacest.start_stopTime[2];//ʱ
	time[0] = spacest.start_stopTime[3];//��
	time[4] = spacest.start_stopTime[4];//��
	for(i=0;i<6;i++)
		 time1[i] = BCDtoHex(time[i]);
	math_time(feetimeold,endtime);
	for(i=0;i<5;i++)
		time[i] = HEX_to_BCD(endtime[i]);
	for(i=0;i<5;i++)
		time1[i] = endtime[i];//������ʱ��
//    parkalltime = ret_max_24hour(spacest.start_stopTime,PARK_CARD);//ʵ�ʲ���ʱ��
	parkfee_time = parkfeetime_count(spacest.start_stopTime+2,endtime);//�շѲ���ʱ��
	if(parkfee_time>=60)
//	if(feetimeold>=60)
		TMP.feemny = RR_STtmp.f2*RR_STtmp.Sale_Base;
	else
		TMP.feemny = RR_STtmp.f1*RR_STtmp.Sale_Base;
  	}
  else
  	{
	feetimeold =0;
  	addf =0;
	feetimeall = momery_to_time(100000);	
  	TMP.feemny = RR_STtmp.f1*RR_STtmp.Sale_Base;
  	}
  
  car = space; 
  //����
  ymoney=hcl(WZT->Balance,4);//�ϲ�
  if(ymoney>100000) // Ǯ����100Ԫ ����
  	{
	Contact_Power_OFF; 
	Buzz_0;
	delay(KEYTIMEOUT_1S/10);
	Buzz_1;
	write_card_error(0);
	delay(KEYTIMEOUT_1S * 3);
    return 3; //IC�����ϣ�����ϵ����Ա
    } 
  for(i=0;i<4;i++)
  	iccardno[i] = WZT->snr[i];

//  RR_STtmp.Max_Park_Time
//  if(feetimeold>=60)	
//	  TMP.feemny = RR_STtmp.f2*RR_STtmp.Sale_Base;
//  else
  TMP.feetime = RR_STtmp.Tb;
//  TMP.feemny = 200;//RR_STtmp.f1*RR_STtmp.Sale_Base;
//  TMP.feetime = 30;//RR_STtmp.Tb;

//�������ж�˳�� ����--����--ȫ��
	memset(WZT->YYXLH,0,4);  
	memcpy(WZT->YYXLH+4,WZT->snr,4);  
	equ = SelectList_SRAM(WZT->YYXLH,ListType_CPCDEL,buffer);
	if(equ<0)
		{//���ڼ�����
		equ = SelectList_SRAM(WZT->YYXLH,ListType_CPCADD,buffer);
		if(equ<0)
			{//����������
			equ = SelectList_SRAM(WZT->YYXLH,ListType_CPCALL,buffer);
			}
		if(equ>=0)
			{
			TMP.cardmny = ymoney;
//			memcpy(TMP.cardno,WZT->snr,4);
			memcpy(TMP.cardno,cardpno+4,4);			
  //		disp_YWT_IMG(11);//��ʾ��������
			disp_YWT_IMG(0xC1);//��ʾ��������
			return 1;
			}
		}

  if(IQFlag==IQ_YES)
  	{  	
  	display_prebuy_menu(cardpno+4,ymoney,0,0,0,0,PreBuyDisp_B1);	
	delay(KEYTIMEOUT_1S * 1);
	key_flag =0;
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	maxtimeout = KEYTIMEOUT_1S * 3;
	while(maxtimeout--)
	   {   
	   if(key_flag||(maxtimeout==1))break;	
	   }	
	return 4;	
  	}  
  feetime = 0;
  feemny = 0;
  I2C_ReadS_24C(PreBuy_NGBuff1+(car-1)*16,buffer,16);
  //buffer-0������� 1-4��� 5-8���� 9-13ʱ�� 14-15����ʱ��
  memcpy(endtime,time1,5);
  memcpy(intime,time,5);
  ngtime = ret_max_24hour(buffer+9,PARK_CARD);//ʵ�ʲ���ʱ��
  memcpy(time1,endtime,5);
  memcpy(time,intime,5);
  if(ngtime>10)//ֻ����5����
 	 {
	 memset(buffer,0,16);//��������־2016-04-12
	 I2C_WriteS_24C(PreBuy_NGBuff1+(car-1)*16,buffer,16);
	 }
  for(i=0;i<4;i++)
  	{
	if(iccardno[i]!=buffer[i+5])
		break;
  	}
  if((buffer[0]>0)&&(i==4))//
  	{
	ngmny=hcl(buffer+1,4);//�ϲ�	
	if(ymoney<ngmny)
		{
		success = 1;
		if(ymoney<TMP.feemny)
			mnyerr =1;
		ymoney = ngmny;
		submny = ngmny;
		feemny = TMP.feemny;		
		}
  	}


  if((ymoney<TMP.feemny)&&(success==0))
  	{
	display_prebuy_menu(cardpno+4,ymoney,0,0,0,0,PreBuyDisp_0);	
	delay(KEYTIMEOUT_1S * 1);
	key_flag = 0;
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	maxtimeout = CPUCARD_OUTTIME;
	while(maxtimeout--)
	   {   
	   if(key_flag||(maxtimeout==1))break;	
	   }	
	return 4;
  	}
  if(spacest.car_stop_way[0] == 0x66)
	display_prebuy_menu(cardpno+4,ymoney,0,0,0,0,PreBuyDisp_B2);
  else
  	display_prebuy_menu(cardpno+4,ymoney,0,0,0,0,PreBuyDisp_1);	
	  
  if(TMP.PSAM!=0)
  	{
	key_flag = 0;
	maxtimeout = KEYTIMEOUT_1S * 3;
	while(maxtimeout--)
	   {   
	   if(key_flag||(maxtimeout==1))break;	
	   }	
	return 5;
  	}
  
  key_flag = 0;
  /* ι��*/
  IWDG_ReloadCounter();//2015-12-23 andyluo
//  maxtimeout = KEYTIMEOUT_1S * 3;											 
  maxtimeout = CPUCARD_OUTTIME;											 
  nrtime = 0;
  while(maxtimeout--)
  	{ 
	IWDG_ReloadCounter();//2015-12-23 andyluo
	if(key_flag)
		{	
		key_flag = 0;
		return 0;
		} 	
//	if(IC_SWITCH_read==NOZBTCARD)
//		break;	
	cflag = inquire_card(&YWCardInfo);//��� ��������
	if(cflag==CardType_E5)
		nrtime++;
	if(nrtime>10)break;
			
	if(maxtimeout==1)
		{
		return 0;
		}
	}
  oldymoney = ymoney;//�������
  maxtimeout = CPUCARD_OUTTIME;											 
  /* ι��*/
  IWDG_ReloadCounter();//2015-12-23 andyluo
  key_flag = 0;
  while(maxtimeout--)
  	{	
	IWDG_ReloadCounter();//2015-12-23 andyluo
	if(key_flag)break;	
//	if(IC_SWITCH_read==NOZBTCARD)continue;
	cflag = inquire_card(&YWCardInfo);//��� ��������
	if(cflag!=CardType_CPU)continue;
		
	if(maxtimeout==1)//��ʱ�˳�
		{
		return 0;	
		}
	flag = 1;
	for(i=0;i<4;i++)
		{
	  	if(iccardno[i] != YWCardInfo.snr[i])
			{
			flag = 0;
			break;
	  		}			
		}	
//	flag = jd_sameCCard();
	if(flag == 0)
		{
		display_prebuy_menu(cardpno+4,ymoney,0,0,0,0,PreBuyDisp_4);   
//		maxtimeout = KEYTIMEOUT_1S * WAITE_TIME;
		continue;
		}
	if(mnyerr==0)
		ymoney=hcl(YWCardInfo.Balance,4);//�ϲ�
	else
		{
		feemny = TMP.feemny;		
		if(ngmny)
			submny = ymoney;
		}

	if((mnyerr==0)&&(success ==1)&&(ymoney<TMP.feemny)||(ymoney==0))//����
		{//�ѿ۷�δ�볡-�ѿ۷ѳɹ�-����
		flag = feemny;
		display_prebuy_menu(cardpno+4,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_5);  
//		delay(KEYTIMEOUT_1S*2);
		break;
		}
	if((TMP.cpc == Disp_CPUBS)&&(feetime>=60))
		{
		TMP.feemny = RR_STtmp.f2*RR_STtmp.Sale_Base;
		}
		
	display_prebuy_menu(cardpno+4,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_6);  
	if((success==0)&&(swok ==1))
		{
		if(oldymoney>feemny)
			feemny += TMP.feemny;
//		feetime += TMP.feetime;
		if(oldymoney>=feemny)
			submny = oldymoney - feemny;//�۷Ѻ���
		else
			{
			feemny -= TMP.feemny;
			display_prebuy_menu(cardpno+4,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_5);  
//			delay(KEYTIMEOUT_1S*2);
			break;
			}
		}
//	feetime = momery_to_time(feemny);
	flag =1;//KEYTIMEOUT_1S * 3;
	while(flag--)
		{		
//		cflag = inquire_card(&YWCardInfo);//��� ��������
//		if(cflag!=CardType_CPU)continue;
//		if(IC_SWITCH_read==NOZBTCARD)break;
		if(ymoney>submny)
			cpufmny = ymoney - submny;
		else
			cpufmny = 0;

//		fll(TMP.feemny,mnybuf,4);
		fll(cpufmny,mnybuf,4);
		YWTFEE.TradeDateTime[0] = 0x20;
		for(i=0;i<5;i++)
			YWTFEE.TradeDateTime[i+1] = time[4-i];
		YWTFEE.TradeDateTime[6] = 0x00;
		memcpy(YWTFEE.QBalance,YWCardInfo.Balance,4);
		memcpy(YWTFEE.Pays,mnybuf,4);
		//YWTFEE.ParkInfo
		YWTFEE.YWParkInfo.CardType = 0x60;
		YWTFEE.YWParkInfo.ParkFlag = 0x02;
		for(i=0;i<4;i++)
			YWTFEE.YWParkInfo.ParkDateTime[i] = time[3-i];//��//��//ʱ//��
		YWTFEE.YWParkInfo.UpdateFlag = 0x88;	
		YWTFEE.YWParkInfo.DongjieMoney[0] = 0x00;
		YWTFEE.YWParkInfo.DongjieMoney[1] = 0x00;//RR_ST1.Max_Stop_Momery;

		math_time(feetime-30,endtime);
		YWTFEE.YWParkInfo.Res[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.Res[i+1] = HEX_to_BCD(endtime[4-i]);//��//��//ʱ//��
		YWTFEE.YWParkInfo.Res[6]= 0x00;
			
		memset(YWTFEE.YWParkInfo.FEEMNY,0,3);//�����۷ѳ��� 	
		memcpy(YWTFEE.YWParkInfo.ParkMBNO,mbno,3);
		YWTFEE.YWParkInfo.ParkMBNO[3] = car+CAR_CLASS;
		
		math_time(feetime,endtime);
		YWTFEE.YWParkInfo.ParkInOutTime[0]= 0x20;
		for(i=0;i<5;i++)
			YWTFEE.YWParkInfo.ParkInOutTime[i+1] = HEX_to_BCD(endtime[4-i]);//��//��//ʱ//��
		YWTFEE.YWParkInfo.ParkInOutTime[6]= 0x00;		
		
		YWTFEE.CardType = YWCardInfo.CardType;
		memcpy(YWTFEE.YYXLH,YWCardInfo.YYXLH,8);
		
//�����쳣�ж� 2016-03-14
//		success = 0;
		I2C_ReadS_24C(PreBuy_NGBuff1+(car-1)*16,buffer,16);
		if(buffer[0]>0)
			{
			cflag = 1;
			for(i=0;i<4;i++)
				{
				if(buffer[5+i]!=iccardno[i])
					{
					cflag = 0;
					buffer[0] =0;
					break;
					}
				}
			if(cflag)
				{
				memcpy(endtime,time1,5);
				memcpy(intime,time,5);
				ngtime = ret_max_24hour(buffer+9,PARK_CARD);//ʵ�ʲ���ʱ��
				memcpy(time1,endtime,5);
				memcpy(time,intime,5);
				if(ngtime>10)//ֻ����5����
					buffer[0]=0;
				else
					{
					ngmny=hcl(buffer+1,4);//�ϲ�			
					if(ngmny>(submny+TMP.feemny))
						success = 1;
					}
				}
			}
		YWTFEE.POS[0] = 0xb2;
		if(success==0)
//�����쳣�ж� 2016-03-14
			success = YWT_FEE_PRO(&YWTFEE,&YWTFEER);//�۷ѳ���
		for(i=1;i<1;i++)
			{
			cflag = inquire_card(&YWCardInfo);//��� ��������
			inquire_card_record(&i,buffer);
			}
		if(success==0xb9)
			{
			maxtimeout = CPUCARD_OUTTIME;
			while(maxtimeout--)
			   {   
			   if(key_flag||(maxtimeout==1))break;				   
			   cflag = inquire_card(&YWCardInfo);//��� ��������
			   if(cflag==CardType_CPU)
			   		{
					YWTFEE.POS[0] = 0xb9;
					success = YWT_FEE_PRO(&YWTFEE,&YWTFEER);//�۷ѳ���
					if(success!=1)//continue;	
						{
						YWTFEE.POS[0] = 0xb9;
						success = YWT_FEE_PRO(&YWTFEE,&YWTFEER);//�۷ѳ���
						}
					break;
					}				
				}
			success =1;			
			}
		if(success==1)//�ۿ�ɹ�2016-03-09
			{
			swok =1;
			swng =0;
			//memcpy(buffer+1,YWCardInfo.Balance,4);
			fll(oldymoney-feemny,buffer+1,4);
//			fll(ymoney-feemny,buffer+1,4);
			if(ngmny)
				submny = ymoney;
			else
				ymoney = submny;
			if(buffer[0]>1)
				buffer[0]++;
			memset(buffer,0,16);//��������־2016-04-12
			I2C_WriteS_24C(PreBuy_NGBuff1+(car-1)*16,buffer,16);
			ngmny = 0;
			break;
			}	
		else//�ۿ�ʧ�ܵ������ 2016-03-14
			{//��־-����-���-ʱ��--��λ
			swok =0;
			if(buffer[0]==0)
				{
				buffer[0]= 1;
				memcpy(buffer+1,YWCardInfo.Balance,4);
				memcpy(buffer+5,iccardno,4);//��������	
				buffer[9] = time[3]; //��									   
				buffer[10] = time[2]; //��										
				buffer[11] = time[1]; //ʱ										 
				buffer[12] = time[0]; //��										 
				buffer[13] = time[4];//0x00; //�� Ԥ��										 
				buffer[14] = feetime / 60; //����ͣ��ʱ�� 24Сʱ									  
				buffer[15] = feetime % 60;	
				I2C_WriteS_24C(PreBuy_NGBuff1+(car-1)*16,buffer,16);
				}
			success =0;
			}		
		}		
	if(ymoney>submny)//�ۿ�δ���
		{
		display_prebuy_menu(cardpno+4,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_7);  
		key_flag = 0;
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
		maxtimeout = CPUCARD_OUTTIME;
		while(maxtimeout--)
		   {   
		   if(key_flag||(maxtimeout==1))break;	
		   
		   cflag = inquire_card(&YWCardInfo);//��� ��������
		   if(cflag==CardType_CPU)continue;
//		   if(IC_SWITCH_read==YESZBTCARD)continue;//�ٴβ忨
		   else break;
		   maxtimeout = CPUCARD_OUTTIME;
		   /* ι��*/
		   IWDG_ReloadCounter();//2015-12-23 andyluo
		   }	
		if(key_flag||(maxtimeout==1))break;  
		maxtimeout = CPUCARD_OUTTIME;
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
		delay(KEYTIMEOUT_1S/10);
		continue;
		}
	success = 0;
	display_prebuy_menu(cardpno+4,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_8);  
	if(IQFlag!=0x88)
		light(car,OK);
	Buzz_0; 	
	delay(KEYTIMEOUT_1S/10); 
	Buzz_1; 
	swok =1;
	swng =0;
	memset(buffer,0,16);
	I2C_WriteS_24C(PreBuy_NGBuff1+(car-1)*16,buffer,16);
	ngmny = 0;
	feetime = momery_to_time_WZ(feemny);
	//4. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ��������ͣ��ʱ�䣩
	buffer[0] = 0x66; //��λ״̬
	buffer[1] = PreBuyflag; //Ԥ���־
	buffer[2] = feetimeall/60; //Ԥ����ʱ��
	buffer[3] = feetimeall%60; //Ԥ����ʱ��
	buffer[4] = 0x00; //��������
	buffer[5] = iccardno[0]; //��������
	buffer[6] = iccardno[1];
	buffer[7] = iccardno[2];
	buffer[8] = iccardno[3];

	if(addf==1)
		{
		for(i=0;i<5;i++)
			buffer[9+i] = spacest.start_stopTime[i];
		
		buffer[14] = (feetime+feetimeold) / 60; //����ͣ��ʱ�� 24Сʱ
		buffer[15] = (feetime+feetimeold) % 60;		 
		}		
	else
		{
		buffer[9] = time[3]; //��
		buffer[10] = time[2]; //��
		buffer[11] = time[1]; //ʱ
		buffer[12] = time[0]; //��
		buffer[13] = time[4]; //�� Ԥ��	 

		buffer[14] = feetime / 60; //����ͣ��ʱ�� 24Сʱ
		buffer[15] = feetime % 60; 		
		}	
	if(IQFlag!=0x88)
		{
		write_car_reference_of_use_info(space,buffer,16);
//		parkalltime = ret_max_24hour(spacest.start_stopTime,PARK_CARD);//ʵ�ʲ���ʱ��
		math_time(feetime,endtime);
		parkfee_time = parkfeetime_count(buffer+11,endtime);//�շѲ���ʱ��
		if(parkfee_time>=60)
			TMP.feemny = RR_STtmp.f2*RR_STtmp.Sale_Base;
		else
			TMP.feemny = RR_STtmp.f1*RR_STtmp.Sale_Base;
		}
//	feetimeaf = momery_to_time(feemny+TMP.feemny);
//	if(feetimeaf==feetime)
	if(addf == 1)
		feetimereal = feetime+feetimeold;
	else
		feetimereal = feetime;
	
	if(feetimereal >= feetimeall)
		{
		display_prebuy_menu(cardpno+4,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_9);
		break;
		}
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	maxtimeout = CPUCARD_OUTTIME;
	while(maxtimeout--)
	   {   
	   if(key_flag||(maxtimeout==1))break;  
	   cflag = inquire_card(&YWCardInfo);//��� ��������
	   if(cflag==CardType_CPU)continue;
//	   if(IC_SWITCH_read==YESZBTCARD)continue;//�ٴβ忨
	   else break;
	   }	
	if(maxtimeout==1)break;  
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	maxtimeout = CPUCARD_OUTTIME;
	delay(KEYTIMEOUT_1S/10);
	cflag = inquire_card(&YWCardInfo);//��� ��������
	if(cflag!=CardType_CPU)
//	if(IC_SWITCH_read==NOZBTCARD)
		display_prebuy_menu(cardpno+4,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_12);
	}
  Contact_Power_OFF; 
  key_flag = 0;
  if(feetime==0)return 0;
  if(swng==1)return 0;
  if(swok==0)
  	{
	feemny -= TMP.feemny;//ʵ�ʿ��ܿۿ� ����ʱ��δ���ӵ���� 2016-04-15
  	}
//  feetime = momery_to_time_WZ(feemny);
  I2C_ReadS_24C(PreBuy_NGBuff1+(car-1)*16,buffer,16);
  ngmny=hcl(buffer+1,4);//�ϲ�	  
  ngtime = buffer[0];
  //2. ��ͣ����¼
  buffer[0] = 0xEE;//��¼ͷ		
  buffer[1] = 0x00; //��������	   
  buffer[2] = ngtime;	  
  buffer[3] = ngmny>>8;	 
  buffer[4] = ngmny;		
  buffer[5] = iccardno[0]; //��������
  buffer[6] = iccardno[1];
  buffer[7] = iccardno[2];
  buffer[8] = iccardno[3];
  for(i=0;i<5;i++)
	  buffer[9+i] = time[4-i];//������ʱ��
  buffer[14] = oldymoney>>16;  
  buffer[15] = oldymoney>>8;  
  buffer[16] = oldymoney;   
  buffer[17] = feemny>>8;
  buffer[18] = feemny; 
  if(IQFlag==0x88)
  	buffer[19] = ((car+CAR_CLASS)<<4) + 0x0E;//��һ��ͣ�� ��λΪcar										  
  else if(addf ==1)
  	buffer[19] = ((car+CAR_CLASS)<<4) + PreBuyAddRecord;//��һ��ͣ�� ��λΪcar											
  else
  	buffer[19] = ((car+CAR_CLASS)<<4) + PreBuyRecord;//��һ��ͣ�� ��λΪcar											  

  if(IQFlag!=0x88)
  	I2C_WriteS_24C(CardNo1_CPU+(space-1)*16,cardpno,8);
  bushimny[car] = 0;   
  bukanmny[car] = 0;  
  TMP.CPC_ckmny[car] = 0;
//  if(swok ==0)
//	  feetime = momery_to_time(feemny-TMP.feemny);
  math_time(feetime,endtime);
  for(i=0;i<5;i++)
	  buffer[20+i] = HEX_to_BCD(endtime[4-i]);//������ʱ��
  buffer[25] = CardType_CPU;//����ͨ��¼��־
  for(i=26;i<32;i++)   
	  buffer[i] = 0xAA;
  Save_Record(buffer,32);
  WriteRecord(car,TMP.cardplace);
  Deal_SwipCardIMG(car-1,1);
  TMP.ckflag[car] = 0;  
  delay(KEYTIMEOUT_1S * 3);
  for(i=0;i<5;i++)
	  TMP.time[i] = HEX_to_BCD(endtime[i]);//������ʱ��
  lcd_clear();
  cflag = inquire_card(&YWCardInfo);//��� ��������
  if(cflag==CardType_CPU)
//  if(IC_SWITCH_read==YESZBTCARD)
  	display_prebuy_menu(cardpno+4,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_10);
  else
  	{
  	display_prebuy_menu(cardpno+4,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_11);
  	delay(KEYTIMEOUT_1S * 2);
  	}
  delay(KEYTIMEOUT_1S * 1);
  /* ι��*/
  IWDG_ReloadCounter();//2015-12-23 andyluo
  maxtimeout = CPUCARD_OUTTIME;//KEYTIMEOUT_1S * 6;
  while(maxtimeout--)
	 {	 
	 IWDG_ReloadCounter();//2015-12-23 andyluo
	 if(key_flag||(maxtimeout==1))break;  
	 cflag = inquire_card(&YWCardInfo);//��� ��������
	 if(cflag==CardType_CPU)
//	 if(IC_SWITCH_read==YESZBTCARD)
		continue;//��ο�
	 else break;
	 }	  
//  if(maxtimeout==1)break;  
  buffer[0] = 0x00;
  I2C_WriteS_24C(ResetCar1Flag + car - 1,buffer,1);				
  /* ι��*/
  IWDG_ReloadCounter();//2015-12-23 andyluo
  GetCurrentTime();
  delay(KEYTIMEOUT_1S * 1);
  return 0;
}


//1-ʧ�� 0-���� IQFlag-0x88 ��ʱ
/*---------------------�ܲ�ͨ������������---E9 30 73 75  25 8E 0E  64  00 00 00 00 00-----------*/
u8 ICCard_Pay(u8 space,u8 IQFlag)
{
  u8 j,flag=0,car,addf,cflag=0,ledf=0,swng=1,icswflag;
  u8 success=0,mnyerr=0,ngtime,swngtime=0,fng=1,scng=0;
  u8 endtime[5],intime[5],iccardno[4];
  u8 buffer[32];
  u16 parkfee_time,parkalltime;
  u32 i,ymoney,oldymoney,submny=0,bkdispmny,ngmny=0,rmny;//  //��� 
  u32 maxtimeout,cardno,feetime,feetimereal,feetimeold,feetimeall,feemny; 
  Rate_reference_ST RR_STtmp;
  carStation_reference_of_used spacest;
  TMP.pktime = 0;

//  Contact_Power_ON;
//  delayms(500); //500 
//  i=4;
//  
//  do
//  {
//    read_cpucard();
//    if((carddata[0]==0xff)||(carddata[0]==0))
//    {
//      i--;
//      if(i==1)
//      {
//        if((carddata[1]==carddata[0])||(carddata[1]==carddata[0]))
//        {
//          //�����������ϴ��о
//          Contact_Power_OFF; 
//          Buzz_0;
//          return 1;
//        }          
//      }
//      delayms(200);
//    }
//    else
//      break;
//    
//  }while(IC_SWITCH_read==YESZBTCARD);  
//  
//  makeup_cardinfor(); 


	get_rate_ref(&RR_STtmp);

//  if(IQFlag==0x88)
//  	TMP.rerun = 1;
//  else
//  	TMP.rerun = 0;
  TMP.PSAM=0;
  car = space;
  if(IQFlag==0x88) 
  	TMP.cpc = Disp_ICBS;//IC����ʱ��ʾ 2016-03-09
  else
  	TMP.cpc = Disp_IC;//IC����ʾ 2016-03-09
  i=10;
  read_car_reference_of_use_info(&spacest,car);  
  if((spacest.car_stop_way[0] == 0x66)&&(IQFlag==IQ_NO))//��ʱ
  	{
	flag = PreBuyDisp_A1;
	cflag = 0;
	feetimeold = spacest.max_stopTime_hour[0]*60+spacest.max_stopTime_min[0];
	feetimeall = spacest.smartCard_SNR[1]*60+spacest.smartCard_SNR[2];
	if(feetimeold>=feetimeall)
		{
		flag = PreBuyDisp_A2;
		cflag = 1;
		}
#ifndef PreBuy_Add
	cflag = 1;
#endif
	if(cflag == 1)
		{
		//spacest.smartCard_SNR[0]//Ԥ���־PreBuyflag
		feetimeold= ret_max_24hour(spacest.start_stopTime,PARK_CARD);//ʵ�ʲ���ʱ��
		feetimeall = spacest.max_stopTime_hour[0]*60+spacest.max_stopTime_min[0];
		feetimeall -= feetimeold;
		lcd_clear();
	    #ifdef CAR
		display_prebuy_menu(spacest.smartCard_SNR+4,car-1,0,feetimeall,0,feetimeold,flag);	
	    #else
		display_prebuy_menu(spacest.smartCard_SNR+4,car,car,feetimeall,0,feetimeold,flag);	
	    #endif
		Contact_Power_OFF; 
		key_flag = 0;
		maxtimeout = KEYTIMEOUT_1S * 2; 										   
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
		while(maxtimeout--)
		  { 
		  if(key_flag)
			  {   
			  key_flag = 0;
			  return 0;
			  }  
		  }
		return PreBuyDisp_A0;
		}
	
	addf =1;
	time[3] = spacest.start_stopTime[0];//��
	time[2] = spacest.start_stopTime[1];//��
	time[1] = spacest.start_stopTime[2];//ʱ
	time[0] = spacest.start_stopTime[3];//��
	time[4] = spacest.start_stopTime[4];//��
	for(i=0;i<6;i++)
		 time1[i] = BCDtoHex(time[i]);
	math_time(feetimeold,endtime);
	for(i=0;i<5;i++)
		time[i] = HEX_to_BCD(endtime[i]);
	for(i=0;i<5;i++)
		time1[i] = endtime[i];//������ʱ��
//	  parkalltime = ret_max_24hour(spacest.start_stopTime,PARK_CARD);//ʵ�ʲ���ʱ��
	parkfee_time = parkfeetime_count(spacest.start_stopTime+2,endtime);//�շѲ���ʱ��
	if(parkfee_time>=60)
//	if(feetimeold>=60)
		TMP.feemny = RR_STtmp.f2*RR_STtmp.Sale_Base;
	else
		TMP.feemny = RR_STtmp.f1*RR_STtmp.Sale_Base;
  	}
  else
  	{
	feetimeold =0;
  	addf =0;
	feetimeall = momery_to_time(100000);
  	TMP.feemny = RR_STtmp.f1*RR_STtmp.Sale_Base;
  	}
  ngtime =0;
  car = space;
//  CCard_GPIOConfig();
  Contact_Power_ON;
  delay(KEYTIMEOUT_1S/2);
  key_flag =0;
  i =ICCARD_OUTTIME*5;//15;
  while(i--)
  	{
	IWDG_ReloadCounter();//2015-12-23 andyluo
	if(key_flag)return 1;
	if(IC_SWITCH_read==NOZBTCARD)continue; 
    read_cpucard();
	if((carddata[0]==0xff)||(carddata[0]==0))
		{
		ngtime++;
		if((ngtime%10)==0)
			{
			ngtime =0;
			Buzz_0;
			delay(KEYTIMEOUT_1S/10);
			Buzz_1;
			display_prebuy_menu(iccardno,ymoney,0,0,0,0,PreBuyDisp_B3);	
			while(IC_SWITCH_read==YESZBTCARD); 
			continue;
			}
		if(i==1)
			{
			//�����������ϴ��о
			Contact_Power_OFF; 
			Buzz_0;
			delay(KEYTIMEOUT_1S/10);
			Buzz_1;
			write_card_error(0);
			delay(KEYTIMEOUT_1S * 3);
			return 1;
			}
		}
	else
		break;	 
	}
  makeup_cardinfor();   
  if((jd_zhoubotong()==0)||(TCardInfor.init_flag&0x01))//�����ܲ�ͨ��
	{//��Ч��
	Contact_Power_OFF; 
	Buzz_0;
	delay(KEYTIMEOUT_1S/10);
	Buzz_1;
	no_use_card(0);
	delay(KEYTIMEOUT_1S * 3);
	return 2;
	}  
//  //����
  ymoney=hcl(TCardInfor.money,4);//�ϲ�  
  if(ymoney>50000) // Ǯ����100Ԫ ����
  	{
	Contact_Power_OFF; 
	Buzz_0;
	delay(KEYTIMEOUT_1S/10);
	Buzz_1;
	no_use_card(1);
	delay(KEYTIMEOUT_1S * 3);
    return 3; //IC�����ϣ�����ϵ����Ա
    } 
  copy_data(1); //���ݵ�һ������ 
  cardno = (TCardInfor.cardNO[0]<<24)+
  			(TCardInfor.cardNO[1]<<16)+
  			(TCardInfor.cardNO[2]<<8)+
  			TCardInfor.cardNO[3];
  iccardno[0] = HEX_to_BCD(cardno/1000000);
  iccardno[1] = HEX_to_BCD((cardno%1000000)/10000);
  iccardno[2] = HEX_to_BCD((cardno%10000)/100);
  iccardno[3] = HEX_to_BCD(cardno%100);
  TMP.feetime = RR_STtmp.Tb;
  if(IQFlag==IQ_YES)
  	{  	
  	display_prebuy_menu(iccardno,ymoney,0,0,0,0,PreBuyDisp_B1);	
	delay(KEYTIMEOUT_1S * 1);
	key_flag =0;
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	maxtimeout = KEYTIMEOUT_1S * 3;
	while(maxtimeout--)
	   {   
	   if(key_flag||(maxtimeout==1))break;	
	   }	
	return 4;	
  	}
  if(IQFlag==0x88)
  	{
	key_flag = 0;
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
  	}
  feetime = 0;
  feemny = 0;
  I2C_ReadS_24C(PreBuy_NGBuff1+(car-1)*16,buffer,16);
  //buffer-0������� 1-4��� 5-8���� 9-13ʱ�� 14-15����ʱ��
  memcpy(endtime,time1,5);
  memcpy(intime,time,5);
  ngtime = ret_max_24hour(buffer+9,PARK_CARD);//ʵ�ʲ���ʱ��
  memcpy(time1,endtime,5);
  memcpy(time,intime,5);
  if(ngtime>10)//ֻ����5����
 	 {
	 memset(buffer,0,16);//��������־2016-04-12
	 I2C_WriteS_24C(PreBuy_NGBuff1+(car-1)*16,buffer,16);
	 }
  for(i=0;i<4;i++)
  	{
	if(iccardno[i]!=buffer[i+5])
		break;
  	}
  if((buffer[0]>0)&&(i==4))//
  	{
	ngmny=hcl(buffer+1,4);//�ϲ�	
	if(ymoney<ngmny)
		{
		success = 1;
		if(ymoney<TMP.feemny)mnyerr =1;
		else mnyerr =0;
		ymoney = ngmny;
		submny = ngmny-TMP.feemny;
		feemny = TMP.feemny;	
		scng=1;
		}
  	}

  if((ymoney<TMP.feemny)&&(success==0))  
  	{
	display_prebuy_menu(iccardno,ymoney,0,0,0,0,PreBuyDisp_0);	
	delay(KEYTIMEOUT_1S * 1);
	key_flag = 0;
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	maxtimeout = KEYTIMEOUT_1S * 3;
	while(maxtimeout--)
	   {   
	   if(key_flag||(maxtimeout==1))break;	
	   }	
	return 4;
  	}
  if(spacest.car_stop_way[0] == 0x66)
	display_prebuy_menu(iccardno,ymoney,0,0,0,0,PreBuyDisp_B2);
  else
  	display_prebuy_menu(iccardno,ymoney,0,0,0,0,PreBuyDisp_1);	
  key_flag = 0;
  /* ι��*/
  IWDG_ReloadCounter();//2015-12-23 andyluo
  maxtimeout = ICCARD_OUTTIME;											 
  while(maxtimeout--)
  	{ 
	IWDG_ReloadCounter();//2015-12-23 andyluo
	if(key_flag||(maxtimeout==1))
		{	
		key_flag = 0;
		Contact_Power_OFF; 
		return 0;
		} 	
	if(IC_SWITCH_read==NOZBTCARD)break;
	}
  oldymoney = ymoney;//�������
  maxtimeout = ICCARD_OUTTIME;											 
  /* ι��*/
  IWDG_ReloadCounter();//2015-12-23 andyluo
  ngtime = 0;
  key_flag = 0;
  while(maxtimeout--)
  	{	
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	if(key_flag)break;	
	icswflag = IC_SWITCH_read;
	if(icswflag==NOZBTCARD)continue;
	if(maxtimeout==1)//��ʱ�˳�
		{
		Contact_Power_OFF; 
		return 0;	
		}
	delay(KEYTIMEOUT_1S/10);
	read_cpucard();
	makeup_cardinfor();	
	if((carddata[0]==0xff)||(carddata[0]==0))
		{
		display_prebuy_menu(iccardno,ymoney,0,0,0,0,PreBuyDisp_2);  
		maxtimeout = ICCARD_OUTTIME;
		continue;
		}
	if((jd_zhoubotong()==0)||(TCardInfor.init_flag&0x01))//�����ܲ�ͨ��
		{
		display_prebuy_menu(iccardno,ymoney,0,0,0,0,PreBuyDisp_3);   
		maxtimeout = ICCARD_OUTTIME;
		continue;
		}
	flag = jd_sameCCard();
	if(flag == 0)
		{
		display_prebuy_menu(iccardno,ymoney,0,0,0,0,PreBuyDisp_4);   
		maxtimeout = ICCARD_OUTTIME;
		continue;
		}
	if(mnyerr==0)
		ymoney=hcl(TCardInfor.money,4);//�ϲ�
	else
		{
		feemny = TMP.feemny;
		submny = ymoney;
		}
	if(oldymoney<ymoney)
		{
		delay(KEYTIMEOUT_1S/10);
		maxtimeout = ICCARD_OUTTIME;
		continue;
		}
	if((mnyerr==0)&&(success ==0)&&(ymoney<TMP.feemny)||(ymoney==0))//����
		{
		display_prebuy_menu(iccardno,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_5);  
		delay(KEYTIMEOUT_1S*1);
		break;
		}
	if((TMP.cpc == Disp_ICBS)&&(feetime>=60))
		{
		TMP.feemny = RR_STtmp.f2*RR_STtmp.Sale_Base;
		}
	fng = 1;
	bkdispmny = ymoney;
	display_prebuy_menu(iccardno,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_6);  
	if((success==0)) //||(mnyerr==0))
		{
		if(oldymoney>feemny)
			feemny += TMP.feemny;
		if(oldymoney>=feemny)
			submny = oldymoney - feemny;//�۷Ѻ���
		else
			{
			feemny -= TMP.feemny;     
			display_prebuy_menu(iccardno,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_5);  
			delay(KEYTIMEOUT_1S*1);
			break;
			}
		}
	{
	copy_data(1);
	copy_data(2); //���ݵ�һ������ 
//	flag = (oldymoney-ymoney)/10;
//	if(flag==0)flag = TMP.feemny/10;
	success = 0;
	if(ymoney<=submny)//�۷Ѻ�Ľ��Ϳ���ʵ�ʽ�� 2016-04-11
		{
		flag = 0;
		rmny = submny;
		}
	else//ymoney>submny
		{
		flag = (ymoney-submny)/10;
		rmny = ymoney;
		}		
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	swngtime = 0;
	cflag = flag;
	while(flag--)
		{
		if(rmny<=submny)
			{ymoney = submny;break;}			
		success=koufei();
		if(success)
			{swngtime =1;break;}
		else
			{	
			for(j=0;j<13;j++)
				oldcarddata[j] = newcarddata[j];
			}
		}	
	
	rmny = submny+1;//Ϊ��У��������� 
	read_cpucard();
	makeup_cardinfor(); 
	if((carddata[0]!=0xff)&&(carddata[0]!=0))
		{
		rmny =hcl(TCardInfor.money,4);//�ϲ�
		}		
	if(rmny>submny)swngtime=1;
	else 
		{swngtime=0;ymoney=submny;}

	success = swngtime;
	if(scng)
		{//��������µĴ�����ʾ
		ymoney = oldymoney;
		scng=0;
		}
	}		
	if(swngtime)
//	if(ymoney>submny)//�ۿ�δ���
		{	
		I2C_ReadS_24C(PreBuy_NGBuff1+(car-1)*16,buffer,16);
		fng = 1;
		if(buffer[0]==0)
			{
			buffer[0]= 1;
			fll(ymoney,buffer+1,4);
			memcpy(buffer+5,iccardno,4);//��������	
			buffer[9] = time[3]; //��									   
			buffer[10] = time[2]; //��										
			buffer[11] = time[1]; //ʱ										 
			buffer[12] = time[0]; //��										 
			buffer[13] = time[4];//0x00; //�� Ԥ��										 
			buffer[14] = feetime / 60; //����ͣ��ʱ�� 24Сʱ									  
			buffer[15] = feetime % 60;		
			I2C_WriteS_24C(PreBuy_NGBuff1+(car-1)*16,buffer,16);
			}
		success = 1;
		display_prebuy_menu(iccardno,submny+TMP.feemny,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_7);  
//		display_prebuy_menu(iccardno,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_7);  
		key_flag = 0;
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo
		Contact_Power_ON;
//		delay(KEYTIMEOUT_1S/10);
		maxtimeout = ICCARD_OUTTIME;
		while(maxtimeout--)
		   {   
		   icswflag = IC_SWITCH_read;
		   if(key_flag||(maxtimeout==1)||(icswflag==NOZBTCARD))break;	
		   maxtimeout = ICCARD_OUTTIME;
		   continue;//�ٴβ忨
		   }	
		if(key_flag||(maxtimeout==1))break;  
		maxtimeout = ICCARD_OUTTIME;
		/* ι��*/
		IWDG_ReloadCounter();//2015-12-23 andyluo			
		continue;
		}
	memset(buffer,0,16);
	I2C_WriteS_24C(PreBuy_NGBuff1+(car-1)*16,buffer,16);
	ngmny = 0;
	feetime = momery_to_time_WZ(feemny);
	swngtime = 0;	
	fng = 0;
	swng = 0;
	success = 0;
	if(scng)
		{//��������µĴ�����ʾ
		ymoney = oldymoney;
		scng=0;
		}
//	if(ymoney>oldymoney)
//		display_prebuy_menu(iccardno,oldymoney-feemny,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_8);  
//	else
		display_prebuy_menu(iccardno,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_8);  
	ledf = 1;
	if(IQFlag!=0x88)
		light(car,OK);
	Buzz_0; 	
	delay(KEYTIMEOUT_1S/10); 
	Buzz_1; 
	//4. ����λ״̬���£�ͣ����־��ͣ���գ�ʱ��������ͣ��ʱ�䣩
	buffer[0] = 0x66; //��λ״̬
	buffer[1] = PreBuyflag; //Ԥ���־
	buffer[2] = feetimeall/60; //Ԥ����ʱ��
	buffer[3] = feetimeall%60; //Ԥ����ʱ��
	buffer[4] = 0x00; //��������
	buffer[5] = iccardno[0]; //��������
	buffer[6] = iccardno[1];
	buffer[7] = iccardno[2];
	buffer[8] = iccardno[3];
	if(addf==1)
		{
		for(i=0;i<5;i++)
			buffer[9+i] = spacest.start_stopTime[i];
		
		buffer[14] = (feetime+feetimeold) / 60; //����ͣ��ʱ�� 24Сʱ
		buffer[15] = (feetime+feetimeold) % 60;		 
		}
	else
		{
		buffer[9] = time[3]; //��
		buffer[10] = time[2]; //��
		buffer[11] = time[1]; //ʱ
		buffer[12] = time[0]; //��
		buffer[13] = time[4]; //�� Ԥ��	 
		
		buffer[14] = feetime / 60; //����ͣ��ʱ�� 24Сʱ
		buffer[15] = feetime % 60; 		
		}
	
	if(IQFlag!=0x88)
		{
		write_car_reference_of_use_info(space,buffer,16);
//		parkalltime = ret_max_24hour(spacest.start_stopTime,PARK_CARD);//ʵ�ʲ���ʱ��
		math_time(feetime,endtime);
		parkfee_time = parkfeetime_count(buffer+11,endtime);//�շѲ���ʱ��
		if(parkfee_time>=60)
			TMP.feemny = RR_STtmp.f2*RR_STtmp.Sale_Base;
		else
			TMP.feemny = RR_STtmp.f1*RR_STtmp.Sale_Base;
		}
//	feetimeaf = momery_to_time(feemny+TMP.feemny);
//	if(feetimeaf==feetime)
	if(addf == 1)
		feetimereal = feetime+feetimeold;
	else
		feetimereal = feetime;
	
	if(feetimereal >= feetimeall)
		{
		display_prebuy_menu(iccardno,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_9);
		break;
		}
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	maxtimeout = ICCARD_OUTTIME;
	while(maxtimeout--)
	   {   
	   IWDG_ReloadCounter();//2015-12-23 andyluo
	   if(key_flag||(maxtimeout==1))break;  
	   if(IC_SWITCH_read==YESZBTCARD)continue;//�ٴβ忨
	   else break;
	   }	
	if(maxtimeout==1)break;  
	/* ι��*/
	IWDG_ReloadCounter();//2015-12-23 andyluo
	maxtimeout = ICCARD_OUTTIME;
	delay(KEYTIMEOUT_1S/10);
	if(IC_SWITCH_read==NOZBTCARD)
		display_prebuy_menu(iccardno,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_12);
	}
  Contact_Power_OFF; 
  key_flag = 0;
  if((feetime==0)||(ledf==0))return 0;
  if(swng==1)return 0;
  if(fng)//2016-04-20 andyluo
  	{
	feemny -= TMP.feemny;//ʵ�ʿ��ܿۿ� ����ʱ��δ���ӵ���� 2016-04-15
  	}
//  feetime = momery_to_time_WZ(feemny);
  I2C_ReadS_24C(PreBuy_NGBuff1+(car-1)*16,buffer,16);
  ngmny=hcl(buffer+1,4);//�ϲ�	  
  ngtime = buffer[0];
  //2. ��ͣ����¼
  buffer[0] = 0xEE;//��¼ͷ		
  buffer[1] = 0x00; //��������	   
  buffer[2] = ngtime;	  
  buffer[3] = ngmny>>8;	 
  buffer[4] = ngmny;		
  buffer[5] = iccardno[0]; //��������
  buffer[6] = iccardno[1];
  buffer[7] = iccardno[2];
  buffer[8] = iccardno[3];
  for(i=0;i<5;i++)
	  buffer[9+i] = time[4-i];//������ʱ��
  buffer[14] = oldymoney>>16;  
  buffer[15] = oldymoney>>8;  
  buffer[16] = oldymoney;   
  buffer[17] = feemny>>8;
  buffer[18] = feemny; 
  if(IQFlag==0x88)
	  buffer[19] = ((car+CAR_CLASS)<<4) + 0x0E;//��һ��ͣ�� ��λΪcar										  
  else if(addf ==1)
  	buffer[19] = ((car+CAR_CLASS)<<4) + PreBuyAddRecord;//��һ��ͣ�� ��λΪcar											
  else
  	buffer[19] = ((car+CAR_CLASS)<<4) + PreBuyRecord;//��һ��ͣ�� ��λΪcar											  

  if(IQFlag!=0x88)
  	{
	for(i=0;i<8;i++)
		buffer[i] = 0xAA;
	I2C_WriteS_24C(CardNo1_CPU+(space-1)*16,buffer,8);
  	}
  bushimny[car] = 0;   
  bukanmny[car] = 0;  
  TMP.CPC_ckmny[car] = 0;
  math_time(feetime,endtime);
  for(i=0;i<5;i++)
	  buffer[20+i] = HEX_to_BCD(endtime[4-i]);//������ʱ��
  buffer[25] = CardType_IC;//����ͨ��¼��־
  for(i=26;i<32;i++)   
	  buffer[i] = 0xAA;
  Save_Record(buffer,32);
  WriteRecord(car,TMP.cardplace);
  Deal_SwipCardIMG(car-1,1);
  TMP.ckflag[car] = 0;  
  delay(KEYTIMEOUT_1S * 1);
  for(i=0;i<5;i++)
	  TMP.time[i] = HEX_to_BCD(endtime[i]);//������ʱ��
  lcd_clear();
  if(IC_SWITCH_read==YESZBTCARD)
  	display_prebuy_menu(iccardno,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_10);
  else
  	{
  	display_prebuy_menu(iccardno,ymoney,TMP.feemny,TMP.feetime,feetime,0,PreBuyDisp_11);
  	delay(KEYTIMEOUT_1S * 2);
  	}
  delay(KEYTIMEOUT_1S * 1);
  /* ι��*/
  IWDG_ReloadCounter();//2015-12-23 andyluo
  maxtimeout = KEYTIMEOUT_1S * 6;
  while(maxtimeout--)
	 {	 
	 IWDG_ReloadCounter();//2015-12-23 andyluo
	 if(key_flag||(maxtimeout==1))break;  
	 if(IC_SWITCH_read==YESZBTCARD)
		continue;//��ο�
	 else break;
	 }	  
//  if(maxtimeout==1)break;  
  buffer[0] = 0x00;
  I2C_WriteS_24C(ResetCar1Flag + car - 1,buffer,1);				
  /* ι��*/
  IWDG_ReloadCounter();//2015-12-23 andyluo
  GetCurrentTime();
  delay(KEYTIMEOUT_1S * 1);
  return 0;
}

