#ifndef  _SYS_DispMenu_H
#define    _SYS_DispMenu_H
void Refresh_SYSallicon(void);
void Refresh_SYSallicon1(void);
void display8X8(void);
extern void SYS_Vision(void);
extern void disp_System_checking(void);
extern void CT_fb_on_gb_on(void);
extern void CT_fb_off_gb_on(void);
extern void CT_fb_on_gb_off(void);
extern void CT_fb_off_gb_off(void);
extern void cursor_flash_time(unsigned char flash_time);
extern void disp_illegalopen(void);
extern void disp_current_time(void);
void disp_current_time12(void);
extern void disp_CURTIM_16x32(void);
extern void disp_CURTIM_16x32line(void);
extern void disp_CURTIM_16x32line0(void);
extern void disp_week1(u8 wordtype);
extern void disp_month(unsigned char disptype);
extern void disp_month1(u8 wordtype);
extern void disp_day1(u8 wordtype);
extern void disp_purch_time1(u8 wordtype);
extern void disp_purch_money1(u8 wordtype);
extern void disp_MinPark(u8 wordtype);
extern void disp_MinCost(u8 wordtype);
extern void disp_year1(u8 wordtype);
extern void disp_time1(u8 wordtype);
extern void disp_endtime1(u8 wordtype);
extern void disp_starttime1(u8 wordtype);
extern void disp_weektoweek(u8 wordtype);
extern void disp_maxtime(u8 wordtype);
extern void disp_AM_PM(u8 wordtype);
extern void disp_SPACE(u8 wordtype);
extern void disp_pertime(u8 wordtype);
extern void disp_Cancel(void);
extern void disp_Menu(void);
extern void disp_mainmenu1(void);
extern void disp_mainmenu2(void);
extern void disp_mainmenu3(void);
extern void disp_mainmenu4(void);
extern void disp_MainMenu(void);
extern void disp_MainMenu_1(void);
extern void disp_MainMenu_2(void);
extern void disp_MainMenu_3(void);
extern void disp_MainMenu_4(void);
extern u8 Enter_AdminMenu(unsigned long eepromaddress);
#define  disp_MainMenu() 	    disp_MainMenu_1()
extern void disp_Adminmenu_1(void);
extern void disp_Adminmenu_2(void);
extern void disp_Adminmenu_3(void);
extern void disp_Adminmenu_4(void);
extern void disp_Adminmenu_5(void);
#define  disp_Adminmenu()    disp_Adminmenu_1()
void INI_FMI2C_SYSSeting(void);
void Disp_SYSINFO_Page1(void);
void Disp_SYSINFO_Page2(void);
void Disp_SYSINFO_Page3(void);
void Disp_SYSINFO_Page4(void);

void Do_MainMenu(void);

void disp_user_OK(u16 user_time);
void Disp_MinmaxTime(void);


//extern void disp_please_swipecard(void);

void disp_Machine_no(void);	 //�����
extern void disp_System_tariff(void); //ϵͳ����
extern void disp_IP_no(void);	   //IP��
extern void disp_APN_no(void);	   //APN��
void disp_Total_Cash(void);	 //���ֽ� ����Ӳ������
void disp_Total_Card_Payment(void);	 //�ܸ�Ӧ�����
void disp_Total_SMS_Payment(void);	 //�ܸ�Ӧ�����
void disp_Total_SMSCH_Payment(void);	 //�ܸ�Ӧ�����
void disp_Total_amount(void);	 //�ܽ��׽��
void disp_Total_Transcations(void);	 //�ܽ��״���
void disp_Preset_coincount(void);	 //Ӳ��������
void disp_Box_coincount(void);	 //ʵ��Ӳ����
void disp_nouse_error(void);
void disp_nouse_error1(void);
void disp_nouse_error2(void);
void disp_other_error(void);
void disp_Coinmodule_error(void);
void disp_Cardmodule_error(void);
u8 checkchewei(void);
extern unsigned int disp_oldutime_max(unsigned char bn);
extern unsigned long get_oldutime(unsigned char bn);
extern void disp_use_time(unsigned long bb);
extern void disp_use_money(unsigned long bb);
extern void disp_user_maintime(u8 timemode,u16 user_time,u16 user_money);
extern void disp_user_maintime1(u8 timemode,u16 user_time,u16 user_money);
extern void disp_user_maintime2(u8 timemode,u16 user_time,u16 user_money);
extern void disp_user_maintime12(u8 timemode,u16 user_time,u16 user_money);
extern void disp_user_maintime13(u8 timemode,u16 user_time,u16 user_money);
extern void disp_user_maintime14(u8 timemode,u16 user_time,u16 user_money);
extern void disp_user_OK111(u8 timemode,u16 user_time,u16 user_money);
extern void disp_user_main(u8 timemode,u16 user_time,u16 user_money);
extern void Disp_week(unsigned char disptype,unsigned char weeks);
extern void disp_lefttime(unsigned char disptype);
extern void disp_leftmoney(unsigned char disptype);
extern void disp_expiredtime(unsigned char disptype);
extern void Disp_CSQ_icon(u8 SG_CSQD);
extern void Disp_NetPOS_icon(void);
extern void Disp_BTValue_icon(u8 BT_Value);
extern void Do_MainMenu_4(void);
void  Disp_ParkState_icon(u8 Park_ST);
void do_coin(void);
char zhibi_init(void);
char get_bizhi();
u8 INI_Creditcard(void);
u8 cctalk_reset(void);

u8 Check_Creditcard(void);
u8 Check_Cash(void);
u8 Check_Coin(void);
u8 Check_CashBox(void);
u8 Check_CoinBox(void);
u8 Check_Battery(void);
u8 Check_Printer(void);
void Check_SystemDevice_DispFault(u8 OnlyDisp);


void SytInfo_print();
void Test_print();
void Income_print();
void Al_Mun_print(u32 ExTime, u32 amtpaid ,u8 Print_Mode);
u8 Printer_Start(void);
void Printer_Over(void);
void disp_coin_return(void);
void disp_Beyond_20pcs(void);
void Takemny_INI(void);
void Day_INI(void);
void INI_G3_Flash(void);
unsigned char GPRS_online_JD2(void);
unsigned char GPRS_online_JD3(void);
unsigned char mathdata(unsigned char timex1[],unsigned char timex2[]);
unsigned char Cal_FreeDay(void);
void Newipstart(void);
void NewMetno(void);
void NewRate(void);
void NewLcd(void);
void generatewarm(unsigned char nowstate,unsigned long IDState_add,unsigned char IDFullFault,unsigned char IDFullRepairOK);
void memreplace(u16 source_addr,u16 aim_addr,u16 translength);
#endif
