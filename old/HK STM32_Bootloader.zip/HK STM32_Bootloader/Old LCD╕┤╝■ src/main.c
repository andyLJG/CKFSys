/************************************************************
**��Ŀ����:NewZealand 2011-10-22
**����:	������Ӳ�ҡ�ֽ�ҡ����ÿ���WCDMA����ӡ��IrDA��
**ע������:������ģ����Զ���
**����:andyluo����·�¸�λͬ��
**���ΰ汾:
**�޶�(���ܼ��汾):
**�޶���:andyluo����·�¸�λͬ��
*************************************************************/
#include "string.h"
#include "stm32f10x_conf.h"
#include "hal.h"
#include "MemoryAssign.h"
#include "I2C.h"
#include "SYS_DispMenu.h"
#include "stm32f10x_pwr.h"
#include "stm32f10x_wwdg.h"
#include "main.h"
#include "spi_flash.h"
#include "fsmc_sram.h"
#include "IapTest.h"
#include <stdio.h>

#define BOOTTIME     20
#define LED1_ON     GPIO_ResetBits(GPIOF, GPIO_Pin_6)
#define LED1_OFF     GPIO_SetBits(GPIOF, GPIO_Pin_6)

#define LED2_ON     GPIO_ResetBits(GPIOD, GPIO_Pin_3)
#define LED2_OFF     GPIO_SetBits(GPIOD, GPIO_Pin_3)

#define LED3_ON     GPIO_ResetBits(GPIOC, GPIO_Pin_4)
#define LED3_OFF     GPIO_SetBits(GPIOC, GPIO_Pin_4)

#define LED4_ON     GPIO_ResetBits(GPIOF, GPIO_Pin_7)
#define LED4_OFF     GPIO_SetBits(GPIOF, GPIO_Pin_7)


#define StartFlashAddress			(0x08000000)
#define IapMemorySize				(0x11000)	/* 64K*/
#define ApplicationAddress1			(StartFlashAddress+IapMemorySize)
#define ApplicationAddress2			(StartFlashAddress+0x70000)
#define AppMemorySize				(0x70000)	/* 448K */

#define UpdateFlag                              (uint32_t)(0x7D0000)     /* ������־ ��ַ*/
///////////////////////////////////////////////////////////////////////////////////////////////
#define Smart_Power_OFF         GPIO_ResetBits(GPIOB, GPIO_Pin_12)
#define Smart_Power_ON         GPIO_SetBits(GPIOB, GPIO_Pin_12)

//��������4G��
#define GPRS_Power_OFF       GPIO_SetBits(GPIOG, GPIO_Pin_15)
#define GPRS_Power_ON         GPIO_ResetBits(GPIOG, GPIO_Pin_15)

typedef  void (*IapFun)(void);				//����һ���������͵Ĳ���.
IapFun Jump2App; 
#define SYSPRO_JD_APP	  		   0x0BF4 // 10
#define SYSPRO_JD_BOOTLOADER 	   0x09E8+48// 10


#define LCD_back_ON   GPIO_SetBits(GPIOG, GPIO_Pin_14)
#define LCD_back_OFF    GPIO_ResetBits(GPIOG, GPIO_Pin_14)

#define LCD_POWER_OFF	GPIO_ResetBits(GPIOG, GPIO_Pin_15)//��ʾ����Դ���ƽŴ򿪡��ر�
#define LCD_POWER_ON	GPIO_SetBits(GPIOG, GPIO_Pin_15)

extern u8 zimo;


//������λ�ĳ���
void GenerateSystemReset(void) 
{ 
  __ASM("MOV R0, #1"); 
  __ASM("MSR FAULTMASK, R0"); 
  SCB->AIRCR = 0x05FA0004; 
  for(;;); 
} 



int main(void)
{
u32 i,appsum,btsum;
u8 buf[16],apbuf[16];

	  ChipHalInit();	  
	  //��ȡFLASH ������־
      SPI_FLASH_BufferRead(buf,(UpdateFlag+3),4);
      for(i=0;i<4;i++)
	  	{
		if(buf[i] != 0xa2)
			break;
		}      
      if(i >= 4) //�����Ҫ���� ������������
      	{
        //��ʾ ������....
		LCD_INIT();
        LCD_POWER_ON;   //PG13
        LCD_back_ON;    //PB13
        lcd_clear();    
		Disp_EnglishStr(2,LCDCENTERDISP,"Updating program..."); 
		Disp_EnglishStr(4,LCDCENTERDISP,"Pls. wait a few minutes."); 
		zimo = 1;
		Disp_EnglishStr(6,LCDCENTERDISP,"Pls. donot poweroff!!!"); 
		zimo = 0;
        while(i > 0)
			{
            if(IapUpdataProgram() == 0x01)
              break;
            else
              i--;
			}        
        if(i > 0)//�����ɹ�
        	{
            lcd_clear();
			Disp_EnglishStr(2,LCDCENTERDISP,"Update success"); 
            SPI_FLASH_SectorErase(UpdateFlag);//����������� �� ��־
            }        
        LCD_POWER_OFF;   //PG13
        LCD_back_OFF;    //PB13
        lcd_clear();
		}  	  
	  buf[0] = 0xB4;
	  I2C_WriteS_24C(0x0B81,buf,1);

	  
	  I2C_ReadS_24C(SYSPRO_JD_APP,apbuf,10);//LUO151210P
	  
	  if((apbuf[0]!='L')&&(apbuf[1]!='U')&&(apbuf[2]!='O'))
	  	{
	  	I2C_WriteS_24C(SYSPRO_JD_APP,"LUO151210P",10);	  
		I2C_WriteS_24C(SYSPRO_JD_BOOTLOADER,"LUO151210P",10);   
	  	}

	I2C_ReadS_24C(SYSPRO_JD_BOOTLOADER,buf,10);   
		{
		buf[8]++;
		I2C_WriteS_24C(SYSPRO_JD_BOOTLOADER,buf,10);   
		}
	
#ifdef BOOTLOADER_B
	  	{
	  	I2C_WriteS_24C(SYSPRO_JD_APP,"LUO151210P",10);	  
		I2C_WriteS_24C(SYSPRO_JD_BOOTLOADER,"LUO151210P",10);   
	  	}
	  GenerateSystemReset();
#endif
	  I2C_ReadS_24C(SYSPRO_JD_BOOTLOADER,buf,10);   
	  I2C_ReadS_24C(SYSPRO_JD_APP,apbuf,10);   
	  appsum = apbuf[7]*256 + apbuf[8];
	  btsum = buf[7]*256 + buf[8];
	  btsum -= appsum;
	  apbuf[11] = apbuf[0];
	  for(i=1;i<9;i++)apbuf[11] ^= apbuf[i];
	  
	  if(btsum>BOOTTIME+1)
	  	{
		btsum=0;
	  	I2C_WriteS_24C(SYSPRO_JD_APP,"LUO151210P",10);	  
		I2C_WriteS_24C(SYSPRO_JD_BOOTLOADER,"LUO151210P",10);   
	  	}
//	  i=0;//��ʱ����
	  if(btsum==5)
		  {		  	
		  LCD_INIT();
		  LCD_POWER_ON;   //PG13
		  LCD_back_ON;	  //PB13
		  lcd_clear();	
		  Disp_EnglishStr(2,LCDCENTERDISP,"Loading program..."); 
		  }
	  if(btsum>5)delay(8500000*2);
	  
	  if(i&&((buf[0]!='L')||(buf[1]!='U')||(buf[2]!='O')||
	  	(apbuf[0]!='L')||(apbuf[1]!='U')||(apbuf[2]!='O')||
	  	(apbuf[9]!=apbuf[11])||(apbuf[9]<'P')||(btsum>BOOTTIME)))
		  {
//		  delay(8500000*3); 	
		  zimo = 1;
		  Disp_EnglishStr(2,LCDCENTERDISP,"Program load failed!"); 
		  zimo = 0;
		  Disp_EnglishStr(4,LCDCENTERDISP,"Please program MCU again."); 
		  Disp_EnglishStr(6,LCDCENTERDISP,"Or pls. connect admin.."); 
		  delay(8500000*3);		
		  delay(8500000*60);		
		  LCD_back_OFF;	  //PB13
		  while(1);
//		  GenerateSystemReset();
		  }
      if(((*(vu32*)(ApplicationAddress1+4))&0xFF000000)==0x08000000)//�ж��Ƿ�Ϊ0X08XXXXXX.
     	  {
		  if(((*(vu32*)ApplicationAddress1)&0x2FFE0000)==0x20000000)	//���ջ����ַ�Ƿ�Ϸ�.
          	{
			NVIC_SetVectorTable(StartFlashAddress,IapMemorySize);
            Jump2App=(IapFun)*(__IO vu32*)(ApplicationAddress1+4);	//�û��������ڶ�����Ϊ����ʼ��ַ(��λ��ַ)			
            __set_MSP(*(__IO vu32*)ApplicationAddress1);//��ʼ��APP��ջָ��(�û��������ĵ�һ�������ڴ��ջ����ַ)               
            Jump2App();//��ת��APP.
          	}
		  }  
}




#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

//�ӳٺ���
void Delay(u16 speed)
{
	u16 i;
	while(speed!=0)
	{
		speed--;
		for(i=0;i<400;i++);
	}
}



