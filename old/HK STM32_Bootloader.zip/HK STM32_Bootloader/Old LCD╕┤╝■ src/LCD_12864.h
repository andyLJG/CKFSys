#ifndef	_LCD_H
//#include "Smart_card.h"

#define		_LCD_H			    
#define	fb_off_gb_off	0xEA						//���׹ع���1110_1010
#define	fb_on_gb_on	0xCE						//���׿���꿪1100_1110
#define	fb_off_gb_on	0xEE						//���׹ع�꿪1110_1110
#define	fb_on_gb_off	0xCA		  			    //���׿�����1100_1010

#define uchar unsigned char

//#define db0_1  GPIO_SetBits(GPIOC, GPIO_Pin_0)
//#define db0_0  GPIO_ResetBits(GPIOC, GPIO_Pin_0)

//#define db1_1  GPIO_SetBits(GPIOC, GPIO_Pin_1)
//#define db1_0  GPIO_ResetBits(GPIOC, GPIO_Pin_1)

//#define db2_1  GPIO_SetBits(GPIOE, GPIO_Pin_2)
//#define db2_0  GPIO_ResetBits(GPIOE, GPIO_Pin_2)

//#define db3_1  GPIO_SetBits(GPIOE, GPIO_Pin_3)
//#define db3_0  GPIO_ResetBits(GPIOE, GPIO_Pin_3)

//#define db4_1  GPIO_SetBits(GPIOE, GPIO_Pin_4)
//#define db4_0  GPIO_ResetBits(GPIOE, GPIO_Pin_4)

//#define db5_1  GPIO_SetBits(GPIOE, GPIO_Pin_5)
//#define db5_0  GPIO_ResetBits(GPIOE, GPIO_Pin_5)

//#define db6_1  GPIO_SetBits(GPIOE, GPIO_Pin_6)
//#define db6_0  GPIO_ResetBits(GPIOE, GPIO_Pin_6)

//#define db7_1  GPIO_SetBits(GPIOG, GPIO_Pin_7)
//#define db7_0  GPIO_ResetBits(GPIOG, GPIO_Pin_7)

//#define lcd_rd_1  GPIO_SetBits(GPIOG, GPIO_Pin_8)
//#define lcd_rd_0  GPIO_ResetBits(GPIOG, GPIO_Pin_8)

//#define lcd_wr_1  GPIO_SetBits(GPIOG, GPIO_Pin_9)
//#define lcd_wr_0  GPIO_ResetBits(GPIOG, GPIO_Pin_9)

//#define lcd_rs_1  GPIO_SetBits(GPIOB, GPIO_Pin_15)
//#define lcd_rs_0  GPIO_ResetBits(GPIOB, GPIO_Pin_15)

//#define lcd_res_1  GPIO_SetBits(GPIOG, GPIO_Pin_11)
//#define lcd_res_0  GPIO_ResetBits(GPIOG, GPIO_Pin_11)

//#define lcd_cs_1  GPIO_SetBits(GPIOG, GPIO_Pin_12)
//#define lcd_cs_0  GPIO_ResetBits(GPIOG, GPIO_Pin_12)

//#define LCD_back_ON  GPIO_SetBits(GPIOB, GPIO_Pin_13)
//#define LCD_back_OFF  GPIO_ResetBits(GPIOB, GPIO_Pin_13)

//#define POWER_change_OFF	GPIO_ResetBits(GPIOA, GPIO_Pin_8)//��Դ����373��չ�����ߴ򿪡��ر�
//#define POWER_change_ON	        GPIO_SetBits(GPIOA, GPIO_Pin_8)//

//#define LCD_POWER_OFF		GPIO_ResetBits(GPIOG, GPIO_Pin_13)//��ʾ����Դ���ƽŴ򿪡��ر�
//#define LCD_POWER_ON	        GPIO_SetBits(GPIOG, GPIO_Pin_13)


#define LCD_change_ON  GPIO_SetBits(GPIOG, GPIO_Pin_13)
#define LCD_change_OFF  GPIO_ResetBits(GPIOG, GPIO_Pin_13)

#define SmartCTRL_ON      GPIO_SetBits(GPIOD, GPIO_Pin_10)
#define SmartCTRL_OFF     ;//GPIO_ResetBits(GPIOD, GPIO_Pin_10)





void test_buzz(void);
void test_led(void);
void test_coin_inout(void);
void Disp_EnglishStr(u8 hang, u8 lie, u8 *pstr);
void Disp_PictureStr(u8 x,u8 y,u8 width,u8 high,u8 const bmp[]);
void Disp_1Num(u8 hang, u8 lie, u8 a);
void Disp_2Num(u8 hang, u8 lie, u8 a);
void Disp_2Num_VeHEX(u8 hang, u8 lie, u8 a);
void Disp_2Num_VeBCD(u8 hang, u8 lie, u8 a); 
void Disp_1Num_VeHEX(u8 hang, u8 lie, u8 a);
void Disp_1Num_VeBCD(u8 hang, u8 lie, u8 a); 




#define	fb_off_gb_off	0xEA						//���׹ع���1110_1010
#define	fb_on_gb_on	0xCE						//���׿���꿪1100_1110
#define	fb_off_gb_on	0xEE						//���׹ع�꿪1110_1110
#define	fb_on_gb_off	0xCA		  			    //���׿�����1100_1010

#define DSPBATTERYBMP   1
#define DSPBATTERYPOINT   0


#define LCDCENTERDISP   		0xFE//��ʾ����
#define LCDRIGHTDISP   			0xFD//��ʾ�Ҷ���
#define LCDLEFTDISP   			0xFC//��ʾ�����

#define LCD_REVERSRDISPON   	zimo =1 //������ʾ��
#define LCD_REVERSRDISPOFF   	zimo =0 //������ʾ��

#define  D0X 9
#define  DX  10
#define  DY  10


/*--------------LM240128C�������ŵĶ���------------------*/
//PF6	LCD_D2
//PF7	LCD_D3
//PF8	LCD_D4
//PF9	LCD_D5
//PF10	LCD_D6
//PF11	LCD_D7
//PG6	LCD_D1
//PG7	LCD_D0
#define db0_1  GPIO_SetBits(GPIOG, GPIO_Pin_7)
#define db0_0  GPIO_ResetBits(GPIOG, GPIO_Pin_7)

#define db1_1  GPIO_SetBits(GPIOG, GPIO_Pin_6)
#define db1_0  GPIO_ResetBits(GPIOG, GPIO_Pin_6)

#define db2_1  GPIO_SetBits(GPIOF, GPIO_Pin_6)
#define db2_0  GPIO_ResetBits(GPIOF, GPIO_Pin_6)

#define db3_1  GPIO_SetBits(GPIOF, GPIO_Pin_7)
#define db3_0  GPIO_ResetBits(GPIOF, GPIO_Pin_7)

#define db4_1  GPIO_SetBits(GPIOF, GPIO_Pin_8)
#define db4_0  GPIO_ResetBits(GPIOF, GPIO_Pin_8)

#define db5_1  GPIO_SetBits(GPIOF, GPIO_Pin_9)
#define db5_0  GPIO_ResetBits(GPIOF, GPIO_Pin_9)

#define db6_1  GPIO_SetBits(GPIOF, GPIO_Pin_10)
#define db6_0  GPIO_ResetBits(GPIOF, GPIO_Pin_10)

#define db7_1  GPIO_SetBits(GPIOF, GPIO_Pin_11)
#define db7_0  GPIO_ResetBits(GPIOF, GPIO_Pin_11)
//PG8	LCD_RES
//PG9	LCD_WR
//PG11	LCD_RD
//PG12	LCD_RS
//PG13	LCD_CS
//PG14	LCD/BL
//PG15	LCD/PW
#define lcd_res_1  GPIO_SetBits(GPIOG, GPIO_Pin_8)
#define lcd_res_0  GPIO_ResetBits(GPIOG, GPIO_Pin_8)

#define lcd_wr_1  GPIO_SetBits(GPIOG, GPIO_Pin_9)
#define lcd_wr_0  GPIO_ResetBits(GPIOG, GPIO_Pin_9)

#define lcd_rd_1  GPIO_SetBits(GPIOG, GPIO_Pin_11)
#define lcd_rd_0  GPIO_ResetBits(GPIOG, GPIO_Pin_11)

#define lcd_rs_1  GPIO_SetBits(GPIOG, GPIO_Pin_12)
#define lcd_rs_0  GPIO_ResetBits(GPIOG, GPIO_Pin_12)

#define lcd_cs_1  GPIO_SetBits(GPIOG, GPIO_Pin_13)
#define lcd_cs_0  GPIO_ResetBits(GPIOG, GPIO_Pin_13)

//ȡ��
#define LCD_back_ONOFF  GPIOB->ODR ^= (1<<13);
//#define LCD_back_ONOFF  {GPIOB->ODR ^= (1<<13);GPIOG->ODR ^= (1<<14);} //PG14

#define LCD_back_ON   GPIO_SetBits(GPIOG, GPIO_Pin_14)
#define LCD_back_OFF    GPIO_ResetBits(GPIOG, GPIO_Pin_14)

#define LCD_POWER_OFF	GPIO_ResetBits(GPIOG, GPIO_Pin_15)//��ʾ����Դ���ƽŴ򿪡��ر�
#define LCD_POWER_ON	GPIO_SetBits(GPIOG, GPIO_Pin_15)
/*--------------LM240128C�������ŵĶ���------------------*/

extern void LCD_pin_init(void);








#define nian 	    (0x20 * 0)        //��
#define yue  	    (0x20 * 1)        //��
#define ri 	    (0x20 * 2)        //��
#define shi 	    (0x20 * 3)        //ʱ
#define fen	    (0x20 * 4)        //��
#define miao	    (0x20 * 5)        //��
#define xing	    (0x20 * 6)        //��
#define qi	    (0x20 * 7)        //��
#define yi	    (0x20 * 8)        //һ
#define er	    (0x20 * 9)        //��
#define san	    (0x20 * 10)       //��
#define si	    (0x20 * 11)       //��
#define wu	    (0x20 * 12)       //��
#define liu	    (0x20 * 13)       //��
#define qing 	    (0x20 * 14)       //��
#define shua	    (0x20 * 15)       //ˢ
#define ka	    (0x20 * 16)       //��
#define yu	    (0x20 * 17)       //��
#define e	    (0x20 * 18)       //��
#define wei	    (0x20 * 19)       //δ
#define jie	    (0x20 * 20)       //��
#define suan	    (0x20 * 21)       //��
#define ke	    (0x20 * 22)       //��
#define ting	    (0x20 * 23)       //ͣ
#define dang	    (0x20 * 24)       //��
#define qian	    (0x20 * 25)       //ǰ
#define che 	    (0x20 * 26)       //��
#define shou	    (0x20 * 27)       //��
#define fei	    (0x20 * 28)       //��
#define xian	    (0x20 * 29)       //��
#define hao	    (0x20 * 30)       //��
#define yuan	    (0x20 * 31)       //Ԫ
#define ci	    (0x20 * 32)       //��
#define yong	    (0x20 * 33)       //��
#define bu	    (0x20 * 34)       //��
#define gu	    (0x20 * 35)       //��
#define zhang	    (0x20 * 36)       //��
#define lian	    (0x20 * 37)       //��
#define xi	    (0x20 * 38)       //ϵ
#define guan	    (0x20 * 39)       //��
#define li	    (0x20 * 40)       //��
#define gong	    (0x20 * 41)       //��
#define si_1	    (0x20 * 42)       //˾
#define cha         (0x20 * 43)       //��
#define xun         (0x20 * 44)       //ѯ
#define wei_1       (0x20 * 45)       //λ
#define zhan        (0x20 * 46)       //ռ
#define zhong       (0x20 * 47)       //��
#define shi_1       (0x20 * 48)       //ʹ
#define can         (0x20 * 49)       //��
#define shu         (0x20 * 50)       //��
#define geng        (0x20 * 51)       //��
#define xin         (0x20 * 52)       //��
#define wan         (0x20 * 53)       //��
#define bi          (0x20 * 54)       //��
#define tong        (0x20 * 55)       //ͳ
#define mi          (0x20 * 56)       //��
#define yao         (0x20 * 57)       //Կ
#define fu          (0x20 * 58)       //��
#define cheng       (0x20 * 59)       //��
#define gong_1      (0x20 * 60)       //��
#define kao         (0x20 * 61)       //��
#define qin         (0x20 * 62)       //��
#define da          (0x20 * 63)       //��
#define yu_1        (0x20 * 64)       //��
#define she         (0x20 * 65)       //��
#define bei         (0x20 * 66)       //��
#define jie_1       (0x20 * 67)       //��
#define jian        (0x20 * 68)       //��
#define zhi         (0x20 * 69)       //��
#define mi_1        (0x20 * 70)       //��
#define biao        (0x20 * 71)       //��
#define cuo         (0x20 * 72)       //��
#define wu_1        (0x20 * 73)       //��
#define dian        (0x20 * 74)       //��
#define ya          (0x20 * 75)       //ѹ
#define di          (0x20 * 76)       //��
#define geng_1      (0x20 * 77)       //��
#define huan        (0x20 * 78)       //��
#define chi         (0x20 * 79)       //��
#define xie         (0x20 * 80)       //д
#define chu         (0x20 * 81)       //��
#define chong       (0x20 * 82)       //��
#define kuan        (0x20 * 83)       //��
#define zu          (0x20 * 84)       //��
#define chu_1       (0x20 * 85)       //��
#define shi_2       (0x20 * 86)       //ʼ
#define hua         (0x20 * 87)       //��
#define xuan        (0x20 * 88)       //ѡ
#define ji          (0x20 * 89)       //��
#define lu          (0x20 * 90)       //¼
#define qing_1      (0x20 * 91)       //��
#define chu_2       (0x20 * 92)       //��
#define chong_1     (0x20 * 93)       //��
#define zhi_1       (0x20 * 94)       //ֵ
#define ju          (0x20 * 95)       //��
#define you         (0x20 * 96)       //��
#define xiao        (0x20 * 97)       //Ч
#define fan         (0x20 * 98)       //��
#define wei_2       (0x20 * 99)       //Χ
#define wu_2        (0x20 * 100)      //��
#define guo         (0x20 * 101)      //��
#define quan        (0x20 * 102)      //Ȩ
#define zai         (0x20 * 103)      //��
#define ci_1        (0x20 * 104)      //��
#define xiao_1      (0x20 * 105)      //��
#define tiao        (0x20 * 106)      //��
#define xia         (0x20 * 107)      //��
#define zai_1       (0x20 * 108)      //��
#define shi_3       (0x20 * 109)      //ʧ
#define bai         (0x20 * 110)      //��
#define jiao        (0x20 * 111)      //��
#define yi_1        (0x20 * 112)      //��
#define ni          (0x20 * 113)      //��
#define shi_4       (0x20 * 114)      //��
#define hei         (0x20 * 115)      //��
#define ming        (0x20 * 116)      //��
#define dan         (0x20 * 117)      //��
#define shang       (0x20 * 118)      //��
#define mei         (0x20 * 119)      //û
#define bu_1        (0x20 * 120)      //��
#define xu          (0x20 * 121)      //��
#define yao_1       (0x20 * 122)      //Ҫ
#define yi_2        (0x20 * 123)      //��
#define da_1        (0x20 * 124)      //��
#define zui         (0x20 * 125)      //��
#define gao         (0x20 * 126)      //��
#define dai         (0x20 * 127)      //��
#define ke_1        (0x20 * 128)      //��
#define bo          (0x20 * 129)      //��
#define bu_2        (0x20 * 130)      //��
#define huo         (0x20 * 131)      //��
#define mian        (0x20 * 132)      //��
#define cao         (0x20 * 133)      //��
#define zuo         (0x20 * 134)      //��
#define xian_1      (0x20 * 135)      //��
#define jin         (0x20 * 136)      //��
#define xing_1      (0x20 * 137)      //��
#define que         (0x20 * 138)      //ȷ
#define ren         (0x20 * 139)      //��
#define qu          (0x20 * 140)      //ȡ
#define jie_2       (0x20 * 141)      //��
#define suo         (0x20 * 142)      //��
#define wei_3       (0x20 * 143)      //ά
#define hu          (0x20 * 144)      //��
#define shao        (0x20 * 145)      //��
#define hou         (0x20 * 146)      //��
#define jia         (0x20 * 147)      //��
#define zhe         (0x20 * 148)      //��
#define du          (0x20 * 149)      //��
#define qi_1        (0x20 * 150)      //��
#define huan_1      (0x20 * 151)      //��
#define ying        (0x20 * 152)      //ӭ
#define shen        (0x20 * 153)      //��
#define zhen        (0x20 * 154)      //��
#define hua_1       (0x20 * 155)      //��
#define lu_1        (0x20 * 156)      //·
#define de          (0x20 * 157)      //��
#define zheng       (0x20 * 158)      //��
#define chang       (0x20 * 159)      //��
#define la          (0x20 * 160)      //��
#define ba          (0x20 * 161)      //��
#define jian_1      (0x20 * 162)      //��
#define ce          (0x20 * 163)      //��
#define tong_1      (0x20 * 164)      //ͨ
#define xin_1       (0x20 * 165)      //��
#define zhu         (0x20 * 166)      //ף
#define shun        (0x20 * 167)      //˳
#define feng        (0x20 * 168)      //��
#define zai_2       (0x20 * 169)      //��
#define jian_2      (0x20 * 170)      //��
#define quan_1      (0x20 * 171)      //ȫ
#define zeng        (0x20 * 172)      //��
#define jian_3      (0x20 * 173)      //��
#define liang       (0x20 * 174)      //��
#define jia_1       (0x20 * 175)      //��
#define fa          (0x20 * 176)      //��
#define song        (0x20 * 177)      //��
#define ge_1        (0x20 * 178)      //��
#define xiao_2      (0x20 * 179)      //С
#define zhong_1     (0x20 * 180)      //��
#define yun         (0x20 * 181)      //��
#define tian        (0x20 * 182)      //��
#define yi_3        (0x20 * 183)      //��
#define ca          (0x20 * 184)      //��
#define kai         (0x20 * 185)      //��
#define li_1        (0x20 * 186)      //��
#define an          (0x20 * 187)      //��
#define wang        (0x20 * 188)      //��
#define chao        (0x20 * 189)      //��
#define xu_1        (0x20 * 190)      //��
#define cheng_1     (0x20 * 191)      //��
#define xu_2        (0x20 * 192)      //��
#define sheng       (0x20 * 193)      //��
#define ji_1        (0x20 * 194)      //��
#define yuan_1      (0x20 * 195)      //Զ
#define zi          (0x20 * 196)      //��
#define shou_1      (0x20 * 197)      //��
#define dong        (0x20 * 198)      //��
#define lv          (0x20 * 199)      //��
#define shou_2      (0x20 * 200)      //��
#define qi_2        (0x20 * 201)      //��
#define ling        (0x20 * 202)      //��
#define nan_1       (0x20 * 203)      //��
#define zuo_1       (0x20 * 204)      //��
#define you_1       (0x20 * 205)      //��
#define di_1        (0x20 * 206)      //��
#define ban         (0x20 * 207)      //��
#define chang_1     (0x20 * 208)      //��
#define qian_1      (0x20 * 209)      //Ƿ
#define fu_1        (0x20 * 210)      //��
#define hou_1       (0x20 * 211)      //��
#define lian_1      (0x20 * 212)      //��
#define qiu         (0x20 * 213)      //��
#define jiao_1      (0x20 * 214)      //��
#define huo_1       (0x20 * 215)      //��
#define cha_1       (0x20 * 216)      //��
#define sheng_1     (0x20 * 217)      //ʣ
#define ba_1     	(0x20 * 218)      //��
#define jie_3		(0x20 * 219)      //��
#define zhi_2		(0x20 * 220)      //ֹ
#define yu_2		(0x20 * 221)      //Ԥ
#define mai			(0x20 * 222)      //��
#define ji_2		(0x20 * 223)      //��





#define qing_32X32    (0x80 * 0)      //��
#define shua_32X32    (0x80 * 1)      //ˢ
#define ka_32X32      (0x80 * 2)      //��
#define gu_32X32      (0x80 * 3)      //��
#define zhang_32X32   (0x80 * 4)      //��
#define yi_32X32      (0x80 * 5)      //1
#define chong_32X32   (0x80 * 6)      //1
#define xin_32X32     (0x80 * 7)      //1






/*
#define lcd_cmd_addr	P0
#define lcd_cmd_data	P0
#define lcd_data	P0
sbit lcd_wr = P2^0;
sbit lcd_rd = P2^1;
sbit lcd_cs = P2^2;
sbit lcd_rs = P2^3;
sbit lcd_rst   = P2^4; 
sbit LCD_LIGHT  = P2^5; 
sbit LCD_Power = P2^6;
*/
void lcd_cmd_write(unsigned char cmd_adr,unsigned char cmd_data);
void delay(unsigned long t);	
void delayNs(u16 t);//��ʱ����

//�������п�ʼ�ȼ��ش�3��
void display_V(void);
void display_V1(void);
void display_A(void);
void display_A1(void);
void display_P(void);
void display_P1(void);
void display_C(void);
void display_C1(void);
void display_money(void);
void display(void);
void lcd_reset(void);	 								//�����ӳ���
void lcd_initial(void); 	  							//�������л������ĳ�ʼֵ
void lcd_clear(void); 	                                //�����ʾ�ڴ� �ӳ���
void LCD_GPIOE_INIT(void);
void LCD_INIT(void);
void LCD_INIT_2(void);
void goto_xy(unsigned char cursor_x,unsigned char cursor_y);
//void print_str_32_32(unsigned char *ptr);
void LCD_no(unsigned char shu1);
void LCD_Sring1(char  *ptr); 
void print_num16_16(unsigned char shu_tmp);
void print_num32_32(unsigned char buf_num);
void print_num_48_48(unsigned char buf_num);
void print_str_48_48( char *ptr);
void print_str_16_16( char *ptr);
void print_str_16_32( char *ptr);
void print_str_32_32( char *ptr);
void print_str_48_48(char *ptr);
//void print_num16_16(unsigned char buf_num);
void print_num16_char(unsigned char buf_num);
void print_num16_char_num(unsigned char cnt_num);
void print_asi( char buf_num);
void display_dianfei(float dianfei11);
void display_feilv(float feilv1);
void disp_feilv(unsigned int u_time,unsigned int u_money,unsigned int d_money,unsigned int y_money);
void control_buf_wccr(unsigned char  cmd_cursor);
void cursor_flash_time(unsigned char  flash_time);
void print_num32_32_1(unsigned char buf_num);
void print_char_st(unsigned char StPos,unsigned char buf_char);
//void arab_mode(u8 cursor_x,u8 cursor_y,u8 numb_8,const unsigned char *spr);
void lcd_test(void);
unsigned char delayout(unsigned long value);

void HZ_write(uchar hang,uchar lie,uchar *data);
void dispaly(uchar row,uchar column,uchar *data);
void LCD_display_symbol(uchar row,uchar column,uchar data,uchar flag);
void LCD_display_no(uchar row ,uchar column ,uchar shu1);

void display_time(uchar year,uchar month,uchar date,uchar hour,uchar minute);
void display_please_swid_card(uchar year,uchar month,uchar date,uchar hour,uchar minute,uchar car,uchar Times);
void display_frist_swid_card(unsigned int momery,uchar times);
void display_frist_time(uchar Card_No[],uchar allow_T_hour,uchar allow_T_min,uchar park_count,uchar YXRQ[]);
void dispaly_32X32(uchar row,uchar column,uchar *data);
void display_second_time(uchar Card_No[],uchar hour,uchar min,int momery,uchar park_count,uchar YXRQ[]);
void display_select_momery(void);
void display_select_result(uchar card_NO_1,uchar card_NO_2,uchar card_NO_3,uchar card_NO_4,unsigned long momery,uchar times,uchar free_count);
void display_car_statue(uchar card_NO_1,uchar card_NO_2,uchar card_NO_3,uchar card_NO_4,uchar hour,uchar min,long momery);
void display_replayMent(uchar hour,uchar min,long momery);
void diplay_problem(void);
void carStation_using(void);
void monthCard_using();//��ʾ �¿�ʹ����
void manageCARD_update(); //��ʾ �����������
void resetCARD_using(); //��ʾ ��λ��ʹ����
void resetCarstation_success(uchar card_NO[],uchar *InTime,int park_time,uchar car);//��ʾ ��λ��λ״̬�ɹ�
void timecard_using();  // ��ʾ ���ڿ�ʹ����
void timecard_OK(uchar card_buffer[]);//��ʾ ���ڴ򿪳ɹ�
void deveice_linking();//��ʾ ���豸������...
void time_setup_success();//��ʾʱ�����óɹ�
void mibiao_NO_setup_success();//��ʾ ��������óɹ�
void connect_false();//��ʾ ���Ӵ���
void voltage_low(void);//��ʾ ��ѹ�� ��������

void write_card_error(uchar error_flag);//��ʾ д������ ������ˢ��

void replay_momery(long R_momery,long E_momery,uchar flag);//��ʾ ������ �������
void no_momery(long momery,u8 sw); //��ʾ����
void display_sysytem_init();
//��ʾ ������¿�                
void display_your_is_monthCard(void);




//
void display_1(uchar card_NO[],uchar hour,uchar min,unsigned long momery,uchar card_flag,u8 pktime);

void display_2(uchar card_NO[],uchar hour,uchar min, long left_momery,long momery,uchar card_flag);



void data_clearing();


void display_month_card_selectResult(uchar card_no[],uchar start_buffer[],uchar end_buffer[],uchar YXRQ[]);

void display_logo();

void display_Logo_1(uchar car_flag);

void car_outdate(void);

void mibiao_error(void);

//��ʾ ��ѯ���Ĺ���
void check_card(void);

//��ʾ ����������...
void data_download(void);


//��ʾ �������سɹ�
void data_download_success(uchar flag);

void ip_setup(uchar flag);

void replement_success(uchar flag);


//��ʾ ����ʧ�� ������ˢ��
void Return_SW_card();

//��ʾ ���Ǻ�����
void display_backList(void);

//��ʾ �ϴ�δ���� ���Ȳ���
void display_outstanding(void);

//��ʾ û��δ���� ����Ҫ����
void display_no_outstanding(void);

//��ʾ �Ѵ���ߴ��Ͳ�������
void display_max_park_count(void);


//��ʾ ��������� �ɹ� �� ʧ��
void display_catch_backList(uchar flag);

void display_month_card_F(uchar card_no[],uchar parkf_time[],uchar start_buffer[],uchar end_buffer[],uchar YXRQ[]);
void display_month_card_S(uchar start_buffer[],uchar end_buffer[],uchar YXRQ[]);

//��ʾ ����ʧ��
void display_operation_false(void);

//��ʾ ��λûʹ�� ����Ҫ��λ
void display_no_reset(void);

void display_please_operation(uchar year,uchar month,uchar date,uchar hour,uchar minute,uchar flag);

//��ʾ ���в������ ȷ�� ȡ��
void display_replaymenory(uchar flag);

void display_recover_BACLK_LIST(uchar flag);

void display_no_backList(void);

void display_recover_BL(void);

//��ʾ ��Ч��
void no_use_card(uchar error_flag);

void dispaly_32_32(uchar row,uchar column,uchar *data);

//��ʾ ϵͳά���� ���Ժ�...
void display_sysytem_Maintaining(void);

//��ʾ ����
void display_rate(void);

//��ʾ ����������
void display_reader_P(uchar flag,uchar clow);


//��ʾ ����������
void display_PSAM(uchar flag,uchar clow);

//��ʾ ϵͳ��Կ�������
void encryptCARD_update(); 

void display_clear_success();

void display_setup_mibiao(void);

void Voltage_Check(uchar flag,uchar clow);

void buzz_check(uchar clow);

void LED_check(uchar clow);

void Communation_check(uchar clow);

void Communation_OK(uchar flag,uchar clow);

void DisplaySystem_Status(uchar Volate,uchar Reader,uchar PSAM);

void display_debug_infornation(uchar *buffer,uchar len);


//��ʾ ף��һ·˳��
void LeaveBlessing(void);

void DisplayBcakList(unsigned long AllCount,unsigned long IncCount,unsigned long DecCount,uchar DownFlag);

void LcdALL(void);

void lcd_clear_h(unsigned char hang);

void displaySendRecord(void);

//��ʾ �������ʱ��
void MaterRunT(void);

void MoneryException(void);

void FLASH_Erased(void);

void RecordSelectDisplay(uchar *CardNo,uchar *InTime,int StopTime,uchar *StopMoney,uchar count);

void displaySelectRecordAndInfo(uchar car);

void displayResetInfo(uchar *CardNo,uchar *InTime,int OverTime,int OvertimeMonery);

void displayProgressBar(uchar row,uchar ProgressValue);

void displayIAP(void);

void DisplayMIFAREBcakList(unsigned long IncCount,unsigned long DecCount);

void displayLNT_BackList(void);

void monthCarOut(void);

void monthCarNoOut(void);
void disptestbar();
void diplay_error(u8 errcode);



void print_XYstr_16_16(u8 X,u8 Y, char  *pbuftmp);
void Display_16HZ(u8 page,u8 column,u8 index[2]);
void print_16x16GB(u8 page,u8 column,u8 * sentence);

void print_num2(unsigned char buf_num);
void print_num2(unsigned char buf_num);

void FLASH_check(uchar clow);
void G24_check(uchar clow);
void FROM_check(uchar clow);

void pdahand_linking();

void disp_overdraft_info(uchar card_NO[],uchar use_time[],s32 momery);
void list_download(u32 disp);
void SRAM_check(uchar clow);
void disp_horoad_ewm(void);
void data_download_bag(u8 ngt,u16 bag1A,u16 bag1,u16 bag2A,u16 bag2);
void display_prebuy_menu(u8 cardno[4],u32 momery,u32 feemny,u16 pktime,u16 apktime,u16 times,u8 flag);
void delayms(u16 t);
void test_key(void);
void display_32s();
void Deal_MainMenu(void);
void disp_IPno_Port(u8 dx,u8 dy);
void disp_Mbno(u8 dx,u8 dy);
void disp_coin_return(void);
void display_coin_interface(void);
void disp_sleep_menu(void);
void disp_Beyond_20pcs(void);
void disp_please_swipecard(u8 retime);
void disp_card_err(u8 errcode);
void pls_wt_Printing_ticket(void);
void disp_nouse_error(void);
void disp_Illegal_card(void);
void disp_Successful(void);
void disp_money_too_low(void);
void disp_money_mfcardfee(u32 omny,u32 fmny);
void disp_ip_setsucess(void);
void disp_money_balance(u8 dx);
u8 do_menu(u8 const **dispstr,u8 MHx,u8 MHnum,u8 MHju);
void disp_dif_cardtype(void);
void lcd_ch(u8 dx);
void Deal_SYS_MDState(u8 flag);
void Do_Illegalopen(u8 doors);
void BUZZ_State(u8 STA);
void disp_sys_nouse(u8 mode);
void disp_Recharge_Processing(void);
void disp_ticket_remind(void);
u8 JD_DOOR_OPEN(void);
int StringFind(u8 *pSrc,u8 *pDst);
u8 Do_Night_Pro(void);
void disp_other_error(void);
void sys_error_user(void);
void Draw_Dot(unsigned int x,unsigned int y);
void Draw_Line(unsigned int x1,unsigned int y1,unsigned int x2,unsigned int y2);
void ShowBMP_01(unsigned int x,unsigned int y,unsigned int width,unsigned int high,unsigned char bmp[]);
void lcd_clearxy1(u8 x, u8 y);

void ShowBMP(uchar x,uchar y,uchar width,uchar high,uchar const bmp[]);
void PrintASCII16(uchar x, uchar y, uchar const *pstr);
void Disp_PictureStrNew(u8 x,u8 y,u8 width,u8 high,u8 const bmp[]);





#endif
