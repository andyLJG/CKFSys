#ifndef _Memory_H_
#define _Memory_H_


#include "stdio.h"
#include "string.h"
#include "stm32f10x_conf.h"
#include "hal.h"
#include "MemoryAssign.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Key.h"
#include "Count.h"
#include "Coin.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include "Gprs_online.h"
#include "stm32f10x_pwr.h"
#include "stm32f10x_wwdg.h"
#include "main.h"
#include "rate.h"
#include "loader.h"
#include "spi_flash.h"
#include "fsmc_sram.h"


u8 read_car_station(u8 car);
uchar write_BlackList_count_to_IIC(u32 count,u8 flag);
u32 read_BlackList_count_from_IIC(u8 flag);
void read_Blacklist_to_Memory();
u32 binary_Menmory_Select(u32 ReadAddr,u8 *data,u32 low,u32 height);
uchar select_BlackList_from_Menmory(u8 *BlackList_Buffer);
uchar binary_Buffer_Select(u32 ReadAddr,u8 *data,long low,long height);
void erase_flash_4K(uint32_t SectorAddr,int flag);


//�� �ڴ� ���� ������      
//output  :  0 ��ʾû�ҵ�
//output  :  ����ֵΪ�ҵ���λ��
uchar select_BlackList_from_Menmory_day(u8* BlackList_Buffer,uchar ClassFlag,uchar Flag);

#endif