#include "stm32f10x_conf.h"
#include "hal.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "I2C_Driver.h"
#include "Count.h"
#include "Key.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include "Gprs_online.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_it.h"
#include "misc.h"
#include "math.h"
#include "Card.h"
#include "MemoryAssign.h"
#include "spi_flash.h"
//extern __IO uint32_t FlashID;
//extern u32 FlashID;
extern u8 parking_station;
extern unsigned int Time1Start,Time1End,Time2Start,Time2End,Time3Start,Time3End,Time4Start,Time4End;
extern unsigned int MyMoney,MyTime,MaxTime,MINTime,MINMoney,BaseMoney5,BaseTime5,BaseMoney6,BaseMoney7; 
extern u16 LimitTime_CARD,LimitMoney_CARD;


unsigned long hcl(unsigned char bufa[],unsigned char b)
{
  unsigned long  FD;
  unsigned char  a;
  FD=0;
  for(a=0;a<b;a++)     
  {
     FD=FD<<8;   
     FD=FD+bufa[a];   
  }                 
     return FD; 
} 

  
void fll(unsigned long FD,unsigned char bufa[],unsigned char b)
{   
	unsigned char  a;
     for(a=0;a<b;a++)                
     bufa[b-1-a]=FD>>(a*8);          
	 return;
}

void save_add_char(unsigned int addr0,unsigned char num)
{
  unsigned char  buf[2];
  unsigned int  f;

	I2C_ReadS_24C(addr0,buf,2);
	f= buf[0];
	f=f<<8;   
	f=f+buf[1];  
	f=f+num;
	buf[0] = f>>8;
	buf[1] = f;  
	I2C_WriteS_24C(addr0,buf,2); 
	return;
}
void save_add_three(unsigned int addr0,unsigned char num)
{
  unsigned char  buf[3];
  unsigned long  f;

	I2C_ReadS_24C(addr0,buf,3);
	f = buf[0]<<16;
	f += buf[1]<<8;
	f += buf[2];  
	f += num;
	buf[0] = f>>16;
	buf[1] = f>>8;
	buf[2] = f;  
	I2C_WriteS_24C(addr0,buf,3); 
	return;
} 

void save_add_long(unsigned int addr0,unsigned int num)
{
  unsigned char  buf[4];
  unsigned long  f;
  
    I2C_ReadS_24C(addr0,buf,4);
	f  =buf[0]<<24;
	f+=buf[1]<<16;
	f+=buf[2]<<8;
	f+=buf[3];  
	f+=num;
	buf[0] = f>>24;
	buf[1] = f>>16;
	buf[2] = f>>8;
	buf[3] = f;  
 	I2C_WriteS_24C(addr0,buf,4); 
	return;
} 
/*----------------------------------------------------------------------
function name:   	unsigned char  DEC_to_HEX(unsigned char DEC)
describe:    	 	ʮ����תʮ������
input:   			
output:
date:			andyluo 2010-12-03 14:26:57
------------------------------------------------------------------------*/
unsigned char  DEC_to_HEX(unsigned char DEC)
{
	unsigned char HEX;

	HEX =( DEC/16)*10+(DEC%16);
		
	return HEX;
}
///////////////////////////////////////
/*
void timeexchange(void)
{
    time1[4]=(((time[4]>>4)&0x0f)*10)+(time[4]&0x0f);
    time1[3]=(((time[3]>>4)&0x0f)*10)+(time[3]&0x0f);
    time1[2]=(((time[2]>>4)&0x0f)*10)+(time[2]&0x0f);
    time1[1]=(((time[1]>>4)&0x0f)*10)+(time[1]&0x0f);
    time1[0]=(((time[0]>>4)&0x0f)*10)+(time[0]&0x0f); 
}*/


///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void math_time(unsigned long utime,unsigned char time2[])
{
	 utime=utime+time1[0];
	 time2[0]=utime%60;
	 utime=utime/60;
	 utime=utime+time1[1];
	 time2[1]=utime%24;
	 utime=utime/24;
	 utime=utime+time1[2];
	 if(time1[2]==2)
	 {
	  if((time1[4]%4)==0)
	  {
	          time2[2]=utime%30;
			  utime=utime/30;
			  if(time2[2]==0)
			  {
			   time2[2]=1;
			  }
	  }
	  else
	  {
	          time2[2]=utime%29;
			  utime=utime/29;
			  if(time2[2]==0)
			  {
			   time2[2]=1;
			  }
	  }
	 }
	 else
	 {
		 if((time1[2]==4)&&(time1[2]==6)&&(time1[2]==9)&&(time1[2]==11))
		 {
		      time2[2]=utime%31;
			  utime=utime/31;
			  if(time2[2]==0)
			  {
			   time2[2]=1;
			  }
		 }
		 else
		 {
			  time2[2]=utime%32;
			  utime=utime/32;
			  if(time2[2]==0)
			  {
			   time2[2]=1;
			  }
		 }
	  } 
	 utime=utime+time1[3];
	 time2[3]=utime%13;
	 if(time2[3]==0)
	 {
	  time2[3]=1;
	 }
	 utime=utime/13;
	 time2[4]=utime+time1[4];
	 return;
}
///////////////////////////////////////////////////////////////////////////////
void math_time1(unsigned long utime,unsigned char time5[],unsigned char time2[])
{
	 utime=utime+time5[0];
	 time2[0]=utime%60;
	 utime=utime/60;
	 utime=utime+time5[1];
	 time2[1]=utime%24;
	 utime=utime/24;
	 utime=utime+time5[2];
	 if(time5[2]==2)
	 {
	  if((time5[4]%4)==0)
	  {
	          time2[2]=utime%30;
			  utime=utime/30;
			  if(time2[2]==0)
			  {
			   time2[2]=1;
			  }
	  }
	  else
	  {
	          time2[2]=utime%29;
			  utime=utime/29;
			  if(time2[2]==0)
			  {
			   time2[2]=1;
			  }
	  }
	 }
	 else
	 {
		 if((time5[2]==4)&&(time5[2]==6)&&(time5[2]==9)&&(time5[2]==11))
		 {
		      time2[2]=utime%31;
			  utime=utime/31;
			  if(time2[2]==0)
			  {
			   time2[2]=1;
			  }
		 }
		 else
		 {
			  time2[2]=utime%32;
			  utime=utime/32;
			  if(time2[2]==0)
			  {
			   time2[2]=1;
			  }
		 }
	  } 
	 utime=utime+time5[3];
	 time2[3]=utime%13;
	 if(time2[3]==0)
	 {
	  time2[3]=1;
	 }
	 utime=utime/13;
	 time2[4]=utime+time5[4];
//	 return;
}







