void audio (u8 addr);
void audio_data(u8 num);
void money_audio() ;
void time_audio();
