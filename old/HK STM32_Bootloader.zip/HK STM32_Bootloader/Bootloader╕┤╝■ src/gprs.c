#include "stm32f10x_conf.h"
#include "hal.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Count.h"
#include "Key.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include "Gprs_online.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_it.h"
#include "misc.h"
#include "math.h"
#include "main.h"
#include "Card.h"
#include "MemoryAssign.h"
#include "Do_Task.h"
//write by andyluo in 2010

////***************************************ASCII ת��Ϊ��BCD********************************************************
unsigned char asic_to_hex(unsigned char rr)
{
  unsigned char c1;

  if(rr<0x3A)
  	c1=rr-0x30;
  else
  	c1=rr-0x37;
  return c1;
}

//andyluo
unsigned char twoasic_to_oenhex(unsigned char *recvgsmproc,u8 ASCII)
{//2///2=1+2=1   1+1=1  36 41 36 44 ==14
  unsigned short i,j;
  unsigned char hex,hex1,hex2,hex3;
  
  //hex3 = 4;
  hex3 = 2;
  j = 0;
  for(i=0;;i++){
  	
    j =i*hex3;	
    if(recvgsmproc[j+1] == '*'){
  		
      recvgsmproc[i+1] = '*';		
      break; 		
    }
  	
    hex = asic_to_hex(recvgsmproc[j+1]);
    hex1 = asic_to_hex(recvgsmproc[j+2]);
    hex = hex<<4;
    hex = hex+hex1;
    hex2 = hex - '9';//31		
	
    if(hex3 == 2){
		
      recvgsmproc[i+1] = hex2;	
      continue;
		
    }
    if(ASCII||(hex2>'F')){

      recvgsmproc[i+1] = hex2;	
      hex3 = 2;	
      j = j/2;
      continue;
		
    }
  	
    hex = asic_to_hex(recvgsmproc[j+3]);
    hex1 = asic_to_hex(recvgsmproc[j+4]);
    hex = hex<<4;
    hex = hex+hex1;
    hex1 = hex-'9';//34	

    hex = asic_to_hex(hex2);
    hex2 = asic_to_hex(hex1);
    hex = hex<<4;
    hex = hex+hex2;
    recvgsmproc[i+1] = hex;		
	
  }
	
  return 1;
}

void open_gprs_power()
{
	WCDMA_Power_ON;
	delay(10000);//andyluo2011-02-12
}


void open_gprs_uart()
{
	 delay(1000);//andyluo2011-02-12
}
void close_uart()
{
	 delay(5);
 }
void close_gprs_power()
{
	 WCDMA_Power_OFF;
	 delay(10000);//andyluo2011-02-12
}



u8 rec_gprs(unsigned long delay_wait,unsigned char *shujv,u8 change)//andyluo2011-02-12
{	
  unsigned short i;
  u32 ack_err;       
  RxCounter = 0;
  ack_err = delay_wait *KEYTIMEOUT_1S;
  while(ack_err--){
             
    if(key_flag)
    {
        return 0;           
    }
    
    if(RxBuffer[RxCounter-1] != '*')
        continue;
    if(RxCounter!=300){
        for(i=0;i<RxCounter;i++)
            shujv[i] = RxBuffer[i];
        return 1;
    }
    else{			
        shujv[5]='*';
        return 0;
    }

  }
  return 0;
}

//����GPRS��Ӧ��
uchar rec_gprs_ack(uchar delay_wait)
{
    u32 timeOut;
    timeOut = delay_wait * KEYTIMEOUT_1S;
    while(timeOut--)
    {
        if(f_receiveOK == OK)
        {
            for(int i=0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && (RxBuffer[i] == 'E') && (RxBuffer[i + 1] == 'r') && (RxBuffer[i + 2] == 'r') && (RxBuffer[i + 3] == 'o') && (RxBuffer[i + 4] == 'r'))
                  return asic_to_hex(RxBuffer[i + 11]);
            }

        }
        
        if(key_flag)
        {
            return 1;            
        }
    }
    return 1;
}



uchar rec_gprs_Time(uchar delay_wait,int data[])
{
    u32 ack_err;
    int i;
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
        if(f_receiveOK == OK)
        {
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'i' && RxBuffer[i + 2] == 'm' && RxBuffer[i + 3] == 'e' )
                {                   
                      data[0] = i + 6;
                      break;
                }
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'i' && RxBuffer[i + 2] == 'm' && RxBuffer[i + 3] == 'e' )
                {                   
                      data[1] = i - 3;
                      return 1;
                }
            }
                     
            break;
        }
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x00;
    
    return 0x00;
}

uchar rec_gprs_Free(uchar delay_wait,int data[])
{
    u32 ack_err;
    int i;
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
        if(f_receiveOK == OK)
        {
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'F' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'e')
                {                   
                      data[0] = i + 5;
                      break;
                }
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'F' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'e')
                {                   
                      data[1] = i - 3;
                      return 1;
                }
            }
                     
            break;
        }
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x00;
    
    return 0x00;
}







u8 rec_gprs_L(uchar delay_wait,int data[])
{
    u32 ack_err;
    int i;
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
        if(f_receiveOK == OK)
        {
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && (RxBuffer[i] == 'M') && (RxBuffer[i + 1] == 'e') && (RxBuffer[i + 2] == 't') && (RxBuffer[i + 3] == 'n') && (RxBuffer[i + 4] == 'o'))
                {
                    for(int j=0;j<6;j++)
                      data[j] = RxBuffer[i + 7 + j];//7
                }
                
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'N' && RxBuffer[i + 1] == 'i' && RxBuffer[i + 2] == 't' && RxBuffer[i + 3] == 'e' && RxBuffer[i + 4] == 'm')
                {
                    for(int j=6;j<10;j++)
                      data[j] = RxBuffer[i + j + 1];
                }
                
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'h' && RxBuffer[i + 1] == 'm' && RxBuffer[i + 2] == 'd' && RxBuffer[i + 3] == 'S' && RxBuffer[i + 4] == 'e')
                {
                    for(int j=10;j<14;j++)
                      data[j] = RxBuffer[i + j - 2];
                }
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'x' && RxBuffer[i + 3] == 't' )
                {                   
                      data[14] = i + 6;
                      break;
                }
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'x' && RxBuffer[i + 3] == 't' )
                {                   
                      data[15] = i - 3;
                      return 1;
                }
            }
                     
            break;
        }
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x00;
    
    return 0x00;
}
////////////////////////////////////////////////////////////////////////////////////////////////
u8 rec_gprs2(unsigned long delay_wait,unsigned char *shujv,u8 change)//andyluo2011-02-12
{
	unsigned short i;
	unsigned char a;
	u32 ack_err;
        
	RxCounter = 0;
	ack_err = delay_wait * KEYTIMEOUT_1S;
	while(ack_err--)  
	{

		if(key_flag)
			{
			a = key_scan1();
			if(a == KEY_Cancel)
			{	
			return 0xe7;
			}
			}                  
		if(RxBuffer[RxCounter-1] != '*')
			continue;
		if(RxCounter!=300)
			{
			for(i=0;i<RxCounter;i++)
				shujv[i] = RxBuffer[i];
		
			return 1;
			}
		else
			{			
			shujv[5]='*';
			return 0;
			}

	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////

u8 rec_gprs1(unsigned long delay_wait,unsigned char *shujv)//andyluo2011-02-12
{
 // unsigned char a;
  unsigned long i,ack_err;
  

		RxCounter = 0;
		ack_err = KEYTIMEOUT_1S*delay_wait;
		while(ack_err--)  
			{
                          if((ack_err==1)&&(ack_err==0))
                            return 0;
			if(RxBuffer[RxCounter-1] == 0x0D)
				break;
			}
		for(i=0;i<RxCounter;i++)
			shujv[i] = RxBuffer[i];

			return 1;
}



//ip:192.168.1.87 ���֣�PaymentDB �û�����sa ���룺316116

//software_sever IP and port.
void send_ip(unsigned char *IP_Add,unsigned char *PORT)
{
     //unsigned char sz7[20];
     //unsigned char k,i;//,Comport;

	 uart_send_som("*I0P");
         uart_send_som("<");
         uart_send_som(IP_Add);
         uart_send_som(">");
         
         uart_send_som("<");
         uart_send_som("PT");
         uart_send_som(">");
         
         uart_send_som("<");
         uart_send_som(PORT);
         uart_send_som(">");
         
         uart_send_som("<AN><1,\"IP\",\"ctnet\">#");
          
         /*
	 for(k=1;k<sz7[0]+1;k++)
	 	{
	 	uart_send(sz7[k]);
		if(sz7[k] == 'P')
			i = k+1;
	 	}
	 uart_send_som(",");
	 for(k=i;k<sz7[0]+1;k++)
	 	uart_send(sz7[k]);
	 uart_send_som("#");
	 
	 return;
         */
}

void send_data(unsigned char *data)
{
    uart_send_som("*0%");
    uart_send_som(data);
    uart_send_som("#");
    
}
void send_apn()
{
     unsigned char sz7[80];
     unsigned int k;
//     unsigned char a,kk;
     unsigned char kk;

      uart_send_som("*APN");     
      kk=0;
	 for(k=0;k<64;k++)     
	 {
            uart_send(sz7[k]);
	    if(sz7[k]=='"')
	        kk=kk+1;
	    if(kk==6)
	        break;
	 }
         uart_send_som("#");         

}
///////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////

u8 Link_DPS(void)
{
	u8 netstate;
	u32 linkacktime;
	delay(KEYTIMEOUT_1S);
	send_DPSip();
	delay(KEYTIMEOUT_1S*2);
	Wakeup__3G_CDMA;	
	netstate = NG;
	linkacktime = KEYTIMEOUT_1S*30;
	while(linkacktime--)
		{
		if((RxBuffer[1] == 'L')&&(RxBuffer[3] == 'k'))
			{
			gprs_user = OK;
			netstate = OK;
			break;	//#Lok*  �����ɹ�	
			}
		}
	if(netstate == OK)
		{
                  
		delay(KEYTIMEOUT_1S/2);
		GPRS_CSQ(Ishide);
		Refresh_SYSallicon();
		delay(KEYTIMEOUT_1S/2);
		}
	return netstate;
	
}

u8 Link_network(void)
{
      unsigned char sz7[10];
      unsigned int k,quit_flag = 0;
      
      
      read_IP();
      send_ip(IP,PORT);

          unsigned short i;
          u32 ack_err;   
          
          for(int i=0;i<RxCounter;i++)
          RxBuffer[i] = 0x00;    
          RxCounter = 0;   
          f_receiveOK = 0;
          
          ack_err = 3 * KEYTIMEOUT_1S;
          while(ack_err > 0){
             
            ack_err--;
              if(key_flag)
              {
                  quit_flag =1;
                  break;           
              }
        
              if(RxBuffer[RxCounter-1] != '*')
                  continue;
              
              if(RxCounter <= 100){
                  for(i=0;i<RxCounter;i++)
                      sz7[i] = RxBuffer[i];
                  quit_flag = 2;
                  break;
              }
              else{			
                  sz7[5]='*';
    
              } 
          }

	
	if(quit_flag == 1)		
		return 0;
	else if(quit_flag == 2)
	{
		//#IP*  �����ɹ�		
		for(k=0;k<100;k++)
		{
                    if(sz7[k]=='#')
                    {
                        if(sz7[k+1]=='I' && sz7[k+2]=='P' && sz7[k+3]=='*')
                        {                            		
                            return 1;	
                        }
                        return 0;
                    }			
		}		
		return 0;
	}
        else
        {
            return 0;
        }
}
////********************************************
void close_gprs_power1()
{
	close_uart();
	delay(500);
	return;
}
//Center sever:disconnect      DPS sever: connect        CS.:��DS.:��
u8 open_gprs()
{
	 //close_gprs_power();
	// delay(10000);
	 delay(KEYTIMEOUT_1S / 10);         
	 open_gprs_power();
	u32 timeOut=0;
                            while(timeOut < KEYTIMEOUT_1S * 12)
                            {
                               if(key_flag){
                                  //key_flag = 0;
                               break;
                               }
                               timeOut++;
                            }
	 return Link_network();
}
//13561876078
