#ifndef __RATE_H
#define __RATE_H

#define free_time    0
#define forbid_time  1
#define time_time    2
#define once_time    3 

extern unsigned char time_now[6];
char check_freeday(void);
char re_table(void);
//int time2rate(int time_S[]);	
int time2rate(void);	
int HMW2rate(int t_H,int t_M,int t_W);
char money2time(unsigned long get_money);
char money2time1(unsigned long get_money);
char time2money(unsigned long get_time);
unsigned char check_charge(void);
unsigned char check_charge1(void);
void LoadValue(void);
#endif
