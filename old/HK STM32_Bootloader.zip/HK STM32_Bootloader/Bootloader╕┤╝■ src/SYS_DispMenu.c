#include "stm32f10x_conf.h"
#include "hal.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Key.h"
#include "Count.h"
#include "Coin.h"
#include "SYS_DispMenu.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "Ir_comm.h"
#include "math.h"
#include "Gprs.h"
#include "Gprs_online.h"
#include "MemoryAssign.h"
#include "String.h"
#include "spi_flash.h"
#include "I2C_Driver.h"
#include "St_credit.h"
#include "rate.h"
#include "main.h"

u8  Key_Value,no_x_y = 0;
u8  FMI2C_buf[64];
extern u8 chewei;
extern u8 parking_station;
extern u8 sz1[10300];
extern long Good_money;
unsigned char time[7],time1[7],time10[7];//,time2[6];

u32 KEY_TIMEOUT;
u8  menunum = 1;
u16 Loopdata,Loopdatalength;
extern u8 tik_No;
extern unsigned char uart_rec2(u32 b);
extern unsigned char uart_rec1(u32 b);
extern void Open_Coin_Power(void);
extern void Close_Coin_Power(void);
void SYS_DO_BUSY_ICON(u8 x1, u8 y1,u8 x2, u8 y2,u8 state);
u8 JD_SYStime(void);
u8 JD_SYStime1(void);
u8 SYSVision[12],CASH_FUC;

void Eaturn_Coin(void);









/*----------------------------------------------------------------------
function name:   	void INI_FMI2C_SYSSeting(void)
describe:    	 	ϵͳ��ʼ��
input:   			
output:			
date:			Wtire By andyluo in 2011-10-24 13:14:13
------------------------------------------------------------------------*/


const unsigned char SG_B5[]=
{
/*------------------------------------------------------------------------------
;  Դ�ļ� / ���� : E:\��������\��ģ����2.2���հ汾\BMP\SBG4.bmp��ģ
;  �����ߣ����أ�: 32��16
------------------------------------------------------------------------------*/
0x00,0x00,0x00,0x00,0xF8,0x00,0x00,0x30,0x50,0x00,0x06,0x30,0x20,0x00,0x06,0x30,
0x20,0x00,0xC6,0x30,0x20,0x00,0xC6,0x30,0x20,0x18,0xC6,0x30,0x20,0x18,0xC6,0x30,
0x23,0x18,0xC6,0x30,0x23,0x18,0xC6,0x30,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
};
const unsigned char SG_B4[]=
{
/*--  ������һ��ͼ��E:\��������\��ģ����2.2���հ汾\BMP\SG_S4.bmp  --*/
/*--  ����x�߶�=32x16  --*/
0x02,0x06,0xFA,0x06,0x02,0x00,0x80,0x80,0x00,0x00,0x00,0xE0,0xE0,0x00,0x00,0x00,
0xF8,0xF8,0x00,0x00,0x00,0xFE,0xFE,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x03,0x00,0x00,0x00,0x03,0x03,0x00,0x00,0x00,0x03,0x03,0x00,0x00,0x00,
0x03,0x03,0x00,0x00,0x00,0x03,0x03,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};
const unsigned char SG_B3[]=
{
/*--  ������һ��ͼ��E:\��������\��ģ����2.2���հ汾\BMP\SG_B3.bmp  --*/
/*--  ����x�߶�=32x16  --*/
0x02,0x06,0xFA,0x06,0x02,0x00,0x80,0x80,0x00,0x00,0x00,0xE0,0xE0,0x00,0x00,0x00,
0xF8,0xF8,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x03,0x00,0x00,0x00,0x03,0x03,0x00,0x00,0x00,0x03,0x03,0x00,0x00,0x00,
0x03,0x03,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};
const unsigned char SG_B2[]=
{
/*--  ������һ��ͼ��E:\��������\��ģ����2.2���հ汾\BMP\SG_B2.bmp  --*/
/*--  ����x�߶�=32x16  --*/
0x02,0x06,0xFA,0x06,0x02,0x00,0x80,0x80,0x00,0x00,0x00,0xE0,0xE0,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x03,0x00,0x00,0x00,0x03,0x03,0x00,0x00,0x00,0x03,0x03,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};
const unsigned char SG_B1[]=
{
/*--  ������һ��ͼ��E:\��������\��ģ����2.2���հ汾\BMP\SG_B1.bmp  --*/
/*--  ����x�߶�=32x16  --*/
0x02,0x06,0xFA,0x06,0x02,0x00,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x03,0x00,0x00,0x00,0x03,0x03,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};
const unsigned char SG_B0[]=
{
/*--  ������һ��ͼ��E:\��������\��ģ����2.2���հ汾\BMP\SG_B0.bmp  --*/
/*--  ����x�߶�=32x16  --*/
0x02,0x06,0xFA,0x06,0x02,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x03,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};
const unsigned char BT_S4[]=
{
/*------------------------------------------------------------------------------
;  Դ�ļ� / ���� : E:\��������\��ģ����2.2���հ汾\BMP\BT_B4.bmp��ģ
;  �����ߣ����أ�: 32��16
------------------------------------------------------------------------------*/
0x00,0x00,0x00,0x00,0x0F,0xFF,0xFF,0x00,0x08,0x00,0x01,0x00,0x09,0x99,0x99,0x00,
0x09,0x99,0x99,0xC0,0x09,0x99,0x98,0x40,0x09,0x99,0x99,0xC0,0x09,0x99,0x99,0x00,
0x08,0x00,0x01,0x00,0x0F,0xFF,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
};
const unsigned char BT_S3[]=
{
/*------------------------------------------------------------------------------
;  Դ�ļ� / ���� : E:\��������\��ģ����2.2���հ汾\BMP\BT_B3.bmp��ģ
;  �����ߣ����أ�: 32��16
------------------------------------------------------------------------------*/
0x00,0x00,0x00,0x00,0x0F,0xFF,0xFF,0x00,0x08,0x00,0x01,0x00,0x09,0x99,0x81,0x00,
0x09,0x99,0x81,0xC0,0x09,0x99,0x80,0x40,0x09,0x99,0x81,0xC0,0x09,0x99,0x81,0x00,
0x08,0x00,0x01,0x00,0x0F,0xFF,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
};
const unsigned char BT_S2[]=
{
/*------------------------------------------------------------------------------
;  Դ�ļ� / ���� : E:\��������\��ģ����2.2���հ汾\BMP\BT_B2.bmp��ģ
;  �����ߣ����أ�: 32��16
------------------------------------------------------------------------------*/
0x00,0x00,0x00,0x00,0x0F,0xFF,0xFF,0x00,0x08,0x00,0x01,0x00,0x09,0x98,0x01,0x00,
0x09,0x98,0x01,0xC0,0x09,0x98,0x00,0x40,0x09,0x98,0x01,0xC0,0x09,0x98,0x01,0x00,
0x08,0x00,0x01,0x00,0x0F,0xFF,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
};
const unsigned char BT_S1[]=
{
/*------------------------------------------------------------------------------
;  Դ�ļ� / ���� : E:\��������\��ģ����2.2���հ汾\BMP\BT_B1.bmp��ģ
;  �����ߣ����أ�: 32��16
------------------------------------------------------------------------------*/
0x00,0x00,0x00,0x00,0x0F,0xFF,0xFF,0x00,0x08,0x00,0x01,0x00,0x09,0x80,0x01,0x00,
0x09,0x80,0x01,0xC0,0x09,0x80,0x00,0x40,0x09,0x80,0x01,0xC0,0x09,0x80,0x01,0x00,
0x08,0x00,0x01,0x00,0x0F,0xFF,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
};
const unsigned char BT_S0[]=
{
/*------------------------------------------------------------------------------
;  Դ�ļ� / ���� : E:\��������\��ģ����2.2���հ汾\BMP\BT_B0.bmp��ģ
;  �����ߣ����أ�: 32��16
------------------------------------------------------------------------------*/
0x00,0x00,0x00,0x00,0x0F,0xFF,0xFF,0x00,0x08,0x00,0x01,0x00,0x08,0x00,0x01,0x00,
0x08,0x00,0x01,0xC0,0x08,0x00,0x00,0x40,0x08,0x00,0x01,0xC0,0x08,0x00,0x01,0x00,
0x08,0x00,0x01,0x00,0x0F,0xFF,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
};
const unsigned char SIGNAL[]=
{
/*------------------------------------------------------------------------------
;  Դ�ļ� / ���� : E:\��������\��ģ����2.2���հ汾\BMP\SBG4.bmp��ģ
;  �����ߣ����أ�: 32��16
------------------------------------------------------------------------------*/
0x02,0xFE,0x02,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xC0,0x00,0x00,0xF8,0x00,0x00, //45SIGN 0
0x00,0x3F,0x00,0x00,0x30,0x00,0x00,0x3E,0x00,0x00,0x3F,0x00,0x00,0x3F,0x00,0x00, //46
///////////////////////////////////////////////////////////////////////////////////
0x02,0xFE,0x02,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xC0,0x00,0x00,0x00,0x00,0x00, //47    32
0x00,0x3F,0x00,0x00,0x30,0x00,0x00,0x3E,0x00,0x00,0x3F,0x00,0x00,0x00,0x00,0x00, //48
////////////////////////////////////////////////////////////////////////////////////
0x02,0xFE,0x02,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,//49     64
0x00,0x3F,0x00,0x00,0x30,0x00,0x00,0x3E,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,//4A
/////////////////////////////////////////////////////////////////////////////////////
0x02,0xFE,0x02,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, //4B    96
0x00,0x3F,0x00,0x00,0x30,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, //4C
/////////////////////////////////////////////////////////////////////////////////////
0x02,0xFE,0x02,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, //4D    128
0x00,0x3F,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, //4E
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
0x80,0xFC,0x04,0xE4,0x04,0x04,0xE4,0x04,0x04,0xE4,0x04,0x04,0xE4,0x04,0xFC,0x00,//4F     160
0x01,0x3F,0x20,0x27,0x20,0x20,0x27,0x20,0x20,0x27,0x20,0x20,0x27,0x20,0x3F,0x00,//50

0x80,0xFC,0x04,0x04,0x04,0x04,0xE4,0x04,0x04,0xE4,0x04,0x04,0xE4,0x04,0xFC,0x00,//51     192
0x01,0x3F,0x20,0x20,0x20,0x20,0x27,0x20,0x20,0x27,0x20,0x20,0x27,0x20,0x3F,0x00,//52

0x80,0xFC,0x04,0x04,0x04,0x04,0x04,0x04,0x04,0xE4,0x04,0x04,0xE4,0x04,0xFC,0x00,//53    224
0x01,0x3F,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x27,0x20,0x20,0x27,0x20,0x3F,0x00,//54

0x80,0xFC,0x04,0x04,0x04,0x04,0x04,0x04,0x04,0x04,0x04,0x04,0xE4,0x04,0xFC,0x00,//55    256
0x01,0x3F,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x27,0x20,0x3F,0x00,//56

0x80,0xFC,0x04,0x04,0x04,0x04,0x04,0x04,0x04,0x04,0x04,0x04,0x04,0x04,0xFC,0x00,//57    288
0x01,0x3F,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x3F,0x00//58
};
const unsigned char SIGNAL123[]=
{
0x00,0x48,0x78,0x40,/*"1",0*/

0x00,0x40,0x00,0x00,/*".",1*/

0x00,0x7C,0x14,0x1C,/*"P",2*/

0x68,0x58,0x78,0x40,/*"a",3*/

0x88,0xD8,0x38,0x08,/*"y",4*/

0x00,0x00,0x00,0x00,/*" ",5*/

0x00,0x7C,0x48,0x78,/*"b",6*/

0x88,0xD8,0x38,0x08,/*"y",7*/

0x00,0x00,0x00,0x00,/*" ",8*/

0x70,0x48,0x48,0x00,/*"c",9*/

0x30,0x48,0x48,0x30,/*"o",10*/

0x00,0x48,0x7C,0x40,/*"i",11*/

0x00,0x78,0x08,0x78,/*"n",12*/
};
const unsigned char SIGNAL124[]=
{
0x00,0x00,0x42,0x7F,0x40,0x00,0x00,0x00,
0x00,0x00,0x60,0x60,0x00,0x00,0x00,0x00,
0x00,0x7E,0x0C,0x12,0x12,0x0C,0x00,0x00,
0x00,0x20,0x54,0x54,0x54,0x78,0x00,0x00,
0x00,0x1C,0xA0,0xA0,0x90,0x7C,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x7F,0x48,0x44,0x44,0x38,0x00,0x00,
0x00,0x1C,0xA0,0xA0,0x90,0x7C,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x38,0x44,0x44,0x44,0x28,0x00,0x00,
0x00,0x38,0x44,0x44,0x44,0x38,0x00,0x00,
0x00,0x00,0x44,0x7D,0x40,0x00,0x00,0x00,
0x00,0x7C,0x08,0x04,0x04,0x78,0x00,0x00
};
void Refresh_SYSallicon(void)
{
 // goto_xy(0x00,0x00);
 //  Disp_CSQ_icon(SG_CSQ);
 // goto_xy(0x00,0x0F);   
 //  Disp_BTValue_icon(BT_Value);  
  //gprs_user = ON;
  //DPSIP = DPS_sever;   
 /* Disp_ParkState_icon(SYS_Stateicon);
  Disp_NetPOS_icon();  */
}
void Refresh_SYSallicon1(void)
{
//  goto_xy(0x00,0x00);
 //  Disp_CSQ_icon(SG_CSQ);
//  goto_xy(0x00,0x0F);   
 //  Disp_BTValue_icon(BT_Value);  
  //gprs_user = ON;
  //DPSIP = DPS_sever;   
 /* Disp_ParkState_icon(SYS_Stateicon);
  Disp_NetPOS_icon();  */
}

void  Disp_ParkState_icon(u8 Park_ST)
{
	/*goto_xy(0,8);
	switch(Park_ST)
		 {
		 case SYSBusy:	
		 	print_char_st(0xA1,0x39);//��1
		 	break;
		 case SYSERR:
		 	print_char_st(0xA1,0x33);//��3
		 case Clearway_time:
			print_char_st(0xA1,0x24);//��ͣ��ʶ
		    break;
		 case Free_date:
	   		print_char_st(0xA1,0x33);//��3
			break;
		 case Free_time:
			 print_char_st(0xA1,0x32);//��2
			break;
		 case Normal_Time:
		 default:
			 print_char_st(0xA1,0x39);//��1
			 print_char_st(0xA1,0x7E);//P		
			break;
		 }*/
}



void  Disp_NetPOS_icon(void)
{
  /*
	goto_xy(0,16);
	if(gprs_user == OK)
		print_char_st(0xA1,0x57);//			 ����Ͽ�
	else if(DPSIP == DPS_sever)
		print_char_st(0xA1,0x3A);//��O	DPS������
	else //if(DPSIP == DPS_sever)
		print_char_st(0xA1,0x2A);//��a		��������	
*/	
}
void display8X8(void)
{
//Writepicture1_8X8(11,0,104,SIGNAL124+0);
Writepicture_8X8(0,0,104,SIGNAL124+0);
Writepicture_8X8(1,0,104,SIGNAL124+0);
Writepicture_8X8(2,0,104,SIGNAL124+0);
Writepicture_8X8(3,0,104,SIGNAL124+0);
Writepicture_8X8(4,0,104,SIGNAL124+0);
Writepicture_8X8(5,0,104,SIGNAL124+0);
Writepicture_8X8(6,0,104,SIGNAL124+0);
Writepicture_8X8(7,0,104,SIGNAL124+0);
}
void  Disp_BTValue_icon(u8 BT_Value)
{
  
	//switch(SG_CSQ)
	switch(BT_Value)
		 {
		 case BT0:
			//arab_mode(0,4,32,BT_S0);
                       Writepicture_16X16(0,0x60,16,SIGNAL+288);
                   //    print_asi(0x4F);
                   //    print_asi(0x50); 
			break;
		 case BT1:
		 	//arab_mode(0,4,32,BT_S1);
                      Writepicture_16X16(0,0x60,16,SIGNAL+256);
                    //   print_asi(0x51);
                    //   print_asi(0x52); 
			break;
		 case BT2:
		 	//arab_mode(0,4,32,BT_S2);
                      Writepicture_16X16(0,0x60,16,SIGNAL+224);                   
           //            print_asi(0x53);
            //           print_asi(0x54); 
			break;
		case BT3:
			//arab_mode(0,4,32,BT_S3);
                      Writepicture_16X16(0,0x60,16,SIGNAL+192);                  
             //          print_asi(0x55);
             //          print_asi(0x56); 
			break; 	 
		 case BT4:
		 default:
		 	//arab_mode(0,4,32,BT_S4);
                       Writepicture_16X16(0,0x60,16,SIGNAL+160);                  
                   //    print_asi(0x57);
                   //    print_asi(0x58);                       
			break;
		 }
        
}

void  Disp_CSQ_icon(u8 SG_CSQD)
{
  
	//switch(SG_CSQ)
	switch(SG_CSQD)
		 {
		 case SG5:
			//arab_mode(0,0,32,SG_B5);
                        Writepicture_16X16(0,0,16,SIGNAL+0);                   
               //         print_asi(0x45);
                //        print_asi(0x46);                        
			//arab_mode(0,4,32,BT_S4);	
			//goto_xy(0,20);
			//print_char_st(0xA1,0x2A);//A	��������
			//print_char_st(0xA1,0x3A);//E	DPS������
			//print_char_st(0xA1,0x57);//O     ����Ͽ�
			//print_char_st(0xA0,0xEF);
			//print_char_st(0xA1,0x0E);
			//print_char_st(0xA1,0x4A);
			//print_char_st(0xA1,0x56);
			//goto_xy(0,26);
			//print_char_st(0xA1,0x29);//ȦC
			//print_char_st(0xA1,0x2E);//ȦR
			break;
		 case SG4:
			//arab_mode(0,0,32,SG_B4);
                        Writepicture_16X16(0,0,16,SIGNAL+0);                   
                  //      print_asi(0x45);
                  //      print_asi(0x46);                        
			break;
		 case SG3:
		 	//arab_mode(0,0,32,SG_B3);
                       Writepicture_16X16(0,0,16,SIGNAL+32);                    
                   //     print_asi(0x47); 
                   //     print_asi(0x48);                         
			break;
		 case SG2:
		 	//arab_mode(0,0,32,SG_B2);
                       Writepicture_16X16(0,0,16,SIGNAL+64);                    
                   //     print_asi(0x49);  
                   //     print_asi(0x4A);                         
			break;
		case SG1:
			//arab_mode(0,0,32,SG_B1);
                       Writepicture_16X16(0,0,16,SIGNAL+96);                   
                   //    print_asi(0x4B);
                   //    print_asi(0x4C);                       
			break; 	 
		 case SG0:
		 default:
		 	//arab_mode(0,0,32,SG_B0);
                        Writepicture_16X16(0,0,16,SIGNAL+128);                   
                   //     print_asi(0x4D);   
                   //     print_asi(0x4E);                         
			break;
		 }
        
}
/*************************************************
  ������:          	void disp_System_checking(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_System_checking(void)
{  	
	lcd_clear();
	goto_xy(0x00,0x05);
	print_str_16_16("System checking...");
	//goto_xy(0x20,24);
	//print_char_st(0xA3,0x70);//��æ
	//print_char_st(0xA3,0x71);
	//print_char_st(0xA3,0x72);
	goto_xy(0x04,0x05);
	print_str_16_16("Please wait...");
	//goto_xy(0x40,19);
	//print_char_st(0xA3,0x20);//���æ
	//print_char_st(0xA3,0x21);

	SYS_DO_BUSY_ICON(0x20,24,0x40,21, 0);
	
	//goto_xy(0x02,13);
	
	//CT_fb_off_gb_on();	
	//cursor_flash_time(100);
	goto_xy(0x08,0x05);
	SYS_Vision();
}
/*************************************************
  ������:          	void CT_fb_off_gb_off(void)
  ��������:        	//���׹ع���1110_1010
*************************************************/ 
void CT_fb_off_gb_off(void)
{
    zimo=0;
	//control_buf_wccr(fb_off_gb_off);
}			
/*************************************************
  ������:          	void CT_fb_off_gb_off(void)
  ��������:        	//���׿���꿪1100_1110
*************************************************/ 
void CT_fb_on_gb_on(void)
{
//	control_buf_wccr(fb_on_gb_on);
}	
/*************************************************
  ������:          	void CT_fb_off_gb_on(void)
  ��������:        	//���׹ع�꿪1110_1110
*************************************************/ 
void CT_fb_off_gb_on(void)
{
//	control_buf_wccr(fb_off_gb_on);
}	
/*************************************************
  ������:          	void CT_fb_on_gb_off(void)
  ��������:        	 //���׿�����1100_1010
*************************************************/ 
void CT_fb_on_gb_off(void)
{
  zimo=1;
//	control_buf_wccr(fb_on_gb_off);
}	


/*************************************************
  ������:          	void disp_illegalopen(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_illegalopen(void)
{  	
	goto_xy(0x40,0x07);
	print_str_16_16("illegal opening!");
}
/*************************************************/ 
void disp_current_time(void)
{  	
	u8 * disp_week;
	
	GetCurrentTime();
	lcd_clear();
	CT_fb_off_gb_off();
	goto_xy(0x08,0x04);
	print_num32_32(time[2]/16);
	print_num32_32(time[2]%16);        
	//print_str_32_32("/");
        print_asi(0x0F);        
	print_num32_32(time[3]/16);
	print_num32_32(time[3]%16);        
//	print_str_32_32("/");
        print_asi(0x0F);        
	print_str_16_16("20");
	print_num32_32(time[4]/16);
	print_num32_32(time[4]%16);        
	goto_xy(12,0x04);
	print_num16_16(time[1]/16);
	print_num16_16(time[1]%16);        
//	print_str_16_16(":");
        print_asi(0x1A);
	print_num16_16(time[0]/16);	
	print_num16_16(time[0]%16);	        
//	goto_xy(0x08,0x04);	
	goto_xy(12,56);        
	switch(time[5])
		{
		case 0:
		case 7:
			disp_week ="Sun";
			break;
		case 1:	
			disp_week ="Mon";
			break;

		case 2:	
			disp_week ="Tue";//7
			break;

		case 3:	
			disp_week ="Wed";//9
			break;

		case 4:
			disp_week ="Thu";//8
			break;

		case 5:	
			disp_week ="Fri";//6
			break;	

		case 6:	
			disp_week ="Sat";//8
			break;
		default:
			disp_week ="DayError";//8
			break;
	}
//	goto_xy(0x08,0x07);	        
	print_str_16_16(disp_week);
}
void Disp_week(unsigned char disptype,unsigned char weeks)
{
  	u8 * disp_week;
	switch(weeks)
		{
		case 0:
		case 7:
			disp_week ="Sun";
			break;
		case 1:	
			disp_week ="Mon";
			break;

		case 2:	
			disp_week ="Tue";//7
			break;

		case 3:	
			disp_week ="Wed";//9
			break;

		case 4:
			disp_week ="Thu";//8
			break;

		case 5:	
			disp_week ="Fri";//6
			break;	

		case 6:	
			disp_week ="Sat";//8
			break;
		default:
			disp_week ="DayError";//8
			break;
	}
//	goto_xy(0x08,0x07);
        switch(disptype)
        {
        case 0:print_str0_16_16(disp_week);break;
        case 1:print_str_16_16(disp_week);break;
        case 2:print_str2_16_16(disp_week);break;
        case 3:print_str3_16_16(disp_week);break;
        case 4:print_str4_16_16(disp_week);break;
        default:break;        
        }
}
/*************************************************/ 
void disp_current_time12(void)
{  	
	u8 * disp_week;
	
	GetCurrentTime();
//	lcd_clear();
	CT_fb_off_gb_off();
	goto_xy(0x04,0x04);
	print_num32_32(time[2]/16);
	print_num32_32(time[2]%16);        
	//print_str_32_32("/");
        print_asi(0x0F);        
	print_num32_32(time[3]/16);
	print_num32_32(time[3]%16);        
//	print_str_32_32("/");
        print_asi(0x0F);        
	print_str_16_16("20");
	print_num32_32(time[4]/16);
	print_num32_32(time[4]%16);        
	goto_xy(0x08,0x04);
	print_num16_16(time[1]/16);
	print_num16_16(time[1]%16);        
//	print_str_16_16(":");
        print_asi(0x1A);
	print_num16_16(time[0]/16);	
	print_num16_16(time[0]%16);	        
	goto_xy(12,0x04);	
	switch(time[5])
		{
		case 0:
		case 7:
			disp_week ="Sunday";
			break;
		case 1:	
			disp_week ="Monday";
			break;

		case 2:	
			disp_week ="Tuesday";//7
			break;

		case 3:	
			disp_week ="Wednesday";//9
			break;

		case 4:
			disp_week ="Thursday";//8
			break;

		case 5:	
			disp_week ="Friday";//6
			break;	

		case 6:	
			disp_week ="Saturday";//8
			break;
		default:
			disp_week ="DayError";//8
			break;
	}
//	goto_xy(0x08,0x07);	        
	print_str_16_16(disp_week);
}
/*************************************************
  ������:          	void disp_CURTIM_16x32(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_CURTIM_16x32(void)
{  	
	u8 * disp_week;
	
	GetCurrentTime();
	lcd_clear();
	CT_fb_off_gb_off();
	goto_xy(0x00,0x04);
	print_num32_32(time[2]/16);
	print_num32_32(time[2]%16);        
	//print_str_32_32("/");
        print_asi(0x0F);        
	print_num32_32(time[3]/16);
	print_num32_32(time[3]%16);        
//	print_str_32_32("/");
        print_asi(0x0F);        
	print_str_16_16("20");
	print_num32_32(time[4]/16);
	print_num32_32(time[4]%16);        
	goto_xy(0x04,0x04);
	print_num16_16(time[1]/16);
	print_num16_16(time[1]%16);        
//	print_str_16_16(":");
        print_asi(0x1A);
	print_num16_16(time[0]/16);	
	print_num16_16(time[0]%16);	        
	goto_xy(0x08,0x04);	
	switch(time[5])
		{
		case 0:
		case 7:
			disp_week ="Sunday";
	//		goto_xy(0x08,0x07);	
			break;
		case 1:	
			disp_week ="Monday";
		//	goto_xy(0x08,0x08);	
			break;

		case 2:	
			disp_week ="Tuesday";//7
			//goto_xy(0x08,0x07);
			break;

		case 3:	
			disp_week ="Wednesday";//9
			//goto_xy(0x08,0x06);
			break;

		case 4:
			disp_week ="Thursday";//8
			//goto_xy(0x08,0x06);	
			break;

		case 5:	
			disp_week ="Friday";//6
			//goto_xy(0x08,0x07);
			break;	

		case 6:	
			disp_week ="Saturday";//8
			//goto_xy(0x08,0x06);
			break;
		default:
			disp_week ="DayError";//8
			//goto_xy(0x08,0x06);
			break;
	}
       // print_asi(0x0E);
	//print_str_16_16("... ");	
	print_str_16_16(disp_week);
	//goto_xy(0x70,21); 
	//print_str_16_16(" ...");	
	goto_xy(12,0x04);
	SYS_Vision();
} 

/*************************************************
  ������:          	void disp_CURTIM_16x32(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_CURTIM_16x32line(void)
{  	
	u8 *disp_week,f_AM1,middledata;
	
	GetCurrentTime();
	//lcd_clear();
	CT_fb_off_gb_off();
///////////////////////////////////////////////
	switch(time[5])
		{
		case 0:
			disp_week ="SUN";
	//		goto_xy(0x08,0x07);	
			break;
		case 1:	
			disp_week ="MON";
		//	goto_xy(0x08,0x08);	
			break;

		case 2:	
			disp_week ="TUE";//7
			//goto_xy(0x08,0x07);
			break;

		case 3:	
			disp_week ="WED";//9
			//goto_xy(0x08,0x06);
			break;

		case 4:
			disp_week ="THU";//8
			//goto_xy(0x08,0x06);	
			break;

		case 5:	
			disp_week ="FRI";//6
			//goto_xy(0x08,0x07);
			break;	

		case 6:	
			disp_week ="SAT";//8
			//goto_xy(0x08,0x06);
			break;
		default:
			disp_week ="DayE";//8
			//goto_xy(0x08,0x06);
			break;
	}
       // print_asi(0x0E);
	//print_str_16_16("... ");	
	print_str_16_16(disp_week);        
/////////////////////////////////////////////////// 
                print_asi111(0x01,0x00);
///////////////////////////////////////////////
	switch(time[3])
		{
		case 0x01:
			disp_week ="JAN";
	//		goto_xy(0x08,0x07);	
			break;
		case 0x02:	
			disp_week ="FEB";
		//	goto_xy(0x08,0x08);	
			break;

		case 0x03:	
			disp_week ="MAR";//7
			//goto_xy(0x08,0x07);
			break;

		case 0x04:	
			disp_week ="APR";//9
			//goto_xy(0x08,0x06);
			break;

		case 0x05:
			disp_week ="MAY";//8
			//goto_xy(0x08,0x06);	
			break;

		case 0x06:	
			disp_week ="JUN";//6
			//goto_xy(0x08,0x07);
			break;	

		case 0x07:	
			disp_week ="JUL";//8
			//goto_xy(0x08,0x06);
			break;

		case 0x08:	
			disp_week ="AUG";//8
			//goto_xy(0x08,0x06);
			break;

		case 0x09:	
			disp_week ="SEP";//8
			//goto_xy(0x08,0x06);
			break;

		case 0x10:	
			disp_week ="OCT";//8
			//goto_xy(0x08,0x06);
			break;  

		case 0x11:	
			disp_week ="NOV";//8
			//goto_xy(0x08,0x06);
			break; 

		case 0x12:	
			disp_week ="DEC";//8
			//goto_xy(0x08,0x06);
			break;                         
                        
		default:
			disp_week ="DayError";//8
			//goto_xy(0x08,0x06);
			break;
	}
       // print_asi(0x0E);
	//print_str_16_16("... ");	
	print_str_16_16(disp_week);        
/////////////////////////////////////////////////// 
         //    print_asi111(0x00,0x00);        
	//goto_xy(0x00,0x04);
	print_asi111(0x01,16+time[2]/16);
	print_asi111(0x01,16+time[2]%16);        
	//print_str_32_32("/");
        print_asi111(0x01,0x00);        
	//print_asi111(0x00,16+time[3]/16);
	//print_asi111(0x00,16+time[3]%16);        
//	print_str_32_32("/");
       // print_asi(0x00);        
	print_str_16_16("20");
	print_asi111(0x01,16+time[4]/16);
	print_asi111(0x01,16+time[4]%16);        
	print_asi111(0x01,0x00);
            //   if(sz2[1]>=0x12)
        /*      if(time[1]>=0x12)                 
               {
               middledata= time[1]-0x12;
               f_AM1=0;
               }
               else
               {
                 middledata= time[1];
                  f_AM1=1;
               }*/
        middledata= time[1];
	print_asi111(0x01,16+middledata/16);
	print_asi111(0x01,16+middledata%16);        
//	print_str_16_16(":");
        print_asi111(0x01,0x1A);
	print_asi111(0x01,16+time[0]/16);	
	print_asi111(0x01,16+time[0]%16);	        
	//goto_xy(0x08,0x04);	

	//goto_xy(0x70,21); 
	//print_str_16_16(" ...");	
	//goto_xy(12,0x04);
	//SYS_Vision();
} 
void disp_month(unsigned char disptype)
{
 	u8 *disp_week;
	
	GetCurrentTime();
///////////////////////////////////////////////
	switch(time[3])
		{
		case 0x01:
			disp_week ="JAN";
	//		goto_xy(0x08,0x07);	
			break;
		case 0x02:	
			disp_week ="FEB";
		//	goto_xy(0x08,0x08);	
			break;

		case 0x03:	
			disp_week ="MAR";//7
			//goto_xy(0x08,0x07);
			break;

		case 0x04:	
			disp_week ="APR";//9
			//goto_xy(0x08,0x06);
			break;

		case 0x05:
			disp_week ="MAY";//8
			//goto_xy(0x08,0x06);	
			break;

		case 0x06:	
			disp_week ="JUN";//6
			//goto_xy(0x08,0x07);
			break;	

		case 0x07:	
			disp_week ="JUL";//8
			//goto_xy(0x08,0x06);
			break;

		case 0x08:	
			disp_week ="AUG";//8
			//goto_xy(0x08,0x06);
			break;

		case 0x09:	
			disp_week ="SEP";//8
			//goto_xy(0x08,0x06);
			break;

		case 0x10:	
			disp_week ="OCT";//8
			//goto_xy(0x08,0x06);
			break;  

		case 0x11:	
			disp_week ="NOV";//8
			//goto_xy(0x08,0x06);
			break; 

		case 0x12:	
			disp_week ="DEC";//8
			//goto_xy(0x08,0x06);
			break;                         
                        
		default:
			disp_week ="DayError";//8
			//goto_xy(0x08,0x06);
			break;
	}
        switch(disptype)
        {
        case 0:print_str0_16_16(disp_week);break;
        case 1:print_str_16_16(disp_week);break;
        case 2:print_str2_16_16(disp_week);break;
        case 3:print_str3_16_16(disp_week);break;
        case 4:print_str4_16_16(disp_week);break;
        default:break;        
        }
}
/*************************************************
  ������:          	void disp_CURTIM_16x32(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_CURTIM_16x32line0(void)
{  	
	u8 *disp_week,f_AM1,middledata;
	
	GetCurrentTime();
	//lcd_clear();
	CT_fb_off_gb_off();
///////////////////////////////////////////////
	switch(time[5])
		{
		case 0:
			disp_week ="SUN";
	//		goto_xy(0x08,0x07);	
			break;
		case 1:	
			disp_week ="MON";
		//	goto_xy(0x08,0x08);	
			break;

		case 2:	
			disp_week ="TUE";//7
			//goto_xy(0x08,0x07);
			break;

		case 3:	
			disp_week ="WED";//9
			//goto_xy(0x08,0x06);
			break;

		case 4:
			disp_week ="THU";//8
			//goto_xy(0x08,0x06);	
			break;

		case 5:	
			disp_week ="FRI";//6
			//goto_xy(0x08,0x07);
			break;	

		case 6:	
			disp_week ="SAT";//8
			//goto_xy(0x08,0x06);
			break;
		default:
			disp_week ="DayE";//8
			//goto_xy(0x08,0x06);
			break;
	}
       // print_asi(0x0E);
	//print_str_16_16("... ");	
	print_str0_16_16(disp_week);        
/////////////////////////////////////////////////// 
                print_asi111(0x00,0x00);
///////////////////////////////////////////////
	switch(time[3])
		{
		case 0x01:
			disp_week ="JAN";
	//		goto_xy(0x08,0x07);	
			break;
		case 0x02:	
			disp_week ="FEB";
		//	goto_xy(0x08,0x08);	
			break;

		case 0x03:	
			disp_week ="MAR";//7
			//goto_xy(0x08,0x07);
			break;

		case 0x04:	
			disp_week ="APR";//9
			//goto_xy(0x08,0x06);
			break;

		case 0x05:
			disp_week ="MAY";//8
			//goto_xy(0x08,0x06);	
			break;

		case 0x06:	
			disp_week ="JUN";//6
			//goto_xy(0x08,0x07);
			break;	

		case 0x07:	
			disp_week ="JUL";//8
			//goto_xy(0x08,0x06);
			break;

		case 0x08:	
			disp_week ="AUG";//8
			//goto_xy(0x08,0x06);
			break;

		case 0x09:	
			disp_week ="SEP";//8
			//goto_xy(0x08,0x06);
			break;

		case 0x10:	
			disp_week ="OCT";//8
			//goto_xy(0x08,0x06);
			break;  

		case 0x11:	
			disp_week ="NOV";//8
			//goto_xy(0x08,0x06);
			break; 

		case 0x12:	
			disp_week ="DEC";//8
			//goto_xy(0x08,0x06);
			break;                         
                        
		default:
			disp_week ="DayError";//8
			//goto_xy(0x08,0x06);
			break;
	}
       // print_asi(0x0E);
	//print_str_16_16("... ");	
	print_str0_16_16(disp_week);        
/////////////////////////////////////////////////// 
         //    print_asi111(0x00,0x00);        
	//goto_xy(0x00,0x04);
	print_asi111(0x00,16+time[2]/16);
	print_asi111(0x00,16+time[2]%16);        
	//print_str_32_32("/");
        print_asi111(0x00,0x00);        
	//print_asi111(0x00,16+time[3]/16);
	//print_asi111(0x00,16+time[3]%16);        
//	print_str_32_32("/");
       // print_asi(0x00);        
	print_str0_16_16("20");
	print_asi111(0x00,16+time[4]/16);
	print_asi111(0x00,16+time[4]%16);        
	print_asi111(0x00,0x00);
            //   if(sz2[1]>=0x12)
             //  if(time[1]>=0x12)                 
             //  {
             //  middledata= time[1]-0x12;
             //  f_AM1=0;
             //  }
             //  else
            //   {
            //     middledata= time[1];
            //      f_AM1=1;
             //  }
        middledata= time[1];
	print_asi111(0x00,16+middledata/16);
	print_asi111(0x00,16+middledata%16);        
	print_str0_16_16(":");
//        print_asi111(0x00,0x1A);
	print_asi111(0x00,16+time[0]/16);	
	print_asi111(0x00,16+time[0]%16);	        
	//goto_xy(0x08,0x04);	

	//goto_xy(0x70,21); 
	//print_str_16_16(" ...");	
	//goto_xy(12,0x04);
	//SYS_Vision();
}
//////////////////////////��ʾ����/////////////////////////////////////////////////////
void disp_week1(u8 wordtype)
{  	
	u8 *disp_week;
	
	GetCurrentTime();
	//lcd_clear();
	CT_fb_off_gb_off();
///////////////////////////////////////////////
	switch(time[5])
		{
		case 0:
			disp_week ="SUN";
	//		goto_xy(0x08,0x07);	
			break;
		case 1:	
			disp_week ="MON";
		//	goto_xy(0x08,0x08);	
			break;

		case 2:	
			disp_week ="TUE";//7
			//goto_xy(0x08,0x07);
			break;

		case 3:	
			disp_week ="WED";//9
			//goto_xy(0x08,0x06);
			break;

		case 4:
			disp_week ="THU";//8
			//goto_xy(0x08,0x06);	
			break;

		case 5:	
			disp_week ="FRI";//6
			//goto_xy(0x08,0x07);
			break;	

		case 6:	
			disp_week ="SAT";//8
			//goto_xy(0x08,0x06);
			break;
		default:
			disp_week ="WEE";//8
			//goto_xy(0x08,0x06);
			break;
	}
       // print_asi(0x0E);
	//print_str_16_16("... ");
       switch(wordtype)
       {
       case 0:print_str0_16_16(disp_week);break;
       case 1:print_str_16_16(disp_week);break; 
       case 2:print_str2_16_16(disp_week);break;  
       case 3:print_str3_16_16(disp_week);break;
       case 4:print_str4_16_16(disp_week);break;
       default:break;       
       }
}
///////////////////////////////////////////////////////////////////////////////////////
//////////////////////////��ʾ�·�////////////////////////////////////////////////////
void disp_month1(u8 wordtype)
{  	
	u8 *disp_week;
	
	GetCurrentTime();
	//lcd_clear();
	CT_fb_off_gb_off();
///////////////////////////////////////////////
	switch(time[3])
		{
		case 0x01:
			disp_week ="JAN";
	//		goto_xy(0x08,0x07);	
			break;
		case 0x02:	
			disp_week ="FEB";
		//	goto_xy(0x08,0x08);	
			break;

		case 0x03:	
			disp_week ="MAR";//7
			//goto_xy(0x08,0x07);
			break;

		case 0x04:	
			disp_week ="APR";//9
			//goto_xy(0x08,0x06);
			break;

		case 0x05:
			disp_week ="MAY";//8
			//goto_xy(0x08,0x06);	
			break;

		case 0x06:	
			disp_week ="JUN";//6
			//goto_xy(0x08,0x07);
			break;	

		case 0x07:	
			disp_week ="JUL";//8
			//goto_xy(0x08,0x06);
			break;

		case 0x08:	
			disp_week ="AUG";//8
			//goto_xy(0x08,0x06);
			break;

		case 0x09:	
			disp_week ="SEP";//8
			//goto_xy(0x08,0x06);
			break;

		case 0x10:	
			disp_week ="OCT";//8
			//goto_xy(0x08,0x06);
			break;  

		case 0x11:	
			disp_week ="NOV";//8
			//goto_xy(0x08,0x06);
			break; 

		case 0x12:	
			disp_week ="DEC";//8
			//goto_xy(0x08,0x06);
			break;                         
                        
		default:
			disp_week ="MON";//8
			//goto_xy(0x08,0x06);
			break;
	}
       // print_asi(0x0E);
	//print_str_16_16("... ");	
       // print_asi(0x0E);
	//print_str_16_16("... ");
       switch(wordtype)
       {
       case 0:print_str0_16_16(disp_week);break;
       case 1:print_str_16_16(disp_week);break; 
       case 2:print_str2_16_16(disp_week);break;  
       case 3:print_str3_16_16(disp_week);break;
       case 4:print_str4_16_16(disp_week);break;
       default:break;       
       }
}
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
//////////////////////////��ʾ����/////////////////////////////////////////////////////
void disp_day1(u8 wordtype)
{  		
	GetCurrentTime();
	//lcd_clear();
	CT_fb_off_gb_off();
	print_asi111(wordtype,16+time[2]/16);
	print_asi111(wordtype,16+time[2]%16);
}
///////////////////////////////////////////////////////////////////////////////////////
//////////////////////////��ʾ���/////////////////////////////////////////////////////
void disp_year1(u8 wordtype)
{  		
	GetCurrentTime();
	//lcd_clear();
	CT_fb_off_gb_off();
//	print_str0_16_16("20");
       switch(wordtype)
       {
       case 0:print_str0_16_16("20");break;
       case 1:print_str_16_16("20");break; 
       case 2:print_str2_16_16("20");break;  
       case 3:print_str3_16_16("20");break;
       case 4:print_str4_16_16("20");break;
       default:break;       
       }        
	print_asi111(wordtype,16+time[4]/16);
	print_asi111(wordtype,16+time[4]%16); 
}
///////////////////////////////////////////////////////////////////////////////////////
//////////////////////////��ʾ���/////////////////////////////////////////////////////
void disp_time2(u8 wordtype)
{
  u16 x_StartTime_h1; 
	GetCurrentTime();
	//lcd_clear();
               if(time1[1]>=12)                 
               {
               x_StartTime_h1=time1[1]-12;
             //  disp_week="AM";
               }
               else
               {
               x_StartTime_h1=time1[1];
              //  disp_week="PM";                
               }        
	CT_fb_off_gb_off();
	print_asi111(wordtype,16+x_StartTime_h1/16);
	print_asi111(wordtype,16+x_StartTime_h1%16);        
//	print_str_16_16(":");
        print_asi111(wordtype,0x1A);
	print_asi111(wordtype,16+time[0]/16);	
	print_asi111(wordtype,16+time[0]%16);
}
//////////////////////////��ʾ���/////////////////////////////////////////////////////
void disp_time1(u8 wordtype)
{
  u16 x_StartTime_h1; 
	GetCurrentTime();
	//lcd_clear();
               if(time1[1]>=12)                 
               {
               x_StartTime_h1=time1[1]-12;
             //  disp_week="AM";
               }
               else
               {
               x_StartTime_h1=time1[1];
              //  disp_week="PM";                
               }        
	CT_fb_off_gb_off();
	print_asi111(wordtype,16+x_StartTime_h1/10);
	print_asi111(wordtype,16+x_StartTime_h1%10);        
//	print_str_16_16(":");
        print_asi111(wordtype,0x1A);
	print_asi111(wordtype,16+time1[0]/10);	
	print_asi111(wordtype,16+time1[0]%10);
}

///////////////////////////////////////////////////////////////////////////////////////

/*************************************************
  ������:          	void disp_CURTIM_16x32(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_CURTIM_16x32CHANG(void)
{  	
	u8 * disp_week;
	
	GetCurrentTime();
//	lcd_clear();
	CT_fb_off_gb_off();
	goto_xy(0x04,0x04);
	print_num32_32(time[2]/16);
	print_num32_32(time[2]%16);        
	//print_str_32_32("/");
        print_asi(0x0F);        
	print_num32_32(time[3]/16);
	print_num32_32(time[3]%16);        
//	print_str_32_32("/");
        print_asi(0x0F);        
	print_str_16_16("20");
	print_num32_32(time[4]/16);
	print_num32_32(time[4]%16);        
	goto_xy(0x08,0x04);
	print_num16_16(time[1]/16);
	print_num16_16(time[1]%16);        
//	print_str_16_16(":");
        print_asi(0x1A);
	print_num16_16(time[0]/16);	
	print_num16_16(time[0]%16);	        
	goto_xy(12,0x04);	
	switch(time[5])
		{
		case 0:
		case 7:                  
			disp_week ="Sunday";
	//		goto_xy(12,0x07);	
			break;
		case 1:	
			disp_week ="Monday";
		//	goto_xy(12,0x08);	
			break;

		case 2:	
			disp_week ="Tuesday";//7
			//goto_xy(12,0x07);
			break;

		case 3:	
			disp_week ="Wednesday";//9
			//goto_xy(12,0x06);
			break;

		case 4:
			disp_week ="Thursday";//8
			//goto_xy(12,0x06);	
			break;

		case 5:	
			disp_week ="Friday";//6
			//goto_xy(12,0x07);
			break;	

		case 6:	
			disp_week ="Saturday";//8
			//goto_xy(12,0x06);
			break;
		default:
			disp_week ="DayError";//8
			//goto_xy(12,0x06);
			break;
	}
 //       print_asi(0x0E);
//	print_str_16_16("... ");	
	print_str_16_16(disp_week);
	//goto_xy(0x70,21); 
//	print_str_16_16(" ...");	
//	goto_xy(12,0x13);
//	SYS_Vision();
}
void disp_Cancel(void)
{  	
	goto_xy(12,0x0d);
	print_str_16_16("'Cancel' for exit");	  
}	 
//����Ϊ����������ʾ�˵�

/*************************************************
  ������:          	void disp_Menu(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_Menu(void)
{  
	lcd_clear();	
	Refresh_SYSallicon();
	//goto_xy(0x00,0x00);
	//print_str_32_32("Menu");
	
	//goto_xy(0x70,0);
	//print_num16_char(menunum);
	

}
/*************************************************
  ������:          	void disp_mainmenu1(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
  display:  insert coins or credit card
*************************************************/ 
void disp_mainmenu1(void)
{  	    
        LoadMenuLcd(3,1);  
        LoadMenuLcd(3,2); 
        LoadMenuLcd(3,3); 
        LoadMenuLcd(3,4);  
        LoadMenuLcd(3,5); 
        LoadMenuLcd(3,6);
        LoadMenuLcd(3,7);  
        LoadMenuLcd(3,8); 
        LoadMenuLcd(3,9);
        LoadMenuLcd(3,0x0A);

}
///////////////////////////////////////////
void disp_SPACE(u8 wordtype)
{
        u8 * disp_week;
        u16 x_EndTime_h1;
       GetCurrentTime(); 
       disp_week="SPACE ";
       switch(wordtype)
       {
       case 0:print_str0_16_16(disp_week);break;
       case 1:print_str_16_16(disp_week);break; 
       case 2:print_str2_16_16(disp_week);break;  
       case 3:print_str3_16_16(disp_week);break;
       case 4:print_str4_16_16(disp_week);break;
       default:break;       
       } 
       x_EndTime_h1=(chewei>>4)&0x0F;
	print_asi111(wordtype,16+x_EndTime_h1);
}
void disp_AM_PM(u8 wordtype)
{
          u8 * disp_week;
 	     GetCurrentTime();             
               if(time[1]>=0x12)                 
               {
//               x_StartTime_h1=x_StartTime_h-0x12;
                disp_week="PM";
               }
               else
               {
//               x_StartTime_h1=x_StartTime_h; 
               disp_week="AM";                
               }
       switch(wordtype)
       {
       case 0:print_str0_16_16(disp_week);break;
       case 1:print_str_16_16(disp_week);break; 
       case 2:print_str2_16_16(disp_week);break;  
       case 3:print_str3_16_16(disp_week);break;
       case 4:print_str4_16_16(disp_week);break;
       default:break;       
       }
}
///////////////////////////////////////////
void disp_starttime_to_endtime(u8 wordtype)
{
  u8 * disp_week;
  u16 x_StartTime_h1,x_EndTime_h1;
 	GetCurrentTime();
               if(x_StartTime_h>=0x12)                 
               {
               x_StartTime_h1=x_StartTime_h-0x12;
                disp_week="PM";               
               }
               else
               {
               x_StartTime_h1=x_StartTime_h;
               disp_week="AM";                
               }
       if(x_StartTime_h1/10)
       print_asi111(wordtype,16+x_StartTime_h1/0x10);
       print_asi111(wordtype,16+x_StartTime_h1%0x10);        
//	print_str_16_16(":");
/*       print_asi111(wordtype,0x1A);
       print_asi111(wordtype,16+x_StartTime_min/10);	
       print_asi111(wordtype,16+x_StartTime_min%10);*/
       switch(wordtype)
       {
       case 0:print_str0_16_16(disp_week);break;
       case 1:print_str_16_16(disp_week);break; 
       case 2:print_str2_16_16(disp_week);break;  
       case 3:print_str3_16_16(disp_week);break;
       case 4:print_str4_16_16(disp_week);break;
       default:break;       
       }
       switch(wordtype)
       {
       case 0:print_str0_16_16("-");break;
       case 1:print_str_16_16("-");break; 
       case 2:print_str2_16_16("-");break;  
       case 3:print_str3_16_16("-");break;
       case 4:print_str4_16_16("-");break;
       default:break;       
       }        
               if(x_EndTime_h>=0x12)                 
               {
               x_EndTime_h1=x_EndTime_h-0x12;
                disp_week="PM";               
               }
               else
               {
               x_EndTime_h1=x_EndTime_h;
               disp_week="AM";                
               }     
       if(x_EndTime_h1/10)        
	print_asi111(wordtype,16+x_EndTime_h1/0x10);
	print_asi111(wordtype,16+x_EndTime_h1%0x10);        
	//       print_str_16_16(":");
/*         print_asi111(wordtype,0x1A);
	print_asi111(wordtype,16+x_EndTime_min/10);	
	 print_asi111(wordtype,16+x_EndTime_min%10); */
       switch(wordtype)
       {
       case 0:print_str0_16_16(disp_week);break;
       case 1:print_str_16_16(disp_week);break; 
       case 2:print_str2_16_16(disp_week);break;  
       case 3:print_str3_16_16(disp_week);break;
       case 4:print_str4_16_16(disp_week);break;
       default:break;       
       }         
}
///////////////////////////////////////////
void disp_starttime_to_endtime1(u8 wordtype)
{
  u8 * disp_week;
  u16 x_StartTime_h1,x_EndTime_h1;
 	GetCurrentTime();
               if(x_StartTime_h>=12)                 
               {
               x_StartTime_h1=x_StartTime_h-0x12;
               disp_week="PM";
               }
               else
               {
               x_StartTime_h1=x_StartTime_h;
                disp_week="AM";                
               }
       if(x_StartTime_h1/16)
       print_asi111(wordtype,16+x_StartTime_h1/16);
       print_asi111(wordtype,16+x_StartTime_h1%16);        
//	print_str_16_16(":");
       print_asi111(wordtype,0x1A);
       print_asi111(wordtype,16+x_StartTime_min/16);	
       print_asi111(wordtype,16+x_StartTime_min%16);
       switch(wordtype)
       {
       case 0:print_str0_16_16(disp_week);break;
       case 1:print_str_16_16(disp_week);break; 
       case 2:print_str2_16_16(disp_week);break;  
       case 3:print_str3_16_16(disp_week);break;
       case 4:print_str4_16_16(disp_week);break;
       default:break;       
       }
       switch(wordtype)
       {
       case 0:print_str0_16_16("-");break;
       case 1:print_str_16_16("-");break; 
       case 2:print_str2_16_16("-");break;  
       case 3:print_str3_16_16("-");break;
       case 4:print_str4_16_16("-");break;
       default:break;       
       }        
               if(x_EndTime_h>=12)                 
               {
               x_EndTime_h1=x_EndTime_h-0x12;
               disp_week="PM";
               }
               else
               {
               x_EndTime_h1=x_EndTime_h;
                disp_week="AM";                
               }     
       if(x_EndTime_h1/16)        
	print_asi111(wordtype,16+x_EndTime_h1/16);
	print_asi111(wordtype,16+x_EndTime_h1%16);        
	//       print_str_16_16(":");
         print_asi111(wordtype,0x1A);
	print_asi111(wordtype,16+x_EndTime_min/16);	
	 print_asi111(wordtype,16+x_EndTime_min%16); 
       switch(wordtype)
       {
       case 0:print_str0_16_16(disp_week);break;
       case 1:print_str_16_16(disp_week);break; 
       case 2:print_str2_16_16(disp_week);break;  
       case 3:print_str3_16_16(disp_week);break;
       case 4:print_str4_16_16(disp_week);break;
       default:break;       
       }         
}
/*************************************************
  ������:          	void disp_mainmenu2(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
//////////////////////////��ʾ��ʼʱ��/////////////////////////////////////////////////////
void disp_starttime1(u8 wordtype)
{  		
	GetCurrentTime();
	//lcd_clear();
	CT_fb_off_gb_off();
       if(x_StartTime_h/16)
       print_asi111(wordtype,16+x_StartTime_h/16);
       print_asi111(wordtype,16+x_StartTime_h%16);        
//	print_str_16_16(":");
       print_asi111(wordtype,0x1A);
       print_asi111(wordtype,16+x_StartTime_min/16);	
       print_asi111(wordtype,16+x_StartTime_min%16);
}
///////////////////////////////////////////////////////////////////////////////////////
//////////////////////////��ʾ����ʱ��/////////////////////////////////////////////////////
void disp_endtime1(u8 wordtype)
{  		
	GetCurrentTime();
	//lcd_clear();
	CT_fb_off_gb_off();
       if(x_EndTime_h/16)        
	print_asi111(wordtype,16+x_EndTime_h/16);
	print_asi111(wordtype,16+x_EndTime_h%16);        
	//       print_str_16_16(":");
         print_asi111(wordtype,0x1A);
	print_asi111(wordtype,16+x_EndTime_min/16);	
	 print_asi111(wordtype,16+x_EndTime_min%16);
}
void disp_weektoweek(u8 wordtype)
{  		
	GetCurrentTime();
	//lcd_clear();
	CT_fb_off_gb_off();
        Disp_week(wordtype,x_StartWeek);       
//	print_str_16_16(":");
        print_asi111(wordtype,0x0D);
        Disp_week(wordtype,x_EndWeek);
}
void disp_maxtime(u8 wordtype)
{
	    //   goto_xy(0x04,0x50);
               	if((x_MaxPark/60)/10)
	       print_asi111(wordtype,16+(x_MaxPark/60)/10);	
	       print_asi111(wordtype,16+(x_MaxPark/60)%10);
////////////////////////////////////////////////////////
       switch(wordtype)
       {
       case 0:print_str0_16_16("HRS MAX");break;
       case 1:print_str_16_16("HRS MAX");break; 
       case 2:print_str2_16_16("HRS MAX");break;  
       case 3:print_str3_16_16("HRS MAX");break;
       case 4:print_str4_16_16("HRS MAX");break;
       default:break;       
       }               
////////////////////////////////////////////////////////               
//               print_str0_16_16("HRS MAX");
}
void disp_pertime(u8 wordtype)
{
//	       goto_xy(0x04,0x00);
  unsigned long x_middledata;
///////////////////////////////////////////////////////////////////////////////////
              if(SYS_Stateicon==1)
              {
                x_middledata=(60*x_Amount)/(x_Stime);
                print_asi111(wordtype,0x04); 
                
	       if(x_middledata/10000)
	        print_asi111(wordtype,16+x_middledata/10000%10);
	       if(x_middledata/1000)               
	        print_asi111(wordtype,16+x_middledata/1000%10);
	        print_asi111(wordtype,16+x_middledata/100%10);
                print_asi111(wordtype,0x0E);
	        print_asi111(wordtype,16+x_middledata/10%10);
	        print_asi111(wordtype,16+x_middledata%10);	               
///////////////////////////////////////////////////////////////////////////////////               
        //       print_asi111(wordtype,16+x_Stime/16);
        //       print_asi111(wordtype,16+x_Stime%16);
    //           print_str0_16_16("PER HOUR");
               print_asi111(wordtype,0x0F); 
      //         print_str0_16_16("HR"); 
////////////////////////////////////////////////////////
       switch(wordtype)
       {
       case 0:print_str0_16_16("HR");break;
       case 1:print_str_16_16("HR");break; 
       case 2:print_str2_16_16("HR");break;  
       case 3:print_str3_16_16("HR");break;
       case 4:print_str4_16_16("HR");break;
       default:break;       
       }
       }
       else if(SYS_Stateicon==2)
       {
                print_asi111(wordtype,0x04);               
	       if(x_Amount/10000)
	        print_asi111(wordtype,16+x_Amount/10000%10);
	       if(x_Amount/1000)               
	        print_asi111(wordtype,16+x_Amount/1000%10);
	        print_asi111(wordtype,16+x_Amount/100%10);
                print_asi111(wordtype,0x0E);
	        print_asi111(wordtype,16+x_Amount/10%10);
	        print_asi111(wordtype,16+x_Amount%10);	               
///////////////////////////////////////////////////////////////////////////////////               
        //       print_asi111(wordtype,16+x_Stime/16);
        //       print_asi111(wordtype,16+x_Stime%16);
    //           print_str0_16_16("PER HOUR");
               print_asi111(wordtype,0x0F); 
      //         print_str0_16_16("HR"); 
////////////////////////////////////////////////////////
       switch(wordtype)
       {
       case 0:print_str0_16_16("flat");break;
       case 1:print_str_16_16("flat");break; 
       case 2:print_str2_16_16("flat");break;  
       case 3:print_str3_16_16("flat");break;
       case 4:print_str4_16_16("flat");break;
       default:break;       
       }         
       }
              else if(SYS_Stateicon==0)
              {
////////////////////////////////////////////////////////
       switch(wordtype)
       {
       case 0:print_str0_16_16("free parking");break;
       case 1:print_str_16_16("free parking");break; 
       case 2:print_str2_16_16("free parking");break;  
       case 3:print_str3_16_16("free parking");break;
       case 4:print_str4_16_16("free parking");break;
       default:break;       
       }
       } 
              else if(SYS_Stateicon==3)
              {
////////////////////////////////////////////////////////
       switch(wordtype)
       {
       case 0:print_str0_16_16("No parking");break;
       case 1:print_str_16_16("No parking");break; 
       case 2:print_str2_16_16("No parking");break;  
       case 3:print_str3_16_16("No parking");break;
       case 4:print_str4_16_16("No parking");break;
       default:break;       
       }
       }        
////////////////////////////////////////////////////////               
//               print_str0_16_16("HRS MAX");
}
void disp_mainmenu2(void)
{  	
	/*       goto_xy(0x04,0x00);
///////////////////////////////////////////////////////////////////////////////////
                print_asi111(0x00,0x04);               
	       if(x_Amount/10000)
	        print_asi111(0x00,16+x_Amount/10000%10);
	       if(x_Amount/1000)               
	        print_asi111(0x00,16+x_Amount/1000%10);
	        print_asi111(0x00,16+x_Amount/100%10);
                print_asi111(0x00,0x0E);
	        print_asi111(0x00,16+x_Amount/10%10);
	        print_asi111(0x00,16+x_Amount%10);	               
///////////////////////////////////////////////////////////////////////////////////               
        //       print_asi111(0x00,16+x_Stime/16);
        //       print_asi111(0x00,16+x_Stime%16);
    //           print_str0_16_16("PER HOUR");
               print_asi111(0x00,0x0F); 
               print_str0_16_16("HR");
               */
               LoadMenuLcd(1,7);
               LoadMenuLcd(1,6);               
           //    print_asi111(0x00,16+(x_Stime/60)/10);
           //    print_asi111(0x00,16+(x_Stime/60)%10);                
	/*       goto_xy(0x04,0x50);
               	if((x_MaxPark/60)/10)
	       print_asi111(0x00,16+(x_MaxPark/60)/10);	
	       print_asi111(0x00,16+(x_MaxPark/60)%10);
               print_str0_16_16("HRS MAX"); 
               */              
	    /*   goto_xy(0x07,0x00);               
               print_asi111(0x00,16+x_StartTime_h/16);
               print_asi111(0x00,16+x_StartTime_h%16);        
	       print_str_16_16(":");
//               print_asi111(0x00,0x1A);
	       print_asi111(0x00,16+x_StartTime_min/16);	
	       print_asi111(0x00,16+x_StartTime_min%16);print_asi111(0x00,0x0D);     
	       print_asi111(0x00,16+x_EndTime_h/16);
	       print_asi111(0x00,16+x_EndTime_h%16);        
//	       print_str0_16_16(":");
               print_asi111(0x00,0x1A);
	       print_asi111(0x00,16+x_EndTime_min/16);	
	       print_asi111(0x00,16+x_EndTime_min%16);
	       goto_xy(0x07,0x60); 
               Disp_week(0x00,x_StartWeek);       
//	       print_str0_16_16(":");
               print_asi111(0x00,0x0D);
               Disp_week(0x00,x_EndWeek);    */          


                
	//print_str_16_16("2.Pay by credit");
             LoadMenuLcd(1,2); 
//	print_str_16_16("2.Pay by credit card");        
}
/*************************************************
  ������:          	void disp_mainmenu3(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_mainmenu3(void)
{  	
	goto_xy(0x08,0x00);
	
	if(CASH_FUC == ON)
        {
        }
//		print_str_16_16("3.Pay by sms");
//        LoadMenuLcd(1,3); 
	else
		print_str_16_16("3.Reserve");

}
void disp_mainmenu4(void)
{  		
	//goto_xy(9,32);
//	print_str_16_16("4.Administrator access");  //��Ҫ�İ�������
	CT_fb_on_gb_off();
        zimo =1;
        LoadMenuLcd(1,4);
        LoadMenuLcd(1,5);               
       // print_str_16_16("INSERT COINS");  //��Ҫ�İ������� 
	//goto_xy(13,24); 
        //print_str_16_16("OR CREDIT CARD");  //��Ҫ�İ�������  
        zimo =0;
	CT_fb_off_gb_off();        
       // goto_xy(18,0x00);
       // disp_CURTIM_16x32line0();
        LoadMenuLcd(1,3); 
}
/*
void disp_MainMenu(void)
{
	disp_Menu();
	disp_mainmenu1();
	disp_mainmenu2();
	disp_mainmenu3();
	disp_mainmenu4();
}*/
void disp_MainMenu_1(void)
{
	disp_Menu();
	goto_xy(0x00,0x00);
	disp_mainmenu1();
	delay(KEYTIMEOUT_1H2S);
}

void disp_MainMenu_2(void)
{
	disp_Menu();
	disp_mainmenu1();
	goto_xy(0x3C,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
	CT_fb_on_gb_off();
        zimo =1;
	disp_mainmenu2();
        zimo =0;
	CT_fb_off_gb_off();
	disp_mainmenu3();
	disp_mainmenu4();
	delay(KEYTIMEOUT_1H2S);
}

void disp_MainMenu_3(void)
{
	disp_Menu();
	disp_mainmenu1();
	disp_mainmenu2();
	goto_xy(10,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
	CT_fb_on_gb_off();
        zimo =1;
	disp_mainmenu3();
        zimo =0;
	CT_fb_off_gb_off();
	disp_mainmenu4();
	delay(KEYTIMEOUT_1H2S);
}
void disp_MainMenu_4(void)
{
	disp_Menu();
	disp_mainmenu1();
	disp_mainmenu2();
	disp_mainmenu3();
	goto_xy(0x64,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
	CT_fb_on_gb_off();
        zimo =1;
	disp_mainmenu4();
        zimo =0;
	CT_fb_off_gb_off();
	delay(KEYTIMEOUT_1H2S);
}
/*************************************************
  ������:          	void disp_please_swipecard(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_please_swipecard(void)
{  	
	goto_xy(0x06,0x07);
	print_str_16_16("Please read card"); 	
}
/*************************************************
  ������:          	void disp_Time_expired(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_Time_expired(void)
{  
	goto_xy(0x08,0x0b);
	print_str_16_16("Time out"); 	  
}

//Ӳ����ʾ��  
/*************************************************
  ������:          	void disp_check_coin(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_check_coin(void)
{  	
/***********************************************************************
   ���Ӳ����Checking coins.
***********************************************************************/
	goto_xy(0x06,0x07);
	print_str_16_16("Checking coins...");	 
/***********************************************************************
	��ȴ�Please wait...
***********************************************************************/
	goto_xy(10,0x09);
	print_str_16_16("Please wait...");

}
/*************************************************
  ������:          	void disp_con_cancel(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_con_cancel(void)
{  	
	goto_xy(14,0x0d);
	print_str_16_16("Confirm or Cancel");
									  
}
	  
void disp_expiry_C2(void)
{  	
	goto_xy(10,0x15);
}	   


/*************************************************
  ������:          	void display_coin_interface(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void display_coin_interface(void)
{  	
	goto_xy(0x08,0x06);
	print_str_16_16("Please insert coins");
}					

/*************************************************
  ������:          	void disp_freetime(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_freetime(void)
{  	
	goto_xy(0x08,0x08);
	print_str_16_16("Free parking"); 
}
/*************************************************
  ������:          	void pls_wt_Printing_ticket(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void pls_wt_Printing_ticket(void)
{  	
/***********************************************************************
Ʊ�ݴ�ӡ��,Ticket printing...
***********************************************************************/
	goto_xy(0x28,0x06);
	print_str_16_16("Ticket printing...");
	goto_xy(0x08,0x06);	
	print_str_16_16("Please wait...");
}	
/*************************************************
  ������:          	void disp_Print_failed(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_Print_failed(void)
{  	
	lcd_clear();
	goto_xy(0x08,0x06);
	print_str_16_16("Print failed");
} 
void disp_Recharge_failed(void)
{  	
	lcd_clear(); 
	goto_xy(0x08,0x01);
	print_str_16_16("Recharge failed,please retry"); 
} 
void disp_Recharge_Processing(void)
{  	
	lcd_clear();
	goto_xy(0x08,0x02);
	print_str_16_16("Processing,please wait..."); 
} 

//����������
/*************************************************
  ������:          	void disp_Input_6digital_password(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_Input_6digital_password(void)
{  	
	goto_xy(0x04,0x03);
	print_str_16_16("Input 6-digital password");	
	goto_xy(0x08,0x08);	 
}
		 
/*************************************************
  ������:          	void disp_X(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_X1(void)
{  	
	//goto_xy(0x50,0x09);
	//print_str("*"); 
	goto_xy(0x08,0x08);	 
}
void disp_X(void)
{  	
	print_str_32_32("*"); 
	//print_str("*"); 
}
void disp_(void)
{  	
	//print_str_32_32(" "); 
	//print_str_16_16(" "); 
        print_asi(0x00);
}
//��������
/*************************************************
  ������:          	void disp_adminmenu*(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_adminmenu1(void)
{  	
	goto_xy(0x00,0x00);
	print_str_16_16("1.PDA");	
      //  LoadMenuLcd(28,1);
}
void disp_adminmenu111(void)
{  	
	//goto_xy(0x00,0x00);
	print_str_16_16("1.PDA");	
      //  LoadMenuLcd(28,1);
}
void disp_adminmenu222(void)
{  	
	//goto_xy(0x04,0x00);
	print_str_16_16("2.System inquiry");
        //LoadMenuLcd(28,2);
}
void disp_adminmenu333(void)
{  	
	//goto_xy(0x08,0x00);
	print_str_16_16("3.Change secret");
       // LoadMenuLcd(28,3);
}
void disp_adminmenu444(void)
{  	
	//goto_xy(12,0x00);
	print_str_16_16("4.Open machine");
       // LoadMenuLcd(28,4);
}
void disp_adminmenu555(void)
{
  	print_str_16_16("5.Adjust contrast");
}
void disp_adminmenu666(void)
{
  	print_str_16_16("6.Get money");
}
void disp_adminmenu777(void)
{
  	print_str_16_16("7.Adjust blacklight");
}
void disp_adminmenu2(void)
{  	
	goto_xy(0x00,0x48);
	print_str_16_16("2.Maintenance");
}
void disp_adminmenu3(void)
{  	
	goto_xy(0x04,0x00);
//	print_str_16_16("3.Cash collection");  ///caseone
	print_str_16_16("3.Cash");  ///caseone        
}
void disp_adminmenu4(void)
{  	
	goto_xy(0x04,0x48);
	print_str_16_16("4.Machine test");
}
void disp_adminmenu5(void)
{  	
	goto_xy(0x08,0x00);
	print_str_16_16("5.System inquiry");
}
void disp_adminmenu6(void)
{  	
	goto_xy(12,0x00);
	print_str_16_16("6.Others");
}

void disp_Admin(void)
{
	lcd_clear();
	Refresh_SYSallicon();
}
/////////////////////////////////////////////////////////////////////////
void disp_Adminmenu_1111(void)
{
	disp_Admin();
	goto_xy(0x02,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
	CT_fb_on_gb_off();
        goto_xy(0x00,0x00);
	disp_adminmenu111();
	CT_fb_off_gb_off();
         goto_xy(0x04,0x00);
	disp_adminmenu222();
        goto_xy(0x08,0x00);
	disp_adminmenu333();
        goto_xy(0x0C,0x00);
	disp_adminmenu444();
	delay(KEYTIMEOUT_1H2S);
}
void disp_Adminmenu_2222(void)
{
	disp_Admin();
	goto_xy(0x02,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
        goto_xy(0x00,0x00);
	disp_adminmenu111();
	CT_fb_on_gb_off();
         goto_xy(0x04,0x00);
	disp_adminmenu222();
	CT_fb_off_gb_off();        
        goto_xy(0x08,0x00);
	disp_adminmenu333();
        goto_xy(0x0C,0x00);
	disp_adminmenu444();
	delay(KEYTIMEOUT_1H2S);
}
void disp_Adminmenu_3333(void)
{
	disp_Admin();
	goto_xy(0x02,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
        goto_xy(0x00,0x00);
	disp_adminmenu111();
         goto_xy(0x04,0x00);
	disp_adminmenu222();
	CT_fb_on_gb_off();        
        goto_xy(0x08,0x00);
	disp_adminmenu333();
	CT_fb_off_gb_off();        
        goto_xy(0x0C,0x00);
	disp_adminmenu444();
	delay(KEYTIMEOUT_1H2S);
}
void disp_Adminmenu_4444(void)
{
	disp_Admin();
	goto_xy(0x02,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
        goto_xy(0x00,0x00);
	disp_adminmenu111();
         goto_xy(0x04,0x00);
	disp_adminmenu222();
        goto_xy(0x08,0x00);
	disp_adminmenu333();
	CT_fb_on_gb_off();        
        goto_xy(0x0C,0x00);
	disp_adminmenu444();
	CT_fb_off_gb_off();        
	delay(KEYTIMEOUT_1H2S);
}
void disp_Adminmenu_5555(void)
{
	disp_Admin();
	goto_xy(0x02,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
        goto_xy(0x00,0x00);        
	disp_adminmenu222();
        goto_xy(0x04,0x00);
	disp_adminmenu333();
        goto_xy(0x08,0x00);
	disp_adminmenu444();
	CT_fb_on_gb_off();
        goto_xy(0x0C,0x00);        
	disp_adminmenu555();
	CT_fb_off_gb_off();        
	delay(KEYTIMEOUT_1H2S);
}
void disp_Adminmenu_6666(void)
{
	disp_Admin();
	goto_xy(0x02,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
        goto_xy(0x00,0x00);        
	disp_adminmenu333();
        goto_xy(0x04,0x00);
	disp_adminmenu444();
        goto_xy(0x08,0x00);
	disp_adminmenu555();
	CT_fb_on_gb_off();
        goto_xy(0x0C,0x00);        
	disp_adminmenu666();
	CT_fb_off_gb_off();        
	delay(KEYTIMEOUT_1H2S);
}
void disp_Adminmenu_7777(void)
{
	disp_Admin();
	goto_xy(0x02,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
        goto_xy(0x00,0x00);        
	disp_adminmenu444();
        goto_xy(0x04,0x00);
	disp_adminmenu555();
        goto_xy(0x08,0x00);
	disp_adminmenu666();
	CT_fb_on_gb_off();
        goto_xy(0x0C,0x00);        
	disp_adminmenu777();
	CT_fb_off_gb_off();        
	delay(KEYTIMEOUT_1H2S);
}
/////////////////////////////////////////////////////////////////////////////////
void disp_Adminmenu_1(void)
{
	disp_Admin();
	goto_xy(0x02,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
	CT_fb_on_gb_off();
	disp_adminmenu1();
	CT_fb_off_gb_off();
	disp_adminmenu2();
	disp_adminmenu3();
	disp_adminmenu4();
	disp_adminmenu5();
	disp_adminmenu6();
	delay(KEYTIMEOUT_1H2S);
}
void disp_Adminmenu_2(void)
{
	disp_Admin();
	disp_adminmenu1();
	goto_xy(0x23,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
	CT_fb_on_gb_off();
	disp_adminmenu2();
	CT_fb_off_gb_off();
	disp_adminmenu3();
	disp_adminmenu4();
	disp_adminmenu5();
	disp_adminmenu6();
	delay(KEYTIMEOUT_1H2S);
}
void disp_Adminmenu_3(void)
{
	disp_Admin();
	disp_adminmenu1();
	disp_adminmenu2();
	goto_xy(0x36,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
	CT_fb_on_gb_off();
	disp_adminmenu3();
	CT_fb_off_gb_off();
	disp_adminmenu4();
	disp_adminmenu5();
	disp_adminmenu6();
	delay(KEYTIMEOUT_1H2S);
}
void disp_Adminmenu_4(void)
{
	disp_Admin();
	disp_adminmenu1();
	disp_adminmenu2();
	disp_adminmenu3();
	goto_xy(0x49,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
	CT_fb_on_gb_off();
	disp_adminmenu4();
	CT_fb_off_gb_off();
	disp_adminmenu5();
	disp_adminmenu6();
	delay(KEYTIMEOUT_1H2S);
}
void disp_Adminmenu_5(void)
{
	disp_Admin();
	disp_adminmenu1();
	disp_adminmenu2();
	disp_adminmenu3();
	disp_adminmenu4();
	goto_xy(0x5C,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
	CT_fb_on_gb_off();
	disp_adminmenu5();
	CT_fb_off_gb_off();
	disp_adminmenu6();
	delay(KEYTIMEOUT_1H2S);
}

void disp_Adminmenu_6(void)
{
	disp_Admin();
	disp_adminmenu1();
	disp_adminmenu2();
	disp_adminmenu3();
	disp_adminmenu4();
	goto_xy(0x70,0x00);
	print_char_st(0xA0,0x10);
	print_char_st(0xA0,0x10);
	disp_adminmenu5();
	CT_fb_on_gb_off();
	disp_adminmenu6();
	CT_fb_off_gb_off();
	delay(KEYTIMEOUT_1H2S);
}


/*************************************************
  ������:          	void disp_PLS_opendoor(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_PLS_opendoor(void)
{  	
	goto_xy(0x20,0x05);
	print_str_16_16("Please open the door");
}
/*************************************************
  ������:          	void disp_outoforder(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_outoforder(void)
{  	
	goto_xy(0x20,0x09);
	print_str_16_16("Out of order");
	goto_xy(0x60,0x02);
}
void disp_outoforder1(void)
{  	
	goto_xy(0x70,0x02);
}
/*************************************************
  ������:          	void disp_outoforder(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_Repairing(void)
{  	
	goto_xy(0x50,0x0a);
	print_str_16_16("Repairing...");
}
void disp_PLS_collect_money(void)
{  	
	goto_xy(0x50,0x04);
	print_str_16_16("Please replace cash box");	
}

/*************************************************
  ������:          	void disp_data_loading(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_data_loading(void)
{  	
	goto_xy(0x40,0x06);
	print_str_16_16("Data downloading...");	  
}
/*************************************************
  ������:          	void disp_downsuccess(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_downsuccess(void)
{  	
	goto_xy(0x40,0x06);
	print_str_16_16("Download Successful");
}	
/*************************************************
  ������:          	void disp_ip_setsucess(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_ip_setsucess(void)
{  	
	goto_xy(0x40,0x04);
	print_str_16_16("IP setting successful");
	goto_xy(0x60,0x07);
}
/*************************************************
  ������:          	void disp_char(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_2X_2Y(void)	
{  	
	lcd_cmd_write(0xF1,0x5F);	    //����F1Ϊ01011111��ѡ�����зŴ����
}
void disp_1X_1Y(void)	
{  	
	lcd_cmd_write(0xF1,0x0F); 			//�������û�����̬��16*16
}
/*************************************************
  ������:          	void disp_coin_return(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_coin_return(void)
{  	
/**********************************************************************
��ȡ��Ӳ��Please take coins
********************************************************************/
	goto_xy(0x06,0x07);
	print_str_16_16("Please take coins");
}
/*************************************************
  ������:          	void disp_Beyond_20pcs(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_Beyond_20pcs(void)
{  	
	goto_xy(0x20,0x02);	 
	print_str_16_16("Max coins allowed: 20 pcs"); 
	goto_xy(0x50,0x07);
	print_str_16_16("Please take coins");
}
/*************************************************
  ������:          	void disp_ticket_remind(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_ticket_remind(void)
{  	
	goto_xy(0x30,0x06);
	print_str_16_16("Please take ticket");  
}
/*************************************************
  ������:          	void disp_testing(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_testing(void)
{  	
	goto_xy(0x30,0x07);
	print_str_16_16("Machine testing...");	 
	goto_xy(0x40,0x07);
	print_str_16_16("Please wait...");	
}		  
/*************************************************
  ������:          	void disp_pda_connecting(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_pda_connecting(void)
{  	
	goto_xy(0x30,0x08);
	print_str_16_16("Connecting...");
	disp_Cancel();
}	
/*************************************************
  ������:          	void disp_set_failed(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_set_failed(void)
{  	
	goto_xy(0x40,0x07);
	print_str_16_16("Connection failed");	
}
/*************************************************
  ������:          	void disp_time_ok(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_time_ok(void)
{  	
	goto_xy(0x40,0x08);
	print_str_16_16("Date and time");	
	goto_xy(0x50,0x07);
	print_str_16_16("setting successful");
}
/*************************************************
  ������:          	void disp_Successful(void)
  ��������:        // �������ܡ����ܵȵ�����
  �����ú����嵥:  // �����������õĺ����嵥
  ���ñ������嵥: // ���ñ������ĺ����嵥
  �������˵��:  // �������˵��������ÿ�����������á�ȡֵ˵�����������ϵ
  �������˵��:  // �����������˵����
  ����˵��:      // ����˵��
*************************************************/ 
void disp_Successful(void)
{  	
	goto_xy(0x20,0x0b);
	print_str_16_16("Successful");
	goto_xy(0x40,0x0b);
}
//mif ������ ��ʾ
/*void disp_max_min_time_mf1(void)
{  	
	disp_max_min_time_C1();
	disp_max_min_time_C2();
}*/	
void disp_max_min_time_mf2(void)
{  	
	goto_xy(0x30,0x02);
	print_str_16_16("Please input parking time");	/////δ����ģ
}
/*void disp_max_min_time_mf211(void)
{  							 
	print_str_32_32("00:00");
}*/
		 
											   

void display_mf_C2(void)
{
	goto_xy(0x20,0x15);			//����
}	

void display_mf_C4(void)
{  	
	disp_expiry_C2();
}						  



void disp_clearing(void)
{  	
	lcd_clear();
	goto_xy(0x30,0x02);
	print_str_32_32("Clearing..."); 
}
void disp_clear_ok(void)
{  	
	lcd_clear();
	goto_xy(0x30,0x06);
	print_str_32_32("Clear ok!"); 
}
void disp_SYSInfo_head(void)	 //��Ϣͷ
{
	Refresh_SYSallicon();
	goto_xy(0x00,no_x_y+9);	 
	print_str_16_16("System Info");//12
	
	goto_xy(0x04,no_x_y);
	print_char_st(0xA0,0x10);
	CT_fb_on_gb_off();
	//print_str_16_16("['P'-print]");//12
	print_str_16_16("'P'=print");//12
	//CT_fb_off_gb_off();
	print_char_st(0xA0,0x11);
	goto_xy(0x04,0x13);
	SYS_Vision();
}
//��ѯ�˵�	
void disp_Machine_no(void)	 //�����
{
	
	goto_xy(0x04,no_x_y);
	print_str_16_16("Machine no");
        print_asi(0x1A);
        goto_xy(0x08,no_x_y);
	I2C_ReadS_24C(PakingMeterNumber_add,FMI2C_buf,3);
	print_num16_char(FMI2C_buf[0]);
	print_num16_char(FMI2C_buf[1]);
	print_num16_char(FMI2C_buf[2]);
}
void disp_Street_no(void)	//�ֵ���
{	 	 
	goto_xy(0x04,no_x_y);
	print_str_16_16("Location"); 
        print_asi(0x1A);
	goto_xy(0x08,no_x_y);        
	I2C_ReadS_24C(StreetNumber_add,FMI2C_buf,60);	
	print_str_16_16(FMI2C_buf);
	I2C_ReadS_24C(SaveSetRouteCode_add,FMI2C_buf,1);	
	print_str_16_16("(");
	print_num16_char(FMI2C_buf[0]);
	print_str_16_16(")");
	
}	 
void disp_System_tariff(void) //ϵͳ����
{
	//goto_xy(0x04,no_x_y);
	//print_str_16_16("PRESS oK to quit"); 
  return;
} 
void disp_IP_no(void)	   //IP��
{
	u8 ipsum,i;
	
	goto_xy(0x00,no_x_y);
	print_str_16_16("IP of Server"); 
        print_asi(0x1A);
	goto_xy(0x04,no_x_y+5);
//	I2C_ReadS_24C(IP_Length_add,FMI2C_buf,1);
	ipsum = FMI2C_buf[0];
//	I2C_ReadS_24C(IP_Port_add,FMI2C_buf,ipsum);//ipsum);	
	//FMI2C_buf[ipsum] = '\0';
	//print_str_16_16(FMI2C_buf);
	//for(ipsum =0 ;ipsum<10;ipsum++)
	//print_num16_char(FMI2C_buf[ipsum]);
	Refresh_SYSallicon();
	goto_xy(0x04,no_x_y);
	//for(i=1;i<ipsum;i++)
	for(i=0;i<ipsum;i++)          
	{
	if(FMI2C_buf[i]>=0x30)
	{
        if(FMI2C_buf[i]==0x50)
        {
       goto_xy(0x08,no_x_y);          
       print_str_16_16("P");
        }
       else
       {
	FMI2C_buf[i]=FMI2C_buf[i]-0x30;
	print_num16_16(FMI2C_buf[i]);
         }
	}
	else
	{
       print_asi(0x0E);
	}
	}        
        
}
void disp_DPSIP_no(void)	   //IP��
{
	u8 ipsum,i;
	
	goto_xy(0x00,no_x_y);
	print_str_16_16("IP of DPS"); 
        print_asi(0x1A);
	//goto_xy(0x50,no_x_y+5);
//	I2C_ReadS_24C(DPSIP_Length_add,FMI2C_buf,1);
	ipsum = FMI2C_buf[0];
//	I2C_ReadS_24C(DPSIP_Port_add,FMI2C_buf,ipsum);//ipsum);	
	//FMI2C_buf[ipsum] = '\0';
	//print_str_16_16(FMI2C_buf);
	Refresh_SYSallicon();
	goto_xy(0x04,no_x_y);
	//for(i=1;i<ipsum;i++)
	for(i=0;i<ipsum;i++)          
	{
	if(FMI2C_buf[i]>=0x30)
	{
        if(FMI2C_buf[i]==0x50)
        {
       goto_xy(0x08,no_x_y);          
       print_str_16_16("P");
        }
       else
       {
	FMI2C_buf[i]=FMI2C_buf[i]-0x30;
	print_num16_16(FMI2C_buf[i]);
         }
	}
	else
	{
       print_asi(0x0E);
	}
	} 
}

//��ʾ���׽��
void Disp_SYSMoney(void)
{
u8  startdisp = 0;
u32 DispMoney,tempnum;

	DispMoney = (FMI2C_buf[0]<<24)+(FMI2C_buf[1]<<16)+(FMI2C_buf[2]<<8)+FMI2C_buf[3];
	
	if(DispMoney == NULL)
		{
		print_num16_16(DispMoney);
		return;
		}
	
	tempnum = 10000000;	
	while(tempnum)
		{
		if((DispMoney/tempnum)||startdisp)
			{
			print_num16_16(DispMoney/tempnum%10);
			startdisp = 1;
			if(tempnum ==100)
				print_str_16_16(".");
			}
		tempnum /= 10;
		}
	return;
}
//��ʾ���״���
void Disp_SYStranstime(void)
{
u8  startdisp = 0;
u32 DispTranstime,tempnum;

	DispTranstime = (FMI2C_buf[0]<<16)+(FMI2C_buf[1]<<8)+FMI2C_buf[2];

	if(DispTranstime == NULL)
		{
		print_num16_16(DispTranstime);
		return;
		}
	
	tempnum = 100000;	
	while(tempnum)
		{
		if((DispTranstime/tempnum)||startdisp)
			{
			print_num16_16(DispTranstime/tempnum%10);
			startdisp = 1;
			}
		tempnum /= 10;
		}
	return;
}	

//�ڶ�ҳ
void disp_APN_no(void)	   //APN��
{
	goto_xy(0x00,no_x_y);
	print_str_16_16("APN"); 
        print_asi(0x1A);
	goto_xy(0x04,no_x_y);        
	memset(FMI2C_buf ,0 ,60);
//	I2C_ReadS_24C(APN_USERNAME_PASSWORD_add,FMI2C_buf,60);	
	print_str_16_16(FMI2C_buf);
}

void disp_APN_no1(void)	   //APN��
{
	goto_xy(0x04,no_x_y);
	print_str_16_16("APN");
        print_asi(0x1A);
}
void disp_APN_no2(void)	   //APN��
{
	goto_xy(0x04,no_x_y);
}
void disp_Preset_coincount(void)	 //Ӳ��������
{
	goto_xy(0x04,no_x_y);
	print_str_16_16("Max coins"); //14
        print_asi(0x1A);
	goto_xy(0x08,no_x_y);        
//	I2C_ReadS_24C(CoinAlarmNumber_add,FMI2C_buf,2);
	FMI2C_buf[2] = FMI2C_buf[1];
	FMI2C_buf[1] = FMI2C_buf[0];	
	FMI2C_buf[0] = 0;
	Disp_SYStranstime();
}
void disp_Box_coincount(void)	 //ʵ��Ӳ����
{
	goto_xy(0x30,no_x_y);
	print_str_16_16("Present coins:"); //Present coins: XXX 	
//	I2C_ReadS_24C(CoinNumberGetmoney_add,FMI2C_buf,2);
	FMI2C_buf[2] = FMI2C_buf[1];
	FMI2C_buf[1] = FMI2C_buf[0];	
	FMI2C_buf[0] = 0;
	Disp_SYStranstime();
}
void disp_Preset_billcount(void)	 //Ӳ��������
{
	goto_xy(0x40,no_x_y);
	print_str_16_16("Max bills:"); //14
//	I2C_ReadS_24C(PaperAlarmNumber_add,FMI2C_buf,2);
	FMI2C_buf[2] = FMI2C_buf[1];
	FMI2C_buf[1] = FMI2C_buf[0];	
	FMI2C_buf[0] = 0;
	Disp_SYStranstime();
}
void disp_Box_billcount(void)	 //ʵ��Ӳ����
{
	goto_xy(0x50,no_x_y);
	print_str_16_16("Present bills:"); //Present coins: XXX 
//	I2C_ReadS_24C(PaperNumberGetmoney_add,FMI2C_buf,2);
	FMI2C_buf[2] = FMI2C_buf[1];
	FMI2C_buf[1] = FMI2C_buf[0];	
	FMI2C_buf[0] = 0;
	Disp_SYStranstime();
}
//����ҳ
void disp_Total_amount(void)	 //�ܽ��׽��
{		   
	goto_xy(0x20,no_x_y);
	print_str_16_16("Total amount:"); 
//	I2C_ReadS_24C(AllMoneyGetmoney_add,FMI2C_buf,4);
	Disp_SYSMoney();
}
void disp_Total_Transcations(void)	 //�ܽ��״���
{		   
	goto_xy(0x30,no_x_y);
	print_str_16_16("Total transaction times:"); 
//	I2C_ReadS_24C(AllTimesGetmoney_add,FMI2C_buf,3);
	Disp_SYStranstime();
}

//����ҳ
void disp_Total_Cash(void)	 //���ֽ� ����Ӳ������
{
	goto_xy(0x20,no_x_y);
	print_str_16_16("Total coin amount:"); 
//	I2C_ReadS_24C(CoinMoneyGetmoney_add,FMI2C_buf,4);
	Disp_SYSMoney();
}
void disp_Total_CashTranscations(void)	 //���ֽ� ����Ӳ������
{
	goto_xy(0x30,no_x_y);
	print_str_16_16("Coin transaction times:"); 
//	I2C_ReadS_24C(CoinTimesGetmoney_add,FMI2C_buf,3);
	Disp_SYStranstime();
}

void disp_Total_Card_Payment(void)	 //�ܸ�Ӧ�����
{

	goto_xy(0x40,no_x_y);
	print_str_16_16("Total card amount:"); 
//	I2C_ReadS_24C(BankMoneyGetmoney_add,FMI2C_buf,4);
	Disp_SYSMoney();
}
void disp_Total_Card_PaymentTranscations(void)	 //�ܸ�Ӧ�����
{

	goto_xy(0x50,no_x_y);
	print_str_16_16("Card transaction times:"); 
//	I2C_ReadS_24C(BankTimesGetmoney_add,FMI2C_buf,3);
	Disp_SYStranstime();
}
void disp_Total_Bill(void)	 //�ܸ�Ӧ�����
{
	goto_xy(0x60,no_x_y);
	print_str_16_16("Total bill amount :"); 
//	I2C_ReadS_24C(PaperMoneyGetmoney_add,FMI2C_buf,4);
	Disp_SYSMoney();
}	
void disp_Total_BillTranscations(void)	 //�ܸ�Ӧ�����
{
	goto_xy(0x70,no_x_y);
	print_str_16_16("Bill transaction times :"); 
//	I2C_ReadS_24C(PaperTimesGetmoney_add,FMI2C_buf,3);
	Disp_SYStranstime();
}	


//ˢ���շѹ���	  
void disp_nouse_error(void)
{  	
	lcd_clear();
	goto_xy(0x20,0x04);
	print_str_16_16("Card module error"); 
	goto_xy(0x60,0x02);
}	
void disp_nouse_error1(void)
{  	
	lcd_clear();
	goto_xy(0x20,0x07);
	print_str_16_16("Coin module error");  
	goto_xy(0x60,0x02);
}	
void disp_nouse_error2(void)
{  	
	lcd_clear();
	goto_xy(0x20,0x07);
	print_str_16_16("SMS module error"); 
	goto_xy(0x60,0x02);
}	
//��ѡ���������ѷ�ʽ	
void disp_other_error(void)
{  	
	goto_xy(0x40,0x09);
	print_str_16_16("Please choose");
	goto_xy(0x50,0x05);
	print_str_16_16("other payment method");
	goto_xy(0x60,0x02);
}			

//Ӳ���շѹ���	
void disp_Coinmodule_error(void)
{  	   
	lcd_clear();
	goto_xy(0x20,0x07);
	print_str_16_16("Coin module error");  
	disp_other_error();
}	
//ˢ���շѹ���	  
void disp_Cardmodule_error(void)
{  	
	lcd_clear();
	goto_xy(0x20,0x07);
	print_str_16_16("Card module error"); 
	disp_other_error();
}
/*----------------------------------------------------------------------
function name:   	void disp_use_money1(unsigned long bb)
describe:    	 	���˵�
input:   			
output:
date:			andyluo 2010-12-03 14:26:57
------------------------------------------------------------------------
void disp_use_money(unsigned long bb)
{
	//u32 bb1,bb2,bb3,bb4;

	goto_xy(0x30,0x00);
	print_str_16_16("Amount paid     ");
	goto_xy(0x20,0x12);
	//bb1 = bb/10;
	//bb2 = bb/100;
	//bb3 = bb/1000;
	//bb4 = bb/10000;
	if(bb/10000)
		print_num32_32(bb/10000%10);
	print_num32_32(bb/1000%10);
	print_num32_32(bb/100%10);
	print_asi(0x0E);	
	print_num32_32(bb/10%10);
	print_num32_32(bb%10);	
	return;
}*/
/*----------------------------------------------------------------------
function name:   	void disp_use_time1(unsigned long bb)
describe:    	 	���˵�
input:   			
output:
date:			andyluo 2010-12-03 14:26:57
------------------------------------------------------------------------
void disp_use_time(unsigned long bb)
{

	goto_xy(10,0x00);
	print_str_16_16("Purchased time");
	goto_xy(0x08,0x12);
	if(bb/6000)
		print_num32_32(bb/6000%10);	
	print_num32_32(bb/600%10);
	print_num32_32(bb/60%10);
	print_asi(0x1A);	
	print_num32_32(bb/10%6);
	print_num32_32(bb/10%10);	
	return;
}*/

void disp_user_OK1(u16 user_time)
{
	u8 time3[7],cheweino[8];	
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
  cheweino[0]=chewei;
  cheweino[1]=time1[4];
  cheweino[2]=time1[3];
  cheweino[3]=time1[2];
  cheweino[4]=time1[1];
  cheweino[5]=time1[0];
  cheweino[6]=(user_time>>8)&0xff;
  cheweino[7]=user_time&0xff;
  if(user_time!=0)
  {

	  switch(chewei)
		  {
		  case 0x10: I2C_WriteS_24C(ltime,cheweino,8);PrintandCoinout_LED_OPEN;break;
		  case 0x20: I2C_WriteS_24C(lltime,cheweino,8);SYSERROR_LED_OPEN;break;
		  case 0x30: I2C_WriteS_24C(rtime,cheweino,8);LED1_OPEN;break;
		  case 0x40: I2C_WriteS_24C(rrtime,cheweino,8);LED2_OPEN;break;	
		  default: break;
		  }
  }
//  delay(85000);        
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
	math_time(user_time,time3);		
	goto_xy(0x00,0x00);
	//print_str_16_16("Present time ");
        LoadMenuLcd(5,1);
	//disp_time1(2,time1);
        goto_xy(0x04,0x00);
	print_num16_16(time1[2]/10);
	print_num16_16(time1[2]%10);
	//print_str_16_16("/");
        print_asi(0x0F);
	print_num16_16(time1[3]/10);
	print_num16_16(time1[3]%10);
	//print_str_16_16("/");
        print_asi(0x0F);
	print_str_16_16("20");	
	print_num16_16(time1[4]/10);
	print_num16_16(time1[4]%10);
	//print_str_16_16(" ");
        print_asi(0x00);
	print_num16_16(time1[1]/10);
	print_num16_16(time1[1]%10);
	//print_str_16_16(":");
        print_asi(0x1A);
	print_num16_16(time1[0]/10);
	print_num16_16(time1[0]%10);
	
	goto_xy(0x08,0x00);
	//print_str_16_16("Expiry time ");
        LoadMenuLcd(5,3);
	//disp_time1(6,time3);
        goto_xy(12,0x00);
	print_num16_16(time3[2]/10);
	print_num16_16(time3[2]%10);
	//print_str_16_16("/");
        print_asi(0x0F);
	print_num16_16(time3[3]/10);
	print_num16_16(time3[3]%10);
	//print_str_16_16("/");
        print_asi(0x0F);
	print_str_16_16("20");	
	print_num16_16(time3[4]/10);
	print_num16_16(time3[4]%10);
	//print_str_16_16(" ");
        print_asi(0x00);
	print_num16_16(time3[1]/10);
	print_num16_16(time3[1]%10);
	//print_str_16_16(":");
        print_asi(0x1A);
	print_num16_16(time3[0]/10);
	print_num16_16(time3[0]%10);	
}
void disp_user_OK(u16 user_time)
{
	u8 time3[7],cheweino[8];	
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
  cheweino[0]=chewei;
  cheweino[1]=time1[4];
  cheweino[2]=time1[3];
  cheweino[3]=time1[2];
  cheweino[4]=time1[1];
  cheweino[5]=time1[0];
  cheweino[6]=((user_time+left_time)>>8)&0xff;
  cheweino[7]=(user_time+left_time)&0xff;
  if(user_time!=0)
  {

	  switch(chewei)
		  {
		  case 0x10: I2C_WriteS_24C(ltime,cheweino,8);if(f_occupied==0)I2C_WriteS_24C(ltime_start,cheweino,8);PrintandCoinout_LED_OPEN;break;
		  case 0x20: I2C_WriteS_24C(lltime,cheweino,8);if(f_occupied==0)I2C_WriteS_24C(lltime_start,cheweino,8);SYSERROR_LED_OPEN;break;
		  case 0x30: I2C_WriteS_24C(rtime,cheweino,8);if(f_occupied==0)I2C_WriteS_24C(rtime_start,cheweino,8);LED1_OPEN;break;
		  case 0x40: I2C_WriteS_24C(rrtime,cheweino,8);if(f_occupied==0)I2C_WriteS_24C(rrtime_start,cheweino,8);LED2_OPEN;break;	
		  default: break;
		  }
  }
//  delay(85000);        
}
//////////////////////////////////////////////////////////////////////////////
void disp_user_maintime(u8 timemode,u16 user_time,u16 user_money)
{
	u8 time3[7];	
///////////////////////////////////////////////////////////////
        LoadMenuLcd(4,1);  
        LoadMenuLcd(4,2); 
        LoadMenuLcd(4,3); 
        LoadMenuLcd(4,4);  
        LoadMenuLcd(4,5); 
        LoadMenuLcd(4,6);
        LoadMenuLcd(4,7);  
        LoadMenuLcd(4,8); 
        LoadMenuLcd(4,9);
        LoadMenuLcd(4,0x0A);        
///////////////////////////////////////////////////////////////
/*	math_time(user_time,time3);	

	goto_xy(0x00,0x01);
//	print_str_16_16("Amount paid");
        LoadMenuLcd(4,1);
	goto_xy(0x08,0x01);
	//print_str_16_16("Purchased time");	
	LoadMenuLcd(4,3);
	//if(timemode != CreditMode)
	//	CT_fb_on_gb_off();
	goto_xy(0x04,0x02);			
	if(user_money/10000)
		print_num32_32(user_money/10000%10);
	print_num32_32(user_money/1000%10);
	print_num32_32(user_money/100%10);
print_asi(0x0E);
	print_num32_32(user_money/10%10);
	print_num32_32(user_money%10);	
	//if(timemode != CreditMode)
	//	CT_fb_off_gb_off();
	
	//if(timemode == CreditMode)
	//	CT_fb_on_gb_off();
	goto_xy(12,0x02);				
	if(user_time/6000)
		print_num32_32(user_time/6000%10);	
	print_num32_32(user_time/600%10);
	print_num32_32(user_time/60%10);
	print_asi(0x1A);	
	print_num32_32(user_time/10%6);
	print_num32_32(user_time%10);	*/
/*
	if(timemode == CreditMode)
		{
		CT_fb_off_gb_off();
		goto_xy(0x30,0x03);
		print_str_16_16("'Up'/'Down' -- +/-15Min");
		}*/
} 
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
void disp_purch_time1(u8 wordtype)
{

	        if(purch_time/6000)
		print_asi111(wordtype,16+purch_time/6000%10);	
	        print_asi111(wordtype,16+purch_time/600%10);
	        print_asi111(wordtype,16+purch_time/60%10);
	        print_asi111(wordtype,0x1A);	
	        print_asi111(wordtype,16+purch_time/10%6);
	        print_asi111(wordtype,16+purch_time%10);	
} 
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
void disp_purch_money1(u8 wordtype)
{
	      if(purch_money/10000)
	      print_asi111(wordtype,16+purch_money/10000%10);
	      print_asi111(wordtype,16+purch_money/1000%10);
	      print_asi111(wordtype,16+purch_money/100%10);
              print_asi111(wordtype,0x0E);
	      print_asi111(wordtype,16+purch_money/10%10);
	      print_asi111(wordtype,16+purch_money%10);	
}
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
void disp_MinPark(u8 wordtype)
{
	        if(x_MinPark/6000)
		print_asi111(wordtype,16+x_MinPark/6000%10);	
	        print_asi111(wordtype,16+x_MinPark/600%10);
	        print_asi111(wordtype,16+x_MinPark/60%10);
//	        print_str0_16_16(":");	
	        print_asi111(wordtype,0x3A);              
	        print_asi111(wordtype,16+x_MinPark/10%6);
	        print_asi111(wordtype,16+x_MinPark%10);	
}
/////////////////////////////////////////////////////////////////////////////////
void disp_MinCost(u8 wordtype)
{
	      if(x_MinCost/10000)
	      print_asi111(wordtype,16+x_MinCost/10000%10);
	      print_asi111(wordtype,16+x_MinCost/1000%10);
	      print_asi111(wordtype,16+x_MinCost/100%10);
              print_asi111(wordtype,0x0E);
	      print_asi111(wordtype,16+x_MinCost/10%10);
	      print_asi111(wordtype,16+x_MinCost%10); 
}
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
void disp_user_maintime1(u8 timemode,u16 user_time,u16 user_money)
{
	u8 time3[7],f_AM;	

	math_time(user_time+left_time,time3);	
/////////////////////////////////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////////////////////
        LoadMenuLcd(16,1);  
        LoadMenuLcd(16,2); 
        LoadMenuLcd(16,3); 
        LoadMenuLcd(16,4);  
        LoadMenuLcd(16,5); 
        LoadMenuLcd(16,6);
        LoadMenuLcd(16,7);  
        LoadMenuLcd(16,8); 
        LoadMenuLcd(16,9);
        LoadMenuLcd(16,0x0A);        
///////////////////////////////////////////////////////////////         
/////////////////////////////////////////////////////////////////////////////////////////
        /*
	        goto_xy(0,0x00);
	        print_str0_16_16("WELCOME TO ABC CITY");
                goto_xy(0x02,0);                
	        print_str0_16_16("MIN ");
	        if(x_MinPark/6000)
		print_asi111(0x00,16+x_MinPark/6000%10);	
	        print_asi111(0x00,16+x_MinPark/600%10);
	        print_asi111(0x00,16+x_MinPark/60%10);
	        print_str0_16_16(":");	
	        print_asi111(0x00,16+x_MinPark/10%6);
	        print_asi111(0x00,16+x_MinPark%10);	
	      goto_xy(0x02,0x60);
              print_asi111(0x00,0x04);
	      if(x_MinCost/10000)
	      print_asi111(0x00,16+x_MinCost/10000%10);
	      print_asi111(0x00,16+x_MinCost/1000%10);
	      print_asi111(0x00,16+x_MinCost/100%10);
              print_asi111(0x00,0x0E);
	      print_asi111(0x00,16+x_MinCost/10%10);
	      print_asi111(0x00,16+x_MinCost%10);                
     //           goto_xy(0x02,0);                
	//        print_str0_16_16("MIN");                
	        CT_fb_on_gb_off(); 
                 zimo=1;
                goto_xy(0x06,8);
	        if(user_time/6000)
		print_asi111(0x01,16+user_time/6000%10);	
	        print_asi111(0x01,16+user_time/600%10);
	        print_asi111(0x01,16+user_time/60%10);
	        print_asi111(0x01,0x1A);	
	        print_asi111(0x01,16+user_time/10%6);
	        print_asi111(0x01,16+user_time%10);	
       //         CT_fb_off_gb_off();
	//	zimo=0;
////////////////////////////////////////////////////////////////////////////////
          //      goto_xy(0x06,40);                
	  //      print_str0_16_16("MIN");                
////////////////////////////////////////////////////////////////////////////////
             //  parking_station=time2money(u1time1);
             //   u1time2=Good_money;  
////////////////////////////////////////////////////////////////////////////////
	      goto_xy(0x06,0x60);
              print_asi111(0x01,0x04);
	      if(user_money/10000)
	      print_asi111(0x01,16+user_money/10000%10);
	      print_asi111(0x01,16+user_money/1000%10);
	      print_asi111(0x01,16+user_money/100%10);
              print_asi111(0x01,0x0E);
	      print_asi111(0x01,16+user_money/10%10);
	      print_asi111(0x01,16+user_money%10);	                
              CT_fb_off_gb_off();
              zimo=0;
////////////////////////////////////////////////////////////////////////////////
                goto_xy(12,16);   
               print_str0_16_16("Expires at ");
	       print_asi111(0x00,16+time3[1]/10);
	       print_asi111(0x00,16+time3[1]%10);        
//	       print_str0_16_16(":");
              print_str0_16_16(":");print_str0_16_16(":");
	       print_asi111(0x00,16+time3[0]/10);	
	       print_asi111(0x00,16+time3[0]%10);	
                 LoadMenuLcd(4,5);
                 */
} 
//////////////////////////////////////////////////////////////////////////////
void disp_user_maintime2(u8 timemode,u16 user_time,u16 user_money)
{
	u8 time3[7],f_AM;	

	math_time(user_time+left_time,time3);	
/////////////////////////////////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////////////////////
        LoadMenuLcd(17,1);  
        LoadMenuLcd(17,2); 
        LoadMenuLcd(17,3); 
        LoadMenuLcd(17,4);  
        LoadMenuLcd(17,5); 
        LoadMenuLcd(17,6);
        LoadMenuLcd(17,7);  
        LoadMenuLcd(17,8); 
        LoadMenuLcd(17,9);
        LoadMenuLcd(17,0x0A);        
///////////////////////////////////////////////////////////////         
/////////////////////////////////////////////////////////////////////////////////////////
	        goto_xy(1,16);
	        print_str_16_16("MAX TIME ALLOWED");                
	        CT_fb_on_gb_off(); 
                 zimo=1;
                goto_xy(0x08,8);
	        if(user_time/6000)
		print_asi111(0x01,16+user_time/6000%10);	
	        print_asi111(0x01,16+user_time/600%10);
	        print_asi111(0x01,16+user_time/60%10);
	        print_asi111(0x01,0x1A);	
	        print_asi111(0x01,16+user_time/10%6);
	        print_asi111(0x01,16+user_time%10);	
       //         CT_fb_off_gb_off();
	//	zimo=0;
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
             //  parking_station=time2money(u1time1);
             //   u1time2=Good_money;  
////////////////////////////////////////////////////////////////////////////////
	      goto_xy(0x08,0x60);
              print_asi111(0x01,0x04);
	      if(user_money/10000)
	      print_asi111(0x01,16+user_money/10000%10);
	      print_asi111(0x01,16+user_money/1000%10);
	      print_asi111(0x01,16+user_money/100%10);
              print_asi111(0x01,0x0E);
	      print_asi111(0x01,16+user_money/10%10);
	      print_asi111(0x01,16+user_money%10);	                
              CT_fb_off_gb_off();
              zimo=0;
////////////////////////////////////////////////////////////////////////////////
                goto_xy(14,16);   
               print_str0_16_16("Expires at ");
          /*     f_AM=1;
            //   if(sz2[1]>=0x12)
               if(time3[1]>=12)                 
               {
               time3[1]= time3[1]-12;
               f_AM=0;
               }*/
	       print_asi111(0x00,16+time3[1]/10);
	       print_asi111(0x00,16+time3[1]%10);        
//	       print_str0_16_16(":");
               print_str0_16_16(":");print_str0_16_16(":");
	       print_asi111(0x00,16+time3[0]/10);	
	       print_asi111(0x00,16+time3[0]%10);	
          /*     if(f_AM==1 )
                print_str0_16_16("AM "); 
               else
                 print_str0_16_16("FM "); */
            //   	goto_xy(16,0x00);        
            //   disp_CURTIM_16x32line0();       
/////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////
} 
/////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
void disp_user_maintime12(u8 timemode,u16 user_time,u16 user_money)
{
	u8 time3[7];	
///////////////////////////////////////////////////////////////
        LoadMenuLcd(5,1);  
        LoadMenuLcd(5,2); 
        LoadMenuLcd(5,3); 
        LoadMenuLcd(5,4);  
        LoadMenuLcd(5,5); 
        LoadMenuLcd(5,6);
        LoadMenuLcd(5,7);  
        LoadMenuLcd(5,8); 
        LoadMenuLcd(5,9);
        LoadMenuLcd(5,0x0A);        
///////////////////////////////////////////////////////////////
        /*
	math_time(user_time,time3);	

	goto_xy(0x08,0x01);
	//print_str_16_16("Amount paid");
        LoadMenuLcd(9,3);
	goto_xy(0x00,0x01);
	//print_str_16_16("Purchased time");	
	LoadMenuLcd(9,1);
	//if(timemode != CreditMode)
	//	CT_fb_on_gb_off();
	goto_xy(12,0x02);			
	if(user_money/10000)
		print_num32_32(user_money/10000%10);
	print_num32_32(user_money/1000%10);
	print_num32_32(user_money/100%10);
print_asi(0x0E);
	print_num32_32(user_money/10%10);
	print_num32_32(user_money%10);	
	//if(timemode != CreditMode)
	//	CT_fb_off_gb_off();
	
	//if(timemode == CreditMode)
	//	CT_fb_on_gb_off();
	goto_xy(0x04,0x02);				
	if(user_time/6000)
		print_num32_32(user_time/6000%10);	
	print_num32_32(user_time/600%10);
	print_num32_32(user_time/60%10);
	print_asi(0x1A);	
	print_num32_32(user_time/10%6);
	print_num32_32(user_time%10);	
/*
	if(timemode == CreditMode)
		{
		CT_fb_off_gb_off();
		goto_xy(0x30,0x03);
		print_str_16_16("'Up'/'Down' -- +/-15Min");
		}*/
} 
//////////////////////////////////////////////////////////////////////////////
void disp_user_maintime13(u8 timemode,u16 user_time,u16 user_money)
{
	u8 time3[7],f_AM;	

	math_time(user_time+left_time,time3);	
	//        goto_xy(1,0x00);
	//        print_str0_16_16("WELCOME TO ABC CITY");
//////////////////////////////////////////////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////////////////////
        LoadMenuLcd(18,1);  
        LoadMenuLcd(18,2); 
        LoadMenuLcd(18,3); 
        LoadMenuLcd(18,4);  
        LoadMenuLcd(18,5); 
        LoadMenuLcd(18,6);
        LoadMenuLcd(18,7);  
        LoadMenuLcd(18,8); 
        LoadMenuLcd(18,9);
        LoadMenuLcd(18,0x0A);        
///////////////////////////////////////////////////////////////          
//////////////////////////////////////////////////////////////////////////////////////////////////////        
/*                goto_xy(0x00,0);                
	        print_str0_16_16("MIN ");
	        if(x_MinPark/6000)
		print_asi111(0x00,16+x_MinPark/6000%10);	
	        print_asi111(0x00,16+x_MinPark/600%10);
	        print_asi111(0x00,16+x_MinPark/60%10);
	        print_str0_16_16(":");	
	        print_asi111(0x00,16+x_MinPark/10%6);
	        print_asi111(0x00,16+x_MinPark%10);	
	      goto_xy(0x00,0x60);
              print_asi111(0x00,0x04);
	      if(x_MinCost/10000)
	      print_asi111(0x00,16+x_MinCost/10000%10);
	      print_asi111(0x00,16+x_MinCost/1000%10);
	      print_asi111(0x00,16+x_MinCost/100%10);
              print_asi111(0x00,0x0E);
	      print_asi111(0x00,16+x_MinCost/10%10);
	      print_asi111(0x00,16+x_MinCost%10); 
////////////////////////////////////////////////////////              
	        CT_fb_on_gb_off(); 
                 zimo=1;
                goto_xy(0x03,8);
	        if(user_time/6000)
		print_asi111(0x01,16+user_time/6000%10);	
	        print_asi111(0x01,16+user_time/600%10);
	        print_asi111(0x01,16+user_time/60%10);
	        print_asi111(0x01,0x1A);	
	        print_asi111(0x01,16+user_time/10%6);
	        print_asi111(0x01,16+user_time%10);	
       //         CT_fb_off_gb_off();
	//	zimo=0;
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
             //  parking_station=time2money(u1time1);
             //   u1time2=Good_money;  
////////////////////////////////////////////////////////////////////////////////
	      goto_xy(0x03,0x60);
              print_asi111(0x01,0x04);
	      if(user_money/10000)
	      print_asi111(0x01,16+user_money/10000%10);
	      print_asi111(0x01,16+user_money/1000%10);
	      print_asi111(0x01,16+user_money/100%10);
              print_asi111(0x01,0x0E);
	      print_asi111(0x01,16+user_money/10%10);
	      print_asi111(0x01,16+user_money%10);	                
              CT_fb_off_gb_off();
              zimo=0;
////////////////////////////////////////////////////////////////////////////////
                goto_xy(8,16);   
               print_str0_16_16("Expires at ");
	       print_asi111(0x00,16+time3[1]/10);
	       print_asi111(0x00,16+time3[1]%10);        
//	       print_str0_16_16(":");
               print_str0_16_16(":");print_str0_16_16(":");
	       print_asi111(0x00,16+time3[0]/10);	
	       print_asi111(0x00,16+time3[0]%10);	
               	goto_xy(12,16); 
                print_str0_16_16("Press +/- OR Max");
             //   print_asi111(0x00,0x47);
             //   print_asi111(0x00,0x0F);
             //   print_asi111(0x00,0x0D);
             //   print_str0_16_16("OR Max");
               	goto_xy(14,0x08);                 
                print_str0_16_16("to Purchase Time");    
               	goto_xy(17,0x00); 
                print_str0_16_16("OK");
                print_asi111(0x00,0x0D);                
                print_str0_16_16("Confirm C");                
                print_asi111(0x00,0x0D);
                print_str0_16_16(" Cancel");*/
            //   disp_CURTIM_16x32line0();       
} 
//////////////////////////////////////////////////////////////////////////////
void disp_user_maintime14(u8 timemode,u16 user_time,u16 user_money)
{
	u8 time3[7],f_AM;	

	math_time(user_time+left_time,time3);	
/////////////////////////////////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////////////////////
        LoadMenuLcd(19,1);  
        LoadMenuLcd(19,2); 
        LoadMenuLcd(19,3); 
        LoadMenuLcd(19,4);  
        LoadMenuLcd(19,5); 
        LoadMenuLcd(19,6);
        LoadMenuLcd(19,7);  
        LoadMenuLcd(19,8); 
        LoadMenuLcd(19,9);
        LoadMenuLcd(19,0x0A);        
///////////////////////////////////////////////////////////////         
/////////////////////////////////////////////////////////////////////////////////////////        
	/*        goto_xy(1,16);
	        print_str0_16_16("MAX TIME ALLOWED");                
	        CT_fb_on_gb_off(); 
                 zimo=1;
                goto_xy(0x06,8);
	        if(user_time/6000)
		print_asi111(0x01,16+user_time/6000%10);	
	        print_asi111(0x01,16+user_time/600%10);
	        print_asi111(0x01,16+user_time/60%10);
	        print_asi111(0x01,0x1A);	
	        print_asi111(0x01,16+user_time/10%6);
	        print_asi111(0x01,16+user_time%10);	
       //         CT_fb_off_gb_off();
	//	zimo=0;
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
             //  parking_station=time2money(u1time1);
             //   u1time2=Good_money;  
////////////////////////////////////////////////////////////////////////////////
	      goto_xy(0x06,0x60);
              print_asi111(0x01,0x04);
	      if(user_money/10000)
	      print_asi111(0x01,16+user_money/10000%10);
	      print_asi111(0x01,16+user_money/1000%10);
	      print_asi111(0x01,16+user_money/100%10);
              print_asi111(0x01,0x0E);
	      print_asi111(0x01,16+user_money/10%10);
	      print_asi111(0x01,16+user_money%10);	                
              CT_fb_off_gb_off();
              zimo=0;
////////////////////////////////////////////////////////////////////////////////
                goto_xy(12,16);   
               print_str0_16_16("Expires at ");
	       print_asi111(0x00,16+time3[1]/10);
	       print_asi111(0x00,16+time3[1]%10);        
//	       print_str0_16_16(":");
               print_str0_16_16(":");print_str0_16_16(":");
	       print_asi111(0x00,16+time3[0]/10);	
	       print_asi111(0x00,16+time3[0]%10);	
              	goto_xy(16,0x00);        
                print_str0_16_16("OK");
                print_asi111(0x00,0x0D);                
                print_str0_16_16("Confirm C");                
                print_asi111(0x00,0x0D);
                print_str0_16_16(" Cancel");      */
/////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////
} 
//////////////////////////////////////////////////////////////////////////////
void disp_user_OK111(u8 timemode,u16 user_time,u16 user_money)
{
	u8 time3[7],f_AM;	

	math_time(user_time+left_time,time3);	
/////////////////////////////////////////////////////////////////////////////////////////
	        goto_xy(1,40);
	        print_str0_16_16("APPROVED");                
	        CT_fb_on_gb_off(); 
                 zimo=1;
                goto_xy(0x06,8);
	        if(user_time/6000)
		print_asi111(0x01,16+user_time/6000%10);	
	        print_asi111(0x01,16+user_time/600%10);
	        print_asi111(0x01,16+user_time/60%10);
	        print_asi111(0x01,0x1A);	
	        print_asi111(0x01,16+user_time/10%6);
	        print_asi111(0x01,16+user_time%10);	
       //         CT_fb_off_gb_off();
	//	zimo=0;
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
             //  parking_station=time2money(u1time1);
             //   u1time2=Good_money;  
////////////////////////////////////////////////////////////////////////////////
	      goto_xy(0x06,0x60);
              print_asi111(0x01,0x04);
	      if(user_money/10000)
	      print_asi111(0x01,16+user_money/10000%10);
	      print_asi111(0x01,16+user_money/1000%10);
	      print_asi111(0x01,16+user_money/100%10);
              print_asi111(0x01,0x0E);
	      print_asi111(0x01,16+user_money/10%10);
	      print_asi111(0x01,16+user_money%10);	                
              CT_fb_off_gb_off();
              zimo=0;
////////////////////////////////////////////////////////////////////////////////
                goto_xy(12,16);   
               print_str0_16_16("Expires at ");
           /*    f_AM=1;
            //   if(sz2[1]>=0x12)
               if(time3[1]>=12)                 
               {
               time3[1]= time3[1]-12;
               f_AM=0;
               }*/
	       print_asi111(0x00,16+time3[1]/10);
	       print_asi111(0x00,16+time3[1]%10);        
//	       print_str0_16_16(":");
               print_str0_16_16(":");print_str0_16_16(":");
	       print_asi111(0x00,16+time3[0]/10);	
	       print_asi111(0x00,16+time3[0]%10);	
          /*     if(f_AM==1 )
                print_str0_16_16("AM "); 
               else
                 print_str0_16_16("FM "); */
            //   	goto_xy(16,0x00);        
             //   print_str0_16_16("OK to Confirm; C - Cancel");       
/////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////
} 
/////////////////////////////////////////////////////////////////////////////
void disp_user_main(u8 timemode,u16 user_time,u16 user_money)
{
	u8 time3[7];	

	math_time(user_time,time3);	

	goto_xy(0x00,0x01);
	print_str_16_16("Amount paid");
	goto_xy(0x08,0x01);
	print_str_16_16("Purchased time");	
	
	if(timemode != CreditMode)
		CT_fb_on_gb_off();
	goto_xy(0x04,0x02);			
	if(user_money/10000)
		print_num32_32(user_money/10000%10);
	print_num32_32(user_money/1000%10);
	print_num32_32(user_money/100%10);
print_asi(0x0E);
	print_num32_32(user_money/10%10);
	print_num32_32(user_money%10);	
	if(timemode != CreditMode)
		CT_fb_off_gb_off();
	
	if(timemode == CreditMode)
		CT_fb_on_gb_off();
	goto_xy(12,0x02);				
	if(user_time/6000)
		print_num32_32(user_time/6000%10);	
	print_num32_32(user_time/600%10);
	print_num32_32(user_time/60%10);
	print_asi(0x1A);	
	print_num32_32(user_time/10%6);
	print_num32_32(user_time%10);	

	if(timemode == CreditMode)
		{
		CT_fb_off_gb_off();
		goto_xy(0x30,0x03);
		print_str_16_16("'Up'/'Down' -- +/-15Min");
		}


        lcd_clear();
	goto_xy(0x00,0x00);
	//print_str_16_16("Present time ");
        LoadMenuLcd(12,1);
	//disp_time1(2,time1);
        goto_xy(0x04,0x02);
	print_num16_16(time1[2]/10);
	print_num16_16(time1[2]%10);
	//print_str_16_16("/");
	print_asi(0x0F);
	print_num16_16(time1[3]/10);
	print_num16_16(time1[3]%10);
	//print_str_16_16("/");
	print_asi(0x0F);
	print_str_16_16("20");	
	print_num16_16(time1[4]/10);
	print_num16_16(time1[4]%10);
	//print_str_16_16(" ");
        print_asi(0x00);
	print_num16_16(time1[1]/10);
	print_num16_16(time1[1]%10);
	//print_str_16_16(":");
        print_asi(0x1A);
	print_num16_16(time1[0]/10);
	print_num16_16(time1[0]%10);
	
	goto_xy(0x08,0x00);
	//print_str_16_16("Expiry time ");
        LoadMenuLcd(12,3);
	//disp_time1(6,time3);
        goto_xy(12,0x02);
	print_num16_16(time3[2]/10);
	print_num16_16(time3[2]%10);
	//print_str_16_16("/");
        print_asi(0x0F);
	print_num16_16(time3[3]/10);
	print_num16_16(time3[3]%10);
	//print_str_16_16("/");
        print_asi(0x0F);
	print_str_16_16("20");	
	print_num16_16(time3[4]/10);
	print_num16_16(time3[4]%10);
	//print_str_16_16(" ");
        print_asi(0x00);
	print_num16_16(time3[1]/10);
	print_num16_16(time3[1]%10);
	//print_str_16_16(":");
        print_asi(0x1A);
	print_num16_16(time3[0]/10);
	print_num16_16(time3[0]%10);
	
 //   goto_xy(14,0x06);	
	//if(timemode == CashMode)
	//	print_str_16_16("'Confirm' to park"); 
	//else
	//	print_str_16_16("'Confirm' or 'Cancel'"); 
}								
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
void Disp_SYSINFO_Page1(void)
{
	lcd_clear();
                    goto_xy(0x00,0x02);
		    zimo=1;                    
                    print_str_16_16("1. Date/Times  ");
		    zimo=0;                    
                    goto_xy(0x04,0x02);                    
		    print_str_16_16("2. Server IP   ");
                    goto_xy(0x08,0x02);                    
		    print_str_16_16("3. APN Settings");
                    goto_xy(12,0x02);                    
		    print_str_16_16("4. Machine no   ");		
}

void Disp_SYSINFO_Page2(void)
{
	lcd_clear();
                    goto_xy(0x00,0x02);                   
                    print_str_16_16("1. Date/Times  ");
		    zimo=1;                     
                    goto_xy(0x04,0x02);                    
		    print_str_16_16("2. Server IP   ");
		    zimo=0;                    
                    goto_xy(0x08,0x02);                    
		    print_str_16_16("3. APN Settings");
                    goto_xy(12,0x02);                    
		    print_str_16_16("4. Machine no   ");	
} 
void Disp_SYSINFO_Page3(void)
{
	lcd_clear();
                    goto_xy(0x00,0x02);                  
                    print_str_16_16("1. Date/Times  ");                   
                    goto_xy(0x04,0x02);                    
		    print_str_16_16("2. Server IP   ");
                    goto_xy(0x08,0x02);
		    zimo=1;                     
		    print_str_16_16("3. APN Settings");
		    zimo=0;                     
                    goto_xy(12,0x02);                    
		    print_str_16_16("4. Machine no   ");	
}
void Disp_SYSINFO_Page4(void)
{
	lcd_clear();
                    goto_xy(0x00,0x02);                 
                    print_str_16_16("1. Date/Times  ");                 
                    goto_xy(0x04,0x02);                    
		    print_str_16_16("2. Server IP   ");
                    goto_xy(0x08,0x02);                    
		    print_str_16_16("3. APN Settings");
                    goto_xy(12,0x02);  
 		    zimo=1;                     
		    print_str_16_16("4. Machine no   ");	
		    zimo=0;  
}
void Disp_SYSINFO_Page5(void)
{
	lcd_clear();
                    goto_xy(0x00,0x02);                    
		    print_str_16_16("2. Server IP   ");
                    goto_xy(0x04,0x02);                    
		    print_str_16_16("3. APN Settings");
                    goto_xy(0x08,0x02);                       
		    print_str_16_16("4. Machine no   ");	
 		    zimo=1;                    
                    goto_xy(12,0x02);                 
                    print_str_16_16("5. Street Info  "); 
		    zimo=0;
}
void Disp_SYSINFO_Page6(void)
{
	lcd_clear();
                    goto_xy(0x00,0x02);                    
		    print_str_16_16("3. APN Settings");
                    goto_xy(0x04,0x02);                       
		    print_str_16_16("4. Machine no   ");	                   
                    goto_xy(0x08,0x02);                 
                    print_str_16_16("5. Street Info  "); 
  		    zimo=1; 
                    goto_xy(12,0x02);                    
		    print_str_16_16("6. Parking Rate"); 
		    zimo=0;  
}
void Disp_SYSINFO_Page7(void)
{
	lcd_clear();
                    goto_xy(0x00,0x02);                       
		    print_str_16_16("4. Machine no   ");	                   
                    goto_xy(0x04,0x02);                 
                    print_str_16_16("5. Street Info  "); 
                    goto_xy(0x08,0x02);                    
		    print_str_16_16("6. Parking Rate");
                    goto_xy(12,0x02); 
  		    zimo=1;                     
		    print_str_16_16("7. DPS IP      ");                    
		    zimo=0;  
}
void Disp_SYSINFO_Page8(void)
{
	lcd_clear();
                    goto_xy(0x00,0x02);                 
                    print_str_16_16("5. Street Info "); 
                    goto_xy(0x04,0x02);                    
		    print_str_16_16("6. Parking Rate");
                    goto_xy(0x08,0x02);                      
		    print_str_16_16("7. DPS IP      "); 
                    goto_xy(12,0x02);
  		    zimo=1;                    
		    print_str_16_16("8. Coin number  ");                    
		    zimo=0;   
}

//lcd_clear();
//Wcdma_main();
//lcd_clear();
//Refresh_SYSallicon();
//DPSIP = 0;
//FRIST_GPRS(Isnohide);

//PDA
void Do_Adminmenu_1(void)
{
	Uart4_Configuration(19200);
        #ifdef _test_all_function
        read_Memory(); 
        #endif               
	ir_comm();
}
void Adjust_contrast_5(void)
{
	unsigned int Electr_volumn1,Electr_volumn2;
        u8 time3[7]; 
	unsigned char flag_b,return_value;
        u32 workloop;
	lcd_clear();
        I2C_ReadS_24C(D_Contrast,time3,2);
        Electr_volumn1=hcl(time3,2);
        Electr_volumn2=Electr_volumn1;
/////////////////////////////////////////////////////////////////////////////
        goto_xy(0x04,0x02);                    
        print_str_16_16("Adjust contrast:");goto_xy(0x08,0x02);       
	if(Electr_volumn1/100)
	print_asi111(1,16+Electr_volumn1/100%10);	
	if(Electr_volumn1/10)        
	print_asi111(1,16+Electr_volumn1/10%10);
	print_asi111(1,16+Electr_volumn1%10);       
/////////////////////////////////////////////////////////////////////////////
	workloop=90000000;	
	//workloop=100;	
	flag_b = 0;
	return_value = 0;//��ʱ==ȷ��
	while(workloop--)
		{
                if(key_flag!=0)
               {
  //              key=key_scan();
		switch(key_scan1())
			{
		/*	case 1:		
				utime += 15;	
				if((utime>=LimitTime_CARD)&&flag_b)
					{
					utime = LimitTime_CARD;	
					flag_b = 0;
					}
				//workloop=300;
				workloop=90000000;
                                lcd_clear();
				break;
				*/
		/*    case 4:
				if(utime>=15)
					utime -= 15;
				//workloop=300;	
				workloop=90000000;
                                lcd_clear();
				break;*/
		/*	case 2:		
                               utime =x_MAXParkingTime-left_time;                                                     
                               flag_b = 1;				                              
				workloop=90000000;
                                lcd_clear();
				break;
				
			case 3:                           
                               utime =x_MAXParkingTime-left_time;
                               flag_b = 1;
				workloop=90000000;
                                lcd_clear();
				break;  */
			case KEY_Down:
                          if(Electr_volumn1<=70)
				Electr_volumn1 += 2;	 
				workloop=90000000;
                              //  lcd_clear();
				break;
				
			case KEY_Up:
				if(Electr_volumn1>=2)
				Electr_volumn1 -=2;
                                else
                                  Electr_volumn1 = 0;
				//workloop=300;
                               flag_b = 0;
				workloop=90000000;
                              //  lcd_clear();
				break;                               

			case KEY_Comfirm://����ȷ�ϻ�ȡ��
				return_value = 1;
				break;
				
			case KEY_Cancel://ȡ��
//////////////////////////////////////////////////////////////////////////////
                        fll(Electr_volumn2,time3,2);
                        I2C_WriteS_24C(D_Contrast,time3,2);               
                        LCD_INIT();
	                lcd_clear();        
                        goto_xy(0x04,0x02);                    
                        print_str_16_16("Adjust contrast:");        
	                if(Electr_volumn2/100)
	                print_asi111(1,16+Electr_volumn2/100%10);	
	                if(Electr_volumn2/10)        
	                print_asi111(1,16+Electr_volumn2/10%10);
	                print_asi111(1,16+Electr_volumn2%10);                           
//////////////////////////////////////////////////////////////////////////////                          
				return_value =1;
				return;
			default :
				break;
				
			}
////////////////////////////////////////////////////////////////////////////// 
                if(f_occupied==1)
                {
////////////////////////////////////////////////////////////////////
                left_time=get_oldutime(chewei);
               parking_station=time2money(left_time); 
               left_money=Good_money;                   
////////////////////////////////////////////////////////////////////                  
              //  time_occpupied=disp_oldutime_max(chewei);
                 } 
        fll(Electr_volumn1,time3,2);
        I2C_WriteS_24C(D_Contrast,time3,2);               
        LCD_INIT();
	lcd_clear();        
/////////////////////////////////////////////////////////////////////////////
        goto_xy(0x04,0x02);                    
        print_str_16_16("Adjust contrast:");        
	if(Electr_volumn1/100)
	print_asi111(1,16+Electr_volumn1/100%10);	
	if(Electr_volumn1/10)        
	print_asi111(1,16+Electr_volumn1/10%10);
	print_asi111(1,16+Electr_volumn1%10); 
                Buzz_0;                  
                delay(10000);                
                Buzz_1;               
		if(return_value)
			break;
                 }
		}	
	return_value = 0;
	return;	
}
//ά��
void Do_Adminmenu_2(void)
{
	lcd_clear();
	Refresh_SYSallicon();
	//goto_xy(0x00,0x02);
	//print_str_16_16("System maintaining...");
	goto_xy(0x04,0x02);
	print_str_16_16("Please wait...");
        delay(KEYTIMEOUT_1S*5);
        return;
	Check_SystemDevice_DispFault(ON);
	delay(KEYTIMEOUT_1S*5);
	//���
	;
	lcd_clear();
	Refresh_SYSallicon();
	goto_xy(0x00,0x02);
	print_str_16_16("	System maintaining...");
	goto_xy(0x08,0x02);
	print_str_16_16("Please wait...");
	Check_SystemDevice_DispFault(OFF);
}
//ȡǮ
void Do_Adminmenu_3(void)
{
	u8 Cardno[5] ={0x12,0x34,0x56,0x78,0x90};
	//LCD_Sring1(0,14, "Please");
	//LCD_Sring1(2,14, "Take MONEY");	
	//LCD_Sring1(4,14, "and Shut");
	//LCD_Sring1(6,14, "Coin Box");
	//LCD_Sring1(0,14, "Succeed in");
	//LCD_Sring1(2,14, "Close Door");
	//LCD_Sring1(4,14, "Please Lock");
	//LCD_Sring1(6,14, "Well");
	lcd_clear();        
	goto_xy(0x04,0x02);
	print_str_16_16("Please wait...");
        delay(KEYTIMEOUT_1S*5);
        return;        
	Income_print();

	takemny_record(Cardno);
}
//����
void Do_Adminmenu_4(void)
{
	lcd_clear();        
	goto_xy(0x04,0x02);
	print_str_16_16("Please wait...");
        delay(KEYTIMEOUT_1S*5);
        return;
 //////////////////////////////////////////       
	lcd_clear();
	Refresh_SYSallicon();
	goto_xy(0x04,0x04);
	print_str_16_16("Machine testing...");
	goto_xy(0x08,0x04);
	print_str_16_16("Please wait...");
	SYS_DO_BUSY_ICON(0x20,24,0x40,21, 0);
	Check_SystemDevice_DispFault(OFF);
	Test_print();
}
void do_main231(unsigned char mid)
{
   switch(mid)
   {
	     case 1:
				   lcd_clear(); 
                                   disp_current_time12();
				    break;					     
	     case 2:
		                lcd_clear();
                                 disp_IP_no();                               
				break;
	     case 3:
				lcd_clear(); 
                               disp_APN_no();
				break;
	     case 4:
		           lcd_clear();
                           disp_Machine_no();
				break;
	     case 5:
		            lcd_clear();         
                            disp_Street_no();
				break;
		 case 6: 
		            lcd_clear();
                           disp_System_tariff();                            
				break;
		 case 7: 
		            lcd_clear();
                            disp_DPSIP_no();
				break;
		 case 8: 
		            lcd_clear();
                            disp_Preset_coincount();
				break;                                
		 default:break; 
   }
	KEY_TIMEOUT = KEYTIMEOUT_1S*2;
	while(KEY_TIMEOUT -- )
		{
		if(key_flag)
			Key_Value = key_scan1();
		else
			continue;
		switch(Key_Value)
			{
			case KEY_Cancel:
                               KEY_TIMEOUT=1;
				break;
			case KEY_Comfirm:
                               KEY_TIMEOUT=1;
                                break;
                        }
                if(KEY_TIMEOUT==1)
                  break;
                }
}
//��ѯ
void Do_Adminmenu_5(void)
{
	u8 loop = 0;
/*	lcd_clear();
	Refresh_SYSallicon();
	//goto_xy(0x00,0x02);
	//print_str_16_16("System maintaining...");
	goto_xy(0x04,0x02);
	print_str_16_16("Please wait...");
        delay(KEYTIMEOUT_1S*5);
        return;  */      
	lcd_clear();
	Disp_SYSINFO_Page1();
	menunum = 1;
	KEY_TIMEOUT = KEYTIMEOUT_1S*2;
	while(KEY_TIMEOUT -- )
		{
		if(key_flag)
			Key_Value = key_scan1();
		else
			continue;
		switch(Key_Value)
			{
			case KEY_1://��ӡƱ��
                              lcd_clear(); 
                              disp_current_time12();
                              delay(KEYTIMEOUT_1S*3);
				loop =1;				
				break;  
			case KEY_2://��ӡƱ��
                             lcd_clear();
                              disp_IP_no();	
                              delay(KEYTIMEOUT_1S*3);	
				loop =1;	                              
				break; 
			case KEY_3://��ӡƱ��
                             lcd_clear();
                              disp_APN_no();
                              delay(KEYTIMEOUT_1S*3);
				loop =1;				
				break; 
			case KEY_4://��ӡƱ��
                             lcd_clear();
                              disp_Machine_no();
                              delay(KEYTIMEOUT_1S*3);
				loop = 1;				
				break;                                 
			case KEY_Up:
				menunum --;
				if(menunum == 0)
					menunum =8;
				switch(menunum)
					{
					case 1:
						Disp_SYSINFO_Page1();
						break;
					case 2:
						Disp_SYSINFO_Page2();					
						break;
					case 3:
						Disp_SYSINFO_Page3();					
						break;
					case 4:
						Disp_SYSINFO_Page4();						
						break;
					case 5:
						Disp_SYSINFO_Page5();						
						break;
					case 6:
						Disp_SYSINFO_Page6();						
						break;
					case 7:
						Disp_SYSINFO_Page7();						
						break;
					case 8:
						Disp_SYSINFO_Page8();						
						break;                                                
					default:
						break;
					}
				loop = 1;
				break;
				
			case KEY_Down:
				menunum ++;
				if(menunum == 9)
					menunum =1;
				switch(menunum)
					{
					case 1:
						Disp_SYSINFO_Page1();
						break;
					case 2:
						Disp_SYSINFO_Page2();					
						break;
					case 3:
						Disp_SYSINFO_Page3();					
						break;
					case 4:
						Disp_SYSINFO_Page4();						
						break;
					case 5:
						Disp_SYSINFO_Page5();						
						break;
					case 6:
						Disp_SYSINFO_Page6();						
						break;
					case 7:
						Disp_SYSINFO_Page7();						
						break;
					case 8:
						Disp_SYSINFO_Page8();						
						break;                                                
					default:
						break;
					}
				loop = 1;
				break;
				
			case KEY_Cancel:
				//return;
				loop = 0;
				break;
			case KEY_Comfirm:
                                do_main231(menunum);
                                lcd_clear();
	                        Disp_SYSINFO_Page1();
	                        menunum = 1;
				loop = 1;
				break;
			case KEY_P://��ӡƱ��
				//Printer_Power_ON;
				//delay(KEYTIMEOUT_1S*1);
				SytInfo_print();
				//Printer_Power_OFF;
				loop = 0;				
				break;
			default:
				loop = 1;
				break;
			}
		KEY_TIMEOUT = KEYTIMEOUT_1S*2;
		if(loop)
			continue;
		break;		
		
		}
	
}
u8 split_time(u8 * inno)
{
	inno[0] = (time[2]>>4)&0x0f;
	inno[1] = time[2]&0x0f;
	
	inno[2] = (time[3]>>4)&0x0f;
	inno[3] = time[3]&0x0f;
	
	inno[4] = (time[4]>>4)&0x0f;
	inno[5] = time[4]&0x0f;
	
	inno[6] = (time[1]>>4)&0x0f;
	inno[7] = time[1]&0x0f;

	inno[8] = (time[0]>>4)&0x0f;
	inno[9] = time[0]&0x0f;
	
	inno[10] = time[5];
        return 1;
}

u8 merge_time(u8 * inno)
{
	time[5] = inno[10];//��
	time[4] = inno[4]<<4+inno[5];//��
	time[3] = inno[2]<<4+inno[3];//��
	time[2] = inno[0]<<4+inno[1];//��
	time[1] = inno[6]<<4+inno[7];//ʱ
	time[0] = inno[8]<<4+inno[9];//��
        return 1;
}

unsigned char mathweek(unsigned char year,unsigned char month, unsigned char date)
{
  unsigned int  mathday;
  unsigned char loop6,ww;
  ww=((year>>4)&0x0f)*10;
  year=ww+(year&0x0f);
  ww=((yue>>4)&0x0f)*10;
  month=ww+(month&0x0f);
  ww=((date>>4)&0x0f)*10;
  date=ww+(date&0x0f);
  mathday=0;
  for(loop6=6;loop6<year;loop6++)
  {
	if(loop6%4==0)
	{
	 mathday=mathday+366;
	}
	else
	{
	 mathday=mathday+365;
	}
  }
  for(loop6=1;loop6<yue;loop6++)
  {
      if(loop6==2)
	  {
	   if(year%4==0)
		{
		 mathday=mathday+29;
		}
		else
		{
		 mathday=mathday+28;
		}
	  }
	  else
	  {
	    if((loop6==4)||(loop6==6)||(loop6==9)||(loop6==11))
		{
		  mathday=mathday+30;
		}
		else
		{
		 mathday=mathday+31;
		}
	  }    
  }
  mathday=mathday+(ri-1);
  ww=mathday%7;
  return ww;
}	

u8 Do_ChangeTime(void)
{
	u8  in_num,keyreturn,in_key,inno[11],trytime =3,inerr;
	u32 looptime = KEYTIMEOUT_1S*10;
	
	disp_CURTIM_16x32();
	Refresh_SYSallicon();
	goto_xy(0x60,0x13);
	print_str_16_16("							   ");
	goto_xy(0x60,0x00);
	print_str_16_16("'Confirm'-change 'Cancel'-exit");
	
	goto_xy(0x02,0x04);//1 ���ַ�λ��4-6-10-12-18-20
	
	
	goto_xy(0x30,0x07);//2 ʱ��λ��7-10-16-19
	

while(trytime--)
	{
	looptime = KEYTIMEOUT_1S*10;
	in_num = 0;
	keyreturn = 0;
	disp_CURTIM_16x32();
	Refresh_SYSallicon();
	goto_xy(0x60,0x13);
	print_str_16_16("							   ");
	goto_xy(0x60,0x00);
	print_str_16_16("'Confirm'-change 'Cancel'-exit");
	goto_xy(0x02,0x04);  
	CT_fb_on_gb_on();

	split_time(inno);

	while(looptime--)
		{
		if(key_flag)
			{
			in_key = key_scan();
			switch(in_key)
				{
				case KEY_0:
				case KEY_1:
				case KEY_2:
				case KEY_3:
				case KEY_4:
				case KEY_5:
				case KEY_6:
				case KEY_7:
				case KEY_8:
				case KEY_9:
				//case KEY_P:
				//case KEY_F:
				//case KEY_Up:
				//case KEY_Down:	
				
					inno[in_num] = in_key;
					keyreturn = 0;
					inerr = 0;
					merge_time(inno);
					switch(in_num)//1 ���Ƴ�ʵ��ʱ�����������
						{
						case 0:break;
							
							
							
						}
					if(inerr)
						continue;
					in_num++;
					if(in_num>6)
						{
						print_num16_16(in_key);	
						goto_xy(0x30,7+3*(in_num-6)); 
						if(in_num == 10)		
							{
							goto_xy(0x02,4); 
							in_num = 0;
							}
						}
					else
						{
						print_num32_32_1(in_key);
						goto_xy(0x02,4+2*(in_num)); 
						if(in_num == 6)
							goto_xy(0x30,7); 
						}	
					
					
					CT_fb_on_gb_on();
					
					continue;
					
	/*			case KEY_Cancel:
					CT_fb_off_gb_off();						
					keyreturn = 1;						 
					break;
					
				case KEY_Comfirm:
					//�ж�ʱ�� ��ȷ					
					
					
					merge_time(inno);
					set_current_time(time);
					
					keyreturn = 2;
					break;*/
				default:				
					break;
				}
			}
		if(keyreturn == 0)
			continue;
		break;
		}
		
	if(keyreturn == 1)
		return 1;
	
	CT_fb_off_gb_off();
	if(!in_num)
		return 1;
		
	for(in_num = 0; in_num<6;in_num++)
		{
		//if(inno[in_num] != oldno[in_num])
			{
			lcd_clear();
			Refresh_SYSallicon();
			goto_xy(0x20,0x08);
			print_str_16_16("Password wrong");
                        //LoadMenuLcd(27,2);
			goto_xy(0x40,0x08);
			print_str_16_16("Please try again");
                       // LoadMenuLcd(27,3);
			delay(KEYTIMEOUT_1S*3);
			if(trytime == 1)
				return 1;
			keyreturn = 99;
			break;;
			}
		}
	if(keyreturn == 99)
		continue;
	break;
	}
return 0;








	
}



//���뿪������
void Do_Adminmenu_6(void)
{
//	;
	if(Enter_AdminMenu(AdminSYS_Keyword_add))
		return;  
	lcd_clear();
	Refresh_SYSallicon();
	goto_xy(0x08,0x08);
	print_str_16_16("Open 15 minutes"); 
        f_openmachine=1;
        jishu2=0;        
       delay(KEYTIMEOUT_1S*2);       
        return;
	//Do_ChangeTime();	
}
/////////////////////////////////////////////////
//����ȡǮ����
void Do_Adminmenu_7(void)
{
//	;
	if(Enter_AdminMenu(Getmoney_Keyword_add))
		return;  
	lcd_clear();
	Refresh_SYSallicon();
	goto_xy(0x08,0x00);
	print_str_16_16("GETMONEY 15 minutes"); 
        f_getmoney=1;
        jishu2=0;        
       delay(KEYTIMEOUT_1S*2);       
        return;
	//Do_ChangeTime();	
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
u8 Choose_blacktime(void)
{
	unsigned char flag_b,flag_black,return_value;
        char timevalue; 
        unsigned char sz2[40];
        u32 workloop;	
	lcd_clear();
        flag_black=0;
////////////////////////////////////////////////////////////////////////////////////////
    //    goto_xy(0x02,0x10);
	//print_str_16_16("blacklight time"); 
	goto_xy(0x06,0x10);
        I2C_ReadS_24C(Refer_BlacklightTime,sz2,6);        
	print_str_16_16("blacklight time"); 
/////////////////////////////////////////////////////////////////////////////////////
	goto_xy(0x0A,0x40);        
   //    if(sz2[0]/16)
        if(flag_black==0)
        CT_fb_on_gb_off();
       print_asi111(1,16+sz2[0]/16);
       if(flag_black==0)
        CT_fb_off_gb_off();
        if(flag_black==1)
        CT_fb_on_gb_off();       
       print_asi111(1,16+sz2[0]%16);
        if(flag_black==1)
        CT_fb_off_gb_off();      
       print_asi111(1,0x1A);
        if(flag_black==2)
        CT_fb_on_gb_off();        
       print_asi111(1,16+sz2[1]/16);
        if(flag_black==2)
        CT_fb_off_gb_off(); 
         if(flag_black==3)
        CT_fb_on_gb_off();        
       print_asi111(1,16+sz2[1]%16);
        if(flag_black==3)
        CT_fb_off_gb_off();       
//////////////////////////////////////////////////////////////////////////// 
      // if(sz2[3]/16)
	goto_xy(0x0E,0x40);        
        if(flag_black==4)
        CT_fb_on_gb_off();
       print_asi111(1,16+sz2[3]/16);
       if(flag_black==4)
        CT_fb_off_gb_off();
        if(flag_black==5)
        CT_fb_on_gb_off();       
       print_asi111(1,16+sz2[3]%16);
        if(flag_black==5)
        CT_fb_off_gb_off();      
       print_asi111(1,0x1A);
        if(flag_black==6)
        CT_fb_on_gb_off();        
       print_asi111(1,16+sz2[4]/16);
        if(flag_black==6)
        CT_fb_off_gb_off(); 
         if(flag_black==7)
        CT_fb_on_gb_off();        
       print_asi111(1,16+sz2[4]%16);
        if(flag_black==7)
        CT_fb_off_gb_off();         
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////       
	workloop=90000000;	
	//workloop=100;	
	flag_b = 0;
	return_value = 0;//��ʱ==ȷ��
	while(workloop--)
		{
                if(key_flag!=0)
               {
		switch(key_scan1())
			{
			case 1:		
                                if(flag_black>=7)
                                flag_black=0;
                                else
                                {
                                  flag_black++;
                                }
                                flag_b =1;
				workloop=90000000;
                                lcd_clear();
				break;
				
			case 2:                         
                                if(flag_black<=0)
                                flag_black=7;
                                else
                                {
                                  flag_black--;
                                }
                                flag_b =1;
				workloop=90000000;
                                lcd_clear();
				break;  
			case KEY_Down:				
                               if(flag_black==0)
                               {
                                timevalue=sz2[0]+0x10;
                               if(timevalue<0x24)
                                sz2[0]=timevalue; 
                               }
                               else if(flag_black==1)
                               {
                                timevalue=sz2[0]+1;
                                if(timevalue<0x24)
                                sz2[0]=timevalue; 
                               }
                               else if(flag_black==2)
                               {
                                timevalue=sz2[1]+0x10;
                                if(timevalue<=0x59)
                                sz2[1]=timevalue; 
                               }
                               else if(flag_black==3)
                               {
                                timevalue=sz2[1]+1;
                                if(timevalue<=0x59)
                                sz2[1]=timevalue; 
                               }
                               else if(flag_black==4)
                               {
                                timevalue=sz2[3]+0x10;
                                if(timevalue<0x24)
                                sz2[3]=timevalue; 
                               }
                               else if(flag_black==5)
                               {
                                timevalue=sz2[3]+1;
                                if(timevalue<0x24)
                                sz2[3]=timevalue; 
                               } 
                               else if(flag_black==6)
                               {
                                timevalue=sz2[4]+0x10;
                                if(timevalue<=0x59)
                                sz2[4]=timevalue; 
                               }
                               else if(flag_black==7)
                               {
                                timevalue=sz2[4]+1;
                                if(timevalue<=0x59)
                                sz2[4]=timevalue; 
                               }
                               flag_b =1;
				workloop=90000000;
                                lcd_clear();
				break;
			case KEY_Up:
                               if(flag_black==0)
                               {
                                 if(sz2[0]>=0x10)
                                sz2[0]=sz2[0]-0x10; 
                               }
                               else if(flag_black==1)
                               {
                                 if(sz2[0]>=0x01)
                                sz2[0]=sz2[0]-0x01;                                 
                               }
                               else if(flag_black==2)
                               {
                                 if(sz2[1]>=0x10)                                 
                                sz2[1]=sz2[1]-0x10;
                               }
                               else if(flag_black==3)
                               {
                                 if(sz2[1]>=0x01)                                  
                                sz2[1]=sz2[1]-1;
                               }
                               else if(flag_black==4)
                               {
                                 if(sz2[3]>=0x10)                                   
                                sz2[3]=sz2[3]-0x10;
                               }
                               else if(flag_black==5)
                               {
                                 if(sz2[3]>=0x01)                                   
                                sz2[3]=sz2[3]-0x01;
                               } 
                               else if(flag_black==6)
                               {
                                 if(sz2[4]>=0x10)                                   
                                sz2[4]=sz2[4]-0x10;
                               }
                               else if(flag_black==7)
                               {
                                 if(sz2[4]>=0x01)                                   
                                sz2[4]=sz2[4]-0x01;
                               }
                               flag_b =1;
				workloop=90000000;
                                lcd_clear();
				break;                              
			case KEY_Comfirm://����ȷ�ϻ�ȡ��
                                I2C_WriteS_24C(Refer_BlacklightTime,sz2,6);                       
				return_value = 1;
                                flag_b =1;
				break;
				
			case KEY_Cancel://ȡ��
				return_value =1;
                                flag_b =1;
				return return_value;
			default :
				break;
				
			}            
                if(flag_b ==1)
                {
////////////////////////////////////////////////////////////////////////////////////////
                  flag_b =0;
/////////////////////////////////////////////////////////////////////////////////////
	goto_xy(0x06,0x10);
//        I2C_ReadS_24C(Refer_BlacklightTime,sz2,6);        
	print_str_16_16("blacklight time"); 
/////////////////////////////////////////////////////////////////////////////////////
	goto_xy(0x0A,0x40);        
   //    if(sz2[0]/16)
        if(flag_black==0)
        CT_fb_on_gb_off();
       print_asi111(1,16+sz2[0]/16);
       if(flag_black==0)
        CT_fb_off_gb_off();
        if(flag_black==1)
        CT_fb_on_gb_off();       
       print_asi111(1,16+sz2[0]%16);
        if(flag_black==1)
        CT_fb_off_gb_off();      
       print_asi111(1,0x1A);
        if(flag_black==2)
        CT_fb_on_gb_off();        
       print_asi111(1,16+sz2[1]/16);
        if(flag_black==2)
        CT_fb_off_gb_off(); 
         if(flag_black==3)
        CT_fb_on_gb_off();        
       print_asi111(1,16+sz2[1]%16);
        if(flag_black==3)
        CT_fb_off_gb_off();       
//////////////////////////////////////////////////////////////////////////// 
      // if(sz2[3]/16)
	goto_xy(0x0E,0x40);        
        if(flag_black==4)
        CT_fb_on_gb_off();
       print_asi111(1,16+sz2[3]/16);
       if(flag_black==4)
        CT_fb_off_gb_off();
        if(flag_black==5)
        CT_fb_on_gb_off();       
       print_asi111(1,16+sz2[3]%16);
        if(flag_black==5)
        CT_fb_off_gb_off();      
       print_asi111(1,0x1A);
        if(flag_black==6)
        CT_fb_on_gb_off();        
       print_asi111(1,16+sz2[4]/16);
        if(flag_black==6)
        CT_fb_off_gb_off(); 
         if(flag_black==7)
        CT_fb_on_gb_off();        
       print_asi111(1,16+sz2[4]%16);
        if(flag_black==7)
        CT_fb_off_gb_off();         
////////////////////////////////////////////////////////////////////////////////////////
                delay(10000);                
                Buzz_1;                                     
                }              
		if(return_value)
			break;
                 }
		}	
	return_value = 0;
	return return_value;	
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
void Adjust_blacklight_7(void)
{
///////////////////////////////////////////////////////////////////////////////
   //  unsigned char sz2[40];
  unsigned char ack;
	//lcd_clear();
	//Refresh_SYSallicon();
	//goto_xy(0x06,0x00);
        /*
	print_str_16_16("blacklight time"); 
	goto_xy(0x0A,0x00);
        I2C_WriteS_24C(Refer_BlacklightTime,sz2,6);        
	print_str_16_16("blacklight time"); 
/////////////////////////////////////////////////////////////////////////////////////
	goto_xy(0x08,0x00);        
       if(sz2[0]/16)
        if(flag_black==0)
        {
       print_asi111(wordtype,16+sz2[0]/16);
         }
       print_asi111(wordtype,16+sz2[0]%16);        
       print_asi111(wordtype,0x1A);
       print_asi111(wordtype,16+sz2[1]/16);	
       print_asi111(wordtype,16+sz2[1]%16); 
/////////////////////////////////////////////////////////////////////////////////////
	goto_xy(0x0A,0x00);        
       if(sz2[0]/16)
       print_asi111(wordtype,16+sz2[0]/16);
       print_asi111(wordtype,16+sz2[0]%16);        
       print_asi111(wordtype,0x1A);
       print_asi111(wordtype,16+sz2[1]/16);	
       print_asi111(wordtype,16+sz2[1]%16);         
/////////////////////////////////////////////////////////////////////////////////////        
        */
        ack=Choose_blacktime();
	//print_str_16_16("light 15 minutes"); 
       // f_blacklight=1;
       // jishu2=0;        
       delay(KEYTIMEOUT_1S*2);
///////////////////////////////////////////////////////////////////////////////  
}
///////////////////////////////////////////////////////////////////////////////

u8 Enter_AdminMenu(unsigned long eepromaddress)
{
	u8 in_num = 0,in_key,inno[7],oldno[7],trytime = 4,keyreturn = 0;
	u32 looptime = KEYTIMEOUT_1S*10;

//	I2C_ReadS_24C(AdminSYS_Keyword_add,oldno ,6);
	I2C_ReadS_24C(eepromaddress,oldno ,6);	
	while(trytime--)
		{
		looptime = KEYTIMEOUT_1S*10;
		in_num = 0;
		keyreturn = 0;
		lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x02,0x00);
		print_str_16_16("Input ");
		//goto_xy(0x04,0x09);
		CT_fb_on_gb_off();
		print_str_32_32("6");	
		CT_fb_off_gb_off();
		//goto_xy(0x06,0x0B);
		print_str_16_16("-digital password");	
                 //       LoadMenuLcd(26,1);
                //LoadMenuLcd(26,2);
		//print_str_16_16("Input 6-digital password");		
		goto_xy(10,0x08);	 
		CT_fb_on_gb_on();
	        
	    while(looptime--)
	        {
			if(key_flag)
				{
				in_key = key_scan1();
				switch(in_key)
					{
					case KEY_0:
					case KEY_1:
					case KEY_2:
					case KEY_3:
					case KEY_4:
					case KEY_5:
					case KEY_6:
					case KEY_7:
					case KEY_8:
					case KEY_9:
					case KEY_P:
					case KEY_F:
					//case KEY_Up:
					//case KEY_Down:	
						inno[in_num] = in_key;
						/*if(in_num>5)
							{							
							CT_fb_off_gb_off();
							continue;
                                                        }*/
					/*	if(in_num>5)
							{							
							//CT_fb_off_gb_off();
                                                         keyreturn =2; 
							break;
							} */
						keyreturn = 0;
                                                in_num++;
						//goto_xy(10,8+2*(in_num++)); 
						//CT_fb_on_gb_on();
						//print_asi('*');
						print_asi(0x0A);
						if(in_num>5)
							{							
							//CT_fb_off_gb_off();
                                                         keyreturn =2; 
							break;
							}                                                 
						continue;
			/*		case KEY_Cancel:
						if(in_num)
							{
							in_num --;
							//in_num --;						
							CT_fb_off_gb_off();
							goto_xy(10,8+2*(in_num)); 
							print_asi(' ');
							print_asi(' ');
							goto_xy(10,8+2*(in_num)); 						
							CT_fb_off_gb_on();
							
							if(in_num)
								continue;
							}
                        keyreturn = 1;                       
						break;*/
	/*				case KEY_Comfirm:
						if(in_num>5)
							{
							keyreturn = 2;
							break;
							}
						continue;*/
					default:				
						break;
					}
				}
			if(keyreturn == 0)
				continue;
			break;
	        }
            
		if(keyreturn == 1)
			return 1;
		
	    CT_fb_off_gb_off();
		if(!in_num)
			return 1;
/////////////////////////////////////////////////////////////////////////////////////////                
/////////////////////////////////////////////////////////////////////////////////////////
                 lcd_clear();
                 goto_xy(0x04,0x00);
		print_str_16_16("PRESS OK or Cancel ");  
                 //LoadMenuLcd(35,2);
            looptime = KEYTIMEOUT_1S*5;
	    while(looptime--)
	        {
			if(key_flag)
				{
				in_key = key_scan1();
                                keyreturn = 1; 
				switch(in_key)
					{
					case KEY_Cancel:
                                                lcd_clear();
                                               	goto_xy(0x04,0x00);
		                                print_str_16_16("Already Cancel "); 
						return 1;
					case KEY_Comfirm:
                                             //  lcd_clear();
		                            for(in_num = 0; in_num<6;in_num++)
			                    {
			                    if(inno[in_num] != oldno[in_num])
				            {
				            lcd_clear();
				            Refresh_SYSallicon();
				            goto_xy(0x04,0x00);
				            print_str_16_16("Password wrong");
				            goto_xy(0x08,0x00);
				            print_str_16_16("Please try again");
				            delay(KEYTIMEOUT_1S*3);
				            if(trytime == 1)
					    return 1;
				            keyreturn = 99;
				            break;
				            }
                                            else
                                            {
                                              if(in_num>=5)
                                              return 0;
                                            }
			                    }
                                            break;
                                       default:
                                         //   keyreturn = 99;
                                             break;
			      }
				}
			//if(keyreturn == 1)
			//break;
			if(keyreturn ==99)
			break;                        
	        }                
/////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////                
	/*	for(in_num = 0; in_num<6;in_num++)
			{
			if(inno[in_num] != oldno[in_num])
				{
				lcd_clear();
				Refresh_SYSallicon();
				goto_xy(0x04,0x00);
				print_str_16_16("Password wrong");
				goto_xy(0x08,0x00);
				print_str_16_16("Please try again");
				delay(KEYTIMEOUT_1S*3);
				if(trytime == 1)
					return 1;
				keyreturn = 99;
				break;;
				}
			   }*/
		if(keyreturn == 99)
			continue;
		break;
		}
	return 0;
	
}
///////////////////////////////////////////////////////////////////////////////////////////////////
void Change_AdminMenu(void)
{
	u8 in_num = 0,in_key,inno[7],keyreturn = 0;
	u32 looptime = KEYTIMEOUT_1S*10;
		looptime = KEYTIMEOUT_1S*10;
		in_num = 0;
		keyreturn = 0;
		lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x02,0x00);
		print_str_16_16("Input ");
		//goto_xy(0x04,0x09);
		CT_fb_on_gb_off();
		print_str_32_32("6");	
		CT_fb_off_gb_off();
		//goto_xy(0x06,0x0B);
		print_str_16_16("-digital password");	
		//print_str_16_16("Input 6-digital password");	
                //LoadMenuLcd(34,1);
                //LoadMenuLcd(34,2);
		goto_xy(10,0x08);	 
		CT_fb_on_gb_on();
	        
	    while(looptime--)
	        {
                  if(looptime==1)
                    break;
			if(key_flag)
				{
				in_key = key_scan1();
				switch(in_key)
					{
					case KEY_0:
					case KEY_1:
					case KEY_2:
					case KEY_3:
					case KEY_4:
					case KEY_5:
					case KEY_6:
					case KEY_7:
					case KEY_8:
					case KEY_9:
					case KEY_P:
					case KEY_F:
					//case KEY_Up:
					//case KEY_Down:	
						inno[in_num] = in_key;
						keyreturn = 0;
                                                in_num++;
						//goto_xy(10,8+2*(in_num++)); 
						//CT_fb_on_gb_on();
						//print_asi('*');
						print_asi(0x0A);
						if(in_num>5)
							{							
							//CT_fb_off_gb_off();
                                                         keyreturn =2; 
							break;
							}                                                 
						continue;
			/*		case KEY_Cancel:
						if(in_num)
							{
							in_num --;
							//in_num --;						
							CT_fb_off_gb_off();
							goto_xy(10,8+2*(in_num)); 
							print_asi(' ');
							print_asi(' ');
							goto_xy(10,8+2*(in_num)); 						
							CT_fb_off_gb_on();
							
							if(in_num)
								continue;
							}
                        keyreturn = 1;                       
						break;*/
	/*				case KEY_Comfirm:
						if(in_num>5)
							{
							keyreturn = 2;
							break;
							}
						continue;*/
					default:				
						break;
					}
				}
			if(keyreturn == 0)
				continue;
			break;
                     
	        }
                   if(looptime==1)
                    return;
                 lcd_clear();
                 goto_xy(0x04,0x00);
		print_str_16_16("PRESS OK or Cancel ");  
                // LoadMenuLcd(35,2);
            looptime = KEYTIMEOUT_1S*5;
	    while(looptime--)
	        {
			if(key_flag)
				{
				in_key = key_scan1();
                                keyreturn = 1; 
				switch(in_key)
					{
					case KEY_Cancel:
                                                lcd_clear();
                                               	goto_xy(0x04,0x00);
		                                print_str_16_16("Already Cancel "); 
						break;
					case KEY_Comfirm:
                                               lcd_clear();
						if(in_num==6)
							{
							keyreturn = 2;
	                                                I2C_WriteS_24C(AdminSYS_Keyword_add,inno,6);
                                               	goto_xy(0x04,0x00);
		                                print_str_16_16("Already Change");                                                         
							}      
			                       else
                                               {
                                               	goto_xy(0x04,0x00);
		                                print_str_16_16("Input Error ");  
                                               }
						  break;
					}
				}
			if(keyreturn == 1)
			break;
	        }
  //    delay(KEYTIMEOUT_1S*2);            
}
///////////////////////////////////////////////////////////////////////////////////////////////////
void Do_AdminMenu(void)
{
	u8 loop = 0;

	if(Enter_AdminMenu(AdminSYS_Keyword_add))
		return;
	
	//disp_Adminmenu_1();
        disp_Adminmenu_1111();
	menunum = 1;
	KEY_TIMEOUT = KEYTIMEOUT_1S*2;
	while(KEY_TIMEOUT -- )
		{
		if(key_flag)
			Key_Value = key_scan1();
		else
			continue;
		switch(Key_Value)
			{
			case KEY_1:
				Do_Adminmenu_1();
				loop = 0;
				break;
			case KEY_2:
				//Do_Adminmenu_2();
 				Do_Adminmenu_5();                               
				loop = 0;
				break;
			case KEY_3:
				//Do_Adminmenu_3();
                                Change_AdminMenu();
				loop = 0;
				break;
			case KEY_4:
				//Do_Adminmenu_4();
                               Do_Adminmenu_6();
				loop = 0;
				break;
			/*case KEY_5:
				Adjust_contrast_5();
				loop = 0;
				break;
			case KEY_6:
				Do_Adminmenu_6();
				loop = 0;
				break;*/
			case KEY_Up:
				menunum --;
				if(menunum == 0)
					menunum =7;
				switch(menunum)
					{
					case 1:
						disp_Adminmenu_1111();
						break;
					case 2:
						disp_Adminmenu_2222();					
						break;
					case 3:
						disp_Adminmenu_3333();					
						break;
					case 4:
						disp_Adminmenu_4444();						
						break;
					case 5:
						disp_Adminmenu_5555(); 	
						break;
					case 6:
						disp_Adminmenu_6666(); 	
						break;
					case 7:
						disp_Adminmenu_7777(); 	
						break;                                                 
					default:
						break;
					}
				loop = 1;
				break;
				
			case KEY_Down:
				menunum ++;
				if(menunum == 8)
					menunum =1;
				switch(menunum)
					{
					case 1:
						disp_Adminmenu_1111();
						break;
					case 2:
						disp_Adminmenu_2222();					
						break;
					case 3:
						disp_Adminmenu_3333();					
						break;
					case 4:
						disp_Adminmenu_4444();						
						break;
					case 5:
						disp_Adminmenu_5555(); 	
						break;
					case 6:
						disp_Adminmenu_6666(); 	
						break;
					case 7:
						disp_Adminmenu_7777(); 	
						break;                                                
					default:
						break;
					}
				loop = 1;
				break;
				
			case KEY_Cancel:
				//return;
				loop = 0;
				break;   
			case KEY_Comfirm:

				switch(menunum)
					{
					case KEY_1:
						Do_Adminmenu_1();
						loop = 0;
						break;
					case KEY_2:
						Do_Adminmenu_5();
						loop = 0;
						break;
					case KEY_3:
						//Do_Adminmenu_3();
                                                 Change_AdminMenu();
						loop = 0;
						break;
					case KEY_4:
						Do_Adminmenu_6();
						loop = 0;
						break;
					case KEY_5:
						Adjust_contrast_5();
						loop = 0;
						break;
					case KEY_6:
						Do_Adminmenu_7();
						loop = 0;
						break;
					case 0x07:
						Adjust_blacklight_7();
						loop = 0;
						break;                                                
					default:
						loop = 1;
						break;
					}				
				break;				
			default:
				loop = 1;
				break;
			}
		KEY_TIMEOUT = KEYTIMEOUT_1S*2;
		if(loop)
			continue;
		break;		
	
	}
}
/*----------------------------------------------------------------------
function name:   	u8 Check_Creditcard(void)
describe:    	 	���ÿ�ģ����
input:   			
output:			Device_OK=:����  Device_MNG=:����
date:			Wtire By andyluo in 2011-10-23 19:17:34
------------------------------------------------------------------------*/
u8 Check_Creditcard(void)
{
	u8 ack;
	
	ack = INI_Creditcard();

	return ack;
}
/*----------------------------------------------------------------------
function name:   	u8 Check_Cash(void)
describe:    	 	ֽ�һ����
input:   			
output:			Device_OK=:����  Device_MNG=:����
date:			Wtire By andyluo in 2011-10-23 19:17:34
------------------------------------------------------------------------*/
u8 Check_Cash(void)
{
	u8 cash_flag,inicash_loop = 3;
	u8 I2c_Buf[1],Credit_ST;
	
		Cash_Power_ON;
		Uart3_Configuration(BaudRate_9600);
		delay(KEYTIMEOUT_1S*5);
		I2C_ReadS_24C(PaperMachineState_add,I2c_Buf,1);
		if(I2c_Buf[0])
			Credit_ST = Device_MNG;
		else
			Credit_ST = Device_OK; 
		
		while(inicash_loop --)
			{
			cash_flag = zhibi_init();//1-OK 2-NGs
			if(cash_flag == 1)
				break;
			}
		
		Cash_Power_OFF;
		
		if(cash_flag == 1)
			{
			I2c_Buf[0] = Device_OK;
			I2C_WriteS_24C(PaperMachineState_add,I2c_Buf,1);
			if(Credit_ST == Device_MNG)
				fault_record(PaperMachineRepairOK);
			return Device_OK;
			}
		I2c_Buf[0] = Device_MNG;
		I2C_WriteS_24C(PaperMachineState_add,I2c_Buf,1);
		if(Credit_ST == Device_OK)
			fault_record(PaperMachineFault);
		return Device_MNG;
}
/*----------------------------------------------------------------------
function name:   	u8 Check_Coin(void)
describe:    	 	Ӳ�һ����
input:   			
output:			Device_OK=:����  Device_MNG=:����
date:			Wtire By andyluo in 2011-10-23 19:17:34
------------------------------------------------------------------------*/
u8 Check_Coin(void)
{
	u8 cash_flag,inicash_loop = 4;
	u8 I2c_Buf[1],Credit_ST;
	

		I2C_ReadS_24C(CoinMachineState_add,I2c_Buf,1);
		if(I2c_Buf[0])
			Credit_ST = Device_MNG;
		else
			Credit_ST = Device_OK; 
		
		Open_Coin_Power();
		delay(KEYTIMEOUT_1S*2);
		
		while(inicash_loop --)
			{
			cash_flag = cctalk_reset();//1-OK 2-NGs
			if(cash_flag == 1)
				break;
			}
		Close_Coin_Power();
		if(cash_flag == 1)
			{
			I2c_Buf[0] = Device_OK;
			I2C_WriteS_24C(CoinMachineState_add,I2c_Buf,1);
			if(Credit_ST == Device_MNG)
				fault_record(CoinMachineRepairOK);
			return Device_OK;
			}
		I2c_Buf[0] = Device_MNG;
		I2C_WriteS_24C(CoinMachineState_add,I2c_Buf,1);
		if(Credit_ST == Device_OK)
			fault_record(CoinMachineFault);
		return Device_MNG;
}
/*----------------------------------------------------------------------
function name:   	void Check_CashBox()
describe:    	 	ֽ��������
input:   			
output:			Device_OK=:����  Device_MNG=:����
date:			Wtire By andyluo in 2011-10-23 19:17:34
------------------------------------------------------------------------*/
u8 Check_CashBox(void)
{
  return Device_OK;
}
/*----------------------------------------------------------------------
function name:   	u8 Check_CoinBox(void)
describe:    	 	Ӳ������
input:   			
output:			Device_OK=:����  Device_MNG=:����
date:			Wtire By andyluo in 2011-10-23 19:17:34
------------------------------------------------------------------------*/
u8 Check_CoinBox(void)
{
  return Device_OK;
}
/*----------------------------------------------------------------------
function name:   	u8 Check_Battery(void)
describe:    	 	��ص�ѹ���
input:   			
output:			Device_OK=:����  Device_MNG=:����
date:			Wtire By andyluo in 2011-10-23 19:17:34
------------------------------------------------------------------------*/
u8 Check_Battery(void)
{
	BT_Value = BT4;

	return Device_OK;
}
/*----------------------------------------------------------------------
function name:   	u8 Check_Printer(void)
describe:    	 	��ӡ���
input:   			
output:			Device_OK=:����  PrintePaperLockFault: PrintePaperWithoutFault; PrinterFault
date:			Wtire By andyluo in 2011-10-23 19:17:34
------------------------------------------------------------------------*/
u8 Check_Printer(void)
{
	u8 printret[1] , retnum , printerstate;// ,checktime ;
/*============add_andyluo2011-10-23 ===============
		TX:10 04 14
		-----------------
		RX:10 0f st1 st2 st3 st4	����6���ֽ�
		-----------------
		st1.0:����ֽ 0-��ֽ 1-��ֽ
		st1.2��ֽ��  0-ֽ�� 1-ֽ��
		��ֻ��������״̬
============add_andyluo2011-10-23 ===============*/		
		Uart4_Configuration(BaudRate_115200);
		Printer_Power_ON;
		SP3243_Open;
		I2C_ReadS_24C(PrinterState_add, printret, 1);
		printerstate = printret[0];
		delay(KEYTIMEOUT_1S*1);
		USART_SendData(UART4,0x10);
		USART_SendData(UART4,0x04);
		USART_SendData(UART4,0x14);

		if(uart_rec1(KEYTIMEOUT_1S*2))
			printret[0]= (USART_ReceiveData(UART4) & 0xFF);
		else
			{
			Printer_Power_OFF;	
			SP3243_Close;
			if(printerstate != Device_MNG)
				{
				//printerstate = Device_MNG;
				//I2C_ByteWrite_24C(PrinterState_add , printerstate);
				fault_record(PrinterFault);
				}
			printerstate = Device_MNG;
			I2C_ByteWrite_24C(PrinterState_add , printerstate);
			return Device_MNG;//PrinterFault;//1 ��ӡ������
			}
			
		for(retnum = 1;retnum<6;retnum++)
			printret[retnum] = uart_rec2(KEYTIMEOUT_1S/2);
		
		Printer_Power_OFF;	
		SP3243_Close;
		
		if(printret[2]&0x01==0x01)
			{
			if(printerstate != Device_PNG)
				{
				fault_record(PrintePaperWithoutFault);
				}
			printerstate = Device_PNG;
			I2C_ByteWrite_24C(PrinterState_add , printerstate);
                        return Device_PNG;//PrintePaperWithoutFault;//1 ��ӡ����ֽ
			}
		else if(printret[2]&0x04==0x04)
			{
			if(printerstate != Device_AM)
				{
				fault_record(PrintePaperLockFault);
				}
			printerstate = Device_AM;
			I2C_ByteWrite_24C(PrinterState_add , printerstate);
			return Device_AM;//PrintePaperLockFault;//1 ��ӡ��ֽ��
			}
		else
			{
			if(printerstate != Device_OK)
				{
				if(printerstate  == Device_MNG)
					fault_record(PrinterRepairOK);
				else if(printerstate  == Device_PNG)
					fault_record(PrintePaperWithoutRepairOK);
				else if(printerstate  == Device_AM)
					fault_record(PrintePaperLockRepairOK);
				
				printerstate = Device_OK;		
				I2C_ByteWrite_24C(PrinterState_add , printerstate);
				}
			return Device_OK;//1 ��ӡ��ֽ����
			}
}
/*----------------------------------------------------------------------
function name:   	u8 Check_Network(void)
describe:    	 	������
input:   			
output:			Device_OK=:����  Device_MNG=:����
date:			Wtire By andyluo in 2011-10-23 19:17:34
------------------------------------------------------------------------*/
u8 Check_Network(void)
{
	if(gprs_user)
		return Device_OK;
	return Device_AM;
}
/*----------------------------------------------------------------------
function name:   	u8 Check_SYS(void)
describe:    	 	������
input:   			
output:			Device_OK=:����  Device_MNG=:����
date:			Wtire By andyluo in 2011-10-23 19:17:34
------------------------------------------------------------------------*/
u8 Check_SYS(void)
{
	return Device_OK;
}

void SYS_DO_BUSY_ICON(u8 x1, u8 y1,u8 x2, u8 y2,u8 state)
{
	switch(state)
		{
		case 0:
			goto_xy(x1,y1);
			print_char_st(0xA3,0x70);//��æ
			print_char_st(0xA3,0x71);
			print_char_st(0xA3,0x72);
			print_char_st(0xA0,0x20);//				
		case 10:
			goto_xy(x2,y2);
			print_char_st(0xA3,0x32);//���æ			
			print_char_st(0xA0,0x20);//���æ			
			break;
		case 1:
			goto_xy(x1,y1);
			print_char_st(0xA3,0x73);//��æ
			print_char_st(0xA3,0x74);
			print_char_st(0xA3,0x75);
			print_char_st(0xA0,0x20);//		
		case 11:
			goto_xy(x2,y2);
			print_char_st(0xA3,0x30);//���æ			
			print_char_st(0xA3,0x31);//���æ			
			break;
		case 2:
			goto_xy(x1,y1);
			print_char_st(0xA3,0x76);//��æ
			print_char_st(0xA3,0x77);
			print_char_st(0xA3,0x78);
			print_char_st(0xA3,0x79);   
		case 12:
			goto_xy(x2,y2);
			print_char_st(0xA3,0x2E);//���æ			
			print_char_st(0xA3,0x2F);//���æ	
			break;
		case 3:
			goto_xy(x1,y1);
			print_char_st(0xA3,0x70);//��æ
			print_char_st(0xA3,0x71);
			print_char_st(0xA3,0x72);
			print_char_st(0xA0,0x20);//	
		case 13:
			goto_xy(x2,y2);
			print_char_st(0xA3,0x2C);//���æ			
			print_char_st(0xA3,0x2D);//���æ	
			break;
		case 4:
			goto_xy(x1,y1);
			print_char_st(0xA3,0x73);//��æ
			print_char_st(0xA3,0x74);
			print_char_st(0xA3,0x75);
			print_char_st(0xA0,0x20);//		
		case 14:
			goto_xy(x2,y2);
			print_char_st(0xA3,0x36);//���æ	
			print_char_st(0xA0,0x20);//���æ			
			break;
		case 5:
			goto_xy(x1,y1);
			print_char_st(0xA3,0x76);//��æ
			print_char_st(0xA3,0x77);
			print_char_st(0xA3,0x78);
			print_char_st(0xA0,0x20);//	
		case 15:
			goto_xy(x2,y2);
			print_char_st(0xA3,0x37);//���æ	
			print_char_st(0xA0,0x20);//���æ			
			break;
	}

}
/*----------------------------------------------------------------------
function name:   	void Check_SystemDevice()
describe:    	 	ϵͳ����������
input:   			OnlyDisp = ON:��� OFF:ֻ��ʾ
output:			
date:			Wtire By andyluo in 2011-10-23 21:03:16
------------------------------------------------------------------------*/
void Check_SystemDevice_DispFault(u8 OnlyDisp)
{
	u8 BatteryState, CashState , CashBoxState, CoinBoxState, CoinState;
	u8 CreditcardState, PrinterState, NetworkState,SYSState,printret[1];
	
	if(OnlyDisp)
		{
		I2C_ReadS_24C(BatteryVoltageState_add, printret, 1);
		BatteryState = printret[0];
		I2C_ReadS_24C(PrinterState_add, printret, 1);
		PrinterState = printret[0];
		I2C_ReadS_24C(CoinBoxState_add, printret, 1);
		CoinBoxState = printret[0];
		I2C_ReadS_24C(CoinMachineState_add, printret, 1);
		CoinState = printret[0];
		I2C_ReadS_24C(CashBoxState_add, printret, 1);
		CashBoxState = printret[0];
		I2C_ReadS_24C(PaperMachineState_add, printret, 1);
		CashState = printret[0];
		I2C_ReadS_24C(CreditCardMachineState_add, printret, 1);
		CreditcardState = printret[0];
		I2C_ReadS_24C(SysterState_add, printret, 1);
		SYSState = printret[0];
		//I2C_ReadS_24C(WCDMAStateInformation_add, printret, 1);
		NetworkState = gprs_user;		
		
		lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x04,0x05); 
		print_str_16_16("Out of order");
		}
	else
		{
		Eaturn_Coin();
		
		PrintandCoinout_LED_OPEN;
		//Retcoin_OPEN;
		delay(KEYTIMEOUT_1S);
		//Retcoin_CLOSE;
		PrintandCoinout_LED_CLOSE;
		
		BatteryState =		Check_Battery();
		SYS_DO_BUSY_ICON(0x20,24,0x40,21, 1);
		
		PrinterState = 		Check_Printer();		
		SYS_DO_BUSY_ICON(0x20,24,0x40,21, 2);
		
		CoinBoxState = 		Check_CoinBox();
		CoinState = 		Check_Coin();		
		SYS_DO_BUSY_ICON(0x20,24,0x40,21, 3);

		
		if(CASH_FUC == ON)
			{
			CashBoxState = 		Check_CashBox();
			CashState = 		Check_Cash();		
			SYS_DO_BUSY_ICON(0x20,24,0x40,21, 4);
			}
		else
			{
			CashBoxState = Device_OK;
			CashState = Device_OK;			
			}
		
		CreditcardState = 	Check_Creditcard();		
		SYS_DO_BUSY_ICON(0x20,24,0x40,21, 5);
		
		SYSState =			Check_SYS();
		NetworkState = 		Check_Network();
		
		lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x04,0x05); 
		print_str_16_16("System check over");
		}
	//1 ��ʾ���ϵ�
	if(BatteryState||(PrinterState == Device_PNG)||(PrinterState == Device_MNG)
		||( ((CoinBoxState == Device_MNG)||(CoinState == Device_MNG))
			&&(CreditcardState == Device_MNG)
			&&((CashBoxState == Device_MNG)||(CashState == Device_MNG)) ) )
		{
		SYS_Stateicon = SYSERR;		
		SYSERROR_LED_OPEN;
		}
	else
		{
		//SYS_Stateicon = SYSERR;
		SYSERROR_LED_CLOSE;
		}
	//1 ��ʾ���ϱ���
	goto_xy(0x08,0x00);	
	if(BatteryState)
		{
		CT_fb_on_gb_off();
		print_num16_char(BackupBatteryVoltageDisp);
		CT_fb_off_gb_off();
		//print_str_16_16(" ");
                print_asi(0x00);
		}
	if(PrinterState)
		{
		CT_fb_on_gb_off();
		if(PrinterState == Device_MNG)
			print_num16_char(PrinterDisp);
		else if(PrinterState == Device_PNG)
			print_num16_char(PrintePaperWithoutDisp);
		else if(PrinterState == Device_AM)
			print_num16_char(PrintePaperLockDisp);
		CT_fb_off_gb_off();
		//print_str_16_16(" ");
                print_asi(0x00);
		}
	if(CoinBoxState)
		{
		CT_fb_on_gb_off();
		if(CoinBoxState == Device_MNG)
			print_num16_char(CoinBoxNoexistDisp);
		else
			print_num16_char(CoinBoxFullDisp);
		CT_fb_off_gb_off();
		//print_str_16_16(" ");
                print_asi(0x00);
		}
	if(CoinState)
		{
		CT_fb_on_gb_off();
		print_num16_char(CoinMachineDisp);
		CT_fb_off_gb_off();
		//print_str_16_16(" ");
                print_asi(0x00);
		}
	if(CashBoxState)
		{
		CT_fb_on_gb_off();
		if(CashBoxState == Device_MNG)
			print_num16_char(PaperBoxNoexistDisp);
		else
			print_num16_char(PaperBoxFullDisp);
		CT_fb_off_gb_off();
		//print_str_16_16(" ");
                print_asi(0x00);
		}
	if(CashState)
		{
		CT_fb_on_gb_off();
		print_num16_char(PaperMachineDisp);
		CT_fb_off_gb_off();
		//print_str_16_16(" ");
                print_asi(0x00);
		}
	if(CreditcardState)
		{
		CT_fb_on_gb_off();
		print_num16_char(CreditCardModuleDisp);
		CT_fb_off_gb_off();
		//print_str_16_16(" ");
                print_asi(0x00);
		}
	if(SYSState)
		{
		CT_fb_on_gb_off();
		print_num16_char(SysterDisp);
		CT_fb_off_gb_off();
		//print_str_16_16(" ");
                print_asi(0x00);
		}
	if(NetworkState)
		{
		CT_fb_on_gb_off();
		print_num16_char(NetworkDisp);
		CT_fb_off_gb_off();
		//print_str_16_16(" ");
                print_asi(0x00);
		}
	
	return;
	
}



void Do_MainMenu_1(void)
{
	do_coin();
}
void Do_MainMenu_2(void)
{
	do_Creditcard_Main();
}
void Do_MainMenu_3(void)
{
u8 cash_flag,chewei1,ijk,f_Correct,link_ack,link_ack1,jilu[20],coinm[5];
u32 cash_mny = 0,cash_sum = 0,cash_time = 0;
u32	loopcash;
unsigned long  f;
char *p,*q,jjj;
                        cash_time=0;
                        cash_mny=0;
	//if(CASH_FUC == OFF)
	//	return;
//////////////////////////////////////////////////////////////////////////////////////////        
//////////////////////////////////////////////////////////////////////////////////////////
//        gprs_user=0; 
        Uart1_Configuration(BaudRate_9600);      //���ڲ����ʵȲ������� 
      //    gprs_user=0;
      //   gprs_busy=0;  
        f_ConnSuccess=0;
        gprs_resetpower=0;
        if(jishu==0)
        link_ack1=GPRS_online_JD2();        
       // delay(KEYTIMEOUT_1S*1);        
//////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////////////////////////
     //    link_ack1=GPRS_online_JD2();
////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////        
	lcd_clear();
	//Refresh_SYSallicon1();
	goto_xy(0x00,0x00);
        CT_fb_on_gb_off(); 
	print_str_16_16("Confirm send message"); 
         // LoadMenuLcd(17,1);
       // LoadMenuLcd(17,2);
	CT_fb_off_gb_off();       
	goto_xy(0x08,0x00);
//	print_str_16_16("Processing");        
//	goto_xy(0x08,0x02);
	print_str_16_16("Press OK or C");
       // LoadMenuLcd(17,3);
///////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
	KEY_TIMEOUT = KEYTIMEOUT_1S*2;
	while(KEY_TIMEOUT -- )
		{
                 ijk=0;
		if(key_flag)
			cash_flag = key_scan1();
		else
			continue;
		switch(cash_flag)
			{
			case KEY_Cancel:
			    lcd_clear();
			     goto_xy(0x04,0x07);
			      print_str_16_16("Quit");
			     goto_xy(0x08,0x07);
			     print_str_16_16("Pls Try Again");
                             GPRS_online_JD3();
			     delay(KEYTIMEOUT_1S*3);
				return;  
			case KEY_Comfirm:
                               ijk=1;
				break;				
			default:
				ijk = 0;
				break;
			}
                if(KEY_TIMEOUT==1)
                  break;
               if(ijk==1)
		break;		
	
	}        
///////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////        
//	Uart3_Configuration(BaudRate_9600);
//	delay(KEYTIMEOUT_1S*4);
//        return;
/*	while(inicash_loop --)
		{
		cash_flag = zhibi_init();//1-OK 2-NGs
		if(cash_flag == 1)
			break;
		}
	if(cash_flag == 2)
		{
		lcd_clear();
		Refresh_SYSallicon();
		Cash_Power_OFF;
		goto_xy(0x04,0x00); 
		print_str_16_16("Cash module failure!"); 	
		//�����ÿ�ģ�����13
		fault_record(CreditCardModuleFault); 
		delay(KEYTIMEOUT_1S*5);
		return;		
		}*/
	lcd_clear();
	//Refresh_SYSallicon1();
	goto_xy(0x00,0x00);
        CT_fb_on_gb_off();        
	print_str_16_16("Confirm right space"); 
        //LoadMenuLcd(19,1);
        //LoadMenuLcd(19,2);
	CT_fb_off_gb_off();        
	goto_xy(0x08,0x00);
//	print_str_16_16("Processing");        
//	goto_xy(0x08,0x02);
	print_str_16_16("Press OK or C");
       // LoadMenuLcd(19,3);
///////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
	KEY_TIMEOUT = KEYTIMEOUT_1S*2;
	while(KEY_TIMEOUT -- )
		{
                 IWDG_ReloadCounter();
                 ijk=0;
		if(key_flag)
			cash_flag = key_scan1();
		else
			continue;
		switch(cash_flag)
			{
			case KEY_Cancel:
			    lcd_clear();
			     goto_xy(0x04,0x07);
			      print_str_16_16("Quit");
			     goto_xy(0x08,0x07);
			     print_str_16_16("Pls Try Again");	
                             GPRS_online_JD3();
			     delay(KEYTIMEOUT_1S*3);
				return;  
			case KEY_Comfirm:
                               ijk=1;
				break;				
			default:
				ijk=0;
				break;
			}
                if(KEY_TIMEOUT==1)
                  break;
               if(ijk==1)
		break;		
	
	}  
     //   delay(KEYTIMEOUT_1S*1);
  	lcd_clear();
	Refresh_SYSallicon1();
	goto_xy(0x04,0x00);
 //       disp_current_time();
//	goto_xy(12,0x00); 
	print_str_16_16("Please wait"); 
         //       LoadMenuLcd(21,2);
//	print_str_16_32("Pls Swipe card");        
	goto_xy(0x08,0x00);
	print_str_16_16("Processing"); 
       // LoadMenuLcd(21,3);
	//delay(KEYTIMEOUT_1S*2);       
////////////////////////////////////////////////////////////////////////////////////////
         link_ack1=GPRS_online_JD2();
                  if(link_ack1==0xE7)
                    {
			lcd_clear();
			 goto_xy(0x04,0x07);
			  print_str_16_16("Quit");
                         //LoadMenuLcd(20,2);
			goto_xy(0x08,0x07);
			print_str_16_16("Pls Try Again");	
                       // LoadMenuLcd(20,3);
                        GPRS_online_JD3();
			 delay(KEYTIMEOUT_1S*3);
                         link_ack =0xE7;
			return;                                                                       
                        }         
/////////////////////////////////////////////////////////////////////////////////////
	//delay(KEYTIMEOUT_1S*7);        
        loopcash=16;
/////////////////////////////////////////////////////////////////////////////////////
                  while(loopcash--)
                  {
 /*                    link_ack =1;
                       delay(KEYTIMEOUT_1S*1);
                    	uart_send_som("*li?#");
                        cash_flag=rec_gprs2(15,sz1,changeon);
	      		if(cash_flag==1)                              
	      			{
                                //  sz1[3]='k';
                                //  sz1[2]='o';
				if((sz1[3]=='k')||(sz1[2]=='o'))   //Lok
                                  {
                                  link_ack = 0;
                                  break;	//#Lok*  �����ɹ�	                                   
                                  }
                                }*/
                   cash_flag=delayout(KEYTIMEOUT_1S*1);
                   cash_flag=GPRS_online_JD2(); 
                        #ifdef _test_all_function
	      		f_ConnSuccess=1;                    
                     //   #else
	      	     //	if(rec_gprs(15,shujv,changeon))
                        #endif                    
                  if(f_ConnSuccess==1)
                  {
                    link_ack = 0;
                    break;
                  }                       
///////////////////////////////////////////////////////////////////////////////////////////////                        
                        else if(cash_flag==0xE7)
                                  {
			          lcd_clear();
			          goto_xy(0x04,0x07);
			          print_str_16_16("Quit");
                                //   LoadMenuLcd(20,2);
			          goto_xy(0x08,0x07);
			          print_str_16_16("Pls Try Again");	
                                  //LoadMenuLcd(20,3);
                                  GPRS_online_JD3();
			          delay(KEYTIMEOUT_1S*3);
                                  link_ack =0xE7;
				  return;                                                                       
                                  }
                       if(loopcash==1)
                                  {
                                  link_ack =0xE9;
			          lcd_clear();	
			         // Refresh_SYSallicon1();
			          goto_xy(0x04,0);
			          print_str_16_16("Network Failure");
                                 // LoadMenuLcd(24,2);
			          goto_xy(0x08,0x00);
			          print_str_16_16("Please Try Again");
                                 // LoadMenuLcd(24,3);
                                  GPRS_online_JD3();
			          delay(KEYTIMEOUT_1S*3);                                  
                                  return;	//#Lok*  �����ɹ�	                                   
                                  }
                  }
             if(link_ack==0)
             {
       /*        *%<Result><Optype><SJ></Optype><Metno><000001></Metno><spaces><0001></spaces></Result>#*/
                 //       delay(KEYTIMEOUT_1S*6);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////                        
                  loopcash=3;
                   link_ack = 0x00;
                 while(loopcash--)
                  {
			uart_send_som("*%<Result><Optype><SJ></Optype><Metno><");//��¼
		//	SEND_asic(0x38);
		//	SEND_asic(0xa1);
			I2C_ReadS_24C(PakingMeterNumber_add,jilu,3);
			SEND_asic_2th(jilu[0]);
			SEND_asic_2th(jilu[1]);
			SEND_asic_2th(jilu[2]);
                        uart_send_som("></Metno><spaces><");
                     //   SEND_asic_2th(0x00);
                        chewei1=(chewei>>4)&0x0F;
                        SEND_asic_2th(chewei1);
                        uart_send_som("></spaces></Result>#");                    
                        delayout(KEYTIMEOUT_1S*4);
                   //     delayout(KEYTIMEOUT_1S*10);                        
                    	uart_send_som("*cha#");
                        cash_flag=rec_gprs2(5,sz1,changeon);
                        #ifdef _test_all_function
	      		//f_ConnSuccess=1;                    
                     //   #else
	      	     //	if(rec_gprs(15,shujv,changeon))
                        strcpy(sz1,"#<Result><Optype><SJ></Optype><Metno><000001></Metno><Spaces><01></Spaces><Eno><000001></Eno><Phone><13596321200></Phone><Stime><2011-11-01 16:13:12></Stime><Tlong><60></Tlong ><Tcost><2></Tcost><Prebuy><2011-11-01 16:13:12></Prebuy></Result>*");
                        cash_flag=1;
                        #endif 
	      		if(cash_flag==1)                              
	      		    {
                                p=strstr(sz1,"<Optype><SJ></Optype>");
                             if(p!=0)
                             {
                                  link_ack = 0x77;
                                  break;	//#Lok*  �����ɹ�	                               
                                 
                              }
                             /* #<Result><Optype><JN></Optype><Metno><000001></Metno><Spaces><0001></Spaces></Result>**/                             
                                p=strstr(sz1,"<Optype><JN></Optype>");
                             if(p!=0)
                             {
			          lcd_clear();
			          goto_xy(0x04,0x07);
			          print_str_16_16("No Message");
                                 // LoadMenuLcd(25,2);
			          goto_xy(0x08,0x07);
			          print_str_16_16("Pls Send First");
                                 // LoadMenuLcd(25,3);
                                  GPRS_online_JD3();
			          delay(KEYTIMEOUT_1S*3);                                 
				  return;                                
                                 
                              }
                                }
                        else if(cash_flag==0xE7)
                                  {
			          lcd_clear();
			          goto_xy(0x04,0x07);
			          print_str_16_16("Quit");
                                //  LoadMenuLcd(18,2);
			          goto_xy(0x08,0x07);
			          print_str_16_16("Pls Try Again");
                                 // LoadMenuLcd(18,3);
                                  GPRS_online_JD3();
			          delay(KEYTIMEOUT_1S*3);
                                  link_ack =0xE7;                                  
				  return;                                                                       
                                  }
                       if(loopcash==1)
                                  {
                                  link_ack =0xE9;
			          lcd_clear();	
			          goto_xy(0x04,0);
			          print_str_16_16("Network Failure");
			          goto_xy(0x08,0x00);
			          print_str_16_16("Please Try Again");	
                                  GPRS_online_JD3();
			          delay(KEYTIMEOUT_1S*3);                                  
                                  return;	//#Lok*  �����ɹ�	                                   
                                  }                        
                  }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////                 
	      		if(link_ack == 0x77)                              
	      			{
/*
#<Result><Optype><SJ></Optype><Metno><000001></Metno><Spaces><0001></Spaces><Eno><000001></Eno><Phone><13596321200></Phone><Stime><2011-11-01 16:13:12>
</Stime><Tlong><60></Tlong ><Tcost><2></Tcost><Prebuy><2011-11-01 16:13:12></Prebuy></Result>*
*/
                //        p=strstr(sz1,"<Optype><SJ></Optype>");
                //        if(p!=0)
                //        {
                        p=strstr(sz1,"<Spaces><");
                        q=(p+9);
                       link_ack=((q[0]-0x30)<<4)+(q[1]-0x30);
                       link_ack=(link_ack<<4)&0xF0;
                    //   link_ack=chewei;
                   /*   if(chewei==0x20)
                        chewei=0x10;
                      else if(chewei==0x10)
                        chewei=0x20;   */                   
                        if(chewei==link_ack)                         
                        {
                        p=strstr(sz1,"<Tlong><");
                         q=(p+8); 
                         f_Correct=1;
                        for(ijk=0;ijk<10;ijk++)
                        {
                          if(q[ijk]=='>')
                            break;
                          jilu[ijk]=q[ijk]-0x30;
                          if(jilu[ijk]>0x09)
                           f_Correct=0;
                        }
                        
                        if(ijk==0)
                         f_Correct=0; 
                       f=jilu[0];
                       if(ijk>=2)
                       {
                        for(jjj=1;jjj<ijk;jjj++)
                        {
                        f= jilu[jjj]+f*10;
                        }}
                         fll(f,jilu,2);
                      //  }
                         if(f_Correct)
                         {
                        cash_time=f;
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
                        p=strstr(sz1,"<Phone><");
                        q=(p+8);                    
               jilu[1]=0x00;
               jilu[2]=0x00; 
               jilu[3]=((0x00)<<4)+(q[0]-0x30);
               jilu[4]=((q[1]-0x30)<<4)+(q[2]-0x30);
               jilu[5]=((q[3]-0x30)<<4)+(q[4]-0x30);
               jilu[6]=((q[5]-0x30)<<4)+(q[6]-0x30); 
               jilu[7]=((q[7]-0x30)<<4)+(q[8]-0x30);
               jilu[8]=((q[9]-0x30)<<4)+(q[10]-0x30);               
////////////////////////////////////////////////////////////////////////               
		jilu[0]=0xE1;              
		jilu[9]=time[4];
		jilu[10]=time[3];
		jilu[11]=time[2];
		jilu[12]=time[1];
		jilu[13]=time[0];
		jilu[14]=0x00;
                jilu[15]=(chewei>>4)&0x0F;                        
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////                        
              //          cash_mny=time_to_money(cash_time,parking_station);
                 if(f_occupied==1)
                {
                time_occpupied=disp_oldutime_max(chewei);
                 }               
                        parking_station=time2money(cash_time);
                        cash_mny=Good_money;
                        if((parking_station==0x03)||(parking_station==0x04)||(parking_station==0x09))
                        {
                           	lcd_clear();	
			        //  Refresh_SYSallicon1();
			          goto_xy(0x04,0);
			          print_str_16_16("Time Select up");
			          goto_xy(0x08,0x00);
			          print_str_16_16("Please Try Again");
                                  GPRS_online_JD3();
			          delay(KEYTIMEOUT_1S*3);                                  
                                  return;                          
                        }
                         }
                         else
                         {
                           	lcd_clear();	
			        //  Refresh_SYSallicon1();
			          goto_xy(0x04,0);
			          print_str_16_16("Data Failure");
			          goto_xy(0x08,0x00);
			          print_str_16_16("Please Try Again");
                                  GPRS_online_JD3();
			          delay(KEYTIMEOUT_1S*3);                                  
                                  return;	                          
                         }
                        }
                        else
                        {
                           	lcd_clear();	
			     //     Refresh_SYSallicon1();
			          goto_xy(0x04,0);
			          print_str_16_16("Space Failure");
			          goto_xy(0x08,0x00);
			          print_str_16_16("Please Try Again");
                                  GPRS_online_JD3();
			          delay(KEYTIMEOUT_1S*3);                                  
                                  return;	                          
                        }
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////                        
          //              }
            /*            else
                        {
                          	lcd_clear();	
			          Refresh_SYSallicon();
			          goto_xy(0x04,0);
			          print_str_16_16("Data Failure");
			          goto_xy(0x08,0x00);
			          print_str_16_16("Please Try Again");					
			          delay(KEYTIMEOUT_1S*5);                                  
                                  return;	
                        }*/
                                }
                        else
                        {
			          lcd_clear();	
			     //     Refresh_SYSallicon1();
			          goto_xy(0x04,0);
			          print_str_16_16("Data Failure");
			          goto_xy(0x08,0x00);
			          print_str_16_16("Please Try Again");	
                                  GPRS_online_JD3();
			          delay(KEYTIMEOUT_1S*3);                                  
                                  return;	//#Lok*  �����ɹ�	
                        }
      //            }
             }
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////        
        /*
	lcd_clear();
	Refresh_SYSallicon();
	Disp_MinmaxTime();
	goto_xy(0x08,0x06);
	print_str_16_16("Please insert cash");
	Delay(500);
	coinm[0] = 0;
	coinm[1] = 0;
	coinm[2] = 0;
	coinm[3] = 0;
	coinm[4] = 0;
	loopcash = 10;//KEYTIMEOUT_1S*10;

	zhibi_init();Delay(500);

	while(loopcash --)
		{
		//zhibi_init();	
		//Delay(500);
		onecashmny = get_bizhi();
		switch(onecashmny)
			{
			case 1: coinm[0]++; zhibi_init();Delay(500);break;
			case 2: coinm[1]++; zhibi_init();Delay(500);break;
			case 5: coinm[2]++; zhibi_init();Delay(500);break;
			case 10:coinm[3]++; zhibi_init();Delay(500);break;
			case 20:coinm[4]++; zhibi_init();Delay(500);break;
			}
		if(onecashmny)
			{		
			cash_mny += onecashmny*100;
			cash_sum ++;
			cash_time=money_to_time(cash_mny,parking_station);
			
			lcd_clear();
			disp_user_main(CashMode,cash_time,cash_mny);
			onecashmny = 0;
			}
		if(cash_mny>=LimitMoney)
			{
			cash_time = LimitTime;
			lcd_clear();
			disp_user_main(CashMode,cash_time,cash_mny);
			Cash_Power_OFF;		
			delay(100);
			//break;
			}
		if(key_flag)
			{
			cash_flag = key_scan();
			
			if(cash_flag == KEY_Comfirm)
				{
				break;
				}
			}
		}
	Cash_Power_OFF; 	
	delay(100);
        */
	//���˱ҹ���	

	if((cash_mny!=0))
		{
		disp_user_OK(cash_time);
	/*	if(Printer_Start() ==Device_MNG)
			{
			Cash_Power_OFF;		
			delay(100);			
			return ;//Device_MNG;
			}
		Al_Mun_print(cash_mny , cash_time,CashMode);*/
////////////////////////////////////////////////////////////////////////
/*                        p=strstr(sz1,"<Phone><");
                         q=(p+8);                   
               jilu[1]=0x00;
               jilu[2]=0x00; 
               jilu[3]=((0x00)<<4)+(q[0]-0x30);
               jilu[4]=((q[1]-0x30)<<4)+(q[2]-0x30);
               jilu[5]=((q[3]-0x30)<<4)+(q[4]-0x30);
               jilu[6]=((q[5]-0x30)<<4)+(q[6]-0x30); 
               jilu[7]=((q[7]-0x30)<<4)+(q[8]-0x30);
               jilu[8]=((q[9]-0x30)<<4)+(q[10]-0x30);               
////////////////////////////////////////////////////////////////////////
                
		jilu[0]=0xE1;             
		jilu[9]=time[4];
		jilu[10]=time[3];
		jilu[11]=time[2];
		jilu[12]=time[1];
		jilu[13]=time[0];
		jilu[14]=0x00;
                jilu[15]=(chewei>>4)&0x0F;
                */
		jilu[16]=(cash_mny>>8)&0xff;
		jilu[17]=cash_mny&0xff;
		jilu[18]=(cash_time>>8)&0xff;
		jilu[19]=cash_time&0xff;
		save_jilu(jilu);
                generatewarm(xxxx,FlashState_add,FlashFullFault,FlashFullRepairOK);
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////	                
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////                
/*		save_add_char(Paper1_0NumberGetmoney_add,coinm[0]);
		save_add_char(Paper2_0NumberGetmoney_add,coinm[1]);
		save_add_char(Paper5_0NumberGetmoney_add,coinm[2]);
		save_add_char(Paper10NumberGetmoney_add,coinm[3]);
		save_add_char(Paper20NumberGetmoney_add,coinm[4]);   */
		//coinm[5]= coinm[0]+coinm[1]+coinm[2]+coinm[3]+coinm[4];
//		save_add_char(PaperNumberGetmoney_add,cash_sum);


//		save_add_char(PaperTimesToday_add,0x01); 				
//		save_add_three(PaperTimesGetmoney_add,0x01);
//		save_add_three(PaperNumberToday_add,cash_mny);
//		save_add_long(PaperNumberGetmoney_add,cash_mny);                
//		save_add_three(PaperMoneyToday_add,cash_mny);
//		save_add_long(PaperMoneyGetmoney_add,cash_mny);
		
//		save_add_char(AllTimesToday_add,0x01);
//		save_add_three(AllMoneyToday_add,cash_mny);
//		save_add_three(AllTimesGetmoney_add,1);
//		save_add_long(AllMoneyGetmoney_add,cash_mny);




		

	/*	I2C_ReadS_24C(PaperNumberGetmoney_add, jilu ,2);		

		I2C_ReadS_24C(CashBoxState_add, coinm ,1);	
		if(coinm[0])
			CIONFULL = Device_AM;
		else
			CIONFULL = Device_OK; 
		I2C_ReadS_24C(PaperAlarmNumber_add, coinm ,2);	

		if((jilu[0]>coinm[0])||((jilu[0]==coinm[0])&&(jilu[1]>=coinm[1])))
			{
			if(CIONFULL == Device_OK)
				{
				//����Ӳ���������ͱ�����¼
				fault_record(PaperBoxFullFault);
				CIONFULL =0;
				coinm[0] = Device_AM;
				I2C_ByteWrite_24C(CashBoxState_add, coinm[0]);	
				}
			}*/
                  delay(KEYTIMEOUT_1S*3);
 	          lcd_clear();
	          goto_xy(0x04,0x00);
	          print_str_16_16("Parking start");
                 // LoadMenuLcd(23,2);
                  delay(KEYTIMEOUT_1S*2);		
	   }
        GPRS_online_JD3();   
	return; 	
}
void Do_MainMenu_4(void)
{
	Do_AdminMenu();
}
//��ʾ�շ�����,0���ͣ��1��ʱͣ��2�����շ�ͣ��3��ֹͣ��
u8 JD_SYStime(void)
{
	if(SYS_Stateicon ==0)
        {
          	lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x00,0x05); 	  
		print_str_32_32("Free time");
                disp_current_time12();
		delay(KEYTIMEOUT_1S*2);
		return 1;
        }
	else if(SYS_Stateicon ==1)
        {
          	lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x00,0x05); 	  
		print_str_32_32("charg by time");
                disp_current_time12();
		delay(KEYTIMEOUT_1S*2);
		return 1;
        }
	else if(SYS_Stateicon ==2)
        {
          	lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x00,0x05); 	  
		print_str_32_32("charg by times");
                disp_current_time12();
		delay(KEYTIMEOUT_1S*2);
		return 1;
        }        
	else if(SYS_Stateicon ==4)
        {
          	lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x00,0x05); 	  
		print_str_32_32("Free day");
                disp_current_time12();
		delay(KEYTIMEOUT_1S*2);
		return 1;
        }        
	else if(SYS_Stateicon ==3)
		{
		lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x00,0x04); 	  
		print_str_32_32("Clearway time");
                disp_current_time12();
		delay(KEYTIMEOUT_1S*2);
                return 0;
		}
/*	else if(SYS_Stateicon == SYSERR)
		{
		lcd_clear();
		Refresh_SYSallicon();
		Check_SystemDevice_DispFault(ON);
		delay(KEYTIMEOUT_1S*5);
		}*/
	else 
		{
		return 0;
		}
	//return 0;
}
u8 JD_SYStime1(void)
{
/*	if((SYS_Stateicon ==1)||(SYS_Stateicon ==5))
        {
          	lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x00,0x05); 	  
		print_str_32_32("Free time");
                disp_current_time12();
		delay(KEYTIMEOUT_1S*2);
		return 1;
        }*/
	      if(SYS_Stateicon ==3)
		{
		lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x00,0x04); 	  
		print_str_32_32("Clearway time");
                disp_current_time12();
		delay(KEYTIMEOUT_1S*2);
                return 0;
		}
/*	else if(SYS_Stateicon == SYSERR)
		{
		lcd_clear();
		Refresh_SYSallicon();
		Check_SystemDevice_DispFault(ON);
		delay(KEYTIMEOUT_1S*5);
		}*/
	else 
		{
		return 1;
		}
	//return 0;
}
/*
u8 JD_SYStime(void)
{
	if(SYS_Stateicon == Normal_Time)
		return 1;
	else if(SYS_Stateicon == Clearway_time)
		{
		lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x04,0x04); 	  
		print_str_32_32("Clearway time");
		delay(KEYTIMEOUT_1S*5);
		}
	else if(SYS_Stateicon == SYSERR)
		{
		lcd_clear();
		Refresh_SYSallicon();
		Check_SystemDevice_DispFault(ON);
		delay(KEYTIMEOUT_1S*5);
		}
	else 
		{
		lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x04,0x05); 	  
		print_str_32_32("Free time");
		delay(KEYTIMEOUT_1S*5);
		}
	return 0;
}*/
///////////////////////////////////////////////////////////////////////////////////////////////
u8 checkchewei(void)
{
    unsigned char wb[2];
	u8 nflag;
	nflag = 0;
			I2C_ReadS_24C(ltime,wb,1);
			if(wb[0]!=0x10)
				nflag = 1;
			I2C_ReadS_24C(lltime,wb,1);
			if(wb[0]!=0x20)
				nflag = 1;
	  		I2C_ReadS_24C(rtime,wb,1);
			if(wb[0]!=0x30)
				nflag = 1;
	  		I2C_ReadS_24C(rrtime,wb,1); 
			if(wb[0]!=0x40)
				nflag = 1;
	
	if(nflag)
		return 1;
	return 0;
}
///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
u8 check(unsigned char bn)
{
    unsigned char nb[8];
	u8 nflag;
	nflag = 1;
    switch(bn)
		{
		case 0x10: 
			I2C_ReadS_24C(ltime,nb,1);
			if(nb[0]==0x10)
				nflag = 0;
			break;
		case 0x20: 
			I2C_ReadS_24C(lltime,nb,1);
			if(nb[0]==0x20)
				nflag = 0;
			break;
	        case 0x30: 
	  		I2C_ReadS_24C(rtime,nb,1);
			if(nb[0]==0x30)
				nflag = 0;
			break;
	        case 0x40:
	  		I2C_ReadS_24C(rrtime,nb,1); 
			if(nb[0]==0x40)
				nflag = 0;
	        default: 
	  		break;
	}
	
	if(nflag)
		return 1;
	return 0;
}
///////////////////////////////////////////////////////////////////////////////////////////////
unsigned int disp_oldutime_max(unsigned char bn)
{
   unsigned char sz2[8];
   unsigned int u1time1,u1time2;
//   unsigned long umoneytemp,BaseFeetemp,BaseTimetemp;
   u8 disp = 1;

    GetCurrentTime();
	
    switch(bn)
		{
		case 0x10: 
			I2C_ReadS_24C(ltime_start,sz1,8);
			break;
		case 0x20: 
			I2C_ReadS_24C(lltime_start,sz1,8);
                        break;
		case 0x30:
			I2C_ReadS_24C(rtime_start,sz1,8);
			break;
		case 0x40: 
			I2C_ReadS_24C(rrtime_start,sz1,8);
			break;
		default: 
			disp = 0;			
			break;
		}
	
	if(disp)
		{
		sz2[4]=sz1[1];
		sz2[3]=sz1[2];
		sz2[2]=sz1[3];
		sz2[1]=sz1[4];
		sz2[0]=sz1[5];
		u1time2=mathtime(sz2);
                return u1time2;
		}
	return u1time2;
}
///////////////////////////////////////////////////////////////////////////////////////////////
void disp_oldutime1(unsigned char bn)
{
   unsigned char sz2[8];
   unsigned int u1time1,u1time2;
//   unsigned long umoneytemp,BaseFeetemp,BaseTimetemp;
   u8 disp = 1;

    GetCurrentTime();
	
    switch(bn)
		{
		case 0x10: 
			I2C_ReadS_24C(ltime,sz1,8);
			break;
		case 0x20: 
			I2C_ReadS_24C(lltime,sz1,8);
                        break;
		case 0x30:
			I2C_ReadS_24C(rtime,sz1,8);
			break;
		case 0x40: 
			I2C_ReadS_24C(rrtime,sz1,8);
			break;
		default: 
			disp = 0;			
			break;
		}
	
	if(disp)
		{
		sz2[4]=sz1[1];
		sz2[3]=sz1[2];
		sz2[2]=sz1[3];
		sz2[1]=sz1[4];
		sz2[0]=sz1[5];
		u1time2=mathtime(sz2);
		u1time1=sz1[6];
		u1time1=u1time1<<8;
		u1time1=u1time1+sz1[7];
		if(u1time1>=u1time2)
			u1time1=u1time1-u1time2;
		else
			u1time1=0;
                 goto_xy(0,0);
                CT_fb_on_gb_off(); 
        //         print_str_16_16("Time left");
                LoadMenuLcd(2,1);
	        print_asi(0x1A);	                 
	        if(u1time1/6000)
		print_num32_32(u1time1/6000%10);	
	        print_num32_32(u1time1/600%10);
	        print_num32_32(u1time1/60%10);
	        print_asi(0x1A);	
	        print_num32_32(u1time1/10%6);
	        print_num32_32(u1time1%10);	
                CT_fb_off_gb_off();
		zimo=0;		
		}
	return;
}
///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
void disp_lefttime(unsigned char disptype)
{                 
 //               goto_xy(0x07,8);
	if(global_u1time1/6000)
	print_asi111(disptype,16+global_u1time1/6000%10);	
	print_asi111(disptype,16+global_u1time1/600%10);
	print_asi111(disptype,16+global_u1time1/60%10);
	print_asi111(disptype,0x1A);	
	print_asi111(disptype,16+global_u1time1/10%6);
	print_asi111(disptype,16+global_u1time1%10);	
}
///////////////////////////////////////////////////////////////////////////////////////////////
void disp_leftmoney(unsigned char disptype)
{                 
               parking_station=time2money(global_u1time1);
              //  u1time2=Good_money;
                left_time=global_u1time1;
                left_money=Good_money;
////////////////////////////////////////////////////////////////////////////////
	    //  goto_xy(0x07,0x68);
              print_asi111(disptype,0x04);
	      if(left_money/10000)
	      print_asi111(disptype,16+left_money/10000%10);
	      print_asi111(disptype,16+left_money/1000%10);
	      print_asi111(disptype,16+left_money/100%10);
              print_asi111(disptype,0x0E);
	      print_asi111(disptype,16+left_money/10%10);
	      print_asi111(disptype,16+left_money%10);	
}
///////////////////////////////////////////////////////////////////////////////////////////////
void disp_expiredtime(unsigned char disptype)
{ 
  unsigned char sz11[8];
  u16 expire_time;
                expire_time=purch_time+left_time;
                math_time(expire_time,sz11);  
//                math_time(global_u1time1,sz11);               
             //   goto_xy(13,16);   
             //  print_str0_16_16("Expires at ");
              /* f_AM=1;
            //   if(sz11[1]>=0x12)
               if(sz11[1]>=12)                 
               {
               sz11[1]= sz11[1]-12;
               f_AM=0;
               }*/
	       print_asi111(disptype,16+sz11[1]/10);
	       print_asi111(disptype,16+sz11[1]%10);        
//	       print_str_16_16(":");
               print_asi111(disptype,0x1A);print_asi111(disptype,0x1A);
	       print_asi111(disptype,16+sz11[0]/10);	
	       print_asi111(disptype,16+sz11[0]%10);	
}
////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
unsigned long get_oldutime(unsigned char bn)
{
   unsigned char sz2[8];
   unsigned long u1time1,u1time2;
   u8 disp = 1;
   GetCurrentTime();
	
    switch(bn){
        case 0x10: 
	  I2C_ReadS_24C(ltime,sz1,8); //��ȡ ���ͣ����ʼ��ʱ��
	  break;
	case 0x20: 
	  I2C_ReadS_24C(lltime,sz1,8);
          break;
	case 0x30:
	  I2C_ReadS_24C(rtime,sz1,8);
	  break;
	case 0x40: 
	  I2C_ReadS_24C(rrtime,sz1,8);
	  break;
	default: 
	  disp = 0;			
	  break;
    }
	
    if(disp){
	sz2[4] = sz1[1];
	sz2[3] = sz1[2];
	sz2[2] = sz1[3];
	sz2[1] = sz1[4];
	sz2[0] = sz1[5];
        
	u1time2 = mathtime(sz2);  //��ȡ ��ʱ - �ϴ�ͣ����ʼʱ��
        
	u1time1 = sz1[6];   //sz1[6,7]��ŵ�ʱ�����ʱ��
	u1time1 = u1time1<<8;
        
	u1time1 = u1time1+sz1[7];
        
        time10[5] = time1[5];
        
	if(u1time1 >= u1time2){
                              
            time10[4] = sz2[4];
            time10[3] = sz2[3];
            time10[2] = sz2[2];
            time10[1] = sz2[1];
            time10[0] = sz2[0];                   
	    u1time1 = u1time1 - u1time2;
            global_u1time1 = u1time1;
        }
	else{
                  
            time10[4] = time1[4];
            time10[3] = time1[3];
            time10[2] = time1[2];
            time10[1] = time1[1];
            time10[0] = time1[0];                   
	    u1time1 = 0;
            global_u1time1 = 0;
        }
                
        return u1time1; 
		
    }
    return u1time1;
}
///////////////////////////////////////////////////////////////////////////////////////////////
void disp_oldutime(unsigned char bn)
{
   unsigned char sz2[8],f_AM;
   unsigned int u1time1,u1time2;
//   unsigned long umoneytemp,BaseFeetemp,BaseTimetemp;
   u8 disp = 1;

    GetCurrentTime();
	
    switch(bn)
		{
		case 0x10: 
			I2C_ReadS_24C(ltime,sz1,8);
			break;
		case 0x20: 
			I2C_ReadS_24C(lltime,sz1,8);
                        break;
		case 0x30:
			I2C_ReadS_24C(rtime,sz1,8);
			break;
		case 0x40: 
			I2C_ReadS_24C(rrtime,sz1,8);
			break;
		default: 
			disp = 0;			
			break;
		}
	
	if(disp)
		{
		sz2[4]=sz1[1];
		sz2[3]=sz1[2];
		sz2[2]=sz1[3];
		sz2[1]=sz1[4];
		sz2[0]=sz1[5];               
		u1time2=mathtime(sz2);
		u1time1=sz1[6];
		u1time1=u1time1<<8;
		u1time1=u1time1+sz1[7];
		if(u1time1>=u1time2)
                {
                time10[5]=time1[5];                   
                time10[4]=sz2[4];
                time10[3]=sz2[3];
                time10[2]=sz2[2];
                time10[1]=sz2[1];
                time10[0]=sz2[0];                   
		 u1time1=u1time1-u1time2;
                 global_u1time1=u1time1;
///////////////////////////////////////////////////////////////
                //LoadMenuLcd(11,1);  
                LoadMenuLcd(11,2); 
                LoadMenuLcd(11,3); 
                LoadMenuLcd(11,4);  
                LoadMenuLcd(11,5); 
                LoadMenuLcd(11,6);
                LoadMenuLcd(11,7);  
                LoadMenuLcd(11,8); 
                LoadMenuLcd(11,9);
                LoadMenuLcd(11,0x0A);        
///////////////////////////////////////////////////////////////                 
                }
		else
                {
                time10[5]=time1[5];                   
                time10[4]=time1[4];
                time10[3]=time1[3];
                time10[2]=time1[2];
                time10[1]=time1[1];
                time10[0]=time1[0];                   
		 u1time1=0;
                 global_u1time1=0;
                }
       //          goto_xy(0,0);
       //         CT_fb_on_gb_off(); 
      //           print_str_16_16("Time left");
//                LoadMenuLcd(2,1);               
	       // goto_xy(1,0x00);
	       // print_str0_16_16("WELCOME TO ABC CITY"); 
                
//	        CT_fb_on_gb_off(); 
//                 zimo=1;
//	        goto_xy(4,40);
//	        print_str0_16_16("Occupied"); 
//                LoadMenuLcd(2,6);
/*                <07,08,05,01,HH:MM>
                goto_xy(0x07,8);
	        if(global_u1time1/6000)
		print_asi111(0x01,16+global_u1time1/6000%10);	
	        print_asi111(0x01,16+global_u1time1/600%10);
	        print_asi111(0x01,16+global_u1time1/60%10);
	        print_asi111(0x01,0x1A);	
	        print_asi111(0x01,16+global_u1time1/10%6);
	        print_asi111(0x01,16+global_u1time1%10);	*/
       //         CT_fb_off_gb_off();
	//	zimo=0;
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//                 LoadMenuLcd(2,7);
        /*       parking_station=time2money(global_u1time1);
                u1time2=Good_money;
                left_time=global_u1time1;
                left_money=u1time2;
////////////////////////////////////////////////////////////////////////////////
	      goto_xy(0x07,0x68);
              print_asi111(0x01,0x04);
	      if(u1time2/10000)
	      print_asi111(0x01,16+u1time2/10000%10);
	      print_asi111(0x01,16+u1time2/1000%10);
	      print_asi111(0x01,16+u1time2/100%10);
              print_asi111(0x01,0x0E);
	      print_asi111(0x01,16+u1time2/10%10);
	      print_asi111(0x01,16+u1time2%10);	*/                
//              CT_fb_off_gb_off();
//              zimo=0;
  /*              if(parking_station==0x03)
                {                 
                lcd_clear(); 
                goto_xy(0x04,0x00); 
                 print_str_16_16("Into Clearway time"); 
                goto_xy(0x08,0x00);                 
                 print_str_16_16("choose time again"); 
                delay(KEYTIMEOUT_1S*1);                 
                } 
                else if(parking_station==0x30)
                {               
                lcd_clear(); 
                goto_xy(0x04,0x00); 
                 print_str_16_16("time over"); 
                goto_xy(0x08,0x00);                 
                 print_str_16_16("choose time again"); 
                delay(KEYTIMEOUT_1S*1);                 
                }                
                else if((parking_station==0x09)||(parking_station==0x04))
                {                 
                lcd_clear(); 
                goto_xy(0x04,0x00); 
                 print_str_16_16("Over Max time"); 
                goto_xy(0x08,0x00);                 
                 print_str_16_16("choose time again"); 
                delay(KEYTIMEOUT_1S*1);                 
                }
                */
////////////////////////////////////////////////////////////////////////////////
          /*      math_time(global_u1time1,sz2);              
                goto_xy(13,16);   
               print_str0_16_16("Expires at ");
	       print_asi111(0x00,16+sz2[1]/10);
	       print_asi111(0x00,16+sz2[1]%10);        
//	       print_str0_16_16(":");
               print_str0_16_16(":");print_str0_16_16(":");
	       print_asi111(0x00,16+sz2[0]/10);	
	       print_asi111(0x00,16+sz2[0]%10);	*/
//               LoadMenuLcd(2,8);
           /*    if(f_AM==1 )
                print_str0_16_16("AM "); 
               else
                 print_str0_16_16("FM "); */
            //   	goto_xy(17,0x00);        
            //   disp_CURTIM_16x32line0();
//               LoadMenuLcd(2,5);
////////////////////////////////////////////////////////////////////////////////                
////////////////////////////////////////////////////////////////////////////////		
		}
	return;
}
///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
void Do_MainMenu(void)
{
	u8 loop = 0;

       if(!check(chewei))//��⳵λ�Ƿ�ռ����
       {
            lcd_clear();
            disp_oldutime(chewei);//��ʾʣ��ʱ��	
            f_occupied=1;
       }
       else
       {      
	    if(SYS_Stateicon ==4)
            {
          	lcd_clear();
		Refresh_SYSallicon();
///////////////////////////////////////////////////////////////
                LoadMenuLcd(14,1);  
                LoadMenuLcd(14,2); 
                LoadMenuLcd(14,3); 
                LoadMenuLcd(14,4);  
                LoadMenuLcd(14,5); 
                LoadMenuLcd(14,6);
                LoadMenuLcd(14,7);  
                LoadMenuLcd(14,8); 
                LoadMenuLcd(14,9);
                LoadMenuLcd(14,0x0A); 
/////////////////////////////////////////////////////////////////////////////////////////////////
	        KEY_TIMEOUT = KEYTIMEOUT_1S*2;
	        while(KEY_TIMEOUT -- )    //��ʾ free parking until 05te 00:00 ���cancel�����˳������û�� ����ʱһ���˳�
		{
		    if(key_flag)
			chewei = key_scan1();
		    else
			continue;
		    switch(chewei){                            
			case KEY_Cancel:
                              return;
				break;			
			default:
                               deal_managecard();
				break;
		    }			
                }
               
///////////////////////////////////////////////////////////////                 
		delay(KEYTIMEOUT_1S*2);
                                return;       
            }        
	    else if(SYS_Stateicon ==3){
		lcd_clear();
		Refresh_SYSallicon();
///////////////////////////////////////////////////////////////
                LoadMenuLcd(13,1);  
                LoadMenuLcd(13,2); 
                LoadMenuLcd(13,3); 
                LoadMenuLcd(13,4);  
                LoadMenuLcd(13,5); 
                LoadMenuLcd(13,6);
                LoadMenuLcd(13,7);  
                LoadMenuLcd(13,8); 
                LoadMenuLcd(13,9);
                LoadMenuLcd(13,0x0A);        
/////////////////////////////////////////////////////////////////////////////////////////////////
	        KEY_TIMEOUT = KEYTIMEOUT_1S*2;
	        while(KEY_TIMEOUT -- ){   //NO PARKING ALLOWED 
                    if(key_flag)
                        chewei = key_scan1();
                    else
			continue;
		    switch(chewei){                             
			case KEY_Cancel:
                              return;
			      break;			
			default:
                              deal_managecard();
                              return;
			      break;		
                    }			
	
                }
////////////////////////////////////////////////////////                
		delay(KEYTIMEOUT_1S*2);
                return;
	
            } 	
            disp_MainMenu();  //display:  insert coins or credit card
            f_occupied=0;
            left_time=0;
            left_money=0;
        }
       
       
	menunum = 1;
	//KEY_TIMEOUT = KEYTIMEOUT_1S*2;
	KEY_TIMEOUT =3;        
         f_execution=0;
	while(KEY_TIMEOUT -- ){
                 
          if((wake_flag == Coin_wakeup)||(f_execution == 4)){
                   
            Do_MainMenu_1();  //do_coin()                 
            f_execution=1;                
          }                
          else if(f_execution==1)                   
            break;                
          else                  
            Do_MainMenu_2();  //do_Creditcard_Main()
          
          if((KEY_TIMEOUT==1)||(KEY_TIMEOUT==0))                   
            break;				
		
        }	
}
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
void Do_MainMenu1(void)
{
	u8 loop = 0;
	if(SYS_Stateicon ==0)
        {
          	lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x08,0x24); 	  
		print_str_32_32("FREE PARKING");
		delay(KEYTIMEOUT_1S*2);
                return;
        }
	/*else if(SYS_Stateicon ==1)
        {
          	lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x08,0x24);  
		print_str_32_32("charg by time");
		delay(KEYTIMEOUT_1S*2);
        }*/
	/*else if(SYS_Stateicon ==2)
        {
          	lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x08,0x24);	  
		print_str_32_32("charg by times");
		delay(KEYTIMEOUT_1S*2);
                                return;
        }    */    
	else if(SYS_Stateicon ==4)
        {
          	lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x08,0x24);	  
		print_str_32_32("FREE PARKING");
		delay(KEYTIMEOUT_1S*2);
                                return;
        }        
	else if(SYS_Stateicon ==3)
		{
		lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x08,0x24);	  
		print_str_32_32("NO PARKING");
		delay(KEYTIMEOUT_1S*2);
                return;
		} 	
	disp_MainMenu();
	menunum = 1;
	KEY_TIMEOUT = KEYTIMEOUT_1S*2;
	while(KEY_TIMEOUT -- )
		{
		if(key_flag)
			Key_Value = key_scan1();
		else
			continue;
		switch(Key_Value)
			{
			case KEY_1:
				if(JD_SYStime())
                                {
                                if(!check(chewei))//��⳵λ�Ƿ�ռ����
			        {
			         //addtime = 1;
			         lcd_clear();
			         disp_oldutime(chewei);//��ʾʣ��ʱ��	
                                 //disp_CURTIM_16x32CHANG();
                                 delay(KEYTIMEOUT_1S*5);
			         //do_Creditcard_intoCoin(space);
			         //KEY_Program();                          
			        }
                                else
                                {
			          Do_MainMenu_1();
                                 }
                                }
			         loop = 0;
			         break;
			case KEY_2:
				if(JD_SYStime())
                                {
                                if(!check(chewei))//��⳵λ�Ƿ�ռ����
			        {
			         //addtime = 1;
			         lcd_clear();
			         disp_oldutime(chewei);//��ʾʣ��ʱ��	
                                 //disp_CURTIM_16x32CHANG();
                                 delay(KEYTIMEOUT_1S*5);
			         //do_Creditcard_intoCoin(space);
			         //KEY_Program();                          
			        }
                                else
                                {
			          Do_MainMenu_2();
                                 }
                                }                                  
//					Do_MainMenu_2();
				loop = 0;
				break;
			case KEY_3:
				if(JD_SYStime())
                                {
                                if(!check(chewei))//��⳵λ�Ƿ�ռ����
			        {
			         //addtime = 1;
			         lcd_clear();
			         disp_oldutime(chewei);//��ʾʣ��ʱ��	
                                 //disp_CURTIM_16x32CHANG();
                                 delay(KEYTIMEOUT_1S*5);
			         //do_Creditcard_intoCoin(space);
			         //KEY_Program();                          
			        }
                                else
                                {
			          Do_MainMenu_3();
                                 }
                                }  
			//		Do_MainMenu_3();
				loop = 0;
				break;
			case KEY_4:
				Do_MainMenu_4();
				loop = 0;
				break;
			case KEY_Up:                         
				menunum --;
				if(menunum == 0)
					menunum =4;
				switch(menunum)
					{
					case 1:
						disp_MainMenu_1();
						break;
					case 2:
						disp_MainMenu_2();					
						break;
					case 3:
						disp_MainMenu_3();					
						break;
					case 4:
						disp_MainMenu_4();						
						break;
					default:
						break;
					}
				loop = 1;
				break;
				
			case KEY_Down:                          
				menunum ++;
				if(menunum == 5)
					menunum =1;
				switch(menunum)
					{
					case 1:
						disp_MainMenu_1();
						break;
					case 2:
						disp_MainMenu_2();					
						break;
					case 3:
						disp_MainMenu_3();					
						break;
					case 4:
						disp_MainMenu_4();						
						break;
					default:
						break;
					}
				loop = 1;
				break;
				
			//case KEY_Cancel:
			case KEY_6:                          
				//return;
				loop = 0;
				break;
			//case KEY_Comfirm:
			case KEY_5:                          
				switch(menunum)
					{
					case 1:
				if(JD_SYStime())
                                {
                                if(!check(chewei))//��⳵λ�Ƿ�ռ����
			        {
			         //addtime = 1;
			         lcd_clear();
			         disp_oldutime(chewei);//��ʾʣ��ʱ��	
                                 disp_CURTIM_16x32CHANG();
                                 delay(KEYTIMEOUT_1S*5);
			         //do_Creditcard_intoCoin(space);
			         //KEY_Program();                          
			        }
                                else
                                {
			          Do_MainMenu_1();
                                 }
                                }
			         loop = 0;
			         break;
					case 2:
				if(JD_SYStime())
                                {
                                if(!check(chewei))//��⳵λ�Ƿ�ռ����
			        {
			         //addtime = 1;
			         lcd_clear();
			         disp_oldutime(chewei);//��ʾʣ��ʱ��	
                                 disp_CURTIM_16x32CHANG();
                                 delay(KEYTIMEOUT_1S*5);
			         //do_Creditcard_intoCoin(space);
			         //KEY_Program();                          
			        }
                                else
                                {
			          Do_MainMenu_2();
                                 }
                                }                                  
//					Do_MainMenu_2();
				loop = 0;
				break;
					case 3:
				if(JD_SYStime())
                                {
                                if(!check(chewei))//��⳵λ�Ƿ�ռ����
			        {
			         //addtime = 1;
			         lcd_clear();
			         disp_oldutime(chewei);//��ʾʣ��ʱ��	
                                 disp_CURTIM_16x32CHANG();
                                 delay(KEYTIMEOUT_1S*5);
			         //do_Creditcard_intoCoin(space);
			         //KEY_Program();                          
			        }
                                else
                                {
			          Do_MainMenu_3();
                                 }
                                }  
			//		Do_MainMenu_3();
				loop = 0;
				break;
					case 4:
						Do_MainMenu_4();						
						loop = 0;
						break;
					default:
						loop = 1;
						break;
					}				
				break;				
			default:
				loop = 1;
				break;
			}
		KEY_TIMEOUT = KEYTIMEOUT_1S*2;
		if(loop)
			continue;
		break;		
		
		}	
}
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////

void Disp_MinmaxTime(void)
{
	u16 bb;
        
	if(LimitTime < MinTime)
            MinTime = LimitTime;

	bb = MinTime;///16*10;
	//MinTime = bb;
	
	goto_xy(0x00,0x06);
	print_str_16_16("Min time");
        print_asi(0x1A);
	print_num16_16(bb/600%10);
	print_num16_16(bb/60%10);
	//print_char_st(0xA0,0x1A);
        print_asi(0x1A);        
	print_num16_16(bb/10%6);
	print_num16_16(bb%10);	
	bb = LimitTime;///16*10;
	
	//LimitTime = bb;
	goto_xy(0x04,0x06);
	print_str_16_16("Max time");
        print_asi(0x1A);
	print_num16_16(bb/600%10);
	print_num16_16(bb/60%10);
	//print_char_st(0xA0,0x1A);
        print_asi(0x1A);        
	print_num16_16(bb/10%6);
	print_num16_16(bb%10);	
}


u8 Printer_Start(void)
{
	u8 print_state;
	
	print_state = Check_Printer();
	if((print_state == Device_MNG)||(print_state == Device_PNG))
		{
		lcd_clear();
		Refresh_SYSallicon();
		goto_xy(0x04,0x06);
		print_str_16_16("Print failed");
		goto_xy(0x08,0x06);
		print_str_16_16("Please try again");		
		delay(KEYTIMEOUT_1S*5);
		return Device_MNG;
		}
	
	//Uart4_Configuration(BaudRate_115200);
	Printer_Power_ON;
	SP3243_Open;	
	delay(KEYTIMEOUT_1S*1);
	lcd_clear();
	Refresh_SYSallicon();
	pls_wt_Printing_ticket();
	PrintandCoinout_LED_OPEN;

	
	return Device_OK;
	//delay(KEYTIMEOUT_1S*1);
}
void Printer_Over(void)
{
	
	//delay(KEYTIMEOUT_1S*10);
	delay(KEYTIMEOUT_1S*3);
	Printer_Power_OFF;	
	SP3243_Close;
	
	tik_No += 1;//Ʊ�ݺ���1Ϊ�´�׼��
		if(tik_No >= 100)
			tik_No = 0;//Ʊ�ݺ�Ϊ0-99
//	I2C_ByteWrite_24C(SerialNo_add,tik_No);

	lcd_clear();
	Refresh_SYSallicon();
	goto_xy(0x30,0x06);
	print_str_16_16("Please take ticket");  
	delay(KEYTIMEOUT_1S*3);
	PrintandCoinout_LED_CLOSE;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
unsigned char GPRS_online_JD2(void)
{
	u32 linkacktime;
        unsigned char Gprsm[6],Time_return;
        if(f_ConnSuccess==1)
          return jishu;
	         jishu++;
		switch(jishu)
			{
			case 1: close_wcdma_modem(); GPRS_LINKing=0;break; 
			case 2: open_wcdma_modem();gprs_resetpower=1;
                                Time_return=delayout(KEYTIMEOUT_1S*3);
					//gprs_user=1;gprs_busy=0;
					break;
                        case 3: Time_return=delayout(KEYTIMEOUT_1S*1);                          
                                DPSIP=0;
                                Link_ServerIP();
				//if(DPSIP)
				Wakeup__3G_CDMA; 
                                already_sleep=0;
                                gprs_user=0;
                                gprs_busy=0;
                                if(gprs_resetpower==1)
                                Time_return=delayout(KEYTIMEOUT_1S*5);
                                break;
			case 4: 
					//if(DPSIP)
						{
						//Time_return=delayout(1000);
						uart_send_som("*li?#");
						RxCounter = 0;
						//Time_return=delayout(KEYTIMEOUT_1S);
						linkacktime = KEYTIMEOUT_1S*2;
						while(linkacktime--)
							{
                                        //                 if(wake_flag ==Coin_wakeup)
                                        //                 return;
                                                         if(key_flag==5)
                                                         return 0xe7;                                                          
							 if((RxBuffer[1] == 'L')&&(RxBuffer[3] == 'k'))
								{
								gprs_user=1;//break;  //#Lok*  �����ɹ�   
								GPRS_CSQ(Isnohide);
								gprs_user=1;gprs_busy=0;
								if(DPSIP==1)
									{
									Sleep__3G_CDMA;
                                                                      //  Time_return=delayout(KEYTIMEOUT_1S);
									//Sleep__3GandMCU_PD;   //3 ����3Gģ�����
                                                                        already_sleep=1;
									}
                                                                else
                                                                {
	                                                               f_ConnSuccess=1;
                                                                }
								break;
								}
							}
						}
					break;
			case 5: 
					//if(DPSIP)
						//{
						if(gprs_user)
							break;
						//Time_return=delayout(1000);
						uart_send_som("*li?#");
						RxCounter = 0;
						//Time_return=delayout(KEYTIMEOUT_1S);
						linkacktime = KEYTIMEOUT_1S*2;
						while(linkacktime--)
							{
                                                    //     if(wake_flag ==Coin_wakeup)
                                                    //     return;
                                                          if(linkacktime==1)
                                                            break;
                                                         if(key_flag==5)
                                                         return 0xe7;                                                          
							 if((RxBuffer[1] == 'L')&&(RxBuffer[3] == 'k'))
								{
								gprs_user=1;//break;  //#Lok*  �����ɹ�   
								GPRS_CSQ(Isnohide);
								gprs_user=1;gprs_busy=0;
								if(DPSIP==1)
									{
									Sleep__3G_CDMA;
                                                                        Time_return=delayout(KEYTIMEOUT_1S);
									Sleep__3GandMCU_PD;   //3 ����3Gģ�����	
                                                                        already_sleep=1;
									}
                                                               else
                                                                {
	                                                               f_ConnSuccess=1;
                                                                }
								break;
								}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////                                               
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////                                                        
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////                                                         
							}
						if((linkacktime==1)||(linkacktime==0))
							jishu = 0;
						//}
					break;
                        case 6:
                                     gprs_user=0;
                                     gprs_busy=0;              
                                   if(DPSIP==1)
                                   {
                                     if(already_sleep==1)
                                     {
					uart_send_som("*sleep#");
					Time_return=delayout(KEYTIMEOUT_1S);
					//uart_send_som("*sleep#");
					Time_return=delayout(KEYTIMEOUT_1S);
					//uart_send_som("*wake#");
                                        already_sleep=0;
					jishu = 2; 
                                     }
                                     else
                                     {
					Sleep__3G_CDMA;
                                      //  Time_return=delayout(KEYTIMEOUT_1S);
					//Sleep__3GandMCU_PD;   //3 ����3Gģ�����
                                        already_sleep=1;
                                      //  jishu = 3;
                                     }
                                   }
                                   else
                                   {
                                     if(already_sleep==1)
                                     {
					uart_send_som("*sleep#");
					Time_return=delayout(KEYTIMEOUT_1S);
					//uart_send_som("*sleep#");
					Time_return=delayout(KEYTIMEOUT_1S);
					uart_send_som("*wake#");
                                        already_sleep=0;
					jishu = 3; 
                                     }
                                     else
                                     {
					//f_ConnSuccess=1;
                                        jishu = 3;
                                        gprs_user=0;
                                        gprs_busy=0;
                                     }                                    
                                   }
                            break;
			default:
                                     gprs_user=0;
                                     gprs_busy=0;                           
                                   if(DPSIP==1)
                                   {
                                     if(already_sleep==1)
                                     {
					uart_send_som("*sleep#");
					Time_return=delayout(KEYTIMEOUT_1S);
					//uart_send_som("*sleep#");
					Time_return=delayout(KEYTIMEOUT_1S);
					//uart_send_som("*wake#");
                                        already_sleep=0;
					jishu = 2; 
                                     }
                                     else
                                     {
					Sleep__3G_CDMA;
                                       // Time_return=delayout(KEYTIMEOUT_1S);
					//Sleep__3GandMCU_PD;   //3 ����3Gģ�����
                                        already_sleep=1;
                                       // jishu = 3;
                                     }
                                   }
                                   else
                                   {
                                     if(already_sleep==1)
                                     {
					uart_send_som("*sleep#");
					Time_return=delayout(KEYTIMEOUT_1S);
					//uart_send_som("*sleep#");
					Time_return=delayout(KEYTIMEOUT_1S);
					uart_send_som("*wake#");
                                        already_sleep=0;
					jishu = 3; 
                                     }
                                     else
                                     {
					//f_ConnSuccess=1;
                                        jishu = 3;
                                        gprs_user=0;
                                        gprs_busy=0;                                        
                                     }                                    
                                   }
                                  break;
			}		
		return jishu;
}
///////////////////////////////////////////////////////////////////////////
/*
void NetInquie(void)
{
//delay(1000);
uart_send_som("*li?#");
RxCounter = 0;
//delay(KEYTIMEOUT_1S);
linkacktime = KEYTIMEOUT_1S*2;
while(linkacktime--)
{
 //                 if(wake_flag ==Coin_wakeup)
 //                 return;
 if(key_flag==5)
 return 0xe7;                                                          
 if((RxBuffer[1] == 'L')&&(RxBuffer[3] == 'k'))
{
//break;  //#Lok*  �����ɹ�   
GPRS_CSQ(Isnohide);
gprs_user=1;gprs_busy=0;
if(DPSIP==1)
{
Sleep__3G_CDMA;
Sleep__3GandMCU_PD;   //3 ����3Gģ�����
already_sleep=1;
}
 else
{
f_ConnSuccess=1;
}
break;
}
}
}*/
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
unsigned char GPRS_online_JD3(void)
{
	//u32 linkacktime;
       // unsigned char Gprsm[6];
       // if(f_ConnSuccess==1)
       //   return jishu;
	//         jishu++;
		switch(jishu)
			{
                        case 3:                          
                               #ifdef _DPSIP_NET
                               break;
                               #else
                               CLOSE_Power_3G;
                               break;
                               #endif 
                               break;
			case 1:
			case 2:
 
                                break;
			case 4:
///////////////////////////////////////////////////////////////////////////////
                               #ifdef _DPSIP_NET                          
///////////////////////////////////////////////////////////////////////////////                          
                             if( f_ConnSuccess==1)
                             {
                                     if(already_sleep==1)
                                     {
                                     }
                                     else
                                     {
					Sleep__3G_CDMA; 
                                       // Time_return=delayout(KEYTIMEOUT_1S);
					//Sleep__3GandMCU_PD;   //3 ����3Gģ�����
                                        already_sleep=1;
                                     }                               
                             }
                             else
                             {
                             }
                               #else
                               CLOSE_Power_3G;
                               #endif                             
			     break;
			case 5:
                               #ifdef _DPSIP_NET                           
                             if( f_ConnSuccess==1)
                             {
                                     if(already_sleep==1)
                                     {
                                     }
                                     else
                                     {
					Sleep__3G_CDMA;
                                        //Time_return=delayout(KEYTIMEOUT_1S);
					//Sleep__3GandMCU_PD;   //3 ����3Gģ�����
                                        already_sleep=1;
                                     }                               
                             }
                             else
                             {
                             }
                               #else
                                CLOSE_Power_3G;
                               #endif                              
			     break;
                        case 6:
                               #ifdef _DPSIP_NET                           
                             if( f_ConnSuccess==1)
                             {
                                     if(already_sleep==1)
                                     {
                                     }
                                     else
                                     {
					Sleep__3G_CDMA;
                                      //  Time_return=delayout(KEYTIMEOUT_1S);
					//Sleep__3GandMCU_PD;   //3 ����3Gģ�����
                                        already_sleep=1;
                                     }                               
                             }
                             else
                             {
                             }
                                #else
                                CLOSE_Power_3G;
                               #endif                             
			     break;
			default:
                               #ifdef _DPSIP_NET                           
                             if( f_ConnSuccess==1)
                             {
                                     if(already_sleep==1)
                                     {
                                     }
                                     else
                                     {
					Sleep__3G_CDMA;
                                     //   Time_return=delayout(KEYTIMEOUT_1S);
					//Sleep__3GandMCU_PD;   //3 ����3Gģ�����
                                        already_sleep=1;
                                     }                               
                             }
                             else
                             {
                             }
                                #else
                                CLOSE_Power_3G;
                               #endif                             
			     break;
			}		
		return jishu;
}
////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
unsigned char mathdata(unsigned char timex1[],unsigned char timex2[])
{
                if(timex1[4]>timex2[4])
                return 2;
                else if(timex1[4]<timex2[4])
                return 0;
                else
                {
                if(timex1[3]>timex2[3])
                return 2;
                else if(timex1[3]<timex2[3])
                return 0; 
                else
                {
                if(timex1[2]>timex2[2])
                return 2;
                else if(timex1[2]<timex2[2])
                return 0; 
                else
                {
                if(timex1[1]>timex2[1])
                return 2;
                else if(timex1[1]<timex2[1])
                return 0;
                else
                {
                if(timex1[0]>timex2[0])
                return 2;
                else if(timex1[0]<timex2[0])
                return 0;
                else
                 return 1;
                }                
                }                
                }                
                }
}
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
unsigned char mathfreeday(unsigned char timex1[],unsigned char timex2[])
{
                if(timex1[4]>timex2[4])
                  return 2;
                else if(timex1[4]<timex2[4])
                  return 0;
                else
                {
                    if(timex1[3]>timex2[3])
                      return 2;
                    else if(timex1[3]<timex2[3])
                      return 0; 
                    else
                    {
                        if(timex1[2]>timex2[2])
                          return 2;
                        else if(timex1[2]<timex2[2])
                          return 0; 
                        else
                        {
                          return 1;
                        }                
                    }                
                }
}
/**********************************************
�Ƿ�Ϊ�����,�õ���ֵ�뵱�ձȽ�
���1ΪFREEDAY,
���0����
***********************************************/
unsigned char Cal_FreeDay(void)
{
  unsigned char i,k;
  unsigned char sz2[10];
             I2C_ReadS_24C(D_WeekSign,sz1,1);
             k = sz1[0];           
             if(k == 1)
             {
                 I2C_ReadS_24C(D_FreeDay,sz1,1);
                 k = sz1[0];
                 if((k >= 1)&&(k <= 30)){
                     I2C_ReadS_24C(D_FreeDay+1,sz1,3*k);
                     for(i=0;i<k;i++){
                         sz2[4]=sz1[3*i];
                         sz2[3]=sz1[3*i+1];
                         sz2[2]=sz1[3*i+2]; 
                         sz2[1]=0; 
                         sz2[0]=0; 
                         if(mathfreeday(sz2,time)==1){
                              return 1;
                         }
                      
                     }
                 }
                 return 0;
             }
             else
             {              
                 I2C_ReadS_24C(D_FreeWeek,sz2,1);
                 k=sz2[0];
                 if((k>=1)&&(k<=30)){             
                     I2C_ReadS_24C(D_FreeWeek+1,sz2,k);             
                     for(i=0;i<k;i++){
                        if(sz2[i]==time1[5]){
                            return 1;
                        }                 
                     }            
                     return 0;
                 }             
             }
             return 0;             
}
/////////////////////////////////////////////////////////////////////////////
void Newipstart(void)
{
  unsigned char l, f_datacontact,k;
  unsigned char sz7[22];
                I2C_ReadS_24C(Newiptime,sz1,5);
                if((sz1[0]==0xFF)&&(sz1[1]==0xFF)&&(sz1[2]==0xFF)&&(sz1[3]==0xFF)&&(sz1[4]==0xFF))
                {
                }
                else
                {
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////                                                        
		if(sz1[3]>0x12)
		return;
		if(sz1[2]>0x31)
		return;
		if(sz1[1]>0x23)
		return;
		if(sz1[0]>0x59)
                return;                  
////////////////////////////////////////////////////////////////////////////////////                  
////////////////////////////////////////////////////////////////////////////////////                  
                if(mathdata(sz1,time)<=1)
                {
                I2C_ReadS_24C(Newapn,sz1,1);
                if(sz1[0]!=0xFF)
                {
                l=sz1[0];
                I2C_ReadS_24C(Newapn,sz1,64);                                           
//		I2C_PageWrite_24C(APN_USERNAME_PASSWORD_add,sz1,64);
                sz1[0]=0xFF;
                I2C_WriteS_24C(Newapn,sz1,1);                
                }                  
///////////////////////////////////////////////////////////////////////////////////
//#define Newipchange                                     0x20A8
//#define Newdpsipchange                                  0x20A9
//#define Newapnchange                                    0x20AA
//#define Newnochange                                     0x20AB 
///////////////////////////////////////////////////////////////////////////////////                  
                I2C_ReadS_24C(Newip,sz1,1);
                if(sz1[0]!=0xFF)
                {
                l=sz1[0];
                I2C_ReadS_24C(Newip,sz1,22);              
             //  k=l+1;
                f_datacontact=0;
//	        I2C_ReadS_24C(IP_Length_add,sz7,22);	 
/*	 for(k=0;k<sz7[0]+1;k++) 	uart_send(sz7[k]);*/
	       for(k=1;k<sz7[0]+1;k++)
	 	{
		if(sz7[k] == 'P')
		f_datacontact=1;
                   if(f_datacontact==1)
                   {
                    sz1[l+1]=sz7[k];
                    l++;
                   }
	 	}
           //    sz1[0]=l+1;
                 sz1[0]=l;                              
//		I2C_PageWrite_24C(IP_Length_add,sz1,16);
		//I2C_PageWrite_24C(IP_Length_add+16,sz1+16,l+1); 
//		I2C_PageWrite_24C(IP_Length_add+16,sz1+16,16);
                sz1[0]=0xFF;
                I2C_WriteS_24C(Newip,sz1,1);                
                }
////////////////////////////////dspip////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
               I2C_ReadS_24C(Newdspip,sz1,1);
                if(sz1[0]!=0xFF)
                {               
                l=sz1[0];
                I2C_ReadS_24C(Newdspip,sz1,22); 
                for(k=1;k<(l+1);k++)
                {
                  if((sz1[k]>0x39)||((sz1[k]<0x30)&&(sz1[k]!='.')))
                    return;
                }
             //  k=l+1;
                f_datacontact=0;
//	        I2C_ReadS_24C(DPSIP_Length_add,sz7,22);	 
	       for(k=1;k<sz7[0]+1;k++)
	 	{
		if(sz7[k] == 'P')
		f_datacontact=1;
                   if(f_datacontact==1)
                   {
                    sz1[l+1]=sz7[k];
                    l++;
                   }
	 	}
           //    sz1[0]=l+1;
                 sz1[0]=l;                              
//		I2C_PageWrite_24C(DPSIP_Length_add,sz1,16);
		//I2C_PageWrite_24C(IP_Length_add+16,sz1+16,l+1); 
//		I2C_PageWrite_24C(DPSIP_Length_add+16,sz1+16,16); 
                sz1[0]=0xFF;
                I2C_WriteS_24C(Newdspip,sz1,1);                
                }               
                sz1[0]=0xFF;
                sz1[1]=0xFF;
                sz1[2]=0xFF;
                sz1[3]=0xFF;
                sz1[4]=0xFF;
                sz1[5]=0xFF;              
                I2C_WriteS_24C(Newiptime,sz1,6);
                }
                }
}
////////////////////////////////////////////////////////////////////////////////////
void NewMetno(void)
{
  unsigned char sz12[10];
                I2C_ReadS_24C(Newnotime,sz1,5);
                if((sz1[0]==0xFF)&&(sz1[1]==0xFF)&&(sz1[2]==0xFF)&&(sz1[3]==0xFF)&&(sz1[4]==0xFF))
                {
                }
                else
                {
////////////////////////////////////////////////////////////////////////////////////                                                        
		if(sz1[3]>0x12)
		return;
		if(sz1[2]>0x31)
		return;
		if(sz1[1]>0x23)
		return;
		if(sz1[0]>0x59)
                return;                  
////////////////////////////////////////////////////////////////////////////////////                   
                if(mathdata(sz1,time)<=1)
                {
                I2C_ReadS_24C(Newno,sz1,3);
                if(sz1[0]!=0xFF)
                {
//		I2C_PageWrite_24C(SerialNo_add,sz1,3);
                sz1[0]=0xFF;
                I2C_WriteS_24C(Newno,sz1,1);                
                }
                sz1[0]=0xFF;
                sz1[1]=0xFF;
                sz1[2]=0xFF;
                sz1[3]=0xFF;
                sz1[4]=0xFF;
                sz1[5]=0xFF;             
                I2C_WriteS_24C(Newnotime,sz1,6);
                }
                }
}
//////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
void NewRate(void)
{
//  unsigned char l;
                I2C_ReadS_24C(BAC_D_Ratestime,sz1,5);
                if((sz1[0]==0xFF)&&(sz1[1]==0xFF)&&(sz1[2]==0xFF)&&(sz1[3]==0xFF)&&(sz1[4]==0xFF))
                {
                }
                else
                {
////////////////////////////////////////////////////////////////////////////////////                                                        
		if(sz1[3]>0x12)
		return;
		if(sz1[2]>0x31)
		return;
		if(sz1[1]>0x23)
		return;
		if(sz1[0]>0x59)
                return;                  
////////////////////////////////////////////////////////////////////////////////////                   
                if(mathdata(sz1,time)<=1)
                { 
                memreplace(0x2B00,0x2800,16); 
                memreplace(0x2B10,0x2810,16); 
                memreplace(0x2B20,0x2820,16); 
                memreplace(0x2B30,0x2830,16);  
                memreplace(0x2B40,0x2840,16); 
                memreplace(0x2B50,0x2850,16); 
                memreplace(0x2B60,0x2860,16); 
                memreplace(0x2B70,0x2870,16); 
                memreplace(0x2B80,0x2880,16); 
                memreplace(0x2B90,0x2890,16); 
                memreplace(0x2BA0,0x28A0,16); 
                memreplace(0x2BB0,0x28B0,16);  
                memreplace(0x2BC0,0x28C0,16); 
                memreplace(0x2BD0,0x28D0,16); 
                memreplace(0x2BE0,0x28E0,16); 
                memreplace(0x2BF0,0x28F0,16);
                memreplace(0x2C00,0x2900,16); 
                memreplace(0x2C10,0x2910,16); 
                memreplace(0x2C20,0x2920,16); 
                memreplace(0x2C30,0x2930,16);  
                memreplace(0x2C40,0x2940,16); 
                memreplace(0x2C50,0x2950,16);
/////////////////////////////////////////////////////////////////////////////////
//                I2C_ReadS_24C(0x2B00,sz1,16);                
//		I2C_PageWrite_24C(0x2800,sz1,16);
//////////////////////////////////////////////////////////////////                
 /*               
                I2C_ReadS_24C(0x2B10,sz1,16);                
		I2C_PageWrite_24C(0x2810,sz1,16);     
                I2C_ReadS_24C(0x2B20,sz1,16);                
		I2C_PageWrite_24C(0x2820,sz1,16);   
                I2C_ReadS_24C(0x2B30,sz1,16);                
		I2C_PageWrite_24C(0x2830,sz1,16);    
                I2C_ReadS_24C(0x2B40,sz1,16);                
		I2C_PageWrite_24C(0x2840,sz1,16);   
                I2C_ReadS_24C(0x2B50,sz1,16);                
		I2C_PageWrite_24C(0x2850,sz1,16);    
                I2C_ReadS_24C(0x2B60,sz1,16);                
		I2C_PageWrite_24C(0x2860,sz1,16);   
                I2C_ReadS_24C(0x2B70,sz1,16);                
		I2C_PageWrite_24C(0x2870,sz1,16);     
                I2C_ReadS_24C(0x2B80,sz1,16);                
		I2C_PageWrite_24C(0x2880,sz1,16);   
                I2C_ReadS_24C(0x2B90,sz1,16);                
		I2C_PageWrite_24C(0x2890,sz1,16);    
                I2C_ReadS_24C(0x2BA0,sz1,16);                
		I2C_PageWrite_24C(0x28A0,sz1,16);   
                I2C_ReadS_24C(0x2BB0,sz1,16);                
		I2C_PageWrite_24C(0x28B0,sz1,16);   
                I2C_ReadS_24C(0x2BC0,sz1,16);                
		I2C_PageWrite_24C(0x28C0,sz1,16);   
                I2C_ReadS_24C(0x2BD0,sz1,16);                
		I2C_PageWrite_24C(0x28D0,sz1,16);     
                I2C_ReadS_24C(0x2BE0,sz1,16);                
		I2C_PageWrite_24C(0x28E0,sz1,16);   
                I2C_ReadS_24C(0x2BF0,sz1,16);                
		I2C_PageWrite_24C(0x28F0,sz1,16);    
                I2C_ReadS_24C(0x2C00,sz1,16);                
		I2C_PageWrite_24C(0x2900,sz1,16);   
                I2C_ReadS_24C(0x2C10,sz1,16);                
		I2C_PageWrite_24C(0x2910,sz1,16);     
                I2C_ReadS_24C(0x2C20,sz1,16);                
		I2C_PageWrite_24C(0x2920,sz1,16);   
                I2C_ReadS_24C(0x2C30,sz1,16);                
		I2C_PageWrite_24C(0x2930,sz1,16);    
                I2C_ReadS_24C(0x2C40,sz1,16);                
		I2C_PageWrite_24C(0x2940,sz1,16);   
                I2C_ReadS_24C(0x2C50,sz1,16);                
		I2C_PageWrite_24C(0x2950,sz1,16);   */ 
/*                I2C_ReadS_24C(0x5160,sz1,16);                
		I2C_PageWrite_24C(0x4160,sz1,16);   
                I2C_ReadS_24C(0x5170,sz1,16);                
		I2C_PageWrite_24C(0x4170,sz1,16);     
                I2C_ReadS_24C(0x5180,sz1,16);                
		I2C_PageWrite_24C(0x4180,sz1,16);   
                I2C_ReadS_24C(0x5190,sz1,16);                
		I2C_PageWrite_24C(0x4190,sz1,16);    
                I2C_ReadS_24C(0x51A0,sz1,16);                
		I2C_PageWrite_24C(0x41A0,sz1,16);   
                I2C_ReadS_24C(0x51B0,sz1,16);                
		I2C_PageWrite_24C(0x41B0,sz1,16);   
                I2C_ReadS_24C(0x51C0,sz1,16);                
		I2C_PageWrite_24C(0x41C0,sz1,16);   
                I2C_ReadS_24C(0x51D0,sz1,16);                
		I2C_PageWrite_24C(0x41D0,sz1,16);     
                I2C_ReadS_24C(0x51E0,sz1,16);                
		I2C_PageWrite_24C(0x41E0,sz1,16);   
                I2C_ReadS_24C(0x51F0,sz1,16);                
		I2C_PageWrite_24C(0x41F0,sz1,16);   */ 
        //        I2C_ReadS_24C(Newip,sz1,1);
        //        l=sz1[0];
/////////////////////////////////////////////////////////////////////////////
                memreplace(0x2D00,0x2A00,16); 
                memreplace(0x2D10,0x2A10,16); 
                memreplace(0x2D20,0x2A20,16); 
                memreplace(0x2D30,0x2A30,16);  
                memreplace(0x2D40,0x2A40,16); 
                memreplace(0x2D50,0x2A50,16);               
/////////////////////////////////////////////////////////////////////////////                
   /*             I2C_ReadS_24C(0x2D00,sz1,16);                
		I2C_PageWrite_24C(0x2A00,sz1,16);
                I2C_ReadS_24C(0x2D10,sz1,16);                
		I2C_PageWrite_24C(0x2A10,sz1,16);
                I2C_ReadS_24C(0x2D20,sz1,16);                
		I2C_PageWrite_24C(0x2A20,sz1,16);
                I2C_ReadS_24C(0x2D30,sz1,16);                
		I2C_PageWrite_24C(0x2A30,sz1,16); 
                I2C_ReadS_24C(0x2D40,sz1,16);                
		I2C_PageWrite_24C(0x2A40,sz1,16);
                I2C_ReadS_24C(0x2D50,sz1,16);                
		I2C_PageWrite_24C(0x2A50,sz1,16);   */              
/////////////////////////////////////////////////////////////////////////////////                
                sz1[0]=0xFF;
                sz1[1]=0xFF;
                sz1[2]=0xFF;
                sz1[3]=0xFF;
                sz1[4]=0xFF;
                sz1[5]=0xFF;
                I2C_WriteS_24C(BAC_D_Ratestime,sz1,5);
                }
                }
}
//////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
void NewLcd(void)
{
//  unsigned char l;
    unsigned long  f_address0,f_address1;
                I2C_ReadS_24C(NewLcdtime,sz1,5);
                if((sz1[0]==0xFF)&&(sz1[1]==0xFF)&&(sz1[2]==0xFF)&&(sz1[3]==0xFF)&&(sz1[4]==0xFF))
                {
                }
                else
                {
////////////////////////////////////////////////////////////////////////////////////                                                        
		if(sz1[3]>0x12)
		return;
		if(sz1[2]>0x31)
		return;
		if(sz1[1]>0x23)
		return;
		if(sz1[0]>0x59)
                return;                  
////////////////////////////////////////////////////////////////////////////////////                   
                if(mathdata(sz1,time)<=1)
                {
        //        I2C_ReadS_24C(Newip,sz1,1);
        //        l=sz1[0];
                 f_address0=0x5000;
                 f_address1=0x3000;
 //                while(f_address0<=0x5F10)
                 while(f_address0<=0x6400)                 
                 {
                memreplace(f_address0,f_address1,16);                   
/*                I2C_ReadS_24C(f_address0,sz1,16);                
		I2C_PageWrite_24C(f_address1,sz1,16);*/
                f_address0+=16;
                f_address1+=16;                
                 }
                 f_address0=0x7500;
                 f_address1=0x6500;
                 while(f_address0<=0x7FF0)
                 {
                memreplace(f_address0,f_address1,16);                    
 /*               I2C_ReadS_24C(f_address0,sz1,16);                
		I2C_PageWrite_24C(f_address1,sz1,16);*/
                f_address0+=16;
                f_address1+=16;                
                 }                 
/*                I2C_ReadS_24C(0x5160,sz1,16);                
		I2C_PageWrite_24C(0x4160,sz1,16);   
                I2C_ReadS_24C(0x5170,sz1,16);                
		I2C_PageWrite_24C(0x4170,sz1,16);     
                I2C_ReadS_24C(0x5180,sz1,16);                
		I2C_PageWrite_24C(0x4180,sz1,16);   
                I2C_ReadS_24C(0x5190,sz1,16);                
		I2C_PageWrite_24C(0x4190,sz1,16);    
                I2C_ReadS_24C(0x51A0,sz1,16);                
		I2C_PageWrite_24C(0x41A0,sz1,16);   
                I2C_ReadS_24C(0x51B0,sz1,16);                
		I2C_PageWrite_24C(0x41B0,sz1,16);   
                I2C_ReadS_24C(0x51C0,sz1,16);                
		I2C_PageWrite_24C(0x41C0,sz1,16);   
                I2C_ReadS_24C(0x51D0,sz1,16);                
		I2C_PageWrite_24C(0x41D0,sz1,16);     
                I2C_ReadS_24C(0x51E0,sz1,16);                
		I2C_PageWrite_24C(0x41E0,sz1,16);   
                I2C_ReadS_24C(0x51F0,sz1,16);                
		I2C_PageWrite_24C(0x41F0,sz1,16);   */              
/////////////////////////////////////////////////////////////////////////////////                
                sz1[0]=0xFF;
                sz1[1]=0xFF;
                sz1[2]=0xFF;
                sz1[3]=0xFF;
                sz1[4]=0xFF;
                sz1[5]=0xFF;
                I2C_WriteS_24C(NewLcdtime,sz1,5);
                }
                }
}
//////////////////////////////////////////////////////////////////////////////////
 /*               nowstate=0;
                for(kkk=0;kkk<20;kkk++)
                {
                 if(buf5[kkk]!=buf[kkk])
                 {
                 nowstate=1;
                 break;
                 }
                }  */
void generatewarm(unsigned char nowstate,unsigned long IDState_add,unsigned char IDFullFault,unsigned char IDFullRepairOK)
{
             unsigned char Flashm[2];
		I2C_ReadS_24C(IDState_add, Flashm ,1);	
		if(Flashm[0])
			Flashm[0] = Device_AM;
		else
			Flashm[0] = Device_OK; 
		if(nowstate==1)
		{
                  if(Flashm[0] == Device_OK)
                  {
                    //����Ӳ���������ͱ�����¼
                    fault_record(IDFullFault);
                    Flashm[0] = Device_AM;
                    I2C_WriteS_24C(IDState_add, Flashm,1);	
                  }
		}
                else
                {
                  if(Flashm[0] == Device_AM)
                  {
                  //����Ӳ����������
	           fault_record(IDFullRepairOK);
		   Flashm[0] = Device_OK;                  
	           I2C_WriteS_24C(IDState_add, Flashm,1);
                  }
                }
}
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////



///////////////////////////////////////////////////////////////////////////////////////////////
/*
void disp_oldutime1(unsigned char bn)
{
   unsigned char sz2[8];
   unsigned int u1time1,u1time2;
//   unsigned long umoneytemp,BaseFeetemp,BaseTimetemp;
   u8 disp = 1;

    GetCurrentTime();
	
    switch(bn)
		{
		case 0x10: 
			I2C_ReadS_24C(ltime,sz1,8);
			break;
		case 0x20: 
			I2C_ReadS_24C(lltime,sz1,8);
                        break;
		case 0x30:
			I2C_ReadS_24C(rtime,sz1,8);
			break;
		case 0x40: 
			I2C_ReadS_24C(rrtime,sz1,8);
			break;
		default: 
			disp = 0;			
			break;
		}
	
	if(disp)
		{
		sz2[4]=sz1[1];
		sz2[3]=sz1[2];
		sz2[2]=sz1[3];
		sz2[1]=sz1[4];
		sz2[0]=sz1[5];
		u1time2=mathtime(sz2);
		u1time1=sz1[6];
		u1time1=u1time1<<8;
		u1time1=u1time1+sz1[7];
		if(u1time1>=u1time2)
			u1time1=u1time1-u1time2;
		else
			u1time1=0;
                 goto_xy(0,0);
                CT_fb_on_gb_off(); 
      //           print_str_16_16("Time left");
                LoadMenuLcd(2,1);
	        print_asi(0x1A);	                 
	        if(u1time1/6000)
		print_asi111(name4[3],u1time1/6000%10);	
	        print_asi111(name4[3],u1time1/600%10);
	        print_asi111(name4[3],u1time1/60%10);
	        print_asi111(name4[3],0x1A);	
	        print_asi111(name4[3],u1time1/10%6);
	        print_asi111(name4[3],u1time1%10);	
                CT_fb_off_gb_off();
		zimo=0;		
		}
	return;
}
*/
void memreplace(u16 source_addr,u16 aim_addr,u16 translength)
{
  unsigned char sz55[64];
        I2C_ReadS_24C(source_addr,sz55,translength); 
        if(sz55[0]==0xFF)
        return;
	I2C_PageWrite_24C(aim_addr,sz55,translength);
        sz55[0]=0xFF;
        I2C_WriteS_24C(source_addr,sz55,1);
}