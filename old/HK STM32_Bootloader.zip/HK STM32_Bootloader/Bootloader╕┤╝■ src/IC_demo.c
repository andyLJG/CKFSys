#include <stdio.h>

#include "IC_demo.h"
#include "Smart_card.h"
#include "Do_Task.h"
#include "hardware_test.h"
#include "Gprs_online.h"

//#define DD_DEBUG

//#define BUG_DISPLAY

#define TWO_CAR

#ifdef TWO_CAR
  #define CAR
  #define CAR_CLASS 4
#else
  #define CAR_CLASS 0
#endif

#define MATERVERSION 4//�������İ汾��

#define INIT_FLAG 0x38
//#define TEST_PSAM
#define QUIT_TIME   0 //��ʾ��ʱ�� ���� ���˶�ú�����
#define WAITE_TIME  3

u8 frist_key_flag;
u8 second_key_flag;
u8 Sec_key_flag;
u8 Fri_key_flag;

unsigned char time[7],time1[7],time10[7];
uchar IP[16];
uchar PORT[5];

extern uchar HZ[];
extern uchar bigHZ[];  
extern void PWR_EnterSLEEPMode(u32 SysCtrl_Set, u8 PWR_SLEEPEntry);
extern void GPIO_Configuration(void);

ErrorStatus HSEStartUpStatus;

void IC_demo(void)
{
    key_flag=0;
    uchar buffer[112];
    carStation_reference_of_used CS_RF_US;    
    uchar BCC;
    uchar read_mech_ID_flag;
    uchar read_PSAM_flag;
    uchar CommunicationFlag;
    u8 LowVoltage;    
    long timeOut = 0;
    uchar Mater_Buf[3];
    uchar block1_buffer[32];       
    uchar flag_buffer[16];
   
    ChipHalInit();			//Ƭ��Ӳ����ʼ��
    LCD_POWER_ON;   //PG13
    LCD_back_ON;    //PB13
    Buzz_1;   //PA1   
    ChipOutHalInit();		//Ƭ��Ӳ����ʼ��
    HC244Wake_Close;
  
    NVIC_Configuration();         //NVICǶ��ʽ�жϹ���ϵͳ�ĳ�ʼ��open interrupt  
    LCD_INIT();
    IWDG_ReloadCounter();	
    
    /* Enable PWR and BKP clock */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
       
    lcd_clear(); 

    while(timeOut < 4)
    {
         I2C_ReadS_24C(initialize_EEPROM,buffer,16);
            
         if(buffer[0] == INIT_FLAG && buffer[1] == INIT_FLAG && buffer[3] == INIT_FLAG && buffer[0] == INIT_FLAG && buffer[3] == INIT_FLAG && buffer[8] == INIT_FLAG)
            break;
         timeOut++;
    }


    if(timeOut >= 4)
    {
        ///////////////��ʾ ϵͳ��ʼ�� /////////////////////////////
        display_sysytem_init();       
        ////////////////////////////////////////////////////////////
            
        /////////////////�ص�///////////////
        LED1_OFF;
        LED2_OFF;
        LED3_OFF;
        LED4_OFF;
        ////////////////////////////////////       
        
        ////////////////�������λ״̬��Ϣ//////////////////////
        for(int i=0;i<16;i++)
          buffer[i] = 0x00;
        /*
        I2C_WriteS_24C(car1_used_reference_info,buffer,16);//��λ��Ϣ
        I2C_WriteS_24C(car2_used_reference_info,buffer,16);
        I2C_WriteS_24C(car3_used_reference_info,buffer,16);
        I2C_WriteS_24C(car4_used_reference_info,buffer,16);
        
        I2C_WriteS_24C(car1_no_S_flag,buffer,4);
        I2C_WriteS_24C(car2_no_S_flag,buffer,4);
        I2C_WriteS_24C(car3_no_S_flag,buffer,4);
        I2C_WriteS_24C(car4_no_S_flag,buffer,4);
        
        I2C_WriteS_24C(car1_smartCard_momenry,buffer,4); //��λ���
        I2C_WriteS_24C(car2_smartCard_momenry,buffer,4);
        I2C_WriteS_24C(car3_smartCard_momenry,buffer,4);
        I2C_WriteS_24C(car4_smartCard_momenry,buffer,4);
        */
        ////////////////////////////////////////////////////////
      
        
        ///////////////// FLASH���� ��ʼ����������ַ������/////////////////////////////
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count,buffer,4); //��ʼ��ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x0C;
        buffer[2] = 0x35;
        buffer[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count + 4,buffer,4); //������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count + 8,buffer,4); //����������
        ///////////////////////////////////////////////////////////////////////////////
        
        
        ///////////////////////////��ʼ�� EEPROM��ַ/////////////////////////////////// ���û��ʹ��
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        I2C_WriteS_24C(EEPROM_last_time_down_addr,buffer,2); //EEPROM �ϴ����ص�ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        I2C_WriteS_24C(addr_of_current_in_EEPROM,buffer,2); //EEPROM ��¼�洢��ǰ��ַ
        ///////////////////////////////////////////////////////////////////////////////
        
        
        /////////////////////////////////FLASH ��ʼ�� ///////////////////////////////// ���ûʹ��
        buffer[0] = 0x00;
        I2C_WriteS_24C(full_of_FLASH_flag,buffer,1); //FLASH ������־
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        I2C_WriteS_24C(clear_4K_of_FLASH_addr,buffer,3); //FLASH 4K������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        I2C_WriteS_24C(FLASH_last_time_down_addr,buffer,3); //FLASH ��¼�ϴ����ص�ַ
        buffer[2] = 0x00;
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        I2C_WriteS_24C(addr_of_current_in_FLASH,buffer,3); //FLASH ��¼�洢��ǰ��ַ       
        ///////////////////////////////////////////////////////////////////////////////                 
        
        ///////////////////////////////������//////////////////////////////////////////
        buffer[0] = 0x08;
        buffer[1] = 0x00;
        buffer[2] = 0x23;
        buffer[3] = 0x00;
        buffer[4] = 100;
        buffer[5] = 15;
        buffer[6] = 0x60;
        buffer[7] = 3;
        buffer[8] = 0x15;
        buffer[9] = 0;
        buffer[10] = 0x24;
            
        BCC = 0x00;
        for(uchar i=0;i<11;i++)
          BCC = BCC ^ buffer[i];
        buffer[11] = BCC;
            
        I2C_WriteS_24C(B_startTime_unit_of_hour,buffer,12);
        I2C_WriteS_24C(back_argument_of_charge,buffer,12);
        ///////////////////////////////////////////////////////////////////////////////
        
        
        //////////////////////////////�ݴ泵λ����/////////////////////////////////////
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(car1_number_temporal,buffer,4);//�ݴ�1�ų�λ���� д������ʱ
        I2C_WriteS_24C(car2_number_temporal,buffer,4);
        I2C_WriteS_24C(car3_number_temporal,buffer,4);
        I2C_WriteS_24C(car4_number_temporal,buffer,4);
        ///////////////////////////////////////////////////////////////////////////////
        
        
        ///////////////////////��������ļ�¼����///////////////////////////////////////
        buffer[0] = 0x17;
        buffer[1] = 0xE0;
        I2C_WriteS_24C(Con_Fm_Record_112_Start_Addr,buffer,2);//��ʼ��ַ  112
        I2C_WriteS_24C(Con_Fm_Record_112_Cursor,buffer,2);//���¼��ַ�α�
        I2C_WriteS_24C(Con_Fm_Record_112_UDCSR,buffer,2);//GPRS ���ؼ�¼��ַ�α�
        I2C_WriteS_24C(Con_Fm_Record_112_UDCSR_P,buffer,2);//POS�� ���ؼ�¼��ַ�α�
        
        buffer[0] = 0x59;
        buffer[1] = 0x80;
        I2C_WriteS_24C(Con_Fm_Record_112_End_Addr,buffer,2);//������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        I2C_WriteS_24C(Con_Fm_Record_112_Count,buffer,2);//����
        I2C_WriteS_24C(Con_Fm_Record_112_Cursor_F,buffer,1);//�α�Խ���ı�־λ
        
        
        buffer[0] = 0x5A;
        buffer[1] = 0x00;
        I2C_WriteS_24C(Con_Fm_Record_16_Start_Addr,buffer,2);//��ʼ��ַ  16
        I2C_WriteS_24C(Con_Fm_Record_16_Cursor,buffer,2);//���¼��ַ�α�
        I2C_WriteS_24C(Con_Fm_Record_16_UDCSR,buffer,2);//GPRS ���ؼ�¼��ַ�α�
        I2C_WriteS_24C(Con_Fm_Record_16_UDCSR_P,buffer,2);//POS�� ���ؼ�¼��ַ�α�
        
        buffer[0] = 0x7F;
        buffer[1] = 0x80;
        I2C_WriteS_24C(Con_Fm_Record_16_End_Addr,buffer,2);//������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        I2C_WriteS_24C(Con_Fm_Record_16_Count,buffer,2);//����
        I2C_WriteS_24C(Con_Fm_Record_16_Cursor_F,buffer,1);//�α�Խ���ı�־λ
        ////////////////////////////////////////////////////////////////////////////////
        
        
        ///////////////////////FLASH����ļ�¼����//////////////////////////////////////
        buffer[0] = 0x0D;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        I2C_WriteS_24C(Con_Flash_Record_16_Start_Addr,buffer,3);//��ʼ��ַ  32
        I2C_WriteS_24C(Con_Flash_Record_16_Cursor,buffer,3);//���¼��ַ�α�
        I2C_WriteS_24C(Con_Flash_Record_16_UDCSR,buffer,3);//���ؼ�¼��ַ�α�
        I2C_WriteS_24C(Con_Flash_Record_16_UDCSR_P,buffer,3);//POS ���ؼ�¼��ַ�α�
        
        buffer[0] = 0x19;
        buffer[1] = 0x35;
        buffer[2] = 0x00;
        I2C_WriteS_24C(Con_Flash_Record_16_End_Addr,buffer,3);//������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        I2C_WriteS_24C(Con_Flash_Record_16_Count,buffer,3);//����
        I2C_WriteS_24C(Con_Flash_Record_16_Cursor_F,buffer,1);//�α�Խ���ı�־λ
        
        
        
        buffer[0] = 0x1A;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        I2C_WriteS_24C(Con_Flash_Record_112_Start_Addr,buffer,3);//��ʼ��ַ  16
        I2C_WriteS_24C(Con_Flash_Record_112_Cursor,buffer,3);//���¼��ַ�α�
        I2C_WriteS_24C(Con_Flash_Record_112_UDCSR,buffer,3);//���ؼ�¼��ַ�α�
        I2C_WriteS_24C(Con_Flash_Record_112_UDCSR_P,buffer,3);//POS ���ؼ�¼��ַ�α�
        
        buffer[0] = 0x6F;
        buffer[1] = 0x73;
        buffer[2] = 0x00;
        I2C_WriteS_24C(Con_Flash_Record_112_End_Addr,buffer,3);//������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        I2C_WriteS_24C(Con_Flash_Record_112_Count,buffer,3);//����
        I2C_WriteS_24C(Con_Flash_Record_112_Cursor_F,buffer,1);//�α�Խ���ı�־λ
        ////////////////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////δ������¼��ʼ��/////////////////////////////////
        for(uchar i=0;i<8;i++)
          buffer[i] = 0x00;
        I2C_WriteS_24C(car1_false_record,buffer,8);
        I2C_WriteS_24C(car2_false_record,buffer,8);
        I2C_WriteS_24C(car3_false_record,buffer,8);
        I2C_WriteS_24C(car4_false_record,buffer,8);
        ////////////////////////////////////////////////////////////////////////////////
        
        
        ////////////////////////////��Կ��ʼ��//////////////////////////////////
	buffer[0]=0x13;
	buffer[1]=0x30;
	buffer[2]=0x10;
	buffer[3]=0x50;
	buffer[4]=0x09;
	buffer[5]=0x31;
        buffer[6] = buffer[0] ^ buffer[1] ^ buffer[2] ^ buffer[3] ^ buffer[4] ^ buffer[5];
	I2C_WriteS_24C(sysytem_public_key,buffer,7);  //���ܺ����в�������
        I2C_WriteS_24C(sysytem_public_key_back,buffer,7);  //���ܺ����в�������
        for(uchar i =0;i< 7;i++)
            buffer[i] = 0x00;
        I2C_ReadS_24C(sysytem_public_key,buffer,7);  //���ܺ����в�������
        
        ////////////////////////////////////////////////////////////////////////
        
        /////////////////////////////IP��ַ�Ͷ˿ں�/////////////////////////////
        for(uchar i=0;i<6;i++)                                      
          buffer[i] = 0x00;
        I2C_WriteS_24C(PSAM_ADRee,buffer,6);//��pasm��
        
        buffer[0] = 120;
        buffer[1] = 196;
        buffer[2] = 136;
        buffer[3] = 170;
        buffer[4] = 0x80;
        buffer[5] = 0x40;
        I2C_WriteS_24C(IPADrees,buffer,6);//��IP��
        ////////////////////////////////////////////////////////////////////////
        
        //////////////////////////////δ������¼////////////////////////////////
        for(uchar i=0;i<112;i++)                                      
          buffer[i] = 0x00;
        
        I2C_WriteS_24C(car1_false_record,buffer,112);
        I2C_WriteS_24C(car2_false_record,buffer,112);
        I2C_WriteS_24C(car3_false_record,buffer,112);
        I2C_WriteS_24C(car4_false_record,buffer,112);
        ////////////////////////////////////////////////////////////////////////
        
        ///////////////////////////���� �������ĳ�ʼ��/////////////////////////  30000��
        buffer[0] = 0x00;
        buffer[1] = 0x70;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count_day,buffer,4);//������������ �׵�ַ
        I2C_WriteS_24C(BackList_Cursor_day,buffer,4);//������������ �α��ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x73;
        buffer[2] = 0xA9;
        buffer[3] = 0x80;
        I2C_WriteS_24C(backList_Addr_and_Count_day + 4,buffer,4);//������������ ������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count_day + 8,buffer,4); //���������� ����   
        
        buffer[0] = 0x00;
        buffer[1] = 0x0C;
        buffer[2] = 0x40;
        buffer[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count_day + 12,buffer,4); //���������� �ڴ濪ʼ��ŵĵ�ַ
        ///////////////////////////////////////////////////////////////////////
        
        
        ///////////////////////////���� �������ĳ�ʼ��///////////////////////// 10960��
        buffer[0] = 0x00;
        buffer[1] = 0x73;
        buffer[2] = 0xA9;
        buffer[3] = 0x80;
        I2C_WriteS_24C(backList_Addr_and_Count_day_reduce,buffer,4);//������������ �׵�ַ
        I2C_WriteS_24C(BackList_Cursor_day_reduce,buffer,4);//������������ �α��ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x75;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count_day_reduce + 4,buffer,4);//������������ ������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count_day_reduce + 8,buffer,4); //���������� ����   
        
        buffer[0] = 0x00;
        buffer[1] = 0x10;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(backList_Addr_and_Count_day_reduce + 12,buffer,4); //���������� �ڴ濪ʼ��ŵĵ�ַ 
        ///////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////////////////////////////////////////////
        buffer[0] = 0x00;
        I2C_WriteS_24C((car1_value_comd),buffer,1);
        I2C_WriteS_24C((car2_value_comd),buffer,1);
        I2C_WriteS_24C((car3_value_comd),buffer,1);
        I2C_WriteS_24C((car4_value_comd),buffer,1);
        
        I2C_WriteS_24C((car1_write_comd),buffer,1);
        I2C_WriteS_24C((car2_write_comd),buffer,1);
        I2C_WriteS_24C((car3_write_comd),buffer,1);
        I2C_WriteS_24C((car4_write_comd),buffer,1);
        ///////////////////////////////////////////////////////////////////////
        
        //////////////////////��� �ͣɣƣ��ңſ���ˢ��ʧ��ʱ��������Ϣ////////
        for(uchar i=0;i<16;i++)
          buffer[i] = 0x00;
        for(uchar car=1;car<=4;car++)
          save_mifare_NO(buffer,buffer,car);
        ///////////////////////////////////////////////////////////////////////
        
        ///////////////////////��� ����Flash�ı��////////////////////////////
        buffer[0] = 0x00;
        I2C_WriteS_24C(Flash_erased_sector_32_F,buffer,1);//�� ������ַ���α� ��־
        I2C_WriteS_24C(Flash_erased_sector_112_F,buffer,1);
        
        buffer[0] = 0x66;
        I2C_WriteS_24C(Flash_erased_sector_32_L,buffer,1);//�� ������ַ���α� ��־
        I2C_WriteS_24C(Flash_erased_sector_112_L,buffer,1);
        ///////////////////////////////////////////////////////////////////////
                              
        I2C_WriteS_24C(LOW_VOLTAGE_F,buffer,1);//�͵�ѹ������¼ ���� ��1����д�ص�ַ��ȥ
        
        /////////////////////����ʱ������///////////////////////////////////////
        buffer[0] = 0x17;
        buffer[1] = 0x00;
        buffer[2] = 0x06;
        buffer[3] = 0x00;
        I2C_WriteS_24C(BACK_TIME,buffer,4);//���������ʱ��
        ////////////////////////////////////////////////////////////////////////
        
        /////////////////////////////
        for(uchar i=1;i<=4;i++)
          WriteRecover(i,0);
        /////////////////////////////
        
        /////////////////////��¼���ͻ��Ƶ� ����////////////////////////////////
        buffer[0] = 4;
        buffer[1] = 10;
        buffer[2] = 4;
        buffer[3] = 2;
        buffer[4] = 4;
        I2C_WriteS_24C(SendInterval,buffer,5);
        ////////////////////////////////////////////////////////////////////////
               
        //////////////////////////����ͨ ������������ �ϵ����//////////////////////////////
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        I2C_WriteS_24C(RequitPageCount,buffer,2);//ȫ��
        I2C_WriteS_24C(BackListAllCount,buffer,2);
        
        I2C_WriteS_24C(LNT_BACLK_RequitPage_DAY,buffer,2);//����
        I2C_WriteS_24C(LNT_BACLKALLCount_DAY,buffer,2);
        
        I2C_WriteS_24C(LNT_BACLK_RequitPage_Reduce,buffer,2);//����
        I2C_WriteS_24C(LNT_BACLK_ALLCount_Reduce,buffer,2);
        ////////////////////////////////////////////////////////////////////////
        
        //////////////////////////�Է��� ����ʱ �ݴ�����////////////////////////
        buffer[0] = 0x00;                                                                      
        I2C_WriteS_24C(ReplenMoneryFlag,buffer,1);                                                                      
        I2C_WriteS_24C(ReplenBlockFlag,buffer,1);                                                                     
        for(uchar i=0;i<8;i++)                                                                     
          buffer[i] = 0;                                                                                                         
        I2C_WriteS_24C(ReplenishmentNo,buffer,8);                                                                    
        I2C_WriteS_24C(ReplenishmentMonery,buffer,4);
        ////////////////////////////////////////////////////////////////////////
        
        /////////////////////////////�Զ���λ ��ʱ ��¼/////////////////////////
        for(uchar i=0;i<32;i++)
          buffer[i] = 0x00;
        I2C_WriteS_24C(ResetCar1Flag,buffer,1);
        I2C_WriteS_24C(ResetCar2Flag,buffer,1);
        I2C_WriteS_24C(ResetCar3Flag,buffer,1);
        I2C_WriteS_24C(ResetCar4Flag,buffer,1);
        
        I2C_WriteS_24C(ResetRecordCar1,buffer,32);
        I2C_WriteS_24C(ResetRecordCar2,buffer,32);
        I2C_WriteS_24C(ResetRecordCar3,buffer,32);
        I2C_WriteS_24C(ResetRecordCar4,buffer,32);
        ////////////////////////////////////////////////////////////////////////
        
        /////////////////////////////�Է�����������ַ��ʼ��///////////////////// ÿ��4�ֽ�        
        //�Է��� ������������ 7000��
        buffer[0] = 0x00;
        buffer[1] = 0x0C;
        buffer[2] = 0x35;
        buffer[3] = 0x00;
        I2C_WriteS_24C(MIFARE_BACLK_DAY_ADD_AC,buffer,4); //��ʼ��ַ
        I2C_WriteS_24C(MIFARE_BACLK_Cursor_day,buffer,4);//������������ �α��ַ

        
        buffer[0] = 0x00;
        buffer[1] = 0x0C;
        buffer[2] = 0xA2;
        buffer[3] = 0x60;
        I2C_WriteS_24C(MIFARE_BACLK_DAY_ADD_AC + 4,buffer,4); //������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(MIFARE_BACLK_DAY_ADD_AC + 8,buffer,4); //����������
        I2C_WriteS_24C(MIFARE_BACLK_ALLCount_DAY ,buffer,2);
        I2C_WriteS_24C(MIFARE_BACLK_RequitPage_DAY ,buffer,2);
        
        //�Է��� �ռ��������� 5992��
        buffer[0] = 0x00;
        buffer[1] = 0x0C;
        buffer[2] = 0xA2;
        buffer[3] = 0x60;
        I2C_WriteS_24C(MIFARE_BACLK_DAY_REDUC_AC,buffer,4); //��ʼ��ַ
        I2C_WriteS_24C(MIFARE_BACLK_Cursor_day_reduce,buffer,4);//������������ �α��ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x0D;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(MIFARE_BACLK_DAY_REDUC_AC + 4,buffer,4); //������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(MIFARE_BACLK_DAY_REDUC_AC + 8,buffer,4); //����������
        I2C_WriteS_24C(MIFARE_BACLK_ALLCount_Reduce ,buffer,2);
        I2C_WriteS_24C(MIFARE_BACLK_RequitPage_Reduce ,buffer,2);
        
        ////////////////////////////////////////////////////////////////////////
        
        ///////////////////////������ ���ڴ�ĵ�ַ//////////////////////////////
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        
        I2C_WriteS_24C(LNT_BaclkMoneryAddrAll,buffer,4); 
        I2C_WriteS_24C(LNT_BaclkMoneryAddrDay_Add,buffer,4);
        I2C_WriteS_24C(LNT_BaclkMoneryAddrDay_Reduce,buffer,4);
        
        I2C_WriteS_24C(MIFARE_BaclkMoneryAddrDay_Add,buffer,4);
        I2C_WriteS_24C(MIFARE_BaclkMoneryAddrDay_Reduce,buffer,4);        
        ////////////////////////////////////////////////////////////////////////

        ///////////////////////����������� ��flash�ĳ�ʼ��/////////////////////
        buffer[0] = 0x00;
        buffer[1] = 0x75;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(UpdateProgramAddr,buffer,4);//����������� ��ʼ��ַ
        I2C_WriteS_24C(UpdateCoursor,buffer,4);//����������� �����α�
        
        buffer[0] = 0x00;
        buffer[1] = 0x7D;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(UpdateProgramAddr + 4,buffer,4);//����������� ������ַ
        
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        I2C_WriteS_24C(UpdateProgramAddr + 8,buffer,4);//����������� ����
        ////////////////////////////////////////////////////////////////////////
        SPI_FLASH_BulkErase();
        
        for(uchar i = 0;i< 16;i++)
          buffer[i] = INIT_FLAG;//д�� �Ѿ���ʼ���� �ı�־
        I2C_WriteS_24C(initialize_EEPROM,buffer,16);
    }
    else
    {
        ////////////////////////////�ϵ��ʼ��//////////////////////////////////
        LCD_POWER_ON;
        LCD_back_ON;
        Smart_Power_ON;
        open_gprs_power();
        GPRS_Power_ON;
        LED1_OFF;
        LED2_OFF;
        LED3_OFF;
        LED4_OFF;
        ////////////////////////////////////////////////////////////////////////
        DISABLE_EXTI15_10_IRQ();      
        DISABLE_EXTI9_5_IRQ();
        
        GetCurrentTime();  
        
        
        OPEN_EXTI9_5_IRQ();                                                                          
        OPEN_EXTI15_10_IRQ();
        
        
//#ifndef DD_DEBUG  
#if 1
        
        #ifdef TWO_CAR
        display_Logo_1(2);
        #else
        display_Logo_1(4);
        #endif       
        delay(KEYTIMEOUT_1S * 3);
        /*************************
        //1.���ȼ��        
        //2.LED���
        //3.��ѹ���
        //4.���������
        //5.PSAM�����
        //6.ͨ��ģ����
        *************************/
        lcd_clear();

        uchar clow;
        clow = 1;        
        
        //1.���ȼ��
        buzz_check(clow++);
        Buzz_0;
        delay(KEYTIMEOUT_1S * 1);
        Buzz_1;
        delay(KEYTIMEOUT_1S * 3);
        
        //2.LED���
        LED_check(clow++);
        LED1_ON;
        LED2_ON;
        LED3_ON;
        LED4_ON;
        delay(KEYTIMEOUT_1S * 4);
        LED1_OFF;
        LED2_OFF;
        LED3_OFF;
        LED4_OFF;
        
        //3.��ѹ���
        LowVoltage = LowVoltage_Test();
        Voltage_Check(LowVoltage,clow++);       
        delay(KEYTIMEOUT_1S * 3);
        
        
        //4.���������
        timeOut = 0;
        read_mech_ID_flag = NO;
        while(timeOut < 3)
        {
            if(read_mech_ID() == 0x00)
            {
                read_mech_ID_flag = OK;
                break;
            }
            
            timeOut++;
        }
        display_reader_P(read_mech_ID_flag,clow++);

        delay(KEYTIMEOUT_1S * 3);
        
        if(clow > 4)
        {
            clow = 0x01;
            lcd_clear();
            LED_check(clow++);
            Voltage_Check(LowVoltage,clow++);  
            display_reader_P(read_mech_ID_flag,clow++);
            
        }
        //5.PSAM�����
        timeOut = 0;
        read_PSAM_flag = NO;
        while(timeOut < 4)
        {
            if(read_PSAM() == 0x00)
            {
                read_PSAM_flag = OK;
                break;
            }
            
            timeOut++;
        }        
        display_PSAM(read_PSAM_flag,clow++);
       
        Smart_Power_OFF;
        delay(KEYTIMEOUT_1S * 3);
        
        
        if(clow > 4)
        {
            clow = 0x01;
            lcd_clear();
            Voltage_Check(LowVoltage,clow++);  
            display_reader_P(read_mech_ID_flag,clow++);
            display_PSAM(read_PSAM_flag,clow++);
            
        }
        //6.ͨ��ģ����
        //��ʾͨ��ģ������...
        Communation_check(clow);
        if(wake_flag)            
          wake_flag = 0;               
        IWDG_ReloadCounter();
        if(key_flag) 
          key_flag = 0;
        CommunicationFlag = open_gprs();
        Communation_OK(CommunicationFlag,clow);

        GPRS_Power_OFF;
        close_gprs_power();
        delay(KEYTIMEOUT_1S * 2);
#endif       
        display_logo();
        delay(KEYTIMEOUT_1S * 2);
        
     
        /////////////////////////�����������ڴ�/////////////////////////////////        
        //��FLASH �������� ��SROM
        read_Blacklist_to_Memory();        
        ////////////////////////////////////////////////////////////////////////   
        
        LowVoltage = LowVoltage_Test();
        if(LowVoltage != 0) 
        {
                uchar flag_buffer[16];
                I2C_ReadS_24C(LOW_VOLTAGE_F,flag_buffer,1);
                flag_buffer[0] = 0x00;
                I2C_WriteS_24C(LOW_VOLTAGE_F,flag_buffer,1);//�͵�ѹ������¼ ���� ��1����д�ص�ַ��ȥ
        } 
        
        /////////////////////////��ģ���Դ�ر�/////////////////////////////////
        Smart_Power_OFF;
        GPRS_Power_OFF;
        LCD_POWER_ON;
        LCD_back_OFF; 
        //////////////////////////////////////////////////////////////////////// 

        #ifdef TEST_PSAM  //���ԣУӣ��Ϳ����ϵ硡�µ�
        LED1_OFF;
        LED2_OFF;
        LED3_OFF;
        LED4_OFF;
        uchar flag;
        unsigned long BaseCount;
        uchar buffer[4];
        BaseCount = 0;
        while(1)
        {
              //3.��ѹ���
              LowVoltage = LowVoltage_Test();
              
              I2C_ReadS_24C(BackList_Cursor,buffer,4);                                              
              BaseCount = hcl(buffer,4);
              
              if(LowVoltage != 0) 
              {
                  Smart_Power_ON;
                  flag = Test_PSAM();
                  if(flag == 1)
                  {
                      BaseCount++;
                      fll(BaseCount,buffer,4);
                
                      I2C_WriteS_24C(BackList_Cursor,buffer,4);//д���������α��ַ
                  }
                    
                  
                  lcd_clear();
                  LCD_display_symbol(3,5,BaseCount/10000%10,0);
                  LCD_display_symbol(3,6,BaseCount/1000%10,0);
                  LCD_display_symbol(3,7,BaseCount/100%10,0);
                  LCD_display_symbol(3,8,BaseCount/10%10,0);
                  LCD_display_symbol(3,9,BaseCount%10,0);
                  Smart_Power_OFF;
              }
              else
              {
                  Voltage_Check(0);
              }
              delay(KEYTIMEOUT_1S * 10);
              
              
         }
         #endif
    }
    
    //д�� �������ʱ��
    GetCurrentTime(); 
    I2C_WriteS_24C(MaterRunTime,time,5);
    
    ////////////////////�������汾�ų�ʼ��////////////////////////////////
    buffer[0] = 0x01;
    buffer[1] = MATERVERSION;
    I2C_WriteS_24C(MATER_VER,buffer,2);
        
    #ifdef CAR
      buffer[0] = 0x02;
    #else
      buffer[0] = 0x04;
    #endif
    I2C_WriteS_24C(MATER_CAR,buffer,1);
    ////////////////////////////////////////////////////////////////////////
    
    
    
    
    
    /////////////////////////����λ״̬�ָ�/////////////////////////////////                
    for(uchar car=1;car<=4;car++)
    {
        I2C_ReadS_24C(0x10 * (car-1) ,buffer,1);
        if(buffer[0] == 0x66)
           light(car,OK);
        else
           light(car,NO);
    }
    ////////////////////////////////////////////////////////////////////////
    
    
        
        
    if(wake_flag)            
      wake_flag = 0;               
     
    if(key_flag)
      key_flag = 0;

    IWDG_ReloadCounter();
                 
    while(1){
      
      
        if(key_flag)
        {
           
           
            LowVoltage = LowVoltage_Test();          
            
            frist_key_flag = key_flag;
            second_key_flag = 0;
            
            Fri_key_flag = 1;
            Sec_key_flag = 0;
            key_flag = 0;            
            delay(KEYTIMEOUT_1S * 0.4);
            if(key_flag){
                frist_key_flag = 0;
                second_key_flag = key_flag;
                
                Fri_key_flag = 0;
                Sec_key_flag = 1;
            }
            key_flag = 0;
            
            sleepout1(); 
           
            if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����
              LCD_back_ON;
            else
              LCD_back_OFF;
            
            DISABLE_EXTI15_10_IRQ();      
            DISABLE_EXTI9_5_IRQ();
            
            GetCurrentTime(); 
            
            OPEN_EXTI9_5_IRQ();                                                                          
            OPEN_EXTI15_10_IRQ();
             
            
            if(LowVoltage == 1)
            {                        
              
              Smart_Power_ON;
              GPRS_Power_OFF;              
              if(frist_key_flag > 0 && Fri_key_flag == 1)
              {
                  Fri_key_flag = 0;
                switch(frist_key_flag){
                    
                    case K1:
                      #ifndef  CAR
                      quit_key_flag = card_station_check(1);  
                      #endif
                      break;
                    case K2:
                      quit_key_flag = card_station_check(2);
                      break;
                    case K3:
                      quit_key_flag = card_station_check(3);
                      break;
                    case K4:
                      #ifndef  CAR
                      quit_key_flag = card_station_check(4);
                      #endif
                      break;
                    default:break;
                }
                frist_key_flag = 0;
              }
              
              if(second_key_flag > 0 && Sec_key_flag == 1)
              {
                  Sec_key_flag = 0;
                  switch(second_key_flag){
                    
                    case K1:
                      #ifndef  CAR
                      quit_key_flag = read_IC_card_amount(1);
                      #endif
                      break;
                    case K2:
                      quit_key_flag = read_IC_card_amount(2);
                      break;
                    case K3:
                      quit_key_flag = read_IC_card_amount(3);
                      break;
                    case K4:
                      #ifndef  CAR
                      quit_key_flag = read_IC_card_amount(4);
                      #endif
                      break;
                    default:break;
                }
                second_key_flag = 0;
                
              }
              
              Smart_Power_OFF;
              if(quit_key_flag == 0x23)
              {
                
                  if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����
                    LCD_back_ON;
                  else
                    LCD_back_OFF;
                  write_card_error(0);
                  delay(KEYTIMEOUT_1S*2);
                  
              }
              else if(quit_key_flag == 0x99)
              {
                  if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����
                    LCD_back_ON;
                  else
                    LCD_back_OFF;
                  //������������
                  //display_reader_P(0);
                  uchar i;
                   i = 3;
                  dispaly(2,i++,(HZ + du));//��
                  dispaly(2,i++,(HZ + ka));
                  dispaly(2,i++,(HZ + qi_1));//��

                  dispaly(2,i++,(HZ + gu));
                  dispaly(2,i++,(HZ + zhang));
                                    
                  delay(KEYTIMEOUT_1S*2);
                  
                  
              }
              else if(quit_key_flag == 0x90)
              {
                  if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����
                    LCD_back_ON;
                  else
                    LCD_back_OFF;
                  //������������
                  //display_PSAM(0);
                  uchar i;
                  i = 5;
                  goto_xy(2,0x20);	
                  print_str_16_16("PSAM");
                  
                  dispaly(2,i++,(HZ + ka));
                                  
                  dispaly(2,i++,(HZ + gu));
                  dispaly(2,i++,(HZ + zhang));
                  delay(KEYTIMEOUT_1S*2);
              }
              else if(quit_key_flag == 0x73)
              {
                  if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����
                    LCD_back_ON;
                  else
                    LCD_back_OFF;
                  //������������
                  MoneryException();
                  delay(KEYTIMEOUT_1S*2);
              }
                
              Smart_Power_OFF;
              OPEN_EXTI9_5_IRQ();                                    
              OPEN_EXTI15_10_IRQ();  
              
                
            }
            else{
              
                voltage_flag=0;
                voltage_low();
                
                
                I2C_ReadS_24C(LOW_VOLTAGE_F,flag_buffer,1);
                if(flag_buffer[0] < 5)
                {
                       block1_buffer[0] = 0xEE;//��¼ͷ                                           
                       block1_buffer[1] = 0x00;                                           
                       block1_buffer[2] = 0x01; //��������                                          
                       block1_buffer[3] = 0x02; //��������                                        
                       block1_buffer[4] = 0x03; //��������                                        
                       block1_buffer[5] = 0x04; //��������                                      
                       block1_buffer[6] = 0x05;                                      
                       block1_buffer[7] = 0x06;                                     
                       block1_buffer[8] = 0x07;                                      
                       block1_buffer[9] = time[4];//��                                     
                       block1_buffer[10] = time[3];//��                                      
                       block1_buffer[11] = time[2];//��                                      
                       block1_buffer[12] = time[1];//ʱ                                    
                       block1_buffer[13] = time[0];//��                                     
                       block1_buffer[14] = 0x00;                                       
                       block1_buffer[15] = 0x00;                                     
                       block1_buffer[16] = 0x00;                                    
                       block1_buffer[17] = 0x00;                                    
                       block1_buffer[18] = 0x00;                                   
                       block1_buffer[19] = (2<<4) + 0x0F;//�͵�ѹ���� ��λΪ2 
                                              
                                              
                       block1_buffer[20] = time[4];                                           
                       block1_buffer[21] = time[3];                                            
                       block1_buffer[22] = time[2];                                            
                       block1_buffer[23] = time[1];                                            
                       block1_buffer[24] = time[0];
                                            
                       block1_buffer[25] = 0x01;                     
                       for(int i=26;i<32;i++)                                              
                         block1_buffer[i] = 0xAA;                    
                       Save_Record(block1_buffer,32);
                       
                       flag_buffer[0] = flag_buffer[0] + 1;
                       I2C_WriteS_24C(LOW_VOLTAGE_F,flag_buffer,1);//�͵�ѹ������¼ ���� ��1����д�ص�ַ��ȥ
                }
                delay(KEYTIMEOUT_1S*1);
            }
            
            if(key_flag)continue;
            
            lcd_clear();
            
            LCD_POWER_OFF;
            lcd_res_0;
            LCD_back_OFF; 
            key_flag = 0;
        }
        else if(wake_flag)
        {
            uchar SendHour;
            uchar SendMin;
            wake_flag = 0x00;
            sleepout1();                                  
            GetCurrentTime();  
            I2C_ReadS_24C(mibiao_number,Mater_Buf,3);//�����
            
            SendHour = (Mater_Buf[1] * 0x100 + Mater_Buf[2]) % 3;// 00:00 - 03:00
            SendMin = (Mater_Buf[1] * 0x100 + Mater_Buf[2]) % 60;// 00 - 59
            
            
            if(time[1] == 0x23 && time[0] == 0x00)
            {             
                uchar RequitPage[2];
                uchar BL_Count_buf[2];
                u16 backList_count;
                u16 AllBackListCount;
                
                //RequitUpdateProgram();
                
                I2C_ReadS_24C(Update_RequitPage,RequitPage,2);//�������
                I2C_ReadS_24C(Update_ALLCount,BL_Count_buf,2);
                
                backList_count = hcl(RequitPage,2);
                AllBackListCount = hcl(BL_Count_buf,2);
                 
                if(backList_count == (u16)AllBackListCount && backList_count != 0)
                {
                    if(BackupProgram() == SUCCESS)
                    {
                        GenerateSystemReset();
                    }
                    
                }
            }
            
            
            
            
            //�Է��� 1������ 23:45 �������� ����������
            if(time[1] == 0x23 && time[0] == 0x45)
            {
                //1.�Ȳ��� �Է������ڵ� FLASH
                if(time[2] == 0x01)
                {
                    InitMifareParameter();
                }                
                //2.�������� ���� ����������
                DownloadDayBaclkMIFARE();
            }
            
            //�Է��� 1������ 23:55 �������� ����������  ������
            if(time[1] == 0x23 && time[0] == 0x55)
            {               
                //2.�������� ���� ����������
                DownloadbackList_Residue(4);
                DownloadbackList_Residue(5);
            }
            
            //����ͨ ȫ������ ������
            if(time[2] == 0x01 && time1[1] == SendHour && time1[0] == SendMin)
            {     
#if 0
                if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����             
                  LCD_back_ON;           
                else              
                  LCD_back_OFF;
                                
                display_sysytem_Maintaining();//��ʾϵͳά���� ���Ժ�..
#endif
                Download_backList_All();
                read_Blacklist_to_Memory();               
            }
            
            //����ͨ ȫ������ ������(δ������ɵĲ���)
            if((time1[1] == (SendHour + 1) && time1[0] == SendMin) || (time[2] == 0x01 && time1[1] == (SendHour + 2) && time1[0] == SendMin))
            { 
#if 0
                if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����             
                  LCD_back_ON;           
                else              
                  LCD_back_OFF;
                                
                display_sysytem_Maintaining();//��ʾϵͳά���� ���Ժ�..
#endif
                DownloadbackList_Residue(1);
                read_Blacklist_to_Memory();               
            }
            
            //����ͨ ������ ��������
            if(time1[2] != 0x01 && time1[1] == SendHour && time1[0] == SendMin)
            {
                DownDayBackList();
                read_Blacklist_to_Memory(); 
            }
            
            //����ͨ ������ ��������(δ������ɵĲ���)
            if(time1[2] != 0x01 && time1[1] == (SendHour + 2) && time1[0] == SendMin)
            {
                DownloadbackList_Residue(2);
                DownloadbackList_Residue(3);
                read_Blacklist_to_Memory(); 
            }
            
            
            //ʱ�� �� ���ʲ������趨
            if(time[1] == 0x23 && time[0] == 0x30)
            {
#if 0
                if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����             
                  LCD_back_ON;           
                else              
                  LCD_back_OFF;                    
            
                display_sysytem_Maintaining();//��ʾϵͳά���� ���Ժ�..
#endif
                DownloadTimeAndFree();
            }                                       
            
            //���� ��flash ���в���
            if(time[1] == 0x04 && time[0] == 0x00)
            {
#if 0
                if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����             
                  LCD_back_ON;           
                else              
                  LCD_back_OFF;
                                
                display_sysytem_Maintaining();//��ʾϵͳά���� ���Ժ�..
#endif
                SendPage_Record();
                //���в���ǰ���Ѽ�¼�ȷ���
                if(ReturnRecordCount() == 0)
                {
                    //��ʾ FLASH������
                    FLASH_Erased();
                    Erased_sector();
                }
                    
                
                lcd_clear();
                LCD_back_OFF;
            }
            
            //����� PSAM����ʹ����� ������̨
            if(time[1] == 0x04 && time[0] == 0x30)
            {
#if 0
                if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����             
                  LCD_back_ON;           
                else              
                  LCD_back_OFF;
                
                display_sysytem_Maintaining();//��ʾϵͳά���� ���Ժ�..
#endif
                SendPSAM();
                
                lcd_clear();
                LCD_back_OFF;
            } 
                        
              
            for(int car = 1; car <= 4;car++)
            { 
                int min;
                read_car_reference_of_use_info(&CS_RF_US,car);//����λ״̬��Ϣ                
                min = CS_RF_US.max_stopTime_hour[0] * 60;
                min = min + CS_RF_US.max_stopTime_min[0];
                
                if(CS_RF_US.car_stop_way[0] != 0x00)
                {
             
                  //�������ж� ������ �����ͣ��ʱ��� �Զ���λ
                  if(ret_max_24hour(CS_RF_US.start_stopTime,SELECT) >= min)
                  {
                      for(int i=0;i<16;i++)
                          buffer[i] = 0;
                       write_car_reference_of_use_info(car,buffer,16);
                       
                       int max_stop_time;	                                
                       max_stop_time = ret_max_24hour(CS_RF_US.start_stopTime,PARK_CARD);
                       if(max_stop_time > 24 * 60)
                         max_stop_time = 24 * 60;
                       //�渴λ��¼
                          //������ж� ͣ�������¿� ���� ����ͨ��
                                                                 
                       block1_buffer[0] = 0xEE;//��¼ͷ                                           
                       block1_buffer[1] = CS_RF_US.smartCard_SNR[0];                                           
                       block1_buffer[2] = CS_RF_US.smartCard_SNR[1]; //��������                                          
                       block1_buffer[3] = CS_RF_US.smartCard_SNR[2]; //��������                                        
                       block1_buffer[4] = CS_RF_US.smartCard_SNR[3]; //��������                                        
                       block1_buffer[5] = CS_RF_US.smartCard_SNR[4]; //��������                                      
                       block1_buffer[6] = CS_RF_US.smartCard_SNR[5];                                      
                       block1_buffer[7] = CS_RF_US.smartCard_SNR[6];                                     
                       block1_buffer[8] = CS_RF_US.smartCard_SNR[7];                                      
                       block1_buffer[9] = time[4];//��                                     
                       block1_buffer[10] = CS_RF_US.start_stopTime[0];//��                                      
                       block1_buffer[11] = CS_RF_US.start_stopTime[1];//��                                      
                       block1_buffer[12] = CS_RF_US.start_stopTime[2];//ʱ                                    
                       block1_buffer[13] = CS_RF_US.start_stopTime[3];//��                                     
                       block1_buffer[14] = CS_RF_US.smartCard_momenry[1];                                       
                       block1_buffer[15] = CS_RF_US.smartCard_momenry[2];                                     
                       block1_buffer[16] = CS_RF_US.smartCard_momenry[3];                                    
                       block1_buffer[17] = 0x00;                                    
                       block1_buffer[18] = 0x00;                                   
                       block1_buffer[19] = ((car + CAR_CLASS)<<4) + 0x04;//�Զ���λ ��λΪcar 
                                              
                                              
                       block1_buffer[20] = time[4];                                           
                       block1_buffer[21] = time[3];                                            
                       block1_buffer[22] = time[2];                                            
                       block1_buffer[23] = time[1];                                            
                       block1_buffer[24] = time[0];
                                            
                       block1_buffer[25] = ReadRecord(car);//����ͨ��¼��־
                       
                       for(int i=26;i<32;i++)                                              
                         block1_buffer[i] = 0xAA;                    
                       Save_Record(block1_buffer,32);
                       
                       SaveResetRecord(block1_buffer,32,car);
                       //��λ����
                       light(car,NO);
                       
                       
                       #ifdef TWO_CAR     	                                 
                       resetCarstation_success(CS_RF_US.smartCard_SNR,CS_RF_US.start_stopTime,max_stop_time,car - 1); //��ʾ car��λ ��λ�ɹ�                                         
                       #else
                       resetCarstation_success(CS_RF_US.smartCard_SNR,CS_RF_US.start_stopTime,max_stop_time,car); //��ʾ car��λ ��λ�ɹ�
                       #endif
                       
                       OPEN_EXTI9_5_IRQ();                                                                          
                       OPEN_EXTI15_10_IRQ();
                       
                       timeOut = 0;                                             
	               while(timeOut < KEYTIMEOUT_1S * WAITE_TIME)                                              
	               {                                                
	                   if(key_flag){                                                 
	                         key_flag = 0; 
	                         delay(KEYTIMEOUT_1S * QUIT_TIME);
	                         break;                                                 
	                   }                                                
	                   timeOut++;                                               	                                          
                       }
                  }                
                }
                
            }
            lcd_clear(); 
            
            //��¼�ķ���
            RecordSendingMechanism();
          
            if(key_flag)continue;
        }
           
          
        lcd_clear();           
        LCD_POWER_OFF;
        lcd_res_0;           
        LCD_back_OFF;            
        
        Smart_Power_OFF;
        CONIN_Power_OFF;
        GPRS_Power_OFF;
        
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG, DISABLE);
        goto_sleep();
        //PWR_EnterSLEEPMode(PWR_Regulator_LowPower, PWR_SLEEPEntry_WFI);
        PWR_EnterSTOPMode(PWR_Regulator_LowPower, PWR_STOPEntry_WFI);
      /* Configures system clock after wake-up from STOP: enable HSE, PLL and select 
        PLL as system clock source (HSE and PLL are disabled in STOP mode) */
        SYSCLKConfig_STOP();
        open_usart();
  ///////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////      
        IWDG_ReloadCounter();
           
    }      

    
}
    
    


void goto_sleep(void)
{
   // ADC_InitTypeDef   ADC_InitStructure;
        GPIO_InitTypeDef  GPIO_InitStructure;
 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////          
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,  DISABLE);	
        
        Uart5_Close();
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, DISABLE); //�رմ���1ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, DISABLE); //�رմ���2ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, DISABLE); //�رմ���3ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,  DISABLE); //�رմ���4ʱ��  
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,  DISABLE); //�رմ���5ʱ��         
        
        SPI_Cmd(SPI_FLASH, DISABLE);
        RCC_APB2PeriphClockCmd(SPI_FLASH_CLK | SPI_FLASH_GPIO_CLK | SPI_FLASH_CS_GPIO_CLK, DISABLE);
        
        ADC_Cmd(ADC1,DISABLE);
        ADC_Cmd(ADC2,DISABLE);//ADC3
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, DISABLE);
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, DISABLE); 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        FSMC_SRAM_DISABLE(); 
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, DISABLE);
        
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
     	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;//��?3G??????
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOA, &GPIO_InitStructure); 
        
   
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
     	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;//��?3G??????
     	//GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_15;//��?3G??????
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOB, &GPIO_InitStructure);      
        
        
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;  //--LED|GPIO_Pin_4
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOC, &GPIO_InitStructure); 
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
        
        
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;////GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_3|-----LED
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOD, &GPIO_InitStructure); 
        GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14| GPIO_Pin_15;  //�Ѿ���Ϊ��ѹ�����
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOD, &GPIO_InitStructure); 
        
        
//////////////////////////////////////////////////////////////////////////////////////////////
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
     	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14 |GPIO_Pin_15;//|GPIO_Pin_13,GPIO_Pin_15��?3G??????
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOE, &GPIO_InitStructure);    
        
        
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        //////////////////////////////////////////////////////////////////////////////////////////////
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;///|GPIO_Pin_6|GPIO_Pin_7
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOF, &GPIO_InitStructure);
     	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;//GPIO_Pin_8|GPIO_Pin_9|
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOF, &GPIO_InitStructure);   
        
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOG, &GPIO_InitStructure);
     	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;//|GPIO_Pin_13,|GPIO_Pin_15
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOG, &GPIO_InitStructure);     
        
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, DISABLE);
	//RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, DISABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, DISABLE);	  
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,  DISABLE);	 
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////// 
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);//dis
        ADC_Cmd(ADC1, DISABLE);
        ADC_Cmd(ADC2, DISABLE);    
        RCC_APB1PeriphResetCmd(RCC_APB1Periph_DAC, ENABLE);//dis
        RCC_APB1PeriphResetCmd(RCC_APB1Periph_DAC, DISABLE);
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB 

                              | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD 

                              | RCC_APB2Periph_GPIOE | RCC_APB2Periph_GPIOF

                              | RCC_APB2Periph_GPIOG| RCC_APB2Periph_AFIO, ENABLE);//dis


  

  // Disable the Serial Wire Jtag Debug Port SWJ-DP

        GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, DISABLE); //dis 

        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;

        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;

        GPIO_Init(GPIOA, &GPIO_InitStructure); 
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_SRAM | RCC_AHBPeriph_FLITF, DISABLE);
    
    
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1 | RCC_AHBPeriph_DMA2 | RCC_AHBPeriph_CRC | RCC_AHBPeriph_SDIO, DISABLE);
        RCC_APB1PeriphResetCmd(RCC_APB1Periph_ALL, DISABLE);
        RCC_APB2PeriphResetCmd(RCC_APB2Periph_ALL, DISABLE);
}


void open_usart(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);//�򿪴���1ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);//�򿪴���2ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);//�򿪴���3ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,ENABLE);//�򿪴���4ʱ��  
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,ENABLE);//�򿪴���5ʱ�� 
}

void sleep_lcd(void)
{
 GPIO_InitTypeDef  GPIO_InitStructure;
 LCD_back_OFF;    
  //Delay(10000); 
 LCD_POWER_OFF; 
 GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_13;
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
 GPIO_Init(GPIOG, &GPIO_InitStructure);
}
void sleepout1(void)
{
    GPIO_Configuration();
    ChipOutHalInit1();
}
//////////////////////////////////////////////////////////////////////////////////
/*----------------------------------------------------------------------
function name:   	unsigned char LowVoltage_Test(void)
describe:    	 	�͵�ѹ��ⷵ��:0Ϊ�� 1Ϊ��
input:   			
output:
date:			andyluo 2010-12-03 14:26:57
------------------------------------------------------------------------*/
unsigned char LowVoltage_Test(void)
{
////////////////////////////////PD4---PB14///////////////////////////////////////////
  GPIO_InitTypeDef GPIO_InitStructure;
  uchar flag;
  /*����MAX884��Դ����������Back batter Ctrl */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;		//��������
	GPIO_Init(GPIOB, &GPIO_InitStructure);

  if((GPIO_ReadInputData(GPIOB)&0x4000)==0x0000)
    {
      Delay(100);
     if((GPIO_ReadInputData(GPIOB)&0x4000)==0x0000)
      {
	 	//fault_record(0x10);
		flag =0;
      }
     else
 	 flag =1;
    }
  else
 	 flag =1;
  
  return flag; 
  
}                                                 
         
///////////////////////////////////////////////////////////////////////////////////////

uchar count_Lcd_back()
{
    uchar Begin_Hour;
    uchar Begin_Min;
    uchar End_Hour;
    uchar End_Min;
    uchar buffer[4];
    
    
    //������һ�� Զ������ �����ʱ��
     
     I2C_ReadS_24C(BACK_TIME,buffer,4);//���������ʱ��
     GetCurrentTime();  
    
     Begin_Hour = buffer[0];
     Begin_Min = buffer[1];
     End_Hour = buffer[2];
     End_Min = buffer[3];
     
    if(time[1] > Begin_Hour || time[1] < End_Hour)
      return 1;
    else if(time[1] == Begin_Hour && time[0] >= Begin_Min)
      return 1;
    else if(time[1] == End_Hour && time[0] <= End_Min)
      return 1;
    else
      return 0;
}

void read_IP()
{
    uchar buffer[6];
    
    uchar hundred;
    uchar ten;
    uchar ge;
    
    uchar i = 0;
    I2C_ReadS_24C(IPADrees,buffer,6);//��IP��
    
    hundred = buffer[0] / 100;
    ten = buffer[0] / 10 % 10;
    ge = buffer[0] % 10;
    if(hundred > 0)
    {
        IP[i++] = hex_to_asic(hundred);
        IP[i++] = hex_to_asic(ten);
        
    }
    else if(ten > 0)
    {
        IP[i++] = hex_to_asic(ten);
    }
    else
    {}
    
    IP[i++] = hex_to_asic(ge);
        
    IP[i++] = 46;// .
    
    
    hundred = buffer[1] / 100;
    ten = buffer[1] / 10 % 10;
    ge = buffer[1] % 10;
    if(hundred > 0)
    {
        IP[i++] = hex_to_asic(hundred);
        IP[i++] = hex_to_asic(ten);
        
    }
    else if(ten > 0)
    {
        IP[i++] = hex_to_asic(ten);
    }
    else
    {}
    
    IP[i++] = hex_to_asic(ge);
        
    IP[i++] = 46;// .
    
    
    
    hundred = buffer[2] / 100;
    ten = buffer[2] / 10 % 10;
    ge = buffer[2] % 10;
    if(hundred > 0)
    {
        IP[i++] = hex_to_asic(hundred);
        IP[i++] = hex_to_asic(ten);
        
    }
    else if(ten > 0)
    {
        IP[i++] = hex_to_asic(ten);
    }
    else
    {}
    
    IP[i++] = hex_to_asic(ge);
        
    IP[i++] = 46;// .
    
    
    
    
    hundred = buffer[3] / 100;
    ten = buffer[3] / 10 % 10;
    ge = buffer[3] % 10;
    if(hundred > 0)
    {
        IP[i++] = hex_to_asic(hundred);
        IP[i++] = hex_to_asic(ten);
        
    }
    else if(ten > 0)
    {
        IP[i++] = hex_to_asic(ten);
    }
    else
    {}
    
    IP[i++] = hex_to_asic(ge);
    
    IP[i++] = '\0';
    
    
    
    //�˿ں� ��ȡ
    
    i = 0;
    
    PORT[i++] = hex_to_asic((buffer[4]>>4)&0x0f);
    PORT[i++] = hex_to_asic(buffer[4]&0x0f);
    PORT[i++] = hex_to_asic((buffer[5]>>4)&0x0f);
    PORT[i++] = hex_to_asic(buffer[5]&0x0f);
    
    PORT[i++] = '\0';
    
    
}

void SYSCLKConfig_STOP(void)
{
  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);

  /* Wait till HSE is ready */
  HSEStartUpStatus = RCC_WaitForHSEStartUp();

  if(HSEStartUpStatus == SUCCESS)
  {

#ifdef STM32F10X_CL
    /* Enable PLL2 */ 
    RCC_PLL2Cmd(ENABLE);

    /* Wait till PLL2 is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLL2RDY) == RESET)
    {
    }
#endif

    /* Enable PLL */ 
    RCC_PLLCmd(ENABLE);

    /* Wait till PLL is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {
    }

    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while(RCC_GetSYSCLKSource() != 0x08)
    {
    }
  }
}

