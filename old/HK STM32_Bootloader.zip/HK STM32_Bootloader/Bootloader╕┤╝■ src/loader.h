#ifndef	__LOADER_H__
#define	__LOADER_H__

#include "string.h"
#include "stm32f10x.h"







#define StartFlashAddress			(0x8000000)
#define PAGE_SIZE				(0x800)		/* 2 Kbytes */
#define FLASH_SIZE				(0x80000)	/* 512 KBytes */
#define IapMemorySize				(0x2000)	/* 8K*/
#define AppMemorySize				(0x3F000)	/* 252K */
#define BackupMemorySize			(0x3F000)	/* 252K*/

#define ApplicationAddress			(StartFlashAddress+IapMemorySize)

/*Backup memory start address:260*1024*/
#define BackUpMemAddress			(ApplicationAddress+AppMemorySize)	
//void LoaderInit(u32 size, u32 num);	/*if you want use this FIFO, please run this function first and ONLY ONCE!*/
void Dly1(u16 n);
void LoaderInit(void);	/*if you want use this FIFO, please run this function first and ONLY ONCE!*/
ErrorStatus BackupProgram(void);


#endif
