#include "Record_Select.h"
#include "Do_Task.h"

#define QUIT_TIME 0
extern uchar HZ[];


void SelectRecordToPrint1(uchar SelectCount)
{
    uchar QuitSelect;
    uchar SelectTimes;//��ѯ��¼������ ���� ���� SelectCount


    unsigned long RecordStart;
    unsigned long RecordCoursor;
    unsigned long timeOut;
    
    int StopTime;
    int count;
    
    
    uchar RecordBuf[32];//��¼
    uchar RecordAddrBuf[3];//��¼��ַ
    
    uchar Record_32_StartBuf[3];
    uchar Record_32_EndBuf[3];
    
    uchar record_buffer[10 * 32];//

    
    SPI_FLASH_Init();
    
    I2C_ReadS_24C(Con_Flash_Record_16_Start_Addr,Record_32_StartBuf,3);//��ʼ��ַ
    I2C_ReadS_24C(Con_Flash_Record_16_End_Addr,Record_32_EndBuf,3);//������ַ    
    I2C_ReadS_24C(Con_Flash_Record_16_Cursor,RecordAddrBuf,3);//�� ��¼���α�
    
    RecordStart = hcl(Record_32_StartBuf,3);
    RecordCoursor = hcl(RecordAddrBuf,3);
    
    SelectTimes = 0;
    count = 0;
    QuitSelect =1;
    while(SelectTimes < SelectCount && QuitSelect == 1)
    {
        if(RecordCoursor > RecordStart)
           RecordCoursor = RecordCoursor - 32;
        else
           QuitSelect = 0;
        
        if(RecordCoursor >= RecordStart)                
        {          
          SPI_FLASH_BufferRead(RecordBuf,RecordCoursor,32);
          if(IsOutRecord(RecordBuf) == OK)
          {
              for(uchar i=0;i<32;i++)
                record_buffer[count + i] = RecordBuf[i];
              
              count = count + 32;
              
              SelectTimes++;
          }
        }
                    
        
    }
    
    if(SelectTimes > 0 )
    {
        if(SelectTimes < SelectCount)        
            SelectCount = SelectTimes;
            
            
        SelectTimes = 0;
        QuitSelect = 1;
        while(QuitSelect == 1)
        {
                
                if(key_flag == 0x01 || key_flag == 0x02)//���� ����
                {
                    if(SelectTimes == 0)
                        SelectTimes = 1;
                    else
                        SelectTimes++;
                    
                    if(SelectTimes <= SelectCount)//�ڲ�ѯ��¼ �ķ�Χ��
                    { 
                        for(uchar i=0;i<32;i++)
                          RecordBuf[i] = record_buffer[(SelectTimes-1) * 32 + i];
                        
                        StopTime = CalcalateStopTime(RecordBuf + 10,RecordBuf + 21);
                        RecordSelectDisplay(RecordBuf + 1,RecordBuf + 9,StopTime,RecordBuf + 17,SelectTimes);
                                                
                                
                        key_flag = 0x00;   
                                
                        timeOut = 0;                                          	                                    
                        while(timeOut < KEYTIMEOUT_1S * 3)                                         	                                    
                        {                                            
                                                          
                                   if(key_flag){                                            	                                        
                                      delay(KEYTIMEOUT_1S * QUIT_TIME);                                        	                                        
                                      break;                                             	                                     
                                   }                                            	                                      
                                   timeOut++;                                         	                                    
                         }
                                    
                         if(key_flag == 0)
                             QuitSelect = 0;
        
                            
                           
                        
                    }
                    else
                    {
                         //��������ǰ��ѯ��
                         //��ʾ ��
                         lcd_clear();
                         dispaly(2,3,(HZ + mei));
                         dispaly(2,4,(HZ + you));
                         dispaly(2,5,(HZ + ji));
                         dispaly(2,6,(HZ + lu));
                         
                         dispaly(3,3,(HZ + qing));
                         dispaly(3,4,(HZ + wang));
                         dispaly(3,5,(HZ + hou));
                         dispaly(3,6,(HZ + cha));
                         
                         timeOut = 0;  
                         key_flag = 0x00;
                         while(timeOut < KEYTIMEOUT_1S * 3)                                         	                                    
                         {                                            
                                                          
                                   if(key_flag){                                            	                                        
                                      delay(KEYTIMEOUT_1S * QUIT_TIME);                                        	                                        
                                      break;                                             	                                     
                                   }                                            	                                      
                                   timeOut++;                                         	                                    
                         }
                                    
                         if(key_flag == 0)
                             QuitSelect = 0;
                    }
                    
                }
                else if(key_flag == 0x03 || key_flag == 0x04)//���·���
                {
                    if(SelectTimes > SelectCount)
                        SelectTimes = SelectCount;
                    else if(SelectTimes > 0)
                        SelectTimes--;
                    else
                    {
                        ;
                    }
                    
                    if(SelectTimes > 0)//�ڲ�ѯ��¼ �ķ�Χ��
                    {  
                        
                        for(uchar i=0;i<32;i++)
                          RecordBuf[i] = record_buffer[(SelectTimes-1) * 32 + i];
                        
                        StopTime = CalcalateStopTime(RecordBuf + 10,RecordBuf + 21);
                        RecordSelectDisplay(RecordBuf + 1,RecordBuf + 9,StopTime,RecordBuf + 17,SelectTimes);
                                                
                                
                        key_flag = 0x00;   
                                
                        timeOut = 0;                                          	                                    
                        while(timeOut < KEYTIMEOUT_1S * 3)                                         	                                    
                        {                                            
                                                          
                                   if(key_flag){                                            	                                        
                                      delay(KEYTIMEOUT_1S * QUIT_TIME);                                        	                                        
                                      break;                                             	                                     
                                   }                                            	                                      
                                   timeOut++;                                         	                                    
                         }
                                    
                         if(key_flag == 0)
                             QuitSelect = 0;
                    }
                    else
                    {
                         //�����������ѯ��
                         //��ʾ ��
                         lcd_clear();
                         dispaly(2,3,(HZ + mei));
                         dispaly(2,4,(HZ + you));
                         dispaly(2,5,(HZ + ji));
                         dispaly(2,6,(HZ + lu)); 
                         
                         dispaly(3,3,(HZ + qing));
                         dispaly(3,4,(HZ + wang));
                         dispaly(3,5,(HZ + qian));
                         dispaly(3,6,(HZ + cha));
                         
                         timeOut = 0;  
                         key_flag = 0x00;
                         while(timeOut < KEYTIMEOUT_1S * 3)                                         	                                    
                         {                                            
                                                          
                                   if(key_flag){                                            	                                        
                                      delay(KEYTIMEOUT_1S * QUIT_TIME);                                        	                                        
                                      break;                                             	                                     
                                   }                                            	                                      
                                   timeOut++;                                         	                                    
                         }
                                    
                         if(key_flag == 0)
                             QuitSelect = 0;
                    }
                }
                else
                {
                    //QuitSelect = 0;
                }
         }
            
        
    }
    else
    {
        //��ʾû�м�¼���˳�
        lcd_clear();
        dispaly(2,3,(HZ + mei));
        dispaly(2,4,(HZ + you));
        dispaly(2,5,(HZ + ji));
        dispaly(2,6,(HZ + lu)); 
        
        timeOut = 0;  
        key_flag = 0x00;
        while(timeOut < KEYTIMEOUT_1S * 2)                                         	                                    
        {                                            
                                                  
                           if(key_flag){                                            	                                        
                              delay(KEYTIMEOUT_1S * QUIT_TIME);                                        	                                        
                              break;                                             	                                     
                           }                                            	                                      
                           timeOut++;                                         	                                    
        }
    }
  
}


void SaveResetRecord(uchar *buffer,uchar count,uchar car)
{
    uchar buf[1];
    buf[0] = 0x01;
    switch(car)
    {
    case 1:
      I2C_WriteS_24C(ResetCar1Flag,buf,1);
      I2C_WriteS_24C(ResetRecordCar1,buffer,count);
      break;
    case 2:
      I2C_WriteS_24C(ResetCar2Flag,buf,1);
      I2C_WriteS_24C(ResetRecordCar2,buffer,count);
      break;
    case 3:
      I2C_WriteS_24C(ResetCar3Flag,buf,1);
      I2C_WriteS_24C(ResetRecordCar3,buffer,count);
      break;
    case 4:
      I2C_WriteS_24C(ResetCar4Flag,buf,1);
      I2C_WriteS_24C(ResetRecordCar4,buffer,count);
      break;
    default:break;
    }
}


void sendUpdataCommand(uchar flag)
{
    //1. �ȶ�����ǰ����� �汾��
    uchar car_buf[1];//��λ��
    uchar mater_buf[3];//�����
    uchar materVer_buf[2];//����汾��
    
    I2C_ReadS_24C(mibiao_number,mater_buf,3);//�����
    I2C_ReadS_24C(MATER_CAR,car_buf,1);
    I2C_ReadS_24C(MATER_VER,materVer_buf,2);
    uart_send_som("*0%");
    
    uart_send_som("<Long><137></Long><Result><Optype><F");
    uart_send(hex_to_asic(flag));
    uart_send_som("></Optype>");
    
    uart_send_som("<Metno><");   
    SEND_asic_2th(mater_buf[0]);
    SEND_asic_2th(mater_buf[1]);
    SEND_asic_2th(mater_buf[2]);
    uart_send_som("></Metno>");
    
    uart_send_som("<CarClass><");   
    SEND_asic_2th(car_buf[0]);
    uart_send_som("></CarClass>");
    
    uart_send_som("<MaterVer><V");   
    uart_send(hex_to_asic(materVer_buf[0]));
    uart_send_som(".");
    if(materVer_buf[1] >= 10)
    {
        uart_send(hex_to_asic(materVer_buf[1] / 10));
    }
    uart_send(hex_to_asic(materVer_buf[1] % 10));
    uart_send_som("></MaterVer>");
    
    uart_send_som("</Result>#");
}

uchar recUpdataPro(uchar delay_wait,int data[])
{
    u32 ack_err;
    int i;
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
        if(f_receiveOK == OK)
        {
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'D' && RxBuffer[i + 1] == 'a' && RxBuffer[i + 2] == 't' && RxBuffer[i + 3] == 'e' )
                {                   
                      data[0] = i + 6;
                      break;
                }
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'D' && RxBuffer[i + 1] == 'a' && RxBuffer[i + 2] == 't' && RxBuffer[i + 3] == 'e' )
                {                   
                      data[1] = i - 3;
                      return 1;
                }
            }
                     
            break;
        }
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x00;
    
    return 0x00;
}
uchar RequitUpdateProgram(void)
{
    uchar error_flag;
    uchar delayTime;
    uchar timeOut;
    int buffer[16];
    
    u16 backList_count;
    int AllCountBackList;
    uchar BL_Addr_buf[4];
    uchar BL_End_Addr_buf[4];
    uchar BL_Count_buf[4];
    uchar RequitPage[2];
    uint32_t SectorAddr;
    unsigned long BL_Addr;
    unsigned long BL_End_addr;
    unsigned long BL_Count;
    uchar BL_buffer[64 * 8];
    uchar Test_buf[64 * 8];
    int count;
    
    timeOut = 0x00;
    
    uchar buf[4];
    ///////////////////////����������� ��flash�ĳ�ʼ��/////////////////////
        buf[0] = 0x00;
        buf[1] = 0x75;
        buf[2] = 0x00;
        buf[3] = 0x00;
        I2C_WriteS_24C(UpdateProgramAddr,buf,4);//����������� ��ʼ��ַ
        I2C_WriteS_24C(UpdateCoursor,buf,4);//����������� �����α�
        
        buf[0] = 0x00;
        buf[1] = 0x7D;
        buf[2] = 0x00;
        buf[3] = 0x00;
        I2C_WriteS_24C(UpdateProgramAddr + 4,buf,4);//����������� ������ַ
        
        buf[0] = 0x00;
        buf[1] = 0x00;
        buf[2] = 0x00;
        buf[3] = 0x00;
        I2C_WriteS_24C(UpdateProgramAddr + 8,buf,4);//����������� ����
        
        I2C_WriteS_24C(Update_RequitPage,buf,2);
        I2C_WriteS_24C(Update_ALLCount,buf,2);
        ////////////////////////////////////////////////////////////////////////
        
    while(timeOut < 2)
    {
        if(open_gprs() == OK)
        {
            //��� ����֮ǰ���յ�����
            for(int i=0;i<RxCounter;i++)
               RxBuffer[i]=0x00; 
            
            RxCounter = 0;
            f_receiveOK = 0;
                  
            for(int i=0;i<16;i++)
                buffer[i] = 0x00;
            
            //sendUpdataCommand(8);//�������ظ��³���
            //error_flag = rec_gprs_Time(delayTime,buffer);
            error_flag = OK;
            
            if(error_flag == OK)
            {
                //count = buffer[1] - buffer[0];
              
                count = 0x02;
                if(count == 0x02)
                {
                    //if((RxBuffer[buffer[0]] == 'O' && RxBuffer[buffer[1]] == 'K') || (RxBuffer[buffer[0]] == 'o' && RxBuffer[buffer[1]] == 'k'))
                    {
                        SectorAddr =0x750000;
                        SPI_FLASH_Init();
                        while(SectorAddr < 0x7D0000) //����flash
                        {
                            SPI_FLASH_SectorErase(SectorAddr);
                            SectorAddr = SectorAddr + 0x010000;
                        }

                        if(error_flag == OK)
                        {
                            backList_count = 1;
                            do
                            {
                                  //��� ����֮ǰ���յ�����
                                  for(int i=0;i<RxCounter;i++)
                                    RxBuffer[i]=0x00;                
                                  RxCounter = 0;
                                  f_receiveOK = 0;
                                  
                                  for(int i=0;i<512;i++)
                                    BL_buffer[i] = 0x00;
                                  
                                  
                                  send_BackList_requestCommand(backList_count,9);//
                                  
                                  for(int i=0;i<16;i++)
                                    buffer[i] = 0x00;
                                                                  
                                  error_flag = rec_gprs_L(delayTime,buffer);
                                  if(error_flag == NO)//���մ���
                                    break;
                                  
                                  //��Asic�� ת���� Hex
                                  for(int i=0;i<14;i++)
                                    buffer[i] = asic_to_hex(buffer[i]);
                                  count = (buffer[15] - buffer[14]) / 2;
                                  //if(count % 512 != 0)
                                    //count = count + (8 - count % 8) - 8;
                                  
                                  for(int i=0;i< count;i++)
                                    BL_buffer[i] = asic_to_hex( RxBuffer[i * 2 + buffer[14] ])* 0x10 + asic_to_hex( RxBuffer[i * 2 + buffer[14] + 1]);
                                
                                  
                                  I2C_ReadS_24C(UpdateCoursor,BL_Addr_buf,4);//��ַ�α�
                                  I2C_ReadS_24C(UpdateProgramAddr + 4,BL_End_Addr_buf,4);//������ַ
                                  I2C_ReadS_24C(UpdateProgramAddr + 8,BL_Count_buf,4);//����
                                                                
                                  BL_Addr = hcl(BL_Addr_buf,4);
                                  BL_End_addr = hcl(BL_End_Addr_buf,4);
                                  BL_Count = hcl(BL_Count_buf,4);
                                  
                                  //����ַ����ı�����ʩ
                                  if(BL_Addr >= BL_End_addr)
                                    break;
                                  
                                  SPI_FLASH_Init();
                                  SPI_FLASH_BufferWrite(BL_buffer,BL_Addr,count);
                                  SPI_FLASH_BufferRead(Test_buf,BL_Addr,count);
                  
                                  if(count != 0)
                                  {
                                      BL_Addr = BL_Addr + count;
                                      BL_Count = BL_Count + count;
                                  }
                                  
                                  fll(BL_Addr,BL_Addr_buf,4);
                                  fll(BL_Count,BL_Count_buf,4);
                                  
                                  I2C_WriteS_24C(UpdateCoursor,BL_Addr_buf,4);//д���������α��ַ
                                  I2C_WriteS_24C(UpdateProgramAddr + 8,BL_Count_buf,4);//д������������
                                  
                                  AllCountBackList = buffer[6] * 0x1000 +buffer[7] * 0x100 + buffer[8] * 0x10 + buffer[9];
                  #if 1
                                  //dispaly(1,3,(HZ + quan_1));//
                                  dispaly(1,4,(HZ + liang)); //
                                  dispaly(1,5,(HZ + xia)); //��
                                  dispaly(1,6,(HZ + zai_1));//��
                                  
                                                  
                                  lcd_clear_h(3);
                                  LCD_display_symbol(3,6,backList_count/100,0);
                                  LCD_display_symbol(3,7,backList_count/10%10,0);
                                  LCD_display_symbol(3,8,backList_count%10,0);
                                  
                                  LCD_display_symbol(3,9,3,1);//  /
                                  
                                  LCD_display_symbol(3,10,AllCountBackList/100,0);
                                  LCD_display_symbol(3,11,AllCountBackList/10%10,0);
                                  LCD_display_symbol(3,12,AllCountBackList%10,0);
                                  
                                  
                  #endif
                                                 
                                  //����Ҫ�� ��ʱ���󵽵İ��� ��������
                                  fll(backList_count,RequitPage,2);
                                  I2C_WriteS_24C(Update_RequitPage,RequitPage,2);
                                  
                                  if(count != 0)
                                  {
                                      backList_count++;
                                  }
                                  
                                  
                                  //�Ѻ�����������������������
                                  fll(AllCountBackList,BL_buffer,2);
                                  I2C_WriteS_24C(Update_ALLCount,BL_buffer,2);//д�������� ȫ������
                      
                                 
                            }
                            while(backList_count <= AllCountBackList);
                                       
                           break;
                        }
                    }
                }
            }
            
            break;
        }
        else
        {
            timeOut++;
        }
    }
    
    return NO;
    
}