

#define PRINTER_BAUD9600 		0xf4 
#define PRINTER_BAUD115200  	0xff 
#define PRINTER_BAUD   	 		PRINTER_BAUD115200 
#define  PRINTER_PAPERNO  	 	0x01
#define  PRINTER_PAPERLOW  	 	0x02
#define  PRINTER_PAPEROK  	 	0x03

#define  Tick_Parkingin	  	 	0x01
#define  Tick_Parkingout	  	 	0x02
#define  Tick_Systemtest  	 	0x03

void Printer_Ticktest(void);
extern void Test_Printer();
extern void Printer_Tick(unsigned char Tick_Type);
extern void Printer_Setting();

