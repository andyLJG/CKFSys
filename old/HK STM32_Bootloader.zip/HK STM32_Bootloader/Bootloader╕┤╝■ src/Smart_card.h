#ifndef _Smart_card_H_
#define _Smart_card_H_

#include "IC_demo.h"

#define Smart_card_opend	        		GPIO_SetBits(GPIOB, GPIO_Pin_12)
#define Smart_card_close	        		GPIO_ResetBits(GPIOB, GPIO_Pin_12)



#define uchar unsigned char
#define uint unsigned int

extern u8 system0_number[];



void Open_Smart_Card_Power(void);
void Close_Smart_Card_Power(void);

void sent_smart_data(unsigned char x);
void TX_smart_card(uchar* data);
void read_MIFARE_card(MIFARE_card_information* CC);
void read_CPU_card(CPU_card_information* CC);
void TX_Smart_Command(uchar STX,uchar ID,uchar LEN,uchar CMD,uchar DATA[],uchar BCC,uchar ETX);
uchar read_card(uchar STX,uchar ID,uchar LEN,uchar CMD,uchar *DATA,uchar BCC,uchar ETX,uchar flag);
uchar read_card_is_OK(uchar STX,uchar LEN,uchar CMD,uchar ETX,uchar flag);


//2013 05 17 �¼ӵĶ�������Ĳ���
uchar inquire_card(void);
void pro(unsigned char * dat1,unsigned char * dat2,unsigned char * dat3,unsigned char length);
void MF1key_main(u8* card_number,uchar* mimakey);
uchar testkey_comd(uchar sector,uchar password_class,uchar* password);
uchar read_comd(unsigned char block,u8 read_data[]);//��� ��0x00~0x3f�� ��64��
uchar write_comd(u8 block,u8 write_data[]);
uchar value_comd(u8 add_sub,u8 block_value, u16 park_mny);
uchar write_CPUcard(char CardId[],uchar FiledId,uchar Addr,uchar Length,u8 info[]);
uchar value_CPUcard(uchar YearH,uchar Year,uchar Month,uchar Date,uchar Hour,uchar Min,uchar Second,uchar* QBalance,uchar* Pays,uchar* CardId);

uchar usart5_rx(void);
uchar read_CPUcard(uchar Catalog[],uchar FileId,uchar Addr,uchar Length);
void read_CPU_data(uchar data[]);

void read_JM_CPU_card(JM_CPU_card_information* CC);
uchar JM_value_CPUcard(uchar Momery[],uchar Time[]);
//����ͨ�� ���� ������
uchar catch_BaclkList(void);
unsigned char Faildeal_CPUcard(u8 data[],uchar TAC[]);

//������ID
uchar read_mech_ID(void);

uchar read_PSAM(void);

//������ ��������
uchar recover_back_list(void);
#endif