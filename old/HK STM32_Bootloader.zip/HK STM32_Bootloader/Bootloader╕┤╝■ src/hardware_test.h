#ifndef _HARDWARE_TEST_
#define _HARDWARE_TEST_


#include "stdio.h"
#include "string.h"
#include "stm32f10x_conf.h"
#include "hal.h"
#include "MemoryAssign.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Key.h"
#include "Count.h"
#include "Coin.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include "Gprs_online.h"
#include "stm32f10x_pwr.h"
#include "stm32f10x_wwdg.h"
#include "main.h"
#include "rate.h"
#include "loader.h"
#include "spi_flash.h"
#include "fsmc_sram.h"
#include "Memory.h"






#define Smart_Power_OFF         GPIO_ResetBits(GPIOB, GPIO_Pin_12)
#define Smart_Power_ON         GPIO_SetBits(GPIOB, GPIO_Pin_12)

#define LCD_Power_OFF         GPIO_ResetBits(GPIOG, GPIO_Pin_13)
#define CONIN_Power_OFF         GPIO_ResetBits(GPIOG, GPIO_Pin_14)

#define GPRS_Power_ON         GPIO_SetBits(GPIOG, GPIO_Pin_15)
#define GPRS_Power_OFF         GPIO_ResetBits(GPIOG, GPIO_Pin_15)
void hardWare_test(void);
//void LCD_display_no(uchar row ,uchar column ,unsigned char shu);

#endif
