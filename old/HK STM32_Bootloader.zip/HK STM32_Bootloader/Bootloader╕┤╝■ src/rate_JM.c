#include "rate_JM.h"
#include "Do_Task.h"

//#define car1        1
//#define car2        2
//#define car3        3
//#define car4        4


#define car1_use_info                       0x0000
#define car2_use_info                       0x0010
#define car3_use_info                       0x0020
#define car4_use_info                       0x0030

uchar year;
uchar month;
uchar day;
uchar hour;
uchar min;
uchar week;

unsigned long stop_time=0;

uchar ChargeStart_H;    //�շѿ�ʼʱ�� ��λ��Сʱ BCD
uchar ChargeStart_M;    //�շѿ�ʼʱ�� ��λ������ BCD
uchar ChargeEnd_H;    //�շѽ���ʱ�� ��λ��Сʱ BCD
uchar ChargeEnd_M;    //�շѽ���ʱ�� ��λ������ BCD
    
uchar SaleBase;      //�ۿۻ��� ��λ 64H - 01H HEX
uchar MaxStop_Momery;  //�������ͣ������ ��λ:Ԫ HEX
uchar MinCharge_Time;    //��С�շ�ʱ�� ��λ:���� BCD
uchar MinCharge_Monery;    //��С�շѽ�� ��λ��Ԫ HEX
uchar StartFree_Time;  //����Ѳ���ʱ�� ��λ������ BCD
    
uchar Nightcharge;      //ҹ���շ� ��λ��Ԫ HEX
uchar MaxPark_Time;  //������󲴳�ʱ�� ��λ��Сʱ BCD
    
Rate_reference_ST RR_ST;

void get_rate_ref(Rate_reference_ST* RR)
{
    uchar buffer[16];
    uchar BCC;
    
    BCC = 0x00;
    I2C_ReadS_24C(B_startTime_unit_of_hour,buffer,12);
    for(uchar i=0;i<11;i++)
      BCC = BCC ^ buffer[i];
    
    if(BCC != buffer[11])
    {
        BCC = 0x00;
        I2C_ReadS_24C(back_argument_of_charge,buffer,12);
        for(uchar i=0;i<11;i++)
          BCC = BCC ^ buffer[i];
        
        if(BCC != buffer[11])
        {
            buffer[0] = 0x08;
            buffer[1] = 0x00;
            buffer[2] = 0x23;
            buffer[3] = 0x00;
            buffer[4] = 100;
            buffer[5] = 15;
            buffer[6] = 0x60;
            buffer[7] = 3;
            buffer[8] = 0x15;
            buffer[9] = 0;
            buffer[10] = 0x24;
            
            BCC = 0x00;
            for(uchar i=0;i<11;i++)
              BCC = BCC ^ buffer[i];
            buffer[11] = BCC;
            
            I2C_WriteS_24C(B_startTime_unit_of_hour,buffer,12);
            I2C_WriteS_24C(back_argument_of_charge,buffer,12);
        }
        else
        {
            I2C_WriteS_24C(B_startTime_unit_of_hour,buffer,12);
        }
    }
 
    
    RR->Charge_Start_H = (((buffer[0]>>4)&0x0f)*10) + (buffer[0]&0x0f); //�շѿ�ʼʱ�� ��λ��Сʱ BCD
    RR->Charge_Start_M = (((buffer[1]>>4)&0x0f)*10) + (buffer[1]&0x0f); //�շѿ�ʼʱ�� ��λ������ BCD
    RR->Charge_End_H = (((buffer[2]>>4)&0x0f)*10) + (buffer[2]&0x0f);//�շѽ���ʱ�� ��λ��Сʱ BCD
    RR->Charge_End_M = (((buffer[3]>>4)&0x0f)*10) + (buffer[3]&0x0f);//�շѽ���ʱ�� ��λ������ BCD

    RR->Sale_Base = buffer[4];//�ۿۻ��� ��λ 64H - 01H HEX
    RR->Max_Stop_Momery = buffer[5];//�������ͣ������ ��λ:Ԫ HEX
    RR->Min_Charge_Time = (((buffer[6]>>4)&0x0f)*10) + (buffer[6]&0x0f);//��С�շ�ʱ�� ��λ:���� BCD
    RR->Min_Charge_Monery = buffer[7];//��С�շѽ�� ��λ��Ԫ HEX
    RR->Start_Free_Time = (((buffer[8]>>4)&0x0f)*10) + (buffer[8]&0x0f);//����Ѳ���ʱ�� ��λ������ BCD
    
    RR->Night_charge = buffer[9];//ҹ���շ� ��λ��Ԫ HEX
    RR->Max_Park_Time = (((buffer[10]>>4)&0x0f)*10) + (buffer[10]&0x0f);//������󲴳�ʱ�� ��λ��Сʱ BCD
    
}
//��ȡ ��ǰ�Ƿ��� ���ʱ��
char get_current_time()
{
    GetCurrentTime();
    get_rate_ref(&RR_ST);
    
    year = time1[4];
    month = time1[3];
    day = time1[2];
    hour = time1[1];
    min = time1[0];
       
        if(hour > RR_ST.Charge_Start_H && hour < RR_ST.Charge_End_H)
        {
            return 1;
        }
        else
        {
            if(hour == RR_ST.Charge_Start_H && min >= RR_ST.Charge_Start_M)
              return 1;
            else if(hour == RR_ST.Charge_End_H && min < RR_ST.Charge_End_M)
              return 1;
            else
              return 0;
        }
    
    
}
int time_to_momery(uchar time_buffer[])
{
    //uchar year;
    //uchar month;
    //uchar date;
    uchar hour;
    uchar min;
    
    //uchar get_month;
    //uchar get_date;
    uchar get_hour;
    uchar get_min;
    
    int stop_time;
    int stop_memory;
    uchar stop_time_hour;
    uchar stop_time_min;//��ȡ��ʱͣ����ʱ��
    
    
    
    get_rate_ref(&RR_ST);
    
    ChargeStart_H = RR_ST.Charge_Start_H;
    ChargeStart_M = RR_ST.Charge_Start_M;
    ChargeEnd_H = RR_ST.Charge_End_H;
    ChargeEnd_M = RR_ST.Charge_End_M;
    
    SaleBase = RR_ST.Sale_Base;    
    MaxStop_Momery = RR_ST.Max_Stop_Momery;
    MinCharge_Time = RR_ST.Min_Charge_Time;
    MinCharge_Monery = RR_ST.Min_Charge_Monery;
    StartFree_Time = RR_ST.Start_Free_Time;
    
    Nightcharge = RR_ST.Night_charge;
    MaxPark_Time = RR_ST.Max_Park_Time;
    
    //month = ((time_buffer[0]>>4)&0x0f)*10 + (time_buffer[0]&0x0f); 
    //date = ((time_buffer[1]>>4)&0x0f)*10 + (time_buffer[1]&0x0f);
    hour = ((time_buffer[2]>>4)&0x0f)*10 + (time_buffer[2]&0x0f);
    min = ((time_buffer[3]>>4)&0x0f)*10 + (time_buffer[3]&0x0f);


    GetCurrentTime();
    
    
    //get_month = time1[3]; //��ȡ��ǰʱ��
    //get_date = time1[2];
    get_hour = time1[1];
    get_min = time1[0];
    

    
    if(ret_max_24hour(time_buffer,PARK_CARD) >= MaxPark_Time *60)
    {
        //return 1500;
      stop_memory = MaxStop_Momery * SaleBase;
      return  stop_memory;
    }
    
    stop_time = ret_max_24hour(time_buffer,PARK_CARD);
    stop_time_hour = stop_time / 60;
    stop_time_min = stop_time % 60;
    
    if(hour > ChargeStart_H && hour < ChargeEnd_H)
    {
        
        
        if(hour < (ChargeEnd_H - 5))
        {
                                 
        }
        else
        {
            stop_time_hour = stop_time_hour + hour;
            stop_time_min = stop_time_min + min;
            if(stop_time_min >= 60)
            {
                stop_time_hour++;
                stop_time_min = stop_time_min - 60;
            }
            
            if(stop_time_hour < ChargeEnd_H || (stop_time_hour == ChargeEnd_H && stop_time_min <= ChargeEnd_M))
            {
                //ͣ��ʱ�� û�г��� �շѽ���ʱ��
            }            
            else if(stop_time_hour < (ChargeStart_H + 24) || (stop_time_hour == (ChargeStart_H + 24) && stop_time_min <= ChargeStart_M))
            {
                //ͣ��ʱ�� û�г�����2�� �շѿ�ʼʱ��
                  hour = ChargeEnd_H - hour;
                  if(hour > 0)
                  {
                       stop_time = (hour - 1) * 60 + (60 - min) + ChargeEnd_M;                    
                  }
                  else
                  {
                       stop_time = (ChargeEnd_M - min);
                  }
                                             
            }            
            else
            {  
                //ͣ��ʱ�� ������2�� �շѿ�ʼʱ��
                if(ChargeEnd_M != 0)
                {
                    stop_time = stop_time - ((24 - ChargeEnd_H - 1) * 60 + (60 - ChargeEnd_M) + ChargeStart_H * 60 + ChargeStart_M);
                }
                else
                {
                    stop_time = stop_time - ((24 -ChargeEnd_H + ChargeStart_H) * 60 + ChargeStart_M);
                }
            }
       
        }
    }
    else if(hour == ChargeStart_H)
    {
        stop_time_hour = stop_time_hour + hour;
        stop_time_min = stop_time_min + min;
        if(stop_time_min >= 60)
        {
             stop_time_hour++;
             stop_time_min = stop_time_min - 60;
        }
        
        if(min < ChargeStart_M)
        {
            if(stop_time_hour == ChargeStart_H)//ͬһ������
            {
                if(stop_time_min  > ChargeStart_M)
                {
                    stop_time =  stop_time_min - ChargeStart_M;
                }
                else
                {
                    stop_time = 0;
                }
            }
            else
            {
                stop_time = (stop_time_hour - ChargeStart_H - 1) * 60 + get_min + (60 - ChargeStart_M);
            }
        }
        else
        {
            if(stop_time_hour == ChargeStart_H)//ͬһ������
            {
                if(stop_time_min  > ChargeStart_M)
                {
                    stop_time =  stop_time_min - min;
                }
                else
                {
                    stop_time = 0;
                }
            }
            else
            {
                stop_time = (stop_time_hour - ChargeStart_H - 1) * 60 + get_min + (60 - min);
            }
        }
    }
    else if(hour == ChargeEnd_H)
    {
        if(min < ChargeEnd_M)
        {
            stop_time_hour = stop_time_hour + hour;
            stop_time_min = stop_time_min + min;
            if(stop_time_min >= 60)
            {
                stop_time_hour++;
                stop_time_min = stop_time_min - 60;
            }
                   
            
            if((stop_time_hour < (ChargeStart_H + 24) ) || (stop_time_hour == (ChargeStart_H + 24) && stop_time_min <= ChargeStart_M))
            {
                stop_time = ChargeEnd_M - min;
            }
            else
            {
                hour = get_hour - ChargeStart_H;
                if(hour > 0)
                {
                        stop_time = (hour - 1)* 60 +(60- ChargeStart_M)+ get_min + ChargeEnd_M - min;                    
                }
                else
                {
                        stop_time = get_min - ChargeStart_M + ChargeEnd_M - min;
                }
            }
        }
        else
        {
            stop_time_hour = stop_time_hour + hour;
            stop_time_min = stop_time_min + min;
            if(stop_time_min >= 60)
            {
                stop_time_hour++;
                stop_time_min = stop_time_min - 60;
            }
                   
            
            if(stop_time_hour < (ChargeStart_H + 24) || (stop_time_hour == (ChargeStart_H + 24) && stop_time_min <= ChargeStart_M))
            {
                stop_time = 0;
            }
            else
            {
                hour = get_hour - ChargeStart_H;
                if(hour > 0)
                {
                        stop_time = (hour - 1)* 60 +(60- ChargeStart_M)+ get_min;                    
                }
                else
                {
                        stop_time = get_min - ChargeStart_M;
                }
            }
        }
        
                
        
    }
    else if(hour > ChargeEnd_H)//ҹ��� ���ʱ��
    {
                   
      stop_time_hour = stop_time_hour + hour;           
      stop_time_min = stop_time_min + min;
            
      if(stop_time_min >= 60)           
      {              
        stop_time_hour++;              
        stop_time_min = stop_time_min - 60;            
      }
                   
                        
      if(stop_time_hour < (ChargeStart_H + 24) || (stop_time_hour == (ChargeStart_H + 24) && stop_time_min <= ChargeStart_M))            
      {                
        stop_time = 0;            
      }            
      else            
      {
          hour = get_hour - ChargeStart_H;
          if(hour > 0)
          {
              stop_time = (hour - 1)* 60 +(60- ChargeStart_M)+ get_min;                    
          }
          else
          {
                 stop_time = get_min - ChargeStart_M;
          }           
      }               
        
    }
    else//��������ʱ���
    {
        stop_time_hour = stop_time_hour + hour;
        stop_time_min = stop_time_min + min;
        if(stop_time_min >= 60)
        {
            stop_time_hour++;
            stop_time_min = stop_time_min - 60;
        }
        
        if(stop_time_hour < ChargeStart_H || (stop_time_hour == ChargeStart_H && stop_time_min <= ChargeStart_M))
        {
            stop_time = 0;
        }
        else
        {
            hour = get_hour - ChargeStart_H;
            if(hour > 0)
            {
                    stop_time = (hour - 1)* 60 +(60- ChargeStart_M)+ get_min;                   
            }
            else
            {
                    stop_time = get_min - ChargeStart_M;
            }
        }
    }
    
    if(stop_time <= StartFree_Time)
    {
         return 0; //���гֿ��û� ��15���� ���
    }
    
    if(stop_time / MinCharge_Time * MinCharge_Monery * SaleBase >= MaxStop_Momery * SaleBase)
    {
         stop_time = MaxStop_Momery / MinCharge_Monery;         
    }
    else
    {
        if(stop_time % MinCharge_Time == 0)
        {
            stop_time = stop_time / MinCharge_Time;
        }
        else
        {
            stop_time = (stop_time / MinCharge_Time) + 1;
        }
    }
    
   
    
    return stop_time * MinCharge_Monery * SaleBase;
    
}



    
int momery_to_time(int  momery)
{
    int max_stop_time;
    int stop_time;
    
    uchar StopTime_Hour;
    uchar StopTime_Min;
    uchar hour;
    int min;
    
    uchar get_hour; //��ȡ�ĵ�ǰʱ�� Сʱ
    int get_min;  //��ȡ�ĵ�ǰʱ�� ����
    get_rate_ref(&RR_ST);
    
    ChargeStart_H = RR_ST.Charge_Start_H;
    ChargeStart_M = RR_ST.Charge_Start_M;
    ChargeEnd_H = RR_ST.Charge_End_H;
    ChargeEnd_M = RR_ST.Charge_End_M;
    
    SaleBase = RR_ST.Sale_Base;    
    MaxStop_Momery = RR_ST.Max_Stop_Momery;
    MinCharge_Time = RR_ST.Min_Charge_Time;
    MinCharge_Monery = RR_ST.Min_Charge_Monery;
    StartFree_Time = RR_ST.Start_Free_Time;
    
    Nightcharge = RR_ST.Night_charge;
    MaxPark_Time = RR_ST.Max_Park_Time;
    

    
    GetCurrentTime();
    
    get_hour = time1[1];
    get_min = time1[0];

    if(get_current_time() == 1)//��ʾ�շ�ʱ��
    {
        if(momery < MinCharge_Monery * SaleBase)
        {
            return 0;//��ʾ���㣬����ͣ�� ����ʱ��Ϊ 0
        }
        
        if(momery < MaxStop_Momery * SaleBase)
        {
            
                hour = ChargeEnd_H - get_hour;
                if(hour > 0)
                  min = (hour - 1) * 60 + (60 - get_min) + ChargeEnd_M;
                else
                  min = ChargeEnd_M - get_min;
                
                hour = min / 60; //������23��֮ǰ��ʱ�� Сʱ
                min = min % 60;  //������23��֮ǰ��ʱ�� ����
                
                stop_time = momery / (MinCharge_Monery * SaleBase);
               
                if(momery % (MinCharge_Monery * SaleBase) != 0)
                   stop_time = stop_time + 1;
                
                StopTime_Hour = (stop_time * MinCharge_Time) / 60;
                StopTime_Min = (stop_time * MinCharge_Time) % 60;
                
                if(StopTime_Hour < hour || (StopTime_Hour == hour && min > StopTime_Min))
                {
                    return stop_time * MinCharge_Time;
                }                
                else
                {
                    return stop_time * MinCharge_Time + ((24 - ChargeEnd_H - 1) + ChargeStart_H) * 60 + (60 -ChargeEnd_M) + ChargeStart_M;
                }
        }         
        else
        {

             return MaxPark_Time * 60;
        }
    }
    else    //��ʾ�����ʱ�� ͣ��
    {
        if((get_hour == ChargeEnd_H && get_min >= ChargeEnd_M ) || (get_hour > ChargeEnd_H && get_hour < 24))//��23�� �� 24���ڼ�
        {        
            max_stop_time = 24 - ChargeEnd_H;
            
            max_stop_time = (max_stop_time - 1) * 60 + (60 - get_min) + ChargeStart_H * 60 + ChargeStart_M;
            if(momery < MinCharge_Monery * SaleBase)
              return 0;
            else if(momery < MaxStop_Momery * SaleBase)
            {
                stop_time = momery / (MinCharge_Monery * SaleBase);
                if(momery % (MinCharge_Monery * SaleBase) != 0)
                   stop_time = stop_time + 1;

               
                max_stop_time = max_stop_time + stop_time * MinCharge_Time;
                
            }
            else
            {
                return MaxPark_Time * 60;
            }
        }
        else //��00�� �� 08���ڼ�
        {
          
            hour = ChargeStart_H - get_hour;
            if(hour > 0)
              max_stop_time = (hour - 1) * 60 + (60 - get_min) + ChargeStart_M;            
            else
              max_stop_time = ChargeStart_M - get_min;
          
            if(momery < MinCharge_Monery * SaleBase)
              return 0;  
            
            if(momery < MaxStop_Momery * SaleBase)
            {
                stop_time = momery / (MinCharge_Monery * SaleBase);
                
                if(momery % (MinCharge_Monery * SaleBase) != 0)
                   stop_time = stop_time + 1;

                
                max_stop_time = max_stop_time + stop_time * MinCharge_Time;
            }
            else
            {
                return MaxPark_Time * 60;
            }
        }
        
        return max_stop_time;
    }

}


