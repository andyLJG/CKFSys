/***************************************************
**HAL.c
**��Ҫ����оƬӲ�����ڲ���Χ���ⲿ��Χ�ĳ�ʼ��������INIT����
**��MAIN�е��ã�ʹMAIN�����о�����Ӳ�����޹�
***************************************************/

#include "STM32Lib\\stm32f10x.h"
#include "LCD_12864.h"
#include "hal.h"
#include "St_credit.h"
#include "fsmc_sram.h"
#include "KEY.h"
//�����ڲ�Ӳ��ģ������ú���
extern void GPIO_Configuration(void);			//GPIO
extern void RCC_Configuration(void);			//RCC
extern void I2C_Configuration(void);			//I2C
extern void IWDG_Configuration(void);
void SPI_FLASH_Init(void);
void ADC_Configuration(void);


/*******************************
**������:ChipHalInit()
**����:Ƭ��Ӳ����ʼ��
*******************************/
void  ChipHalInit(void)
{
	//��ʼ��ʱ��Դ
	RCC_Configuration();    // this is ok!
	//��ʼ��GPIO
	GPIO_Configuration();
		
	//Flash��ʼ��
	SPI_FLASH_Init(); // this is ok!
        
	//ADC_Configuration();
        
        //��ʼ���������Ź�
        IWDG_Configuration();   // this is ok!

	//��ʼ��I2C
	//I2C_Configuration();	
        
        //JM_keypin_init();
      NVIC_Configuration();  
        Buzz_1;
}
void I2C_Configuration(void)
{
	I2C_InitTypeDef  I2C_InitStructure;
	GPIO_InitTypeDef  GPIO_InitStructure; 

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1,ENABLE);

	/* PB6,7 SCL and SDA */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	/* PB6,7 SCL and SDA */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
        I2C_DeInit(I2C1);
        I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
        I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
        I2C_InitStructure.I2C_OwnAddress1 = 0x30;
        I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
        I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
        I2C_InitStructure.I2C_ClockSpeed = 100000;//100K�ٶ�
    
	I2C_Cmd(I2C1, ENABLE);
	I2C_Init(I2C1, &I2C_InitStructure);
	/*����1�ֽ�1Ӧ��ģʽ*/
	I2C_AcknowledgeConfig(I2C1, ENABLE);

}


/*********************************
**������:ChipOutHalInit()
**����:Ƭ��Ӳ����ʼ��
*********************************/
void  ChipOutHalInit1(void)
{
  LCD_INIT();
  Uart1_Configuration(BaudRate_9600);      //���ڲ����ʵȲ�������
  Uart2_Configuration();
  Uart3_Configuration(BaudRate_38400);
  //Uart3_Configuration(BaudRate_38400);
  Uart4_Configuration(BaudRate_19200);
  Uart5_Configuration();
  FSMC_SRAM_Init();

}
/*********************************
**������:ChipOutHalInit()
**����:Ƭ��Ӳ����ʼ��
*********************************/
void  ChipOutHalInit(void)
{
  //keypin_init();
  Uart1_Configuration(BaudRate_9600);      //���ڲ����ʵȲ�������
  Uart2_Configuration();                   // 115200
  Uart3_Configuration(BaudRate_38400);
  Uart4_Configuration(BaudRate_19200);	   //����ͨ��  ����   ��ӡ��
  Uart5_Configuration();                   //38400
  init_rx8025sa();
  FSMC_SRAM_Init();
}
void Uart1_Configuration(u32 BaudRate)
{

USART_InitTypeDef USART_InitStructure;
  
/* USART1 configuration ------------------------------------------------------*/
  /* USART1 configured as follow:
        - BaudRate = 19200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
  */
  USART_DeInit(USART1);

  USART_InitStructure.USART_BaudRate = BaudRate;//19200;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  /* Configure USART1 */
  USART_Init(USART1, &USART_InitStructure);
  
  /* Enable USART1 Receive and Transmit interrupts */
  USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

  /* Enable the USART1 */
  USART_Cmd(USART1, ENABLE);

}
///////////////////////////////////////////////////////////////////////////////////
void Uart1_Enable(void)
{

//USART_InitTypeDef USART_InitStructure;
  USART_ITConfig(UART5, USART_IT_RXNE, ENABLE);
  /* ENABLE the USART5 */
  USART_Cmd(UART5, ENABLE);
  USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);
  /* ENABLE the USART5 */
  USART_Cmd(UART4, ENABLE);
  USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);
  /* ENABLE the USART5 */
  USART_Cmd(USART3, ENABLE);
  USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
  /* ENABLE the USART5 */
  USART_Cmd(USART2, ENABLE);
  USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
  /* ENABLE the USART5 */
  USART_Cmd(USART1, ENABLE); 
}
void Uart2_Configuration(void)
{
  USART_InitTypeDef USART_InitStructure;
  
/* USART2 configuration ------------------------------------------------------*/
  /* USART2 configured as follow:
        - BaudRate = 115200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
  */
  USART_DeInit(USART2);

  USART_InitStructure.USART_BaudRate = BaudRate_115200;//19200;//38400;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  /* Configure USART2 */
  USART_Init(USART2, &USART_InitStructure);
  
  /* Enable USART2 Receive and Transmit interrupts */
  USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

  /* Enable the USART2 */
  USART_Cmd(USART2, ENABLE);

}
void Uart3_Configuration(u32 BaudRate)
{
  USART_InitTypeDef USART_InitStructure;
  
/* USART3 configuration ------------------------------------------------------*/
  /* USART3 configured as follow:
        - BaudRate = 19200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
  */
  USART_DeInit(USART3);

  USART_InitStructure.USART_BaudRate = BaudRate;//38400;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  /* Configure USART3 */
  USART_Init(USART3, &USART_InitStructure);
  
  /* Enable USART3 Receive and Transmit interrupts */
  USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);

  /* Enable the USART3 */
  USART_Cmd(USART3, ENABLE);

}


void Uart4_Configuration(u32 BaudRate)
{
  USART_InitTypeDef USART_InitStructure;
  
/* USART4 configuration ------------------------------------------------------*/
  /* USART4 configured as follow:
        - BaudRate = BaudRate 
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
  */
  USART_DeInit(UART4);

  USART_InitStructure.USART_BaudRate = BaudRate;//38400;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  /* Configure USART4 */
  USART_Init(UART4, &USART_InitStructure);
  
  /* Enable USART4 Receive and Transmit interrupts */
  USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);

  /* Enable the USART4 */
  USART_Cmd(UART4, ENABLE);

}

void Uart5_Configuration(void)
{

USART_InitTypeDef USART_InitStructure;
  
/* USART5 configuration ------------------------------------------------------*/
  /* USART5 configured as follow:
        - BaudRate = 19200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
  */
  USART_DeInit(UART5);

  //USART_InitStructure.USART_BaudRate = BaudRate_38400;//;
  USART_InitStructure.USART_BaudRate = BaudRate_115200;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  /* Configure USART5 */
  USART_Init(UART5, &USART_InitStructure);
  
  /* Enable USART5 Receive and Transmit interrupts */
  USART_ITConfig(UART5, USART_IT_RXNE, ENABLE);

  /* Enable the USART5 */
  USART_Cmd(UART5, ENABLE);

}
void Uart5_Close(void)
{
  USART_ITConfig(UART5, USART_IT_RXNE, DISABLE);
  /* DISABLE the USART5 */
  USART_Cmd(UART5, DISABLE);
  
  USART_ITConfig(UART4, USART_IT_RXNE, DISABLE);
  /* DISABLE the USART5 */
  USART_Cmd(UART4, DISABLE);
  
  USART_ITConfig(USART3, USART_IT_RXNE, DISABLE);
  /* DISABLE the USART5 */
  USART_Cmd(USART3, DISABLE);
  
  USART_ITConfig(USART2, USART_IT_RXNE, DISABLE);
  /* DISABLE the USART5 */
  USART_Cmd(USART2, DISABLE);
  

  
  USART_ITConfig(USART1, USART_IT_RXNE, DISABLE);
  /* DISABLE the USART5 */
  USART_Cmd(USART1, DISABLE); 
}  

/////////////////////////////////////
void NVIC_Configuration(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;

  /* Configure the NVIC Preemption Priority Bits */  
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
  
  
  /* Enable the USART1 Interrupt*/ 
  NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  
  /* Enable the USART2 Interrupt*/ 
  NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelCmd =DISABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  
  /* Enable the USART3 Interrupt 
  NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
  NVIC_Init(&NVIC_InitStructure);
  */
  
  
  /* Enable the USART4 Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
  NVIC_Init(&NVIC_InitStructure);

   //Enable the USART5 Interrupt 
  NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  /* EXTI10-15*/
  NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
 // NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//
  NVIC_InitStructure.NVIC_IRQChannelCmd =DISABLE;//ENABLE;
  NVIC_Init(&NVIC_InitStructure);

/* EXTI5-9 */
  NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;//ENABLE;//
  NVIC_Init(&NVIC_InitStructure);	
  
//////////////////////////////////////////////////////////////
    /* 2 bits for Preemption Priority and 2 bits for Sub Priority */
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
  NVIC_InitStructure.NVIC_IRQChannel = WWDG_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd =DISABLE; // ENABLE;
  NVIC_Init(&NVIC_InitStructure);  
  /* ι��*/
  IWDG_ReloadCounter();//2015-12-23 andyluo
}
