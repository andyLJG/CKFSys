
#ifndef	_Gprs_H
#define		_Gprs_H			    

unsigned char asic_to_hex(unsigned char rr);
void open_gprs_uart();
void close_uart();
void open_gprs_power();
void close_gprs_power();
void close_gprs_power1();
//void send_apn();
void send_ip(unsigned char IP_Addr[],unsigned char PORT[]);
void send_DPSip();
u8 open_gprs11();
u8 open_gprs();
u8 open_DPS();
u8 Link_network(void);
unsigned char rec_gprs_lin(unsigned long timeout);
unsigned char twoasic_to_oenhex(unsigned char *recvgsmproc,u8 ASCII);
//void CDMA_sleep();
//void CDMA_wake();
void Link_ServerIP(void);
u8 rec_gprs1(unsigned long delay_wait,unsigned char *shujv);//andyluo2011-02-12
u8 rec_gprs(unsigned long delay_wait,unsigned char *shujv,u8 change);//andyluo2011-02-12
u8 rec_gprs2(unsigned long delay_wait,unsigned char *shujv,u8 change);//andyluo2011-02-12

u8 rec_gprs_L(uchar delay_wait,int data[]);

uchar rec_gprs_ack(uchar delay_wait);

void open_gprs_power();
void open_gprs_uart();
void close_uart();
void close_gprs_power();


uchar rec_gprs_Time(uchar delay_wait,int data[]);

uchar rec_gprs_Free(uchar delay_wait,int data[]);


#endif


