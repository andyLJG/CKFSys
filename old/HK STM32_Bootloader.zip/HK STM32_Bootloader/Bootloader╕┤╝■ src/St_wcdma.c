#include "stm32f10x_conf.h"
#include "hal.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Count.h"
#include "Key.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include "Gprs_online.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_it.h"
#include "misc.h"
#include "math.h"
#include "Card.h"
#include "MemoryAssign.h"

u16 RxCounter;
u16 TxCounter;
unsigned char RxBuffer[3000];

unsigned char first_card(void);
void open_wcdma_modem(void);
void close_wcdma_modem(void);
unsigned char reqest_comd(void);
////////////////////�����Լ�һЩ�򵥴���///////////////////////////
/*----------------------------------------------------------------------
����:    card_modem_configor(void)
����:    �򿪶���ģ���Դ������ʼ������
input:   ��
output:  ��
------------------------------------------------------------------------*/
void open_wcdma_modem(void)
{
 // WCDMA_Power_ON;
  WCDMA_Power_OFF;
  delay(5000);
}
/*----------------------------------------------------------------------
����:    close_card_modem(void)
����:   �򿪶���ģ���Դ�����رմ���
input:   ��
output:  ��
-----------------------------------------------------------------------*/
void close_wcdma_modem(void)
{
  //WCDMA_Power_OFF;
  WCDMA_Power_ON;  
//  delay(10000);    
  delay(KEYTIMEOUT_1S*4);
}
/*-------------------------------------------------------------------*/

void USART_SendDataPacket(USART_TypeDef* USARTx, uint16_t Data_Len, u8 *Send_Data)
{
	u8 i;
	for(i = 0;i < Data_Len;i++){
	    if(Send_Data[i] == '\0')
		break;
	    USART_SendData(USARTx,Send_Data[i]);   
		
        }
	return;
}

void USART_SendDataPacketNoAscii(USART_TypeDef* USARTx, uint16_t Data, u8 *Senddata, int length)
{
	u8 i;
	for(i=0;i<length;i++){
		
          USART_SendData(USARTx,Senddata[i]);   
		
        }
	return;
}
void uart_send_sombufall(unsigned char *ptr,unsigned int k)
{	
	u8 i;
	for(i=0;i<k;i++)
		USART_SendData(USART1,ptr[i]);   
	return;
}



void Wcdma_main(void)
{
      u8 i,loop;
      u32 timeout;
	//first_card();
	open_wcdma_modem();	

	goto_xy(0x00,0x00); 
	print_str_16_16("WCDMA���ڳ�ʼ��--"); 
        loop = 3;
	while(loop--)
          {
          for(i=0;i<10;i++)
          USART_SendData(USART1,'M');       
          delay(550);          
          RxCounter = 0;
          goto_xy(0x20,0x00); 
          print_str_16_16("WCDMA���ݽ�����---");
          delay(5500);          
          timeout = 10;//1000000;
          for(;;)
            {
            if((timeout==0)||(RxCounter>10))
              break; 
            timeout-- ;           
            }                  
          //print_str_16_16(RxBuffer);
          }
	//memcpy(Creditcard_Readdata ,RxBuffer,50);

	goto_xy(0x40,0x00);	
	print_str_16_16("WCDMA���ݽ������"); 	
	

}

