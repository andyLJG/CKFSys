#include "stm32f10x_conf.h"
#include "hal.h"
#include "IRrecei.h"
#include "LCD.h"
#include "KEY.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_it.h"
#include "misc.h"
#include "main.h"
#include "card.h"
#include "PWM.h"
#include "MAX485.h"
void close_card_modem(void);
void Send_card_data(u8* p,u16 num);
void GPIO_Configuration(void);
void Uart1_Configuration(u16 rate);
void Uart3_Configuration(void);
void open_card_modem(void);
//extern  void clear_zuo(void);
//extern  void clear_you(void);
//extern  u8 car_check(void);
extern void display_menu(u8 flag);
extern u8 RxBuffer[];
extern u8 RxState;
extern vu16 RxCounter;
extern u8 turn;
extern u8 money_h,money_m,money_l;
extern u8   card_no[4];//����
extern u8   old_card_no[4];//����
extern u8   old_card_no_1[4];//����
extern u8   old_card_no_2[4];//����
extern u8   machine_no[3];//���
extern u8  card_use_flag;
extern u8 fee[2];//�ۿ���
extern u8 ReadB[14];
extern u8 dianbiao_type;
//code unsigned char  intcika[]={0x02,0x00,0x06,0x46,0x30,0x30,0x30,0x37,0x31,0x03,0x77};
extern u8 display_flag_1;
extern u8 display_flag_2;
extern  u8 car_flag;
unsigned char  command[23];	//����
unsigned char keya[]={0x05,0x13,0x87,0x88,0x82,0x62};//��ԿB
unsigned int   ymoney;//���
extern u8 key;


////////////////////�����Լ�һЩ�򵥴���///////////////////////////
void firstcard(void)
{
  switch(first_card())
  	          {
		    case 0:
                          close_card_modem();
                          if(key==3)display_flag_1=1;
                          if(key==4)display_flag_1=2;
                          if(key==1)display_flag_2=1;
                          if(key==2)display_flag_2=2;
                          for(i=0;i<4;i++)
                            {
                              old_card_no[i]=card_no[i];
                            }
                          
                          if(key_flag_3==1)
                          {
                          key_flag=2;//ֵΪ��־ 
                          goto_xy(0x70,0x04);
                          display_money();
                          money_audio();      //  ����������ǰ���
                          for(i=0;i<4;i++)
                            {
                              old_card_no_1[i]=old_card_no[i];
                            }
                          if(display_flag_1==1)
                          J_5_ON; 
                          }
                          if(key_flag_3==2)
                          {
                          PWM_CONFIG(0.8);//����80%�ķ��������ڵ糵ͨѶ
                          Uart1_Configuration(1200);      //���ڲ����ʵȲ�������
                          dianbiao_type=18;
                          Max485_0_send;
                          sendcom(ReadB,14);                        //���Ͷ���������ȡ����ĵ�ǰ����
                          goto_xy(0x70,0x17);
                          display_money();
                          money_audio();      //  ����������ǰ���
                          key_flag_2=2;
                          for(i=0;i<4;i++)
                            {
                              old_card_no_2[i]=old_card_no[i];
                            }
                          if(display_flag_2==1)
                            {
                              if((car_check())==2)//�������ͨѶ���ɹ�
                                {
                                  J_4_ON;
                                  Delay(500);
                                  goto_xy(0x70,0x13);
                                  print_str_16_16("�Ѿ��򿪳���Դ");
                                  Delay(500);
                                }
                              else
                                {
                                  display_flag_2=2;
                                }
                            }
                          
  			  }
                                      //�򿪼̵���
                          display_menu(1);
                          break;
  			  
  		    case 1:
                        close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("�޿�");
  			  break;
  	      	    case 2:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("�Ƿ���");
  			  break;
  		    case 3:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("��������");
  			  break;
		    case 4:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          for(i=0;i<4;i++)
                            {
                              old_card_no[i]=card_no[i];
                            }
  			  print_str_16_16("��������");
                        if(key_flag_3==1)
      {
        for(i=0;i<4;i++)
           {
             old_card_no_1[i]=old_card_no[i];
           }
      }
if(key_flag_3==2)
      {
        for(i=0;i<4;i++)
          {
            old_card_no_2[i]=old_card_no[i];
          }
      }
      delay(50000);
                          second_card();
  			  break;
		    case 5:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("������쳣");
  			  break;
                    case 6:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("���̫��");
  			  break;
                    case 7:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("д������");
  			  //money_audio(8) ;
  			  break;
  			    			    			  
  	          default:
                    close_card_modem();
		          break;	    			    			  
  	         }
  
  if(key_flag_3==1)
      {
        for(i=0;i<4;i++)
           {
             old_card_no_1[i]=old_card_no[i];
           }
      }
if(key_flag_3==2)
      {
        for(i=0;i<4;i++)
          {
            old_card_no_2[i]=old_card_no[i];
          }
      }
  
              if(((key_flag==2)&&(key_flag_3==1))||((key_flag_2==2)&&(key_flag_3==2)))         //���ˢ����ͣ���ɹ�
                {
                  delay(100);
                  if(key_flag_2==1)display_menu(8);
                  if(key_flag==1)display_menu(7);
                }
              else
                {
                  if(key_flag_3==1)
                    {
                      display_menu(9);
                    }
                  if(key_flag_3==2)
                    {
                      display_menu(10);
                    }
                  //goto_xy(0x50,0x05);	
  		  //print_str_16_16("�����°���ˢ��");
                  delay(50000);
                }
  
}
////////////////////
void secondcard(void)
{
  switch(second_card())
  	        {
		    case 0:
                          close_card_modem();
            if(key_flag_3==1)
            {
              //clear_zuo();
            }

            if(key_flag_3==2)
            {
              clear_you();
            }
                          //lcd_clear();
                          //delay(5000000); 
                          
                          if(key_flag_3==1)
                          {
                          key_flag=1;//ֵΪ��־ 
                          goto_xy(0x70,0x04);
                          display_money();
                          display_menu(7);
                          J_5_OFF;
                          }
                          if(key_flag_3==2)
                          {
                          key_flag_2=1;
                          goto_xy(0x70,0x17);
                          display_money();
                          display_menu(8);
                          J_4_OFF;
  			  }
                          Delay(500);
                          display_menu(2);
                          if(key==3)display_flag_1=0;
                          if(key==4)display_flag_1=0;
                          if(key==1)display_flag_2=0;
                          if(key==2)display_flag_2=0;
  			  break;
  			  
  		    case 1:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("�޿�");
  			  break;
  	      	    case 2:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("�Ƿ���");
  			  break;
  		    case 3:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("��������");
  			  break;
		    case 4:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("��������");
  			  break;
		    case 5:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("������쳣");
  			  break;
                    case 6:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("���̫��");
  			  break;
                    case 7:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("д������");
  			  break;
                    case 8:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("��λռ����");
  			  break;
                    case 9:
                      close_card_modem();
                          if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                          //lcd_clear();
                          //delay(50000);
			  //goto_xy(0x30,0x05);	
  			  print_str_16_16("�ÿ�δʹ��");
  			  break;  			  
  	            default:
                      close_card_modem();
		          break;	    			    			  
  	          }
          if((key_flag==1)||(key_flag_2==1))         //���ˢ�����۷ѳɹ�
              {
                display_menu(3);
                          if(key_flag_3==1)
                          {
                            
                          display_menu(7);
                          if(key_flag_2==1)display_menu(8);
                          //clear_zuo();
                          }
                          if(key_flag_3==2)
                          {
                            
                          display_menu(8);
                          if(key_flag==1)display_menu(7);
                          //clear_you();
  			  }
              }
         else                    //��������ˢ��
              {    
              display_menu(4);
              
              }
  
}
////////////////////�����Լ�һЩ�򵥴���///////////////////////////
/*----------------------------------------------------------------------
����:    card_modem_configor(void)
����:    �򿪶���ģ���Դ������ʼ������
input:   ��
output:  ��
------------------------------------------------------------------------*/
void open_card_modem(void)
{
  card_power_set;
  POWER_change_ON;
  card_power_on;
  card_cs_on;
  delay(5000000);
  card_reset_on;
  delay(5000000);
  card_reset_off;
  delay(8000000);
  card_power_lock;
}
/*----------------------------------------------------------------------
����:    close_card_modem(void)
����:   �򿪶���ģ���Դ�����رմ���
input:   ��
output:  ��
-----------------------------------------------------------------------*/
void close_card_modem(void)
{
  card_power_set;
  POWER_change_ON;
  card_power_off;
  card_cs_off;
  delay(8000000);
  card_power_lock;  
}

 
/*----------------------------------------------------------------------
����:    first_card
          (    )
����:    
input:   ��
output:  card_no,money_h,money_m,money_l�Լ�0~9 ������־
------------------------------------------------------------------------*/
unsigned char first_card(void)
{
  open_card_modem();
  delay(3500000);
  turn=50;
	do
		{
                  IWDG_ReloadCounter();	//ι��
		      if(reqest_comd()==0)
			  {
		       	break;
			  }
		}while(--turn);
   if(turn!=0)
   	{  
   	   if(lodkey_comd()==0)
   		{ if(read_comd(0x06)==0)
   			{ card_use_flag=RxBuffer[4];
   			  if(card_use_flag==0x55)
   			  	{
   			  	return (4);
   			  	}
   			  else
   			  	{
					if(read_comd(0x04)==0)
   						{
   						     money_h=RxBuffer[5];
   						     money_m=RxBuffer[4];
   						     money_l=RxBuffer[3];
   						     if(money_h==0&money_m==0&money_l==0)
   						     	{
   						     	return (6);
   						     	}
  						     else
	   						{
	   						     	if(write_comd(0x06, 0x55)==0)
	   						     		{
	   						     		return (0);
	   						     		}
	   						     	else
	   						     		{
	   						     		return(7);
	   						     		}
   						     	}
   						}
   					else
   						return(3);
   			  	}
   			
   			}
   		   else
   		   	return(3);
   		
   		}
          else
          	return (2);
   	    
   	}
   else
   	return (1);
   close_card_modem();
}
/*----------------------------------------------------------------------
����:    second_card
          (����ʱ����¿���old_card_no ,�ۿ���fee[1](H)��fee[0](L)
����:    
input:   ��
output:  0~9
------------------------------------------------------------------------*/
unsigned char second_card(void)
{
  u8 i=0;
  open_card_modem();
  delay(3500000);
  turn=50;
	do
		{
                      IWDG_ReloadCounter();	//ι��
		      if(reqest_comd()==0)
			  {
		       	break;
			  }
		}while(--turn);
   if(turn!=0)

   	{
 ////////////////////
if(key_flag_3==1)
      {
        for(i=0;i<4;i++)
           {
             old_card_no[i]=old_card_no_1[i];
           }
      }
if(key_flag_3==2)
      {
        for(i=0;i<4;i++)
          {
            old_card_no[i]=old_card_no_2[i];
          }
      }
//       for(i=0;i<4;i++)
//  {
//    old_card_no[i]=card_no[i];
//  }
  ///////////////////
          if((card_no[0]==old_card_no[0])&&(card_no[1]==old_card_no[1])&&(card_no[2]==old_card_no[2])&&(card_no[3]==old_card_no[3]))
	   		{
			   	   if(lodkey_comd()==0)
			   		{ delay(1000);
                                          if(read_comd(0x06)==0)
			   			{ card_use_flag=RxBuffer[4];
			   			  if(card_use_flag!=0x55)
			   			  	{
			   			  	return (9);
			   			  	}
			   			  else
			   			  	{
								if(value_comd()==0)
			   						{
                                                                                delay(1000);
			   						     	if(write_comd(0x06, 0x00)==0)
				   						     	{
				   						   	return (0);
				   						     	}
				   						else
				   						     	{
				   						     	return(7);
				   						     	}
			   						     	
			   						}
			   					else
			   						return(3);
			   			  	}
			   			
			   			}
			   		   else
			   		   	return(3);
			   		
			   		}  	          

         	 	else
          			return (2);
   		}
   	   else
              return (8);
              
   	}
   else
   	return (1);
   close_card_modem();
}


/*----------------------------------------------------------------------
����:    read_moldem_no 02FF01674103
          (��02 ff 01 67 99 03,��Ӧ0x02��0x01��0x02��0x00��01��02��03)
����:  ��ȡ����ģ���ţ����1�ֽ�
input:   ��
output:  ״̬0��1��ģ����
------------------------------------------------------------------------*/

unsigned char  read_modem_no(void)
{     goto_xy(0x20,0x08);   
      print_str_16_16("������");
      unsigned char k;
        command[0]=0x02;
        command[1]=0xff;//����ѯ������������Ч��Χ���Ƿ��п�����
        command[2]=0x01;
        command[3]=0x67;//=0,�������߷�Χ��IDLE״̬�Ŀ�(HALT״̬�ĳ���)
                          //=1,�������߷�Χ�ڵ����п�
        command[4]=0x99;//(0xFF^1^0X67);
        command[5]=0x03;
       // return WRC500_MOD();
        for(k=0;k<(command[2]+5);k++)
                {
                    USART_SendData(USART3,command[k]);//�����ʽ����,���ش�����Ϣ                    
                   RxCounter=0;
                   }
        delay(400000);
        if((RxBuffer[RxCounter-1] == 0x03)&&(RxState == 0xFF) )
                {                  
                goto_xy(0x20,0x08); 
                print_str_16_16("ģ���Ŷ��ɹ�");
                RxState = 0x00;
                goto_xy(0x20,0x12);	
                RxBuffer[0]=RxBuffer[4];
         	  print_num16_char_num(1);
                return(0);
                }
           else 
           {    goto_xy(0x20,0x08); 
                print_str_16_16("ģ���ų���");
                 return(1);
           }
          
          
}

/*----------------------------------------------------------------------
����:    reqest_comd()
;;send=02 01 01 51 51 03
;�п���020108002CB5CF340804006703
;�޿���020101FFFF03
����:    �������Ч�ķ�Χ���Ƿ��п�����,��ѡ��һ���¿�ʱ,������á�
input:   ��
output:  ״ֵ̬��MI_OK��MI_QUIT��SPI_ERR����������80~87
------------------------------------------------------------------------*/

unsigned char reqest_comd(void)
    {unsigned char k;
        // goto_xy(0x30,0x08); 
           //     print_str_16_16("Ѱ����ʼ");
        command[0]=0x02;
        command[1]=0x01;//����ѯ������������Ч��Χ���Ƿ��п�����
        command[2]=0x01;
        command[3]=0x51;//=0,�������߷�Χ��IDLE״̬�Ŀ�(HALT״̬�ĳ���)
                          //=1,�������߷�Χ�ڵ����п�
        command[4]=0x51;//(command[1]^command[2]^command[3]);
        command[5]=0x03;
        for(k=0;k<(command[2]+5);k++)
                {
                    USART_SendData(USART3,command[k]);       
                    RxCounter=0;
                 }
        delay(1000000);
        if((RxState == 0xFF)&&(RxBuffer[RxCounter-3] != 0xff))
        	{ 
                 //goto_xy(0x40,0x02); 
                //print_str_16_16("Ѱ���ɹ�����=");
               // goto_xy(0x40,0x12);	
                 card_no[0]=RxBuffer[7];
                 card_no[1]=RxBuffer[6];
                 card_no[2]=RxBuffer[5];
                 card_no[3]=RxBuffer[4];     
;
         	 // print_num16_char_num(4);
         	 return(0);
              }
       else 
            	{if(turn==0)
                      {
                      goto_xy(0x40,0x08); 
                      print_str_16_16("Ѱ��ʧ��");
                       delay(50000000);
                      
                      }
                 return(1);
                }
          
    }



/*----------------------------------------------------------------------
����:   mifkey(void)
����:    ͨ�����кž������㴦��,�õ�Ψһ������
input:   ����kahao[i]
output:  ����command[16]
------------------------------------------------------------------------*/
/*void mifkey(void)
{
	unsigned char i,j=0,k,m,n;//,p;
	for(i=0;i<4;i++)
	{
	//j+=kahao[i];
	}
	
	for(k=6,i=0;k>0;k--,i++)
	{  
		    m=7-k;
			//CY=0;
	        j+=keya[i];
	        n=j;
      //      j=swap(j);
			//j=_crol_(j, m);
			///command[i+13]=j^keyb[i];
            j=n;
	}
}  */ 
/*----------------------------------------------------------------------
����:    lodkey_comd()
����:    �ڶԿ����ж���д���ӡ����Ȳ���ǰ,����Կ�������֤.
        ������ĳ��������ԿA��B�봫�����Կ��ƥ��,��֤ʵ�ɹ�,��������MI��OK. 
input:   ��
output:  ״ֵ̬��MI_OK��MI_QUIT��SPI_ERR����������80~87
//�̶�����01����02��
------------------------------------------------------------------------*/

unsigned char lodkey_comd()
    {
	    unsigned char i,k;
        command[0]=0x02;
        command[1]=0x01;
        command[2]=0x09;
        command[3]=0x6c;       //������֤��ʽ
        command[4]=0x01;    //0~15����
        
	command[5]=0x0a;
		
	    command[6]=0xff;//command[14];
	    command[7]=0xff;//command[15];
	    command[8]=0xff;//command[16];
	    command[9]=0xff;//command[17];
	    command[10]=0xff;//command[18];  
        command[11]=0xff;//command[0];
        command[12]=command[1];
        for(i=2;i<12;i++)
            {
                command[12]=command[12]^command[i];
            }
        //command[11]=~command[11];
        command[13]=0x03;
        for(k=0;k<(command[2]+5);k++)
                {
                    USART_SendData(USART3,command[k]);       
                    RxCounter=0;
                 }
        delay(1000000);
        if((RxState == 0xFF)&&(RxBuffer[RxCounter-3] == 0x4c))
        	{ 
                 //goto_xy(0x50,0x08); 
                //print_str_16_16("��֤����ɹ�");
                return(0);
                
              }
       else
            	{
                  /*
                  if(key_flag_3==1)
                    {
                      goto_xy(0x70,0x04); 
                      print_str_16_16("��֤����ʧ��");
                    }
                  if(key_flag_3==2)
                    {
                      goto_xy(0x70,0x17); 
                      print_str_16_16("��֤����ʧ��");
                    }
                  */
            	  
                return(1);
            	}
          
       // return WRC500_MOD();
    }  
 /*----------------------------------------------------------------------
����:    mifs_read
����:    ����ѡ��ͨ����֤�󣬶�ȥһ��16�ֽڵĿ�
input:   i(�����ų���4<=i<=�����ų���4+3)
output:  ״ֵ̬��MI_OK��MI_QUIT��SPI_ERR����������80~87
------------------------------------------------------------------------*/
unsigned char read_comd(unsigned char i)//���ַ
    {  unsigned char k;
        command[0]=0x02;
        command[1]=0x01;//�ӿ�����Ӧ��ַ�ж���һ��16�ֽڵĿ�
        
        command[2]=0x02;
        command[3]=0x72;
        command[4]=i;
        command[5]=(command[1]^command[2]^command[3]^command[4]);
        command[6]=0x03;
        for(k=0;k<(command[2]+5);k++)
                {
                    USART_SendData(USART3,command[k]);       
                    RxCounter=0;
                 }
        delay(1000000);
        if((RxState == 0xFF)&&(RxBuffer[RxCounter-3] != 0x01))
        	{ 
                //goto_xy(0x60,0x02); 
               // print_str_16_16("�����ɹ����Ϊ");
                  RxBuffer[0]=RxBuffer[6];
                 RxBuffer[1]=RxBuffer[5];
                 RxBuffer[2]=RxBuffer[4];
                 RxBuffer[3]=RxBuffer[3]; 
               // goto_xy(0x60,0x12);	
         	 // print_num16_char_num(4);
         	 return(0);
              }
       else
            	{
            	  goto_xy(0x60,0x10); 
                print_str_16_16("����ʧ��");
                return(1);
            	}
       // return WRC500_MOD();
    }

/*----------------------------------------------------------------------
����:    mifs_write
����:    ����ѡ��ͨ����֤��д��һ��16�ֽڵĿ�
input:   i(�����ų���4<=i<=�����ų���4+3)�����ַ
output:  ״ֵ̬��MI_OK��MI_QUIT��SPI_ERR����������80~87
------------------------------------------------------------------------*/

unsigned char write_comd(unsigned char i,unsigned char use_times)
    {
          unsigned char k;
        command[0]=0x02;
        command[1]=0x01;
        command[2]=0x12;
        command[3]=0x77;       //������֤��ʽ
        command[4]=i;    //0~15����
        
	command[5]=0x60;
		
	    command[6]=use_times;//00;//command[14];
	    command[7]=0x04;//command[15];
	    command[8]=0x06;//command[16];
	    command[9]=0xff;//command[17];
	    command[10]=0xff;//command[18];  
        command[11]=0xff;//command[0];
         command[21]=0x01;
        for(k=2;k<21;k++)
            {
                command[21]=command[21]^command[k];
            }
        //command[11]=~command[11];
        command[22]=0x03;
        for(k=0;k<(command[2]+5);k++)
                {
                    USART_SendData(USART3,command[k]);       
                    RxCounter=0;
                 }
        delay(1000000);
        if((RxState == 0xFF)&&(RxBuffer[2] == 0x10))
        	{ 
                // goto_xy(0x80,0x08); 
                //print_str_16_16("д���ɹ�");
                 //               goto_xy(0x90,0x02);	
         	  //print_num16_char_num(RxCounter);
         	  return(0);
                
              }
       else
            	{
            	  if(key_flag_3==1)goto_xy(0x60,0x04);
                          if(key_flag_3==2)goto_xy(0x60,0x17);
                print_str_16_16("д��ʧ��");
                return(1);
            	}
    }

/*----------------------------------------------------------------------
����:    mifs_value
����:    �Կ����ڵ�ĳһ����м�,�ÿ����Ϊֵ���ʽ,��֧���Զ����͡�
input:   ��
output:  ״ֵ̬��MI_OK��MI_QUIT��SPI_ERR����������80~87
         �̶���04�����
------------------------------------------------------------------------*/
unsigned char value_comd(void)//j��ַ������Ϊֵ��ģʽ
    {
	   unsigned char i;
        command[0]=0x02;
        command[1]=0x01;
        command[2]=0x06;
        command[3]=0x2d;
        command[4]=0x04;/////////////kuaidizhi
//***************************************************
    
        command[5]=0x00;
        command[6]=0x00;
        command[7]=fee[1];
        command[8]=fee[0];
       command[9]=command[1];
//***************************************************

        for(i=2;i<9;i++)
        {
             command[9]=command[9]^command[i];
        }
         //command[9]=0x21;
        command[10]=0x03;
        for(i=0;i<(command[2]+5);i++)
                {
                    USART_SendData(USART3,command[i]);       
                    RxCounter=0;
                 }
        delay(1000000);
        if((RxState == 0xFF)&&(RxBuffer[2] == 0x04))
        	{ 
                 
                  if(key_flag_3==1)
                    {
                      goto_xy(0x50,0x04); 
                      //display_menu(9);
                    }
                  if(key_flag_3==2)
                    {
                      goto_xy(0x50,0x17); 
                      //display_menu(10);
                    }
                print_str_16_16("�ۿ�ɹ�");
                 RxBuffer[0]=RxBuffer[3];
                 RxBuffer[1]=RxBuffer[4];
                 RxBuffer[2]=RxBuffer[5];
                 RxBuffer[3]=RxBuffer[6]; 
                //goto_xy(0xa0,0x12);	
         	//  print_num16_char_num(4);
                return(0);
              }
       else
            	{
            	if(key_flag_3==1)
                    {
                      goto_xy(0x50,0x04); 
                      //display_menu(9);
                    }
                  if(key_flag_3==2)
                    {
                      goto_xy(0x50,0x17); 
                      //display_menu(10);
                    }
                print_str_16_16("�ۿ�ʧ��");
                return(1);
            	}
        //return WRC500_MOD();
        
    }
//=====================================================*/
/*
void  deng(unsigned char kk)
{
  unsigned char l,la;
  int_uart(0xfa);
  P4=0x09;
  l=3;
  do
  {
     P33=1;
	 delay(5);
	 P33=0;
	 delay(5);
     P33=1;
     uart_send(0x66);
     uart_send(0x05);
     switch(kk)
	 {
           case 0x01: uart_send(0x01);uart_send(0x62);break;
            case 0x02: uart_send(0x11);uart_send(0x72);break;
	   case 0x03: uart_send(0x04);uart_send(0x67);break;
	   case 0x04: uart_send(0x14);uart_send(0x77);break;

	   case 0x05: uart_send(0x05);uart_send(0x66);break;
	   case 0x06: uart_send(0x06);uart_send(0x65);break;

	   case 0x09: uart_send(0x43);uart_send(0x20);break;
	   case 0x0A: uart_send(0x44);uart_send(0x27);break;

	   case 0x07: uart_send(0x41);uart_send(0x22);break;
	   case 0x08: uart_send(0x42);uart_send(0x21);break;

	   case 0x0b: uart_send(0x10);uart_send(0x73);break;
	   case 0x0c: uart_send(0x20);uart_send(0x43);break;
	   default: break;
	 }
   uart_send(0x88);
   la=uart_rec(10000);
   if(la==0x66)
   {
    break;
   }
  }while(--l);
  P4=0x08;
}
void  jiliang(unsigned char canshu[],unsigned char chewei)
{
   unsigned char l,la;
  int_uart(0xfa);
  P4=0x09;
  l=3;
  do
  {
     P33=1;
	 delay(5);
	 P33=0;
	 delay(5);
     P33=1;
     uart_send(0x66);
     uart_send(0x05);
     switch(chewei)
	 {
       case 0x01: uart_send(0x53);uart_send(0x30);break;
       case 0x04: uart_send(0x54);uart_send(0x37);break;
	   default: break;
	 }
   uart_send(0x88);
   la=uart_rec(10000);
   if(la==0x66)
   {
        la=uart_rec(3000);
		for(l=0;l<la;l++)
		{
	     canshu[l]=uart_rec(3000);
		}
		break;
   }
   else
   {
		for(l=0;l<la;l++)
		{
	     canshu[l]=0x00;
		}
   }
  }while(--l);
  P4=0x08;
}
unsigned long hc(unsigned char canshu[])
{
  unsigned long  lk;
  lk=canshu[0];
  lk=lk<<8;
  lk=lk+canshu[1];
  lk=lk<<8;
  lk=lk+canshu[2];
  lk=lk<<8;
  lk=lk+canshu[3];
  return lk;
}
void fenli(unsigned char canshu[],unsigned long kk)
{
 canshu[0]= (kk>>24)&0xff;
 canshu[1]= (kk>>16)&0xff;
 canshu[2]= (kk>>8)&0xff;
 canshu[3]= kk&0xff;
}
void  savejilu(unsigned char buf1[])
{
 unsigned char  xdata ji_lu[64];
 unsigned char  xdata xtime[7];
 unsigned long  zan;
 unsigned char  loop,xor;
 ji_lu[0]=0xee;
 ji_lu[1]=buf1[1];
 read_block(liushui,xtime,4);
 ji_lu[2]=xtime[0];
 ji_lu[3]=xtime[1];
 ji_lu[4]=xtime[2];
 ji_lu[5]=xtime[3];
 zan=hc(xtime);
 zan=zan+1;
 fenli(xtime,zan);
 write_block(liushui,xtime,4);
 read_block(diqv,xtime,2);
 ji_lu[6]=xtime[0];
 ji_lu[7]=xtime[1];
 ji_lu[8]=kahao[0];
 ji_lu[9]=kahao[1];
 ji_lu[10]=kahao[2];
 ji_lu[11]=kahao[3];
 ji_lu[12]=0x01;
 ji_lu[13]=buf1[2];
 ji_lu[14]=buf1[3];
 read_block(rate+6,xtime,2);
 ji_lu[15]=xtime[0];
 ji_lu[16]=xtime[1];
 switch(buf1[0])
 {
  case 0x01:     
                ji_lu[17]=zuoche[5];
				ji_lu[18]=zuoche[6];
				ji_lu[19]=zuoche[7];
				ji_lu[20]=zuoche[8];
				ji_lu[21]=zuoche[9];
			    ji_lu[22]=zuoche[10];
				ji_lu[23]=zuoche[11];
                 break;
  case 0x02:     
                ji_lu[17]=youche[5];
				ji_lu[18]=youche[6];
				ji_lu[19]=youche[7];
				ji_lu[20]=youche[8];
				ji_lu[21]=youche[9];
			    ji_lu[22]=youche[10];
				ji_lu[23]=youche[11];
                 break;
  default:       break;
 }
 get_time(xtime);
 ji_lu[24]=0x20;
 ji_lu[25]=((xtime[4]/10)*16)+(xtime[4]%10);
 ji_lu[26]=((xtime[3]/10)*16)+(xtime[3]%10);
 ji_lu[27]=((xtime[2]/10)*16)+(xtime[2]%10);
 ji_lu[28]=((xtime[1]/10)*16)+(xtime[1]%10);
 ji_lu[29]=((xtime[0]/10)*16)+(xtime[0]%10);
 ji_lu[30]=xtime[5];
 ji_lu[31]=xtime[6];

 ji_lu[32]=0x00;
 ji_lu[33]=0x00;
 ji_lu[34]=buf1[4];
 ji_lu[35]=buf1[5];

 ji_lu[36]=0x00;
 ji_lu[37]=0x00;
 ji_lu[38]=buf1[6];
 ji_lu[39]=buf1[7];

 ji_lu[40]=0x00;
 ji_lu[41]=0x00;
 ji_lu[42]=buf1[8];
 ji_lu[43]=buf1[9];

 ji_lu[44]=shujv1[1];
 ji_lu[45]=shujv1[2];
 ji_lu[46]=shujv1[3];
 ji_lu[47]=shujv1[4];
 read_block(mbno,xtime,4);
 ji_lu[48]=xtime[0];
 ji_lu[49]=xtime[1];
 ji_lu[50]=xtime[2];
 ji_lu[51]=xtime[3];

 ji_lu[52]=shujv1[5];
 ji_lu[53]=shujv1[6];
 ji_lu[54]=shujv1[7];
 ji_lu[55]=shujv1[8];

 ji_lu[56]=xtime[0];
 ji_lu[57]=xtime[1];
 ji_lu[58]=xtime[2];
 ji_lu[59]=xtime[3];

 ji_lu[60]=shujv1[9];
 ji_lu[61]=buf1[0];
 xor=ji_lu[0];
 for(loop=1;loop<62;loop++)
 {
  xor=xor^ji_lu[loop];
 }
 read_block(saveaddr,xtime,4);
 zan=hc(xtime);
 HW_SPI_Init();
 w080fastd(zan);
 for(loop=0;loop<32;loop++)
 {
	AAI_byte_program_2(ji_lu[loop+loop],ji_lu[loop+loop+1]);
 }
 end080();
 zan=zan+64;
 fenli(xtime,zan);
 write_block(saveaddr,xtime,4);
 if((0x400000-zan)<0x800)
 {
  systemerr=1;
  deng(0x06);
  	 ji_lu[0]=0x44;
	 write_block(erradd+3,ji_lu,1);
 }
}
void t_qvche(unsigned char key2,unsigned char jilu[])
{
 unsigned char  xdata time[7],time1[7];
 unsigned char  xdata c_canshu[12];
 unsigned int   u_v,u_i,u_p;
 unsigned int   u_time,u_money,d_money,z_money;
 unsigned long   xvhao;
       get_time(time);
       switch(jilu[0])
	   {
	       case 0x00:  
           case 0x04:
		               {
                          if(shujv1[11]==0)
						  {
							 switch(key2)
							 {
							  case 0x01:   deng(0x01); break;
							  case 0x04:   deng(0x03); break;
							 }
		                     jilu[0]=0x01;
							 jilu[1]=kahao[0];
			                 jilu[2]=kahao[1];
			                 jilu[3]=kahao[2];
			                 jilu[4]=kahao[3];
		                     jilu[5]=time[4];
							 jilu[6]=time[3];
							 jilu[7]=time[2];
							 jilu[8]=time[1];
							 jilu[9]=time[0];
							 jilu[10]=time[5];
							 jilu[11]=time[6];

                             jilu[12]=0x00;
							 jilu[13]=0x00;

							 jilu[14]=0x00;
							 jilu[15]=0x00;

                             jilu[16]=(ymoney>>8)&0xff;
							 jilu[17]=ymoney&0xff;
							  shujv1[9]=time[3];
							  shujv1[10]=time[2];
							  shujv1[11]=shujv1[11]+0x01;
                              time[5]=mifs_write(0x06);
                              closezlg500();
							   lcd_clear();
							   goto_xy(0x30,0x08); 
							   print_str_16_16("��ǰʱ��: ");
							   print_num16_16(time[1]/10);
							   print_num16_16(time[1]%10);
							    print_asi(0x3a);
							    print_num16_16(time[0]/10);
							    print_num16_16(time[0]%10);
							   u_time=ymoney;
							   goto_xy(0x40,0x08); 
							   print_str_16_16("�������:");
							   print_num16_16(u_time/10000);
							   u_time=u_time%10000;
							   print_num16_16(u_time/1000);
							   u_time=u_time%1000;
							   print_num16_16(u_time/100);
							   print_asi(0x2e);
							   u_time=u_time%100;
							   print_num16_16(u_time/10);
							   print_num16_16(u_time%10);
							   delay(50000);
						 }
						 else
						 {
						    closezlg500();
                            lcd_clear();
                            goto_xy(0x30,0x0b);
                            print_str_16_16("δ���㿨");
							goto_xy(0x40,0x0b);
                            print_str_16_16("��������");
							delay(80000);
						 }
	                         
					   }
		               break;
			case 0x01:  
			case 0x02:  
		               {
					    if((jilu[1]==kahao[0])&&(jilu[2]==kahao[1])
						     &&(jilu[3]==kahao[2])&&(jilu[4]==kahao[3]))
						{
							     time1[4]=jilu[5];
								 time1[3]=jilu[6];
								 time1[2]=jilu[7];
								 time1[1]=jilu[8];
								 time1[0]=jilu[9];
								 switch(key2)
								 {
								  case 0x01: jiliang(c_canshu,0x01);  break;
								  case 0x04: jiliang(c_canshu,0x04);  break;
								 }
								    u_v=c_canshu[0];
									u_v=u_v<<8;
								    u_v=u_v+c_canshu[1];
									u_i=c_canshu[2];
									u_i=u_i<<8;
								    u_i=u_i+c_canshu[3];
									u_p=c_canshu[4];
									u_p=u_p<<8;
								    u_p=u_p+c_canshu[5];
								 u_time=mathtime(time,time1);
							     u_money=time_to_money(time,key2);
								 d_money=dianfei(u_p,key2);
	                             z_money=d_money+u_money;
								 jilu[0]=z_money&0xff;
								 jilu[1]=(z_money>>8)&0xff;
								 //jilu[0]=0x00;
								 //jilu[1]=0x01;
								 time1[6]=mifs_value(jilu);
								 if(time1[6]==0)
								 {
								   shujv1[9]=0x00;
							       shujv1[10]=0x00;
							       shujv1[11]=shujv1[11]-0x01;
                                   xvhao=shujv1[1];
                                   xvhao=xvhao<<8;
								   xvhao=xvhao+shujv1[2];
								   xvhao=xvhao<<8;
								   xvhao=xvhao+shujv1[3];
								   xvhao=xvhao<<8;
								   xvhao=xvhao+shujv1[4];
								   xvhao=xvhao+1;
								   shujv1[1]=(xvhao>>24)&0xff;
								   shujv1[2]=(xvhao>>16)&0xff;
								   shujv1[3]=(xvhao>>8)&0xff;
								   shujv1[4]=xvhao&0xff;
                                   time[0]=mifs_write(0x06);
	                               closezlg500();
                                  switch(key2)
								   {
								     case 0x01: deng(0x02);
  								                deng(0x09);
									            break;
								     case 0x04: deng(0x04);
   								                deng(0x0a);
									            break;
								   }
								   disp_feilv(u_time,u_money,d_money,ymoney);
                                   switch(key2)
								   {
								     case 0x01: c_canshu[0]=0x01;   break;
								     case 0x04: c_canshu[0]=0x02;   break;
								   }
								   c_canshu[1]=0x01;

								   c_canshu[2]=(u_p>>8)&0xff;
								   c_canshu[3]=u_p&0xff;

								   c_canshu[4]=(ymoney>>8)&0xff;
								   c_canshu[5]=ymoney&0xff;
                                   ymoney=ymoney-z_money;
								   c_canshu[6]=(ymoney>>8)&0xff;
								   c_canshu[7]=ymoney&0xff;
								   savejilu(c_canshu);
			                       for(u_v=0;u_v<20;u_v++)
								   {
									 jilu[u_v]=0x00;
								   }
								 }
                                 closezlg500();
								
								 
					   }
					   else
					   {
                         closezlg500();
					   }
		               }break;
          default:   closezlg500(); break;
        }
}

void c_qvche(unsigned char jilu[],unsigned char key2)
{
 unsigned char  xdata time[7],time1[7];
 unsigned char  xdata c_canshu[12];
 unsigned int   u_v,u_i,u_p;
 unsigned int   u_time,u_money,d_money,z_money;
 unsigned long  xvhao;
       get_time(time);
       switch(jilu[0])
	   {
	       case 0x00: 
           case 0x04: 
		               {
					       if(shujv1[11]==0)
						   {
							 switch(key2)
							 {
							  case 0x02:   
							               deng(0x01); 
										   deng(0x07); 
							               break;
							  case 0x03:   deng(0x03);
 							               deng(0x08); 
							               break;
							 }
		                     jilu[0]=0x02;
							 jilu[1]=kahao[0];
			                 jilu[2]=kahao[1];
			                 jilu[3]=kahao[2];
			                 jilu[4]=kahao[3];
		                     jilu[5]=time[4];
							 jilu[6]=time[3];
							 jilu[7]=time[2];
							 jilu[8]=time[1];
							 jilu[9]=time[0];
							 jilu[10]=time[5];
							 jilu[11]=time[6];

                             jilu[12]=0x00;
							 jilu[13]=0x00;

							 jilu[14]=0x00;
							 jilu[15]=0x00;

                             jilu[16]=(ymoney>>8)&0xff;
							 jilu[17]=ymoney&0xff;

							  shujv1[9]=time[3];
							  shujv1[10]=time[2];
							  shujv1[11]=shujv1[11]+0x01;
                              time[5]=mifs_write(0x06);
                              closezlg500();
                                lcd_clear();
							    LCD_Power = 0;
								delay(2);
							    LCD_Power = 1;
								LCD_LIGHT = 1;
								lcd_reset();
								lcd_initial();
								lcd_clear(); 
							   //disp_time1();
							   goto_xy(0x30,0x08); 
							   print_str_16_16("��ǰʱ��: ");
							   print_num16_16(time[1]/10);
							   print_num16_16(time[1]%10);
							    print_asi(0x3a);
							    print_num16_16(time[0]/10);
							    print_num16_16(time[0]%10);
							   u_time=ymoney;
							   goto_xy(0x40,0x08); 
							   print_str_16_16("�������:");
							   print_num16_16(u_time/10000);
							   u_time=u_time%10000;
							   print_num16_16(u_time/1000);
							   u_time=u_time%1000;
							   print_num16_16(u_time/100);
							   print_asi(0x2e);
							   u_time=u_time%100;
							   print_num16_16(u_time/10);
							   print_num16_16(u_time%10);
							   delay(50000);
							}
							else
							{
							     closezlg500();
                                lcd_clear();
                                goto_xy(0x30,0x0b);
                                print_str_16_16("δ���㿨");
							    goto_xy(0x40,0x0b);
                                print_str_16_16("��������");
							    delay(80000);
							}
	                         

					   }
		               break;
			case 0x01:  
			            {
	                         closezlg500();
							 if((jilu[1]==kahao[0])&&(jilu[2]==kahao[1])
						     &&(jilu[3]==kahao[2])&&(jilu[4]==kahao[3]))
						     {
									 switch(key2)
									 {
									  case 0x02:   
									               deng(0x01); 
												   deng(0x07); 
									               break;
									  case 0x03:   deng(0x03);
		 							               deng(0x08); 
									               break;
									 }
				                     jilu[0]=0x02;	
								lcd_clear();
							    LCD_Power = 0;
								delay(2);
							    LCD_Power = 1;
								LCD_LIGHT = 1;
								lcd_reset();
								lcd_initial();
								lcd_clear(); 
							   goto_xy(0x30,0x08); 
							   print_str_16_16("��ǰʱ��: ");
							   print_num16_16(time[1]/10);
							   print_num16_16(time[1]%10);
							    print_asi(0x3a);
							    print_num16_16(time[0]/10);
							    print_num16_16(time[0]%10);
							   u_time=ymoney;
							   goto_xy(0x40,0x08); 
							   print_str_16_16("�������:");
							   print_num16_16(u_time/10000);
							   u_time=u_time%10000;
							   print_num16_16(u_time/1000);
							   u_time=u_time%1000;
							   print_num16_16(u_time/100);
							   print_asi(0x2e);
							   u_time=u_time%100;
							   print_num16_16(u_time/10);
							   print_num16_16(u_time%10);
							   delay(50000);
							   }
					    }
		                break;
			case 0x02:  
		               {
					    if((jilu[1]==kahao[0])&&(jilu[2]==kahao[1])
						     &&(jilu[3]==kahao[2])&&(jilu[4]==kahao[3]))
						{
							     time1[4]=jilu[5];
								 time1[3]=jilu[6];
								 time1[2]=jilu[7];
								 time1[1]=jilu[8];
								 time1[0]=jilu[9];
								 switch(key2)
								 {
								  case 0x02: jiliang(c_canshu,0x01);  break;
								  case 0x03: jiliang(c_canshu,0x04);  break;
								 }
								    u_v=c_canshu[0];
									u_v=u_v<<8;
								    u_v=u_v+c_canshu[1];
									u_i=c_canshu[2];
									u_i=u_i<<8;
								    u_i=u_i+c_canshu[3];
									u_p=c_canshu[4];
									u_p=u_p<<8;
								    u_p=u_p+c_canshu[5];
								 u_time=mathtime(time,time1);
							     u_money=time_to_money(time,key2);
								 d_money=dianfei(u_p,key2);
	                             z_money=d_money+u_money;
								 jilu[0]=z_money&0xff;
								 jilu[1]=(z_money>>8)&0xff;
								 //jilu[0]=0x00;
								 //jilu[1]=0x01;
								 time1[6]=mifs_value(jilu);
								 if(time1[6]==0)
								 {
								   shujv1[9]=0x00;
							       shujv1[10]=0x00;
							       shujv1[11]=shujv1[11]-0x01;
								   xvhao=shujv1[1];
                                   xvhao=xvhao<<8;
								   xvhao=xvhao+shujv1[2];
								   xvhao=xvhao<<8;
								   xvhao=xvhao+shujv1[3];
								   xvhao=xvhao<<8;
								   xvhao=xvhao+shujv1[4];
								   xvhao=xvhao+1;
								   shujv1[1]=(xvhao>>24)&0xff;
								   shujv1[2]=(xvhao>>16)&0xff;
								   shujv1[3]=(xvhao>>8)&0xff;
								   shujv1[4]=xvhao&0xff;
                                   time[0]=mifs_write(0x06);
                                   closezlg500();
                                   switch(key2)
								   {
								     case 0x02: deng(0x02); deng(0x09);  break;
								     case 0x03: deng(0x04); deng(0x0a); break;
								   }
								   disp_feilv(u_time,u_money,d_money,ymoney);
                                   switch(key2)
								   {
								     case 0x02: c_canshu[0]=0x01;   break;
								     case 0x03: c_canshu[0]=0x02;   break;
								   }
								   c_canshu[1]=0x02;

								   c_canshu[2]=(u_p>>8)&0xff;
								   c_canshu[3]=u_p&0xff;

								   c_canshu[4]=(ymoney>>8)&0xff;
								   c_canshu[5]=ymoney&0xff;
                                   ymoney=ymoney-z_money;
								   c_canshu[6]=(ymoney>>8)&0xff;
								   c_canshu[7]=ymoney&0xff;
								   savejilu(c_canshu);
								   for(u_v=0;u_v<20;u_v++)
								   {
									 jilu[u_v]=0x00;
								   }
								 }
                                 closezlg500();
								
					   }
					   else
					   {
                         closezlg500();
					   }
		               }break;
          default:    break;
        }
}

void  do60_poche(unsigned char key1_key)
{
	 switch(key1_key)
	 {
	   case 0x01: 
	               t_qvche(0x01,zuoche); 
   				   write_block(zuo,zuoche,18);
            
				   break;
	   case 0x02:     c_qvche(zuoche,0x02); 
 	               write_block(zuo,zuoche,18);
				   break;
	   case 0x03:     c_qvche(youche,0x03);
	                  write_block(you,youche,18); 
				   break;
	   case 0x04:  t_qvche(0x04,youche);
                   write_block(you,youche,18);
	               break;
	   default: break;	
	 }
}
void xiaoer(unsigned char key1_key)
{
  unsigned char  xdata time[7];
  unsigned long  xdata uutime;
  get_time(time);
  if((key1_key==0x01)||(key1_key==0x02)||(key1_key==0x03)||(key1_key==0x04))
  {
       uutime=0;
       uutime=money_to_time(time,ymoney);
       lcd_clear();
       goto_xy(0x30,0x07);
       print_str_16_16("��������");
       goto_xy(0x40,0x07);
       print_str_16_16("ֻ��ͣ��");
       print_num16_16(uutime/600);
       uutime=uutime%600;
       print_num16_16(uutime/60);
       print_asi(0x3a);
       uutime=uutime%60;
       print_num16_16(uutime/10);
       print_num16_16(uutime%10);
       delay(10000);
  	 switch(key1_key)
	 {
	   case 0x01: 
	   case 0x02:
	               t_qvche(0x01,zuoche);
				   write_block(zuo,zuoche,18);
				   break;
	   case 0x03:  
	   case 0x04:        
	               t_qvche(0x04,youche); 
			       write_block(you,youche,18);   
	               break;
	   default: break;	
	 }
  }
  else
  {
	  lcd_clear();
	  goto_xy(0x10,0x08); 
	  print_num16_char(key1_key);
	  goto_xy(0x40,0x09); 
	  print_str_16_16("��������");
	  goto_xy(0x50,0x0b);
	  print_str_16_16("ֻ��ͣ��");
	  delay(10000);
  }
  closezlg500();
}
bit chulipo()
{
  unsigned char  xdata time[7],rate1[16];
  unsigned int   fmoney;
  bit   yx;
  read_block(rate,rate1,16);
  yx=0;
//  zuoche[16],youche[16]
  get_time(time);
  if(shujv1[11]!=0)
  {
       if(!qingka)
	   {
		    if(zuoche[0]!=0)
		    {
			 if((zuoche[1]==kahao[0])&&(zuoche[2]==kahao[1])
				&&(zuoche[3]==kahao[2])&&(zuoche[4]==kahao[3]))
				 {
			       yx=1;
				 }
		    }
			if(youche[0]!=0)
		    {
			  if((youche[1]==kahao[0])&&(youche[2]==kahao[1])
				&&(youche[3]==kahao[2])&&(youche[4]==kahao[3]))										
				  {
			        yx=1;
				  }
		    }
		}
		if(!yx)
		{
	      if(qingka||((shujv1[9]!=time[3])&&(time[2]!=0x01))||((time[2]-shujv1[10])>1)) 
		  {
	        lcd_clear();
			goto_xy(0x10,0x06); 
		    print_str_16_16("�ϴ�δ����"); 
			goto_xy(0x20,0x06); 
		    print_str_16_16("����:"); 
	        ymoney=0;
			time[0]=mifs_read(0x04);
			ymoney=command[4];
		    ymoney=ymoney<<8;
			ymoney=ymoney+command[3];
	
			fmoney=rate1[14];
		    fmoney=fmoney<<8;
			fmoney=fmoney+rate1[15];
			if(fmoney>=ymoney)
			{
			  time[0]=ymoney&0xff;
			  time[1]=(ymoney>>8)&0xff;
			  time[6]=mifs_value(time);
	          shujv1[10]=0x00;
			  shujv1[11]=0x00;
	          time[0]=mifs_write(0x06);
	          print_num16_16(ymoney/1000);
	          ymoney=ymoney%1000;
	          print_num16_16(ymoney/100);
	          ymoney=ymoney%100;
			  print_asi(0x2e);
	          print_num16_16(ymoney/10);
	          print_num16_16(ymoney%10);
			  yx=1;
			  delay(10000);
			}
			else
			{
	          time[0]=fmoney&0xff;
			  time[1]=(fmoney>>8)&0xff;
			  time[6]=mifs_value(time);
	          shujv1[10]=0x00;
			  shujv1[11]=0x00;
	          time[0]=mifs_write(0x06);
	          print_num16_16(fmoney/1000);
	          fmoney=fmoney%1000;
	          print_num16_16(fmoney/100);
	          fmoney=fmoney%100;
			  print_asi(0x2e);
	          print_num16_16(fmoney/10);
	          print_num16_16(fmoney%10);
			  delay(10000);
			  yx=1;
			} 
			if(qingka)
			{
			  yx=0;
			}
		  }
		  else
		  {
	        yx=0;
		  }
		}
  }
  else
  {
   yx=1;
  }
  return yx;
}
bit do_poche(unsigned char key_key)
{
  unsigned long t1;
  unsigned char b;
		  if(intcad())
		  {
		     t1=500;
		     do
			 {
		      if(FindCard()==0)
			  {
		       break;
			  }
			 }while(--t1);
			 if(t1!=0)
			 {
			     if((rmifkahao()==0)&&(mifschoose()==0))
			       {
			             mifkey();
						 if(mifcheccommandey()==0)//��֤�ɹ�
						 {
				          	b=mifs_read(0x06);//��ȡֵ  //���ݽṹ  ��־��1��+���Ѵ�����4��+�������ţ�4��+�����գ�2��+δ���������1��
							  	for(b=0;b<16;b++)
							  	{
							   		shujv1[b]=command[b+3];//������
							  	}
                                  
								 switch(shujv1[0])
							  	 {
								  case 0x60: 
								            check_rate();
								   			if(systemerr)
						                  	{
							                     lcd_clear(); 
											     goto_xy(0x10,0x0b); 
											     print_str_16_16("ϵͳ�쳣");
												 disp_err();
												deng(0x06);
							                    delay(100000);
						                  	}
						                  else
										  {
                                             deng(0x05);
								             if(key_key!=0x88)
											 {
											      if(chulipo())
												  {
											              ymoney=0;
											              b=mifs_read(0x04);
														  if(b==0)
														  {
																	  ymoney=command[4];
																	  ymoney=ymoney<<8;
											                          ymoney=ymoney+command[3];
						                                              if(ymoney>1000)
																	  {
						                                               do60_poche(key_key);
																	  }
																	  else
																	  {
						                                               xiaoer(key_key);
																	  }
																	  return  1;
														   }
														   else
														   {
		                                                     return  0;
														   }
													 }
													 else
													 {
													   lcd_clear();
                                                       goto_xy(0x10,0x0b); 
													   if(qingka)
													   {
													   	qingka=0;
                                                        print_str_16_16("���ѽ���");
													   }
													   else
													   {
	                                                     print_str_16_16("δ���㿨");
													   }
													   delay(100000);
													 }
											  }
											  else
											  {
                                                  b=mifs_read(0x04);
												  if(b==0)
												  {
													  ymoney=command[4];
													  ymoney=ymoney<<8;
							                          ymoney=ymoney+command[3];
													  closezlg500();
													  lcd_clear();
												      goto_xy(0x20,0x0b); 
												      print_str_16_16("����ѯ");
													  goto_xy(0x30,0x01);
	                                                  print_str_16_16("����:");
													  print_num16_char(kahao[0]);
													  print_num16_char(kahao[1]);
													  print_num16_char(kahao[2]);
													  print_num16_char(kahao[3]);
													  goto_xy(0x40,0x01);
	                                                  print_str_16_16("���:");
													  print_num16_16(ymoney/10000);
													   ymoney=ymoney%10000;
													   print_num16_16(ymoney/1000);
													   ymoney=ymoney%1000;
													   print_num16_16(ymoney/100);
													   print_asi(0x2e);
													   ymoney=ymoney%100;
													   print_num16_16(ymoney/10);
													   print_num16_16(ymoney%10);
													   if(shujv1[11]!=0x00)
													   {
													    goto_xy(0x50,0x01);
	                                                    print_str_16_16("������δ����");
														print_num16_char(shujv1[11]);
													   }
													   delay(500000);
													  return  1;
                                                 }
												 else
												 {
                                                   return  0;
												 }
                                              }
											}
										       closezlg500();
						                       break;
								  case 0x35: 
								               lcd_clear();
											   closezlg500(); 
											   disp_chaxun();
 											  return  1;
											  break;
								  case 0x49: 
								               closezlg500();
 											   ir_comm();
											   return  1;
											   break;
								  case 0x36: 
								               if(key_key==0x88)
                                               {
	                                            //����
				                                   closezlg500();
												   command[0]=0x01;  
												   command[1]=0x04;
												   command[2]=0x00;
												   command[3]=0x00;
												   command[4]=0x00;
												   command[5]=0x00;
												   command[6]=0x00;
												   command[7]=0x00;
												   savejilu(command);
                                                   return  1;
                                               }
                                               else
                                               {
                                                   closezlg500();
                                                    switch(key_key)
                                                    {
                                                     case 0x01:
                                                     case 0x02:  
                                                                 if((zuoche[0]==0x01)||(zuoche[0]==0x02))
                                                                 {
																   disp_time23(1);
																   return  1;
                                                                 }
                                                                 else
                                                                 {
																   qingka=1;
																   return  0;
                                                                  }
																 break;
                                                     case 0x03:
                                                     case 0x04:  
                                                                 if((youche[0]==0x01)||(youche[0]==0x02))
                                                                 {
																  disp_time33(1);
																  return  1;
                                                                 }
                                                                 else
                                                                 {
																   qingka=1;
																   return  0;
                                                                  }
																 break;
                                                     default  :   break;
                                                    }  
     											}
											   break;
                                  case 0x11: 
								               closezlg500();
 											   	for(b=0;b<6;b++)
											  	{
												  keyb[b]=shujv1[b+1];
											  	}
                                                write_block(mima,keyb,6);
											   return  1;
											   break;
								  default:
								               lcd_clear();
											   goto_xy(0x30,0x08); 
											   print_num16_char(shujv1[0]);
											   delay(100000);
								               closezlg500(); 
											   return  1;
											   break;
							     }
								 
						  }
						  else
						  {
						    closezlg500();
                            return  0;
						  }
					}
					else
					{
					 closezlg500();
                     return  0;
					}
		  }
		  else
		  {
            closezlg500();
            return  1;
		  }
    deng(0x05);
   } 
   else
   {
     closezlg500();
	 command[0]=0x44;
	 write_block(erradd,command,1);
	 systemerr=1;
	 lcd_clear(); 
     goto_xy(0x10,0x0b); 
     print_str_16_16("ϵͳ�쳣");
	 disp_err();
	 deng(0x06);
	 delay(100000);
     return  1;
   }
  closezlg500();
}
bit intcad()
{
  openzlg500();//��
  return Res500();//��λ
}
*/



















