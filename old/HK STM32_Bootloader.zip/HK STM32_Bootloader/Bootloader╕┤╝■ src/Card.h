#ifndef _card_H
#define _card_H
unsigned char read_modem_no(void);
unsigned char reqest_comd(void);
void open_card_modem(void);
void close_card_modem(void);
unsigned char first_card(void);
unsigned char second_card(void);
void firstcard(void);
void secondcard(void);
//void mifkey(void);
unsigned char lodkey_comd();
unsigned char read_comd(unsigned char i);//���ַ
unsigned char write_comd(unsigned char i,unsigned char use_times);//д����i���ÿ���־
unsigned char value_comd();//j��ַ������Ϊֵ��ģʽ
/*IC������*/
//#define card_power_on  GPIOB->BSRR = 0x00000001
//#define card_power_off  GPIOB->BSRR = 0x00010000
/*
#define card_reset_on  GPIOE->BSRR = 0x00000020
#define card_reset_off  GPIOE->BSRR = 0x00200000
#define card_power_set  GPIOA->BSRR=0x00000100
#define card_power_lock GPIOA->BSRR=0x01000000
#define card_cs_on  GPIOB->BSRR = 0x00001000
#define card_cs_off  GPIOB->BSRR = 0x10000000
*/
extern u8 diandu[20];
extern u32 i;
extern u8 key_flag;
extern u8 key_flag_2;
extern u8 key_flag_3;
#endif