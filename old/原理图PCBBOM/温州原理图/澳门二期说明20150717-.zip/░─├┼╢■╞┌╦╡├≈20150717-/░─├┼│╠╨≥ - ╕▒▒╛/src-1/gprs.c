#include "stm32f10x_conf.h"
#include "hal.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Count.h"
#include "Key.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include "Gprs_online.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_it.h"
#include "string.h"
#include "misc.h"
#include "math.h"
#include "main.h"
#include "Card.h"
#include "MemoryAssign.h"
#include "Do_Task.h"
//write by andyluo in 2010

////***************************************ASCII ת��Ϊ��BCD********************************************************
unsigned char asic_to_hex(unsigned char rr)
{
  unsigned char c1;

  if(rr<0x3A)
  	c1=rr-0x30;
  else
  	c1=rr-0x37;
  return c1;
}

//andyluo
unsigned char twoasic_to_oenhex(unsigned char *recvgsmproc,u8 ASCII)
{//2///2=1+2=1   1+1=1  36 41 36 44 ==14
  unsigned short i,j;
  unsigned char hex,hex1,hex2,hex3;
  
  //hex3 = 4;
  hex3 = 2;
  j = 0;
  for(i=0;;i++){
  	
    j =i*hex3;	
    if(recvgsmproc[j+1] == '*'){
  		
      recvgsmproc[i+1] = '*';		
      break; 		
    }
  	
    hex = asic_to_hex(recvgsmproc[j+1]);
    hex1 = asic_to_hex(recvgsmproc[j+2]);
    hex = hex<<4;
    hex = hex+hex1;
    hex2 = hex - '9';//31		
	
    if(hex3 == 2){
		
      recvgsmproc[i+1] = hex2;	
      continue;
		
    }
    if(ASCII||(hex2>'F')){

      recvgsmproc[i+1] = hex2;	
      hex3 = 2;	
      j = j/2;
      continue;
		
    }
  	
    hex = asic_to_hex(recvgsmproc[j+3]);
    hex1 = asic_to_hex(recvgsmproc[j+4]);
    hex = hex<<4;
    hex = hex+hex1;
    hex1 = hex-'9';//34	

    hex = asic_to_hex(hex2);
    hex2 = asic_to_hex(hex1);
    hex = hex<<4;
    hex = hex+hex2;
    recvgsmproc[i+1] = hex;		
	
  }
	
  return 1;
}

void open_gprs_power()
{
	if(SYS_MS.G3S ==OFF)return;
	WCDMA_Power_ON;
	delay(10000);//andyluo2011-02-12
}


void open_gprs_uart()
{
	 delay(1000);//andyluo2011-02-12
}
void close_uart()
{
	 delay(5);
 }
void close_gprs_power()
{
	 WCDMA_Power_OFF;
	 delay(10000);//andyluo2011-02-12
}


/*----------------------------------------------------------------------
����:    card_modem_configor(void)
����:    �򿪶���ģ���Դ������ʼ������
input:   ��ʱ����
output:  
2������
0x55������
0�ɹ���
------------------------------------------------------------------------*/
u8 Initial_3G(u8 time)
{ 
  u32 timeOut;  
  
  WCDMA_Power_OFF;
  delay(KEYTIMEOUT_1S / 10);
  WCDMA_Power_ON; 
  //�ж�  
  RxCounter =0;   
  f_receiveOK = 0; 
  timeOut=KEYTIMEOUT_1S* time;   // 20s�ȴ�3Gģ���ʼ��
  
  while(--timeOut) 
  {
    IWDG_ReloadCounter(); //ι��
    if(key_flag)
    {
      WCDMA_Power_OFF;
      return 2;  //��������
    }
    
    if(f_receiveOK==1) //�յ��ظ��ȴ�3Gģ���ʼ��
    { 
      f_receiveOK = 0;
      if((RxBuffer[1]=='A')&&(RxBuffer[2]=='A'))  //#AA*�ɹ�
      {break;}              
    }   
  }
  if(timeOut)
  return Link_network();
  else
  {
    WCDMA_Power_OFF;
    return 0x55;
  }
}

/*------------�߱����߹��ܵ�3G��----------------------
//����������u8 open_3G(u8 time)
//2������
//0x55������
//0�ɹ���
//-------------------------------------------------------*/
//u8 open_3G(u8 time)
//{
//  u8 netstate;  

//  netstate=MBto3G_CtlCommmand(1,time);//ֱ�ӻ���3Gģ��  
//  if(key_flag)
//  {
//    WCDMA_Power_OFF;
//    return 2;
//  }  //��������
//  
//  if(netstate)//ʧ��
//  {    
//    netstate=Initial_3G(time);//�Ӷϵ翪ʼ���� 
//    if(key_flag)//
//    { WCDMA_Power_OFF;return 2;}  //��������
//    
//  }  
//  /*�������������*/    
//  return netstate;
//}


//��3g
//void close_3G(u8 type)
//{
//  // �ػ����� *OFF# 
//  if(type==1)
//  {
//    WCDMA_Power_OFF;  
//  }
//  else if(type==2)
//  {
//    WCDMA_Power_OFF;   
//    delayms_keybreak(1000);
//  }
//  else
//  {
//    send_string_3G("*OFF#"); //��������������
//    delayms_keybreak(4000);
//    WCDMA_Power_OFF;  
//  }
//}








u8 rec_gprs(unsigned long delay_wait,unsigned char *shujv,u8 change)//andyluo2011-02-12
{	
  unsigned short i;
  u32 ack_err;       
  RxCounter = 0;
  ack_err = delay_wait *KEYTIMEOUT_1S;
  while(ack_err--){
             
    if(key_flag)
    {
        return 0;           
    }
    
    if(RxBuffer[RxCounter-1] != '*')
        continue;
    if(RxCounter!=300){
        for(i=0;i<RxCounter;i++)
            shujv[i] = RxBuffer[i];
        return 1;
    }
    else{			
        shujv[5]='*';
        return 0;
    }

  }
  return 0;
}
//ʵʱ����RTCʱ�� locs-ʱ��RxBuffer��ʼλ�� 2015-08-08  andyluo
void Update_RTC(u8 locs)
{
u8 timenew[7],timenewH[7],buffer[2],i,j,ckflag;
u32 tln,tlnold,subv;

	I2C_ReadS_24C(SYS_RTC,buffer,1);//ʱ��ʵʱ���¿��� 1-�� 0-��
	if(locs>30)//��¼ʱ�����ж�
		{
		if(buffer[0]==0)return;//δ����ʵʱ����
		}
	i = locs;
	for(j=0;j<5;j++)
		timenew[4-j] = (asic_to_hex(RxBuffer[i+j*3])<<4)+asic_to_hex(RxBuffer[i+j*3+1]);
	//time[4]-time[0]//YYMMDDHHMM
	ckflag = JD_TIMECK(timenew,1);
	if(ckflag==OK)
		{		
		for(i=0;i<6;i++)
			 timenewH[i] = BCDtoHex(timenew[i]);
		GetCurrentTime();
		if(timenewH[1]==0)
			tln = 24*60+timenewH[0];
		else
			tln = timenewH[1]*60+timenewH[0];
		if(time1[1]==0)
			tlnold = 24*60+time1[0];
		else
			tlnold = time1[1]*60+time1[0];
		if(tln>tlnold)
			subv = tln-tlnold;
		else
			subv = tlnold-tln;

		ckflag=0;
		if((timenew[4]!=time[4])||(timenew[3]!=time[3])||(timenew[2]!=time[2]))
			ckflag=1;		
		else if(subv>2)//����ʱ�� RTC
			ckflag=1;
		if(ckflag)
			set_current_time(timenew); 			
		}	
	return;
}


uchar rec_gprs_feeYW(uchar delay_wait)
{
    u32 timeOut;
	u8 i,j;
    timeOut = delay_wait * KEYTIMEOUT_1S*5;
    while(timeOut--)
		{
		if(f_receiveOK == OK)
			{
            for(i=1;i<RxCounter;i++)
				{
//#<ErrorCode><AA1501301619005500220864320203300024010499120015020155002208643202033000240104991200AB></ErrorCode>*
                if((RxBuffer[i-1] == '<') && (RxBuffer[i] == 'E') && (RxBuffer[i + 1] == 'r') && (RxBuffer[i + 2] == 'r') && (RxBuffer[i + 3] == 'o') && (RxBuffer[i + 4] == 'r'))
					{
					return i + 11;
                	}
				}
        }  
	if(key_flag)
		{
		return 0;            
        }
	}
	return 0;
}



//����GPRS��Ӧ��
//#<ErrorCode><0></ErrorCode><Time><2015-07-17|18:25:10></Time>*
uchar rec_gprs_ack(uchar delay_wait)
{
    u32 timeOut;
	u8 i,j;
    timeOut = delay_wait * KEYTIMEOUT_1S*5;
    while(timeOut--)
		{
		if(f_receiveOK == OK)
			{
            for(i=1;i<RxCounter;i++)
				{
                if((RxBuffer[i-1] == '<') && (RxBuffer[i] == 'E') && (RxBuffer[i + 1] == 'r') && (RxBuffer[i + 2] == 'r') && (RxBuffer[i + 3] == 'o') && (RxBuffer[i + 4] == 'r'))
					{
					//RxBuffer[i+34]-35 37-38 40-41 43-44 46-47
					Update_RTC(i+34);
					return asic_to_hex(RxBuffer[i + 11]);
                	}
				}
        }  
	if(key_flag)
		{
		return 1;            
        }
	}
	return 1;
}

uchar rec_IAP(uchar delay_wait,int data[])
{
    u32 ack_err;
    int i;
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
        if(f_receiveOK == OK)
        {
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'x' && RxBuffer[i + 3] == 't' )
                {                   
                      data[14] = i + 6;
                      break;
                }
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'x' && RxBuffer[i + 3] == 't' )
                {                   
                      data[15] = i - 3;
                      return 1;
                }
            }
                     
            break;
        }
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x00;
    
    return 0x00;
}


uchar recFreeCom(uchar delay_wait,int data[])
{
    u32 ack_err;
    int i;
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
        if(f_receiveOK == OK)
        {
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'F' && RxBuffer[i + 1] == 'r' && RxBuffer[i + 2] == 'e' && RxBuffer[i + 3] == 'e' )
                {                   
                      data[0] = i + 6;
                      break;
                }
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'F' && RxBuffer[i + 1] == 'r' && RxBuffer[i + 2] == 'e' && RxBuffer[i + 3] == 'e' )
                {                   
                      data[1] = i - 3;
                      return 1;
                }
            }
                     
            break;
        }
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x00;
    
    return 0x00;
}



uchar recTimeData(uchar delay_wait,int data[])
{
    u32 ack_err;
    int i;
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
        if(f_receiveOK == OK)
        {
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'i' && RxBuffer[i + 2] == 'm' && RxBuffer[i + 3] == 'e' )
                {                   
                      data[0] = i + 6;
                      break;
                }
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'i' && RxBuffer[i + 2] == 'm' && RxBuffer[i + 3] == 'e' )
                {                   
                      data[1] = i - 3;
                      return 1;
                }
            }
                     
            break;
        }
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x00;
    
    return 0x00;
}

uchar recFreeData(uchar delay_wait,int data[])
{
    u32 ack_err;
    int i;
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
        if(f_receiveOK == OK)
        {
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'F' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'e')
                {                   
                      data[0] = i + 5;
                      break;
                }
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'F' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'e')
                {                   
                      data[1] = i - 3;
                      return 1;
                }
            }
                     
            break;
        }
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x00;
    
    return 0x00;
}







u8 rec_gprs_L(uchar delay_wait,int data[])
{
    u32 ack_err;
    int i;
    ack_err = delay_wait * KEYTIMEOUT_1S;
    while(ack_err--)
    {
        if(f_receiveOK == OK)
        {
            for(i = 0;i<RxCounter;i++)
            {
                if((RxBuffer[i-1] == '<') && (RxBuffer[i] == 'B') && (RxBuffer[i + 1] == 'C') && (RxBuffer[i + 2] == 'C'))
                {
                    for(int j=0;j<2;j++)
                      data[j] = RxBuffer[i + 5 + j];//BCC
                }
                
                if((RxBuffer[i-1] == '<') && (RxBuffer[i] == 'C') && (RxBuffer[i + 1] == 'o') && (RxBuffer[i + 2] == 'u'))
                {
                    for(int j=2;j<6;j++)
                      data[j] = RxBuffer[i + 7 + j - 2];//Count
                }
                
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'N' && RxBuffer[i + 1] == 'i' && RxBuffer[i + 2] == 't' && RxBuffer[i + 3] == 'e' && RxBuffer[i + 4] == 'm')
                {
                    for(int j=6;j<10;j++)
                      data[j] = RxBuffer[i + j + 1];
                }
                
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'h' && RxBuffer[i + 1] == 'm' && RxBuffer[i + 2] == 'd' && RxBuffer[i + 3] == 'S' && RxBuffer[i + 4] == 'e')
                {
                    for(int j=10;j<14;j++)
                      data[j] = RxBuffer[i + j - 2];
                }
                if((RxBuffer[i-1] == '<') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'x' && RxBuffer[i + 3] == 't' )
                {                   
                      data[14] = i + 6;
                      break;
                }
                
                if(key_flag)
                  return 0x00;
            }
            
            for(i = RxCounter;i > 0;i--)
            {
                if((RxBuffer[i-2] == '<') && (RxBuffer[i-1] == '/') && RxBuffer[i] == 'T' && RxBuffer[i + 1] == 'e' && RxBuffer[i + 2] == 'x' && RxBuffer[i + 3] == 't' )
                {                   
                      data[15] = i - 3;
                      return 1;
                }
                
                if(key_flag)
                  return 0x00;
            }
                     
            break;
        }
        
        if(key_flag)
          return 0x00;
    }
    
    if(ack_err >= delay_wait * KEYTIMEOUT_1S)
      return 0x03;
    
    return 0x00;
}
////////////////////////////////////////////////////////////////////////////////////////////////
u8 rec_gprs2(unsigned long delay_wait,unsigned char *shujv,u8 change)//andyluo2011-02-12
{
	unsigned short i;
	unsigned char a;
	u32 ack_err;
        
	RxCounter = 0;
	ack_err = delay_wait * KEYTIMEOUT_1S;
	while(ack_err--)  
	{

		if(key_flag)
			{
			a = key_scan1();
			if(a == KEY_Cancel)
			{	
			return 0xe7;
			}
			}                  
		if(RxBuffer[RxCounter-1] != '*')
			continue;
		if(RxCounter!=300)
			{
			for(i=0;i<RxCounter;i++)
				shujv[i] = RxBuffer[i];
		
			return 1;
			}
		else
			{			
			shujv[5]='*';
			return 0;
			}

	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////

u8 rec_gprs1(unsigned long delay_wait,unsigned char *shujv)//andyluo2011-02-12
{
 // unsigned char a;
  unsigned long i,ack_err;
  

		RxCounter = 0;
		ack_err = KEYTIMEOUT_1S*delay_wait;
		while(ack_err--)  
			{
                          if((ack_err==1)&&(ack_err==0))
                            return 0;
			if(RxBuffer[RxCounter-1] == 0x0D)
				break;
			}
		for(i=0;i<RxCounter;i++)
			shujv[i] = RxBuffer[i];

			return 1;
}

/*
*<IP><14.154.233.181><PT><7600><APN><"CTNET","CARD","CARD">#
�ϸ�ʽ��
*I0P<121.34.41.198><PT><3333><AN><1,"IP","ctnet">#

*/

//ip:192.168.1.87 ���֣�PaymentDB �û�����sa ���룺316116

//software_sever IP and port.
void send_ip(unsigned char *IP_Add,unsigned char *PORT)
{
u8 buffer[32],i,j,sendip[100];
u8 username[32],userpsd[32];
     //unsigned char sz7[20];
     //unsigned char k,i;//,Comport;

 //   ywcj@jhywcj.vpdn.zj
 //   123456
 //172.16.0.8:9001
	
#ifdef YW_VPN
	uart_send_som("*<IP><172.16.0.8><PT><9001><APN><\"3GNET\",\"ywcj@jhywcj.vpdn.zj\",\"123456\">#");
	return;
#endif 

	 
	 I2C_ReadS_24C(APNuser_possword,buffer,32);//��IP��
	 for(i=0;i<32;i++)
	 	{
		if(buffer[i] == 0xff)break;
		username[i] = buffer[i];
	 	}
         username[i++] = '\0';
	 for(j=0;i<32;i++)
	 	{
	 	if(buffer[i] == 0xff)break;
		userpsd[j++] = buffer[i];
	 	}
         userpsd[j] = '\0';
	 memset(sendip,0,100);
	 strcat(sendip,"*<IP><");
	 strcat(sendip,IP_Add);
	 strcat(sendip,"><PT><");
	 strcat(sendip,PORT);
	 // 	uart_send_som("<APN><\"3GNET\",\"");
	 //   //uart_send_som(username);
	 //   uart_send_som("CARD");
	 //   uart_send_som("\",\"");
	 //   //uart_send_som(userpsd);
	 //   uart_send_som("CARD");
	 //   uart_send_som("\">#");
	 strcat(sendip,"><APN><\"3GNET\",\"");
	 strcat(sendip,username);
	 strcat(sendip,"\",\"");
	 strcat(sendip,userpsd);	 
	 strcat(sendip,"\">#");
//	 strcat(sendip,"><APN><\"3GNET\",\"CARD\",\"CARD\">#");
//	 uart_send_som(sendip);
	 uart_send_som(sendip);

	 
//	 uart_send_som("*<IP>");
//	 uart_send_som("<");
//	 uart_send_som(IP_Add);
//	 uart_send_som(">");
//	 
//     uart_send_som("<");
//     uart_send_som("PT");
//     uart_send_som(">");
//     
//     uart_send_som("<");
//     uart_send_som(PORT);
//     uart_send_som(">");
//     
//     //uart_send_som("<AN><1,\"IP\",\"ctnet\">#");
//	 
//     uart_send_som("<APN><\"CTNET\",\"");
//	 //uart_send_som(username);
//	 uart_send_som("CARD");
//	 uart_send_som("\",\"");
//	 //uart_send_som(userpsd);
//	 uart_send_som("CARD");
//	 uart_send_som("\">#");
//		 
		 //*<IP><14.154.233.181><PT><7600><APN><"CTNET","CARD","CARD">#
          
         /*
	 for(k=1;k<sz7[0]+1;k++)
	 	{
	 	uart_send(sz7[k]);
		if(sz7[k] == 'P')
			i = k+1;
	 	}
	 uart_send_som(",");
	 for(k=i;k<sz7[0]+1;k++)
	 	uart_send(sz7[k]);
	 uart_send_som("#");
	 
	 return;
         */
}

void send_data(unsigned char *data)
{
    uart_send_som("*0%");
    uart_send_som(data);
    uart_send_som("#");
    
}
void send_apn()
{
     unsigned char sz7[80];
     unsigned int k;
//     unsigned char a,kk;
     unsigned char kk;

      uart_send_som("*APN");     
      kk=0;
	 for(k=0;k<64;k++)     
	 {
            uart_send(sz7[k]);
	    if(sz7[k]=='"')
	        kk=kk+1;
	    if(kk==6)
	        break;
	 }
         uart_send_som("#");         

}
///////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////

u8 Link_DPS(void)
{
	u8 netstate;
	u32 linkacktime;
	delay(KEYTIMEOUT_1S);
	send_DPSip();
	delay(KEYTIMEOUT_1S*2);
	Wakeup__3G_CDMA;	
	netstate = NG;
	linkacktime = KEYTIMEOUT_1S*30;
	while(linkacktime--)
		{
		if((RxBuffer[1] == 'L')&&(RxBuffer[3] == 'k'))
			{
			gprs_user = OK;
			netstate = OK;
			break;	//#Lok*  �����ɹ�	
			}
		}
	if(netstate == OK)
		{
                  
		delay(KEYTIMEOUT_1S/2);
		GPRS_CSQ(Ishide);
		Refresh_SYSallicon();
		delay(KEYTIMEOUT_1S/2);
		}
	return netstate;
	
}
/*  return 0 ���� �˳�
 *  return 1 �ɹ����� �˳�
 *  return 2 ��������ʧ�� �˳�
*/
u8 Link_network(void)
{
      unsigned char sz7[10];
      unsigned int k,quit_flag = 0;
      
      
      read_IP();
      send_ip(IP,PORT);

          unsigned short i;
          u32 ack_err;   
          
          for(int i=0;i<RxCounter;i++)
          RxBuffer[i] = 0x00;    
          RxCounter = 0;   
          f_receiveOK = 0;
          
          ack_err = 10 * KEYTIMEOUT_1S;
          while(ack_err > 0){
             
            ack_err--;
              if(key_flag||key_flagbk)
              {
                  quit_flag =1;
                  break;           
              }
        
              if(RxBuffer[RxCounter-1] != '*')
                  continue;
              
              if(RxCounter <= 100){
                  for(i=0;i<RxCounter;i++)
                      sz7[i] = RxBuffer[i];
                  quit_flag = 2;
                  break;
              }
              else{			
                  sz7[5]='*';
    
              } 
          }

	
	if(quit_flag == 1)		
		return 0;
	else if(quit_flag == 2)
		{
		//#IP*  �����ɹ�		
		for(k=0;k<100;k++)
			{
			if(sz7[k]=='#')
				{
				if(sz7[k+1]=='I' && sz7[k+2]=='P' && sz7[k+3]=='*')
                    {  
					NETSTATE = NETSTATE_LINK;
					return 1;
					}
				return 2;
				}		
			}		
		return 3;
		}
	else
		{
		return 4;
		}
}
////********************************************
void close_gprs_power1()
{
	close_uart();
	delay(500);
	return;
}
//Center sever:disconnect      DPS sever: connect        CS.:��DS.:��
u8 open_gprs()
{
u8 loop,sendFlag;
u32 timeOut=0;

	OPEN_EXTI9_5_IRQ(); 								   
	OPEN_EXTI15_10_IRQ();	
	key_flagbk = 0;
	key_flag= 0;
	
	if(SYS_MS.G3S ==OFF)return NG;

	RxCounter =0;	
	f_receiveOK = 0; 

	if(NETSTATE == NETSTATE_LINK)
		{
		loop = 1;
		while(loop--)
			{
//			sendFlag =NETSTATE_FUN("*LK?#");
			sendFlag =NETSTATE_FUN("@@@@@*WAKE#");
			if(sendFlag==NETSTATE_LINK)break;
			}
		if(NETSTATE != NETSTATE_LINK)
			{
			NETSTATE = NETSTATE_CLOSE;
//			return NG;
			}
		else
			return OK;//����δ�Ͽ�
		}
	if(NETSTATE == NETSTATE_SLEEP)//���紦������״̬
		{//��������--
		loop = 1;
		while(loop--)
			{
//			sendFlag =NETSTATE_FUN("*LK?#");
			sendFlag =NETSTATE_FUN("@@@@@*WAKE#");
			if(sendFlag==NETSTATE_LINK)break;
			}
		if(NETSTATE != NETSTATE_LINK)
			{
			NETSTATE = NETSTATE_CLOSE;
//			return NG;
			}
		else
			return OK;//����δ�Ͽ�
		
		}
	else if(NETSTATE != NETSTATE_CLOSE)
		{
		loop = 1;
		while(loop--)
			{
			sendFlag =NETSTATE_FUN("@@@@@*WAKE#");
			if(sendFlag==NETSTATE_LINK)break;
			}
		if(NETSTATE != NETSTATE_LINK)
			{
			NETSTATE = NETSTATE_CLOSE;
//			return NG;
			}
		else
			return OK;//����δ�Ͽ�
		}


	
	close_gprs_power();
	delay(KEYTIMEOUT_1S/10);
	open_gprs_power();
	key_flag= 0;
//	delay(KEYTIMEOUT_1S / 10);         
    while(timeOut < KEYTIMEOUT_1S * 10)
	   {
	 if(key_flag||key_flagbk)
	   	{
		NET_KeyDeal();	
		return NG;
       	}
       timeOut++;
	   if(f_receiveOK==1) //�յ��ظ��ȴ�3Gģ���ʼ��
	   	 { 
		 f_receiveOK = 0;
		 if((RxBuffer[1]=='A')&&(RxBuffer[2]=='A'))  //#AA*�ɹ�
		 	break;	
		 }
	   }
	 return Link_network();
}

void NET_KeyDeal(void)
{
u8 loop,sendFlag;

//	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_11)==0)//����״̬	
//		return
	key_flag = key_flagbk;
	loop = 3;
	while(loop--)
		{
		sendFlag =NETSTATE_FUN("*SLEEP#");
		if(key_flag)break;
		if(sendFlag==NETSTATE_SLEEP)break;
		}
}

/*
(����?3G ��)��������˵����
? *SLEEP#��  //���� 3G ��-----�ɹ�����#SS*
? @@@@@*WAKE#�� //���� 3G �壬������������-----�ɹ�����#IP*
? *OFF#��   //��������·----�ɹ�����#OK*
? *LK?#��  //��ѯ��������״̬-----����״̬����#IP*�����򷵻� #NOIP*
? *CSQ#��   //��ѯ��ǰ�ź�ֵ-----�������磺 #23*
ǰ�� 2 �������������ߺͻ��� 3G �壬 ���� 3 ����� *OFF#\*LK?#\*CSQ#�����ڵ��ԡ�
*VR#
*/
u8 NETSTATE_FUN(u8* NETFUN)
{

  unsigned char sz7[10],G3ST;
  unsigned int k,quit_flag = 0;
  unsigned short i;
  u32 ack_err;	 

  if((NETFUN[1] == 'S')&&(NETFUN[2] == 'L'))
  	{
	// 1-���� 0-˯��
	G3ST = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_11);
  	if(G3ST==0) return NETSTATE_SLEEP; 
  	}
  
  uart_send_som(NETFUN);
	  
  for(i=0;i<RxCounter;i++)RxBuffer[i] = 0x00;	 
  
  RxCounter = 0;   
  f_receiveOK = 0;
	  
  ack_err = 3 * KEYTIMEOUT_1S;
  while(ack_err > 0)
  	{
	ack_err--;
	if(key_flag)
		{
		quit_flag =1;
		break;	
		}
	if(RxBuffer[RxCounter-1] != '*')
		continue;
	if(RxCounter <= 100)
		{
		for(i=0;i<RxCounter;i++)
			sz7[i] = RxBuffer[i];
		quit_flag = 2;
		break;
		}
	else{ 		
		quit_flag = 2;
		sz7[5]='*';
		} 
	  }
	if(quit_flag == 1)		
		{				
		NETSTATE = NETSTATE_KEYCL;
		return NETSTATE_KEYCL;	
		}
	else if(quit_flag == 2)
		{
	//#IP*	�����ɹ�	
		for(k=0;k<100;k++)
			{
			if(sz7[k]=='#')
				{
				if(sz7[k+1]=='I' && sz7[k+2]=='P' && sz7[k+3]=='*')
					{				
					NETSTATE = NETSTATE_LINK;
					return NETSTATE_LINK;	
					}
				else if(sz7[k+1]=='s' && sz7[k+2]=='s' && sz7[k+3]=='*')
					{
					NETSTATE = NETSTATE_SLEEP;
					return NETSTATE_SLEEP;				
					}	
				else if(sz7[k+1]=='N' && sz7[k+2]=='O' && sz7[k+5]=='*')
					{
					NETSTATE = NETSTATE_ERR;
					return NETSTATE_ERR;				
					}
				else if(sz7[k+1]=='V' && sz7[k+2]=='R')
					return NETSTATE_VR;
				else
					{
					NETSTATE = NETSTATE_CLOSE;
					return NETSTATE_CLOSE;				
					}
				}
			}
		}
	NETSTATE = NETSTATE_CLOSE;
	return NETSTATE_CLOSE;				
}



//13561876078
