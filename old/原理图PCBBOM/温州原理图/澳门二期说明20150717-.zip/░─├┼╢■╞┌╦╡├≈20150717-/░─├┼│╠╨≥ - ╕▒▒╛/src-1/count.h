#ifndef	_Count_H
#define		_Count_H	
unsigned char  DEC_to_HEX(unsigned char DEC);
unsigned long money_to_time(unsigned int umoney,unsigned char X);
unsigned long time_to_money(unsigned int utime,unsigned char X);
unsigned long hcl(unsigned char bufa[],unsigned char b);
void fll(unsigned long FD,unsigned char bufa[],unsigned char b);
void save_add_char(unsigned int addr0,unsigned char num);
void save_add_three(unsigned int addr0,unsigned char num);
void save_add_long(unsigned int addr0,unsigned int num);
void save_jilu(unsigned char buf5[]);
void Set_shoufei(void);
unsigned char  check_shoufei();
void math_time(unsigned long utime,unsigned char time2[]);
void math_time1(unsigned long utime,unsigned char time5[],unsigned char time2[]);
u8 Judge_freeday(void);

//#define  Normal_Time				1
#define  Free_time    	 			0
#define  Free_date    	 			2
#define  SYSERR    	 			3
#define  SYSBusy    	 			4
#define  Clearway_time            0x88



//void fault_record(unsigned char FAULT_TYPE);
//void takemny_record(unsigned char * card_no);
//void day_record(void);
#endif
