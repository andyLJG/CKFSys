#include "Loader.h"

static u32 SoucePt;

uint32_t FlashDestination = ApplicationAddress; /* Flash user program offset */
uint16_t PageSize = PAGE_SIZE;
uint32_t EraseCounter = 0x0;
uint32_t NbrOfPage = 0;
FLASH_Status FLASHStatus = FLASH_COMPLETE;

uint32_t FLASH_PagesMask(__IO uint32_t Size)
{
  uint32_t pagenumber = 0x0;
  uint32_t size = Size;

  if ((size % PAGE_SIZE) != 0)
  {
    pagenumber = (size / PAGE_SIZE) + 1;
  }
  else
  {
    pagenumber = size / PAGE_SIZE;
  }
  return pagenumber;

}

static ErrorStatus ProgramCode(void)
{
	u32 j;
	SoucePt = BackUpMemAddress;
	
	/* Erase the needed pages where the user application will be loaded */
	/* Define the number of page to be erased */
	NbrOfPage = FLASH_PagesMask(AppMemorySize);

	/* Erase the FLASH pages */
	for (EraseCounter = 0; (EraseCounter < NbrOfPage) && (FLASHStatus == FLASH_COMPLETE); EraseCounter++)
	{
	FLASHStatus = FLASH_ErasePage(FlashDestination + (PageSize * EraseCounter));
	}

	FlashDestination = ApplicationAddress;
	
	for (j = 0;(j < AppMemorySize) && (FlashDestination <  BackUpMemAddress);j += 4)
	{
		/* Program the data received into STM32F10x Flash */
		FLASH_ProgramWord(FlashDestination, *(u32*)SoucePt);

		if (*(u32*)FlashDestination != *(u32*)SoucePt)
			return ERROR;
		
		FlashDestination += 4;
		SoucePt += 4;
	}
	
	return SUCCESS;
}

void IapUpdata(void)
{
	if(ProgramCode() != SUCCESS);
		ProgramCode();

}

