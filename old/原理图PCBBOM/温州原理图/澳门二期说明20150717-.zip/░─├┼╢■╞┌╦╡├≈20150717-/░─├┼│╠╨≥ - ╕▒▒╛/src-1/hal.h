#ifndef HAL_H
#define HAL_H

#include "stm32f10x_conf.h"
#include "LCD_12864.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_it.h"
#include "misc.h"
//#include "audio.h"
#include "math.h"

void IRrecei_INIT(void);
/*
#define LED1_OFF		GPIO_ResetBits(GPIOD, GPIO_Pin_11)
#define LED1_ON	                GPIO_SetBits(GPIOD, GPIO_Pin_11)
#define LED2_OFF		GPIO_ResetBits(GPIOC, GPIO_Pin_15)
#define LED2_ON	                GPIO_SetBits(GPIOC, GPIO_Pin_15)
#define LED3_OFF		GPIO_ResetBits(GPIOE, GPIO_Pin_15)
#define LED3_ON	                GPIO_SetBits(GPIOE, GPIO_Pin_15)
#define LED4_OFF		GPIO_ResetBits(GPIOE, GPIO_Pin_14)
#define LED4_ON	                GPIO_SetBits(GPIOE, GPIO_Pin_14)
#define LED5_OFF		GPIO_ResetBits(GPIOC, GPIO_Pin_4)
#define LED5_ON	                GPIO_SetBits(GPIOC, GPIO_Pin_4)
#define LED6_OFF		GPIO_ResetBits(GPIOC, GPIO_Pin_5)
#define LED6_ON	                GPIO_SetBits(GPIOC, GPIO_Pin_5)
*/
//Ӳ����ʼ��
void  ChipHalInit(void);
void  ChipOutHalInit(void);
void  ChipOutHalInit1(void);
void I2C_Configuration(void);
void I2C_Test(void);
//void	init_rx8025sa(void);
//void set_time(unsigned char  timeg[]);
//void get_time(void);
//void set_time(void);
void init_rx8025sa(void);
void IWDG_Configuration(void);
void Uart1_Enable(void);
void Uart1_Configuration(u32 BaudRate);
void Uart2_Configuration(void);
void Uart3_Configuration(u32 BaudRate);
void Uart4_Configuration(u32 BaudRate);
void Uart5_Configuration(void);
void Uart5_Close(void);
void NVIC_Configuration(void);
void NVIC_Usart1(void);
//#endif
void audio (u8 addr);
void audio_data(u8 num);
void money_audio() ;
void time_audio();


void key_over(void);
////////////////////////////////////
/*
PD10--PD11--PD12--PD13--PD14--PD15-------OK
PF10--PF11--PC8---PC13--PC14--PC15-------OK
PD4--PD5--PD6--PD7--PD8--PD9-------------OK
PB14-PB5--PD6--PD7--PF8--PF9-------------OK
*/
/****************start�����ӿ�start*****************/
#define key1_0		GPIO_ResetBits(GPIOF, GPIO_Pin_8)
#define key1_1	    GPIO_SetBits(GPIOF, GPIO_Pin_8)
#define key2_0		GPIO_ResetBits(GPIOF, GPIO_Pin_9)
#define key2_1	    GPIO_SetBits(GPIOF, GPIO_Pin_9)
#define key3_0		GPIO_ResetBits(GPIOF, GPIO_Pin_10)
#define key3_1	    GPIO_SetBits(GPIOF, GPIO_Pin_10)
#define key4_0		GPIO_ResetBits(GPIOF, GPIO_Pin_11)
#define key4_1	    GPIO_SetBits(GPIOF, GPIO_Pin_11)
/****************************************************/
//#define HC244CS_0		GPIO_ResetBits(GPIOC, GPIO_Pin_6)
//#define HC244CS_1	    GPIO_SetBits(GPIOC, GPIO_Pin_6)
/////////////////////////////////////////////////////////////////////////
#define Buzz_0		GPIO_ResetBits(GPIOA, GPIO_Pin_1)
#define Buzz_1	    GPIO_SetBits(GPIOA, GPIO_Pin_1)
/////////////////////////////////////////////////////////////////////////
#define BackCTRL_0		GPIO_ResetBits(GPIOC, GPIO_Pin_3)
#define BackCTRL_1	    GPIO_SetBits(GPIOC, GPIO_Pin_3)
///////////////////////////////////////////////////////////////////////////////////
#define UartCtrl_0		GPIO_ResetBits(GPIOA, GPIO_Pin_9)
#define UartCtrl_1	    GPIO_SetBits(GPIOA, GPIO_Pin_9)
///////////////////////////////////////////////////////////////////////////////////
/******************end�����ӿ�end*******************/

#define  BaudRate_115200 115200
#define  BaudRate_57600  57600
#define  BaudRate_38400  38400
#define  BaudRate_19200  19200
#define  BaudRate_9600   9600

void keypin_init(void);

#endif
