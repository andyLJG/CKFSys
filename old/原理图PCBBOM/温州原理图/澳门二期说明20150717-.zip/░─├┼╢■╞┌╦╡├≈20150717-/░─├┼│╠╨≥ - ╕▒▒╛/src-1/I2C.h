#ifndef _I2C_H
#define _I2C_H

#define EEPROM_ADDR		0xA0
#define RX8025_ADDR		0x64
#define I2C_PAGESIZE	4		//24C01/01Aҳ������4��
void I2C_Standby_24C(void);    
void I2C_ByteWrite_24C(u16 addr,u8 dat);
void I2C_TwoByteWrite_24C(u16 addr,u8 *dat);
extern void GetCurrentTime();
void set_current_time(unsigned char  timeg[]);
void I2C_WriteS_24C(u16 addr,u8* pBuffer,  u16 no);
void I2C_PageWrite_24C(u16 addr,u8* pBuffer, u8 no);
void I2C_ReadS_24C(u16 addr ,u8* pBuffer,u16 no);
extern void set_time(void);//unsigned char  timeg[])
extern void init_rx8025sa(void);
extern void get_time(void);

extern u8 RxBuffer[];
//extern u8 TxBuffer[];
//extern u8 time[4];//0�գ�1ʱ��2�֣�3��
extern u8 time[7],time1[7],IAP_Night,LIST_UD[10];//,time2[6];

#endif
