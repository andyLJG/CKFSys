#include "des.h"
#include <string.h>
//#include "sst89x5x4.h"


//key from  lib; 
// E879234289AFE1DF

const unsigned char k[11]={0xe8,0x79,0x23,0x42,0x89,0xaf,0xe1,0xdf};

/*
		 des(&s[0],&d[0],k,0);
			i= specialdeschk(&s[0],&s[0],&d[0]);
			*/
//flg = 1Ϊ���ܡ�flg = 0Ϊ����
unsigned  char des(unsigned char *source,unsigned char * dest,unsigned char * inkey, unsigned char flg);
//int _tmain(int argc, _TCHAR* argv[])

union union1 u_ram;


//unsigned  char specialdes(unsigned char *snr,unsigned char * in,unsigned char * out);
// snr serial number
//in 8 bytes out 8 bytes 
//return 0 sucess
// return 1 fail; 

/*
void main(void)
{	  
	
	unsigned char xdata i;
	unsigned char xdata s[65]={0x01,0x23,0x45,0x67,0x89,0xab,0xcd,0xe7};
	unsigned char xdata d[65]={0};
	unsigned char xdata k[11]={0x01,0x23,0x45,0x67,0x89,0xab,0xcd,0xef};
	unsigned char xdata m[65]={0};
	TMOD = 0x20;
	SCON = 0x50;
	PCON = 0x80;
	TH1 = 0xF4;
	TL1 = 0xF4;
	TR1 = 1;
	while(1){
for(i =0;i<8;i++)
{
    des(&s[8*i],&d[8*i],k,1);
}
for(i=0;i<8;i++)
{
	SBUF = d[i];
	while(!TI);
	TI = 0;
}
for(i =0;i<8;i++)
{
    des(&d[8*i],&m[8*i],k,0);
}
for(i=0;i<8;i++)
{
	SBUF = m[i];
	while(!TI);
	TI = 0;
}
}
} 
	*/
/* ============================================================
des()
Description: DES algorithm,do encript or descript.
============================================================ */
unsigned char des(unsigned char *source,unsigned char * dest,unsigned char * inkey,unsigned char flg)
{
unsigned char nbrofshift, temp1, temp2;
int valindex;
register i, j, k, iter;
/* INITIALIZE THE TABLES */
/* Table - s1 */
static unsigned char s1[4][16] = {
14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7,
0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8,
4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0,
15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13 };
/* Table - s2 */
static  unsigned char s2[4][16] = {
15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10,
3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5,
0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15,
13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9 };
/* Table - s3 */
static  unsigned char s3[4][16] = {
10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8,
13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1,
13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7,
1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12 };
/* Table - s4 */
static  unsigned char s4[4][16] = {
7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15,
13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9,
10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4,
3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14 };
/* Table - s5 */
static  unsigned char s5[4][16] = {
2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9,
14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6,
4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14,
11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3 };
/* Table - s6 */
static  unsigned char s6[4][16] = {
12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11,
10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8,
9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6,
4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13 };
/* Table - s7 */
static  unsigned char s7[4][16] = {
4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1,
13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6,
1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2,
6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12 };
/* Table - s8 */
static  unsigned char s8[4][16] = {
13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7,
1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2,
7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8,
2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11 };

/* Table - Shift */
static  unsigned char shift[16] = {
1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1 };

/* Table - Binary */
static  unsigned char binary[64] = {
0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1,
0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1,
1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1,
1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1 };
/* MAIN PROCESS */
/* Convert from 64-bit key into 64-byte key */
for (i = 0; i < 8; i++) {
k=8*i;
u_ram.des_str.key[k] =((j = *(inkey + i))>>7) & 1;// ((j = *(inkey + i)) / 128) % 2;
u_ram.des_str.key[k+1] =(j>>6)&0x01;		// (j / 64) % 2;
u_ram.des_str.key[k+2] =(j>>5)&0x01;		// (j / 32) % 2;
u_ram.des_str.key[k+3] =(j>>4)&1;		// (j / 16) % 2;
u_ram.des_str.key[k+4] =(j>>3)&1;		// (j / 8) % 2;
u_ram.des_str.key[k+5] =(j>>2)&1;		// (j / 4) % 2;
u_ram.des_str.key[k+6] =(j>>1)&1;		// (j / 2) % 2;
u_ram.des_str.key[k+7] = j & 1;
}
/* Convert from 64-bit data into 64-byte data */
for (i = 0; i < 8; i++) {
k=8*i;
u_ram.des_str.buffer[k] = ((j = *(source + i))>>7) % 2;// ((j = *(source + i)) / 128) % 2;
u_ram.des_str.buffer[k+1] =(j>>6)&1;		// (j / 64) % 2;
u_ram.des_str.buffer[k+2] =(j>>5)&1;		// (j / 32) % 2;
u_ram.des_str.buffer[k+3] =(j>>4)&1;		// (j / 16) % 2;
u_ram.des_str.buffer[k+4] =(j>>3)&1;		// (j / 8) % 2;
u_ram.des_str.buffer[k+5] =(j>>2)&1;		// (j / 4) % 2;
u_ram.des_str.buffer[k+6] =(j>>1)&1;		// (j / 2) % 2;
u_ram.des_str.buffer[k+7] = j & 1;
}
/* Initial Permutation of Data */
u_ram.des_str.bufout[ 0] = u_ram.des_str.buffer[57];
u_ram.des_str.bufout[ 1] = u_ram.des_str.buffer[49];
u_ram.des_str.bufout[ 2] = u_ram.des_str.buffer[41];
u_ram.des_str.bufout[ 3] = u_ram.des_str.buffer[33];
u_ram.des_str.bufout[ 4] = u_ram.des_str.buffer[25];
u_ram.des_str.bufout[ 5] = u_ram.des_str.buffer[17];
u_ram.des_str.bufout[ 6] = u_ram.des_str.buffer[ 9];
u_ram.des_str.bufout[ 7] = u_ram.des_str.buffer[ 1];
u_ram.des_str.bufout[ 8] = u_ram.des_str.buffer[59];
u_ram.des_str.bufout[ 9] = u_ram.des_str.buffer[51];
u_ram.des_str.bufout[10] = u_ram.des_str.buffer[43];
u_ram.des_str.bufout[11] = u_ram.des_str.buffer[35];
u_ram.des_str.bufout[12] = u_ram.des_str.buffer[27];
u_ram.des_str.bufout[13] = u_ram.des_str.buffer[19];
u_ram.des_str.bufout[14] = u_ram.des_str.buffer[11];
u_ram.des_str.bufout[15] = u_ram.des_str.buffer[ 3];
u_ram.des_str.bufout[16] = u_ram.des_str.buffer[61];
u_ram.des_str.bufout[17] = u_ram.des_str.buffer[53];
u_ram.des_str.bufout[18] = u_ram.des_str.buffer[45];
u_ram.des_str.bufout[19] = u_ram.des_str.buffer[37];
u_ram.des_str.bufout[20] = u_ram.des_str.buffer[29];
u_ram.des_str.bufout[21] = u_ram.des_str.buffer[21];
u_ram.des_str.bufout[22] = u_ram.des_str.buffer[13];
u_ram.des_str.bufout[23] = u_ram.des_str.buffer[ 5];
u_ram.des_str.bufout[24] = u_ram.des_str.buffer[63];
u_ram.des_str.bufout[25] = u_ram.des_str.buffer[55];
u_ram.des_str.bufout[26] = u_ram.des_str.buffer[47];
u_ram.des_str.bufout[27] = u_ram.des_str.buffer[39];
u_ram.des_str.bufout[28] = u_ram.des_str.buffer[31];
u_ram.des_str.bufout[29] = u_ram.des_str.buffer[23];
u_ram.des_str.bufout[30] = u_ram.des_str.buffer[15];
u_ram.des_str.bufout[31] = u_ram.des_str.buffer[ 7];
u_ram.des_str.bufout[32] = u_ram.des_str.buffer[56];
u_ram.des_str.bufout[33] = u_ram.des_str.buffer[48];
u_ram.des_str.bufout[34] = u_ram.des_str.buffer[40];
u_ram.des_str.bufout[35] = u_ram.des_str.buffer[32];
u_ram.des_str.bufout[36] = u_ram.des_str.buffer[24];
u_ram.des_str.bufout[37] = u_ram.des_str.buffer[16];
u_ram.des_str.bufout[38] = u_ram.des_str.buffer[ 8];
u_ram.des_str.bufout[39] = u_ram.des_str.buffer[ 0];
u_ram.des_str.bufout[40] = u_ram.des_str.buffer[58];
u_ram.des_str.bufout[41] = u_ram.des_str.buffer[50];
u_ram.des_str.bufout[42] = u_ram.des_str.buffer[42];
u_ram.des_str.bufout[43] = u_ram.des_str.buffer[34];
u_ram.des_str.bufout[44] = u_ram.des_str.buffer[26];
u_ram.des_str.bufout[45] = u_ram.des_str.buffer[18];
u_ram.des_str.bufout[46] = u_ram.des_str.buffer[10];
u_ram.des_str.bufout[47] = u_ram.des_str.buffer[ 2];
u_ram.des_str.bufout[48] = u_ram.des_str.buffer[60];
u_ram.des_str.bufout[49] = u_ram.des_str.buffer[52];
u_ram.des_str.bufout[50] = u_ram.des_str.buffer[44];
u_ram.des_str.bufout[51] = u_ram.des_str.buffer[36];
u_ram.des_str.bufout[52] = u_ram.des_str.buffer[28];
u_ram.des_str.bufout[53] = u_ram.des_str.buffer[20];
u_ram.des_str.bufout[54] = u_ram.des_str.buffer[12];
u_ram.des_str.bufout[55] = u_ram.des_str.buffer[ 4];
u_ram.des_str.bufout[56] = u_ram.des_str.buffer[62];
u_ram.des_str.bufout[57] = u_ram.des_str.buffer[54];
u_ram.des_str.bufout[58] = u_ram.des_str.buffer[46];
u_ram.des_str.bufout[59] = u_ram.des_str.buffer[38];
u_ram.des_str.bufout[60] = u_ram.des_str.buffer[30];
u_ram.des_str.bufout[61] = u_ram.des_str.buffer[22];
u_ram.des_str.bufout[62] = u_ram.des_str.buffer[14];
u_ram.des_str.bufout[63] = u_ram.des_str.buffer[6];
/* Initial Permutation of Key */
u_ram.des_str.kwork[0] = u_ram.des_str.key[56];
u_ram.des_str.kwork[ 1] = u_ram.des_str.key[48];
u_ram.des_str.kwork[ 2] = u_ram.des_str.key[40];
u_ram.des_str.kwork[ 3] = u_ram.des_str.key[32];
u_ram.des_str.kwork[ 4] = u_ram.des_str.key[24];
u_ram.des_str.kwork[ 5] = u_ram.des_str.key[16];
u_ram.des_str.kwork[ 6] = u_ram.des_str.key[ 8];
u_ram.des_str.kwork[ 7] = u_ram.des_str.key[ 0];
u_ram.des_str.kwork[ 8] = u_ram.des_str.key[57];
u_ram.des_str.kwork[ 9] = u_ram.des_str.key[49];
u_ram.des_str.kwork[10] = u_ram.des_str.key[41];
u_ram.des_str.kwork[11] = u_ram.des_str.key[33];
u_ram.des_str.kwork[12] = u_ram.des_str.key[25];
u_ram.des_str.kwork[13] = u_ram.des_str.key[17];
u_ram.des_str.kwork[14] = u_ram.des_str.key[ 9];
u_ram.des_str.kwork[15] = u_ram.des_str.key[ 1];
u_ram.des_str.kwork[16] = u_ram.des_str.key[58];
u_ram.des_str.kwork[17] = u_ram.des_str.key[50];
u_ram.des_str.kwork[18] = u_ram.des_str.key[42];
u_ram.des_str.kwork[19] = u_ram.des_str.key[34];
u_ram.des_str.kwork[20] = u_ram.des_str.key[26];
u_ram.des_str.kwork[21] = u_ram.des_str.key[18];
u_ram.des_str.kwork[22] = u_ram.des_str.key[10];
u_ram.des_str.kwork[23] = u_ram.des_str.key[ 2];
u_ram.des_str.kwork[24] = u_ram.des_str.key[59];
u_ram.des_str.kwork[25] = u_ram.des_str.key[51];
u_ram.des_str.kwork[26] = u_ram.des_str.key[43];
u_ram.des_str.kwork[27] = u_ram.des_str.key[35];
u_ram.des_str.kwork[28] = u_ram.des_str.key[62];
u_ram.des_str.kwork[29] = u_ram.des_str.key[54];
u_ram.des_str.kwork[30] = u_ram.des_str.key[46];
u_ram.des_str.kwork[31] = u_ram.des_str.key[38];
u_ram.des_str.kwork[32] = u_ram.des_str.key[30];
u_ram.des_str.kwork[33] = u_ram.des_str.key[22];
u_ram.des_str.kwork[34] = u_ram.des_str.key[14];
u_ram.des_str.kwork[35] = u_ram.des_str.key[ 6];
u_ram.des_str.kwork[36] = u_ram.des_str.key[61];
u_ram.des_str.kwork[37] = u_ram.des_str.key[53];
u_ram.des_str.kwork[38] = u_ram.des_str.key[45];
u_ram.des_str.kwork[39] = u_ram.des_str.key[37];
u_ram.des_str.kwork[40] = u_ram.des_str.key[29];
u_ram.des_str.kwork[41] = u_ram.des_str.key[21];
u_ram.des_str.kwork[42] = u_ram.des_str.key[13];
u_ram.des_str.kwork[43] = u_ram.des_str.key[ 5];
u_ram.des_str.kwork[44] = u_ram.des_str.key[60];
u_ram.des_str.kwork[45] = u_ram.des_str.key[52];
u_ram.des_str.kwork[46] = u_ram.des_str.key[44];
u_ram.des_str.kwork[47] = u_ram.des_str.key[36];
u_ram.des_str.kwork[48] = u_ram.des_str.key[28];
u_ram.des_str.kwork[49] = u_ram.des_str.key[20];
u_ram.des_str.kwork[50] = u_ram.des_str.key[12];
u_ram.des_str.kwork[51] = u_ram.des_str.key[ 4];
u_ram.des_str.kwork[52] = u_ram.des_str.key[27];
u_ram.des_str.kwork[53] = u_ram.des_str.key[19];
u_ram.des_str.kwork[54] = u_ram.des_str.key[11];
u_ram.des_str.kwork[55] = u_ram.des_str.key[ 3];
/* 16 Iterations */
for (iter = 1; iter < 17; iter++) {
for (i = 0; i < 32; i++)
{
    u_ram.des_str.buffer[i] = u_ram.des_str.bufout[32+i];
}
/* Calculation of F(R, K) */
/* Permute - E */
u_ram.des_str.worka[ 0] = u_ram.des_str.buffer[31];
u_ram.des_str.worka[ 1] = u_ram.des_str.buffer[ 0];
u_ram.des_str.worka[ 2] = u_ram.des_str.buffer[ 1];
u_ram.des_str.worka[ 3] = u_ram.des_str.buffer[ 2];
u_ram.des_str.worka[ 4] = u_ram.des_str.buffer[ 3];
u_ram.des_str.worka[ 5] = u_ram.des_str.buffer[ 4];
u_ram.des_str.worka[ 6] = u_ram.des_str.buffer[ 3];
u_ram.des_str.worka[ 7] = u_ram.des_str.buffer[ 4];
u_ram.des_str.worka[ 8] = u_ram.des_str.buffer[ 5];
u_ram.des_str.worka[ 9] = u_ram.des_str.buffer[ 6];
u_ram.des_str.worka[10] = u_ram.des_str.buffer[ 7];
u_ram.des_str.worka[11] = u_ram.des_str.buffer[ 8];
u_ram.des_str.worka[12] = u_ram.des_str.buffer[ 7];
u_ram.des_str.worka[13] = u_ram.des_str.buffer[ 8];
u_ram.des_str.worka[14] = u_ram.des_str.buffer[ 9];
u_ram.des_str.worka[15] = u_ram.des_str.buffer[10];
u_ram.des_str.worka[16] = u_ram.des_str.buffer[11];
u_ram.des_str.worka[17] = u_ram.des_str.buffer[12];
u_ram.des_str.worka[18] = u_ram.des_str.buffer[11];
u_ram.des_str.worka[19] = u_ram.des_str.buffer[12];
u_ram.des_str.worka[20] = u_ram.des_str.buffer[13];
u_ram.des_str.worka[21] = u_ram.des_str.buffer[14];
u_ram.des_str.worka[22] = u_ram.des_str.buffer[15];
u_ram.des_str.worka[23] = u_ram.des_str.buffer[16];
u_ram.des_str.worka[24] = u_ram.des_str.buffer[15];
u_ram.des_str.worka[25] = u_ram.des_str.buffer[16];
u_ram.des_str.worka[26] = u_ram.des_str.buffer[17];
u_ram.des_str.worka[27] = u_ram.des_str.buffer[18];
u_ram.des_str.worka[28] = u_ram.des_str.buffer[19];
u_ram.des_str.worka[29] = u_ram.des_str.buffer[20];
u_ram.des_str.worka[30] = u_ram.des_str.buffer[19];
u_ram.des_str.worka[31] = u_ram.des_str.buffer[20];
u_ram.des_str.worka[32] = u_ram.des_str.buffer[21];
u_ram.des_str.worka[33] = u_ram.des_str.buffer[22];
u_ram.des_str.worka[34] = u_ram.des_str.buffer[23];
u_ram.des_str.worka[35] = u_ram.des_str.buffer[24];
u_ram.des_str.worka[36] = u_ram.des_str.buffer[23];
u_ram.des_str.worka[37] = u_ram.des_str.buffer[24];
u_ram.des_str.worka[38] = u_ram.des_str.buffer[25];
u_ram.des_str.worka[39] = u_ram.des_str.buffer[26];
u_ram.des_str.worka[40] = u_ram.des_str.buffer[27];
u_ram.des_str.worka[41] = u_ram.des_str.buffer[28];
u_ram.des_str.worka[42] = u_ram.des_str.buffer[27];
u_ram.des_str.worka[43] = u_ram.des_str.buffer[28];
u_ram.des_str.worka[44] = u_ram.des_str.buffer[29];
u_ram.des_str.worka[45] = u_ram.des_str.buffer[30];
u_ram.des_str.worka[46] = u_ram.des_str.buffer[31];
u_ram.des_str.worka[47] = u_ram.des_str.buffer[ 0];
/* KS Function Begin */
if (flg) {
nbrofshift = shift[iter-1];
for (i = 0; i < (int) nbrofshift; i++) {
    temp1 = u_ram.des_str.kwork[0];
    temp2 = u_ram.des_str.kwork[28];
    for (j = 0; j < 27; j++) {
     u_ram.des_str.kwork[j] = u_ram.des_str.kwork[j+1];
     u_ram.des_str.kwork[j+28] = u_ram.des_str.kwork[j+29];
    }
    u_ram.des_str.kwork[27] = temp1;
    u_ram.des_str.kwork[55] = temp2;
}
} else if (iter > 1) {
nbrofshift = shift[17-iter];
for (i = 0; i < (int) nbrofshift; i++) {
    temp1 = u_ram.des_str.kwork[27];
    temp2 = u_ram.des_str.kwork[55];
    for (j = 27; j > 0; j--) {
     u_ram.des_str.kwork[j] = u_ram.des_str.kwork[j-1];
     u_ram.des_str.kwork[j+28] = u_ram.des_str.kwork[j+27];
    }
    u_ram.des_str.kwork[0] = temp1;
    u_ram.des_str.kwork[28] = temp2;
}
}
/* Permute u_ram.des_str.hwork - PC2 */
u_ram.des_str.kn[ 0] = u_ram.des_str.kwork[13];
u_ram.des_str.kn[ 1] = u_ram.des_str.kwork[16];
u_ram.des_str.kn[ 2] = u_ram.des_str.kwork[10];
u_ram.des_str.kn[ 3] = u_ram.des_str.kwork[23];
u_ram.des_str.kn[ 4] = u_ram.des_str.kwork[ 0];
u_ram.des_str.kn[ 5] = u_ram.des_str.kwork[ 4];
u_ram.des_str.kn[ 6] = u_ram.des_str.kwork[ 2];
u_ram.des_str.kn[ 7] = u_ram.des_str.kwork[27];
u_ram.des_str.kn[ 8] = u_ram.des_str.kwork[14];
u_ram.des_str.kn[ 9] = u_ram.des_str.kwork[ 5];
u_ram.des_str.kn[10] = u_ram.des_str.kwork[20];
u_ram.des_str.kn[11] = u_ram.des_str.kwork[ 9];
u_ram.des_str.kn[12] = u_ram.des_str.kwork[22];
u_ram.des_str.kn[13] = u_ram.des_str.kwork[18];
u_ram.des_str.kn[14] = u_ram.des_str.kwork[11];
u_ram.des_str.kn[15] = u_ram.des_str.kwork[ 3];
u_ram.des_str.kn[16] = u_ram.des_str.kwork[25];
u_ram.des_str.kn[17] = u_ram.des_str.kwork[ 7];
u_ram.des_str.kn[18] = u_ram.des_str.kwork[15];
u_ram.des_str.kn[19] = u_ram.des_str.kwork[ 6];
u_ram.des_str.kn[20] = u_ram.des_str.kwork[26];
u_ram.des_str.kn[21] = u_ram.des_str.kwork[19];
u_ram.des_str.kn[22] = u_ram.des_str.kwork[12];
u_ram.des_str.kn[23] = u_ram.des_str.kwork[ 1];
u_ram.des_str.kn[24] = u_ram.des_str.kwork[40];
u_ram.des_str.kn[25] = u_ram.des_str.kwork[51];
u_ram.des_str.kn[26] = u_ram.des_str.kwork[30];
u_ram.des_str.kn[27] = u_ram.des_str.kwork[36];
u_ram.des_str.kn[28] = u_ram.des_str.kwork[46];
u_ram.des_str.kn[29] = u_ram.des_str.kwork[54];
u_ram.des_str.kn[30] = u_ram.des_str.kwork[29];
u_ram.des_str.kn[31] = u_ram.des_str.kwork[39];
u_ram.des_str.kn[32] = u_ram.des_str.kwork[50];
u_ram.des_str.kn[33] = u_ram.des_str.kwork[44];
u_ram.des_str.kn[34] = u_ram.des_str.kwork[32];
u_ram.des_str.kn[35] = u_ram.des_str.kwork[47];
u_ram.des_str.kn[36] = u_ram.des_str.kwork[43];
u_ram.des_str.kn[37] = u_ram.des_str.kwork[48];
u_ram.des_str.kn[38] = u_ram.des_str.kwork[38];
u_ram.des_str.kn[39] = u_ram.des_str.kwork[55];
u_ram.des_str.kn[40] = u_ram.des_str.kwork[33];
u_ram.des_str.kn[41] = u_ram.des_str.kwork[52];
u_ram.des_str.kn[42] = u_ram.des_str.kwork[45];
u_ram.des_str.kn[43] = u_ram.des_str.kwork[41];
u_ram.des_str.kn[44] = u_ram.des_str.kwork[49];
u_ram.des_str.kn[45] = u_ram.des_str.kwork[35];
u_ram.des_str.kn[46] = u_ram.des_str.kwork[28];
u_ram.des_str.kn[47] = u_ram.des_str.kwork[31];
/* KS Function End */
/* u_ram.des_str.worka XOR kn */
for (i = 0; i < 48; i++)
u_ram.des_str.worka[i] = u_ram.des_str.worka[i] ^ u_ram.des_str.kn[i];
/* 8 s-functions */
valindex = s1[2*u_ram.des_str.worka[ 0]+u_ram.des_str.worka[ 5]]
[2*(2*(2*u_ram.des_str.worka[ 1]+u_ram.des_str.worka[ 2])+
u_ram.des_str.worka[ 3])+u_ram.des_str.worka[ 4]];
//valindex = valindex * 4;
valindex = valindex <<2;
u_ram.des_str.kn[ 0] = binary[0+valindex];
u_ram.des_str.kn[ 1] = binary[1+valindex];
u_ram.des_str.kn[ 2] = binary[2+valindex];
u_ram.des_str.kn[ 3] = binary[3+valindex];
valindex = s2[2*u_ram.des_str.worka[ 6]+u_ram.des_str.worka[11]]
[2*(2*(2*u_ram.des_str.worka[ 7]+u_ram.des_str.worka[ 8])+
u_ram.des_str.worka[ 9])+u_ram.des_str.worka[10]];
//valindex = valindex * 4;
valindex = valindex <<2;
u_ram.des_str.kn[ 4] = binary[0+valindex];
u_ram.des_str.kn[ 5] = binary[1+valindex];
u_ram.des_str.kn[ 6] = binary[2+valindex];
u_ram.des_str.kn[ 7] = binary[3+valindex];
valindex = s3[2*u_ram.des_str.worka[12]+u_ram.des_str.worka[17]]
[2*(2*(2*u_ram.des_str.worka[13]+u_ram.des_str.worka[14])+
u_ram.des_str.worka[15])+u_ram.des_str.worka[16]];
//valindex = valindex * 4;
valindex = valindex <<2;
u_ram.des_str.kn[ 8] = binary[0+valindex];
u_ram.des_str.kn[ 9] = binary[1+valindex];
u_ram.des_str.kn[10] = binary[2+valindex];
u_ram.des_str.kn[11] = binary[3+valindex];
valindex = s4[2*u_ram.des_str.worka[18]+u_ram.des_str.worka[23]]
[2*(2*(2*u_ram.des_str.worka[19]+u_ram.des_str.worka[20])+
u_ram.des_str.worka[21])+u_ram.des_str.worka[22]];
//valindex = valindex * 4;
valindex = valindex <<2;
u_ram.des_str.kn[12] = binary[0+valindex];
u_ram.des_str.kn[13] = binary[1+valindex];
u_ram.des_str.kn[14] = binary[2+valindex];
u_ram.des_str.kn[15] = binary[3+valindex];
valindex = s5[2*u_ram.des_str.worka[24]+u_ram.des_str.worka[29]]
[2*(2*(2*u_ram.des_str.worka[25]+u_ram.des_str.worka[26])+
u_ram.des_str.worka[27])+u_ram.des_str.worka[28]];
//valindex = valindex * 4;
valindex = valindex <<2;
u_ram.des_str.kn[16] = binary[0+valindex];
u_ram.des_str.kn[17] = binary[1+valindex];
u_ram.des_str.kn[18] = binary[2+valindex];
u_ram.des_str.kn[19] = binary[3+valindex];
valindex = s6[2*u_ram.des_str.worka[30]+u_ram.des_str.worka[35]]
[2*(2*(2*u_ram.des_str.worka[31]+u_ram.des_str.worka[32])+
u_ram.des_str.worka[33])+u_ram.des_str.worka[34]];
//valindex = valindex * 4;
valindex = valindex <<2;
u_ram.des_str.kn[20] = binary[0+valindex];
u_ram.des_str.kn[21] = binary[1+valindex];
u_ram.des_str.kn[22] = binary[2+valindex];
u_ram.des_str.kn[23] = binary[3+valindex];
valindex = s7[2*u_ram.des_str.worka[36]+u_ram.des_str.worka[41]]
[2*(2*(2*u_ram.des_str.worka[37]+u_ram.des_str.worka[38])+
u_ram.des_str.worka[39])+u_ram.des_str.worka[40]];
//valindex = valindex * 4;
valindex = valindex <<2;
u_ram.des_str.kn[24] = binary[0+valindex];
u_ram.des_str.kn[25] = binary[1+valindex];
u_ram.des_str.kn[26] = binary[2+valindex];
u_ram.des_str.kn[27] = binary[3+valindex];
valindex = s8[2*u_ram.des_str.worka[42]+u_ram.des_str.worka[47]]
[2*(2*(2*u_ram.des_str.worka[43]+u_ram.des_str.worka[44])+
u_ram.des_str.worka[45])+u_ram.des_str.worka[46]];
//valindex = valindex * 4;
valindex = valindex <<2;
u_ram.des_str.kn[28] = binary[0+valindex];
u_ram.des_str.kn[29] = binary[1+valindex];
u_ram.des_str.kn[30] = binary[2+valindex];
u_ram.des_str.kn[31] = binary[3+valindex];
/* Permute - P */
u_ram.des_str.worka[ 0] = u_ram.des_str.kn[15];
u_ram.des_str.worka[ 1] = u_ram.des_str.kn[ 6];
u_ram.des_str.worka[ 2] = u_ram.des_str.kn[19];
u_ram.des_str.worka[ 3] = u_ram.des_str.kn[20];
u_ram.des_str.worka[ 4] = u_ram.des_str.kn[28];
u_ram.des_str.worka[ 5] = u_ram.des_str.kn[11];
u_ram.des_str.worka[ 6] = u_ram.des_str.kn[27];
u_ram.des_str.worka[ 7] = u_ram.des_str.kn[16];
u_ram.des_str.worka[ 8] = u_ram.des_str.kn[ 0];
u_ram.des_str.worka[ 9] = u_ram.des_str.kn[14];
u_ram.des_str.worka[10] = u_ram.des_str.kn[22];
u_ram.des_str.worka[11] = u_ram.des_str.kn[25];
u_ram.des_str.worka[12] = u_ram.des_str.kn[ 4];
u_ram.des_str.worka[13] = u_ram.des_str.kn[17];
u_ram.des_str.worka[14] = u_ram.des_str.kn[30];
u_ram.des_str.worka[15] = u_ram.des_str.kn[ 9];
u_ram.des_str.worka[16] = u_ram.des_str.kn[ 1];
u_ram.des_str.worka[17] = u_ram.des_str.kn[ 7];
u_ram.des_str.worka[18] = u_ram.des_str.kn[23];
u_ram.des_str.worka[19] = u_ram.des_str.kn[13];
u_ram.des_str.worka[20] = u_ram.des_str.kn[31];
u_ram.des_str.worka[21] = u_ram.des_str.kn[26];
u_ram.des_str.worka[22] = u_ram.des_str.kn[ 2];
u_ram.des_str.worka[23] = u_ram.des_str.kn[ 8];
u_ram.des_str.worka[24] = u_ram.des_str.kn[18];
u_ram.des_str.worka[25] = u_ram.des_str.kn[12];
u_ram.des_str.worka[26] = u_ram.des_str.kn[29];
u_ram.des_str.worka[27] = u_ram.des_str.kn[ 5];
u_ram.des_str.worka[28] = u_ram.des_str.kn[21];
u_ram.des_str.worka[29] = u_ram.des_str.kn[10];
u_ram.des_str.worka[30] = u_ram.des_str.kn[ 3];
u_ram.des_str.worka[31] = u_ram.des_str.kn[24];
/* u_ram.des_str.bufout XOR u_ram.des_str.worka */
for (i = 0; i < 32; i++) {
    u_ram.des_str.bufout[i+32] = u_ram.des_str.bufout[i] ^ u_ram.des_str.worka[i];
    u_ram.des_str.bufout[i] = u_ram.des_str.buffer[i];
}
} /* End of Iter */
/* Prepare Output */
for (i = 0; i < 32; i++) {
    j = u_ram.des_str.bufout[i];
    u_ram.des_str.bufout[i] = u_ram.des_str.bufout[32+i];
    u_ram.des_str.bufout[32+i] = j;
}
/* Inverse Initial Permutation */
u_ram.des_str.buffer[ 0] = u_ram.des_str.bufout[39];
u_ram.des_str.buffer[ 1] = u_ram.des_str.bufout[ 7];
u_ram.des_str.buffer[ 2] = u_ram.des_str.bufout[47];
u_ram.des_str.buffer[ 3] = u_ram.des_str.bufout[15];
u_ram.des_str.buffer[ 4] = u_ram.des_str.bufout[55];
u_ram.des_str.buffer[ 5] = u_ram.des_str.bufout[23];
u_ram.des_str.buffer[ 6] = u_ram.des_str.bufout[63];
u_ram.des_str.buffer[ 7] = u_ram.des_str.bufout[31];
u_ram.des_str.buffer[ 8] = u_ram.des_str.bufout[38];
u_ram.des_str.buffer[ 9] = u_ram.des_str.bufout[ 6];
u_ram.des_str.buffer[10] = u_ram.des_str.bufout[46];
u_ram.des_str.buffer[11] = u_ram.des_str.bufout[14];
u_ram.des_str.buffer[12] = u_ram.des_str.bufout[54];
u_ram.des_str.buffer[13] = u_ram.des_str.bufout[22];
u_ram.des_str.buffer[14] = u_ram.des_str.bufout[62];
u_ram.des_str.buffer[15] = u_ram.des_str.bufout[30];
u_ram.des_str.buffer[16] = u_ram.des_str.bufout[37];
u_ram.des_str.buffer[17] = u_ram.des_str.bufout[ 5];
u_ram.des_str.buffer[18] = u_ram.des_str.bufout[45];
u_ram.des_str.buffer[19] = u_ram.des_str.bufout[13];
u_ram.des_str.buffer[20] = u_ram.des_str.bufout[53];
u_ram.des_str.buffer[21] = u_ram.des_str.bufout[21];
u_ram.des_str.buffer[22] = u_ram.des_str.bufout[61];
u_ram.des_str.buffer[23] = u_ram.des_str.bufout[29];
u_ram.des_str.buffer[24] = u_ram.des_str.bufout[36];
u_ram.des_str.buffer[25] = u_ram.des_str.bufout[ 4];
u_ram.des_str.buffer[26] = u_ram.des_str.bufout[44];
u_ram.des_str.buffer[27] = u_ram.des_str.bufout[12];
u_ram.des_str.buffer[28] = u_ram.des_str.bufout[52];
u_ram.des_str.buffer[29] = u_ram.des_str.bufout[20];
u_ram.des_str.buffer[30] = u_ram.des_str.bufout[60];
u_ram.des_str.buffer[31] = u_ram.des_str.bufout[28];
u_ram.des_str.buffer[32] = u_ram.des_str.bufout[35];
u_ram.des_str.buffer[33] = u_ram.des_str.bufout[ 3];
u_ram.des_str.buffer[34] = u_ram.des_str.bufout[43];
u_ram.des_str.buffer[35] = u_ram.des_str.bufout[11];
u_ram.des_str.buffer[36] = u_ram.des_str.bufout[51];
u_ram.des_str.buffer[37] = u_ram.des_str.bufout[19];
u_ram.des_str.buffer[38] = u_ram.des_str.bufout[59];
u_ram.des_str.buffer[39] = u_ram.des_str.bufout[27];
u_ram.des_str.buffer[40] = u_ram.des_str.bufout[34];
u_ram.des_str.buffer[41] = u_ram.des_str.bufout[ 2];
u_ram.des_str.buffer[42] = u_ram.des_str.bufout[42];
u_ram.des_str.buffer[43] = u_ram.des_str.bufout[10];
u_ram.des_str.buffer[44] = u_ram.des_str.bufout[50];
u_ram.des_str.buffer[45] = u_ram.des_str.bufout[18];
u_ram.des_str.buffer[46] = u_ram.des_str.bufout[58];
u_ram.des_str.buffer[47] = u_ram.des_str.bufout[26];
u_ram.des_str.buffer[48] = u_ram.des_str.bufout[33];
u_ram.des_str.buffer[49] = u_ram.des_str.bufout[ 1];
u_ram.des_str.buffer[50] = u_ram.des_str.bufout[41];
u_ram.des_str.buffer[51] = u_ram.des_str.bufout[ 9];
u_ram.des_str.buffer[52] = u_ram.des_str.bufout[49];
u_ram.des_str.buffer[53] = u_ram.des_str.bufout[17];
u_ram.des_str.buffer[54] = u_ram.des_str.bufout[57];
u_ram.des_str.buffer[55] = u_ram.des_str.bufout[25];
u_ram.des_str.buffer[56] = u_ram.des_str.bufout[32];
u_ram.des_str.buffer[57] = u_ram.des_str.bufout[ 0];
u_ram.des_str.buffer[58] = u_ram.des_str.bufout[40];
u_ram.des_str.buffer[59] = u_ram.des_str.bufout[ 8];
u_ram.des_str.buffer[60] = u_ram.des_str.bufout[48];
u_ram.des_str.buffer[61] = u_ram.des_str.bufout[16];
u_ram.des_str.buffer[62] = u_ram.des_str.bufout[56];
u_ram.des_str.buffer[63] = u_ram.des_str.bufout[24];
j = 0;
for (i = 0; i < 8; i++) {
    *(dest + i) = 0x00;
    for (k = 0; k < 7; k++)
    *(dest + i) = ((*(dest + i)) + u_ram.des_str.buffer[j+k]) * 2;
    *(dest + i) = *(dest + i) + u_ram.des_str.buffer[j+7];
    j += 8;
}
return 0;
}


/////

//? hex(inbuf(5)),hex(inbuf(6)),hex(inbuf(7)),hex(inbuf(8)),hex(inbuf(9)),hex(inbuf(10)),hex(inbuf(11)),hex(inbuf(12))
//F7            35            4B            5B            1F            74            2C            3
//uid  FF39475A19741203
//key 
//? hex(Akey(0)),hex(Akey(1)),hex(Akey(2)),hex(Akey(3)),hex(Akey(4)),hex(Akey(5)),hex(Akey(6)),hex(Akey(7))
// E8            79            23            42            89            AF            E1            DF
//result  00 
//? hex(inbuf(8+5)),hex(inbuf(8+6)),hex(inbuf(8+7)),hex(inbuf(8+8)),hex(inbuf(8+9)),hex(inbuf(8+10)),hex(inbuf(8+11)),hex(8+inbuf(12))
//E8            67            52            DF            C5            4F            A2            B
/*
unsigned  char specialdeschk(unsigned char *snr,unsigned char * in,unsigned char * out)
{	
	//xor snr[8] then des
		unsigned char snradvant[8];
		unsigned char temp;

		unsigned char km[8];
		unsigned i;

		for(i=0;i<8;i++)	snradvant[i]=snr[i];
		temp=snradvant[1];
		snradvant[1]=snradvant[3];
		snradvant[3]=temp;

		for(i=0;i<8;i++)
		{
			in[i]=in[i]^snradvant[i];

		}




		des(&in[0],&km[0],k,1);
			
		if(memcmp(out, km,8)==0)
		{
			return 0;
		}
		else
		{	 
		return 1;
		}
}
*/
