#ifndef	_St_wcdma_H
#define		_St_wcdma_H

#ifdef JM3G_UPDATE
//����4G����ǰ
#define WCDMA_Power_ON  	 GPIOG->BSRR = 0x00008000 //15
#define WCDMA_Power_OFF    GPIOG->BSRR = 0x80000000 
#else
//����4G������
#define WCDMA_Power_OFF  	 GPIOG->BSRR = 0x00008000 //15
#define WCDMA_Power_ON    GPIOG->BSRR = 0x80000000 
#endif

#define CLOSE_Power_3G    jishu=1;close_wcdma_modem(); GPRS_LINKing=0;LED1_OPEN;f_enablecard=0;RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);UartCtrl_0
extern void USART_SendDataPacket(USART_TypeDef* USARTx, uint16_t Data, u8 *Senddata);
extern void Wcdma_main(void);
extern void open_wcdma_modem(void);
extern void close_wcdma_modem(void);
extern void uart_send_sombufall(unsigned char *ptr,unsigned int k);
//void SerialPutString(uint8_t *s);

#endif
