#include "rate_JM.h"
#include "Do_Task.h"

//#define car1        1
//#define car2        2
//#define car3        3
//#define car4        4


#define car1_use_info                       0x0000
#define car2_use_info                       0x0010
#define car3_use_info                       0x0020
#define car4_use_info                       0x0030

uchar year;
uchar month;
uchar day;
uchar hour;
uchar min;
uchar week;

unsigned long stop_time=0;

uchar ChargeStart_H;    //�շѿ�ʼʱ�� ��λ��Сʱ BCD
uchar ChargeStart_M;    //�շѿ�ʼʱ�� ��λ������ BCD
uchar ChargeEnd_H;      //�շѽ���ʱ�� ��λ��Сʱ BCD
uchar ChargeEnd_M;      //�շѽ���ʱ�� ��λ������ BCD
    
uchar SaleBase;         //�ۿۻ��� ��λ 64H - 01H HEX
uchar MaxStop_Momery;   //�������ͣ������ ��λ:Ԫ HEX
uchar MinCharge_Time;   //��С�շ�ʱ�� ��λ:���� BCD
uchar MinCharge_Monery; //��С�շѽ�� ��λ��Ԫ HEX
uchar StartFree_Time;   //����Ѳ���ʱ�� ��λ������ BCD
    
uchar Nightcharge;      //ҹ���շ� ��λ��Ԫ HEX
uchar MaxPark_Time;     //������󲴳�ʱ�� ��λ��Сʱ BCD

uchar PrivilegeTime;    //ǰ���Ż�ʱ��
uchar PrivilegeBase;    //ǰ���Ż�ʱ�� ����
uchar NormalTime;       //���������շ�ʱ��
uchar NormalBase;       //���������շ�ʱ�����
    
Rate_reference_ST RR_ST;

void get_rate_ref(Rate_reference_ST* RR)
{
    u8 buffer[16],BCC;
	u8 buffer1[32]= {0xDD,0x43 ,0x61 ,0x72 ,0x64 ,0x40 ,0x68 ,0x6F ,0x72 ,
		0x6F ,0x61 ,0x64 ,0x2E ,0x63 ,0x6F ,0x6D ,0x2E ,0x63 ,0x6E ,
		0xFF ,0x43 ,0x61 ,0x72 ,0x64 ,0xFF ,0xFF};
 //�û�����Card@horoad.com.cn���룺Card   
    BCC = 0x00;
    I2C_ReadS_24C(B_startTime_unit_of_hour,buffer,16);
    //I2C_ReadS_24C(B_startTime_unit_of_hour+12,buffer+12,4);
    for(uchar i=0;i<15;i++)
      BCC = BCC ^ buffer[i];

	
/*	//��ԭΪ������Կ//;wencheng key  610639610639
	buffer[0]=0x61;
	buffer[1]=0x06;
	buffer[2]=0x39;
	buffer[3]=0x61;
	buffer[4]=0x06;
	buffer[5]=0x39;
	buffer[6] = buffer[0] ^ buffer[1] ^ buffer[2] ^ buffer[3] ^ buffer[4] ^ buffer[5];
	I2C_WriteS_24C(sysytem_public_key,buffer,7);  //���ܺ����в�������
	I2C_WriteS_24C(sysytem_public_key_back,buffer,7);
	I2C_WriteS_24C(APNuser_possword,buffer1+1,31);//��APN
    BCC =0;//����*/
    if (BCC != buffer[15])
    {
        BCC = 0x00;
        I2C_ReadS_24C(back_argument_of_charge,buffer,16);
        for(uchar i=0;i<15;i++)
          BCC = BCC ^ buffer[i];
        
        if(BCC != buffer[14])
        {//55002109643202033000240204991200
			buffer[0] = 0x00;
			buffer[1] = 0x21;
			buffer[2] = 0x09;
			buffer[3] = 100;
			buffer[4] = 50;
			buffer[5] = 0x02;
			buffer[6] = 0x03;
			buffer[7] = 0x30;
			buffer[8] = 0x00;
			buffer[9] = 0x24;
			buffer[10] = 0x02;
			buffer[11] = 0x04;
			buffer[12] = 0x99;
			buffer[13] = 0x12;
			buffer[14] = 0x30;
			buffer[15] = 0xF3;
            
            BCC = 0x00;
            for(uchar i=0;i<15;i++)
              BCC = BCC ^ buffer[i];
            buffer[15] = BCC;            
            
            I2C_WriteS_24C(B_startTime_unit_of_hour,buffer,16);
            I2C_WriteS_24C(back_argument_of_charge,buffer,16);
        }
        else
        {
            I2C_WriteS_24C(B_startTime_unit_of_hour,buffer,16);
        }
    }
 
    
    RR->Charge_End_M = (((buffer[0]>>4)&0x0f)*10) + (buffer[0]&0x0f); //�շѿ�ʼʱ�� ��λ��Сʱ BCD
    RR->Charge_End_H = (((buffer[1]>>4)&0x0f)*10) + (buffer[1]&0x0f); //�շѿ�ʼʱ�� ��λ������ BCD
    RR->Charge_Start_H = (((buffer[2]>>4)&0x0f)*10) + (buffer[2]&0x0f);//�շѽ���ʱ�� ��λ��Сʱ BCD
//    RR->Charge_End_M = (((buffer[3]>>4)&0x0f)*10) + (buffer[3]&0x0f);//�շѽ���ʱ�� ��λ������ BCD
    RR->Charge_Start_M = (((buffer[14]>>4)&0x0f)*10) + (buffer[14]&0x0f);//�շѽ���ʱ�� ��λ������ BCD

    RR->Sale_Base = buffer[3];//�ۿۻ��� ��λ 64H - 01H HEX
    RR->Max_Stop_Momery = buffer[4];//�������ͣ������ ��λ:Ԫ HEX
//    RR->Min_Charge_Time = (((buffer[5]>>4)&0x0f)*10) + (buffer[5]&0x0f);//��С�շ�ʱ�� ��λ:���� BCD
    RR->Min_Charge_Time = 60/buffer[5];//��С�շ�ʱ�� ��λ:���� BCD
    RR->Min_Charge_Monery = buffer[6];//��С�շѽ�� ��λ��Ԫ HEX
    RR->Start_Free_Time = (((buffer[7]>>4)&0x0f)*10) + (buffer[7]&0x0f);//����Ѳ���ʱ�� ��λ������ BCD
    
    RR->Night_charge = buffer[8];//ҹ���շ� ��λ��Ԫ HEX
    RR->Max_Park_Time = (((buffer[9]>>4)&0x0f)*10) + (buffer[9]&0x0f);//������󲴳�ʱ�� ��λ��Сʱ BCD
    
    RR->Frist_time = buffer[10];//��ʱ����
    RR->Frist_Money = buffer[11];//���շѱ���
    
}
//��ȡ ��ǰ�Ƿ��� ���ʱ��
char get_current_time()
{
    GetCurrentTime();
    get_rate_ref(&RR_ST);
    
    year = time1[4];
    month = time1[3];
    day = time1[2];
    hour = time1[1];
    min = time1[0];
       
        if(hour > RR_ST.Charge_Start_H && hour < RR_ST.Charge_End_H)
        {
            return 1;
        }
        else
        {
            if(hour == RR_ST.Charge_Start_H && min >= RR_ST.Charge_Start_M)
              return 1;
            else if(hour == RR_ST.Charge_End_H && min < RR_ST.Charge_End_M)
              return 1;
            else
              return 0;
        }
    
    
}

//BCDתʮ������     
u8 BCDtoHex(u8 a)    
{    
    u8 t_h,t_l;    
        
    t_h = (a&0xf0)>>4;    
    t_l = a&0x0f;    
        
    a = t_h*10 + t_l;            
    return a; 
}

u16 parkfeetime_count(u8 pkintm[2],u8 pkouttm[2])
{
	u8 parkinhr,parkinmn,parkouthr,parkoutmn;
	u8 sthr,stmn,endhr,endmn;
	u16 feeparktime,STTIME,ENDTIME,INTIME,OUTTIME;

	parkinhr  =  BCDtoHex(pkintm[0]);
	parkinmn  =  BCDtoHex(pkintm[1]);
	parkouthr =  pkouttm[1];
	parkoutmn =  pkouttm[0];
	sthr  = (RR_ST.Charge_Start_H);
	stmn  = (RR_ST.Charge_Start_M);
	endhr = (RR_ST.Charge_End_H);
	endmn = (RR_ST.Charge_End_M);

	STTIME = sthr*60+stmn;				//�շѿ�ʼʱ��
	ENDTIME = endhr*60+endmn;			//�շѽ�ֹʱ��
	INTIME = parkinhr*60+parkinmn;		//��������ʱ��
	OUTTIME = parkouthr*60+parkoutmn;	//��������ʱ��
	
// 1-���ǰ���볡 0:00<= INTIME <8:00
	if((INTIME>=0)&&(INTIME<STTIME))
		{
		// 1-1 ���ǰ�γ��� 0:00<= OUTTIME <8:00	
		if((OUTTIME>=0)&&(OUTTIME<STTIME))
			{
			// 1-1-1 OUTTIME<INTIME 
			if(OUTTIME<INTIME)	
				feeparktime = ENDTIME - STTIME;
			// 1-1-2 OUTTIME>=INTIME  OUTTIME=INTIME ʱ ��Ҫ�ж�ʵ�ʲ���ʱ�� �Ƿ��ҹ����
			else
				feeparktime = 0;
			}
		// 1-2 �շѶγ��� 8:00<= OUTTIME <22:00 
		else if((OUTTIME>=STTIME)&&(OUTTIME<ENDTIME))
				{
				feeparktime = OUTTIME - STTIME;
				}
		// 1-3 ��Ѻ�γ��� 22:00<= OUTTIME <24:00	
		else if((OUTTIME>=ENDTIME)&&(OUTTIME<1440))
				{
				feeparktime = ENDTIME - STTIME;
				}			
		}
	
// 2-�շѶ��볡 8:00<= INTIME <22:00
	else if((INTIME>=STTIME)&&(INTIME<ENDTIME))
		{
		// 2-1 ���ǰ�γ��� 0:00<= OUTTIME <8:00	
		if((OUTTIME>=0)&&(OUTTIME<STTIME))
			{
			feeparktime = ENDTIME - INTIME;
			}
		// 2-2 �շѶγ��� 8:00<= OUTTIME <22:00 
		else if((OUTTIME>=STTIME)&&(OUTTIME<ENDTIME))
			{
			// 2-2-1 OUTTIME>=INTIME	
			if(OUTTIME>=INTIME)
				feeparktime = OUTTIME - INTIME;
			// 3-3-2 OUTTIME<=INTIME  OUTTIME=INTIME ʱ ��Ҫ�ж�ʵ�ʲ���ʱ�� �Ƿ��ҹ����
			else
				feeparktime = OUTTIME - STTIME + ENDTIME - INTIME;
			}
		// 2-3 ��Ѻ�γ��� 22:00<= OUTTIME <24:00	
		else if((OUTTIME>=ENDTIME)&&(OUTTIME<1440))
			{
			feeparktime = ENDTIME - INTIME;
			}			
		}		

// 3-��Ѻ���볡 22:00<= INTIME <24:00
	else if((INTIME>=ENDTIME)&&(INTIME<1440))
		{
		// 3-1 ���ǰ�γ��� 0:00<= OUTTIME <8:00	
		if((OUTTIME>=0)&&(OUTTIME<STTIME))
			{
			feeparktime = 0;
			}
		// 3-2 �շѶγ��� 8:00<= OUTTIME <22:00 
		else if((OUTTIME>=STTIME)&&(OUTTIME<ENDTIME))
			{
			feeparktime = OUTTIME - STTIME;
			}
		// 3-3 ��Ѻ�γ��� 22:00<= OUTTIME <24:00	
		else if((OUTTIME>=ENDTIME)&&(OUTTIME<1440))
			{
			// 3-3-1 OUTTIME<INTIME 
			if(OUTTIME<INTIME)	
				feeparktime = ENDTIME - STTIME;
			// 3-3-2 OUTTIME>=INTIME  OUTTIME=INTIME ʱ ��Ҫ�ж�ʵ�ʲ���ʱ�� �Ƿ��ҹ����
			else
				feeparktime = 0;
			}			
		}

	return	feeparktime;
}

u16 time_to_momery(u8 time_buffer[])
{
    u8 mintime,ftime;    
    u16 stop_time,park_memory,parkfee_time;    
    
    get_rate_ref(&RR_ST);    
    GetCurrentTime();    
    stop_time = ret_max_24hour(time_buffer,PARK_CARD);//ʵ�ʲ���ʱ��
	parkfee_time = parkfeetime_count(time_buffer+2,time1);//�շѲ���ʱ��
	mintime = (RR_ST.Min_Charge_Time);
	
	if(stop_time>=1440)//����24Сʱ����� 2015-03-16
		parkfee_time = 15*60;

	park_memory = 0;
	if(parkfee_time>RR_ST.Start_Free_Time)
		{
		stop_time = parkfee_time/mintime;
		ftime = parkfee_time%mintime;
		switch(stop_time)
			{
			case 0:
				break;
			case 1:
//			case 2: 
//			case 3: 
				park_memory = RR_ST.Frist_Money;
				break;
			default:
				if(ftime >15)stop_time++;	
				park_memory = RR_ST.Frist_Money;
//				park_memory += (stop_time-2)*RR_ST.Night_charge;
				park_memory += (stop_time-2)*RR_ST.Min_Charge_Monery;
				if(park_memory>RR_ST.Max_Stop_Momery)
					park_memory = RR_ST.Max_Stop_Momery;
				break;		
			}
		park_memory	*= RR_ST.Sale_Base;
		}	
	
    return park_memory;    
}
//�ĳɶ��Ʒ��� ����շ�20Ԫ
u16 time_to_momeryWC(u8 time_buffer[])
{
    u8 mintime;    
    u16 stop_time,park_memory,parkfee_time;    
    
    get_rate_ref(&RR_ST);    
    GetCurrentTime();    
    stop_time = ret_max_24hour(time_buffer,PARK_CARD);//ʵ�ʲ���ʱ��
	parkfee_time = parkfeetime_count(time_buffer+2,time1);//�շѲ���ʱ��
	mintime = (RR_ST.Min_Charge_Time);
	
	if(stop_time>=1440)//����24Сʱ����� 2015-03-16
		parkfee_time = 15*60;

	park_memory = 0;
	if(parkfee_time>RR_ST.Start_Free_Time)
		{
		stop_time = parkfee_time/mintime;
		if(parkfee_time%mintime)stop_time++;	
		switch(stop_time)
			{
			case 1:
			case 2: 
//			case 3: 
				park_memory = RR_ST.Min_Charge_Monery;
				break;
			default:
				if((stop_time>2)&&(stop_time<11))
					{
					park_memory = RR_ST.Min_Charge_Monery;
//					park_memory += (stop_time-2)*RR_ST.Night_charge;
					park_memory += (stop_time-2)*RR_ST.Min_Charge_Monery;
					}
				else
					park_memory = RR_ST.Max_Stop_Momery;
				break;		
			}
		park_memory	*= RR_ST.Sale_Base;
		}	
	
    return park_memory;    
}
//�ĳɶ��Ʒ��� ��󲴳�ʱ��Ϊ24Сʱ
u16 momery_to_timeWC(u32 moneycard)
{
    u16 stop_time,parkfee_time,CMPmny,freeparktime;    
	u8 mintime,parkinhr,parkinmn,sthr,stmn,endhr,endmn;
	u32 Cardmny;
    get_rate_ref(&RR_ST);    
    GetCurrentTime();    
	
	mintime = (RR_ST.Min_Charge_Time);
	parkinhr  =  time1[1];
	parkinmn  =  time1[0];
	sthr  = (RR_ST.Charge_Start_H);
	stmn  = (RR_ST.Charge_Start_M);
	endhr = (RR_ST.Charge_End_H);
	endmn = (RR_ST.Charge_End_M);

	parkfee_time = 0;
	// 	1.���ǰ���볡
	if((parkinhr>endhr)||((parkinhr==endhr)&&(parkinmn>=endmn)))
		freeparktime = (24-parkinhr)*60-parkinmn+sthr*60+stmn;	
	// 2. ��Ѻ���볡
	else if((parkinhr<sthr)||((parkinhr==sthr)&&(parkinmn<=stmn)))
		freeparktime = (sthr-parkinhr)*60-parkinmn+stmn;	
	// 	3.�շѶ��볡
	else
		{
		parkfee_time = (endhr-parkinhr)*60-parkinmn+endmn;
		freeparktime = (24-endhr)*60-endmn+sthr*60+stmn;	
		}
	Cardmny = moneycard;
	CMPmny = RR_ST.Max_Stop_Momery*RR_ST.Sale_Base;
	
#ifdef OVERDRAFT //��͸֧������� 2015-04-27
	CMPmny = Cardmny;
#endif

	if(Cardmny >= CMPmny)
		stop_time = RR_ST.Max_Park_Time*60;		
	else 
		{
		CMPmny = RR_ST.Min_Charge_Monery*RR_ST.Sale_Base;
		stop_time = 0;
		if(Cardmny >= CMPmny)
			{
			stop_time = 60;	
			stop_time += (Cardmny-CMPmny)/RR_ST.Sale_Base/RR_ST.Min_Charge_Monery*mintime;
			if(Cardmny%CMPmny)
				stop_time += mintime;//С����Ż�2014-03-11			
			}
		}
	if(stop_time >parkfee_time)
		stop_time += freeparktime;		
	if(stop_time >=1440)
		stop_time = 1440;

    return stop_time;    
}
u16 momery_to_time(u32 moneycard)
{
    u16 stop_time,parkfee_time,CMPmny,freeparktime;    
	u8 mintime,parkinhr,parkinmn,sthr,stmn,endhr,endmn;
	u32 Cardmny;
    get_rate_ref(&RR_ST);    
    GetCurrentTime();    
	
	mintime = (RR_ST.Min_Charge_Time);
	parkinhr  =  time1[1];
	parkinmn  =  time1[0];
	sthr  = (RR_ST.Charge_Start_H);
	stmn  = (RR_ST.Charge_Start_M);
	endhr = (RR_ST.Charge_End_H);
	endmn = (RR_ST.Charge_End_M);

	parkfee_time = 0;
	// 	1.���ǰ���볡
	if((parkinhr>endhr)||((parkinhr==endhr)&&(parkinmn>=endmn)))
		freeparktime = (24-parkinhr)*60-parkinmn+sthr*60+stmn;	
	// 2. ��Ѻ���볡
	else if((parkinhr<sthr)||((parkinhr==sthr)&&(parkinmn<=stmn)))
		freeparktime = (sthr-parkinhr)*60-parkinmn+stmn;	
	// 	3.�շѶ��볡
	else
		{
		parkfee_time = (endhr-parkinhr)*60-parkinmn+endmn;
		freeparktime = (24-endhr)*60-endmn+sthr*60+stmn;	
		}
	Cardmny = moneycard;
	CMPmny = RR_ST.Max_Stop_Momery*RR_ST.Sale_Base;
	
#ifdef OVERDRAFT //��͸֧������� 2015-04-27
	CMPmny = Cardmny;
#endif

	if(Cardmny >= CMPmny)
		stop_time = RR_ST.Max_Park_Time*60;		
	else 
		{
		CMPmny = RR_ST.Frist_Money*RR_ST.Sale_Base;
		stop_time = 0;
		if(Cardmny >= CMPmny)
			{
			stop_time = 60;	
			stop_time += (Cardmny-CMPmny)/RR_ST.Sale_Base/RR_ST.Min_Charge_Monery*mintime;
			if((Cardmny-CMPmny)%RR_ST.Min_Charge_Monery)
				stop_time += mintime;//С����Ż�2014-03-11	
			
			stop_time += 15;//2015-08-20 ����С����Ż�
			}
		}
	if(stop_time >parkfee_time)
		stop_time += freeparktime;		
	if(stop_time >=1440)
		stop_time = 1440;

    return stop_time;    
}


