#ifndef	_UPGRADE_H
#define		_UPGRADE_H
extern u8 buff[1024];
int upgrade(void);			    
void upgrade1(void);
#endif 
