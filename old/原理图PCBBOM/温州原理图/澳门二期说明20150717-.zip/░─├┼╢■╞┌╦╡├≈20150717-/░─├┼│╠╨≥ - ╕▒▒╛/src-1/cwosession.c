//-----------------------------------------------------------------------------
//
// Owner.......: (c) 2000, CALE AB, Sweden
// File Name...: cwocommhandler.cpp
// Descriptions: Implements protocol and network functions to communicate with
//				 CWO backoffice system.
// Created.....: 2006-05-16  Johan Johansson
// Modified....:
//

//-----------------------------------------------------------------------------
// Cale History

//-----------------------------------------------------------------------------
// INCLUDE FILES
//-----------------------------------------------------------------------------
#include "cwosession.h"
#include <wchar.h>
///////////////////////////////////////////
#include <string.h>
#include "stm32f10x_conf.h"
#include "hal.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Count.h"
#include "Key.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include "Gprs_online.h"

#include "stm32f10x_usart.h"
#include "stm32f10x_it.h"
#include "misc.h"
#include "math.h"
#include "main.h"
#include "Card.h"
#include "MemoryAssign.h"
#include "coin.h"
#include "spi_flash.h"
#include "I2C_Driver.h"
#include "loader.h"
#include "stm32f10x_wwdg.h"
#include "zlib.h"
///////////////////////////////////////////

//Buffers
u8 sz2[2048];
u8 sz3[2048];

//CRC implementation
unsigned short CRCCITT(char *data_p, unsigned int length)
{
  
  int startvalue = 0xFFFF;
  
  unsigned int crc = startvalue;
  int i;
  for(i=0; i < (int)length; i++) 
  { 
    crc = (unsigned char)(crc >> 8) | (crc << 8); 
    crc ^= (unsigned char)data_p[i];
    crc ^= (unsigned char)(crc & 0xff) >> 4;
    crc ^= (crc << 8) << 4;
    crc ^= ((crc & 0xff) << 4) << 1; 
  }
  return crc;
}

//Memory allocation
void* GetMemory(size_t size,const char* callerName){ return malloc(size); }
void ReleaseMemory(void* pointer){ free(pointer); }

//Logging

//Define no logging for now
void LOG(tLogLevel level, const char* logString, ...)
{
  
}

//Connect to the server
CDS_RETVAL CreateSession(const char* hostName, const char* hostPort, unsigned long connectionTimeout)
{
  u32 linkacktime;
  
  close_wcdma_modem(); 
  GPRS_LINKing=0;
  LED1_OPEN;
  f_enablecard=0; 
  delay(KEYTIMEOUT_1S*5);
  
  open_wcdma_modem();
  delay(KEYTIMEOUT_1S*10);
  
  uart_send_som("*<IP1><94.246.76.138><PT1><50952><IP2><94.246.76.138><PT2><50952><APN><");
  uart_send(0x22);
  uart_send_som("3gnet");  
  uart_send(0x22);   
  uart_send_som(","); 
  uart_send(0x22);
  uart_send_som("USER");
  uart_send(0x22); 
  uart_send_som(","); 
  uart_send(0x22);  
  uart_send_som("GPRS");  
  uart_send(0x22);
  uart_send_som(">#");  
  //  uart_send_som(""3gnet","USER","GPRS">#");
  delay(KEYTIMEOUT_1S*1); 
  ////////////////////////////////////////////////////////////////
  f_connectOK=0;
  uart_send_som("*wak2#");
  delay(KEYTIMEOUT_1S/2);
  uart_send_som("*wak2#");  
  linkacktime = KEYTIMEOUT_1S*10;
  while(linkacktime--)
  {
    if(key_flag==5)
    {
      //CLOSE_Power_3G;
      Sleep__3G_CDMA;
      delay(KEYTIMEOUT_1S);                                      
      Sleep__3G_CDMA;   
      return FALSE;
    }    
    if(f_connectOK==1)
      break;
    if((linkacktime==1)||(linkacktime==0))
    {
      CLOSE_Power_3G;
      return FALSE;
    }
  }
  // Sleep__3G_CDMA;
  //delay(KEYTIMEOUT_1S);                                      
  //Sleep__3G_CDMA;  
  ////////////////////////////////////////////////////////////////
  LED1_CLOSE;  
  //////////////////////////////////////////////////////////////////
  
  return OK;
  //////////////////////////////////////////////////  
}

//Disconnect from the server
CDS_RETVAL DestroySession()
{
//  Sleep__3G_CDMA;
//  delay(KEYTIMEOUT_1S);                                      
//  Sleep__3G_CDMA;
  return OK;
}

//Send the data in sendBuffer (send length equal to sendBufferLen) and receive the response in recvBuffer (received length in recvBufferLen).
//Caller is responsible to free the memory allocated in SocketSendAndRecv function with a call to ReleaseMemory
/*
CDS_RETVAL SocketSendAndRecv(const unsigned char* sendBuffer, 
unsigned long sendBufferLen, 
unsigned char** recvBuffer, 
unsigned long* recvBufferLen,
unsigned long readTimeout)
{

return OK;   
}*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//-----------------------------------------------------------------------------
/// <summary>
/// Sends a request buffer and receives a response buffer according to request
/// response pattern in the backoffice gateway protocol.
/// </summary>
/// <param name="CWOSESSION session">Socket to use for sending and receiving the data</param>
/// <param name="const unsigned char * sendBuffer">The output buffer to send as a request message</param>
/// <param name="unsigned long sendBufferLen">Length of the request message</param>
/// <param name="unsigned char * * recvBuffer">Pointer to a receive buffer. 
///  Memory for this buffer is allocated dynamically in this method. Receiver is responsible for release of memory</param>
/// <param name="unsigned long * recvBufferLen">Length of the response buffer received (and allocated)</param>
/// <param name="unsigned long readTimeout">The timeout used to wait for a response from gateway</param>
/// <returns>CDS_RETVAL</returns>
//-----------------------------------------------------------------------------
CDS_RETVAL SocketSendAndRecv(
                             const unsigned char* sendBuffer, 
                             unsigned long sendBufferLen, 
                             unsigned char** recvBuffer, 
                             unsigned long* recvBufferLen,
                             unsigned long readTimeout)
{
  CDS_RETVAL retVal;
  long result;
  char* tempBuffer;
  unsigned long recvBufferOffset;
  unsigned char messageHeaderFound = FALSE;
  unsigned long dataLength = 0;
  unsigned int i;
  u32 linkacktime5;
  
  //send the request to the server
  ///////////////////////////////////////////////////////////////////////////////////////////
  uart_send_no_ascii(0x01); 
  for(i=0;i<sendBufferLen;i++)
  {
    uart_send_no_ascii(sendBuffer[i]);
  }
  uart_send_no_ascii(0x04);
  f_receiveOK=0;
  linkacktime5 = KEYTIMEOUT_1S*10;
  while(linkacktime5--)
  {
    if(f_receiveOK==1)
      break;
    if((linkacktime5==1)||(linkacktime5==0)||(key_flag==5))
    {
      //CLOSE_Power_3G;  
      return CDS_ERROR_SOCKET;
    }
  }
  
  //for(i=0;(i<RxCounter) && ;i++)
  //  tempBuffer[i]=RxBuffer[i];
  
  
  //Allocate space for temp buffer
  tempBuffer = sz2;//(char*)GetMemory(RECV_BUFFER_MAX_LENGTH+1, "SocketSendAndRecv tempBuffer");
  if(NULL == tempBuffer)
  {
    LOG(cLevelError, "SocketSendAndRecv: Failed to allocate %d bytes for tempBuffer", RECV_BUFFER_MAX_LENGTH+1);
    return CDS_ERROR_OUT_OF_MEMORY;
  }
  
  //Allocate initial buffer memory (expanded if needed below)
  *recvBufferLen = RECV_BUFFER_MAX_LENGTH;
  *recvBuffer = sz3;//(unsigned char*)GetMemory(*recvBufferLen, "SocketSendAndRecv");
  if(NULL == *recvBuffer)
  {
    //ReleaseMemory(tempBuffer);
    LOG(cLevelError, "SocketSendAndRecv: Failed to allocate %d bytes for recvBuffer", *recvBufferLen);
    return CDS_ERROR_OUT_OF_MEMORY;
  }
  
  recvBufferOffset = 0;
  messageHeaderFound = FALSE;
  
  //enter receive loop
  for(;;)
  {
    
    //read data from server
    LOG(cLevelDebug, "SocketSendAndRecv: Calling recv...");
    for(i=0;i<RxCounter && i < RECV_BUFFER_MAX_LENGTH;++i)
      tempBuffer[i]= RxBuffer[i];
    
    tempBuffer++;
    result = i-2;
    
    LOG(cLevelDebug, "SocketSendAndRecv: Read %d bytes from server", result);
    
    if(0 == result) //socket has been gracefully closed on remote side
    {
      LOG(cLevelInfo, "SocketSendAndRecv: socket gracefully closed");
      retVal = OK;
      break;
    }
    else //we got data
    {
      LOG(cLevelDebug, "SocketSendAndRecv: we got %d data bytes", result);
      
      //if data fits in result buffer copy it
      if(*recvBufferLen >= (recvBufferOffset + result))
      {
        //copy received data to result buffer
        memcpy((*recvBuffer)+recvBufferOffset, tempBuffer, result);
        
        //set start address for next memcpy (if we get more data)
        recvBufferOffset += result;
        
        if(!messageHeaderFound && (recvBufferOffset >= CWO_MSG_HEADER_LENGTH))
        {
          LOG(cLevelDebug, "SocketSendAndRecv: we have found a header");
          
          dataLength = GetMessageDataLengthFromHeader(*recvBuffer, recvBufferOffset);
          
          LOG(cLevelDebug, "SocketSendAndRecv: datalength found in header %u", dataLength);
          
          //Check if we got a successful result
          if(0xFFFFFFFF == dataLength)
          {
            LOG(cLevelDebug, "SocketSendAndRecv: we have received a message OK -> quit loop");
            
            retVal = CDS_ERROR_COMMUNICATION;
            break;
          }
          unsigned long totalLength = CWO_MSG_HEADER_LENGTH + dataLength + CWO_MSG_FOOTER_LENGTH;
          
          //Realloc space for response message
          if(totalLength > *recvBufferLen)
          {
            LOG(cLevelDebug, "SocketSendAndRecv: old buffer is too small (%u) -> reallocate space to %u bytes",*recvBufferLen, totalLength);
            
            unsigned char* oldBuffer = *recvBuffer;
            
            //allocate new buffer to handle large message size
            *recvBuffer = (unsigned char*)GetMemory(totalLength+1, "SocketSendAndRecv");
            if(NULL == * recvBuffer)
            {
              LOG(cLevelDebug, "SocketSendAndRecv: Allocate new recvbuffer failed (size %u)", totalLength +1);
              retVal = CDS_ERROR_MEMORY;
              break;
            }
            else
              LOG(cLevelDebug, "SocketSendAndRecv: Allocate new buffer OK (size %u)", totalLength +1);
            
            //copy content to new large buffer
            LOG(cLevelDebug, "SocketSendAndRecv: Copy content of old buffer to new buffer (%d bytes)", *recvBufferLen);
            
            memcpy(*recvBuffer, oldBuffer, *recvBufferLen);
            
            //Release old buffer
            LOG(cLevelDebug, "SocketSendAndRecv: Release old buffer");
            
            ReleaseMemory(oldBuffer);
            
            *recvBufferLen = totalLength;
            
            LOG(cLevelDebug, "SocketSendAndRecv: RecvBufferLen = %d", *recvBufferLen);
          }
          
          LOG(cLevelInfo, "SocketSendAndRecv: Found a message header = TRUE");
          
          messageHeaderFound = TRUE;
        }
        
        //Check if we got a complete message
        if(recvBufferOffset == CWO_MSG_HEADER_LENGTH + dataLength + CWO_MSG_FOOTER_LENGTH)
        {
          
          LOG(cLevelInfo, "SocketSendAndRecv: We got a complete message -> break recv loop");
          
          retVal = OK;
          *recvBufferLen = recvBufferOffset;
          break;
        }
      }
      else //error in message size in header
      {
        LOG(cLevelError, "SocketSendAndRecv: Can not fit message in buffer");
        retVal = CDS_ERROR_BUFFER_TOO_SMALL;
        break;
      }
    }
  }
  
  //Clean up resources
  //ReleaseMemory(tempBuffer);
  
  return retVal;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Convert inputBuffer (unicode format) to UTF-8 format and assign to outputBuffer. UnicodeToUtf8 function allocates memory for the output
//and assigns the outputBuffer pointer to the allocated memory. Caller is responsible to free the memory with a call to ReleaseMemory.
CDS_RETVAL UnicodeToUtf8(const unsigned short* inputBuffer, int inputBufferLength , char** outputBuffer, unsigned long* outputBufferLength)
{
  unsigned long length = 0;

   for ( int i = 0; i < inputBufferLength; ++i) 
   {
      if ( inputBuffer[i] < 0x0080 ) length++;
      else if ( inputBuffer[i] < 0x0800 ) length += 2;
      else length += 3;
   }

   //Allocate memory for output buffer. Caller of UnicodeToUtf8 is responsible to free the memory with ReleaseMemory function.
   unsigned char* szOut = ( unsigned char* )GetMemory( length+1, "UnicodeToUtf8");

   if ( szOut == NULL )
      return CDS_ERROR_MEMORY;

   unsigned long i = 0;
   for (int sourceIndex = 0; sourceIndex < inputBufferLength; ++sourceIndex)
   {
      if ( inputBuffer[sourceIndex] < 0x0080 )
         szOut[i++] = ( unsigned char ) inputBuffer[sourceIndex];
      else if (inputBuffer[sourceIndex] < 0x0800) 
      {
         szOut[i++] = 0xc0 | (( inputBuffer[sourceIndex] ) >> 6 );
         szOut[i++] = 0x80 | (( inputBuffer[sourceIndex] ) & 0x3f );
      }
      else 
      {
         szOut[i++] = 0xe0 | (( inputBuffer[sourceIndex] ) >> 12 );
         szOut[i++] = 0x80 | (( ( inputBuffer[sourceIndex] ) >> 6 ) & 0x3f );
         szOut[i++] = 0x80 | (( inputBuffer[sourceIndex] ) & 0x3f );
      } 
   }

   *outputBuffer = (char*)szOut;
   *outputBufferLength = i;

   return OK;
}

//Convert inputBuffer (UTF-8 format) to Unicode format and assign to outputBuffer. Utf8ToUnicode function allocates memory for the output
//and assigns the outputBuffer pointer to the allocated memory. Caller is responsible to free the memory with a call to ReleaseMemory.
CDS_RETVAL Utf8ToUnicode(const unsigned char* inputBuffer, int inputBufferLength, unsigned short** outputBuffer, unsigned long* outputSize)
{
  unsigned long length = 0;

   for(int i=0; i < inputBufferLength;)
   {
      if((inputBuffer[i] & 0x80) == 0x00)
      {
         length++;
         i += 1;
      }
      else if((inputBuffer[i] & 0xE0) == 0xE0)
      {
         length++;
         i += 3;
      }
      else if((inputBuffer[i] & 0xC0) == 0xC0)
      {
         length++;
         i += 2;
      }
   }

   *outputBuffer = (unsigned short*)GetMemory((length * sizeof(unsigned short))+1, "Utf8ToUnicode");

   if(NULL == *outputBuffer)
   {
      return CDS_ERROR_MEMORY;
   }

   *outputSize = length;

   unsigned long outputBufferIndex = 0;
   for(int i=0; i < inputBufferLength; )
   {
      if((inputBuffer[i] & 0x80) == 0x00)
      {
         (*outputBuffer)[outputBufferIndex] = (unsigned char)inputBuffer[i];
         outputBufferIndex++;
         i += 1;
      }
      else if((inputBuffer[i] & 0xE0) == 0xE0)
      {
         unsigned short wide_char;
         wide_char = (inputBuffer[i] & 0x0F) << 12;
         wide_char |= (inputBuffer[i+1] & 0x3F) << 6;
         wide_char |= (inputBuffer[i+2] & 0x3F);
         (*outputBuffer)[outputBufferIndex] = wide_char;
         outputBufferIndex++;
         i += 3;
      }
      else if((inputBuffer[i] & 0xC0) == 0xC0)
      {
         unsigned short wide_char;
         wide_char = (inputBuffer[i] & 0x1F) << 6;
         wide_char |= (inputBuffer[i+1] & 0x3F); 
         (*outputBuffer)[outputBufferIndex] = wide_char;
         outputBufferIndex++;
         i += 2;
      }
   }

   (*outputBuffer)[outputBufferIndex] = 0;

   return OK;
}

//Uncompress zlib compressed buffer. Uncompress allocates memory for the outputBuffer and caller is responsible to free the memory with a call to ReleaseMemory.
CDS_RETVAL ZlibUncompress(const unsigned char* inputBuffer, int inputBufferLength, unsigned char** outputBuffer, unsigned long* uncompressedLength)
{
  unsigned long result;

   //Allocate memory for uncompressed output
   *outputBuffer = (unsigned char*)GetMemory((*uncompressedLength) + 1, "ZlibUncompress");
   if (NULL == *outputBuffer) return CDS_ERROR_INSTANCE;

   result = uncompress(*outputBuffer, uncompressedLength, inputBuffer, inputBufferLength);

   //Free memory if we got a bad result
   if(Z_OK != result)
   {
      ReleaseMemory(*outputBuffer);
      *outputBuffer = NULL;
      *uncompressedLength = 0;
   }

   if(Z_OK == result)
      return OK;
   else if (Z_MEM_ERROR == result) //out of memory
      return CDS_ERROR_MEMORY;
   else if(Z_BUF_ERROR == result)
      return CDS_ERROR_BUFFER_TOO_SMALL;
   else if (Z_DATA_ERROR == result)
      return CDS_ERROR_INVALID_DATA;
   else
      return CDS_ERROR_UNKNOWN;
}

//Compress  inputBuffer with zlib compression. Compress allocates memory for the outputBuffer and caller is responsible to free the memory with a call to ReleaseMemory.
CDS_RETVAL ZlibCompress(const unsigned char* inputBuffer, int inputBufferLength, unsigned char** outputBuffer, unsigned long* compressedLength)
{   
  unsigned long result;
   unsigned long output_len = (unsigned long)(inputBufferLength * 1.01) + 12;

   //Allocate memory for result data (1% bigger than input size + 12 bytes according to zlib.h)
   *outputBuffer = (unsigned char*)GetMemory(output_len, "ZlibCompress");
   if(NULL == *outputBuffer)
      return CDS_ERROR_OUT_OF_MEMORY;

   *compressedLength = output_len;

   result = compress2(*outputBuffer, compressedLength, inputBuffer, inputBufferLength, Z_BEST_COMPRESSION);

   //Free memory if we got a bad result
   if(Z_OK != result)
   {
      ReleaseMemory(*outputBuffer);
      *outputBuffer = NULL;
      *compressedLength = 0;
   }

   if(Z_OK == result)
      return OK;
   else if (Z_MEM_ERROR == result) //out of memory
      return CDS_ERROR_MEMORY;
   else if(Z_BUF_ERROR == result)
      return CDS_ERROR_BUFFER_TOO_SMALL;
   else if (Z_DATA_ERROR == result)
      return CDS_ERROR_INVALID_DATA;
   else
      return CDS_ERROR_UNKNOWN;
}

CDS_RETVAL SendRequestAndGetResponse(const unsigned short* sendBuffer,
                                     unsigned short** responseBuffer,
                                     tCompressionAlgorithm compAlgorithm,
                                     unsigned long readTimeout)
{
  CDS_RETVAL retVal = OK;
  unsigned long uncompressed_length;
  unsigned long compressed_length=0;
  long sendBufLen = wcslen(sendBuffer);
  unsigned long result_length=0;
  unsigned long request_length=0;
  
  // allocate memory for the whole request
  unsigned long utf8_size = 0;
  unsigned char* request_buffer = NULL;
  //  (char**)&request_buffer;
  //Do the utf-8 conversion
  //   CDS_RETVAL utf8RetVal = UnicodeToUtf8(sendBuffer, sendBufLen, (char**)&request_buffer, &utf8_size);
  CDS_RETVAL utf8RetVal = UnicodeToUtf8(sendBuffer, sendBufLen, (char**)&request_buffer, &utf8_size);   
  if ((OK != utf8RetVal) || (utf8_size == 0))
  {
    LOG(cLevelError, "SendRequestAndGetResponse: Call to WideCharToMultiByte failed"); 
    return CDS_ERROR_INSTANCE;
  }
  request_buffer[utf8_size] = 0;
  uncompressed_length = utf8_size;
  
  //compress data according to selected algorithm
  switch(compAlgorithm)
  {
  case cNoCompression:
    LOG(cLevelInfo, "SendRequestAndGetResponse: No compression is used");
    compressed_length=uncompressed_length;
    break;
  case cZlibCompression:
    {
      LOG(cLevelInfo, "SendRequestAndGetResponse: Zlib compression is used");
      unsigned char* compressed_buffer = NULL;
      retVal = ZlibCompress(request_buffer, utf8_size, &compressed_buffer, &result_length);
      if(OK != retVal)
      {
        LOG(cLevelError, "SendRequestAndGetResponse: Zlib compression failed with retVal %d", retVal);
        retVal = CDS_ERROR_UNKNOWN;
      }
      
      compressed_length = result_length;
      ReleaseMemory(request_buffer);
      request_buffer = compressed_buffer;
    }
    break;
  default:        
    ReleaseMemory(request_buffer);
    return CDS_ERROR_PARAMETER;
  }
  
  //
  // prepare data for the actual request - make room for the request header
  //
  unsigned char* tempBuffer = &request_buffer[CWO_MSG_HEADER_LENGTH];
  memmove(tempBuffer,request_buffer,compressed_length);
  //determine length to send
  request_length = CWO_MSG_HEADER_LENGTH; //header
  //add length of message body
  request_length += compressed_length;
  //add length for footer
  request_length += CWO_MSG_FOOTER_LENGTH;
  
  retVal = CreateRequestMessage(request_buffer, (const unsigned char*)tempBuffer, request_length, compressed_length, uncompressed_length, compAlgorithm);
  if(OK != retVal)
  {
    LOG(cLevelError, "SendRequestAndGetResponse: CreateRequestMessage failed with retVal %d", retVal);
    return retVal;
  }
  //
  //Call send recv function to transmit our message and get the result back
  //Space for recvBuffer is allocated in SocketSendAndRecv since it depends on
  //response from gateway.
  //
  unsigned char* response_buffer=NULL;
  unsigned long response_length=0;
  char isException;
  
  retVal = SocketSendAndRecv(request_buffer, request_length, &response_buffer, &response_length, readTimeout);
  //Check that we got a response back
  if (OK == retVal && response_length > 0)
  {  
    unsigned short* responseStr = NULL;
    retVal = ReadResponseMessage(response_buffer, response_length, &responseStr, &isException);
    *responseBuffer = responseStr;
    
    if(OK != retVal)
      LOG(cLevelError, "SendRequestAndGetResponse: ReadResponseMessage failed with retVal %d", retVal);
  }
  else
  {
    LOG(cLevelError, "SendRequestAndGetResponse: SocketSendAndRecv failed with retVal %d", retVal);
    isException = FALSE;
  }
  
  //Check if we got an exception back
  if(isException)
  {
    LOG(cLevelError, "SendRequestAndGetResponse: isException!");
    retVal = CDS_ERROR_COMM_EXCEPTION;
  }
  
  return retVal;
}

//-----------------------------------------------------------------------------
/// <summary>
/// Builds a request message according to the gateway protocol
/// </summary>
/// <param name="unsigned char * requestBuffer">Output request message buffer</param>
/// <param name="const unsigned char * payloadBuffer">Payload data to send in the request message</param>
/// <param name="unsigned long requestLength"></param>
/// <param name="unsigned long compressedLength"></param>
/// <param name="unsigned long uncompressedLength"></param>
/// <param name="unsigned char compAlgorithm"></param>
/// <returns>CDS_RETVAL</returns>
//-----------------------------------------------------------------------------
CDS_RETVAL CreateRequestMessage(unsigned char* requestBuffer, 
                                const unsigned char* payloadBuffer, 
                                unsigned long requestLength, 
                                unsigned long compressedLength,
                                unsigned long uncompressedLength,
                                unsigned char compAlgorithm)
{
  unsigned short crc=0;
  unsigned long index=0;
  
  //Write ProtocolVersion to header
  requestBuffer[index++] = CWO_MSG_PROTOCOL_VERSION & 0x00FF;
  requestBuffer[index++] = (CWO_MSG_PROTOCOL_VERSION >> 8) & 0x00FF;
  
  //Write compressed length to header
  requestBuffer[index++] = (unsigned char)(compressedLength & 0x00FF);
  requestBuffer[index++] = (unsigned char)((compressedLength >> 8) & 0x00FF);
  requestBuffer[index++] = (unsigned char)((compressedLength >> 16) & 0x00FF);
  requestBuffer[index++] = (unsigned char)((compressedLength >> 24) & 0x00FF);
  
  //Write compression algorithm identifier to buffer
  requestBuffer[index++] = (unsigned char) compAlgorithm; 
  
  //Write uncompressed data length to buffer
  requestBuffer[index++] = (unsigned char)(uncompressedLength & 0x00FF);
  requestBuffer[index++] = (unsigned char)((uncompressedLength >> 8) & 0x00FF);
  requestBuffer[index++] = (unsigned char)((uncompressedLength >> 16) & 0x00FF);
  requestBuffer[index++] = (unsigned char)((uncompressedLength >> 24) & 0x00FF);
  
  //Write message type request to buffer
  requestBuffer[index++] = CWO_MSG_TYPE_REQUEST; 
  
  //This is not an exception message
  requestBuffer[index++] = CWO_MSG_NO_EXCEPTION; 
  
  //copy message data into request buffer
  memcpy(requestBuffer + index, payloadBuffer, compressedLength);
  index += compressedLength;
  
  //Add checksum as trailer
  crc = CRCCITT((char*)requestBuffer, index);
  requestBuffer[index++] = (unsigned char)(crc & 0x00FF);
  requestBuffer[index++] = (unsigned char)((crc >> 8) & 0x00FF);
  
  return OK;
}


//-----------------------------------------------------------------------------
/// <summary>
/// Parse and checks the validity of a response message. Extracts the response string.
/// </summary>
/// <param name="const unsigned char * responseData">Response data received on socket</param>
/// <param name="unsigned long responseLength">Length of the data received on socket</param>
/// <param name="std::wstring & responseBuffer">Result buffer where the response string is stored</param>
/// <param name="CDS_BOOL * isException">A flag indicating if the request resulted in an exception from the gateway</param>
/// <returns>CDS_RETVAL</returns>
//-----------------------------------------------------------------------------
CDS_RETVAL ReadResponseMessage(const unsigned char* responseData, 
                               unsigned long responseLength, 
                               unsigned short** responseBuffer,
                               char* isException)
{
  unsigned short protocol_version=0;
  unsigned long data_len = 0;
  tCompressionAlgorithm compression_id = cNoCompression;
  unsigned long uncompressed_len = 0;
  unsigned long real_uncomp_len = 0;
  unsigned char message_type=0;
  unsigned char is_exception=0;
  unsigned long index =0;
  unsigned char* extracted_data=NULL;
  unsigned short calculated_crc;
  unsigned short message_crc;
  unsigned long wide_size  = 0;
  CDS_RETVAL retVal;
  
  //check that we got a message with at least length of header
  if(responseLength < CWO_MSG_HEADER_LENGTH)
  {
    LOG(cLevelError, "ReadResponseMessage: Invalid header length"); 
    return CDS_ERROR_PROTOCOL;
  }
  
  //Verify protocol version
  protocol_version = responseData[index++] & 0x00FF;
  protocol_version |= (responseData[index++] << 8) & 0xFF00;
  if(CWO_MSG_PROTOCOL_VERSION != protocol_version)
  {
    LOG(cLevelError, "ReadResponseMessage: Invalid protocol version %d", protocol_version); 
    return CDS_ERROR_PROTOCOL;
  }
  
  //Get data length
  data_len = responseData[index++]          & 0x000000FF;
  data_len |= (responseData[index++] << 8 ) & 0x0000FF00;
  data_len |= (responseData[index++] << 16) & 0x00FF0000;
  data_len |= (responseData[index++] << 24) & 0xFF000000;
  
  LOG(cLevelDebug, "ReadResponseMessage: Message data (message body) length %d", data_len); 
  
  //Get compression identifier
  compression_id = (tCompressionAlgorithm)responseData[index++];
  LOG(cLevelDebug, "ReadResponseMessage: Compression id = %d", compression_id);
  
  //Get uncompressed length
  uncompressed_len = responseData[index++]          & 0x000000FF;
  uncompressed_len |= (responseData[index++] << 8 ) & 0x0000FF00;
  uncompressed_len |= (responseData[index++] << 16) & 0x00FF0000;
  uncompressed_len |= (responseData[index++] << 24) & 0xFF000000;
  
  LOG(cLevelDebug, "ReadResponseMessage: Uncompressed data length %d", uncompressed_len);
  
  //Check that we got a message with matching lengths according to header data
  if((CWO_MSG_HEADER_LENGTH + data_len + CWO_MSG_FOOTER_LENGTH) != responseLength)
  {
    LOG(cLevelError, "ReadResponseMessage: Message size should be %d but is %d", 
        responseLength, (CWO_MSG_HEADER_LENGTH + data_len + CWO_MSG_FOOTER_LENGTH));
    return CDS_ERROR_PROTOCOL;
  }
  
  //Verify CRC16 checksum
  calculated_crc = CRCCITT((char*)responseData, CWO_MSG_HEADER_LENGTH + data_len);
  message_crc = responseData[CWO_MSG_HEADER_LENGTH + data_len] & 0x00FF;
  message_crc |= (responseData[CWO_MSG_HEADER_LENGTH + data_len + 1] << 8) & 0xFF00;
  if(calculated_crc != message_crc)
  {
    LOG(cLevelError, "ReadResponseMessage: Message checksum should be %d according to header but is %d", message_crc, calculated_crc);
    return CDS_ERROR_PROTOCOL;
  }
  
  //Check that we got a response
  message_type = responseData[index++];
  if(CWO_MSG_TYPE_RESPONSE != message_type)
  {
    LOG(cLevelError, "ReadResponseMessage: This is not a response!");
    return CDS_ERROR_PROTOCOL;
  }
  
  //Check if this is an exception
  is_exception = responseData[index++];
  if(1 == is_exception)
  {
    LOG(cLevelError, "ReadResponseMessage: We got an exception message from CWO");
    *isException = TRUE;
  }
  else
  {
    LOG(cLevelInfo, "ReadResponseMessage: This is not an exception message");
    *isException = FALSE;
  }
  
  //Handle decompression of data if needed
  if(cZlibCompression == compression_id)
  {
    LOG(cLevelInfo, "ReadResponseMessage: Zlib compression is used");
    
    real_uncomp_len = uncompressed_len;
    retVal = ZlibUncompress(responseData + index, data_len, &extracted_data, &real_uncomp_len);
    if(OK != retVal)
    {
      LOG(cLevelError, "ReadResponseMessage: Uncompress failed!");
      ReleaseMemory(extracted_data);
      return retVal;
    }
    else
    {
      LOG(cLevelInfo, "ReadResponseMessage: Uncompress OK");
      
      if(uncompressed_len != real_uncomp_len)
      {
        LOG(cLevelError, "ReadResponseMessage: Expected uncompressed size (%d) is different from real uncomp size (%d)" ,uncompressed_len, real_uncomp_len);
        ReleaseMemory(extracted_data);
        return CDS_ERROR_UNKNOWN;
      }
      
      LOG(cLevelInfo, "ReadResponseMessage: Uncompressed size of message matches expected size (%d)", uncompressed_len);
      
      extracted_data[real_uncomp_len] = 0;
    }
  }
  else
  {
    LOG(cLevelInfo, "ReadResponseMessage: No compression is used");
    
    extracted_data = (unsigned char*)GetMemory(data_len + 1, "HandleResponseMessage: Not compressed");
    
    if(NULL != extracted_data)
      LOG(cLevelDebug, "ReadResponseMessage: Allocated %d bytes for message copy OK", data_len);
    else
    {
      LOG(cLevelError, "ReadResponseMessage: Failed to allocate %d bytes for message copy -> abort!", data_len);
      return CDS_ERROR_OUT_OF_MEMORY;
    }
    
    //Copy the response to extracted data
    memcpy(extracted_data, responseData + index, data_len);
    real_uncomp_len = data_len;
    extracted_data[real_uncomp_len]=0;
  }
  
  unsigned short* wide_response = NULL;
  CDS_RETVAL utf8RetVal = Utf8ToUnicode(extracted_data, real_uncomp_len, &wide_response, &wide_size);
  if ((OK != utf8RetVal) || (wide_size == 0))
  {
    LOG(cLevelError, "ReadResponseMessage: Call to MultiByteToWideChar conversion FAILED");
    retVal = CDS_ERROR_UNKNOWN;
  }
  else
    LOG(cLevelInfo, "ReadResponseMessage: MultiByteToWideChar OK");
  
  wide_response[wide_size] = 0;
  
  // Copy to response buffer
  LOG(cLevelInfo, "ReadResponseMessage: Copy to response buffer");
  *responseBuffer = wide_response;
  
  retVal = OK;
  
  ReleaseMemory(extracted_data);
  
  return retVal;
}


//-----------------------------------------------------------------------------
/// <summary>
/// Returns the length of the data in a message by reading the relevant part of the header
/// </summary>
/// <param name="const unsigned char * buffer">Buffer containing message header where length is extracted</param>
/// <param name="const unsigned long bufferLength">Length found in header</param>
/// <returns>unsigned long</returns>
//-----------------------------------------------------------------------------
unsigned long GetMessageDataLengthFromHeader(const unsigned char* buffer, const unsigned long bufferLength)
{
  unsigned long index = 0;
  unsigned long compressed_length = 0;
  unsigned short protocol_version=0;
  
  //Check protocol version
  protocol_version = *(buffer + index++) & 0x00FF;
  protocol_version |= (*(buffer + index++) << 8) & 0xFF00;
  if(CWO_MSG_PROTOCOL_VERSION != protocol_version)
    return 0xFFFFFFFF;
  
  //Get compressed length
  compressed_length = *(buffer + index++) & 0x00FF;
  compressed_length |= (*(buffer + index++) << 8) & 0xFF00;
  compressed_length |= (*(buffer + index++) << 16) & 0xFF0000;
  compressed_length |= (*(buffer + index++) << 24) & 0xFF000000;
  
  return compressed_length;
}




