
#include "STM32Lib\\stm32f10x.h"
#include "stm32f10x_conf.h"
#include "hal.h"
#include "MemoryAssign.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Key.h"
#include "Count.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include "Gprs_online.h"
#include "Coin.h"
#include "MemoryAssign.h"
#include "rate.h"


#define uchar unsigned char
#define uint unsigned int
unsigned char resetcoin;
extern long Good_money;
extern u8 parking_station;
extern u8 f_coinfirst,chewei;
extern u8 jilu[20];
extern unsigned long stoptime;
uchar coin_value[5];
uchar coin_event_counter = 0;			//229???????????
uchar cctalk_tx_data[20];	//?????data,??????
uchar cctalk_rx_data[30];	//?????????data??????,crc????????????
									    //??:[????] [????] [] [] [] []
uchar cctalk_data[20]  ;	//?????data,??????
//=================================================


void Open_Coin_Power(void)
{
  coinpower_1;
}
void Close_Coin_Power(void)
{
  coinpower_0;
}


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
void sent_cctalk_data(uchar x)
{	
    USART_SendData(UART5,x);
    while(USART_GetFlagStatus(UART5, USART_FLAG_TXE) == RESET)
    {
    }  
}
void cctalk_delay(uint t)
{	
	while(t--);
	return;
	
} 
/***************************************************************************************
????:

????:

??:    
****************************************************************************************/
void tx_cctalk(unsigned char header,unsigned char len)
{	
	unsigned char i = 0;
	unsigned char k = 0;
	unsigned int timeout;
	unsigned int cheak_sum = 0;							//?????
	unsigned char cheak_result = 0;						//?????

	cctalk_data[0] = slave_addr;				//???????
	cctalk_data[1] = len;						//?????
	cctalk_data[2] = host_addr;					//??????
	cctalk_data[3] = header;					//???????
	
	for(i = 0;i < len;i++)
	{	
		cctalk_data[i+4] = cctalk_tx_data[i];
	}
	
	for(k = 0;k < (i+4); k++)
	{
		cheak_sum = cheak_sum + cctalk_data[k];
	}
	cheak_result = 256 - (uchar)(cheak_sum - (cheak_sum / 256) * 256);
	cctalk_data[i+4] = cheak_result;			//???????,?????
	for(k = 0;k < (i+5);k ++)
	{
		sent_cctalk_data(cctalk_data[k]);		//?????????
		timeout = 100000;
     while(USART_GetFlagStatus(UART5, USART_FLAG_RXNE) == RESET)   
		{
		        timeout--;
			if(timeout <= 0)
			break;
		}
     (USART_ReceiveData(UART5) & 0xFF);   
	}
	return;
}


unsigned char rx_cctalk(void)
{	
	unsigned char iiii,i = 0;
	u32 timeout;
        cctalk_rx_data[0]= (USART_ReceiveData(UART5) & 0xFF);
        iiii=0;
	timeout =20000000;
	do{
          
          if(USART_GetFlagStatus(UART5, USART_FLAG_RXNE) != RESET) {
			
            cctalk_rx_data[0]= (USART_ReceiveData(UART5) & 0xFF);
	    if(cctalk_rx_data[0]==0X48){                          
              iiii=1;			  
              break;                       
            }		
            if(cctalk_rx_data[0]==0X4C){                          
              iiii=2;			  
              break;                        
            }
	    if(cctalk_rx_data[0]==0X44){                          
              iiii=3;			 
              break;                       
            }                       			
          }
          
          /*   ��ʱû�õ�
          if(key_flag)			
          {		
            i = key_scan1();			
            if(i == KEY_Cancel)				
            {					
              return 0x88;				
            }			
            else if(i == KEY_Comfirm)                          				
            {                              
              return 0x88;				
            }			
          }
          */
          
          if(timeout==0)              
            break;	
          
        }while(--timeout);         
      
        if(timeout<=0)
        return 0; 
      
        if(iiii==1)      
        {	
          for(i = 1;i <8;i ++)	//HLD003 0D,0A						
          { 			
            timeout = 50000;		 
            do						   //��ʱ���		  
            {      		  
              if(USART_GetFlagStatus(UART5, USART_FLAG_RXNE) != RESET)                        			
              {		
                cctalk_rx_data[i]= (USART_ReceiveData(UART5) & 0xFF); 		
                break;		
              }		
            }while(--timeout);		
            if(timeout==0)			
              i=5;	
          }      
        }     
        else if(iiii==2)      
        {	
          for(i =2;i <8;i ++)	//HLD003 0D,0A						
          { 			
            timeout = 50000;		 
            do						   //��ʱ���		 
            {      		  
              if(USART_GetFlagStatus(UART5, USART_FLAG_RXNE) != RESET)                        		
              {		
                cctalk_rx_data[i]= (USART_ReceiveData(UART5) & 0xFF); 		
                break;		
              }	
            }while(--timeout);		 		
            if(timeout==0)		
              i=5;	
          }     
        }      
        else if(iiii==3)      
        {
          for(i = 3;i <8;i ++)	//HLD003 0D,0A						
          { 			
            timeout = 50000;		
            do						   //��ʱ���		 
            {      	 
              if(USART_GetFlagStatus(UART5, USART_FLAG_RXNE) != RESET)                        		
              {		
                cctalk_rx_data[i]= (USART_ReceiveData(UART5) & 0xFF); 			
                break;			
              }		
            }while(--timeout);		 		
            if(timeout==0)		
              i=5;
          }      
        }   
        
	if((cctalk_rx_data[6]==0x0D)&&(cctalk_rx_data[7]==0x0A)&&(cctalk_rx_data[3]=='0')&&(cctalk_rx_data[3]=='0')) 	
          return 1;
	else	
          return 0;	
}

u8 cctalk_reset(void)
{	
	tx_cctalk(0x01,0x00);									 
	if(rx_cctalk() == 1)
	{	
		if((cctalk_rx_data[0] == host_addr) && 
		   (cctalk_rx_data[2] == slave_addr) && 
		   (cctalk_rx_data[3] == 0x00)   )			//�ж�ͷ�Ƿ�Ϊ0x00������λ��Ӧ������
		{
			coin_event_counter = 0;					//��λ���¼���������   (����Ҫ)
			cctalk_delay(50000);				    //��������Ҫ�ȵ�>50ms��ʱ���ٿ�ʼ��������Ϻ�
			cctalk_delay(50000);
                        resetcoin=1;
			return 1;
		}	
	 }
	resetcoin=0;   
    return 0;
}
/****************************************************************************************
�������ƣ�

ʹ�÷�����

��ע��    
*****************************************************************************************/

/****************************************************************************************
�������ƣ�

ʹ�÷�����

��ע��    
*****************************************************************************************/

void int_coin()
{
  Open_Coin_Power();
//  delay(500);
//  delay(80000);
  return;
}
void Return_Coin(u8 coinsum)
{
	PrintandCoinout_LED_OPEN;
	//Retcoin_OPEN;
	delay(KEYTIMEOUT_1S);
	//Retcoin_CLOSE;
	//Close_Coin_Power();
	lcd_clear();
	Refresh_SYSallicon();
	if(coinsum)
		disp_Beyond_20pcs();
	else
		disp_coin_return();		
	delay(KEYTIMEOUT_1S*3);	
	PrintandCoinout_LED_CLOSE;
}
void Eaturn_Coin(void)
{
	//Eatcoin_OPEN;
	delay(KEYTIMEOUT_1S);
	//Eatcoin_CLOSE;
}


/*----------------------------------------------------------------------
function name:   	void do_coin(void)
describe:    	 	Ͷ�Ҳ˵�
input:   			
output:
date:			andyluo 2010-12-03 14:26:57
------------------------------------------------------------------------*/

u8 int_coin_check( )
{
	Open_Coin_Power();
	delay(100);
	tx_cctalk(0x01,0x00);									 
	if(rx_cctalk() == 1)
		{	
		if((cctalk_rx_data[0] == host_addr) && 
		   (cctalk_rx_data[2] == slave_addr) && 
		   (cctalk_rx_data[3] == 0x00))		//�ж�ͷ�Ƿ�Ϊ0x00������λ��Ӧ������
			return 0;
		}
	return 1;
}
//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////
/*----------------------------------------------------------------------
function name:   	void do_coin0(void)
describe:    	 	Ͷ�Ҳ˵�
input:   			
output:
date:			andyluo 2010-12-03 14:26:57
------------------------------------------------------------------------*/
