#ifndef _IAPTEST_H
#define _IAPTEST_H

#include "hal.h"

#define USART_REC_LEN  			30*1024 //�����������ֽ��� 55K


void IapTest(void);

void iap_write_appbin(u32 appxaddr,u8 *appbuf,u32 appsize);

void STMFLASH_Write_NoCheck(u32 WriteAddr,u16 *pBuffer,u16 NumToWrite);

void STMFLASH_Write(u32 WriteAddr,u16 *pBuffer,u16 NumToWrite);

void STMFLASH_Read(u32 ReadAddr,u16 *pBuffer,u16 NumToRead);

u16 STMFLASH_ReadHalfWord(u32 faddr);
#endif