#ifndef	_St_credit_H
#define	_St_credit_H

#define Credit_Power_ON  	 	GPIOB->BSRR = 0x00000001 //0
#define Credit_Power_OFF     GPIOB->BSRR = 0x00010000 
#define SP3243_Open  	        GPIOA->BSRR = 0x00000100 //8
#define SP3243_Close          GPIOA->BSRR = 0x01000000 
#define Cash_Power_ON  	 	GPIOC->BSRR = 0x00000001 //0
#define Cash_Power_OFF        GPIOC->BSRR = 0x00010000 
#define Printer_Power_ON  	     GPIOC->BSRR = 0x00002000 //13
//#define Printer_Power_ON     	GPIO_SetBits(GPIOC, GPIO_Pin_13)//13

#define Printer_Power_OFF    GPIOC->BSRR = 0x20000000 

void do_Creditcard_Main(void);
//unsigned char find_Creditcard(u8 Creditcard_Readdata[]);
unsigned char find_Creditcard();
u8 key_scan();
void uart_send_som(unsigned char *ptr);
unsigned char Deduct_Creditcard(unsigned int ParkingUser_money, u8 Creditcard_Readdata[]);
//unsigned char Deduct_Creditcard(unsigned int ParkingUser_money);
u8 Choose_time(void);
void uart_send_sombuf(unsigned char *ptr,unsigned int k);
void uart_send_som(unsigned char *ptr);
void uart_send(unsigned char a);
void fault_record(unsigned char FAULT_TYPE);
void refer_record(unsigned char FAULT_TYPE);
 void deal_managecard(void);
 void Open_Creditcard_Power();
 void Close_Creditcard_Power();
 u8 CardDeal12(void);
unsigned char GPRS_online_JD1(void);
void read_Memory();

extern u16 RxCounter,CarCounter;
extern u8 RxBuffer[2000],CarBuffer[300];
//////////////////////////////////////////////////////////////////////////////////
#define SST_SELECT()		GPIO_ResetBits(GPIOB, GPIO_Pin_2)       /* SST CS = L */ 
#define SST_DESELECT()		GPIO_SetBits(GPIOB, GPIO_Pin_2)         /* SST CS = H */
 #define SPI_FLASH_CS1             GPIO_Pin_2 
 #define SPI_FLASH_CS_GPIO1        GPIOB 
 #define SPI_FLASH_CS_GPIO_CLK1    RCC_APB2Periph_GPIOB
#define ccard_CS1_LOW       GPIO_ResetBits(SPI_FLASH_CS_GPIO1, SPI_FLASH_CS1)
#define ccard_CS1_HIGH      GPIO_SetBits(SPI_FLASH_CS_GPIO1, SPI_FLASH_CS1)
#define ccard_dav_LOW       GPIO_ResetBits(GPIOB, GPIO_Pin_1)
#define ccard_dav_HIGH      GPIO_SetBits(GPIOB, GPIO_Pin_1)
//////////////////////////////////////////////////////////////////////////////////
#define  Com_port_testing     1
#define  Com_port_real    	 0
#define  Ishide         		 1
#define  Isnohide     			 0
#define  changeon     			 1
#define  changeoff     		 0
#define  ONLINE_TIME     		 250//29//15//
#define  SG5    	 			5
#define  SG4    	 			4
#define  SG3    	 			3
#define  SG2    	 			2
#define  SG1    	 			1
#define  SG0    	 			0
#define  BT4    	 			4
#define  BT3    	 			3
#define  BT2    	 			2
#define  BT1    	 			1
#define  BT0    	 			0

#define  Software_sever		0
#define  DPS_sever    	 		1

#define  ON						1
#define  OFF    	 			0
//#define  OK						1
#define  NG    	 				0
//#define  NULL    	 				0

#define  Opendisp				1
#define  Closedisp	 			0

#define  OtherMode				3
#define  CashMode				2
#define  CoinMode				1
#define  CreditMode				0


#define  CoinRecordMode			0xE0
#define  CreditRecordMode			0xE2
#define  CashRecordMode			0xE3

#define KEY_0  			16
#define KEY_1  			1
#define KEY_2  			2
/*#define KEY_1  			2
#define KEY_2  			1*/
#define KEY_3  			3
#define KEY_4  			4
#define KEY_5  			5
#define KEY_6  			6
#define KEY_7  			7
#define KEY_8  			8
#define KEY_9  			9
#define KEY_P  			10
#define KEY_F  			11
/*
//#define KEY_Cancel		12
//#define KEY_Up			13
//#define KEY_Down		14
//#define KEY_Comfirm	15
*/
#define KEY_Cancel		6
#define KEY_Up			7
#define KEY_Down		8
#define KEY_Comfirm	        5
#define KEYTIMEOUT_1S	8500000
#define KEYTIMEOUT_1H2S	10//500000
#define KEYTIMEOUT	    88



#define		Wakeup__3G_CDMA				uart_send_som("*wake#");delay(45000*50)			//3Gģ�黽��
#define		Entrans__3G_CDMA				uart_send_som("*ent#");delay(45000*50)		//3G͸����
#define		Disentrans__3G_CDMA			uart_send_som("*dis#");delay(45000*50)	//3G͸����
#define		Sleep__3G_MCU			   		uart_send_som("*mcusleep#");delay(45000*50)		//�ӻ�MCU˯��
#define		Sleep__3G_CDMA		   		uart_send_som("*sleep#");delay(45000*50)		//�ӻ�MCU˯��
#define		Sleep__3GandMCU_PD	   		uart_send_som("*mcusleep#");delay(15000*50)		//�ӻ�MCU˯��

extern u8 f_getmoney,f_openmachine,jishu2,OP_NS,CO_NS,Backup_NS;
extern u8  zimo,doint,LV_NS,BL_NS,day_flag,time_OK,GPRS_LINKing,CLOSE_GPRS,SCR_CK,QL_CK;
extern u8  gprs_user,gprs_busy,DPSIP,all_dawnload,addtime,gprs_refer,gprs_busy1,already_sleep,f_ConnSuccess,f_Sendrecord,gprs_resetpower,Time_return,xxxx,gprs_busy2,f_referinit;
extern u16 x_StartTime_h,x_StartTime_min,x_EndTime_h,x_EndTime_min,x_StartWeek,x_EndWeek,x_Stime,x_Amount,x_MaxPark,x_MinPark,x_MinCost,f_execution,f_occupied,key_number,f_overmax;
extern u16 MinTime,LimitTime,LimitMoney,LimitMoney_CARD,BaseFee,length_heartjump,x_MAXParkingTime;
extern unsigned long left_time,left_money,global_u1time1;
extern u16 f_sendsimulatedata,time_occpupied;
extern u8 jishu,jishu1,jishu10,SG_CSQ,BaseTime,FEE_SAT,FEE_END,BT_Value,SYS_Stateicon;
extern u8 f_enablecard,f_connectOK,f_receiveOK,f_quit,f_blacklight,f_closeIP,NETSTATE;
extern u16 purch_time,purch_money;
//extern u8 Creditcard_Readdata[],Creditcard_Cardno[4];
//extern uint16_t sz111[0x400];

#endif
