/**
  ******************************************************************************
  * @file    IAP/src/main.c 
  * @author  MCD Application Team
  * @version V3.2.0
  * @date    04/23/2010
  * @brief   Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 STMicroelectronics</center></h2>
  */ 

/** @addtogroup IAP
  * @{
  */

/* Includes ------------------------------------------------------------------*/
#include "common.h"
#include "upgrade.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
extern pFunction Jump_To_Application;
extern uint32_t JumpAddress;


/* Private function prototypes -----------------------------------------------*/
static void IAP_Init(void);
static void NVIC_Configuration(void);

/* Private functions ---------------------------------------------------------*/
typedef enum
{
	FifoWriteOK = 0,			/*Writing FIFO actions is OK*/
	FifoFull,				/*FIFO is no ram to be wrote and this writing action is aborted*/
	FifoAlmostFull,		/*FIFO is almost full but this writing actions is valid*/
	
	FifoReadOK,			/*Reading FIFO action is OK*/
	FifoEmpty,			/*FIFO is no data to be read and this reading action is aborted*/
	FifoAlmostEmpty		/*FIFO is almost empty but this reading actions is valid*/
}FIFO_InfoDef;

u8 buff[1024];
extern ErrorStatus LoaderInit(u32 size, u32 num);

extern FIFO_InfoDef FIFO_write(u8* src);



void Dly(u16 n)
{
	u8 i;
	while(n--){
		for(i=50;i>0;i--);
	}
}

void LoadBuffer(void)
{
	u16 i;
	static u16 inc=0;
	for(i=0;i<1024;inc++){
		
		buff[i++] = (u8)((inc>>8)&0xFF);
		
		buff[i++] = (u8)(inc&0xFF);	
	}
}

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
   u8 flag;
int upgrade(void)
{
   GPIO_InitTypeDef GPIO_InitStructure;
  /* Flash unlock */
  //FLASH_Unlock();

  /* Enable GPIOA, GPIOB, RCC_APB2Periph_GPIO_KEY_BUTTON and AFIO clocks */
  RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB| RCC_APB2Periph_GPIOA|RCC_APB2Periph_USART1, ENABLE);
  RCC_APB1PeriphClockCmd( RCC_APB1Periph_USART2, ENABLE);



    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);


  /* Configure USART1 Rx as input floating */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10|GPIO_Pin_3 ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  

  /* Configure USART1 Tx as alternate function push-pull */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9|GPIO_Pin_2 ;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  
  NVIC_Configuration();
  IAP_Init();
 
#if 0 
  Main_Menu();

  while(1)
  	{

  	}
  #endif
  
 LoadBuffer();
 
  /* Test if Key push-button on STM3210X-EVAL Board is pressed */
//  if ((GPIOB->IDR&GPIO_Pin_10) == 0x00)
LoaderInit((32*1024+200), 33);
flag = 1;
  while (1){
  	if(flag == 1){
		if(FIFO_write(buff) == FifoFull)
			Dly(20);
		else
			LoadBuffer();
  	}

  }
  
}
void upgrade1(void)
{
 LoadBuffer();
 
  /* Test if Key push-button on STM3210X-EVAL Board is pressed */
//  if ((GPIOB->IDR&GPIO_Pin_10) == 0x00)
 if(flag ==1)
LoaderInit((32*1024+200), 33);
		if(FIFO_write(buff) == FifoFull)
			Dly(20);
		else
			LoadBuffer(); 
//                return 1;
}

/**
  * @brief  Initialize the IAP: Configure RCC, USART and GPIOs.
  * @param  None
  * @retval None
  */
void IAP_Init(void)
{
 USART_InitTypeDef USART_InitStructure;

  /* USART resources configuration (Clock, GPIO pins and USART registers) ----*/
  /* USART configured as follow:
        - BaudRate = 115200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
  */
  USART_InitStructure.USART_BaudRate = 115200;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  USART_Init(USART1, &USART_InitStructure);  
  USART_Cmd(USART1,ENABLE);
  USART_Init(USART2, &USART_InitStructure);
  USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);
  USART_ClearFlag(USART2,USART_IT_RXNE);
  USART_Cmd(USART2,ENABLE);
  
}

void NVIC_Configuration(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;

  /* Configure the NVIC Preemption Priority Bits */  
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
  
  
  /* Enable the USART1 Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  
}




#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/******************* (C) COPYRIGHT 2010 STMicroelectronics *****END OF FILE****/
