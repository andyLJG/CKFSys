#include "Do_Task.h"
//#include "Smart_card.h"
#include "hardware_test.h"
#include "stm32f10x_conf.h"
#include "hal.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Count.h"
#include "Key.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include "Gprs_online.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_it.h"
#include "string.h"
#include "misc.h"
#include "math.h"
#include "main.h"
#include "Card.h"
#include "MemoryAssign.h"
#include "Do_Task.h"

extern uchar HZ[];  

CARIMG CARINFO;//2015-04-15 andyluo
u8 exit_cariq;
Rate_reference_ST RR_STCAR;


//������رճ����������ж� 2015-04-29 andyluo
void UART4_IRQn_CTL(u8 OPEN_CLOSE)
{
  NVIC_InitTypeDef NVIC_InitStructure;

  /* Enable the USART4 Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  if(OPEN_CLOSE)
  	NVIC_InitStructure.NVIC_IRQChannelCmd =ENABLE;
  else
  	NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
  NVIC_Init(&NVIC_InitStructure);  
}


//�����м��������ͨ����Ƿ��������
void G3_PowerOFF_Mode(void)
{
u8 base,mbno[3];

	I2C_ReadS_24C(mibiao_number,mbno,3);//�����

//	I2C_ReadS_24C(MBMODE_ADD,&base,1);

	if(mbno[2])
		base = 0;//��ͨ���
	else
		base = 1;//�м����		
	
	if(base)//base
		;
	else//��ͨ������ô���
		{
		NETSTATE = NETSTATE_CLOSE;
		GPRS_Power_OFF;
		}
}
//��ʼ����������Ϣ 2015-04-15andyluo
void INI_CARIMG(void)	
{
u8 k,carimgbuf[800];
u16 wtadd;

	memset(carimgbuf,0,800);
//	I2C_WriteS_24C(SYS_CARIMG_ADD,carimgbuf,800);
	for(k=0;k<CarNumSetting;k++)
		{		
		wtadd = SYS_CARIMG_ADD+k*40;
		I2C_WriteS_24C(wtadd,carimgbuf,40);
		}
	I2C_WriteS_24C(CARSUM_ADD,carimgbuf,1);
	
}
//����ͳ�ʼ��������������� 2015-04-16
void INI_SYSCARIMG(void)
{
	INI_MBMODE();
	INI_CARIMG();
	INI_CARRECORD_ADD();
}


//��ʼ���������ߵ�ַ
void INI_CARRECORD_ADD(void)	
{
u8 carimgbuf[2];

	carimgbuf[0] = (u8)(CARRECORD_ADD>>8);
	carimgbuf[1] = (u8)CARRECORD_ADD;
	I2C_WriteS_24C(CARRECORD_SAVEADD,carimgbuf,2);
	I2C_WriteS_24C(CARRECORD_SENDADD,carimgbuf,2);
}

//�ظ�:CMD +�豸�š�4��+00
void ACK_PDA(u8 STATE)
{
u8 CarACK[32],i=0,j,xor=0xff;

	CarACK[i++] = 0x28;
	CarACK[i++] = 0x28;
	CarACK[i++] = 0xCC;
	CarACK[i++] = 0x09;
	CarACK[i++] = CarBuffer[4];

	for(j=0;j<6;j++)
		{
		CarACK[i++] = CarBuffer[j+5];
		xor ^= CarBuffer[j+5];
		}
	CarACK[i++] = STATE;

	xor ^=	STATE;
	
	CarACK[i++] = xor;
	
	CarACK[i++] = 0xCC;
	CarACK[i++] = 0xCC;
	USART_SendDataPacket(UART4 ,15,CarACK);
}

//�ظ�:BD +�豸�š�4��+4F 4B
void ACK_PDAInt(void)
{
u8 CarACK[32],i=0,j,xor=0xff;

	CarACK[i++] = 0x28;
	CarACK[i++] = 0x28;
	CarACK[i++] = 0xCC;
	CarACK[i++] = 0x09;
	CarACK[i++] = CarBuffer[4];

	for(j=0;j<5;j++)
		{
		CarACK[i++] = CarBuffer[j+5];
		xor ^= CarBuffer[j+5];
		}
	CarACK[i++] = 0x4F;
	CarACK[i++] = 0x4B;

	xor ^=	0x4F;
	xor ^=	0x4B;
	CarACK[i++] = xor;
	
	CarACK[i++] = 0xCC;
	CarACK[i++] = 0xCC;
	USART_SendDataPacket(UART4 ,16,CarACK);
}


//�ظ�:F1 +�豸�š�4��+DE 4F 4B
void ACK_CarInt(void)
{
u8 CarACK[32],i=0,j,xor=0xff;

	CarACK[i++] = 0x28;
	CarACK[i++] = 0x28;
	CarACK[i++] = 0xCC;
	CarACK[i++] = 0x0A;
	CarACK[i++] = CarBuffer[4];

	for(j=0;j<6;j++)
		{
		CarACK[i++] = CarBuffer[j+5];
		xor ^= CarBuffer[j+5];
		}
	CarACK[i++] = 0x4F;
	CarACK[i++] = 0x4B;

	xor ^=	0x4F;
	xor ^=	0x4B;
	CarACK[i++] = xor;
	
	CarACK[i++] = 0xCC;
	CarACK[i++] = 0xCC;
	USART_SendDataPacket(UART4 ,16,CarACK);
}
/*		2828CC
		CarBuffer[3]--����
		CarBuffer[4]--Ƶ�ʶ�
		CarBuffer[5]--��������
		CarBuffer[6-9]--�豸��
		CarBuffer[10-n]--����
			DX +����������1��+��������λ��Ϣ1+����+������
			��������λ��Ϣ=�������š�4��+��λ��ˮ�š�1��+��λ״̬��1��+��λʱ�䡾2��
			CarBuffer[10]--��������
			CarBuffer[11]--����������
			CarBuffer[12-19]--���ֽڳ�λ��Ϣ			
		CarBuffer[CarCounter-1]--���У���
		CarBuffer[CarCounter--CarCounter+1]--֡βCCCC	          */
/*
flag=
		0:normal 
		1:disp
		
*/
void Deal_CarInfo(u8 flag)
{
u8	Rec_Length,carsum,i,ii,k,xor=0xff,Rxor,page,suma,equ,stflag,car;
u8  Carinfo_buf[160],WaringRe[16],carno[4],momery_buffer[4];//20*8
u16 momery;
u32 timeOut;
u8 block1_buffer[32];
carStation_reference_of_used CS_RF_US; 


	GetCurrentTime();
	Rec_Length = CarBuffer[3];
	carsum = CarBuffer[11];
	
//	for(i=0;i<carsum;i++)
//		{
//		for(j=0;j<8;j++)
//			Carinfo_buf[j+i*8] = CarBuffer[j+i*8+12]
//		}
	memcpy(Carinfo_buf,CarBuffer+12,carsum*8);

	for(i=0;i<carsum*8+7;i++)
		xor ^= CarBuffer[5+i];
	Rxor = CarBuffer[CarCounter-3];
//	Rxor = CarBuffer[5+i];
	if((xor != Rxor)||(flag==1))
		{//У���쳣		
		lcd_clear();
		if(flag==1)
			print_XYstr_16_16(1,1,"CarInfo--01/10");	
		else
			print_XYstr_16_16(1,1,"CRC ERR--01/10");	
		goto_xy(0xA1,13);
		print_num2(HEX_to_BCD(carsum)); 		
		page = carsum/3;
		if(carsum%3)page++;
		for(i=0;i<page;i++)
			{
			zimo =1;
			goto_xy(0xA1,10);
			suma = (i+1)*3;
			if(suma >= carsum)
				print_num2(HEX_to_BCD(carsum)); 
			else
				print_num2(HEX_to_BCD(suma)); 
			zimo =0;
			lcd_clear_h(2);
			lcd_clear_h(3);
			lcd_clear_h(4);
			if(suma-2 <= carsum)
				{
				goto_xy(0xA2,1);			
				for(ii=0;ii<5;ii++)
					print_num2(Carinfo_buf[i*24+0+ii]); 
				zimo =1;
				for(ii=5;ii<6;ii++)
					print_num2(Carinfo_buf[i*24+0+ii]); 				
				zimo =0;
				for(ii=6;ii<8;ii++)
					print_num2(Carinfo_buf[i*24+0+ii]); 
				}
			zimo =1;
			if(suma-1 <= carsum)
				{
				goto_xy(0xA3,1);
				for(ii=0;ii<5;ii++)
					print_num2(Carinfo_buf[i*24+8+ii]); 
				zimo =0;
				for(ii=5;ii<6;ii++)
					print_num2(Carinfo_buf[i*24+8+ii]); 				
				zimo =1;
				for(ii=6;ii<8;ii++)
					print_num2(Carinfo_buf[i*24+8+ii]); 
				}
			zimo =0;
			if(suma <= carsum)
				{
				goto_xy(0xA4,1);
				for(ii=0;ii<5;ii++)
					print_num2(Carinfo_buf[i*24+16+ii]); 
				zimo =1;
				for(ii=5;ii<6;ii++)
					print_num2(Carinfo_buf[i*24+16+ii]); 				
				zimo =0;
				for(ii=6;ii<8;ii++)
					print_num2(Carinfo_buf[i*24+16+ii]); 
				}
			delay(KEYTIMEOUT_1S/100); 
			key_flag = 0;
			timeOut = KEYTIMEOUT_1S *4; 		
			while(timeOut--)
				{ 
				if(key_flag)
					break;
				}	
			if(key_flag)continue;
			}
		}
//	if(xor == Rxor)
//	if(carsum)
//		{
//		suma = carsum;//���յ��ĳ���������
//		for(i=0;i<CarNumSetting;i++)
//			I2C_ReadS_24C(SYS_CARIMG_ADD+i*40,carimgbuf+i*40,40);
//		}
	for(i=0;i<carsum;i++)//�յ�������
		{
//		equ = 0;//�˳�����Ԥ��̶����ڴ��У�ֻ����λ�ã�δ�ҵ���ʾ�ó�����δԤ����
//		for(j=0;j<CarNumSetting;j++)
//			{
//			equ = 1;
//			for(k=0;k<4;k++)
//				{
//				if(Carinfo_buf[i*8+k]!=carimgbuf[j*40+k])
//					{
//					equ = 0;
//					break;
//					}
//				suma = j;//�ҵ��˳���������λ��
//				}
//			if(equ)break;//��Ѱ�¸�������
//			}
		for(ii=0;ii<4;ii++)
			carno[ii] = Carinfo_buf[i*8+ii];
		equ = READ_CARIMG(carno);
		if(equ==0xff)//δԤ���ã���ʾ
			{
#ifdef  0
			lcd_clear();
			zimo =1;
			goto_xy(0xA1,4);
			for(ii=0;ii<4;ii++)
				print_num2(Carinfo_buf[i*8+ii]); 
			zimo =0;
			print_XYstr_16_16(3,3,"No Setting");
			delay(KEYTIMEOUT_1S); 	
#endif
			continue;//ֱ���˳�
			}
		else//�����ҵ��ĸó�����
			{
			u8 CSN,CST,OSN,OST;
			GetCurrentTime();
//��������λ��Ϣ=�������š�4��+��λ��ˮ�š�1��+��λ״̬��1��+��λʱ�䡾2��
			suma = equ;
			CSN = Carinfo_buf[i*8+4];
			CST = Carinfo_buf[i*8+5];
			OSN = CARINFO.carsn[suma];
			OST = CARINFO.carst[suma];
			if(CSN&&(CSN!=OSN))//��ˮ�Ÿı�
				{				
				CARINFO.caroldsn[suma] = OSN;
				CARINFO.carsn[suma] = CSN;
				CARINFO.carst[suma] = CST;
				CARINFO.cartime[suma][0] = Carinfo_buf[i*8+6];
				CARINFO.cartime[suma][1] = Carinfo_buf[i*8+7];				
				if(CST!=OST)//������λ�仯
					{
					if(CST)//��������
						stflag = 1;
					else//��������--
						stflag = 0;						
					}
				else//���ٻ���
					{
					if(CST)//��ǰ�г�--����������������(����-����)
						stflag = 2;
					else
						stflag = 3;
					}
				if((stflag ==0)||(stflag ==2))//�������߻���ٻ���
					{
					// �ڴ������޳���λ������Ϣ 2015-07-17	 ��Ա��������
					if((suma==0)||(suma==1))
						{
						//�ж�ˢ��ʱ���복��ʱ���С  ˢ��ʱ��С �Զ���λ��λˢ�� 2015-06-13
						if(CARINFO.cardflag[suma])//�޳�״̬&&ˢ��
							{
					//carsno[3]//��λ��
					//CARINFO.cardintime[k][1]:CARINFO.cardintime[k][0]//ˢ��ʱ��
					//cartime[1]:cartime[0]//����ʱ��
							//��λ��λ״̬ 	
					//				RESET_NOCAR_PARKING();				
							beep(KEYTIMEOUT_1S/10);
							beep(KEYTIMEOUT_1S/10);
							beep(KEYTIMEOUT_1S/10);
							car = CARINFO.carno[suma][3];
#ifdef TWO_CAR
							car += 1;
#endif
							Deal_SwipCardIMG(car-1,0);
							read_car_reference_of_use_info(&CS_RF_US,car);//����λ״̬��Ϣ				  
							reset_carStation(car); //��λ car��λ ״̬
//							int max_stop_time;
//							max_stop_time = ret_max_24hour(CS_RF_US.start_stopTime,PARK_CARD);						
							momery = time_to_momery(CS_RF_US.start_stopTime);
							momery_buffer[0] = 0x00;												   
							momery_buffer[1] = 0x00;												  
							momery_buffer[2] = momery / 256;												   
							momery_buffer[3] = momery % 256;
							get_rate_ref(&RR_STCAR);										  
							block1_buffer[0] = 0xEE;//��¼ͷ
							block1_buffer[1] = 0;
							block1_buffer[2] = 1;
							fll(RR_STCAR.Max_Stop_Momery,block1_buffer+3,2);
//							block1_buffer[1] = CS_RF_US.smartCard_SNR[0];											 
//							block1_buffer[2] = CS_RF_US.smartCard_SNR[1]; //��������										   
//							block1_buffer[3] = CS_RF_US.smartCard_SNR[2]; //��������										 
//							block1_buffer[4] = CS_RF_US.smartCard_SNR[3]; //��������										 
							block1_buffer[5] = CS_RF_US.smartCard_SNR[4]; //��������									   
							block1_buffer[6] = CS_RF_US.smartCard_SNR[5];										
							block1_buffer[7] = CS_RF_US.smartCard_SNR[6];									   
							block1_buffer[8] = CS_RF_US.smartCard_SNR[7];										
							block1_buffer[9] = time[4];//�� 								 
							block1_buffer[10] = CS_RF_US.start_stopTime[0];//�� //�볡ʱ��
							block1_buffer[11] = CS_RF_US.start_stopTime[1];//��
							block1_buffer[12] = CS_RF_US.start_stopTime[2];//ʱ
							block1_buffer[13] = CS_RF_US.start_stopTime[3];//��
							block1_buffer[14] = CS_RF_US.smartCard_momenry[1];
							block1_buffer[15] = CS_RF_US.smartCard_momenry[2];
							block1_buffer[16] = CS_RF_US.smartCard_momenry[3];
							block1_buffer[17] = momery_buffer[2];
							block1_buffer[18] = momery_buffer[3];
							block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x06;//2015-07-17
							block1_buffer[20] = time[4];
							block1_buffer[21] = time[3];
							block1_buffer[22] = time[2];
							block1_buffer[23] = time[1];
							block1_buffer[24] = time[0];
							block1_buffer[25] = ReadRecord(car);//����ͨ��¼��־
							for(k=26;k<32;k++)			
								block1_buffer[k] = 0xAA;					
							Save_Record(block1_buffer,32);
			//				 Deal_SwipCardIMG(car-1,0);
							SaveResetRecord(block1_buffer,32,car);
							//��λ����
							light(car,NO); 
							}
						}
					//�洢������Ϣ 2015-07-17
					for(ii=0;ii<5;ii++)
						CARINFO.carouttime[suma][ii] = time[ii];					
					CARINFO.parkst[suma] = 0;//����
					CARINFO.cardflag[suma] = 0;//δˢ��
					
					WaringRe[0] = 0xEA;
					WaringRe[1] = 0x00;
					for(ii=0;ii<3;ii++)
						WaringRe[2+ii] = CARINFO.carno[suma][ii];
					for(ii=0;ii<5;ii++)
						WaringRe[5+ii] = time[4-ii];						
					WaringRe[10] = ((CARINFO.carno[suma][3]+0x05)<<4)+0x0B;						
					for(ii=0;ii<4;ii++)
						WaringRe[11+ii] = Carinfo_buf[i*8+4+ii];
					WaringRe[15] = 0xDD;						
					Save_CarRecord(WaringRe);					
					}
				if((stflag ==1)||(stflag ==2))//������������ٻ���
					{
					for(ii=0;ii<5;ii++)
						CARINFO.carintime[suma][ii] = time[ii];
//					CARINFO.parkst[suma] = 0;//����
//					CARINFO.cardflag[suma] = 0;//δˢ��
					
					WaringRe[0] = 0xEA;
					WaringRe[1] = 0x00;
					for(ii=0;ii<3;ii++)
						WaringRe[2+ii] = CARINFO.carno[suma][ii];
					for(ii=0;ii<5;ii++)
						WaringRe[5+ii] = time[4-ii];						
					WaringRe[10] = ((CARINFO.carno[suma][3]+0x05)<<4)+0x0D;						
					for(ii=0;ii<4;ii++)
						WaringRe[11+ii] = Carinfo_buf[i*8+4+ii];
					WaringRe[15] = 0xDD;						
					Save_CarRecord(WaringRe);
					}				
//				for(i=0;i<10;i++) 
//					I2C_ReadS_24C(CARRECORD_ADD+16*i,Carinfo_buf+16*i,16);
//				delay(1000);
				WRITE_CARIMG(suma);	//���³�λ״̬ 2015-04-21
				}
			//��ˮ��Ϊ0 ������ˮ��δ�ı�					
			}		
		}	
	
	memset(CarBuffer,0,CarCounter);//��ս���buffer
	CarCounter = 0;
	
}

//����Υͣ��¼����  ��Ҫ������м����ͨѶ�ſ������˹���2015-04-21
void Judge_CarTime_Illegal(void)
{
u8 i,ii,WaringRe[16],carsum,IllegalTime;
u16 pktime;

#ifdef IllegalTime_30
	IllegalTime = 29;
#else
{
#ifdef IllegalTime_15
	IllegalTime = 14;
#else
{
#ifdef IllegalTime_10
	IllegalTime = 9;
#else
	{
#ifdef IllegalTime_5
	IllegalTime = 4;
#else
	IllegalTime = 9;
#endif
	}
#endif
}
#endif
}
#endif

	I2C_ReadS_24C(LISTNET_ADD,WaringRe,16);//0-��־99 1- 2- 3-���ͼ��Ƶ�� 4- 5-Υ��ʱ��
	IllegalTime = WaringRe[5];

	READ_CARIMG("NULL");
	GetCurrentTime();
	I2C_ReadS_24C(CARSUM_ADD,&carsum,1);
//	for(i=0;i<CarNumSetting;i++)
	for(i=0;i<carsum;i++)
		{//�г�+δˢ��/����
		if(CARINFO.carst[i]&&((CARINFO.parkst[i]==1)||(CARINFO.parkst[i]==0)))//�г�-δˢ��
			{
			pktime = ret_max_24hour(CARINFO.carintime[i],MATER_RUN_TIME);
			if(pktime>=IllegalTime)
				{				
				WaringRe[0] = 0xEA;
				WaringRe[1] = 0x00;
				for(ii=0;ii<3;ii++)
					WaringRe[2+ii] = CARINFO.carno[i][ii];
				for(ii=0;ii<5;ii++)
					WaringRe[5+ii] = time[4-ii];						
				WaringRe[10] = ((CARINFO.carno[i][3]+0x05)<<4)+0x0C;						
				for(ii=0;ii<4;ii++)
					WaringRe[11+ii] = CARINFO.carintime[i][ii];
				WaringRe[15] = 0xDD;						
				Save_CarRecord(WaringRe);
				CARINFO.parkst[i] = 3;//Υ��Υͣ 
				WRITE_CARIMG(i);
				}				
			}
		}	
}

//��ȡ��������״̬ 2015-04-15 andyluo
//cararyno--0xff ������ 0-40����λ�� 
//carnobuf[4]--��������
u8 READ_CARIMG(u8 carnobuf[4])
{
u8 carimgbufR[40],aryno,cararyno,equflag;
u16 i,j,k,readadd;

	cararyno = 0xff;
	for(k=0;k<CarNumSetting;k++)
		{		
		readadd = SYS_CARIMG_ADD+k*40;
//		I2C_ReadS_24C(readadd,carimgbufR+i*40,40);
		I2C_ReadS_24C(readadd,carimgbufR,40);
//		}
//	I2C_ReadS_24C(SYS_CARIMG_ADD,carimgbuf,800);
//	for(i=0,aryno=0;aryno<CarNumSetting;aryno++)
//		{
		aryno = k;
		i = 0;
		equflag =1;
		for(j=0;j<4;j++)
			{
			CARINFO.carno[aryno][j] = carimgbufR[i++]; 
			if(carnobuf[j]!=CARINFO.carno[aryno][j])
				equflag = 0;
			}
		if(equflag)
			cararyno = aryno;
		
		for(j=0;j<1;j++)
			CARINFO.carsn[aryno] = carimgbufR[i++];  

		for(j=0;j<1;j++)
			CARINFO.carst[aryno] = carimgbufR[i++];  
		
		for(j=0;j<2;j++)
			CARINFO.cartime[aryno][j] = carimgbufR[i++];
		
		for(j=0;j<1;j++)
			CARINFO.parkst[aryno] = carimgbufR[i++];
		
		for(j=0;j<1;j++)
			CARINFO.cardflag[aryno] = carimgbufR[i++];
		
		for(j=0;j<5;j++)
			CARINFO.carintime[aryno][j] = carimgbufR[i++];
		
		for(j=0;j<5;j++)
			CARINFO.cardintime[aryno][j] = carimgbufR[i++];
		
		for(j=0;j<5;j++)
			CARINFO.carouttime[aryno][j] = carimgbufR[i++];

		for(j=0;j<4;j++)
			CARINFO.cardno[aryno][j] = carimgbufR[i++];

		for(j=0;j<1;j++)			
			CARINFO.caroldsn[aryno] = carimgbufR[i++];  
		
		for(j=0;j<3;j++)
			CARINFO.res[aryno][j] = carimgbufR[i++];

		for(j=0;j<8;j++)
			CARINFO.res1[aryno][j] = carimgbufR[i++];		
		
		}
	return cararyno;
}

//�洢��������״̬ 2015-04-15 andyluo
//aryno--���������к�
void WRITE_CARIMG(u8 aryno)	
{
u8 carimgbufW[40],carimgbufb[40],arynum;
u16 i,j;

	arynum = aryno;
	i=0;
	for(j=0;j<4;j++)
		carimgbufW[i++] = CARINFO.carno[arynum][j];
	
	for(j=0;j<1;j++)
		carimgbufW[i++] = CARINFO.carsn[arynum];

	for(j=0;j<1;j++)
		carimgbufW[i++] = CARINFO.carst[arynum];
	
	for(j=0;j<2;j++)
		carimgbufW[i++] = CARINFO.cartime[arynum][j];
	
	for(j=0;j<1;j++)
		carimgbufW[i++] = CARINFO.parkst[arynum];
	
	for(j=0;j<1;j++)
		carimgbufW[i++] = CARINFO.cardflag[arynum];
	
	for(j=0;j<5;j++)
		carimgbufW[i++] = CARINFO.carintime[arynum][j];
	
	for(j=0;j<5;j++)
		carimgbufW[i++] = CARINFO.cardintime[arynum][j];
	
	for(j=0;j<5;j++)
		carimgbufW[i++] = CARINFO.carouttime[arynum][j];

	for(j=0;j<4;j++)
		carimgbufW[i++] = CARINFO.cardno[arynum][j];
	
	for(j=0;j<1;j++)
		carimgbufW[i++] = CARINFO.caroldsn[arynum];
	
	for(j=0;j<2;j++)
		carimgbufW[i++] = CARINFO.res[arynum][j];

	for(j=0;j<8;j++)
		carimgbufW[i++] = CARINFO.res1[arynum][j];		

	j = SYS_CARIMG_ADD+arynum*40;
	I2C_WriteS_24C(j,carimgbufW,40);
	I2C_ReadS_24C(j,carimgbufb,40);
//	I2C_ReadS_24C(j,carimgbufb,40);
	
}
//��ʼ���豸ģʽ��Ϣ 2015-04-15andyluo
void INI_MBMODE(void)	
{
u8 carimgbuf[1];

	memset(carimgbuf,0,1);//��ͨ���
	I2C_WriteS_24C(MBMODE_ADD,carimgbuf,1);
}

void send_F3testimg(u8 testf3[],u8 CMD,u8 snum)
{
u8 i;
	lcd_clear();
	print_XYstr_16_16(1,1,"Send F3:");	
	goto_xy(0xA1,14);
	print_num2(snum); 
	
	zimo =1;
	goto_xy(0xA2,5);
	for(i=0;i<snum;i++)
		print_num2(testf3[i]); 
	zimo =0;
	delay(KEYTIMEOUT_1S);
}
//������м̡��м̶ˡ�
//���:�����֣� F3	���ģ�AA ��λ����1������λ1ˢ����Ϣ������λ2ˢ����Ϣ��
//��λˢ����Ϣ=��λ�š�4��+ˢ��ʱ�䡾5��+ˢ��״̬��1��	 ��1-ˢ�� 0-δˢ����
//CarBuffer[5] -F3 CarBuffer[6-9]--�豸�� CarBuffer[10-n]--����
//���յ������ˢ��״̬�����󳵼���״̬-- �ظ�������״̬
void deal_mbcardS(void)//�������ˢ��״̬
{
u8 num,carsno[4],cardtime[5],swips,i,j,k;
	//CarBuffer[10]-AA
	num = CarBuffer[11];
	for(i=0;i<num;i++)
		{
		for(j=0;j<4;j++)
			carsno[j] = CarBuffer[12+10*i+j]; 	
		for(j=4;j<9;j++)
			cardtime[j-4] = CarBuffer[12+10*i+j]; 	
		swips = CarBuffer[12+10*i+j];
		
		k = READ_CARIMG(carsno);	
		CARINFO.cardflag[k] = swips;
		if(CARINFO.parkst[k] != 3)//δΥ��
			CARINFO.parkst[k] = swips;
//		if(swips==2)//ˢ��
//			CARINFO.parkst[k] = 2;//����ˢ��
//		else if(swips==1)//ˢ��
//			CARINFO.parkst[k] = 2;//����ˢ��
//		else//δˢ��
//			CARINFO.parkst[k] = 1;//����δˢ��
			
		for(j=0;j<5;j++)
			CARINFO.cardintime[k][j] = cardtime[j];
		if(CARINFO.parkst[k]==6)//���ó���ʱ�� �Թ�����Υ�汨��
			{			
			for(j=0;j<5;j++)
				CARINFO.carintime[k][j] = cardtime[j];
			CARINFO.parkst[k]=1;
			}
		WRITE_CARIMG(k);
//��������λ��Ϣ=�������š�4��+��λ��ˮ�š�1��+��λ״̬��1��+��λʱ�䡾2��+���á�2��		
		j=4;
		CarBuffer[12+10*i+(j++)] = CARINFO.carsn[k]; 	
		CarBuffer[12+10*i+(j++)] = CARINFO.carst[k]; 	
		CarBuffer[12+10*i+(j++)] = CARINFO.cartime[k][0]; 	
		CarBuffer[12+10*i+(j++)] = CARINFO.cartime[k][1];
		CarBuffer[12+10*i+(j++)] = 0x00; 	
		CarBuffer[12+10*i+(j++)] = 0x00; 			
		}
	num = CarBuffer[3]+6;
//	send_F3testimg(CarBuffer,0xf3,num);
	USART_SendDataPacket(UART4 ,num,CarBuffer);
}
//�м̡����������ˡ�
//�м�:F3 +����š�4��AA ����������1������������λ1��Ϣ������������λ2��Ϣ��				
//��������λ��Ϣ=�������š�4��+��λ��ˮ�š�1��+��λ״̬��1��+��λʱ�䡾2��+���á�2��		
//�ó�λ������״̬
//���յ��м̳�����״̬�ظ�
void deal_basecarS(void)//�����м̳�����״̬
{
u8 num,carsno[4],carsn,carst,cartime[2],i,j,k,car;
u8 block1_buffer[32],momery_buffer[4];
u16 momery;
carStation_reference_of_used CS_RF_US; 


	//CarBuffer[10]-AA
	num = CarBuffer[11];
	for(i=0;i<num;i++)
		{
		for(j=0;j<4;j++)
			carsno[j] = CarBuffer[12+10*i+j]; 	
		carsn = CarBuffer[12+10*i+(j++)];
		carst = CarBuffer[12+10*i+(j++)];
		cartime[0] = CarBuffer[12+10*i+(j++)];
		cartime[1] = CarBuffer[12+10*i+(j++)];
		car = carsno[3];
		k = READ_CARIMG(carsno);	
		if(CARINFO.parkst[k]==6)//����ˢ��������δˢ��
			CARINFO.parkst[k]=1;	
		CARINFO.carsn[k] = carsn;	
		CARINFO.carst[k] = carst;	
		CARINFO.cartime[k][0] = cartime[0]; 	
		CARINFO.cartime[k][1] = cartime[1];		
		CARINFO.res[k][0] = 0x01; 			
		WRITE_CARIMG(k);		

		//�ж�ˢ��ʱ���복��ʱ���С  ˢ��ʱ��С �Զ���λ��λˢ�� 2015-06-13
		if((carst==0)&&(CARINFO.cardflag[k]))//�޳�״̬&&ˢ��
			{
//carsno[3]//��λ��
//CARINFO.cardintime[k][1]:CARINFO.cardintime[k][0]//ˢ��ʱ��
//cartime[1]:cartime[0]//����ʱ��
			if((cartime[1]>CARINFO.cardintime[k][1])||
			   ((cartime[1]==CARINFO.cardintime[k][1])&&
				(cartime[0]>CARINFO.cardintime[k][0])))
				{//��λ��λ״̬ 	
//				RESET_NOCAR_PARKING();				
				beep(KEYTIMEOUT_1S/10);
				beep(KEYTIMEOUT_1S/10);
				beep(KEYTIMEOUT_1S/10);
#ifdef TWO_CAR
				car += 1;
#endif
				Deal_SwipCardIMG(car-1,0);
				read_car_reference_of_use_info(&CS_RF_US,car);//����λ״̬��Ϣ				  
				reset_carStation(car); //��λ car��λ ״̬
//				int max_stop_time;
//				max_stop_time = ret_max_24hour(CS_RF_US.start_stopTime,PARK_CARD);						
				momery = time_to_momery(CS_RF_US.start_stopTime);
				momery_buffer[0] = 0x00;												   
				momery_buffer[1] = 0x00;												  
				momery_buffer[2] = momery / 256;												   
				momery_buffer[3] = momery % 256;
				get_rate_ref(&RR_STCAR);										  
				block1_buffer[0] = 0xEE;//��¼ͷ
				block1_buffer[1] = 0;
				block1_buffer[2] = 1;
				fll(RR_STCAR.Max_Stop_Momery,block1_buffer+3,2);
//				block1_buffer[1] = CS_RF_US.smartCard_SNR[0];											 
//				block1_buffer[2] = CS_RF_US.smartCard_SNR[1]; //��������										   
//				block1_buffer[3] = CS_RF_US.smartCard_SNR[2]; //��������										 
//				block1_buffer[4] = CS_RF_US.smartCard_SNR[3]; //��������										 
				block1_buffer[5] = CS_RF_US.smartCard_SNR[4]; //��������									   
				block1_buffer[6] = CS_RF_US.smartCard_SNR[5];										
				block1_buffer[7] = CS_RF_US.smartCard_SNR[6];									   
				block1_buffer[8] = CS_RF_US.smartCard_SNR[7];										
				block1_buffer[9] = time[4];//�� 								 
				block1_buffer[10] = CS_RF_US.start_stopTime[0];//�� //�볡ʱ��
				block1_buffer[11] = CS_RF_US.start_stopTime[1];//��
				block1_buffer[12] = CS_RF_US.start_stopTime[2];//ʱ
				block1_buffer[13] = CS_RF_US.start_stopTime[3];//��
				block1_buffer[14] = CS_RF_US.smartCard_momenry[1];
				block1_buffer[15] = CS_RF_US.smartCard_momenry[2];
				block1_buffer[16] = CS_RF_US.smartCard_momenry[3];
				block1_buffer[17] = momery_buffer[2];
				block1_buffer[18] = momery_buffer[3];
				block1_buffer[19] = ((car+CAR_CLASS)<<4) + 0x06;//2015-07-17
				block1_buffer[20] = time[4];
				block1_buffer[21] = time[3];
				block1_buffer[22] = time[2];
				block1_buffer[23] = time[1];
				block1_buffer[24] = time[0];
				block1_buffer[25] = ReadRecord(car);//����ͨ��¼��־
				for(k=26;k<32;k++) 			
					block1_buffer[k] = 0xAA;					
				Save_Record(block1_buffer,32);
//				 Deal_SwipCardIMG(car-1,0);
				SaveResetRecord(block1_buffer,32,car);
				//��λ����
				light(car,NO); 
				}
			}		
		}	
}

//���:������ˡ������֣� F3	���ģ�AA ��λ����1������λ1ˢ����Ϣ������λ2ˢ����Ϣ��
//��λˢ����Ϣ=��λ�š�4��+ˢ��ʱ�䡾5��+ˢ��״̬��1��	 ��1-ˢ�� 0-δˢ����
//�������ˢ����Ϣ���м�  
//��֪�м�ˢ��״̬ ���󳵼���״̬
void MBtoBase_Card(void)
{
u8 CarACK[40],i=0,j,k,xor=0xff,mbno[4],swips=0,cariq=0;
u32 timeout;

	I2C_ReadS_24C(mibiao_number,mbno,3);//�����
	CarACK[i++] = 0x28;
	CarACK[i++] = 0x28;
	CarACK[i++] = 0xCC;
	CarACK[i++] = 29;//����
	CarACK[i++] = 0x01;
	CarACK[i++] = 0xF3;
	CarACK[i++] = mbno[0];
	CarACK[i++] = mbno[1];
	CarACK[i++] = mbno[2];
	CarACK[i++] = 0x00;
	CarACK[i++] = 0xAA;
	CarACK[i++] = 0x02;
    mbno[3] = 0x01;
	k = READ_CARIMG(mbno);		
	CarACK[i++] = mbno[0];
	CarACK[i++] = mbno[1];
	CarACK[i++] = mbno[2];
	CarACK[i++] = mbno[3];
	for(j=0;j<5;j++)
		CarACK[i++] = CARINFO.cardintime[k][j];
	CarACK[i++] = CARINFO.parkst[k];	
	if(CARINFO.parkst[k]==2)swips =1;
	if(CARINFO.res[k][0]==0x00)cariq =1;	
    mbno[3] = 0x02;
	k = READ_CARIMG(mbno);	
	CarACK[i++] = mbno[0];
	CarACK[i++] = mbno[1];
	CarACK[i++] = mbno[2];
	CarACK[i++] = mbno[3];
	for(j=0;j<5;j++)
		CarACK[i++] = CARINFO.cardintime[k][j];
	CarACK[i++] = CARINFO.parkst[k];	
	if(CARINFO.parkst[k]==2)swips =1;
	if(CARINFO.res[k][0]==0x00)cariq =1;	
	for(j=0;j<27;j++)
		{
		xor ^= CarACK[5+j];
		}
	CarACK[i++] = xor;	
	CarACK[i++] = 0xCC;
	CarACK[i++] = 0xCC;
	//δˢ������
//	if((swips ==0)&&(cariq ==0))return;//��ʾ�޳�λˢ�� 2015-05-11 andyluo
	if(swips ==0)return;//��ʾ�޳�λˢ�� 2015-05-11 andyluo
//ÿ2���Ӹ��³�������״̬ 2015-07-17  ���ǵ����߸�λ�����
	if(((time1[0]+mbno[2])%2)!=0)//ÿ2����
		return;	
	SYS_MS.INT_BASE = FALSE;
	Set_G24_BaseM();//����2.4Gģ����Ҫ���յĳ�������
	if(key_flag)return;	
//	send_F3testimg(CarACK,0xf3,35);
	USART_SendDataPacket(UART4 ,35,CarACK);	
	key_flag = 0;
	timeout= KEYTIMEOUT_1S*1;
	while(timeout--)
		{	
		if((SYS_MS.INT_BASE == TRUE)||key_flag)
			{
			break;
			}
		}
	close_ir_comm();
	UART4_IRQn_CTL(OFF);
	
}

//���ظó�λ�ĳ�����״̬ 1-�г�  0-�޳�
u8 IQ_SpaceState(u8 space)
{
u8 k,mbno[4];

	I2C_ReadS_24C(mibiao_number,mbno,3);//�����
    mbno[3] = space;
	k = READ_CARIMG(mbno);	
	if(CARINFO.carst[k])return 1;
	else return 0;	
}

//����ˢ��״̬��ˢ��ʱ��
//carnum ��λ�� 1-2 cards-2:��ǩ 1:ˢ�� 0:����
//�� CARINFO.parkst�볡-2 ����-6
void Deal_SwipCardIMG(u8 carnum,u8 cards)
{
u8 j,k,mbno[4],flag;

	GetCurrentTime();
	I2C_ReadS_24C(mibiao_number,mbno,3);//�����
    mbno[3] = carnum;
	k = READ_CARIMG(mbno);	
	flag = Judge_MB_MODE();// 1-�������
	CARINFO.cardflag[k] = cards;
	if(cards==CardType_MF1)//MF1ˢ��
		CARINFO.parkst[k] = 2;//����ˢ��
	else if(cards==CardType_CPC)//����ˢ��
		CARINFO.parkst[k] = 2;//����ˢ��
	else if(cards==CardType_BIKE)//���г���ˢ��
		CARINFO.parkst[k] = 2;//����ˢ��
	else if(cards==4)//��ǩˢ��
		CARINFO.parkst[k] = 2;//����ˢ��
	else if((cards==0)&&(flag==1))//��ͨ���ˢ��
		CARINFO.parkst[k] = 6;//����ˢ��
	else//δˢ��
		CARINFO.parkst[k] = 1;//����δˢ��
	if(cards==0)//����
		{
		for(j=0;j<5;j++)
			{//�Զ���Ϊ�³�2015-05-15
			CARINFO.carintime[k][j]= time[j];
			}
		}		
	for(j=0;j<5;j++)//ˢ��ʱ��
		CARINFO.cardintime[k][j] = time[j];	
	CARINFO.res[k][0] = 0x00;	//��Ҫѯ�ʵı�־ 2015-05-14
	WRITE_CARIMG(k);	
}




//�洢�������ߡ�Υ����Ϣ 
void Save_CarRecord(u8 carbuf[16])
{
u8 carimgbuf[2];
u16 saveadd;

	I2C_ReadS_24C(CARRECORD_SAVEADD,carimgbuf,2);
	saveadd = hcl(carimgbuf,2);
	I2C_WriteS_24C(saveadd,carbuf,16);
//	delay(1000);
	saveadd += 16;
	if(saveadd >= CARRECORD_ENDADD)
		saveadd = CARRECORD_ADD;
	fll(saveadd,carimgbuf,2);
	I2C_WriteS_24C(CARRECORD_SAVEADD,carimgbuf,2);
}


//�´��Э��-����������
void SendCar16Record(u8 record[],u16 RecordPage,u8 RecordCount1)
{
/*
*<Long><0196></Long><Result><Optype><EAEA></Optype><Metno><000063></Metno><Bagsum><0020></Bagsum><Waring><���������¼></Waring></Result># 
   ��̨�ظ�
#<ErrorCode><0></ErrorCode>*
���������¼ÿ����¼˵����
ÿ����16�ֽڹ��ɣ���<Metno><000063></Metno>�˴������ֻ������������ţ���������¼��������ţ���¼�������������ÿ��16�ֽ��С���
EA��1�ֽ�-�̶���־��+����š�4�ֽڣ����ǵ��������������ʱ�Դ������Ϊ��׼��+��¼����ʱ�䡾5�ֽڡ�+��¼��־��1�ֽڡ�+������Ϣ��5�ֽ�--�ɲ���������*/
unsigned char  sz3[4];

	uart_send_som("*0%<Long><0196></Long><Result>");
	Send_Segtime();

    I2C_ReadS_24C(mibiao_number,sz3,3);//�����
    uart_send_som("<Optype><EAEA></Optype><Metno><66");
    
    SEND_asic_2th(sz3[0]);//����� 3�ֽ�
    SEND_asic_2th(sz3[1]);
    SEND_asic_2th(sz3[2]);
	
    uart_send_som("></Metno><Bagsum><");
    
    SEND_asic_2th((RecordPage / RecordCount1) / 256);// �������� 2�ֽ� Hex
    SEND_asic_2th((RecordPage / RecordCount1) % 256);
    uart_send_som("></Bagsum><Waring><");
    
    for(int i=0;i < RecordPage;i++)
      SEND_asic_2th(record[i]);    
    
    uart_send_som("></Waring></Result>#");
}

//������Ϣ���� SendCon32Record
u8 SendCarRecord(void)
{
u8 	i,k,loop,waringbuf[320],sendFlag;
u16 waringsum,fsum1,fsum2;
u8 saveadd[2],sendadd[2];

	I2C_ReadS_24C(CARRECORD_SAVEADD,saveadd,2);
	I2C_ReadS_24C(CARRECORD_SENDADD,sendadd,2);
	fsum1 =hcl(saveadd,2);
	fsum2 =hcl(sendadd,2);
	if(fsum1>=fsum2)
		{
		waringsum = fsum1-fsum2;
		loop = waringsum/16;
		if(loop>20)loop = 20;
		for(i=0;i<loop;i++)	
			I2C_ReadS_24C(fsum2+16*i,waringbuf+16*i,16);
		}
	else 
		{
		waringsum =CARRECORD_ENDADD+fsum1-CARRECORD_ADD-fsum2;
		loop = (CARRECORD_ENDADD-fsum2)/16;
		if(loop>=20)
			{
			loop = 20;
			for(i=0;i<loop;i++)	
				I2C_ReadS_24C(fsum2+16*i,waringbuf+16*i,16);
			}
		else
			{
			k = i;
			loop = (fsum1-CARRECORD_ADD)/16;
			if(loop >20)
				{
				loop = 20;
				for(i=0;i<loop;i++) 
					I2C_ReadS_24C(CARRECORD_ADD+16*i,waringbuf+16*(i+k),16);
				}
			else
				{
				for(i=0;i<loop;i++) 
					I2C_ReadS_24C(CARRECORD_ADD+16*i,waringbuf+16*(i+k),16);
				}
			}
		}
	if(waringsum >= 20*16)waringsum = 20*16;
	
	if(!waringsum)return 0;//������ֱ�ӷ���2015-04-28
	
	sendFlag = open_gprs();
	if(sendFlag != OK)return 1;//�������ɹ�
	f_receiveOK = 0;
	key_flag = 0;
	SendCar16Record(waringbuf,waringsum,16);
	rec_gprs_ack(3);
	if(key_flag)//�����˳�
		{
		NET_KeyDeal();	
		}
	if(f_receiveOK)//���ճɹ�
		{	
		fsum2 += waringsum;
		if(fsum2>=CARRECORD_ENDADD)
			fsum2 = fsum2-CARRECORD_ENDADD+CARRECORD_ADD;
		fll(fsum2,sendadd,2);
		I2C_WriteS_24C(CARRECORD_SENDADD,sendadd,2);

		loop = 3;
		while(loop--)
			{
			sendFlag =NETSTATE_FUN("*SLEEP#");
			if(key_flag)break;
			if(sendFlag==NETSTATE_SLEEP)break;
			}
		}
	return 1;
}


//��ʾ �ε� 										  
void beep(u32 timespace)
{
	Buzz_0;
	delay(timespace);
	Buzz_1;
}
void disp_systest(u8 inverseline)
{
char *str1 ="1.CarIQ",*str2 ="2.RecIQ";
char *str3 ="3.RomIQ",*str4 ="4.TestC";
char *str5 ="5.SetC",*str6 ="6.SysIQ";
char *str7 ="7.CRRec",*str8 ="8.CRRom";
char *str9 ="9.Reset",*str10 ="10.SetS";
char *str11 ="11.ListU",*str12 ="12.ListI";
char *str13 ="13.APPU",*str14 ="14.RTCU";
char *str15 ="15.CPCT",*str16 ="16.NETIQ";
char *str17 ="17.CRList",*str18 ="18.LOCK";

//	LCD_POWER_OFF;
//	delay(KEYTIMEOUT_1S/10);
//	LCD_POWER_ON;
//	LCD_INIT();
//	disp_YWT_IMG(2);
	lcd_clear();
	
	print_XYstr_16_16(1,1,str1);	
	print_XYstr_16_16(1,9,str2);
	print_XYstr_16_16(2,1,str3);
	print_XYstr_16_16(2,9,str4);
	print_XYstr_16_16(3,1,str5);
	print_XYstr_16_16(3,9,str6);
	print_XYstr_16_16(4,4,str7);
	//print_XYstr_16_16(4,9,str8);

	zimo =1;
	switch(inverseline)
		{
		case 1:
			print_XYstr_16_16(1,1,str1);	
			break;
		case 2:
			print_XYstr_16_16(1,9,str2);
			break;
		case 3:
			print_XYstr_16_16(2,1,str3);
			break;
		case 4:
			print_XYstr_16_16(2,9,str4);//�汾/ ״̬/��ѹ
			break;
		case 5:
			print_XYstr_16_16(3,1,str5);
			break;
		case 6:
			print_XYstr_16_16(3,9,str6);//��������+�����
			break;
		case 7:
			print_XYstr_16_16(4,4,str7);
			break;
		case 8:
			print_XYstr_16_16(4,4,str8);
			break;
		case 9:
			print_XYstr_16_16(4,4,str9);
			break;
		case 10:
			print_XYstr_16_16(4,4,str10);
			break;
		case 11:
			print_XYstr_16_16(4,4,str11);
			break;
		case 12:
			print_XYstr_16_16(4,4,str12);
			break;
		case 13:
			print_XYstr_16_16(4,4,str13);
			break;
		case 14:
			print_XYstr_16_16(4,4,str14);
			break;			
		case 15:
			print_XYstr_16_16(4,4,str15);
			break;			
		case 16:
			print_XYstr_16_16(4,4,str16);
			break;			
		case 17:
			print_XYstr_16_16(4,4,str17);
			break;			
		case 18:
			print_XYstr_16_16(4,4,str18);
			break;			
		default:
			break;			
		}
	print_16x16GB(4,1,"�S");//ѡȡͼ��"��"
	print_16x16GB(4,14,"�_");//ȷ��ͼ��" ��"
	zimo =0;	
}

unsigned char  HEX_to_BCD(unsigned char HEX)
{
	unsigned char BCD;
    
	BCD = ( HEX/10)*16+(HEX%10);
		
	return BCD;
}
//1-������� 0-�м����
u8 Judge_MB_MODE(void)
{
u8 mbno[4];
//	return 1;//��ʱ����


	I2C_ReadS_24C(mibiao_number,mbno,4);//�����
	if(mbno[2])//�������
		return 1;
	else 
		return 0;
}
//CMD -1 
/*
�����֣�F1
1-1-1����Ͻ��Χ
���ģ�D1
��ѯ���м̺Ź�Ͻ��Χ�����г�������״̬
���ģ�D2
��ѯ������Ź�Ͻ��Χ�����г�������״̬
���ģ�D3+����������1��+��������1��4��+����+��������N��4��
��ѯ�о���N����������״̬
*/
//LENGTH-���ĳ���
void Send_CarIQ_CMD(u8 LENGTH,u8 CMD,u8 TEXT[32])
{
u8 data[64]={0x28,0x28,0xCC,
			8,
			0x01,
			0xF1,
			0x01,0x02,0x00,0x00,
			0xD1,
			0xff,
			0xCC,0xCC,
			};
u8 BCC,i;

	data[3] = LENGTH+7;	//�ܳ���

	data[5] = CMD;		//������
	
    I2C_ReadS_24C(mibiao_number,data+6,3);//�����
	
	for(i=0;i<LENGTH;i++)
		data[10+i] = TEXT[i];
	
	BCC = 0xff;
	for(i=0;i<LENGTH+5;i++)
		BCC ^= data[i+5];
	
	data[LENGTH+10] = BCC;
	data[LENGTH+11] = 0xCC;
	data[LENGTH+12] = 0xCC;

//    open_ir_comm();	
//    delay(500000);
    USART_SendPacket(UART4,LENGTH+13,data);
	
}
//����2.4G��Ͻ�豸�� 2015-05-09
void Set_G24_BaseM(void)
{
u8 cartext[16],i;
u32 timeOut;

	for(i=0;i<180;i++)
		CarBuffer[i] = 0x00;//cartest[i];
	CarCounter = 0;
	CarBuffer[201] = 0;
	CarBuffer[200] = 0;//��ʾ���Խ��ղ���Ҫ��ʾ 2015-04-30
//	CarBuffer[200] = 1;//��ʾ���Խ�����Ҫ��ʾ 2015-04-30
//	UART4_IRQn_CTL(OFF);
	UART4_IRQn_CTL(ON);
	open_ir_comm();
	cartext[0] = 0xD0;
	key_flag = 0;
	timeOut = KEYTIMEOUT_1S /3; 		
	while(timeOut--)
		{ 
		if(key_flag)return;
		}
	
	i = 3;
	while(i--)
		{
//		delay(500);		
		Send_CarIQ_CMD(1,0xF1,cartext);

		key_flag = 0;
		timeOut = KEYTIMEOUT_1S *2; 		
		while(timeOut--)
			{ 
			if(key_flag)return;
			}
		
		if(CarBuffer[201] == 0xAA)//�лظ������޻ظ�������3��
			break;
		}
	
}


void IQ_CarState(void)
{
u8 cartext[16],i;
u32 timeOut;

	for(i=0;i<180;i++)
		CarBuffer[i] = 0x00;//cartest[i];
	CarCounter = 0;
	CarBuffer[201] = 0;
	CarBuffer[200] = 0;//��ʾ���Խ��ղ���Ҫ��ʾ 2015-04-30
//	CarBuffer[200] = 1;//��ʾ���Խ�����Ҫ��ʾ 2015-04-30
//	UART4_IRQn_CTL(OFF);
	UART4_IRQn_CTL(ON);
	open_ir_comm();
	key_flag = 0;
	timeOut = KEYTIMEOUT_1S /3; 		
	while(timeOut--)
		{ 
		if(key_flag)return;
		}
	cartext[0] = 0xD1;
//	Send_CarIQ_CMD(1,0xF1,cartext);	
	
	i = 2;
	while(i--)
		{
//		delay(500); 	
		Send_CarIQ_CMD(1,0xF1,cartext);

		key_flag = 0;
		timeOut = KEYTIMEOUT_1S *2; 		
		while(timeOut--)
			{ 
			if(key_flag)return;
			if(CarBuffer[201] == 0xAA)//�лظ������޻ظ�������3��
				break;
			}
		
		if(CarBuffer[201] == 0xAA)//�лظ������޻ظ�������3��
			break;
		}
	if(CarBuffer[201] != 0xAA)//�лظ������޻ظ�������3��
		{
		lcd_clear();
		print_XYstr_16_16(2,3,"Please wait...");
		print_XYstr_16_16(3,3,"Reset BTM...");
		close_ir_comm();
		delay(KEYTIMEOUT_1S/2);
		open_ir_comm(); 
		delay(KEYTIMEOUT_1S/2);
		UART4_IRQn_CTL(ON);//�򿪳����������ж� 2015-04-29
		Set_G24_BaseM();
		}	
}

//���ù�Ͻ�������λ 2015-05-09 andyluo
void SetAdmin_SYSCarNo(u8 data[4])
{
u8 i,j,k,carsum;
//data[0] data[1] �м̺�    data[2]�����  data[3]��λ��
	carsum = BCDtoHex(data[3]);
//	if(data[2])//Ϊ���
//		;
//	else
//		carsum *= 2;	
	if(carsum>CarNumSetting)carsum = CarNumSetting; 
	else if(carsum<2)carsum =2;
	I2C_WriteS_24C(CARSUM_ADD,&carsum,1);	
	for(i=0,k=0;i<carsum;k++)
		{
		CARINFO.carno[i][2]= data[2]+k;
		CARINFO.carno[i][3]= 0x01;
		CARINFO.carno[i+1][2]= data[2]+k;
		CARINFO.carno[i+1][3]= 0x02;
		i += 2;		
		}	
	for(i=0;i<carsum;i++)
		{
		for(j=0;j<2;j++)
			CARINFO.carno[i][j]=data[j];
		for(j=0;j<1;j++)
			CARINFO.carsn[i] = 0;  		
		for(j=0;j<1;j++)
			CARINFO.carst[i] = 0;  		
		for(j=0;j<2;j++)
			CARINFO.cartime[i][j] = 0;		
		for(j=0;j<1;j++)
			CARINFO.parkst[i] = 0;		
		for(j=0;j<1;j++)
			CARINFO.cardflag[i] = 0;		
		for(j=0;j<5;j++)
			CARINFO.carintime[i][j] = 0;		
		for(j=0;j<5;j++)
			CARINFO.cardintime[i][j] = 0;		
		for(j=0;j<5;j++)
			CARINFO.carouttime[i][j] = 0;		
		for(j=0;j<4;j++)
			CARINFO.cardno[i][j] = 0;		
		for(j=0;j<1;j++)			
			CARINFO.caroldsn[i] = 0;			
		for(j=0;j<3;j++)
			CARINFO.res[i][j] = 0;		
		for(j=0;j<8;j++)
			CARINFO.res1[i][j] = 0; 			
		WRITE_CARIMG(i);
		}
}

//��ѯ����λ��״̬ 2015-05-09
void CarIQ_MENU(void)
{
u8 carsum,page,suma,ii,i,j,mbno[3];
u32 timeOut;

	READ_CARIMG("NULL");			
	I2C_ReadS_24C(CARSUM_ADD,&carsum,1);
	lcd_clear();
	goto_xy(0,0);
	for(i=0;i<carsum;i++)
		{
		for(j=0;j<5;j++)
			{
			if(i*5+j>=carsum)break;
			if(CARINFO.carst[i*5+j])zimo =1;
			LCD_Sring1("P");
			if(CARINFO.carst[i*5+j])zimo =0;		
			if(CARINFO.parkst[i*5+j]==2)zimo =1;
			LCD_Sring1("S ");
			if(CARINFO.parkst[i*5+j]==2)zimo =0;
			}
		LCD_Sring1("-");
//		i += 5;		
		}
	delay(KEYTIMEOUT_1S); 
	key_flag = 0;
	timeOut = KEYTIMEOUT_1S *8; 		
	while(timeOut--)
		{ 
		if(key_flag)
			break;
		}	


	lcd_clear();
	print_XYstr_16_16(1,1,"SUM:");				
	print_XYstr_16_16(1,7,"--");	
	goto_xy(0xA1,9);//HEX_to_BCD(carsum)
	print_num2(HEX_to_BCD(carsum));		
	
	I2C_ReadS_24C(mibiao_number,mbno,3);//�����
	
	if(mbno[2])
		suma = 0;//��ͨ���
	else
		suma = 1;//�м���� 	
	
//	I2C_ReadS_24C(MBMODE_ADD,&suma,1);
	zimo =1;
	if(suma)//base
		print_XYstr_16_16(1,11,"Base");
	else
		print_XYstr_16_16(1,11,"Normal"); 				
	zimo =0;
	
//	carsum = CarNumSetting;//���� 2015-04-17
//	page = carsum/6;
//	if(carsum%12)page++;
	page = carsum/3;
	if(carsum%6)page++;
	for(i=0;i<page;i++)
		{
		zimo =1;
		goto_xy(0xA1,5);
		suma = (i+1)*3;
		if(suma >= carsum)
			print_num2(HEX_to_BCD(carsum)); 
		else
			print_num2(HEX_to_BCD(suma)); 
		zimo =0;
		lcd_clear_h(2);
		lcd_clear_h(3);
		lcd_clear_h(4);
		for(j=0;j<3;j++)
			{
			if((i*3+j) >= carsum)break;
			goto_xy(0xA2+j,1);
			for(ii=0;ii<4;ii++)
				print_num2(CARINFO.carno[i*3+j][ii]); 

			if(CARINFO.carst[i*3+j])zimo =1;
			print_XYstr_16_16(2+j,10,"P");				
			if(CARINFO.carst[i*3+j])zimo =0;
			
			if(CARINFO.parkst[i*3+j]==2)zimo =1;
			print_XYstr_16_16(2+j,12,"S ");				
			if(CARINFO.parkst[i*3+j]==2)zimo =0;
			print_num2(CARINFO.parkst[i*3+j]); 
			
			}
		delay(KEYTIMEOUT_1S); 
		key_flag = 0;
		timeOut = KEYTIMEOUT_1S *4; 		
		while(timeOut--)
			{ 
			if(key_flag)
				break;
			}	
		if(key_flag==0x03)
			{
			key_flag = 0;
			timeOut = KEYTIMEOUT_1S; 		
			while(timeOut--)
				{ 
				if(key_flag)
					break;
				}	
			if(key_flag==0x03)
				exit_cariq = 1;
			break;
			}
		}		
}
void RecIQ_MENU(void)
{
u8 saveadd[2],sendadd[2],i;
u16 fsum1,fsum2,ssum;
u32 timeOut;

	I2C_ReadS_24C(CARRECORD_SAVEADD,saveadd,2);
	I2C_ReadS_24C(CARRECORD_SENDADD,sendadd,2);
	fsum2 =hcl(saveadd,2);
	fsum1 =hcl(sendadd,2);
	if(fsum1<=fsum2)ssum = fsum2-fsum1;
	else ssum =CARRECORD_ENDADD-CARRECORD_ADD-fsum2+fsum1;
	ssum /= 16;
	
	lcd_clear();
	print_XYstr_16_16(1,1,"Add-:");				
	goto_xy(0xA1,6);
	print_num2((u8)(CARRECORD_ADD>>8)); 
	print_num2((u8)CARRECORD_ADD); 
	print_XYstr_16_16(1,10,"--");				
	goto_xy(0xA1,12);
	print_num2((u8)(CARRECORD_ENDADD>>8)); 
	print_num2((u8)CARRECORD_ENDADD); 
	
	print_XYstr_16_16(2,1,"Save:");				
	goto_xy(0xA2,8);
	for(i=0;i<2;i++)
		print_num2(saveadd[i]); 
	print_XYstr_16_16(3,1,"Send:");				
	goto_xy(0xA3,8);
	for(i=0;i<2;i++)
		print_num2(sendadd[i]); 
	
	print_XYstr_16_16(4,1,"Nsum:");				
	goto_xy(0xA4,8);
	print_num2(HEX_to_BCD(ssum)); 
	
	//��ʾδ�������Ѽ�¼�� 2015-04-29
	ssum = ReturnRecordCount();
	zimo = 1;
	goto_xy(0xA4,15);
	print_num2(HEX_to_BCD(ssum)); 
	zimo =0;
	
	delay(KEYTIMEOUT_1S); 
	key_flag = 0;
	timeOut = KEYTIMEOUT_1S *4; 		
	while(timeOut--)
		{ 
		if(key_flag)
			break;
		}	
}
void RomIQ_MENU(void)
{
u8 carsum,i,j;
u32 timeOut;

	READ_CARIMG("NULL");			
	I2C_ReadS_24C(CARSUM_ADD,&carsum,1);
	lcd_clear();
	for(i=0;i<CarNumSetting;i++)
		{
		zimo =1;
		goto_xy(0xA1,1);
		print_num2(HEX_to_BCD(i+1)); 
		zimo =0;
		
		for(j=0;j<4;j++)
			print_num2(CARINFO.carno[i][j]);
		
		zimo =1;
		for(j=0;j<1;j++)
			print_num2(CARINFO.carsn[i]);
		
		for(j=0;j<1;j++)
			print_num2(CARINFO.carst[i]);	
		zimo =0;
		
		for(j=0;j<2;j++)
			print_num2(CARINFO.cartime[i][j]);
		
		zimo =1;
		for(j=0;j<1;j++)
			print_num2(CARINFO.parkst[i]);
		zimo =0;
		
		for(j=0;j<1;j++)
			print_num2(CARINFO.cardflag[i]);
		
		for(j=0;j<5;j++)
			print_num2(CARINFO.carintime[i][4-j]);
		
		zimo =1;
		for(j=0;j<5;j++)
			print_num2(CARINFO.cardintime[i][4-j]);
		zimo =0;
		
		for(j=0;j<5;j++)
			print_num2(CARINFO.carouttime[i][4-j]);
		
		for(j=0;j<4;j++)
			print_num2(CARINFO.cardno[i][j]);
		
		zimo =1;
		for(j=0;j<1;j++)
			print_num2(CARINFO.caroldsn[i]);
		zimo =0;
		
		delay(KEYTIMEOUT_1S); 
		key_flag = 0;
		timeOut = KEYTIMEOUT_1S *8; 		
		while(timeOut--)
			{ 
			if(key_flag)
				break;
			}	
		if(key_flag==0x03)return;
		}
}
 
void TestC_MENU(void)
{
u8 cartext[16],i,cartest[180]={
				0x28,0x28,0xCC,
				94,
				0x01,
				0xF1,
				0x00,0x01,0x01,0x00,
				0xDE,
				20,
				0x00,0x01,0x01,0x01,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x01,0x02,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x02,0x01,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x02,0x02,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x03,0x01,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x03,0x02,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x04,0x01,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x04,0x02,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x05,0x01,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x05,0x02,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x06,0x01,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x06,0x02,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x07,0x01,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x07,0x02,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x08,0x01,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x08,0x02,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x09,0x01,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x09,0x02,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x10,0x01,0x0A,0x01,0x00,0x00,
				0x00,0x01,0x10,0x02,0x0A,0x01,0x00,0x00,
				0xFF,
				0xCC,0xCC
				};	
	for(i=0;i<180;i++)
		CarBuffer[i] = 0x00;//cartest[i];
	CarCounter = 0;
	CarBuffer[200] = 0;//��ʾ���Խ��ղ���Ҫ��ʾ 2015-04-30
//	CarBuffer[200] = 1;//��ʾ���Խ�����Ҫ��ʾ 2015-04-30
//	UART4_IRQn_CTL(OFF);
	lcd_clear();
	print_XYstr_16_16(2,2,"Please wait");
	print_XYstr_16_16(3,2,"Car testing...");				
	UART4_IRQn_CTL(ON);
	open_ir_comm();
	delay(500000);
	cartext[0] = 0xD1;
	Send_CarIQ_CMD(1,0xF1,cartext);
	CarBuffer[200] = 1;
	delay(KEYTIMEOUT_1S*2);
	key_flag = 0;
	u32 timeOut = KEYTIMEOUT_1S *4; 		
	while(timeOut--)
		{ 
		if(key_flag)
			break;
		}	
	if(key_flag)return;
//	Deal_CarInfo(1);
}
//��ʼ��Ϊ0101�м�
void SetC_MENU(void)
{
u8 i,j,carimgbuf[800];
u32 timeOut,ssum;
u8 tmpcarno[20][4]={
	{0x00,0x01,0x00,0x01},{0x00,0x01,0x00,0x02},
	{0x00,0x01,0x01,0x01},{0x00,0x01,0x01,0x02},
	{0x00,0x01,0x02,0x01},{0x00,0x01,0x02,0x02},
	{0x00,0x01,0x03,0x01},{0x00,0x01,0x03,0x02},
	{0x00,0x01,0x04,0x01},{0x00,0x01,0x04,0x02},
	{0x00,0x01,0x05,0x01},{0x00,0x01,0x05,0x02},
	{0x00,0x01,0x06,0x01},{0x00,0x01,0x06,0x02},
	{0x00,0x01,0x07,0x01},{0x00,0x01,0x07,0x02},
	{0x00,0x01,0x08,0x01},{0x00,0x01,0x08,0x02},
	{0x00,0x01,0x09,0x01},{0x00,0x01,0x09,0x02},
	};

	lcd_clear();
	print_XYstr_16_16(1,3,"Initialize");				
	print_XYstr_16_16(2,2,"Car sensor no.");
	zimo =1;
	print_XYstr_16_16(4,1,"CL");	
	print_XYstr_16_16(4,14,"CM");	
	zimo =0;
	delay(KEYTIMEOUT_1S); 
	key_flag = 0;
	timeOut = KEYTIMEOUT_1S *4; 		
	while(timeOut--)
		{ 
		if(key_flag)
			break;
		}	
	if(key_flag==0x02)return;
	
	i = CarNumSetting;
	I2C_WriteS_24C(CARSUM_ADD,&i,1);	
	
	for(i=0;i<CarNumSetting;i++)
		{
		for(j=0;j<4;j++)
			CARINFO.carno[i][j]=tmpcarno[i][j];
		WRITE_CARIMG(i);
		}
	for(i=0;i<CarNumSetting;i++)
		I2C_ReadS_24C(SYS_CARIMG_ADD+i*40,carimgbuf+i*40,40);
	//			I2C_ReadS_24C(SYS_CARIMG_ADD,carimgbufA+,800);
	for(ssum=0;ssum<800;)
		{
		for(i=0;i<36;i++)
			carimgbuf[ssum+4+i]=0x00;
		ssum += 40;
		}			
	for(i=0;i<CarNumSetting;i++)
		I2C_WriteS_24C(SYS_CARIMG_ADD+i*40,carimgbuf+i*40,40);
	//			I2C_WriteS_24C(SYS_CARIMG_ADD,carimgbufA,800);
	for(i=0;i<CarNumSetting;i++)
		I2C_ReadS_24C(SYS_CARIMG_ADD+i*40,carimgbuf+i*40,40);

	lcd_clear_h(4);
	print_XYstr_16_16(4,8,"OK");	
	delay(KEYTIMEOUT_1S); 
}

//��ѯ�˵�--
void SysIQ_MENU(void)
{
u8 mbno[6],PDACMD,Rx_IrDA[32];
u32 timeOut;
unsigned char data[64]={0x28,0x28,0xCC,0x08,0x01,0xF4,
	0x01,0x02,0x03,0x00,0xA6,0xFF,0xCC,0xCC};

	key_flag = 0;
	I2C_ReadS_24C(mibiao_number,mbno,4);//�����
	lcd_clear();
	print_XYstr_16_16(1,1,"MB no.:"); 			
	zimo =1;
	goto_xy(0xA1,8);
	print_num2(mbno[0]); 
	print_num2(mbno[1]); 
	print_num2(mbno[2]); 
	print_num2(mbno[3]); 
	zimo =0;	
	if(mbno[2])//�������
		print_XYstr_16_16(1,16,"N");		
	else
		print_XYstr_16_16(1,16,"B");
	
    I2C_ReadS_24C(MATER_VER,mbno,2);
    
    //�汾��
	print_XYstr_16_16(2,1,"MBV:"); 	
	print_XYstr_16_16(2,6,CUSTOMERVERSION); 	
    LCD_display_symbol(2,9,mbno[0]&0x0f,0);
    LCD_display_symbol(2,10,5,1);// .
    LCD_display_symbol(2,11,mbno[1]&0x0f,0);

	//����-ģ�鿪��  ����-�ر�
	print_XYstr_16_16(3,1,"2G4V:"); 		
	
	if(SYS_MS.G24S == ON)
		{
		close_ir_comm();
		delay(KEYTIMEOUT_1S/2);
		open_ir_comm(); 
		delay(KEYTIMEOUT_1S/2);
		UART4_IRQn_CTL(OFF);
//		ir_comm(OFF);
//	2-3-5���汾��Ϣ
//	A��F4 ����š�4��A6 
//	Q��F4 ����š�4��A6 ͨѶģ�顾2.4Gģ�顿�汾��Ϣ��V2015-03-21-1WC��
		timeOut = 3;
		while(timeOut--)
			{
			USART_SendPacket(UART4,14,data);
			PDACMD = rev_ack_new(Rx_IrDA);
			if(PDACMD==0xF4)break;
			delay(KEYTIMEOUT_1S/2);
			}
		UART4_IRQn_CTL(ON);

		print_num2(Rx_IrDA[5]); 
		print_num2(Rx_IrDA[6]); 
		print_num2(Rx_IrDA[7]); 
		print_num2(Rx_IrDA[8]); 
		print_num2(Rx_IrDA[9]); 
		}
	else
		LCD_Sring1("close");

	
	if(SYS_MS.G3S == ON)
		{
		if(NETSTATE == NETSTATE_CLOSE)
			{
			open_gprs_power();
			delay(KEYTIMEOUT_1S*2);
			}
		timeOut = 3;
		while(timeOut--)
			{
			PDACMD =NETSTATE_FUN("@@@@@*VR#");
			if(PDACMD == NETSTATE_VR)break;;
			}
		}
//	memcpy(data,CarBuffer+4,20);
//	twoasic_to_oenhex(data,10);
	print_XYstr_16_16(4,1,"3GV:"); 
	if(SYS_MS.G3S == ON)
		{
		RxBuffer[16]=0;
		LCD_Sring1(RxBuffer+4);	
		}
	else
		LCD_Sring1("close");
	
	delay(KEYTIMEOUT_1S); 
	key_flag = 0;
	timeOut = KEYTIMEOUT_1S *4; 		
	while(timeOut--)
		{ 
		if(key_flag)
			break;
		}	
	if(key_flag==0x02)return;	
}


void CRRec_MENU(void)
{
u32 timeOut;
	
	lcd_clear();
	print_XYstr_16_16(1,5,"Clear");				
	print_XYstr_16_16(2,1,"Record of car");
	zimo =1;
	print_XYstr_16_16(4,1,"CL");	
	print_XYstr_16_16(4,14,"CM");	
	zimo =0;
	delay(KEYTIMEOUT_1S); 
	key_flag = 0;
	timeOut = KEYTIMEOUT_1S *4; 		
	while(timeOut--)
		{ 
		if(key_flag)
			break;
		}	
	if(key_flag==0x02)return;

	INI_CARRECORD_ADD();
	lcd_clear_h(4);
	print_XYstr_16_16(4,8,"OK");	
	delay(KEYTIMEOUT_1S); 
}

void CRRom_MENU(void)
{
u8 i,carimgbuf[800];
u32 ssum,timeOut;

	lcd_clear();
	print_XYstr_16_16(1,5,"Clear");				
	print_XYstr_16_16(2,3,"Rom of car");
	zimo =1;
	print_XYstr_16_16(4,1,"CL");	
	print_XYstr_16_16(4,14,"CM");	
	zimo =0;
	delay(KEYTIMEOUT_1S); 
	key_flag = 0;
	timeOut = KEYTIMEOUT_1S *4; 		
	while(timeOut--)
		{ 
		if(key_flag)
			break;
		}	
	if(key_flag==0x02)return;
	
	for(i=0;i<CarNumSetting;i++)
		I2C_ReadS_24C(SYS_CARIMG_ADD+i*40,carimgbuf+i*40,40);
//			I2C_ReadS_24C(SYS_CARIMG_ADD,carimgbuf,800);
	for(ssum=0;ssum<800;)
		{
		for(i=4;i<40;i++)
			carimgbuf[ssum+i]=0;
		ssum += 40;
		}			
//			I2C_WriteS_24C(SYS_CARIMG_ADD,carimgbuf,800);
	for(i=0;i<CarNumSetting;i++)
		I2C_WriteS_24C(SYS_CARIMG_ADD+i*40,carimgbuf+i*40,40);
	lcd_clear_h(4);
	print_XYstr_16_16(4,5,"OK");	
	delay(KEYTIMEOUT_1S); 
}

void Reset_MENU(void)
{
u32 timeOut;

	lcd_clear();
	print_XYstr_16_16(1,6,"Reset");				
	print_XYstr_16_16(2,6,"System");
	zimo =1;
	print_XYstr_16_16(4,1,"CL");	
	print_XYstr_16_16(4,14,"CM");	
	zimo =0;
	delay(KEYTIMEOUT_1S); 
	key_flag = 0;
	timeOut = KEYTIMEOUT_1S *4; 		
	while(timeOut--)
		{ 
		if(key_flag)
			break;
		}	
	if(key_flag==0x02)return;
	GenerateSystemReset();
}
void SetS_MENU(void)
{
u8 mbno[4];
u32 timeOut;

	I2C_ReadS_24C(mibiao_number,mbno,4);//�����
	
	lcd_clear();
	print_XYstr_16_16(1,1,"Machine no.:"); 			
	zimo =1;
	goto_xy(0xA2,5);
	print_num2(mbno[0]); 
	print_num2(mbno[1]); 
	print_num2(mbno[2]); 
	print_num2(mbno[3]); 
	zimo =0;
	
	
	if(mbno[2])//�������
		print_XYstr_16_16(3,3,"Normal meter");		
	else
		print_XYstr_16_16(3,4,"Base meter");

//	zimo =1;
	print_XYstr_16_16(4,6,"Change");
//	zimo =0;
	
	
//	I2C_ReadS_24C(MBMODE_ADD,&base,1);
//	lcd_clear();
//	if(base)//base
//		{
//		print_XYstr_16_16(1,3,"Base meter");
//		zimo =1;
//		print_XYstr_16_16(2,1,"Change to normal");
//		zimo =0;
//		}
//	else
//		{
//		print_XYstr_16_16(1,2,"Normal meter"); 				
//		zimo =1;
//		print_XYstr_16_16(2,1,"Change to base");
//		zimo =0;
//		}
	
	zimo =1;
	print_XYstr_16_16(4,1,"CL");	
	print_XYstr_16_16(4,14,"CM");	
	zimo =0;
	delay(KEYTIMEOUT_1S); 
	key_flag = 0;
	timeOut = KEYTIMEOUT_1S *4; 		
	while(timeOut--)
		{ 
		if(key_flag)
			break;
		}	
	if(key_flag==0x02)return;
	
	key_flag = 0;
	UART4_IRQn_CTL(OFF);
	ir_comm(OFF);
	UART4_IRQn_CTL(ON);


//	base = !base;
//	I2C_WriteS_24C(MBMODE_ADD,&base,1);
//	
//	lcd_clear_h(4);
//	print_XYstr_16_16(4,5,"Set OK");	
//	delay(KEYTIMEOUT_1S);
}

//��������� 2015-08-23
void CR_SYSList()//
{
	INI_SYSLIST();
	lcd_clear();
	print_XYstr_16_16(3,1,"List Clear OK!");
	delay(KEYTIMEOUT_1S*3);	
}

//��ѯ���������� 2015-08-04
void IQ_SYSList()//
{	
	u8	buf[32],buf1[32],i;
	u32 opdata,orgadd,displist;
	u32 timeOut;
	
	orgadd = CARD_BIKE_BLACKLISTALL_VERSION;	//����-�汾
	I2C_ReadS_24C(orgadd,buf,16);	
	orgadd = CARD_BIKE_BLACKLISTALL_NUMADD; 	//����-����
	I2C_ReadS_24C(orgadd,buf1,24);
	while(1)
	{
	for(i=0;i<8;i++)
		{
		key_flag = 0;//
		switch(i)
			{
			case 0: lcd_clear();print_XYstr_16_16(i+1,1,"B1V");break;
			case 1: print_XYstr_16_16(i+1,1,"B2V");break;
			case 2: print_XYstr_16_16(i+1,1,"B3V");break;
			case 3: print_XYstr_16_16(i+1,1,"B4V");break;
			case 4: lcd_clear();print_XYstr_16_16(i-3,1,"B5V");break;
			case 5: print_XYstr_16_16(i-3,1,"B6V");break;
			case 6: print_XYstr_16_16(i-3,1,"B7V");break;
			case 7: print_XYstr_16_16(i-3,1,"B8V");break;			
			}
		print_num2(buf[i*2]);		
		print_num2(buf[i*2+1]);		
		opdata = hcl(buf1+i*3,3);	
		LCD_Sring1("@");
		displist = HEX_to_BCD(opdata/10000);
		print_num2(displist); 	
		displist = HEX_to_BCD((opdata%10000)/100);
		print_num2(displist); 	
		displist = HEX_to_BCD((opdata%10000)%100);
		print_num2(displist); 	
		
//		print_num2(opdata>>16); 		
//		print_num2(opdata>>8); 		
//		print_num2(opdata); 
		if((i==3)||(i==7))
			{
			timeOut = KEYTIMEOUT_1S *3;  
			while(timeOut--)
				{ 
				if(key_flag)
					{
					if(key_flag==0x03)return;//ֱ���˳�
					else break;
					}
				if(timeOut==1)return;
				}				 
			}
		}		
	}	
}

//2015-08-24  andyluo  ���������������ر�
void CPCLOCK_Set()
{
u8 buffer[2];
u32 timeOut;

	while(1)
		{
		lcd_clear();
		print_XYstr_16_16(1,5,"LOCK");
		I2C_ReadS_24C(SYS_LOCKCPC,buffer,1);//��������� 1-�� 0-��
		zimo = 1;
		if(buffer[0])
			print_XYstr_16_16(2,5,"OPEN");
		else
			print_XYstr_16_16(2,5,"CLOSE");
		zimo = 0;
		print_XYstr_16_16(4,1,"L-CH   R-ET");
		
		key_flag = 0;
		timeOut = KEYTIMEOUT_1S *3;  
		while(timeOut--)
			{ 
			if(key_flag)
				{
				if(key_flag==0x03)return;//ֱ���˳�
				else break;
				}
			if(timeOut==1)return;
			}				 
		if(buffer[0])
			{
			buffer[0] = 0;
			print_XYstr_16_16(3,5,"CLOSE OK");
			}
		else
			{
			buffer[0] = 1;
			print_XYstr_16_16(3,5,"OPEN OK");
			}
		I2C_WriteS_24C(SYS_LOCKCPC,buffer,1);//��������� 1-�� 0-��
		}
}



//2015-08-08  andyluo
void RTC_UPDATE_PRO()
{
u8 buffer[2];
u32 timeOut;

	while(1)
		{
		lcd_clear();
		print_XYstr_16_16(1,5,"RTC");
		I2C_ReadS_24C(SYS_RTC,buffer,1);//ʱ��ʵʱ���¿��� 1-�� 0-��
		zimo = 1;
		if(buffer[0])
			print_XYstr_16_16(2,5,"OPEN");
		else
			print_XYstr_16_16(2,5,"CLOSE");
		zimo = 0;
		print_XYstr_16_16(4,1,"L-CH   R-ET");
		
		key_flag = 0;
		timeOut = KEYTIMEOUT_1S *3;  
		while(timeOut--)
			{ 
			if(key_flag)
				{
				if(key_flag==0x03)return;//ֱ���˳�
				else break;
				}
			if(timeOut==1)return;
			}				 
		if(buffer[0])
			{
			buffer[0] = 0;
			print_XYstr_16_16(3,5,"CLOSE OK");
			}
		else
			{
			buffer[0] = 1;
			print_XYstr_16_16(3,5,"OPEN OK");
			}
		I2C_WriteS_24C(SYS_RTC,buffer,1);//ʱ��ʵʱ���¿���
		}
}



//ϵͳ���Բ˵�
void Car_IMGIQ(void)
{
u8 keytp;
u32 timeOut;
//char *str1 ="1.CarIQ",*str2 ="2.RecIQ";
//char *str3 ="3.RomIQ",*str4 ="4.TestC";
//char *str5 ="5.SetC",*str6 ="6.SysIQ";
//char *str7 ="7.CRRec",*str8 ="8.CRRom";
//char *str9 ="9.Reset",*str10 ="10.SetS";
//char *str11 ="11.RES1",*str12 ="12.RES1";
//char *str13 ="13.RES1",*str14 ="14.RES1";

//disp_systest(1);	

OPEN_EXTI9_5_IRQ();
OPEN_EXTI15_10_IRQ();
beep(KEYTIMEOUT_1S/10);
beep(KEYTIMEOUT_1S/10);

while(1)
	{
	disp_systest(1);	
	delay(KEYTIMEOUT_1S /10 ); 
	key_flag = 0;
	keytp = 1;
    timeOut = KEYTIMEOUT_1S *4;   
    while(timeOut--)
		{ 
		if(key_flag)
			{
			if(key_flag==0x01)	break;//ֱ���˳�
			else if(key_flag==0x04)
				{
				if(keytp==1)keytp=18;
//				if(keytp==1)keytp=12;
				keytp--;
				disp_systest(keytp);
				timeOut = KEYTIMEOUT_1S *4;   
				key_flag = 0;
				}
			else if(key_flag==0x02)
				{
				if(keytp>17)keytp=0;
//				if(keytp>11)keytp=0;
				keytp++;
				disp_systest(keytp);
				timeOut = KEYTIMEOUT_1S *4;   
				key_flag = 0;
				}
			 else
			 	{
			 	keytp += 100;
				key_flag = 0;
				break;
			 	}
			}
		}
	exit_cariq = 0;
	//disp_systest(keytp);
	if(keytp<100)return;//��ʱ����
//	keytp -= 100;
	switch(keytp-100)
		{
		case 1://1����������ѯ--����+����---��λ״̬ˢ��״̬
#ifdef testing
			lcd_clear();print_XYstr_16_16(1,1,"testing...");
			CPC_Card_Test();
//			DownloadTimeAndFree();
//			IQ_SYSList();//��ʽ���� 2015-08-04
//			Update_SYSList(2);//��ʽ���� 2015-08-03
#endif
			CarIQ_MENU();
			break;	
		case 2://2����¼��ѯ--��ַ δ������
			RecIQ_MENU();
			break;
			
		case 3://3���ڴ���Ϣ--�������洢��Ϣ
			RomIQ_MENU();
			break;
			
		case 4://4�����Գ�����--����������		
			TestC_MENU();
			break;
			
		case 5://5�����ó�����--������Ҫ����
			SetC_MENU();
			break;
			
		case 6://6��ϵͳ��Ϣ--�����Ϣ��ѯ	
			SysIQ_MENU();
			break;
		
		case 7://7�������¼--��ʼ����¼��ַ
			CRRec_MENU();		
			break;

		case 8://8������ڴ���Ϣ--����洢��Ϣ		
			CRRom_MENU();
			break;
			
		case 9://9��ϵͳ����--����ϵͳ
			Reset_MENU();
			break;

		case 10://10���������ϵͳ--�����м�/���
			SetS_MENU();	
			break;
			
		case 11://11.��������
			Update_SYSList(2);
			break;

		case 12://12.��ѯ����
			IQ_SYSList();//ListIQ_PC_P1
			break;
			
		case 13://13.�Զ������������
			DISABLE_EXTI15_10_IRQ();	  
			DISABLE_EXTI9_5_IRQ();	
			lcd_clear();
			print_XYstr_16_16(1,1,"Updateing...");
			IAP_UpData(1);					 
//			IAP_UpData(2);	//�ϵ�����			 
			OPEN_EXTI9_5_IRQ(); 																		 
			OPEN_EXTI15_10_IRQ(); 
			break;	
			
		case 14://RTCʵʱ����- ������ر�
			RTC_UPDATE_PRO();						
			break;			
		case 15:
			CPC_Card_Test();
			break;			
		case 16:
			NET_Card_IQ();
			break;			
		case 17://���������
			CR_SYSList();
			break;	
		case 18:
			CPCLOCK_Set();
			break;			
		case 19:
			MBtoBase_Card();
			break;			
		default:
			break;			
		}	
	if(exit_cariq)return;
	}
}





