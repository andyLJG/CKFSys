void Open_Coin_Power(void);
void Close_Coin_Power(void);
void int_coin( );
void Open_Coin_Com1(void);
unsigned char int_coin_check( );
void do_coin0(void);
void do_coin(void);
#define uchar unsigned char 
#define uint unsigned int 

#define	host_addr	0x01 
#define slave_addr	0x02
/////PE11--PE15----PG11--PG15
#define coinpower_1	        		GPIO_SetBits(GPIOG, GPIO_Pin_14)
#define coinpower_0	        		GPIO_ResetBits(GPIOG, GPIO_Pin_14)
//#define Retcoin_OPEN	        		GPIO_SetBits(GPIOC, GPIO_Pin_14)
//#define Retcoin_CLOSE	        		GPIO_ResetBits(GPIOC, GPIO_Pin_14)
//#define Eatcoin_OPEN	        		GPIO_SetBits(GPIOC, GPIO_Pin_15)
//#define Eatcoin_CLOSE	       	 		GPIO_ResetBits(GPIOC, GPIO_Pin_15)
/*
#define PrintandCoinout_LED_CLOSE 	GPIO_SetBits(GPIOD, GPIO_Pin_1)
#define PrintandCoinout_LED_OPEN	GPIO_ResetBits(GPIOD, GPIO_Pin_1)
#define SYSERROR_LED_CLOSE	        GPIO_SetBits(GPIOD, GPIO_Pin_0)
#define SYSERROR_LED_OPEN	        	GPIO_ResetBits(GPIOD, GPIO_Pin_0)
*/
//////PD0--PD1------PF6--PF7
#define PrintandCoinout_LED_CLOSE 	GPIO_SetBits(GPIOF, GPIO_Pin_6)
#define PrintandCoinout_LED_OPEN	GPIO_ResetBits(GPIOF, GPIO_Pin_6)
#define SYSERROR_LED_CLOSE	        GPIO_SetBits(GPIOF, GPIO_Pin_7)
#define SYSERROR_LED_OPEN	        GPIO_ResetBits(GPIOF, GPIO_Pin_7)	

#define LED2_CLOSE 	                GPIO_SetBits(GPIOC, GPIO_Pin_4)
#define LED2_OPEN	                GPIO_ResetBits(GPIOC, GPIO_Pin_4)
#define LED1_CLOSE	                GPIO_SetBits(GPIOD, GPIO_Pin_3)
#define LED1_OPEN	        	GPIO_ResetBits(GPIOD, GPIO_Pin_3)
/*
��Ӧ��ԭ��ͼ�ı�
///////////////////////////////////////////////////////////////////////////////////////
LED3              LED1             LED4                     LED2         VCC
////////////////////////////////////////////////////////////////////////////////////////
ԭ���ı�׼:
////////////////////////////////////////////////////////////////////////////////////////
LED4              LED3             LED2                     LED1         VCC
////////////////////////////////////////////////////////////////////////////////////////
ԭ��ͼ�����ơ�---��Ӧ��PIN��--�����ϵĶ���
LED4(PC4)=LED2    LED3(PD3)=LED1   LED2(PF7)=SYSERROR_LED   LED1(PF6)=PrintandCoinout_LED
////////////////////////////////////////////////////////////////////////////////////////
���ĺ�Ķ�Ӧ
LED3(PC4��λ)=LED1    LED1(PD3)=PrintandCoinout_LED      LED4(PF7)=LED2  LED2(PF6)=SYSERROR_LED
//////////////////////////////////////////////////////////////////////////////////////////////
#define PrintandCoinout_LED_CLOSE 	GPIO_SetBits(GPIOD, GPIO_Pin_3)
#define PrintandCoinout_LED_OPEN	GPIO_ResetBits(GPIOD, GPIO_Pin_3)
#define SYSERROR_LED_CLOSE	        GPIO_SetBits(GPIOF, GPIO_Pin_6)
#define SYSERROR_LED_OPEN	        GPIO_ResetBits(GPIOF, GPIO_Pin_6)	
#define LED2_CLOSE 	GPIO_SetBits(GPIOF, GPIO_Pin_7)
#define LED2_OPEN	GPIO_ResetBits(GPIOF, GPIO_Pin_7)
#define LED1_CLOSE	        GPIO_SetBits(GPIOC, GPIO_Pin_4)
#define LED1_OPEN	        	GPIO_ResetBits(GPIOC, GPIO_Pin_4)
///////////////////////////////////////////////////////////////////////////////////////////////
*/
uchar cctalk_reset();
uchar get_coin_value(void);
void tx_cctalk(uchar header,uchar len);
uchar rx_cctalk(void);
