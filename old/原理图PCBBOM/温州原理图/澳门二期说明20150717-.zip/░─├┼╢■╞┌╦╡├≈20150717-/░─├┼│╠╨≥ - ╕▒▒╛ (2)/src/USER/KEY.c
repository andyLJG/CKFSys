#include "stm32f10x_it.h"
#include "delay_systick.h"
#include "touch_key.h"
#include "LM240128C.h"  //����
#include "ADC.h"  //
#include "I2C_Driver.h"
#include "mifare.h"
#include "usart.h"
#include "save_record.h"
#include "rate.h"
#include "main.h"
#include "MemoryAssign.h"


