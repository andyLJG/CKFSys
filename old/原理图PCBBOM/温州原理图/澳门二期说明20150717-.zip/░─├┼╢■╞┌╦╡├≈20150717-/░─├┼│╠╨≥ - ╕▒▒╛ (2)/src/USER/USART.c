#include "stm32f10x.h"
#include "USART.h"


/*------------���ڣ����жϣ��ӷ�����---------
ע�⣺UART4 UART5 ��ͬ��USART1\2\3��д
--------------huangfeng-------------------*/ 
///*����*/
//unsigned char USART_ReceiveChar(USART_TypeDef* USARTx)
//{
//  while(USART_GetFlagStatus(USARTx, USART_FLAG_RXNE) == RESET);
//  return(USART_ReceiveData(USARTx));
//}

/*���͵����ֽ�*/
void USART_Putc(USART_TypeDef* USARTx,u8 c)
{
    //�����־λ�������1λ���ݻᶪʧ	huangfeng 
	USART_ClearFlag(USARTx,USART_FLAG_TC);
	
	USART_SendData(USARTx, c);
    while(USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET );
}
/*�����ַ���*/
void USART_Puts(USART_TypeDef* USARTx,u8 *s)
{  
  //�����־λ�������1λ���ݻᶪʧ	huangfeng 
  USART_ClearFlag(USARTx,USART_FLAG_TC);
   
  while(*s!='\0')  // ÿ���ַ�����β ������  \0 ��β��
  {
    USART_SendData(USARTx,*s);        //ͨ���⺯��  ��������
//    while(USART_GetFlagStatus(USARTx, USART_FLAG_TC)==RESET);  
    while(USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET );    
    s++;
  }
}

/*����n���ֽ�*/
void USART_SendPacket(USART_TypeDef* USARTx, uint16_t Data,  u8 *Senddata)
{
	u16 i;
	//�����־λ�������1λ���ݻᶪʧhuangfeng 
	USART_ClearFlag(USARTx,USART_FLAG_TC);
	
	for(i=0;i<Data;i++)
	{
//		if(Senddata[i] == '\0')	 break;		
          
		USART_SendData(USARTx,Senddata[i]); 
//		while(USART_GetFlagStatus(USARTx, USART_FLAG_TC)==RESET); 
                while(USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET ); 
                
        //��Ҫ��һ�� �жϷ��������ֻ�ܷ����������ַ�����Ҫ���ж��Ƿ�����ɡ�	huangfeng 
	}	
}
void USART_SendPacket_new(USART_TypeDef* USARTx, uint16_t Data,  u8 *Senddata)
{
	u16 i;
	//�����־λ�������1λ���ݻᶪʧhuangfeng 
	USART_ClearFlag(USARTx,USART_FLAG_TC);
	
	for(i=0;i<Data;i++)
	{
		if(Senddata[i] == '\0')	 break;		
          
		USART_SendData(USARTx,Senddata[i]); 
//		while(USART_GetFlagStatus(USARTx, USART_FLAG_TC)==RESET); 
                while(USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET ); 
                
        //��Ҫ��һ�� �жϷ��������ֻ�ܷ����������ַ�����Ҫ���ж��Ƿ�����ɡ�	huangfeng 
	}	
}

/*�ϲ�*/
 unsigned long hcl(unsigned char *bufa,unsigned char b)
{
  unsigned long  FD;		//ע�� long
  unsigned char  i;
  FD=bufa[0];
  for(i=1;i<b;i++)     
  {
    FD=FD<<8;   
     FD=FD+bufa[i];   
  }                 
     return FD; 
 } 
 /*���long FD*/ 
void fll(unsigned long FD,unsigned char *bufa,unsigned char b)
{   
	unsigned char  i; 	
     for(i=0;i<b;i++)   
     	{bufa[b-1-i]=FD>>(i*8); }
}
void fll_BCD(unsigned long FD,unsigned char *bufa,unsigned char b)
{   
	unsigned char  i; 
	
     for(i=0;i<b;i++)   
     	{
        //  bufa[b-1-i]=FD>>(i*8); 
          bufa[b-1-i]=hex_to_bcd(FD%100); 

          FD =FD/100; 
        }
     
     
     
}




void AscToBcd(unsigned char *bufa0,unsigned long len,unsigned char *bufa)
{   

	u8	mid=0,ch=0;
	int    i=0,j=0,asc=0;
     
     	for(i=1; i<len+1; i++)
	{
		if( bufa0[asc]>='a' )
		{
			ch=((bufa0[asc]-'a')+10);
		}
		else if( bufa0[asc]>='A')
		{
			ch=((bufa0[asc]-'A')+10);
		}
		else if( bufa0[asc] >='0' )
		{
			ch=bufa0[asc]-'0';
		}
		else
			ch = 0;
		if( i%2 == 1 )
		{
			ch=ch<<4;
			mid = ch;
		}
		else
		{			
			bufa[j]=mid+ch;			
			j++;
		}	
		asc++;
	}
  
     
     
}

/*��������ڣ�������BCD�룩--------*/
unsigned char mathweek(unsigned char nian,unsigned char yue, unsigned char ri)
{
  unsigned int  mathday;
  unsigned char loop6,ww;
  ww=((nian>>4)&0x0f)*10;
  nian=ww+(nian&0x0f);
  ww=((yue>>4)&0x0f)*10;
  yue=ww+(yue&0x0f);
  ww=((ri>>4)&0x0f)*10;
  ri=ww+(ri&0x0f);
  mathday=0;
  for(loop6=6;loop6<nian;loop6++)
  {
	if(loop6%4==0)
	{
	 mathday=mathday+366;
	}
	else
	{
	 mathday=mathday+365;
	}
  }
  for(loop6=1;loop6<yue;loop6++)
  {
      if(loop6==2)
	  {
	   if(nian%4==0)
		{
		 mathday=mathday+29;
		}
		else
		{
		 mathday=mathday+28;
		}
	  }
	  else
	  {
	    if((loop6==4)||(loop6==6)||(loop6==9)||(loop6==11))
		{
		  mathday=mathday+30;
		}
		else
		{
		 mathday=mathday+31;
		}
	  }    
  }
  mathday=mathday+(ri-1);
  ww=mathday%7;
  return ww; 
 }

unsigned char bcd_to_hex(unsigned char a)//0x15--0x21
{
	a = ((a&0xf0)>>4)*10+(a&0x0f);
	return a;
}
unsigned char hex_to_bcd(unsigned char a)//0x15--0x21
{
	a= ((a/10)<<4)+(a%10);
	return a;
}


 /*16����תASCII*/
 unsigned char hex_to_asic(unsigned char a)
{
	if(a <= 9)
	{
		a = a + 0x30;
	}
	else 
	{
		a = a + 0x37;
	}
	return a;
}


////***************************************ASCII ת��Ϊ��BCD********************************************************/
unsigned char asic_to_hex(unsigned char rr)
{
  unsigned char c1;

  if(rr<0x3A)
  	c1=rr-0x30;
  else
  	c1=rr-0x37;
  return c1;
}

//andyluo
unsigned char twoasic_to_oenhex(unsigned char *recvgsmproc,u8 ASCII)
{//2///2=1+2=1   1+1=1  36 41 36 44 ==14
  unsigned short i,j;
  unsigned char hex,hex1,hex2,hex3;
  
  //hex3 = 4;
  hex3 = 2;
  j = 0;
  for(i=0;;i++){
  	
    j =i*hex3;	
    if(recvgsmproc[j+1] == '*'){
  		
      recvgsmproc[i+1] = '*';		
      break; 		
    }
  	
    hex = asic_to_hex(recvgsmproc[j+1]);
    hex1 = asic_to_hex(recvgsmproc[j+2]);
    hex = hex<<4;
    hex = hex+hex1;
    hex2 = hex - '9';//31		
	
    if(hex3 == 2){
		
      recvgsmproc[i+1] = hex2;	
      continue;
		
    }
    if(ASCII||(hex2>'F')){

      recvgsmproc[i+1] = hex2;	
      hex3 = 2;	
      j = j/2;
      continue;
		
    }
  	
    hex = asic_to_hex(recvgsmproc[j+3]);
    hex1 = asic_to_hex(recvgsmproc[j+4]);
    hex = hex<<4;
    hex = hex+hex1;
    hex1 = hex-'9';//34	

    hex = asic_to_hex(hex2);
    hex2 = asic_to_hex(hex1);
    hex = hex<<4;
    hex = hex+hex2;
    recvgsmproc[i+1] = hex;		
	
  }
	
  return 1;
}
