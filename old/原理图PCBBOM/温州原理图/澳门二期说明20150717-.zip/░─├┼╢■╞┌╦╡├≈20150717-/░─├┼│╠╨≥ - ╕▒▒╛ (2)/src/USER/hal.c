/***************************************************
**HAL.c
**��Ҫ����оƬӲ�����ڲ���Χ���ⲿ��Χ�ĳ�ʼ��������INIT����
**��MAIN�е��ã�ʹMAIN�����о�����Ӳ�����޹�
***************************************************/
#include "hal.h" 
#include "LM240128C.h"  //����
#include "spi_flash.h" 
#include "stm32f10x_iwdg.h"
#include "GPIO.h"
#include "ADC.h"
#include "touch_key.h"
#include "I2C_Driver.h"	
#include "stm32f10x.h"
#include "fsmc_sram.h"
#include "delay_systick.h"
#include "contact_card.h"  //�ܲ�ͨ


/*ʱ�ӳ�ʼ������*/
void RCC_Configuration(void)
{	 
  RCC_ClocksTypeDef RCC_ClockFreq;
  //ʱ�ӳ�ʼ������
  SystemInit();//Դ��system_stm32f10x.c�ļ�,ֻ��Ҫ���ô˺���,������RCC������.�����뿴2_RCC
  
  /**************************************************
  ��ȡRCC����Ϣ,������
  ��ο�RCC_ClocksTypeDef�ṹ�������,��ʱ��������ɺ�,
  ���������ֵ��ֱ�ӷ�ӳ�������������ֵ�����Ƶ��
  ***************************************************/
  RCC_GetClocksFreq(&RCC_ClockFreq);
  
  /* ������ÿ�ʹ�ⲿ����ͣ���ʱ��,����һ��NMI�ж�,����Ҫ�õĿ����ε�*/
  //RCC_ClockSecuritySystemCmd(ENABLE);
}


/*���Ź���ʼ������(������256*���ֵ0xfff)= ���26��-----huangfeng 2013-3-11*/
void IWDG_Configuration(void)
{
  /* д��0x5555,�������������Ĵ���д�빦�� */
  IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
  
  /* ����ʱ�ӷ�Ƶ,40K/256=156HZ(6.4ms)*/
  IWDG_SetPrescaler(IWDG_Prescaler_256);
  
  /* ι��ʱ�� 5s/6.4MS=781 .ע�ⲻ�ܴ���0xfff*/	  
  IWDG_SetReload(4000);	 //6.4*4000=25s				 // (5s֮��һ��Ҫ�ֶ�ι������λ)
  
  /* ι��*/
  IWDG_ReloadCounter();
  
  //ʹ�ܹ����������Ź�,�Զ��ͻ�ʹ���ڲ���40K 
  IWDG_Enable();		//���εĻ�  �رտ��Ź�
}


/*******************************
**������:ChipHalInit()
**����:Ƭ��Ӳ����ʼ��
*******************************/
void  ChipHalInit(void)
{
  //��ʼ��ʱ��Դ
  RCC_Configuration();   
  //��ʼ��GPIO
  GPIO_Configuration();  
  //��ʼ��I2C
  I2C_GPIOB_Config();
  //�����ܲ�ͨ	
  CCard_GPIOConfig(); 
  //LCD
  LCD_pin_init();
//  
//  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x10000);  
//  __enable_irq();//�������ж�
  
  //��ʱ������ʼ��
  Delay_Init(72);
  //Flash��ʼ��
  SPI_FLASH_Init();	
  //ADC��ʼ��    
  //ADC2_Configuration();	 //ADC2        
  //��ʼ���������Ź�
  IWDG_Configuration(); 
  
}
		
/*********************************
**������:ChipOutHalInit()
**����:Ƭ��Ӳ����ʼ��
*********************************/
void  ChipOutHalInit(void)
{
  LCD_INIT();		   //С����ʾ�� ���� 	
  touchkeypin_init();	 //���Ű���	
  Uart1_Configuration(BaudRate_115200);        //3Gͨ��
  Uart2_Configuration(BaudRate_9600);	   //
 // Uart3_Configuration(BaudRate_19200);	   //������ 38400
  Uart3_Configuration(BaudRate_38400);	
  Uart4_Configuration(BaudRate_19200);	   //����ͨ��
  Uart5_Configuration(BaudRate_19200);	   //Ӳ�һ�
  init_rx8025sa();	    //ʱ��оƬ  huangfeng
  //	FSMC_SRAM_Init();       //	
  //�ж�
  NVIC_Configuration();         //NVICǶ��ʽ�жϹ���ϵͳ�ĳ�ʼ��open interrupt
  IWDG_ReloadCounter();	//ι��
}

void  ChipOutHalInitsleep(void)
{
  //  LCD_INIT();		   //С����ʾ�� ���� 	
  Uart1_Configuration(BaudRate_115200);        //3Gͨ��
  //  Uart2_Configuration(BaudRate_9600);	   //
  //Uart3_Configuration(BaudRate_19200);	   //������ 38400
  Uart3_Configuration(BaudRate_38400);	
  Uart4_Configuration(BaudRate_19200);	   //����ͨ��
  Uart5_Configuration(BaudRate_19200);	   //Ӳ�һ�   
  FSMC_SRAM_Init();   //���ź�����û����    
}


void Uart1_Configuration(u32 BaudRate)
{

USART_InitTypeDef USART_InitStructure;
  
/* USART1 configuration ------------------------------------------------------*/
  /* USART1 configured as follow:
        - BaudRate = 19200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
  */
  USART_DeInit(USART1);

  USART_InitStructure.USART_BaudRate = BaudRate;   //19200;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  /* Configure USART1 */
  USART_Init(USART1, &USART_InitStructure);
  
  /* Enable USART1 Receive and Transmit interrupts */
  USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

  /* Enable the USART1 */
  USART_Cmd(USART1, ENABLE);

}

void Uart2_Configuration(u32 BaudRate)
{
  USART_InitTypeDef USART_InitStructure;
  
/* USART2 configuration ------------------------------------------------------*/
  /* USART2 configured as follow:
        - BaudRate = 115200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
  */
  USART_DeInit(USART2);

  USART_InitStructure.USART_BaudRate = BaudRate;  //19200;//38400;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  /* Configure USART2 */
  USART_Init(USART2, &USART_InitStructure);
  
  /* Enable USART2 Receive and Transmit interrupts */
  USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

  /* Enable the USART2 */
  USART_Cmd(USART2, ENABLE);

}

void Uart3_Configuration(u32 BaudRate)
{
  USART_InitTypeDef USART_InitStructure;
  
/* USART3 configuration ------------------------------------------------------*/
  /* USART3 configured as follow:
        - BaudRate = 19200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
  */
  USART_DeInit(USART3);

  USART_InitStructure.USART_BaudRate = BaudRate;//38400;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  /* Configure USART3 */
  USART_Init(USART3, &USART_InitStructure);
  
  /* Enable USART3 Receive and Transmit interrupts */
  USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);

  /* Enable the USART3 */
  USART_Cmd(USART3, ENABLE);

}


void Uart4_Configuration(u32 BaudRate)
{
  USART_InitTypeDef USART_InitStructure;
  
/* USART4 configuration ------------------------------------------------------*/
  /* USART4 configured as follow:
        - BaudRate = BaudRate 
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
  */
  USART_DeInit(UART4);

  USART_InitStructure.USART_BaudRate = BaudRate;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  /* Configure USART4 */
  USART_Init(UART4, &USART_InitStructure);
  
  /* Enable USART4 Receive and Transmit interrupts */
  USART_ITConfig(UART4, USART_IT_RXNE, DISABLE);			 //�����ж�  ENABLE
  //USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);	
  /* Enable the USART4 */
  USART_Cmd(UART4, ENABLE);

}

void Uart5_Configuration(u32 BaudRate)
{

USART_InitTypeDef USART_InitStructure;
  
/* USART5 configuration ------------------------------------------------------*/
  /* USART5 configured as follow:
        - BaudRate = 19200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
  */
  USART_DeInit(UART5);

  USART_InitStructure.USART_BaudRate = BaudRate;//19200;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  /* Configure USART5 */
  USART_Init(UART5, &USART_InitStructure);
  
  /* Enable USART5 Receive and Transmit interrupts */
  USART_ITConfig(UART5, USART_IT_RXNE, ENABLE);
 /* Enable the USART5 */
  USART_Cmd(UART5, ENABLE);

}

/*�رմ��ڿ���*/
void AllUart_Close(void)
{
  /* DISABLE the USART5 */
//  USART_ITConfig(UART5, USART_IT_RXNE, DISABLE);  //Ӳ�һ�����
//  USART_Cmd(UART5, DISABLE);
  /* DISABLE the USART4 */
  USART_ITConfig(UART4, USART_IT_RXNE, DISABLE); 
  USART_Cmd(UART4, DISABLE); 
  /* DISABLE the USART3 */
  USART_ITConfig(USART3, USART_IT_RXNE, DISABLE); 
  USART_Cmd(USART3, DISABLE); 
  /* DISABLE the USART2 */
  USART_ITConfig(USART2, USART_IT_RXNE, DISABLE); 
  USART_Cmd(USART2, DISABLE);
  /* DISABLE the USART1 */
  USART_ITConfig(USART1, USART_IT_RXNE, DISABLE);  
  USART_Cmd(USART1, DISABLE); 
}



/*�ж����ȼ�����*/
void NVIC_Configuration(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;
  /* Configure the NVIC Preemption Priority Bits */  
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
  
  
//  /* Enable the USART1 Interrupt 3G*/
  NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;	   //DISABLE
  NVIC_Init(&NVIC_InitStructure);
  
  /* Enable the USART2 Interrupt Ӳ�һ� */
//  NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
//  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
//  NVIC_InitStructure.NVIC_IRQChannelCmd =ENABLE;
//  NVIC_Init(&NVIC_InitStructure);
  
  /* Enable the USART3 Interrupt ������*/	 
  NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  /* Enable the USART4 Interrupt POS��2.4G*/
 /* NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
 // NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;	
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;	*/
  //
  NVIC_Init(&NVIC_InitStructure);

//  /* Enable the USART5 Interrupt Ӳ�һ�*/
  NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  /* EXTI10-15*/
  NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
  NVIC_Init(&NVIC_InitStructure);

/* EXTI5-9 */
  NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;	//0	
  NVIC_InitStructure.NVIC_IRQChannelCmd =ENABLE;
  NVIC_Init(&NVIC_InitStructure);	
  
  
  NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	//0	
  NVIC_InitStructure.NVIC_IRQChannelCmd =ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
//////////////////////////////////////////////////////////////
    /* 2 bits for Preemption Priority and 2 bits for Sub Priority 
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
  NVIC_InitStructure.NVIC_IRQChannel = WWDG_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd =DISABLE; // ENABLE;
  NVIC_Init(&NVIC_InitStructure); 	*/	   //huangfeng 
}								
