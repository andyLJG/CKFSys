#include "stm32f10x_conf.h"
#include "hal.h" 
#include "St_wcdma.h"
#include "touch_key.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_it.h"
#include "misc.h"
#include "math.h"
#include "main.h"
#include "MemoryAssign.h"  
#include "USART.h"
#include "string.h" 
#include "spi_flash.h"
#include "I2C_Driver.h"
#include "delay_systick.h"
#include "save_record.h"
#include "mifare.h"
#include <string.h>
#include <rate.h>
#include "save_record.h"
#include "ADC.h"
#include "MU509.h"
#include "blacklist.h"
#include "LM240128C.h" 


//���������Ϣ�ṹ�����
NETInformation  NET; 
Send_Parameter G3; 

/*-----------3G���Ͷ��ǰ����ַ���ʽ���͵�--------------start-------------------*/

/*3Gͨ�Žӿڵ�һ�η�������100���ַ�*/
void send_string_3G(u8 *ptr)
{  
  USART_Puts(USART1,ptr);   
}
/*3G���͸�λ����a����0~f��*/
void USART_SendDataPacket(USART_TypeDef* USARTx, uint16_t Data_Len, u8 *Send_Data)
{
	u16 i;
	for(i = 0;i < Data_Len;i++)
		{
	    if((Send_Data[i] == '\0')&&(Data_Len==65535))
			break;
	    USART_SendData(USARTx,Send_Data[i]);   
		
        }
	return;
}
void send_onedigit_3G(unsigned char a)
{
  unsigned char ptr[2];
  
  ptr[0] = hex_to_asic(a);
  ptr[1] = '\0';
  
  send_string_3G(ptr);
}

/*3G������λ��0x00~0xff*/
void send_twodigit_3G(unsigned char a)
{
  unsigned char ptr[3];
  
  ptr[0] = hex_to_asic((a>>4)&0x0f);
  ptr[1] = hex_to_asic(a&0x0f);
  ptr[2] = '\0';  
  send_string_3G(ptr);
}
/*-----------3G���Ͷ��ǰ����ַ���ʽ���͵�--------------end-------------------*/

/*------------�߱����߹��ܵ�3G��----------------------
����:    void close_3G(u8 type)
����:    ��3G��
input:   ��ͬ��ʽ
output:  ��        
-------------------------------------------------------*/
void close_3G(u8 type)
{
  // �ػ����� *OFF# 
  if(type==1)
  {

    ;
  }
  else if(type==2)
  {

    //delayms_keybreak(1000);
  }
  else
  {
   // send_string_3G("*OFF#"); //��������������
   // delayms_keybreak(4000);

  }
}


/*���IP��ַ�Ͷ˿ں�,�û���������*/
void Read_IP(void)
{	    
  u8 i,j; 	
  u8 hundred;
  u8 ten;
  u8 ge; 
  
  u8 buffer[32]; 
  
  //---------��IP��ַ�Ͷ˿�---------start---------------
  I2C_ReadS_24C(IPAddr,buffer,6);//
  i=0;
  //IP��ַ��� 
  for(j=0;j<4;j++)
  {
    hundred = buffer[j]/100;
    ten = buffer[j]/10%10;
    ge = buffer[j]%10;
    if(hundred > 0)
    {
      NET.Address[i++] = hex_to_asic(hundred);
      NET.Address[i++] = hex_to_asic(ten);
      NET.Address[i++] = hex_to_asic(ge);
    }
    else if(ten > 0)
    {
      NET.Address[i++] = hex_to_asic(ten);	
      NET.Address[i++] = hex_to_asic(ge);
    }
    else
    {NET.Address[i++] = hex_to_asic(ge);}
    NET.Address[i++] = 46;  //. 
  }
  NET.Address[--i] = '\0';	   
  
  //�˿ں����    
  i = 0;	    
  NET.Port[i++] = hex_to_asic((buffer[4]>>4)&0x0f);
  NET.Port[i++] = hex_to_asic(buffer[4]&0x0f);
  NET.Port[i++] = hex_to_asic((buffer[5]>>4)&0x0f);
  NET.Port[i++] = hex_to_asic(buffer[5]&0x0f);     
  NET.Port[i] = '\0';  
  //---------��IP��ַ�Ͷ˿�---------end---------------
  
  //---------���û���������---------start---------------
  I2C_ReadS_24C(UserPosswordAddr,buffer,32);//
  for(i=0;i<32;i++)
  {
    if(buffer[i] == 0xff)break;
    NET.Username[i] = buffer[i];
  }
  NET.Username[i++] = '\0';
  for(j=0;i<32;i++)
  {
    if(buffer[i] == 0xff)break;
    NET.Password[j++] = buffer[i];
  }
  NET.Password[j] = '\0';  
  //---------���û���������---------end--------------- 
}

/*���Ϳ�������
input:type 
0:*SLEEP# //˯��-----����#SS*
1��*WAKE# //����-----����#IP*
2��*OFF#  //������-----����#OK*
3��*LK?#  //��ѯ����״̬-----����#IP*  #NO*
4��*CSQ#  //��ѯ�ź�ֵ-----����#18*
*/
u8 MBto3G_CtlCommmand(u8 type,u8 delaytime)
{
  u8 flag;
  u32 timeout;   
    
  if(NET.poweron==WCDMAPWROFF) //3G���ڶϵ��״̬
  {
    if(type==SLEEP_WCDMA) //����������
//      return 0;
      ;
    else
      return 5;
  }    
  //1��������----------------start----------------------------------------  
  switch(type)
  {   
  case SLEEP_WCDMA:
    {    
      if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_11)==1)
        send_string_3G("*SLEEP#");
      else
        return 0; 
      break;
    }    
  case WAKE_WCDMA: 
    { 
//      if(NET.IPportOn!=WCDMAIPPON) //֮ǰ��û��IPʱ
//      {
//        Read_IP();
//        Send_IP();
//      }      
      send_string_3G("@@@@@@*WAKE#");     
      break;
    }
  case OFF_WCDMA:
    {      
      send_string_3G("*OFF#"); 
      break;
    }
  case LK_WCDMA:
    {        
      //      send_string_3G("*LK?#");
      //      break;
      flag=InquireLink_G3();
      if(flag==0)
        return 0;
      else if(flag==2)
        return 4; //�лظ�������û���ϵ�״̬
      else if(flag==KEYOP_RETURN)
      { 

        return 2;
      }
      return 3;   //�п�������������
    }
  case CSQ_WCDMA:
    {  
      send_string_3G("*CSQ#");
      break;
    }
  case VER_WCDMA:
    {
      send_string_3G("*VR#");
      break;
    }
  default: return 1;
  }
  //��������----------------end------------------------------------------ 
  
  timeout =KEYTIMEOUT_3S*delaytime;  //�ȴ�ʱ������
  //�ж�  
  RxCounter_3G=0;   
  RxState_3G = 0;
  IWDG_ReloadCounter(); //ι��  
  while(--timeout)
  {	
    //����
    if(key_flag)//
    { 

      return 2;
    } 
    if(RxState_3G == 0x66) //�յ��ظ�
    {     
      RxState_3G = 0;      
      switch(type)
      {   
      case SLEEP_WCDMA:
        {  
          if((RxBuffer_3G[1]=='s')&&(RxBuffer_3G[2]=='s'))  //#ss*�ɹ�                      
            return 0;
          else 
            return 3;   //�п������������� 
        }    
      case WAKE_WCDMA: 
        {
          if((RxBuffer_3G[1]=='I')&&(RxBuffer_3G[2]=='P'))  //#IP*�ɹ�                      
            return 0;
          else 
            return 3;   //�п������������� #NOIP* 
        }
      case OFF_WCDMA:
        {  
          if((RxBuffer_3G[1]=='O')&&(RxBuffer_3G[2]=='K'))  //#OK*�ɹ�                      
            return 0;
          else 
            return 3;   //�п�������������  
        }
      case LK_WCDMA:
        {  
          if((RxBuffer_3G[1]=='I')&&(RxBuffer_3G[2]=='P'))  //#IP*�ɹ�                      
            return 0;
          else if((RxBuffer_3G[1]=='N')&&(RxBuffer_3G[2]=='O'))
            return 4; //�лظ�������û���ϵ�״̬
          else 
            return 3;   //�п�������������  
        }
      case CSQ_WCDMA: //#99*
        {  
          if((RxBuffer_3G[1]=='9')&&(RxBuffer_3G[2]=='9'))  //#ss*�ɹ�                      
            return 4; //�лظ��������ź�ֵ��ȷ��
          else 
            return 0;   //�п�������������  
        }
      case VER_WCDMA: //#VER.WCEQ20150508A*
        {  
          if((RxBuffer_3G[1]=='V')&&(RxBuffer_3G[2]=='R'))  //                
            return 0; //�лظ��������ź�ֵ��ȷ��
          else 
            return 3;   //�п�������������  
        } 
      default: return 1;
      } 
    }
  } 
  return 1;  //ʧ�� 
}






/*�������ϵͳ��Ϣ����ǰ�汾 ����̨��*/
//*<Send><Time><2014-11-12|15:17:10></Time>
//<Optype><CC></Optype><DataMeter><12345678 ></DataMeter></Send>#
void MBto3G_HeadData(u8 *type)
{
  //MUPֱ�ӿ���3Gģ��
  EmptyRcv3G();    
  send_string_3G("AT^IPSEND=1,\"");  
  
  //1����----------------start----------------------------------------   
  send_string_3G("*<Send><Time><20");  //ʱ��0% 
  send_twodigit_3G(time_BCD[4]);
  send_string_3G("-");
  send_twodigit_3G(time_BCD[3]);
  send_string_3G("-");
  send_twodigit_3G(time_BCD[2]);
  send_string_3G("|");
  send_twodigit_3G(time_BCD[1]);
  send_string_3G(":");
  send_twodigit_3G(time_BCD[0]);
  send_string_3G(":");
  send_twodigit_3G(time_BCD[5]);  
  send_string_3G("></Time><Optype><");
  send_string_3G(type);      
  send_string_3G("></Optype><DataMeter><");//�����
  send_twodigit_3G(MeterInfor.number[0]);
  send_twodigit_3G(MeterInfor.number[1]);
  send_twodigit_3G(MeterInfor.number[2]); 
  send_twodigit_3G(MeterInfor.number[3]);  
  //����----------------end------------------------------------------ 
}

void MBto3G_HeadData_AMT(u8 Rcsum,u8 *type,u8 falge_rc)
{
  //MUPֱ�ӿ���3Gģ��

  EmptyRcv3G();    
  send_string_3G("AT^IPSEND=1,\"");  
  
  //1����----------------start----------------------------------------   
  send_string_3G("*<Long><0196></Long><Result><Time><20");  //ʱ��0% 
  send_twodigit_3G(time_BCD[4]);
  send_string_3G("-");
  send_twodigit_3G(time_BCD[3]);
  send_string_3G("-");
  send_twodigit_3G(time_BCD[2]);
  send_string_3G("|");
  send_twodigit_3G(time_BCD[1]);
  send_string_3G(":");
  send_twodigit_3G(time_BCD[0]);
  send_string_3G(":");
  send_twodigit_3G(time_BCD[5]);  
  send_string_3G("></Time><Optype><");
  send_string_3G(type);      
  send_string_3G("></Optype><Metno><");//�����
  send_twodigit_3G(MeterInfor.number[0]);
  send_twodigit_3G(MeterInfor.number[1]);
  send_twodigit_3G(MeterInfor.number[2]); 
  send_twodigit_3G(MeterInfor.number[3]);
  
  send_string_3G("></Metno><Bagsum><00");
  send_twodigit_3G(Rcsum);
  
  
   // if(type=="EAEA")
      if(falge_rc==1)   
    {
    send_string_3G("></Bagsum><Record><"); 
    }
  else
  {
    send_string_3G("></Bagsum><Waring><"); 
  }  


  //����----------------end------------------------------------------ 
}
/*-------------------------------------------------------------
//���ܣ�Уʱʱ��]
^IPSEND:1 OK
#<Receive><Time><2014-11-12|15:17:10></Time><Optype><CC></Optype><DataCent
er><2014-11-12|15:17:10></DataCenter></Receive>*
����������ʱ��������Ч��Ϣ����data�У�
------------------------------------------------------------------------------*/
u8 MBto3G_UpdateTime(u8 delays,u8 data[])
{
  
  u8 i;
  u8 onehex[2];
//  u8 *p_temp=RxBuffer_3G;
  char *p_temp=(char *)RxBuffer_3G;
  u32 timeout;  
  
  //1����ʱ������----------------start----------------------------------------
  MBto3G_HeadData(TimeCommand);  
  //  send_string_3G("></DataMeter></Send>#");  //ʱ��
  send_string_ATCMD("></DataMeter></Send>#\""); //����\" 0x0d 0x0a
  //1����ʱ������----------------end------------------------------------------ 
  
  //2�ж���û�з��ɹ�(���Ϳ�����Ҫһ��ʱ��)---------------start-------------------------------------
  timeout=WAITPCDATATIMES;
  while(timeout)
  {
    if(ReadGsmString(READWAITTWOTIME))
    {
      if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))//OK
      { 
        break;
      }       
    }
    else
    {
     --timeout;     
    }// break;
    if(key_flag)
      return 2;
  }
  if(timeout==0)
    return 1; //ʧ��
  //2�ж���û�з��ɹ�---------------end-------------------------------------
    
  //^IPDATA: 1,34,#http://www.cmsoft.cn QQ:10865600*     
  //3�����жϺ�̨����--------------------start-------------------------------------
  timeout= WAITPCDATATIMES*1;  //delays  
  while(timeout)
  {
    IWDG_ReloadCounter(); //ι�� 
    if(ReadGsmString(READWAITTWOTIME))
    {//^IPDATA:
      if((RxBuffer_3G[0]=='^')&&(RxBuffer_3G[1]=='I')
         &&(RxBuffer_3G[3]=='D')&&(RxBuffer_3G[7]==':'))
      {         
        p_temp=strstr((char *)RxBuffer_3G,"#<Receive>");
        p_temp=p_temp+53;
        if(*p_temp!='C'||*(p_temp+1)!='C' )
          return 1; //ʧ��
        else
        {    
          i=0;
          for(p_temp=p_temp+27;*p_temp!='>';)//<DataCenter><20
          { 
            onehex[0]=asic_to_hex(*p_temp)<<4;
            p_temp+=1;
            onehex[1]=asic_to_hex(*p_temp);
            data[i++]=onehex[0]|onehex[1]; 
            p_temp+=2;          
          } 
          return 0;  //�ɹ� 
        }         
      }       
    }
    else
      --timeout;
    if(key_flag)
      return 2;
  } 
  
  return 1;  
  //3�����жϺ�̨����--------------------end-------------------------------------
}

/*-------------------------------------------------------------
//���ܣ����·���
//<Long><80></Long><Result><Optype><CC></Optype><Metno><678920></Metno></Result>#
����������ʱ��������Ч��Ϣ����data�У�
------------------------------------------------------------------------------*/
u8 MBto3G_UpdateRate(u8 delays,u8 data[])
{
  
  u8 i;
  u8 onehex[2];
  //  u8 *p_temp=RxBuffer_3G;
  char *p_temp=(char *)RxBuffer_3G;
  u32 timeout;
  
  //1����ʱ������----------------start----------------------------------------
  MBto3G_HeadData(RateBCommand); 
//  send_string_3G("></DataMeter></Send>#");  //ʱ��  
  send_string_ATCMD("></DataMeter></Send>#\""); //����\" 0x0d 0x0a
  //1����ʱ������----------------end------------------------------------------ 
  
   //2�ж���û�з��ɹ�(���Ϳ�����Ҫһ��ʱ��)---------------start-------------------------------------
  timeout=WAITPCDATATIMES;
  while(timeout)
  {
    if(ReadGsmString(READWAITTWOTIME))
    {
      if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))//OK
      { 
        break;
      }       
    }
    else
    {
     --timeout;     
    }// break;
    if(key_flag)
      return 2;
  }
  if(timeout==0)
    return 1; //ʧ��
  //2�ж���û�з��ɹ�---------------end-------------------------------------
    
  //^IPDATA: 1,34,#http://www.cmsoft.cn QQ:10865600*     
  //3�����жϺ�̨����--------------------start-------------------------------------
  timeout= WAITPCDATATIMES*1;  //delays  
  while(timeout)
  {
    IWDG_ReloadCounter(); //ι�� 
    if(ReadGsmString(READWAITTWOTIME))
    {//^IPDATA:
      if((RxBuffer_3G[0]=='^')&&(RxBuffer_3G[1]=='I')
         &&(RxBuffer_3G[3]=='D')&&(RxBuffer_3G[7]==':'))
      {         
        p_temp=strstr((char *)RxBuffer_3G,"#<Receive>");
        p_temp=p_temp+53;
        if(*p_temp!='R'||*(p_temp+1)!='B' )
          return 1; //ʧ��
        else
        {    
          i=0;
          for(p_temp=p_temp+25;*p_temp!='>';)//<DataCenter><
          { 
            onehex[0]=asic_to_hex(*p_temp)<<4;
            p_temp+=1;
            onehex[1]=asic_to_hex(*p_temp);
            data[i++]=onehex[0]|onehex[1]; 
            p_temp+=1;          
          } 
          return 0;  //�ɹ� 
        }
      }       
    }
    else
      --timeout;
    if(key_flag)
      return 2;
  } 
  
  return 1;  
  //3�����жϺ�̨����--------------------end-------------------------------------
}  


/*-------------------------------------------------------------
//���ܣ���¼�����ж�
//0%senddata#
��������¼���͡�����Ŀ����¼senddata��
------------------------------------------------------------------------------*/
u8 MBto3G_Record(u8 recordtype,u8 pack_num, u8 senddata[])
     //����˵��������¼���ͣ��ܰ����������ݣ�
{
  u8 recordbyte;
  u8 onehex[2];
//  u8 *p_temp=RxBuffer_3G;
  char *p_temp=(char *)RxBuffer_3G;
  u16 i,total;
  u32 address,timeout;
  
  
  address=G3.start_add;
  
   IWDG_ReloadCounter();
   EmptyRcv3G();
    
  //1���ͼ�¼������----------------start----------------------------------------
  //��ͬ���͵ļ�¼
  if(recordtype==Record)//����/��־/��ͳ�Ƽ�¼
  {
    recordbyte=Record_Byte;
    total=pack_num*recordbyte; //���ֽ�
    //ͷ�ļ�
   // MBto3G_HeadData(RecordCommand);
    MBto3G_HeadData_AMT(pack_num,"EEEE",1);
  }
  else if(recordtype==AlarmRecord) //������¼ 
  {    
    recordbyte=AlarmRecord_Byte;
    total=pack_num*recordbyte; //���ֽ�    
   // MBto3G_HeadData(AlarmRecordCommand);
    MBto3G_HeadData_AMT(pack_num,"EAEA",2); 
  }
   else if(recordtype==CPURecord) //������¼ 
  {    
    recordbyte=CPURecord_Byte;
    total=pack_num*recordbyte; //���ֽ�    
   // MBto3G_HeadData(AlarmRecordCommand);
    MBto3G_HeadData_AMT(pack_num,"EDED",1); 
  }
  else       
    return 1;
  //�м̺�
  
  // MBto3G_HeadData_AMT(pack_num,"EDED");
  
  
 // send_twodigit_3G(hex_to_bcd(pack_num)); //����
  //G3.start_add
 // send_string_3G("@");
  //send_twodigit_3G((address>>16)&0xff);
  //send_twodigit_3G((address>>8)&0xff);
 // send_twodigit_3G(address&0xff);  
  //send_string_3G("-"); 
  address+=total;
  //send_twodigit_3G((address>>16)&0xff);
  //send_twodigit_3G((address>>8)&0xff);
 // send_twodigit_3G(address&0xff);
  //flash��ַ  
  for(i=0;i<total;i++) //��¼����
    send_twodigit_3G(senddata[i]); 
  //   send_string_3G("></DataCenter></Send>#");  //ʱ��DataMeter 
  //send_string_ATCMD("></DataMeter></Send>#\""); //����\" 0x0d 0x0a
  
   if(recordtype==AlarmRecord)
   {
      send_string_ATCMD("></Waring></Result>#\"");
   } 
   else
   {
     send_string_ATCMD("></Record></Result>#\"");
   }

  
  //1���ͼ�¼������----------------end------------------------------------------ 
  
  
  
  //2�ж���û�з��ɹ�(���Ϳ�����Ҫһ��ʱ��)---------------start-------------------------------------
  //timeout=WAITPCDATATIMES;

   timeout=40; //10  
  while(timeout)
  { 
    
    
    if(ReadGsmString(READWAITTWOTIME))
    {
      if((RxBuffer_3G[0]==0x4F)&&(RxBuffer_3G[1]=='K'))//OK
      { 
        break;
      }       
    }
    else
    {
      --timeout;     
    }
    // break;
    if(key_flag)
      return 2;
  }
  
   if(timeout==0) 
   return 1; //ʧ��

  
  //2�ж���û�з��ɹ�---------------end-------------------------------------
 
  
  
  //3�����жϺ�̨����--------------------start-------------------------------------
  // timeout= WAITPCDATATIMES*2;  //delays  
   //timeout= WAITPCDATATIMES*2;
   timeout= 40;
   EmptyRcv3G();
   IWDG_ReloadCounter();  
  while(timeout)
  {
   //ι�� 
  //  IWDG_ReloadCounter();   
    if(ReadGsmString(READWAITTWOTIME))
    {
      //^IPDATA:
      
      
     /* if((RxBuffer_3G[0]=='^')&&(RxBuffer_3G[1]=='I')
         &&(RxBuffer_3G[3]=='D')&&(RxBuffer_3G[7]==':'))*/
         
          if((recv_3G[0]=='^')&&(recv_3G[1]=='I')
         &&(recv_3G[3]=='D')&&(recv_3G[7]==':'))    
      {         
          /*  p_temp=strstr((char *)RxBuffer_3G,"#<Receive>");
         // p_temp=p_temp+78;
       // if(*p_temp!='E')
          return 1; //ʧ��      
        else */
        //��ֹ�ظ����ֶδ������䳤
       // if(recv_3G[17]=='E') 
        
         if(1)  
        { 
          
          //ʱ��У��
          
          settimefun(recv_3G);
          
          
          p_temp=p_temp+1;
          onehex[0]=asic_to_hex(*p_temp)<<4;
          p_temp+=1;
          onehex[1]=asic_to_hex(*p_temp);
          onehex[0]=onehex[0]|onehex[1]; //RXX
          //      if(onehex[0]==0 || onehex[0]==0x01)  
          //        return 0;  //�ɹ� 
          //      else
          //        return 1;
          return 0;  //�ɹ�  
        }  
        else
        {
           return 1;
        }
      }       
    } 
    else
      --timeout;
    if(key_flag)
      return 2;
  } 
  
  return 1;  
   // return 0;  //�ɹ�  
  
  //3�����жϺ�̨����--------------------end-------------------------------------
}  

//���ͼ�¼(type�����ĸ���20��16���ֽڣ�10��32���ֽڣ�4��80���ֽڵ�CPU)
//���ͼ�¼(type�����ĸ���20��16���ֽڣ�10��32���ֽڣ�4��80���ֽڵ�CPU)
u8 SendPage_Record(u8 type, u8 netstate)
{
  u8 i,j,times;
  u8 set_success,net_flag,bytenum,packet;
  u8 bytetotal,oldbytetotal,f_ToEnd;
  u8 st_numpage,sumnumpaged;
  u8 buffer[1024];
  u16 sendbyte,jishu;
  u32 total_record;
  u32 addr1,addr2,MAXADDR,MINADDR,num;  //
  u8 BUF_NET_LINK_0[1];
  
  addr2=G3.start_add;      //��¼��ʼ��ַ  
  addr1=G3.end_add;        //��¼������ַ 
  total_record=G3.RTotal;
  f_ToEnd=0;
  //��ͬ���͵ļ�¼
  if(type==Record)
  {
    packet=Bag_Record;
    bytenum=Record_Byte;
    MINADDR=MINFlashRecordAdd;
    MAXADDR=MAXFlashRecordAdd; 
  }
  else if(type==AlarmRecord) //������¼
  {
    packet=AlarmBag_Record;
    bytenum=AlarmRecord_Byte;
    MINADDR=MINFlashAlarmRecordAdd;
    MAXADDR=MAXFlashAlarmRecordAdd; 
  }
   else if(type==CPURecord) //������¼
  {
    packet=CPUBag_Record;
    bytenum=CPURecord_Byte;
    MINADDR=MINFlash_AMT_RecordAdd;
    MAXADDR=MAXFlash_AMT_RecordAdd; 
  } 
  else
    return 1;
  

 

 
 
 //
  if(netstate==0)
  { 
    net_flag=MU509link_net(); //open_3G(8)Initial_3G
  }
   
  else  if(netstate==1)
  {
    net_flag=0;

  }
    if(net_flag!=0)   
    {
     I2C_ReadS_24C(NET_MAX_LINK_COUNT,BUF_NET_LINK_0,1); 
     BUF_NET_LINK_0[0]++;
     I2C_WriteS_24C(NET_MAX_LINK_COUNT,BUF_NET_LINK_0,1); 

    }
  else
  {
     BUF_NET_LINK_0[0]=0x00;
     I2C_WriteS_24C(NET_MAX_LINK_COUNT,BUF_NET_LINK_0,1); 
  }

       if(key_flag)
        return 1;
  
  
 
  //����


  times=bytenum/16;
  //�����ɹ�------------start------------------------------------
  if(net_flag==0) 
  {    netstate=1;  
    //ÿ�η���(Bag_Record��)��¼��Ϊһ��
    while(total_record)
    {
      IWDG_ReloadCounter(); //ι�� 
      //
      //��Ҫ����--�жϵ�ַ�ϲ��Ϸ�--------START---------- 
      if(addr2<MINADDR || addr2>=MAXADDR)
        addr2=MINADDR;  
      num=addr2-MINADDR;    
      if(num%bytenum)
      {    
        addr2=MINADDR+(num/bytenum)*bytenum;    
      }     
      if(addr2<MINADDR || addr2>=MAXADDR)
        addr2=MINADDR;         
      //��Ҫ����--�жϵ�ַ�ϲ��Ϸ�--------END------------- 
      //
      if(total_record>packet)  
      {
        st_numpage=packet;        
      }
      else
      {
        st_numpage=total_record;
      }  
      sendbyte=st_numpage*bytenum; //����*ÿ����¼���ֽ�
      
      if(key_flag)
        return 2;
      
      
      SPI_FLASH_Init();      
      /////////////////////////////////////////
      bytetotal=sendbyte/16;
      oldbytetotal=bytetotal;
      
      for(jishu=0;jishu<bytetotal;) //ÿ��ֻ��16���ֽڵ�flash
      {
        SPI_FLASH_BufferRead(buffer+jishu*16,addr2,16);        
       
        if(jishu % times==0)//�жϼ�¼��16���ֽ�FF
        {
          for(i=0;i<16;i++)
          {
            if(buffer[jishu*16+i]!=0xff)
              break;        
          }
          if(i==16)//����0xff
          {
            if(oldbytetotal>times)
              oldbytetotal-=times;
            else
              oldbytetotal=0;
            
            //��ַ�ж�
            for(j=0;j<times;j++)
            {
              addr2+=16;
              if(addr2==addr1)
                f_ToEnd=1; //�������
              if(addr2>=MAXADDR)	
                addr2=MINADDR; 
              if(addr2==addr1)
                f_ToEnd=1;
            } 
            
          }  
          else
          {
            addr2+=16;
            if(addr2==addr1)
              f_ToEnd=1; //�������
            if(addr2>=MAXADDR)	
              addr2=MINADDR; 
            if(addr2==addr1)
              f_ToEnd=1;
            jishu++;
          }
        }
        //
        else
        {
          addr2+=16;
          if(addr2==addr1)
            f_ToEnd=1; //�������
          if(addr2>=MAXADDR)	
            addr2=MINADDR; 
          if(addr2==addr1)
            f_ToEnd=1;
          jishu++;
        }
        
        if(jishu>=oldbytetotal)
          break;
        
      } 
      
      buffer[jishu*16]='\0'; 
      //////////////��¼������/////////////////////////// 
      if(key_flag)
        return 2; 
      IWDG_ReloadCounter(); //ι�� 
      
      sendbyte=oldbytetotal*16;
      sumnumpaged=sendbyte/bytenum;
      if(sumnumpaged)
      {   
        //����˵��������¼���ͣ��ܰ����������ݣ�
        
        if(key_flag)
        return 2;
        set_success=MBto3G_Record(type,sumnumpaged, buffer);
        
        
        if(set_success==0) //�ɹ�
        {
          if(total_record>=st_numpage)
            total_record-=st_numpage;  //�ܰ���-�Ѿ����͵İ���
          if(f_ToEnd==1)
            total_record=0;
          G3.start_add=addr2;
        }
        else if(set_success==2) //�а���
        {
          return 2;     
        }
        
        else  //ʧ�ܳ���
        {        
          return 1;
        }
      }
      //ֱ������
      else
      {
        if(total_record>=st_numpage)
          total_record-=st_numpage;  //�ܰ���-�Ѿ����͵İ���
        if(f_ToEnd==1)
          total_record=0;
        G3.start_add=addr2;  
        if(key_flag)
          return 2; 
      }
        
      //////////////////////////////////////////////
    }      
  } 
  //�����ɹ�------------end------------------------------------
  //����ʧ��------------start------------------------------------
  else if(net_flag==2) //����
  {
     netstate=0;  
    return 2;
  }  
  else  //����
  {
   netstate=0; 
    return 1;
  }

  //����ʧ��------------end------------------------------------
  
  return 0; //ȫ��������� �ɹ�
}

/*����3�ּ�¼������Ϣ���������Լ�δ���͵�������POS�Լ�3G��*/
//pos_3gtype=1ΪPOS��pos_3gtype=0Ϊ3G
u32 Count_Record(u8 pos_3gtype, u8 recordtype)
{    
  u8 record_Byte;
  u8 justmax[2];
  u8 Send_buf[3];
  u8 SaveRecord_buf[3]; 
  
  u16 SaveCurrentAdd,EndAddr,G3EndAddr,JustMAXAddr;
  u32 MAXAdd,MINAdd;
  
  u32 FD,FD3G,num; 
  u32 Count;
  
  
  if(recordtype==Record) //32���ֽ�
  {
    SaveCurrentAdd=FLASHRecordSaveCurrentAddr;
    EndAddr=FLASHLastTimeLoadEndAddr;
    G3EndAddr=G3LastTimeLoadEndAddr;
    JustMAXAddr=FLASHRecordJustMAXAddr;
    MAXAdd=MAXFlashRecordAdd;
    MINAdd=MINFlashRecordAdd; 
    record_Byte=Record_Byte;
  }
  else if(recordtype==AlarmRecord) //16���ֽ�
  {
    SaveCurrentAdd=FLASHCheckRecordSaveCurrentAddr;
    EndAddr=FLASHCheckLastTimeLoadEndAddr;
    G3EndAddr=G3CheckLastTimeLoadEndAddr;
    JustMAXAddr=FLASHCheckRecordJustMAXAddr;
    MAXAdd=MAXFlashAlarmRecordAdd;
    MINAdd=MINFlashAlarmRecordAdd;
    record_Byte=AlarmRecord_Byte;
  } 
   else if(recordtype==CPURecord) //16���ֽ�
  {
    SaveCurrentAdd=FLASHCPURecordSaveCurrentAddr;
    EndAddr=FLASHCPULastTimeLoadEndAddr ;
    G3EndAddr=G3CPULastTimeLoadEndAddr;
    JustMAXAddr=FLASHCPURecordJustMAXAddr ;
    MAXAdd=MAXFlash_AMT_RecordAdd ;
    MINAdd=MINFlash_AMT_RecordAdd ;
    record_Byte=CPURecord_Byte;
  }  
  
  else
    return 0;
  
  if(key_flag)
    return 0;
  
  I2C_ReadS_24C(JustMAXAddr,justmax,2);	//������    
  if(justmax[1] == 1)//��
  {
    Count=MAXAdd-MINAdd;      //������ַ����   
    
    G3.start_add=MINAdd;      //��¼��ʼ��ַ  
    G3.end_add=MAXAdd;        //��¼������ַ
  }
  else
  {
    I2C_ReadS_24C(SaveCurrentAdd,SaveRecord_buf,3);//�����磬��ǰ����FLASH��¼�Ŀ�ʼ��ַ 
    FD=hcl(SaveRecord_buf,3);	 //�ϲ�3���ֽڵ�ַ	
    if(pos_3gtype==G3InRecord)
      I2C_ReadS_24C(G3EndAddr,Send_buf,3);	 //3G��¼���ص��ĵĵ�ַ
    else
      I2C_ReadS_24C(EndAddr,Send_buf,3);	 //��¼���ص��ĵĵ�ַ
    
    FD3G=hcl(Send_buf,3);	 //�ϲ�3���ֽڵ�ַ
    
    //��Ҫ����--�жϵ�ַ�ϲ��Ϸ�--------START---------- 
    if(FD3G<MINAdd || FD3G>=MAXAdd)
      FD3G=MINAdd;  
    num=FD3G-MINAdd;    
    if(num%record_Byte)
    {    
      FD3G=MINAdd+(num/record_Byte)*record_Byte;    
    }     
    if(FD3G<MINAdd || FD3G>=MAXAdd)
      FD3G=MINAdd;
    //FD
    if(FD<MINAdd || FD>=MAXAdd)
      FD=MINAdd;  
    num=FD-MINAdd;    
    if(num%record_Byte)
    {    
      FD=MINAdd+(num/record_Byte)*record_Byte;    
    }     
    if(FD<MINAdd || FD>=MAXAdd)
      FD=MINAdd;    
  //��Ҫ����--�жϵ�ַ�ϲ��Ϸ�--------END------------ 
        
    G3.start_add=FD3G;      //��¼��ʼ��ַ  
    G3.end_add=FD;          //��¼������ַ
    
    if(FD>=FD3G)
      Count=FD-FD3G; 
    else
      Count=(MAXAdd-FD3G)+(FD-MINAdd);
    
  }  
  Count = Count/record_Byte;  
  return Count;
}

/*-----------��¼���ͻ���------------------------
ע�⣺ ���㷢�͵ķ���ʱ��Ϊ����������һλ�� ��60����
1.���ͼ���� 4Сʱ.��6:00-24:00�����ʱ��ŷ���¼
2.��¼������1��.��˵��:���32�ֽڼ�¼����1���������ʱ���κ�һ��32���жϷ��ͣ�
3.����ʧ�ܺ󣨰�����:a\����ʣ�������4 �Σ�b\���͵ļ��(2����)ע�⣺���㷢�͵ķ���ʱ��Ϊ����������һλ����60����
buffer[0] = 4;
buffer[1] = 1;
buffer[2] = 4;
buffer[3] = 2;
buffer[4] = 4;Alarm_OP SLEEP_WCDMA
I2C_WriteS_24C(SendInterval,buffer,5);
----------------------------------------------------*/
void Record_TXMechanism(u8 min)
{
  u8 net_state;  //tmp,
  u8 send_success=0;//��Ҫ
  u8 buffer[7];
  
//   I2C_ReadS_24C(LOWPOWER,buffer,3);
//   if(buffer[1]==1 && buffer[0]>1)
//     return ;  //û��
 
//  if(G3.falseTimes)
//  {
//  G3.falseTimes=0;
//  return;
//  }
  
//  1��ǰʱ���ǰ���-----------start-------------	   
 /* if(((time[1]>FEE.starthour)&&(time[1]<FEE.endhour))		
     ||((time[1]==FEE.starthour)&&(time[0]>FEE.startmin))
       ||((time[1]==FEE.endhour)&&(time[0]<FEE.endmin)))
  {*/ 
  
  #if TEST
     if(1) 
  #else
    if ((time[1]==0x03)&&(time[0]>=0x01)&&(time[0]<=0x1E))
  #endif
  
//  if ((time[1]==0x03)&&(time[0]>=0x01)&&(time[0]<=0x1E))
 //  if(1) 
  {
    
  /*  IWDG_ReloadCounter(); //ι�� 
      //------��ȡ�������¼���Ͳ���--------start------------------------  
    I2C_ReadS_24C(SendTimeInterval,buffer,7);
    G3.SendTime=buffer[0];       //����ʱ����4
    G3.RCount=buffer[1];         //��¼����1�����ڴ�����ÿ32�ж϶�Ҫ���ͣ�������η��ͣ�
    G3.falseTimes=buffer[2];     //����ʣ�����4
    G3.falseInterval=buffer[3];  //����ʧ�ܺ�� ���͵ļ��2
    
    G3.falseValTimes=buffer[4];  //֮ǰ����ʧ�ܺ�ķ���ʣ�����
    G3.lasthour=buffer[5];       //�ϴη��͵�ʱ�䣨ʱ�֣�
    G3.lastmin=buffer[6];  
   */
    
    
  //    if(G3.SendTime==0)
 //      return;
    //------��ȡ�������¼���Ͳ���-----------end---------------------   
//    if((time[1]>=FEE.starthour)&&((time[1]-FEE.starthour)%G3.SendTime==0));
//    else
//      return;
   //�������ʣ�෢�ʹ���
    
 /*   if(G3.falseValTimes>=G3.falseTimes)
    {
      if(time[1]==G3.lasthour) //����һ��ʱ������4�λ���
      {

        //���ϼ�¼
        if(G3.falseValTimes==G3.falseTimes)
        {
          buffer[0]=50;
          I2C_WriteS_24C(FalseSendValTimes,buffer,1);  //           
        }
        return ;
      } //������¼��
      else
      {
        G3.falseValTimes=0;
        G3.lasthour=time[1];
        G3.lastmin=time[0];
        buffer[0]=G3.falseValTimes;
        buffer[1]=G3.lasthour;
        buffer[2]=G3.lastmin;      
        I2C_WriteS_24C(FalseSendValTimes,buffer,3);  //������÷�
      }
    } 
    else    
    {
      //������������ʧ�ܺ�� ���͵ļ��--------start------------
      if(G3.falseValTimes && time[0]==G3.lastmin) //�ø���һ�η���
        return;    
    }
    */
    
//    �����-------------------end------------------------
     
    
    //���ͼ�¼----------start------------------  
  
  //�����������  
   net_state=0; //û������
  
  
  //������¼����
  
  
  //������¼�����ַ������������ѭ����
   
   for(int i = 0; i < 3; ++i)
   {
      
    if(key_flag==0)
   {
     
     G3.RTotal=Count_Record(G3InRecord,AlarmRecord); //G3.start_add(��¼��ʼ��ַ)G3.end_add//��¼������ַ  
 
   }
    
      if( key_flag==0 && G3.RTotal > G3.RCount)//�ﵽ���δ���ͼ�¼
    {  
  
    // G3.RTotal=Count_Record(G3InRecord,AlarmRecord); //G3.start_add(��¼��ʼ��ַ)G3.end_add//��¼������ַ  

      send_success=SendPage_Record(AlarmRecord,net_state);//(����������)     
      //����һ�£���ַ  
      fll(G3.start_add,buffer,3);
      I2C_WriteS_24C(G3CheckLastTimeLoadEndAddr,buffer,3);	//���浽�Ǹ���ַд������ 
      net_state=0; 
      if(send_success==0) //ȫ��������ɹ�--���
      {         
        net_state=1;
        G3.falseValTimes=0;
        G3.lasthour=time[1];
        G3.lastmin=time[0];        
      }   
      else if(send_success==1)
           return;  
      else//ʧ��---������1
      {
        close_3G(1);
        if(send_success==2);//�а���--���ֲ��� 
        else
        {
          G3.falseValTimes+=1;
          G3.lasthour=time[1];
          G3.lastmin=time[0];
        }
      }
      //////////////////////////
      buffer[0]=G3.falseValTimes;
      buffer[1]=G3.lasthour;
      buffer[2]=G3.lastmin;     
      I2C_WriteS_24C(FalseSendValTimes,buffer,3);  //������÷�
      
     if(key_flag)
        return;
      
    } 
    
    //���ͼ�¼----------end--------------------
    
    //����ͨ��¼����
    //1����CPUδ����¼������
    
  
    if(key_flag==0 && send_success==0 )//send_success==0 && 
    {
      G3.RTotal=Count_Record(G3InRecord,CPURecord); //G3.start_add(��¼��ʼ��ַ)G3.end_add//��¼������ַ  
      //G3.RTotal=0;
      if(key_flag==0 && G3.RTotal > G3.RCount)//�ﵽ���δ���ͼ�¼
      { 
       // send_success=SendPage_Record(1,net_state);//����Ҫ�������� 
        send_success=SendPage_Record(CPURecord,net_state);
        //����һ�£���ַ  
        fll(G3.start_add,buffer,3);
        I2C_WriteS_24C(G3CPULastTimeLoadEndAddr,buffer,3);	//���浽�Ǹ���ַд������ 
        
        net_state=0;
        if(send_success==0) //ȫ��������ɹ�--���
        {          
          net_state=1;
          G3.falseValTimes=0;
          G3.lasthour=time[1];
          G3.lastmin=time[0];        
        }    else if(send_success==1)
           return;
          else if(send_success==2)
           

            ;
        else//ʧ��---������1
        {
        //  close_3G(1);

          if(send_success==2);//�а���--���ֲ��� 
          else
          {
           G3.falseValTimes+=1;
           G3.lasthour=time[1];
            G3.lastmin=time[0];
          }
        }
        //////////////////////////
        buffer[0]=G3.falseValTimes;
        buffer[1]=G3.lasthour;
        buffer[2]=G3.lastmin;     
        I2C_WriteS_24C(FalseSendValTimes,buffer,3);  //������÷�
        
      }
        if(key_flag)
        return;
    }
    
      //ͣ����¼����
    if(send_success==0 && key_flag==0)//send_success==0 && 
    {
      //1����32���ֽ�δ����¼������
      G3.RTotal=Count_Record(G3InRecord,Record); //G3.start_add(��¼��ʼ��ַ)G3.end_add//��¼������ַ  
      if(key_flag==0 && G3.RTotal > G3.RCount)//�ﵽ���δ���ͼ�¼
      { 
      
        send_success=SendPage_Record(Record,net_state);//���ͼ�¼ (�ȹ��������ӣ�����)    
              Battery_alarm_RC(1);
        //����һ�£���ַ
        
        fll(G3.start_add,buffer,3);
        I2C_WriteS_24C(G3LastTimeLoadEndAddr,buffer,3);	//���浽�Ǹ���ַд������ 
        net_state=0;
        if(send_success==0) //ȫ��������ɹ�--���
        {
//          close_3G(3); //3G��Դ���������߻�أ�
          G3.falseValTimes=0;
          G3.lasthour=time[1];
          G3.lastmin=time[0];        
        }     else if(send_success==1)
           return;
        else if(send_success==2)

          ;
        else //ʧ��---������1
        {      

          G3.falseValTimes+=1;
          G3.lasthour=time[1];
          G3.lastmin=time[0];        
        }
        //////////////////////////
        buffer[0]=G3.falseValTimes;
        buffer[1]=G3.lasthour;
        buffer[2]=G3.lastmin;     
        I2C_WriteS_24C(FalseSendValTimes,buffer,3);  //������÷�
        
      }
      else
      {
        if(net_state)
          ;
//          close_3G(3); //3G��Դ���������߻�أ�   
      }
    }
    

    
    
          if(key_flag)
        return;
    }
    
    //ҵ������

    
  }
  //ҹ��
  else
  {    

    ;
  }

  return;
  
}




/*----------����������-------------------*/


//����ʱ��˶Ի���
u8 RateTime_Mechanism(u8 *min)
{
  u8 j,chargetime;//�Ǳ���ʱ��
  u8 lk_success,time_success,rate_success;
  u8 timesOut,buffer[3];
  u8 data[16];  
  
  //ÿ��23��
//  if(time_BCD[1] == TimeRateStartTIME && time_BCD[0] == min )//
  if(key_flag==0 && time[1]==min[0] && time[0] == min[1] )// 
  {      
    I2C_ReadS_24C(RateTimeUpdateClass,buffer,3);  //��ȡ�ֶ� ʱ�� 
    if(buffer[0] == AUTO_UPDATE)
    {
//      if(LowVoltage_Test(0)) //û��
//        return 0;
      time_success=1;
      rate_success=1;
      lk_success=1;
      //ʱ�����----------start---------------------
      timesOut=0;
      while(timesOut<4)
      { 
        IWDG_ReloadCounter(); //ι��           
        if(lk_success==0||(MU509link_net()== 0)) //�����ɹ�open_3G(8) Initial_3G
        { 
          //ʱ�����----------start---------------------
          if(time_success)
          {          
            time_success=MBto3G_UpdateTime(2,RxBuffer_3G);
            //ʱ����³ɹ�--------------------------------
            if(time_success==0) 
            {
              //<20140828045020> 
              //1���ж��½��յ��������Ƿ�Ϸ�------start-------
              data[4]=RxBuffer_3G[0];	  //��				
              data[3]=RxBuffer_3G[1];	  //��				
              data[2]=RxBuffer_3G[2];	  //��				
              data[1]=RxBuffer_3G[3];	  //ʱ				
              data[0]=RxBuffer_3G[4];	  //��	
              data[5]=RxBuffer_3G[5];
              time_success=jd_downtime(data);
              if(time_success==1)
              {
                timesOut++;//���ݳ���             
                lk_success=MBto3G_CtlCommmand(LK_WCDMA,2);
                continue;
              }
              //�������ݴ��ж�----------end------------  
              judge_get_time();
              //2���ж��½��յ��������Ƿ�Ϸ�------end-------
              chargetime=0;
              if(time_BCD[4]!= RxBuffer_3G[0] || time_BCD[3]!= RxBuffer_3G[1] || time_BCD[2] != RxBuffer_3G[2]
                 || time_BCD[1] != RxBuffer_3G[3])
              {
                chargetime=1;
                timesOut=0;
              }
              //�꣬�£��գ�ʱ���,�����2����
              else
              {
                if((time_BCD[0]>RxBuffer_3G[4] && time_BCD[0]-RxBuffer_3G[4]>2)
                   ||(time_BCD[4]>RxBuffer_3G[0] && time_BCD[4]-RxBuffer_3G[0]>2))
                  chargetime=1;
                else
                  chargetime=0; 
                timesOut=0;
              }
              if(chargetime==1)
              {
                data[4]=RxBuffer_3G[0];	  //��				
                data[3]=RxBuffer_3G[1];	  //��				
                data[2]=RxBuffer_3G[2];	  //��				
                data[1]=RxBuffer_3G[3];	  //ʱ				
                data[0]=RxBuffer_3G[4];	  //��								
                data[6]=mathweek(RxBuffer_3G[0],RxBuffer_3G[1],RxBuffer_3G[2]);					
                set_current_time(data);	
                //��¼              
//                make_timerecord(Journal_OP,UpdateTime_LOG,NetTIME_Record,space_HEX);
                judge_get_time();
//                save_YWrecord(Meter_Journal,1,MeterNetTIME_Record);//�����м̼�¼                              
                //���֮ǰ����ˢʱ��
//                ClearFreeCardInf();
                
                //            if(tpye==Clock_Card)//ʱ�ӿ�,ֻ����ʱ��
                //            {close_3G(3);return Clock_Card;}           
                
              }               
            } 
            /////////////////////////////////////////          
            else if(time_success==2) //�а���
            {
//           
              return 0;
            }
            else
            {
              time_success=1;//���ݳ��� 
              timesOut++;  
              if(timesOut>=4)
                break;
              lk_success=MBto3G_CtlCommmand(LK_WCDMA,2);
              continue;
            }
            
          }
          //ʱ�����----------end---------------------
          
          //���·���------------start----------------
          if(rate_success)
          {
            rate_success=MBto3G_UpdateRate(2,RxBuffer_3G);
            if(rate_success==0) //���յ���������
            { 
              //10 20 00 07 30 64 28 02 02 30 00 24 02 02 02 51
              //�жϽ��յ��ķ�������---�Ƿ�Ϸ�-------
              RxBuffer_3G[19]=RxBuffer_3G[0];
              for(j=17;j>0;j--)
                RxBuffer_3G[19] += RxBuffer_3G[j];
              if(RxBuffer_3G[19]==RxBuffer_3G[18]) //�������
              {
                //up_IRGpower();
                //�ж��Ƿ��֮ǰ����һ�£���һ�²ű���
                I2C_ReadS_24C(INOUTTIMEAddr,RxBuffer_3G+20,19); 
                for(j=0;j<19;j++)
                {
                  if(RxBuffer_3G[j]!=RxBuffer_3G[j+20])
                  {
                    //��¼                
                    //make_raterecord(Journal_OP,Rate_LOG,NetRate_Record,space_HEX);
//                      save_YWrecord(Meter_Journal,1,MeterNetRate_Record);//�����м̼�¼
                    break;
                  }
                }
                close_3G(3);
                return 0;   
              }
              else
              {
                rate_success=1;//���ݳ��� 
                timesOut++; 
                lk_success=MBto3G_CtlCommmand(LK_WCDMA,2);
                continue;
              }            
            }        
            /////////////////////////////////////////          
            else if(time_success==2) //�а���
            {
   
              return 0;}
            else
            {
              rate_success=1;//���ݳ��� 
              timesOut++; 
              if(timesOut>=4)
                break;
              lk_success=MBto3G_CtlCommmand(LK_WCDMA,2);
              continue; 
            }   
            
          }
            //���·���------------end----------------
        }
        //����ʧ��------------start--------------
        else 
        {

          if(key_flag)
          {return 0;}
          lk_success=1;
          timesOut++;
          if(timesOut>=4)
            break;
          delayms(500);
        }
        
        //����ʧ��------------end--------------
      }  

      ;
    }
  }
  return 0;
}





//����ʱ��ͷ���  �������صķ���
void  count_nettime( u8 meterminno)
{
  u8 n; 
  u8 netnet[4];
  
  ////ʱ��ͷ���
  //n=meterminno/TimeRateMeterSectionNum;
  //if(n>0)
  //netnet[0]=(n-1)*TimeRateNeedMinute;
  //else
  //netnet[0]=0;
  ////��������
  //n=meterminno/IAPMeterSectionNum;
  //if(n>0)
  //netnet[0]=(n-1)*IAPNeedMinute;
  //else
  //netnet[0]=0;
  
  
  netnet[0]=TimeRateStartTIME;
  netnet[2]=IAPStartTIME;
  //ʱ��ͷ���
  n=bcd_to_hex(meterminno);
  if(n<=MAXNETLinknum)
  {    
    netnet[1]=0;   
    netnet[3]=0;
    
  }
  else if(n<2*MAXNETLinknum)
  {    
    netnet[1]=TimeRateNeedMinute;    
    netnet[3]=IAPNeedMinute;
  }
  else if(n<3*MAXNETLinknum)
  {   
    netnet[1]=2*TimeRateNeedMinute;    
    netnet[3]=2*IAPNeedMinute;
  }
  else if(n<4*MAXNETLinknum)
  {   
    netnet[1]=3*TimeRateNeedMinute;   
    netnet[3]=3*IAPNeedMinute;
  }
  else 
  {    
    netnet[1]=4*TimeRateNeedMinute;   
    netnet[3]=4*IAPNeedMinute;
  }
 
//  netnet[1]++;
//  netnet[3]++;
  if(netnet[1]>=60)
  {
    n=netnet[1]/60;	
    netnet[0]=netnet[0]+n;
    netnet[1]=netnet[1]%60;	    
  }
  if(netnet[3]>=60)
  {
    n=netnet[3]/60;	
    netnet[2]=netnet[2]+n;
    netnet[3]=netnet[3]%60;	    
  }
  
  
  
   I2C_WriteS_24C(NetTimeAddr,netnet,4);  //���  
  
  
}

void MBto3G_DownCommmand(u8 mintype,u16 bag,u8 type)
{
  //1��������----------------start----------------------------------------   
  
  send_string_3G("*0%<Long><137></Long><Result><Optype><");
  send_twodigit_3G(mintype);
  send_string_3G("></Optype><Nitem><88888></Nitem><");
  send_twodigit_3G(mintype);
  send_string_3G("></Optype><hmdSeq><");
  send_onedigit_3G(bag/1000);
  send_onedigit_3G(bag/100%10);
  send_onedigit_3G(bag/10%10);
  send_onedigit_3G(bag%10);
  send_string_3G("></hmdSeq>");
  
  send_string_3G("<Metno><");   //�����
  send_twodigit_3G(MeterInfor.number[0]);
  send_twodigit_3G(MeterInfor.number[1]);
  send_twodigit_3G(MeterInfor.number[2]);
  send_string_3G("></Metno>");
  
  send_string_3G("<Ptype><"); //���ط�ʽ
  send_twodigit_3G(type);
  send_string_3G("></Ptype>");
  
  send_string_3G("</Result>#"); 
  //��������----------------end------------------------------------------ 
}
u8 MBto3G_BackListCommmand(u16 bag,u8 type,u8 rebuffer[])
{ 
  u16 i,num; //numΪ���������ֽ���
  u8 onehex[2];
  u8 *p_temp=RxBuffer_3G;
  u32 timeout;
  //���ͣ�*%<Long><137></Long><Result><Optype><F3></Optype><Nitem><88888</Nitem><F3>
  //</Optype><hmdSeq><0001></hmdSeq><Metno><000001></Metno><Ptype><1></Ptype></Result>#
  
  
  MBto3G_DownCommmand(0xf3,bag,type); //������F3
  
  //���գ�
  //#<Metno><000001></Metno><Optype><F2></Optype><Nitem><0038></Nitem>
  //  <hmdSeq><0008></hmdSeq><BCC><C0></BCC><Count><0512></Count>
  //  <Text><51000002260044685100000</Text><Type><01></Type>*
  //2�����жϺ�̨����--------------------start-------------------------------------
  timeout=TIMEOUT_1S*6;  
  IWDG_ReloadCounter(); //ι�� 
  RxCounter_3G=0;   ////��ս��յı�־λ
  RxState_3G = 0;
  while(--timeout)
  {    
    IWDG_ReloadCounter(); //ι��
    if(RxState_3G ==0x66)  //���յ���̨����
    { 
      p_temp= p_temp+46;//#<Metno><000001></Metno><Optype><F2></Optype><Nitem>
      //�ܹ��м���
      if(*p_temp!='N')
        return 1; //ʧ��    
      else
      {       
        IWDG_ReloadCounter(); //ι�� 
        //1�ܰ���(2���ֽ�)--------<Nitem><0320></Nitem>----------------------------
        i=0;
        for(p_temp=p_temp+7;*p_temp!='>';)  //����ASCIIתһ��hex����
        { 
          onehex[0]=asic_to_hex(*p_temp)<<4;
          p_temp+=1;
          onehex[1]=asic_to_hex(*p_temp);
          rebuffer[i++]=onehex[0]|onehex[1]; 
          p_temp+=1;
        }
        /////////////////////////////////////////////
        //2����(2���ֽ�BCD)-----></Nitem><hmdSeq><-------------------------------    
        for(p_temp=p_temp+18;*p_temp!='>';)  //����ASCIIתһ��hex����
        { 
          onehex[0]=asic_to_hex(*p_temp)<<4;
          p_temp+=1;
          onehex[1]=asic_to_hex(*p_temp);
          rebuffer[i++]=onehex[0]|onehex[1]; 
          p_temp+=1;
        }
        //3BCC����(1���ֽ�)----></hmdSeq><BCC><-----------
        for(p_temp=p_temp+16;*p_temp!='>';)  //����ASCIIתһ��hex����
        { 
          onehex[0]=asic_to_hex(*p_temp)<<4;
          p_temp+=1;
          onehex[1]=asic_to_hex(*p_temp);
          rebuffer[i++]=onehex[0]|onehex[1]; 
          p_temp+=1;
        }
        //4�ֽ���(2���ֽ�BCD��)----></BCC><Count><-----------
        //        for(p_temp=p_temp+16;*p_temp!='>';)  //����ASCIIתһ��hex����
        //        { 
        //          onehex[0]=asic_to_hex(*p_temp)<<4; //rebuffer[5],rebuffer[6]
        //          p_temp+=1;
        //          onehex[1]=asic_to_hex(*p_temp);
        //          rebuffer[i++]=onehex[0]|onehex[1]; 
        //          p_temp+=1;
        //        }
        //5 rebuffer[7] ��Ϊ���ط�ʽ       
        //6����������------------------------------------
        i=8;
        p_temp=p_temp+34;//></BCC><Count><0512></Count><Text><
        if(*p_temp!='<')
          return 1; //ʧ��
        for(p_temp=p_temp+1;*p_temp!='>';)  //����ASCIIתһ��hex����
        { 
          onehex[0]=asic_to_hex(*p_temp)<<4;
          p_temp+=1;
          onehex[1]=asic_to_hex(*p_temp);
          rebuffer[i++]=onehex[0]|onehex[1]; 
          p_temp+=1;
        }
        //2014-8-28��ʹkey_flag=0x35
        /////////////////////////////////////////////
        key_flag=0;
        //3���ط�ʽ------------------------------------        
        rebuffer[i]='\0';
        p_temp=p_temp+14; 
        if(*p_temp!='<') //></Text><Type><
          return 1; //ʧ��
        p_temp+=1;
        onehex[0]=asic_to_hex(*p_temp)<<4;
        p_temp+=1;
        onehex[1]=asic_to_hex(*p_temp);
        rebuffer[7]=onehex[0]|onehex[1]; //���ط�ʽ
        p_temp+=1;        
        //4���������ֽ���
        num=i-8;
        rebuffer[5]=(num>>8)&0xff;
        rebuffer[6]=num&0xff;
        /////////////////////////////////////////////        
        return 0;  //�ɹ�
      }  
      
    }
    
    if(key_flag) //�а���
    {return 2;} 
    
  } 
  
  return 1;  
  //2�����жϺ�̨����--------------------end-------------------------------------
  
}
u8 MBto3G_lkCommmand(void)
{
  u32 timeout;
  
  //1��������----------------start----------------------------------------  
  
  send_string_3G("*lk?#");
  //��������----------------end------------------------------------------ 
  //�ж�  
  RxCounter_3G=0;   
  RxState_3G = 0;  
  timeout =KEYTIMEOUT_3S*2;  //�ȴ�ʱ������
  IWDG_ReloadCounter(); //ι�� 
  while(--timeout)
  {	
    //����
    if(key_flag)
    {
      return 2;
    }  //��������
    if(RxState_3G == 0x66) //�յ��ظ�
    { 
      IWDG_ReloadCounter(); //ι�� 
      RxState_3G = 0;
      if((RxBuffer_3G[1]=='I')&&(RxBuffer_3G[2]=='P'))  //#IP*�ɹ�                         
        return 0;
      else 
        return 3;   //�п�������������	
    }
    
  } 
  return 1;  //ʧ��  
  
}




/*���غ�����*/
//void Download_backList(u16 DownCount,uchar ClassFlag)
u8 Download_backList(u16 DownCount,uchar ClassFlag)
{
  u8 BCC;
  u8 timesOut,set_success;
  u8 endaddr[3], sumvalue[3];
  u8 record_read[512];
  u16 nn,balckcard_num;
  u16 WREnd_addr,WRCount_addr,WRsum_addr,WRAll_count_addr,Update_OK_addr;//����������������������ַ��
  
  u16 j;
  u32 rqdown_count, rvdown_count, totalcount; //�������ţ����յ������
  u32 WREndflash_addr,maxflashcount;//flash��ַ
  u32 nowconut; //nowaddr  
  u8 listbuf[513];
  u8 temp_add_0[4];
  u8 rev_type;
     //,temp_add_1[4];
   
  int equalsite;
  //u32 listsum;
  
  IWDG_ReloadCounter(); //ι�� 
  //CPU������������-----------start----------------------------------
  //����ȫ������
  if(ClassFlag<=CPUReduceDownload)
  {
    //��ʾ��ϵͳά����----CPU�ܰ�������ǰ������
  //  lcd_clear(); 
    
   // display_lastinfor(11,95,0x32); // ϵͳά����   
    
    
 /*   if(DownCount == 1 && ClassFlag == CPUALLDownload)//��1����ʼȫ���ر����ʼ��
    {            
      //CPU��������ʼ����ַ 
      Initial_CPUBlackListAddr();   
    }  */
    
    OPEN_CLOSE_IRQ(IRQ_OPEN,ALL_IRQ);   
    rqdown_count=DownCount;
    //���������ᣬ��������ʧ��
    timesOut=0;
    
    //USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); 
    
    while(timesOut<4)
    { 
      IWDG_ReloadCounter(); //ι�� 
      //�����ɹ�---------start----------------   
     // if(open_3G(6)== 0) 
      // if(MU509link_net()== 0)
       if(1)   
      { 
          //������� �����ж�
        while(timesOut<4)
       // while(1)   
        {
          key_flag=0;
          IWDG_ReloadCounter(); //ι�� 
         // USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); 
          //���͵ڼ�������������(1:ʧ�ܣ�2��������0�ɹ�)RxBuffer_3G---rv_data
          
          //����������Ϊ����
          //set_success=MBto3G_BackListCommmand(rqdown_count,ClassFlag,RxBuffer_3G);

     //  ListIQ_BX_P3(0xB4,0x00);
          
        //  USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); 
           
           //  TCPLink_G3_0(1);
           // SLEEP_3G_0; //����
          //  delayms_break(1000);
          //  NET.poweron=WCDMAPWRON;
            delayms_break(100);  
           if(key_flag)
            return 1;
            
             if (ClassFlag == CPUALLDownload)
             {
               rev_type=0xB1;
               ListIQ_BX_P3(0xB1,rqdown_count);  
             }
              //ListIQ_BX_P3(0xB4,rqdown_count);
             
             else   if (ClassFlag == CPUIncreaseDownload)
             {
                  rev_type=0xB2;
                   ListIQ_BX_P3(0xB2,rqdown_count);
               
             }
             // ListIQ_BX_P3(0xB5,rqdown_count);
          
             else   if (ClassFlag == CPUReduceDownload)
             // ListIQ_BX_P3(0xB6,rqdown_count);
             {
               rev_type=0xB3;
              ListIQ_BX_P3(0xB3,rqdown_count);
             }
             
             else 
               return 1;
                
             //��ȡ��������
              if(ListIQ_PC_P_0()==0) 
              {
                //�ܰ����Ͱ�����
                
                    //  if ((recv_3G[10]==((rev_type>>4)&0x0F))&&(recv_3G[10]==(rev_type&0x0F))
                //68  69  
                
                //�������
                
                rev_type=Get_Optype(recv_3G,rev_type); 
                
            //    if ((recv_3G[68]==hex_to_asic(rev_type&0x0F))&&(recv_3G[69]==hex_to_asic(rev_type&0x0F)))
               
                if(rev_type==0)
                {
                  equalsite=1*getequal();//126
                  
            
                  
               
                  
                  
                  
                 
                                
                // rvdown_count=recv_3G[equalsite-14];//112-114
                  totalcount=asic_to_hex(recv_3G[equalsite-14])*16+asic_to_hex(recv_3G[equalsite-13]);//112-114
               //  rvdown_count=(rvdown_count<<8)+recv_3G[equalsite-12];  
                  totalcount=(totalcount<<8)+asic_to_hex(recv_3G[equalsite-12])*16+asic_to_hex(recv_3G[equalsite-11]);//112-114 
                  
                  
                 rvdown_count =asic_to_hex(recv_3G[equalsite-9])*16+asic_to_hex(recv_3G[equalsite-8]);//112-114 
                // totalcount= recv_3G[equalsite-9];  //117-119
                 rvdown_count=(rvdown_count<<8)+asic_to_hex(recv_3G[equalsite-7])*16+asic_to_hex(recv_3G[equalsite-6]);//112-114 
               //  totalcount=(totalcount<<8)+recv_3G[equalsite-7]; 
                 
                // balckcard_num=recv_3G[equalsite-4]; 
               //  balckcard_num=(balckcard_num<<8)+recv_3G[equalsite-2];///CPUBlackListByte*/
                balckcard_num=asic_to_hex(recv_3G[equalsite-4])*16+asic_to_hex(recv_3G[equalsite-3]);//112-114 
                balckcard_num=(balckcard_num<<8)+asic_to_hex(recv_3G[equalsite-2])*16+asic_to_hex(recv_3G[equalsite-1]);//112-114 
                balckcard_num=balckcard_num-1;
                 
                set_success=ListReal_MB_P4(8,listbuf);	
                  }
                  else
                  {
                    //���ݽ��մ���
                         return  1;
                  }

              }
              else
              {
                set_success=1;
              }
          
           //  delayms_break(1000);  
             
             
          if(set_success==0)
          {
            
          }
          else if(set_success==1)//���մ���--��������
          {
           timesOut++;
           
           if(timesOut==2)
                 return  1;
           
           // break;
           continue;
          /*  
            timesOut++; 
           // if( MBto3G_lkCommmand()!=0)
            if(MU509link_net()!=0)   
            {
              close_3G(2);
              break;
            }
            else
            {continue;} 
            */    
          } 
          else  //����
          {
       
            return  1;
            
          }  
          //USART_ITConfig(USART1, USART_IT_RXNE, DISABLE); 
          
          //�Ƚϰ��ţ������к������ĸ����Լ�BCC---��û�ж��壩-----start---------
      /*    rvdown_count=RxBuffer_3G[2];
          rvdown_count=(rvdown_count<<8)+RxBuffer_3G[3];  
          totalcount= RxBuffer_3G[0];  
          totalcount=(totalcount<<8)+RxBuffer_3G[1]; 
          */

         //if((RxBuffer_3G[0]==0)&&(RxBuffer_3G[1]==0))//(rvdown_count==0)&&û�к�����
           if(totalcount==0 )
          {
            //�����������FLash-------
           /* if(ClassFlag == CPUALLDownload)
            {         
              //�Ѻ��������ܰ�������������
              I2C_WriteS_24C(CPUBackListAllCount,RxBuffer_3G,2);               
            }      
            else if(ClassFlag == CPUIncreaseDownload)
            {
              //�Ѻ��������ܰ������浽������
              I2C_WriteS_24C(IncreaseCPUBackListAllCount,RxBuffer_3G,2);
            }     
            else if(ClassFlag == CPUReduceDownload)
            {
              //�Ѻ��������ܰ������浽������
              I2C_WriteS_24C(ReduceCPUBackListAllCount,RxBuffer_3G,2);
            }  
            
            //close_3G(3);*/ 
            return 1;  
            
          }
          
              
          IWDG_ReloadCounter(); //ι�� 
          
          if(rqdown_count==rvdown_count) //�������ŵ��ڽ��յ������
          {     
            //����������ĸ��� 
           /* balckcard_num=RxBuffer_3G[5]; 
            balckcard_num=(balckcard_num<<8)+RxBuffer_3G[6];///CPUBlackListByte*/
            
            //BCC
            
          //  BCC=RxBuffer_3G[balckcard_num/2-1];
          //  i=9;
            
            BCC=0xFF;
            for(j=0;j<balckcard_num;j++)//BCCУ�飬�����Ǵ�RxBuffer_3G[8]��ʼ
            {
              BCC=BCC^listbuf[j++];              
            }
            
            
          //  if(BCC==listbuf[balckcard_num])
            if (1) 
            {
              IWDG_ReloadCounter(); //ι�� 
              timesOut=0; //�ɹ��ˣ�������4�λ���
              rqdown_count++;
              
              
              //�����󵽵İ�����������
             // fll(rqdown_count,RxBuffer_3G+2,2);				
              // I2C_WriteS_24C(CPUBackListRequireCount,RxBuffer_3G+2,2);	
              
              //�����������FLash-------
                /*    temp_add_0[0]=(rvdown_count>>24&0xff);
                temp_add_0[1]=(rvdown_count>>16&0xff);   
                temp_add_0[2]=(rvdown_count>>8&0xff);
                temp_add_0[3]=(rvdown_count&0xff);             
                  
              
                temp_add_1[0]=(totalcount>>24&0xff);
                temp_add_1[1]=(totalcount>>16&0xff);  
                temp_add_1[2]=(totalcount>>8&0xff);
                temp_add_1[3]=(totalcount&0xff);*/
                
              if(ClassFlag == CPUALLDownload)
              {   
               // I2C_WriteS_24C(CPUBackListRequireCount,temp_add_0,2);	
		//�Ѻ��������ܰ�������������
               // I2C_WriteS_24C(CPUBackListAllCount,temp_add_1,2);
                WREnd_addr=CPUBlackList_EndAddr; //������ַ
                WRsum_addr=CPUBlackList_Count; //������ַ
                WRCount_addr=CPUBackListRequireCount; //������ַ
                WRAll_count_addr=CPUBackListAllCount;
                Update_OK_addr=Today_Update_OK;
               // maxflashcount=MAXFlashCPUBlackAdd-MINFlashCPUBlackAdd;
                maxflashcount=MAXFlashCPUBlackAdd; 
              }      
              else if(ClassFlag == CPUIncreaseDownload)
              {
           
               // I2C_WriteS_24C(IncreaseCPUBackListRequireCount ,temp_add_0,2);	
		//�Ѻ��������ܰ������浽������
               // I2C_WriteS_24C(IncreaseCPUBackListAllCount,temp_add_1,2);
                WREnd_addr=CPUBlackList_EndAddr_Increase;
                WRsum_addr=CPUBlackList_Count_Increase;
                WRCount_addr=IncreaseCPUBackListRequireCount; 
                WRAll_count_addr=IncreaseCPUBackListAllCount;
                 Update_OK_addr=Today_Update_OK+1;
                   //     maxflashcount=MAXFlashIncreaseCPUBlackAdd-MINFlashIncreaseCPUBlackAdd;
                   maxflashcount=MAXFlashIncreaseCPUBlackAdd;     
              }     
              else if(ClassFlag == CPUReduceDownload)
              {        
               // I2C_WriteS_24C(ReduceCPUBackListRequireCount ,temp_add_0,2);
		//�Ѻ��������ܰ������浽������
               // I2C_WriteS_24C(ReduceCPUBackListAllCount,temp_add_1,2);
                WREnd_addr=CPUBlackList_EndAddr_Reduce; //�洢λ��
                WRsum_addr=CPUBlackList_Count_Reduce; //�Ѿ�������
                WRCount_addr=ReduceCPUBackListRequireCount; 
                 WRAll_count_addr=ReduceCPUBackListAllCount;
                   Update_OK_addr=Today_Update_OK+2;
                 maxflashcount=MAXFlashReduceCPUBlackAdd;
              } 
              else
              { 

                return 1;
              }
              
              //�жϺ����������Ƿ�Ϸ�-------------------
              if((balckcard_num>=CPUBlackListByte)&&(balckcard_num%CPUBlackListByte==0))
              {
                IWDG_ReloadCounter(); //ι��
                I2C_ReadS_24C(WREnd_addr,endaddr,3); //�������ڴ�ŵĵ�ֵַ
               // I2C_ReadS_24C(WRCount_addr,countvalue,3); //�������ڵ�����ֵ
                
                //������
                
                
                if(WRsum_addr<maxflashcount)
                {
               
                
                //������������flash
                  
               if(key_flag)
              return 1;
                SPI_FLASH_Init();
                WREndflash_addr=hcl(endaddr,3);   //ע��RxBuffer_3G+8 
                if((WREndflash_addr&0xFFFF)==0) //һ�������Ȳ���������д���ݽ�ȥ�������ȵ��ж� ��ʼʱ��ַ�ǲ���4K�ֽڿռ�Ŀ�ʼ��ַ��
                  SPI_FLASH_SectorErase(WREndflash_addr);
                else if(((WREndflash_addr+8)&0xFFFF)==0)
                  SPI_FLASH_SectorErase(WREndflash_addr+8);
                else if(((WREndflash_addr+16)&0xFFFF)==0)
                  SPI_FLASH_SectorErase(WREndflash_addr+16);
                
               // SPI_FLASH_BufferWrite(RxBuffer_3G+8,WREndflash_addr,balckcard_num);
                SPI_FLASH_BufferWrite(listbuf,WREndflash_addr,balckcard_num);
                
                if(key_flag)
                 return 1;
                
                //------------�ж��Ƿ�д����ȷ-------------------------------------
                SPI_FLASH_BufferRead(record_read,WREndflash_addr,balckcard_num);
                 if(key_flag)
                 return 1;
                for(nn=0;nn<balckcard_num;nn++)
                {
                  //if(record_read[nn]!=RxBuffer_3G[nn+8]) break; 
                   if(record_read[nn]!=listbuf[nn]) break; 
                }
                if(nn!=balckcard_num)
                {
                  SPI_FLASH_Init();
                  if((WREndflash_addr&0xFFFF)==0) //һ�������Ȳ���������д���ݽ�ȥ�������ȵ��ж� ��ʼʱ��ַ�ǲ���4K�ֽڿռ�Ŀ�ʼ��ַ��
                    SPI_FLASH_SectorErase(WREndflash_addr);
                  else if(((WREndflash_addr+8)&0xFFFF)==0)
                    SPI_FLASH_SectorErase(WREndflash_addr+8);
                  else if(((WREndflash_addr+16)&0xFFFF)==0)
                    SPI_FLASH_SectorErase(WREndflash_addr+16);
                //  SPI_FLASH_BufferWrite(RxBuffer_3G+8,WREndflash_addr,balckcard_num);
                      SPI_FLASH_BufferWrite(listbuf,WREndflash_addr,balckcard_num);
                }
                //------------�ж��Ƿ�д����ȷ-------------------------------------
               // CPUBlackList_Count
                
                //��ַ
                 }
                
                
                 if(key_flag)
                return 1;
                WREndflash_addr+=balckcard_num;         
                fll(WREndflash_addr,endaddr,3);  
                I2C_WriteS_24C(WREnd_addr,endaddr,3);
                
                
                //�Ѻ���������������������
              /*  nowconut= hcl(countvalue,3);
                nowconut+=balckcard_num/CPUBlackListByte;
                fll(nowconut,countvalue,3); 
                I2C_WriteS_24C(WRCount_addr,countvalue,3); */
                
                
                I2C_ReadS_24C(WRsum_addr,sumvalue,3);  
                nowconut= hcl(sumvalue,3);
                nowconut+=balckcard_num/CPUBlackListByte;
                fll(nowconut,sumvalue,3); 
                I2C_WriteS_24C(WRsum_addr,sumvalue,3);   
                
                
                //����
                
                
         
                temp_add_0[0]=(rvdown_count>>8&0xff);
                temp_add_0[1]=(rvdown_count&0xff);         
                I2C_WriteS_24C(WRCount_addr ,temp_add_0,2);	
                
          
                temp_add_0[0]=(totalcount>>8&0xff);
                temp_add_0[1]=(totalcount&0xff);         
                I2C_WriteS_24C(WRAll_count_addr ,temp_add_0,2);	    
                
                  
                  
                
               // balckcard_num
              //  sumvalue[3]
               /* I2C_WriteS_24C(WRsum_addr,sumvalue,3);  
                nowconut= hcl(sumvalue,3);
                nowconut+=balckcard_num/CPUBlackListByte;
                fll(nowconut,sumvalue,3); 
                I2C_WriteS_24C(WRsum_addr,sumvalue,3);   */  
                
                
                
              }
    
             
                
              if(rqdown_count>totalcount)
              {   
                //close_3G(3);
                //
                
                temp_add_0[0]=0x01;
                I2C_WriteS_24C(Update_OK_addr ,temp_add_0,1);	 
                return 0;
              }
              
            }
            else
              timesOut++; //BCC����
          }            
          else
            timesOut++;  //����Ų���                     
          //�Ƚϰ��ţ������к������ĸ����Լ�BCC---��û�ж��壩-----end---------    
        }
        if( timesOut>4)
          break;
      } 
      //�����ɹ�---------end---------------- 
      else
      {
        if(key_flag==0)
        { 
         // close_3G(1);
          return 1 ;
        }
       // close_3G(2); 
        timesOut++;
      } 
    }
  }
   return 1 ;
}
 void settimefun(u8 *rev_bk_data)
{
  u8 data[16]; 
  u8 time1[5],time2[5];
  u16 timediff;
  //u8   recv_3G_data[GSML];
  int i,j;
  i=0;
  while(i<GSML-6)
  {
 
    if ((rev_bk_data[i]=='T')&&
        (rev_bk_data[i+1]=='i')&&
        (rev_bk_data[i+2]=='m')&&
        (rev_bk_data[i+3]=='e'))
    {
      
      
                          judge_get_time();
                          
                          
                          data[4]=(asic_to_hex(rev_bk_data[i+8])<<4)|asic_to_hex(rev_bk_data[i+9]);	  //��
                          data[3]=(asic_to_hex(rev_bk_data[i+11])<<4)|asic_to_hex(rev_bk_data[i+12]);	  //��
                          data[2]=(asic_to_hex(rev_bk_data[i+14])<<4)|asic_to_hex(rev_bk_data[i+15]);	  //��
                          
                          data[1]=(asic_to_hex(rev_bk_data[i+17])<<4)|asic_to_hex(rev_bk_data[i+18]);	  //ʱ
                          data[0]=(asic_to_hex(rev_bk_data[i+20])<<4)|asic_to_hex(rev_bk_data[i+21]);	  //��				
                          data[6]=mathweek(data[4],data[3],data[2]);	//��������
                          
                        for( j = 0; j < 5; j++)
                          {
                            time1[j]=data[4-j];
                           
                          }
                          
                          
                          
                          //time1
                          for( j = 0; j < 5; j++)
                          {
                            time2[j]=time_BCD[4-j];
                           
                          }
                          
                          //�ж�
                        for( j = 0; j < 5; j++)
                        {
                          if (time1[j]!=time2[j])
                            break;
                          
                          
                        }
                        
                         if(j==5)
                         {
                           timediff=1;
                         
                         }
                        else
                        {
                           timediff=Count_time_setret(time1,time2);
                           
                           if (timediff==0)
                           {
                           
                              timediff=Count_time_setret(time2,time1);
                           }
                           
                        
                        }
                        
                          
                        
                     
                          if(timediff>=3)
                            
                         //   <Time><2015-10-20|11:30:40></Time>
                         {
                      /*    data[4]=(asic_to_hex(rev_bk_data[i+8])<<4)|asic_to_hex(rev_bk_data[i+9]);	  //��
                          data[3]=(asic_to_hex(rev_bk_data[i+11])<<4)|asic_to_hex(rev_bk_data[i+12]);	  //��
                          data[2]=(asic_to_hex(rev_bk_data[i+14])<<4)|asic_to_hex(rev_bk_data[i+15]);	  //��
                          
                          data[1]=(asic_to_hex(rev_bk_data[i+17])<<4)|asic_to_hex(rev_bk_data[i+18]);	  //ʱ
                          data[0]=(asic_to_hex(rev_bk_data[i+20])<<4)|asic_to_hex(rev_bk_data[i+21]);	  //��				
                          data[6]=mathweek(data[4],data[3],data[2]);	//��������
                     */
                        
                         
                          set_current_time(data);
                           
                          judge_get_time();                    
                         
                         }
                          


     
     break;
    }
    
    if(rev_bk_data[i]=='*') 
      break;   
    
    i++;
  }


}


void make_record_btry(void)
{
     u8 record_Alarm_0[16]; 
     record_Alarm_0[0]=0xEA;            //1����¼���� 
  
     record_Alarm_0[1]=0x00;            //2����������  
     record_Alarm_0[2]=0x00;   
     record_Alarm_0[3]=0x00;   
     record_Alarm_0[4]=0x00;   
  

      record_Alarm_0[5]=time_BCD[4]; 
      record_Alarm_0[6]=time_BCD[3]; 
      record_Alarm_0[7]=time_BCD[2]; 
      record_Alarm_0[8]=time_BCD[1]; 
      record_Alarm_0[9]=time_BCD[0]; 
      
      record_Alarm_0[10]=battery; 
      
         for(int i = 0; i < 3; i++)
        {
          

     if(TestADC1()!=2)
    {
            
      
           record_Alarm_0[11]=(ADCinf.evenvalue>>8)&0xFF;     
           record_Alarm_0[12]=ADCinf.evenvalue&0xFF;  
      
      
      
     break;
     

    }
    else
    {
           record_Alarm_0[11]=0xFF;        
           record_Alarm_0[12]=0xFF;  
    }
   
       } 
    

        
        record_Alarm_0[13]=0x00;   
        record_Alarm_0[14]=0x00;
        record_Alarm_0[15]=0x00;  
      
     //���� 
        
        
      MBto3G_Record(AlarmRecord,0x01, record_Alarm_0);  
     

      
}

void Battery_alarm_RC(u8 falge_0)
{
 u8 timesOut_0,G3_state_0;
   u8  BUF_NET_LINK_1[1];
   timesOut_0=0;
   if  ((falge_0)||((time[0]==0x00) ||(time[0]==0x01))) 
   {
     
        
     while(timesOut_0<4)
     { 
       
     
      if (networkOKflag==0)
      {
      G3_state_0=MU509link_net();
      
            if(G3_state_0== 0)   
       //  if(1)     
       { 
             BUF_NET_LINK_1[0]=0x00;
             I2C_WriteS_24C(NET_MAX_LINK_COUNT,BUF_NET_LINK_1,1); 
             
         break;
         
         
         }
       else  if(G3_state_0== KEYOP_RETURN)   
       {
       return;
         
       }
      else
      {
             I2C_ReadS_24C(NET_MAX_LINK_COUNT,BUF_NET_LINK_1,1); 
             BUF_NET_LINK_1[0]++;
             I2C_WriteS_24C(NET_MAX_LINK_COUNT,BUF_NET_LINK_1,1); 
        
            timesOut_0++;
      }
      
      
      }
      else
      {
      
        break;
      
        
      }
     timesOut_0++;
   
   
    }
    
    
    
    //���͵���

   make_record_btry();
        
}
}


void BackList_Mechanism(u8 min)
{
  
  //u8 buffer[6];
  u8 require_buff[3],all_buff[2],temp_falg_0[2];  
  u16 require_num, all_num;      
  u8 timesOut_0,reslut_0;
  u8 G3_state_0;
  u8  BUF_NET_LINK_1[1];
  //1CPU������������ ���� �ֶ�OR�Զ�---------start---------------
  //I2C_ReadS_24C(CPUBlackUpdateClass,buffer,6);
  //if(buffer[0] == AUTO_UPDATE)
//  if(1) 
  
    
  #if (TEST==1)
     if(1) 
  #else
   //  if ((time[1]==0x04)&&(time[0]>=0x01)&&(time[0]<=0x1E))
      if ((time[1]>=0x03)&&(time[1]<=0x04)) 
  #endif
  
 // if ((time[1]==0x04)&&(time[0]>=0x01)&&(time[0]<=0x1E))
  {
    //1\00��XX�֣�1�Ŵӵ�һ������ȫ������������1�Ŵӵ�һ������������������
   // if(time_BCD[1] == 0x00 && time_BCD[0] == 0x01)
    
    
  /*  if(time_BCD[1] == 0x00 && (time_BCD[0]==0x00||time_BCD[0] == 0x01))
    {
         require_buff[0]=0x00;
         I2C_WriteS_24C(Today_Update_OK,require_buff,1); 
    }
    */
   
    //if(time_BCD[0] == 0x01)  
    if(1)  
    {     
      //if(time_BCD[2] == 0x01) //ÿ����1�Ŵӵ�һ������ȫ������
      
      //����0��
      
       // USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); 
     
      I2C_ReadS_24C(Today_Update_OK,require_buff,3); 
     //��ʱ���
    // if((require_buff[0]==0x01)&&(require_buff[1]==0x01)&&(require_buff[2]==0x01)&&(time_BCD[0] != 0x01))
       if((require_buff[0]==0x01)&&(require_buff[1]==0x01)&&(require_buff[2]==0x01))    
    //  if(1)   
     {
      
       
       //ȫ���������
       
       
     }
     else
     {
     
 
        
    IWDG_ReloadCounter();    
      
     timesOut_0=0;     
        
     while(timesOut_0<4)
    { 
     
      if (networkOKflag==0)
      {
      G3_state_0=MU509link_net();
     // if(MU509link_net()== 0)
       if(G3_state_0== 0)   
       //  if(1)     
       { 
             BUF_NET_LINK_1[0]=0x00;
             I2C_WriteS_24C(NET_MAX_LINK_COUNT,BUF_NET_LINK_1,1); 
         break;
         
         
         }
       else  if(G3_state_0== KEYOP_RETURN)   
       {
       return;
         
       }
      else
      {
             I2C_ReadS_24C(NET_MAX_LINK_COUNT,BUF_NET_LINK_1,1); 
             BUF_NET_LINK_1[0]++;
             I2C_WriteS_24C(NET_MAX_LINK_COUNT,BUF_NET_LINK_1,1); 
        
            timesOut_0++;
      }
        
       }
      else
      {
          break;
      
      }
      }
     
     
    if(timesOut_0==4)
    {
      return ;
    }
    
        //����汾
    
          delayms_keybreak(100); 
          ListIQ_PC_P1();
          reslut_0=ListIQ_PC_P_0();
           
          if(reslut_0==0) 
          {
            //�ж��յ����ǲ���BO
          //  if((recv_3G[68]=='B')&&(recv_3G[69]=='0'))
                 if(Get_Optype(recv_3G,0xB0)==0)
                 
            {
            
            
            
            ListACK_MB_P2(8);

            I2C_WriteS_24C(CARD_BIKE_BLACKLISTALL_VERSION, SYS_LIST.version[1],2);
            delayms(50);
            I2C_WriteS_24C(CARD_BIKE_BLACKLISTALL_VERSION+2, SYS_LIST.version[2],2);
            delayms(50);
            I2C_WriteS_24C(CARD_BIKE_BLACKLISTALL_VERSION+4, SYS_LIST.version[3],2);
            delayms(50);
         
             
            I2C_WriteS_24C( CPUBackListAllCount, SYS_LIST.bagnum[1],2); 
            I2C_WriteS_24C( IncreaseCPUBackListAllCount, SYS_LIST.bagnum[2],2); 
            I2C_WriteS_24C( ReduceCPUBackListAllCount, SYS_LIST.bagnum[3],2); 
                            
            }
            else
            {
            
               return;
            }
         
          }
          else
          {
            return;
          
          }

      

     
     
       if(SYS_LIST.updateflag[1])    
      {
        Initial_CPUBlackListAddr(0);
        
        // for(int i = 0; i < 10; ++i)
        {
          
          
       if(  Download_backList(1,CPUALLDownload))
         return ;
         
        // delayms(100);
        }
      }
      else
      {
    
      
      I2C_ReadS_24C(CPUBackListRequireCount,require_buff,2);                 
      I2C_ReadS_24C(CPUBackListAllCount,all_buff,2);
      require_num = hcl(require_buff,2);                  
      all_num = hcl(all_buff,2);
      
      if(require_num < all_num)                                                                
      {   
       
       //    Download_backList(require_num,CPUALLDownload); 
      if(  Download_backList(require_num,CPUALLDownload))
         return ;
        
      }
      else
      {
              //�������سɹ�
                temp_falg_0[0]=0x01;
                I2C_WriteS_24C(Today_Update_OK ,temp_falg_0,1);	 
      
      }
      
      
      
      }
       //��/�������������أ��ӵ�1��ȫ����
      
 
       if(SYS_LIST.updateflag[2])     
      {
        Initial_CPUBlackListAddr(1);   
      //  Download_backList(1,CPUIncreaseDownload); 
        
       if(  Download_backList(1,CPUIncreaseDownload))
         return ;
     
     
       // Download_backList(1,CPUReduceDownload);
       // IWDG_ReloadCounter(); //ι�� 
       // Download_backList(1,CPUReduceDownload);
      }
      else
      {
    

      I2C_ReadS_24C(IncreaseCPUBackListRequireCount,require_buff,2);                 
      I2C_ReadS_24C(IncreaseCPUBackListAllCount,all_buff,2);
      require_num = hcl(require_buff,2);                  
      all_num = hcl(all_buff,2);
      
      if(require_num < all_num)                                                                
      {     
      //  Download_backList(require_num,CPUIncreaseDownload);  
        
     if(   Download_backList(require_num,CPUIncreaseDownload))
         return ;
      }
           else
      {
              
                temp_falg_0[0]=0x01;
                I2C_WriteS_24C(Today_Update_OK+1 ,temp_falg_0,1);	 
      
      }
      
   }
      
       if(SYS_LIST.updateflag[3])   
      {
           Initial_CPUBlackListAddr(2);   
         if(  Download_backList(1,CPUReduceDownload))
            return ; 
      
      }
      else
      {
   
      I2C_ReadS_24C(ReduceCPUBackListRequireCount,require_buff,2);                 
      I2C_ReadS_24C(ReduceCPUBackListAllCount,all_buff,2);
      require_num = hcl(require_buff,2);                  
      all_num = hcl(all_buff,2);
      
      if(require_num < all_num)                                                                
      {     
        
        //  Download_backList(require_num,CPUReduceDownload);  
               if(  Download_backList(require_num,CPUReduceDownload))
            return ; 
      
        
      }    else
      {
              
                temp_falg_0[0]=0x01;
                I2C_WriteS_24C(Today_Update_OK+2 ,temp_falg_0,1);	 
      
      } 
      
      }
      
      
      read_Blacklist_to_SRAM(CPUBlackListByte); 
      
      IWDG_ReloadCounter(); //ι�� 
      
    }
  }
    
    //�ϵ���������
    //2\ÿ��01��XX�֣�����CPU������ȫ��(δ��ɵĲ���)
  /*  
    else if((time_BCD[1] == 1 && time_BCD[0] == min)||(time_BCD[2] == 0x01 &&time_BCD[1] == 2 && time_BCD[0] == min))
    { 
      //�ȶ��� �Ƿ���Ҫ�ϵ�����������
      I2C_ReadS_24C(CPUBackListRequireCount,require_buff,2);                 
      I2C_ReadS_24C(CPUBackListAllCount,all_buff,2);
      
      require_num = hcl(require_buff,2);                  
      all_num = hcl(all_buff,2);
      
      if(require_num <= all_num)                                                                
      {           
        Download_backList(require_num,CPUALLDownload);  
        read_Blacklist_to_SRAM(CPUBlackListByte);
        IWDG_ReloadCounter(); //ι�� 
      }                                        
    } 
    //3\����1�ŵ�02��XX�֣���/����������(δ������ɵĲ���)
    else if(time_BCD[2] != 0x01 &&time_BCD[1] == 2 && time_BCD[0] == min)
    {
      //�ȶ��� �Ƿ���Ҫ�ϵ�����������
      I2C_ReadS_24C(IncreaseCPUBackListRequireCount,require_buff,2);                 
      I2C_ReadS_24C(IncreaseCPUBackListAllCount,all_buff,2);
      
      require_num = hcl(require_buff,2);                  
      all_num = hcl(all_buff,2);  
      
      if(require_num <= all_num)                                                                
      {           
        Download_backList(require_num,CPUIncreaseDownload);  
        read_Blacklist_to_SRAM(CPUBlackListByte);  
        IWDG_ReloadCounter(); //ι�� 
      }        
      //�ȶ��� �Ƿ���Ҫ�ϵ�����������
      I2C_ReadS_24C(ReduceCPUBackListRequireCount,require_buff,2);                 
      I2C_ReadS_24C(ReduceCPUBackListAllCount,all_buff,2);
      
      require_num = hcl(require_buff,2);                  
      all_num = hcl(all_buff,2);
      
      if(require_num <= all_num)                                                                
      {           
        Download_backList(require_num,CPUReduceDownload);  
        read_Blacklist_to_SRAM(CPUBlackListByte); 
        IWDG_ReloadCounter(); //ι�� 
      }       
    }
    */
  }
  
  
}

