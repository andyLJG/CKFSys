/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "touch_key.h"
#include "delay_systick.h"
#include "main.h" 
#include "coin.h" 
#include "LM240128C.h"  //����
#include "save_record.h"
#include "new_mifare.h"
#include "Menu.h"
#include "MemoryAssign.h"


u8 key_flag;   	  //������־
u8 wake_flag;     //32S�ж�

//
/*uart1��3Gͨ�ţ�*/
u8   esflag_3G;
u8   OK_flag_3G;
u8   OK_flag_POS;
u16  s_head_3G,s_tail_3G; 
u8   recv_3G[GSML];

u8   RxState_3G;		//('*'����ʱ=0x66) ���������ݱ�־λ
u16  RxCounter_3G;              //�������ݵĸ���

/*uart2Ӳ�һ�*/
u8   esflag;
u8   s_head,s_tail; 
u8   recvcoin[COINL];

/*uart3�жϽ��գ�������ģ��*/
u16 RxCounter_Card;                //���տ����ݵĸ���
u8  RxBuffer_Card[120];	          //���濨����
u8  RxState_Card;	          //(0x77) �����꿨���ݱ�־λ

///*uart4�����⣩*/	//huangfeng
//u16 RxCounter_IrDA=0;                  //�������ݵĸ���
//u8  RxBuffer_IrDA[300];	         //��������
//u8  RxState_IrDA=0;			//('*'=0xff) ���������ݱ�־λ

/*uart5�жϽ��գ��¹���ģ��*/
//u16 RxCounter_Credit;                //���տ����ݵĸ���
//u8  RxBuffer_Credit[120];	     //���濨����
//u8  RxState_Credit;	             //(0xff) �����꿨���ݱ�־λ

/** @addtogroup STM32F10x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
 
  
  while (1)
  {
  }
}

/*huangfeng------tiaoshi-----------------------
__asm void wait()
{
      BX lr
}
void HardFault_Handler(void)
{
    // Go to infinite loop when Hard Fault exception occurs 
       wait();
}
------------------------------------------------*/


/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)			 //ϵͳ��ʱ��SysTick�жϺ���
{ 

}

/*------------------------------------------------------------------
----------------5�����ڽ����жϺ���---------------------------------
------------------------------------------------------------------*/
/*3Gͨ��----��ʽ#*��ʽ*/
void USART1_IRQHandler(void)
{
  
  //������-�Ͽ�-����
 /* unsigned char Rxdata;
  
  if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
  {     	
    Rxdata = USART_ReceiveData(USART1); 
    recv_3G[s_head_3G++] = Rxdata;     		
    if(s_head_3G==GSML)
      s_head_3G=0;
    if(s_head_3G==s_tail_3G)  
     {  
       s_tail_3G++;
       if(s_tail_3G==GSML) 
       s_tail_3G=0;  
     }
     esflag_3G=1;  
  } */
   unsigned char Rxdata;
   if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
  {     
      Rxdata = USART_ReceiveData(USART1); 

    //AT
     if((Rxdata=='A')&&(s_head_3G==0))
     {
      recv_3G[s_head_3G++] = Rxdata; 
    }
    else if((recv_3G[0]=='A')&&s_head_3G>0)
    {  
      recv_3G[s_head_3G++] = Rxdata; 
      if((recv_3G[s_head_3G-2]=='O')&&(Rxdata=='K'))
      {
        OK_flag_3G=1;
      }
      
    } 
    
    
    //ip
    
      if((Rxdata=='^')&&(s_head_3G==0))
      {
         recv_3G[s_head_3G++] = Rxdata; 
      }
      else   if((Rxdata=='I')&&s_head_3G==1)
      {
         recv_3G[s_head_3G++] = Rxdata; 
      }  
      else if((recv_3G[0]=='^')&&(s_head_3G>0)&&(recv_3G[1]=='I'))
     {  
      recv_3G[s_head_3G++] = Rxdata; 
      if(Rxdata=='*')
      {
        OK_flag_3G=1;
      }
      
    } 
    
    
    //����
    /*    if((Rxdata == '#')&&(s_head_3G==0))
    {
          recv_3G[s_head_3G++] = Rxdata; 
    }
    if((Rxdata == '*')&&(recv_3G[0] == '#'))
    {
        recv_3G[s_head_3G++] = Rxdata; 
      
        OK_flag_3G=1;

    }*/
    
    
    
    
    
      esflag_3G=1;  
  
  }
}


//void USART2_IRQHandler(void)
//{
//  unsigned char Rxdata;
//  if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
//  {     	
//    Rxdata = USART_ReceiveData(USART2); 
//    recvcoin[s_head++] = Rxdata;     		//������
//    if(s_head==COINL)
//      s_head=0;
//    if(s_head==s_tail)  //��s_head++������s_head==s_tail��˵��s_head��ǰ���ֿ�ʼ����֮ǰ���յ�����Ϣ
//     {  
//       s_tail++;
//       if(s_tail==COINL) 
//       s_tail=0;  
//     }
//     esflag=1;  //���ڽ��յ���Ϣ�ı�־
//  }   
//}
 
/*Mifare������--------huangfeng------2013.5.8-------------*/
//void USART3_IRQHandler(void)
//{  
//  unsigned char Rxdata; 
//  
//  if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
//  {
//    
//    Rxdata = USART_ReceiveData(USART3); 
//    if(RxCounter_Card==0 && Rxdata!=0x00)
//      RxCounter_Card=0;
//    else
//    {
//      RxBuffer_Card[RxCounter_Card++] = Rxdata; 
//      if((RxCounter_Card == (RxBuffer_Card[2] + 5))&& (RxBuffer_Card[RxCounter_Card - 1] == 0x03) )
//        RxState_Card=0x66;
//    }
//  }  
//}
void USART3_IRQHandler(void)
{  
  unsigned char Rxdata; 
  //unsigned char RxdataArr[120]; 
  if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
  {
    
    Rxdata = USART_ReceiveData(USART3 ); 
   // RxdataArr=USART_ReceiveData(USART3); 
   // if(RxReadCard.RxCounter_Card==0 && Rxdata!=0x00)
    if((Rxdata==0xBD)&&RxReadCard.RxCounter_Card==0)
    {
      RxReadCard.RxBuffer_Card[RxReadCard.RxCounter_Card] = Rxdata;
      RxReadCard.RXBCC_Card^=RxReadCard.RxBuffer_Card[RxReadCard.RxCounter_Card];
      RxReadCard.RxCounter_Card++;   
    }
    else if((RxReadCard.RxBuffer_Card[0]==0xBD)&&RxReadCard.RxCounter_Card>0)
    {
      
      RxReadCard.RxBuffer_Card[RxReadCard.RxCounter_Card] = Rxdata;
      RxReadCard.RXBCC_Card^=RxReadCard.RxBuffer_Card[RxReadCard.RxCounter_Card];
      RxReadCard.RxCounter_Card++;
      
      //���Ƚ����ж�
     // if(RxReadCard.RxBuffer_Card[1] && RxReadCard.RxCounter_Card == (RxReadCard.RxBuffer_Card[1]+1))//���ݽ���
     if(RxReadCard.RxBuffer_Card[1]+2 ==(RxReadCard.RxCounter_Card)) 
      {
        RxReadCard.RXBCC_Card^=Rxdata;
        if( RxReadCard.RXBCC_Card==  RxReadCard.RxBuffer_Card[RxReadCard.RxCounter_Card-1])
          RxReadCard.RxState_Card=0x66; //�ɹ�
        else
          RxReadCard.RxState_Card=0x55; //����ʧ�ܣ����ݳ���
      
      }

    }
  }  
}
/*����ͨ�ţ�����������û�в����жϽ��գ�������ֻ�ǲ���*/
void UART4_IRQHandler(void)
{
 /*if(USART_GetITStatus(UART4, USART_IT_RXNE) != RESET)
  {
    unsigned char Rxdata; 	
    Rxdata = USART_ReceiveData(UART4); 
    RxBuffer_IrDA[RxCounter_IrDA++] = Rxdata;     		
    if(Rxdata == '*')		
      {
        RxState_IrDA= 0xFF;
      }		
  }  */

  unsigned char Rxdata; 
  //unsigned char RxdataArr[120]; 
  if(USART_GetITStatus(UART4, USART_IT_RXNE) != RESET)
  {
    
    Rxdata = USART_ReceiveData(USART3 ); 

    if((Rxdata==0x28)&&RxPOSdot.RxCounter_POS==0)
    {
      RxPOSdot.RxBuffer_POS[RxPOSdot.RxCounter_POS] = Rxdata;
      RxPOSdot.RXBCC_POS^=RxPOSdot.RxBuffer_POS[RxPOSdot.RxCounter_POS];
      RxPOSdot.RxCounter_POS++;   
    }
    else if((RxPOSdot.RxBuffer_POS[0]==0x28)&&RxPOSdot.RxCounter_POS>0)
    {
      
      RxPOSdot.RxBuffer_POS[RxPOSdot.RxCounter_POS] = Rxdata;
      RxPOSdot.RXBCC_POS^=RxPOSdot.RxBuffer_POS[RxPOSdot.RxCounter_POS];
      RxPOSdot.RxCounter_POS++;   
      

      if(Rxdata==0xcc) 
      {
        RxPOSdot.RxState_POS=0x55; 
        OK_flag_POS=0x01;
      }

    }
  }  
}


//void UART5_IRQHandler(void)
//{
//  if(USART_GetITStatus(UART5, USART_IT_RXNE) != RESET)
//  {
//    unsigned char Rxdata; 	
//    Rxdata = USART_ReceiveData(UART5); 
////    RxBuffer_IrDA[RxCounter_IrDA++] = Rxdata;     		//������
////    if(Rxdata == '*')		 //&&(RxCounter_Car>=4)
////      {
////        RxState_IrDA= 0xFF;//���ս��� 
////      }		
//  } 
//
//}
/*Ӳ�һ�ѭ������*/
void UART5_IRQHandler(void)
{
  unsigned char Rxdata;
  if(USART_GetITStatus(UART5, USART_IT_RXNE) != RESET)
  {     	
    Rxdata = USART_ReceiveData(UART5); 
    recvcoin[s_head++] = Rxdata;
    
    //text
   /* if (Rxdata=='H')
    {    
      s_head=0x01;
      recvcoin[0] = Rxdata; 
    }*/


    

    if(s_head==COINL)
      s_head=0;
    if(s_head==s_tail)  //��s_head++������s_head==s_tail��˵��s_head��ǰ���ֿ�ʼ����֮ǰ���յ�����Ϣ
     {  
       s_tail++;
       if(s_tail==COINL) 
       s_tail=0;  
     }                                        
     esflag=1;  //���ڽ��յ���Ϣ�ı�־
    
  }  
}


//�Ŵż��
void EXTI3_IRQHandler(void)
{
  if(EXTI_GetITStatus(EXTI_Line3) != RESET) //  
  {
    wake_flag = Wakeup_DOOR; 
    OPEN_CLOSE_IRQ(IRQ_CLOSE,DOOR_IRQ);
    if( MeterInfor.sleepflag==1)
    {   
      SYSCLKConfig_STOP();
      sleepout(); 
    }
    delay(100);
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_3)!=(uint8_t)Bit_RESET)
    {
      Buzz_0;
      //      ERRLED_ON; 
      judge_get_time();
      
      make_record_Alarm(Open_Door_0,0,0,0xa0);


      
      //      make_record(Wakeup_32S,0,0xa1); //�Ƿ��Ŵż�¼
      while((GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_3)!=(uint8_t)Bit_RESET))
      { IWDG_ReloadCounter();} //ι��
      Buzz_1;
      //      ERRLED_OFF;
    }
    else
      ;
    
  } 
  EXTI_ClearITPendingBit(EXTI_Line3);   
  OPEN_CLOSE_IRQ(IRQ_OPEN,DOOR_IRQ);
}





///*******************************************************************************
//	* Function Name  : EXTI9_5_IRQHandler
//	* Description	 : This function handles External lines 9 to 5 interrupt request.
//	* Input 		 : None
//	* Output		 : None
//	* Return		 : None
//*******************************************************************************/
void EXTI9_5_IRQHandler(void)
{

  if(EXTI_GetITStatus(EXTI_Line6) != RESET) //����
  {			
    delay(10);
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_6)==(uint8_t)Bit_RESET)
    {
      key_flag=1;
      wake_flag=0;	
    }
    //    EXTI_ClearITPendingBit(EXTI_Line6);
  }
  else if(EXTI_GetITStatus(EXTI_Line7) != RESET) //Ӳ��
  {	
    wakecoininf.wakecoin_flag=Wakeup_COIN;	
    key_flag=2;
//    EXTI_ClearITPendingBit(EXTI_Line7);
  }  
  
  else if(EXTI_GetITStatus(EXTI_Line5) != RESET) //1\32S�ж�����PB5
  {    
    wake_flag = Wakeup_32S;
//    EXTI_ClearITPendingBit(EXTI_Line5);
  }  
  EXTI_ClearITPendingBit(EXTI_Line5);
  EXTI_ClearITPendingBit(EXTI_Line6);
  EXTI_ClearITPendingBit(EXTI_Line7);
  EXTI_ClearITPendingBit(EXTI_Line8);
  EXTI_ClearITPendingBit(EXTI_Line9);
		
}


/*******************************************************************************
	* Function Name  : EXTI15_10_IRQHandler
	* Description	 : This function handles External lines 15 to 10 interrupt request.
	* Input 		 : None
	* Output		 : None
	* Return		 : None
*******************************************************************************/
void EXTI15_10_IRQHandler(void)
{ 
  EXTI_ClearITPendingBit(EXTI_Line10);
  EXTI_ClearITPendingBit(EXTI_Line11);
  EXTI_ClearITPendingBit(EXTI_Line12); 
  EXTI_ClearITPendingBit(EXTI_Line13);
  EXTI_ClearITPendingBit(EXTI_Line14);
  EXTI_ClearITPendingBit(EXTI_Line15);
}

/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
