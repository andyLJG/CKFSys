#ifndef _coin_H
#define _coin_H

#include "stm32f10x.h"
#include "delay_systick.h"
#include "stm32f10x_it.h"


extern u8 recvcoinproc[COINL];

#define REVCOINLEN  0X06 //HLD001����Э�鳤
#define ONEMOP      1   //100��
#define FIVEMOP     5   //500��

//Ӳ�һ���Դ 
#define COIN_Power_ON     GPIO_SetBits(GPIOB, GPIO_Pin_9)
#define COIN_Power_OFF      GPIO_ResetBits(GPIOB, GPIO_Pin_9)


//232��ƽת��ʹ�ܿ���
#define SP3243_ON           GPIO_SetBits(GPIOA, GPIO_Pin_8)
#define SP3243_OFF          GPIO_ResetBits(GPIOA, GPIO_Pin_8)


//��λʹ����Ϣ����16���ֽ�
typedef struct
{   
    u8 wakecoin_flag;
    u8 coinwakework;
    unsigned char BuyTime[2];	               //��ǰ�������Сʱ���֣�  
    u8 RemainTime[2];  
    u8 totalcoinmoney; //��
    u8 Countcoinmoney; //��
    u8 coinmoney; //�������ֵ��Ϊ��Ч
     u8 coinCount;
}FirstWakeCoinInformation; 	

extern FirstWakeCoinInformation wakecoininf;


extern void open_coin_power(void);
extern void close_coin_power(void);
extern void ADD_coin(u8 count,u8 mount);
extern u8  tx_coin(u8 i);
extern u16 rx_coin(void);                   
extern void EmptyRcvCoin(void);

extern u8 coin_pay(u8 space, u8 value,u8 firstcoin);

extern u8 open_close_COIN(u8 *coin_able, u8 remain_maxtime);
#endif