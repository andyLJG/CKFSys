#ifndef __I2C_Driver_H
#define __I2C_Driver_H 
#include "stm32f10x.h"

typedef enum {FALSE = 0, TRUE = !FALSE} bool;

#define EEPROM_ADDR		0xA0
#define RX8025_ADDR		0x64

#define I2C_PAGESIZE	4		//24C01/01Aҳ������4��
#define I2C_PageSize  256  //24C02ÿҳ8�ֽڣ�256*8=2k��
//pb6/pb7
#define SCL_H         GPIOB->BSRR = GPIO_Pin_6
#define SCL_L         GPIOB->BRR  = GPIO_Pin_6 
   
#define SDA_H         GPIOB->BSRR = GPIO_Pin_7
#define SDA_L         GPIOB->BRR  = GPIO_Pin_7

#define SCL_read      GPIOB->IDR  & GPIO_Pin_6
#define SDA_read      GPIOB->IDR  & GPIO_Pin_7

//����
extern u8 time_BCD[7],time[7],time1[7];

//����
extern void I2C_GPIOB_Config(void);
bool I2C_Start(void);
void I2C_Stop(void);
void I2C_Ack(void);
void I2C_NoAck(void);
bool I2C_WaitAck(void);
void I2C_SendByte(u8 SendByte);
u8 I2C_ReceiveByte(void);

bool I2C_WriteByte(u8 SendByte, u16 WriteAddress, u8 DeviceAddress);
bool I2C_BufferWrite(u8* pBuffer, u8 length, u16 WriteAddress, u8 DeviceAddress);
bool I2C_ReadByte(u8* pBuffer,   u8 length,     u16 ReadAddress,  u8 DeviceAddress);


//�洢����д
extern void I2C_ByteWrite_24C(u16 addr,u8 dat);
extern void I2C_WriteS_24C(u16 addr,u8* pBuffer,  u16 no);
extern void I2C_ReadS_24C(u16 addr ,u8* pBuffer,u16 no);

//ʱ��оƬ��д
extern void RD_RX8025SA(u8 addr ,u8* pBuffer,u16 no);
extern void WR_RX8025SA(u8 addr,u8 dat);
//ʱ��оƬ����
extern void set_time(void);
extern void set_time_2(void);
extern void init_rx8025sa(void);  
extern u8   GetCurrentTime(void);
extern void set_current_time(unsigned char  time_set[]); 	//��������ʱ�䣨�֣�Сʱ���գ��£��꣬���ڣ��룩��
extern void Backlight_Open_Close(void);
extern void set_current_IP(u8 Ip_set[]);
extern void set_current_MeterNo(u8 Meter_N0_set[]);


#endif 

