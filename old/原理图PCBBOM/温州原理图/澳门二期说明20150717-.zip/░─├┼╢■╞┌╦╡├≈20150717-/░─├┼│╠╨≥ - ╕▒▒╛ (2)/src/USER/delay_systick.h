#ifndef __delay_systick_H
#define __delay_systick_H

#include "stm32f10x.h"

typedef  unsigned char uchar;
typedef  unsigned int  uint;	

#define countof(a)   (sizeof(a) / sizeof(*(a)))

#define   NETTIMEOUT_1S  9500000
#define   KEYTIMEOUT_5S	 10000000
#define   KEYTIMEOUT_4S	 8000000
#define   KEYTIMEOUT_3S	 6000000	//6500000
#define   KEYTIMEOUT_2S	 4000000
#define   KEYTIMEOUT_1S	 2000000

#define   TIMEOUT_1S	 8500000  //mine8000000(1152)3400000(384)6400000(192)
//#define   KEYTIMEOUT_5S	 KEYTIMEOUT_1S*2

#define   ERROR_DELAY   2000	  //3S
#define   DELAYTIME     5000	  //5S
/*MIfare������ʱ��*/
#define   MTIMEOUT_5S	 5600000
#define   MTIMEOUT_4S	 4400000  //1000000
#define   MTIMEOUT_3S	 3200000	
#define   MTIMEOUT_2S	 2000000
#define   MTIMEOUT_1S	 800000  //1000000
/*�ܲ�ͨ������ʱ��*/
/*
#define   ZTIMEOUT_5S	 6700000
#define   ZTIMEOUT_4S	 5200000
#define   ZTIMEOUT_3S	 3700000	
#define   ZTIMEOUT_2S	 2200000
#define   ZTIMEOUT_1S	 800000*/

#define   ZTIMEOUT_5S	 ZTIMEOUT_1S*5
#define   ZTIMEOUT_4S	 ZTIMEOUT_1S*4
#define   ZTIMEOUT_3S	 ZTIMEOUT_1S*3
#define   ZTIMEOUT_2S	 ZTIMEOUT_1S*2
#define   ZTIMEOUT_1S	 650000

/*��������ʱ---����//115200 //38400(16\11\6) //19200��300 200 100��*/
//#define   M_3S    80  //90
//#define   M_2S    60
//#define   M_1S    30

/*#define   M_5S    325  //90
#define   M_4S    260
#define   M_3S    195  //90
#define   M_2S    130
#define   M_1S    65
*/



#define   M_5S    M_1S*5  //90
#define   M_4S    M_1S*4
#define   M_3S    M_1S*3  //90
#define   M_2S    M_1S*2
#define   M_1S    20

#define   L_M_5S    L_M_1S*5  //90
#define   L_M_4S    L_M_1S*4
#define   L_M_3S    L_M_1S*3  //90
#define   L_M_2S    L_M_1S*2
#define   L_M_1S    50

#define   C_M_5S    C_M_1S*5  //90
#define   C_M_4S    C_M_1S*4
#define   C_M_3S    C_M_1S*3  //90
#define   C_M_2S    C_M_1S*2
#define   C_M_1S    50

#define   A_M_5S    A_M_1S*5  //90
#define   A_M_4S    A_M_1S*4
#define   A_M_3S    A_M_1S*3  //90
#define   A_M_2S    A_M_1S*2
#define   A_M_1S    34

#define   Min_5S    5500000
#define   Min_4S    4500000
#define   Min_3S    3500000
#define   Min_2S    2500000
#define   Min_1S    1500000

/*���õ�sysytick��ʱ*/
extern void Delay_Init(u8 SYSCLK);
extern void delay_ms(u32 nms);
extern void delay_us(u32 nus);

extern void delay(unsigned long value);
extern void delayus(u16 t);	
extern void delayms(u16 t);
extern void delayms_keybreak(u16 t);     //Լ��ʱn��ms��
extern void delayms_break(u16 t);     //Լ��ʱn��ms��

extern unsigned char  touchkey_scan(u8 flag);

extern void SoftReset(void);
#endif

