#ifndef _USART_H_
#define _USART_H_



/*���͵����ֽ�*/
extern void USART_Putc(USART_TypeDef* USARTx,u8 c);
/*�����ַ���*/
extern void USART_Puts(USART_TypeDef* USARTx,u8 * str);
/*����n���ֽ�*/
extern void USART_SendPacket(USART_TypeDef* USARTx, uint16_t Data, u8 *Senddata);
extern void USART_SendPacket_new(USART_TypeDef* USARTx, uint16_t Data,  u8 *Senddata);
extern unsigned char bcd_to_hex(unsigned char a);
extern unsigned char hex_to_bcd(unsigned char a);
extern void fll_BCD(unsigned long FD,unsigned char *bufa,unsigned char b);
extern unsigned char hex_to_asic(unsigned char a);
extern unsigned char asic_to_hex(unsigned char rr);
extern unsigned char twoasic_to_oenhex(unsigned char *recvgsmproc,u8 ASCII);
extern void AscToBcd(unsigned char *bufa0,unsigned long len,unsigned char *bufa);
extern unsigned long hcl(unsigned char *bufa,unsigned char b);
extern void fll(unsigned long FD,unsigned char *bufa,unsigned char b);
extern unsigned char mathweek(unsigned char nian,unsigned char yue, unsigned char ri);
#endif

