#ifndef __HW_check_H
#define __HW_check_H


extern void hardWare_Check(void);


#endif
