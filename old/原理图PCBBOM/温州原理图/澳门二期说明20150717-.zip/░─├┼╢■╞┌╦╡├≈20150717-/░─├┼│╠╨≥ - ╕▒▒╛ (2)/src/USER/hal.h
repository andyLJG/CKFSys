#ifndef __hal_H
#define __hal_H
 
#include "stm32f10x.h"

#define  BaudRate_115200 115200
#define  BaudRate_57600  57600
#define  BaudRate_38400  38400
#define  BaudRate_19200  19200
#define  BaudRate_9600   9600

void RCC_Configuration(void);
void IWDG_Configuration(void);

void Uart1_Configuration(u32 BaudRate);
void Uart2_Configuration(u32 BaudRate);
void Uart3_Configuration(u32 BaudRate);
void Uart4_Configuration(u32 BaudRate);
void Uart5_Configuration(u32 BaudRate);

extern void AllUart_Close(void);

//�ⲿ����
extern void  ChipHalInit(void);		  //Ƭ��Ӳ����ʼ��
extern void  ChipOutHalInit(void);	  //Ƭ��Ӳ����ʼ��
extern void  ChipOutHalInitsleep(void);
extern void NVIC_Configuration(void);
#endif

