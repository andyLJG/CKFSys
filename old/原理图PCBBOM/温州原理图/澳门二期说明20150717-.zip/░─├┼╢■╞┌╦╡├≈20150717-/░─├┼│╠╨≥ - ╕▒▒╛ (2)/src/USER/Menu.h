#ifndef	_Menu_H
#define	_Menu_H

#include "delay_systick.h" 

#define LCDCENTERDISP   		0xFE//��ʾ����
typedef struct 
{
  u8  RxBuffer_POS[120];
  u8  RXBCC_POS;
  u8  RxState_POS;
  u16 RxCounter_POS;
} RxPOS_2_dot_4_G; 
  
#define fee_STR_1        "MOP1/HR"   
#define fee_STR_2        "MOP1/30min"   
#define fee_STR_3        "MOP1/10min"



extern  RxPOS_2_dot_4_G  RxPOSdot;  
extern void Update_RTC(u8 locs);
extern u8 disp_MainMenu(void);
extern void Enter_MainMenu(void);
extern u8  Main_Menu_Enter(void);
extern   void disp_MainMenu_Fee(void);
#endif