#include "MAIN.h"
#include "USART.h"
#include "coin.h" 
#include "mifare.h"
#include "I2C_Driver.h"
#include "LM240128C.h"  //����
#include "rate.h"  //����
#include "save_record.h" 
#include "MemoryAssign.h"
#include "report.h"


FirstWakeCoinInformation wakecoininf; //wakecoininf.coinmoney

u8 gg;
u8 coinp;
u8 recvcoinproc[COINL];

/*��Ӳ�һ���Դ*/
void open_coin_power(void)
{
  COIN_Power_ON;
  
}

/*�ص�Ӳ�һ���Դ*/
void close_coin_power(void)
{
 // COIN_Power_OFF;
}

/*Ӳ�һ���������*/
void sent_coin_data(u8 x)
{	 
  USART_Putc(UART5,x);  //USART2
}

/***�����COIN����********/
void EmptyRcvCoin(void)   //
{     
  do
  {   
    esflag=0;  
    delay_ms(5); //5ms��ʱ
  } while(esflag);
  s_head=0;
  s_tail=0;
}

/**********************************************************
***********��Ӳ�һ�COINģ���Ƿ������ݷ��͹���*********************
***********************************************************/
u8 ReadCoinChar(void)   //�˺����ж��Ƿ������ݴ�����
{       
		
  u8 s_tailc; 
//  do
//  {   
    esflag=0;	
    s_tailc=s_tail;      
    if(s_tailc==s_head)
    {   
      if(esflag==0) 
        {s_tail=s_tailc; return 0;}  
    }
    gg=recvcoin[s_tailc];
    s_tailc++;
    if(s_tailc==COINL)  
      s_tailc=0;          
//  }while(esflag);
  s_tail=s_tailc; 
  return 1;
}

/*
 "HLD000"---δʶ��ı�
 "HLD001"---5����
 "HLD002"---10����
 "HLD003"---25����
 "HLD004"---50���֣�Ԥ����
 "HLD005"---100����
*/
void ReadCoinStr0(void)  //��Ӳ�һ�����
{       
  coinp=0;
  recvcoinproc[0]=0;
  recvcoinproc[REVCOINLEN-1]=0; 
  while(esflag)   //Ӳ�һ��Ѿ��д����������������� 
  {  
    if( ReadCoinChar()) //����ReadcoinChar()�лὫesflag����
    {        
      esflag=1; 
      recvcoinproc[coinp]=gg;
      if(recvcoinproc[0]!='H')//0x90
      {
        coinp=0;
      }
      if(coinp<(COINL-1))   
        coinp++; 
      if(coinp==REVCOINLEN)//recvcoinproc[1]
      { 
        if(s_head==s_tail)
        esflag=0;  
        break;	
      } 
    }
    else
    {   
      delayms(50);  //500          
    }
  }
  recvcoinproc[coinp]=0;
}



/*����Ӳ�һ���������*/
u8  tx_coin( u8 i )
{
//  u32 timeout;  
//  EmptyRcvCoin();  //������� ע��
  switch( i )
  {
  case 1:
    sent_coin_data( 0x90 );	 //	 ʹ������
    sent_coin_data( 0x05 );	 //
    sent_coin_data( 0x01 );	 //
    sent_coin_data( 0x03 );	 //
    sent_coin_data( 0x99 );	 //
    break;
  case 2:
    sent_coin_data( 0x90 );	 //	 ��������
    sent_coin_data( 0x05 );	 //
    sent_coin_data( 0x02 );	 //
    sent_coin_data( 0x03 );	 //
    sent_coin_data( 0x9a );	 //
    break;
  case 3:	  	
    sent_coin_data( 0x90 );	 //	 ��ѯ����
    sent_coin_data( 0x05 );	 //
    sent_coin_data( 0x11 );	 //
    sent_coin_data( 0x03 );	 //
    sent_coin_data( 0xa9 );	 //
    break;
  case 4:	  	
    sent_coin_data( 0x90 );	 //	 ��λ����----2Ӧ��
    sent_coin_data( 0x05 );	 //
    sent_coin_data( 0x05 );	 //
    sent_coin_data( 0x03 );	 //
    sent_coin_data( 0x9D );	 //
    break; 
  case 5:	  	
    sent_coin_data( 0x90 );	 //	�汾��
    sent_coin_data( 0x05 );	 //
    sent_coin_data( 0x03 );	 //
    sent_coin_data( 0x03 );	 //
    sent_coin_data( 0x9B );	 //
    break;                         
  default:  return 0xff;
  }
//�ȴ�Ӳ�һ��ظ�
//  esflag = 0;
//  timeout = 500000;	//5S
//  while( esflag == 0 )
//  {	  
//    if( timeout == 0 )
//    { return 0x10;}     //ͨ�ų�ʱ		 
//    timeout--;  
//  } 
  delayms(100);  //100
  return 0;
}


/*
�����ж�Ӳ�һ��ظ�����
 "HLD000"---δʶ��ı�
 "HLD001"---5����
 "HLD002"---10����
 "HLD003"---25����
 "HLD004"---50���֣�Ԥ����
 "HLD005"---100����
*/
u16 rx_coin(void)
{ 

  ReadCoinStr0();  
  //û����   
  switch(recvcoinproc[REVCOINLEN-1])
  {
  case '1':    return 0;   
  case '2':    return 0;   
  case '3':    return 0; 
  case '4':    return ONEMOP;   
  case '5':    return FIVEMOP;
  default:     return 0;  //δ����  
  } 

}

void ADD_coin(u8 count,u8 mount)
{    u8 coinbuffer[4];
      u16 ct_coin;

  
                I2C_ReadS_24C(MeterCoinTotalAddr,coinbuffer,2);     //
                ct_coin=coinbuffer[0];
                ct_coin=(ct_coin<<8)+coinbuffer[1];
                ct_coin+=mount;    
                coinbuffer[0]=(ct_coin>>8)&0xff; 
                coinbuffer[1]=ct_coin&0xff;
                I2C_WriteS_24C(MeterCoinTotalAddr,coinbuffer,3);  
                
                
                I2C_ReadS_24C(MeterCoinCountAddr,coinbuffer,2);     //
                ct_coin=coinbuffer[0];
                ct_coin=(ct_coin<<8)+coinbuffer[1];
                ct_coin+=count;    
                coinbuffer[0]=(ct_coin>>8)&0xff; 
                coinbuffer[1]=ct_coin&0xff;
                I2C_WriteS_24C(MeterCoinCountAddr,coinbuffer,3); 
            //    
          
             delayms(30);    
           make_record_Alarm(Unown_coin,mount,0,0xa0);
           
}
/*Ӳ�һ����� value���һ��Ӳ��*/
u8 coin_pay(u8 space, u8 value,u8 firstcoin)
{
  u8 coin_value;
  u8 max;
  u8 revcoin,lastcoin;
  u8 coinbuffer[16];
  u16 ct_coin; //��ǰӲ�һ�����
  u32 maxtimeout;   
  
  coin_value=0;
  open_coin_power();     
  /*�������һ��Ӳ��---------start*/
  display_head();
  if(value==0x20)
  { 
    coin_value=firstcoin; 
    Buzz_0;                
    max=money_to_time(space_HEX,coin_value);
    //��ʾ������Ϣ
    display_Infor(space,coin_value,0,1);          
    if(max==1)//||(coin_value==FEE.MAXmoney)) //�����е������ͣ����
      //2014-2-9�滻
    {
      display_lastinfor(0,112,0x30);            
      maxtimeout=2;      
    } 
    else
    {  
      


    
  
       maxtimeout= KEYTIMEOUT_5S+1;
    
       
      
    }
    OPEN_CLOSE_IRQ(IRQ_OPEN,KEY_IRQ);  
    delayms(20);    
    Buzz_1;
    //5sӲ�һ�û����ʱ���Զ��˳� 
                   if(METERTYPE!=ELECTCARMETER)   
                     display_lastinfor(0,112,0x59);  
            
                   
    
    while( maxtimeout--)
    {       
      //������------START--------------
      if(key_flag) //�а���
      { 
//        KeyInfor.keyvalue=key_scan(0x88);
        KeyInfor.keyvalue=touchkey_return(0x88);
        if(KeyInfor.keyvalue==KEY_X)//ȡ����
        {          
          OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
          Buzz_0;
          maxtimeout=1;         
          display_lastinfor(0,112,0x49);//ȡ����....
          delayms(20);
          Buzz_1;
        }
              if(KeyInfor.keyvalue==KEY_Chinese)//ȡ����
            {
                if(METERTYPE!=ELECTCARMETER) 
                {      
          OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
          Buzz_0;
          maxtimeout=1;         
          display_lastinfor(0,112,0x49);//ȡ����....
          delayms(20);
          Buzz_1;
        } 
            }
        
        
      }//��ǰ����ֵ
      if( maxtimeout== KEYTIMEOUT_5S)
        Print_time(5); 
      else if(maxtimeout==KEYTIMEOUT_4S)
        Print_time(4);
      else if(maxtimeout==KEYTIMEOUT_3S)
        Print_time(3); 
      else if( maxtimeout==KEYTIMEOUT_2S)
        Print_time(2);       
      else if(maxtimeout==KEYTIMEOUT_1S)
        Print_time(1); 
      else if(maxtimeout==1) //��ʱ 
      {       
        IWDG_ReloadCounter(); //ι��
        OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
        Print_time(0); 
        key_flag=0;
//        delayms(300);  //ע��
        
        delayms_break(300);
        
        lastcoin=rx_coin();
        if(lastcoin==ONEMOP || lastcoin==FIVEMOP)//֮ǰ��Ͷ�� 
        {
        ; 
        }
        else
        {
          lastcoin=0;
          break;
        }
         wakecoininf.coinCount+=1;  
        coin_value+=lastcoin;

        
        money_to_time(space_HEX,coin_value);
        //��ʾ������Ϣ
        display_Infor(space,coin_value,1,1); 
        
         Buzz_0;
        delayms(40);
        Buzz_1;
        break;      
      }
     //������------END--------------       
      //1��Ӳ��--------start-----------      
      if(esflag==1) //���յ�����
      {
        maxtimeout=KEYTIMEOUT_5S+1;
        IWDG_ReloadCounter(); //ι��
        revcoin=rx_coin();
        if(revcoin==ONEMOP || revcoin==FIVEMOP)//��Ͷ��
        {
          Buzz_0;
          coin_value+=revcoin;
          
          
          wakecoininf.totalcoinmoney+=revcoin;
          wakecoininf.coinCount+=1;   
          
          
          max=money_to_time(space_HEX,coin_value);
          //��ʾ������Ϣ
          display_Infor(space,coin_value,0,1);          
          if(max==1) //||(coin_value==FEE.MAXmoney)�����е������ͣ����
          {
            display_lastinfor(0,112,0x30);            
            maxtimeout=2;            
          } 
          delayms(30);
          Buzz_1; 
        }           
      }       
      //1��Ӳ��--------end-----------
    }
  }
  /*�������һ��Ӳ��---------end----*/
  
  /*���һ��Ӳ��---start----*/
  else
  {
    Print_time(0); 
    coin_value+=firstcoin;
    
    if(jd_maxtime(0)==0) 
      {//��ʱ
      
       ADD_coin(wakecoininf.coinCount,wakecoininf.totalcoinmoney);
       
       display_lastinfor(0,112,0x30); 
       delayms_keybreak(1200);
        //
        coin_value=0;
        
      //�쳣��¼
       
      
      }  
    else
    {
       wakecoininf.totalcoinmoney+=revcoin;
     //  wakecoininf.coinCount+=1;  
       money_to_time(space_HEX,coin_value); 
    }
    
    
   
         
      
  } 
   /*���һ��Ӳ��---end----*/    
  /*��Ӳ�һ�*/ 
  close_coin_power();
  judge_get_time();
  if(coin_value) //�нɷ�
  {    
    //������
    Buzz_0;  
    LED_ONOFF(space_HEX,GREENLED,LEDON);
  
    
    coinbuffer[0]=COINPAY;//��λ״̬
    coinbuffer[1]=Spaces_Infor[space_HEX].RemainTime[0];//����ʣ��ʱ��
    coinbuffer[2]=Spaces_Infor[space_HEX].RemainTime[1];//    
    coinbuffer[3]=0;//����
    coinbuffer[4]=0;//
    coinbuffer[5]=0;//
    coinbuffer[6]=0;//    
    coinbuffer[7]=time[4];//��  //�ĳ�time_BCD
    coinbuffer[8]=time[3];//��
    coinbuffer[9]=time[2];//��
    coinbuffer[10]=time[1];//ʱ
    coinbuffer[11]=time[0];//��
    
    WriteSpaceUsingInf(space_HEX,coinbuffer);     
    //LCD��ʾ���
//    Count_Endtime(Spaces_Infor[space_HEX].RemainTime,Spaces_Infor[space_HEX].deadline);
    display_consume(0,coin_value,0);
    //�����¼----------------     
    Buzz_1;
    //дӲ����������ַ------start-----------
    I2C_ReadS_24C(MeterCoinTotalAddr,coinbuffer,2);     //
    
    ct_coin=coinbuffer[0];
    ct_coin=(ct_coin<<8)+coinbuffer[1];
  //  ct_coin+=coin_value;   
     ct_coin+= wakecoininf.totalcoinmoney; 
    coinbuffer[0]=(ct_coin>>8)&0xff; 
    coinbuffer[1]=ct_coin&0xff;
    
     I2C_WriteS_24C(MeterCoinTotalAddr,coinbuffer,2);   //д����
    //д����
        

     
     
     //�����
    I2C_ReadS_24C(MeterCoinCountAddr,coinbuffer,2);     //
    
    ct_coin=coinbuffer[0];
    ct_coin=(ct_coin<<8)+coinbuffer[1];
   // ct_coin+=1;   
    ct_coin+=   wakecoininf.coinCount ; 
    coinbuffer[1]=(ct_coin>>8)&0xff; 
    coinbuffer[2]=ct_coin&0xff;
    
    
     
    
    if(ct_coin<=MAXCOIN)
    {
      coinbuffer[0]=0;
    }
    else
    {
        if((ct_coin>=MAXCOIN+50)&&(ct_coin<=MAXCOIN+60))
        { 
          make_record_Alarm(Coin_full,0,0,0xa0);
        }
        else if((ct_coin>=MAXCOIN)&&(ct_coin<=MAXCOIN+5))
        {
         make_record_Alarm(Coin_near_full,0,0,0xa0);
         
        }
      
      delayms(30);
      coinbuffer[0]=1;       
    }
   
    
    
      I2C_WriteS_24C(MeterCoinCountAddr-1,coinbuffer,3);  

    
    
    
    
    //------------------end----------
//    make_record(space_HEX,0x01); //0x01���Ѽ�¼
    CardInfor.ParkingMoney=coin_value;
    CardInfor.ParkingMoney*=100;
  
    
    //make_record(Consume_OP,Coin_Record,BuyTime_Record,space_HEX); //0x01���Ѽ�¼
    make_Stope_record_Coin(Consume_OP,Coin_Record,BuyTime_Record,space_HEX,coin_value);
    
    
    //�����¼----------------
    save_report(coin_value,COINPAY);
    return 0;
  } 
  else
  {
    Buzz_0;
    //û������
    display_lastinfor(0,112,0x29); 
    delayms(40);
    Buzz_1;
    return ERROR_NOWAIT;
  } 

}  


