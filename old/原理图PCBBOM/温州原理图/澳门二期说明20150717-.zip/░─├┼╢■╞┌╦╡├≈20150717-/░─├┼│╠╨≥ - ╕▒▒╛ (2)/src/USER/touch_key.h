#ifndef	_touch_key_H
#define	_touch_key_H

#include "stm32f10x.h"

//�жϿ���
#define IRQ_OPEN        1
#define IRQ_CLOSE       0
//�ж�Դ
#define ALL_IRQ          0x01   //ȫ��
#define KEY_IRQ          0x02   //����
#define T32SCOIN_IRQ	 0X03   //16S�жϺ�Ӳ�Ҽ��
#define T32S_IRQ	 0X04   //16S�ж�
#define COIN_IRQ         0x05   //Ӳ�Ҽ��
#define DOOR_IRQ         0X06   //�Ŵ�
#define DOORCOIN_IRQ	 0X07   //�Ŵź�Ӳ�Ҽ��
//�ж�ֵ
#define Wakeup_32S	0X32
#define Wakeup_DOOR     0X77
#define Wakeup_COIN     0X55
#define Wakeup_IRDA     0X99
//������¼����
#define Low_volt_0	0X0F
#define Open_Door_0	0X0E
#define Reader_NG_0	0X0D
#define Coin_near_full	0X0C
#define Coin_full	0X0B
#define battery  	0X0A
#define Unown_coin	0X09
#define FEESET_0	0X08

/*����4*4����*/
#define KEY_0  			0x10
#define KEY_1  			0x01
#define KEY_2  			0x02
#define KEY_3  			0x03

#define KEY_4  			0x04
#define KEY_5  			0x05
#define KEY_6  			0x06
#define KEY_7  			0x07
#define KEY_8  			0x08

#define KEY_9  			0x09
#define KEY_Lamp  	        0x61  //0x11 //���ⰴ��
#define KEY_X  	                0x72  //X�˳���
#define KEY_Chinese		0x83  //����
//#define KEY_Portugues  	        0x94  //������
//#define KEY_English  	        0xa5  //Ӣ��
#define KEY_UP  	        0x94  //��
#define KEY_DOWN  	        0xa5  //��
#define KEY_Instruct     	0xb6  //ʹ��˵��
#define KEY_Management   	0xb7  //ʹ��˵��

#define GREENLED 0
#define REDLED 1
#define  LEDON  0
#define  LEDOFF  1


/*A����ɨ��*/
/****************start�����ӿ�start*****************/
//#define key1_0		GPIO_ResetBits(GPIOC, GPIO_Pin_5)
//#define key1_1	    GPIO_SetBits(GPIOC, GPIO_Pin_5)
//#define key2_0		GPIO_ResetBits(GPIOC, GPIO_Pin_6)
//#define key2_1	    GPIO_SetBits(GPIOC, GPIO_Pin_6)
//#define key3_0		GPIO_ResetBits(GPIOC, GPIO_Pin_7)
//#define key3_1	    GPIO_SetBits(GPIOC, GPIO_Pin_7)
//#define key4_0		GPIO_ResetBits(GPIOC, GPIO_Pin_8)
//#define key4_1	    GPIO_SetBits(GPIOC, GPIO_Pin_8)
/******************end�����ӿ�end*******************/


//// ---��������---------- //
typedef struct                
{
  u8 flag;              
  u8 first_secord; 
}TouchKeyInfor;

extern  TouchKeyInfor key;

extern void AM_keypin_init(void);
extern u8 process_32s(u8 order);
extern unsigned char  key_scan(u8 flag);
extern u8 key_value(u8 firsttime);

extern void OPEN_CLOSE_IRQ(u8 open_close, u8 irq_type);

extern void touchkeypin_init(void);
extern u8 touchkey_return(u8 flag);
extern void LED_ONOFF(u8 space,u8 oneled, u8 ONorOFF);

#endif

