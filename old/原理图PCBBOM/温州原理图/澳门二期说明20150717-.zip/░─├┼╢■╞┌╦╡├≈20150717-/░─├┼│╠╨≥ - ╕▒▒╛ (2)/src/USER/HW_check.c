#include "stm32f10x.h" 
#include "stm32f10x_it.h"
#include "delay_systick.h" 
#include "Hal.h"
#include "touch_key.h"
#include "I2C_Driver.h"
#include "spi_flash.h"
#include "ADC.h"
#include "LM240128C.h"  //����
#include "GPIO.h"
#include "mifare.h"
#include "MemoryAssign.h"
#include "fsmc_sram.h"
#include "MAIN.h"
#include "ir_comm.h"
#include "USART.h"
#include "St_wcdma.h" 
#include "COIN.h"
#include "new_mifare.h"
#include "contact_card.h"
#include  "AoMenTong.h"
/*------------------����Ӳ��������---------------huangfeng-----------------*/	
void hardWare_Check(void)
{

  u8 x,y;
  u8 LowVoltage;
  u8  carddatatestC[13] ;
  u8 Buffer[128];
  u16 i;	
  //u32 timeoutCoin;  
  key_flag=0;   
  i=2;
  lcd_clear();  
  do
  {
    /*��ͷ��ϵͳ��⣺*/
    x=0;
    y=0;
    lcd_clear(); 
    LCD_back_ON;  //�ѱ����
    PrintGB(x,y,"ϵͳ���");
    PrintASCII(x+20,2,":");   
    

    //****

    
    
    //***********
    


    
    //1.LCD������
    x=0;
    y+=16;
    PrintASCII(x,y,"1.LCD");
    if(i==2)
      LCD_REVERSRDISPON;
    else if(i==1)
      break;    
    delayms(3000);
    lcd_clear();
    LCD_REVERSRDISPOFF;
    delayms(2000);
    LCD_back_ON;   //�ѱ���ص�	
  }while(i--);
  
  //1.���������
  x=0;
  y+=16;
  PrintASCII(x,y,"2.Buzzer");
  Buzz_0;
  delayms(50);
  Buzz_1;;  //�ѷ������ص�
  delayms(1000);
 
  
  //3.LED���
  x=0;
  y+=16;
  PrintASCII(x,y,"3.LED");
 

  
  
  
  LED1_GON;//����
  LED2_GON;
  LED3_GON;
  LED4_GON;
  delayms(3000);
  LED1_GOFF;//����
  LED2_GOFF;
  LED3_GOFF;
  LED4_GOFF; 
  
  //delayms(3000);
  //
  LED1_RON;
  LED2_RON;
  LED3_RON;
  LED4_RON;
  
  delayms(3000);
  LED1_ROFF;
  LED2_ROFF;
  LED3_ROFF;
  LED4_ROFF;  
  
  
  //4.32S�жϼ�⣨�����˳���
  x=0;
  y+=16;
  PrintASCII(x,y,"4.16S");
  i=0;
  key_flag=0;
  OPEN_CLOSE_IRQ(IRQ_OPEN,KEY_IRQ);//�򿪰����ж�
  wake_flag=0;
 /* IWDG_ReloadCounter(); //ι�� 
  while(1)
  {
    if(wake_flag==Wakeup_32S)		//32���ж�
    { 
      wake_flag=0;
      Buzz_0;
      delayms(50);
      Buzz_1; 
      i++;
      IWDG_ReloadCounter(); //ι�� 
      if((i==2)||(key_flag)) //�а����˳�
      {break;} 		
    }
    if(key_flag)break; 
  }
  if(key_flag)
  {
//    OPEN_KEY_IRQ();
    key_flag=0;
  }
  */
  
  IWDG_ReloadCounter(); //ι�� 
  
  
  //5.������
  x=0;
  y+=16;
  PrintASCII(x,y,"5.FRAM");
  for(i = 0;i<64;i++)
    Buffer[i] = i; 
  I2C_WriteS_24C(TestFRAMAddr,Buffer,64); //д����
  for(i = 0;i<64;i++)
    Buffer[i] = 0;
  I2C_ReadS_24C(TestFRAMAddr,Buffer,64); //������
  for(i = 0; i<64;i++)
  {
    if(Buffer[i] != i)
    {
      PrintASCII(x+12,y,"......NO");  
      break;
    }
  }
  if(i >= 64)
  {
    PrintASCII(x+12,y,"......OK");
  }
  //6.SPI_FLASH ���
  x=0;
  y+=16;
  PrintASCII(x,y,"6.FLASH"); 
  SPI_FLASH_Init();
  SPI_FLASH_SectorErase(0);  //��0����
  for(i = 0;i<128;i++)
    Buffer[i] = i;
  SPI_FLASH_BufferWrite(Buffer, 0, 128); //дFLASH
  for(i = 0;i<128;i++)
    Buffer[i] = 0;
  SPI_FLASH_BufferRead(Buffer, 0, 128);  //��FLASH
  for(i = 0; i<128;i++)
  {
    if(Buffer[i] != i)
    {
      PrintASCII(x+14,y,".....NO");  
      break;
    }
  }
  if(i >= 127)
  {
    PrintASCII(x+14,y,".....OK");
  } 
  
  //7.FMSC���Ƶ�SRAM���
  x=0;
  y+=16;
  PrintASCII(x,y,"7.SRAM"); 
  PrintASCII(x+12,y,"......");
  FSMC_SRAM_Init();  //��Ҫ
  for(i=0;i<128;i++)
  {  
      Buffer[i]=i; 
  } 

  /*д��SRAM*/
  FSMC_SRAM_WriteBuffer(Buffer, 0X500000, 64);       
  for(i=0;i<128;i++)
  Buffer[i] = 0; 
  /*Read data from FSMC SRAM memory */
  FSMC_SRAM_ReadBuffer(Buffer, 0X500000, 64); 
  
  for(i = 0; i<64;i++)
  {
    if(Buffer[i] != i)
    {     
      break;
    }
  }  
  if(i >= 64)
  {    
    PrintASCII(x+24,y,"OK");
  }  
  else
    PrintASCII(x+24,y,"NO");
  
  
  //�м�����
  Draw_Line(102,0,102,127);      //����
  
  //8.ʱ��оƬ���
//  x=40;
//  y=16;
//  PrintASCII(x,y,"7.Timer");
  //(�֡�Сʱ���ա��¡��ꡢ���ڡ���)set_time[7];
  //set_current_time(stime);//дʱ��
  //GetCurrentTime(); //��ʱ��
  //for(i=0;i<6;i++)
  //{
  //if(stime[i]!=time_BCD[i])
  // {
  //  PrintASCII(x+14,y,"......");
  //  PrintASCII(x+26,y,"NO");
  // break;
  // } 
  //}
  //if(i>=6)
  //{
  //  PrintASCII(x+14,y,"......");
  //  PrintASCII(x+26,y,"OK");
  //} 
//  PrintASCII(x+14,y,"......");
//  PrintASCII(x+26,y,"OK");
  //8.0 �ܲ�ͨ���
   x=40;
   y=0;
   PrintASCII(x,y,"8.ZhouBoTong");
   //PrintGB(x,y,"�ܲ�ͨ");
    Contact_Power_ON;
    read_card_test(carddatatestC);
    Contact_Power_OFF;
    if((carddatatestC[0]==0xff)||(carddatatestC[0]==0))
    {  
      PrintASCII(x+24,y,".NO-Card");
    }
    else
    {
          PrintASCII(x+24,y,".OK");
    }

    delayms(1000);
  //9. �͵�ѹ���
  x=40;
  y=16;
  PrintASCII(x,y,"9.Battery"); 
  LowVoltage=TestADC1();//
  PrintASCII(x+18,y,"....");
  if(LowVoltage==2)
  {
    PrintASCII(x+26,y,"NO");   
  }
  else
  {
//    PrintASCII(x+26,y,"OK"); //ADCinf.evenvalue
  //  Display_money(x+26,y,ADCinf.evenvalue,0);
      Display_money_BT(x+26,y,ADCinf.evenvalue,0);
  
  } 
  
  ////10.3Gģ����
  x=40;
  y+=16;
  key_flag=0;
  PrintASCII(x,y,"10.3G"); 
  PrintASCII(x+10,y,"........");
  Buffer[0]=MU509link_net();
  if(Buffer[0]==0)
  { 
    PrintASCII(x+26,y,"OK");
  }
  else
  { 
    PrintASCII(x+26,y,"NO-");
    display_BCD(x+32,y-4,Buffer[0]);
  }

  OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
 
  //11.2.4G���
  x=40;
  y+=16;
  PrintASCII(x,y,"11.2.4G"); 
  key_flag=0;
  IWDG_ReloadCounter(); //ι��
  
 /* open_ir_comm();	
  delayms(1000);			   //key-huangfeng(��ʱ����ܷ��л���������)
    Buffer[0]=0x28;
  Buffer[1]=0x28;
  Buffer[2]=0xcc;
  Buffer[3]=0x04; 
  
  for(i=0;i<4;i++)
    Buffer[i+4]=0x99;
  Buffer[8]=0xcc;
  Buffer[9]=0xcc; 
  USART_SendPacket(UART4,10,Buffer);
  Buffer[0]=IrDAuart_rec2(90000); */
  
  Buffer[0]=BT_CK();

  
  PrintASCII(x+14,y,"......");
  if(Buffer[0]==0)	//û���յ�����ʱ���ص���0 ��s˵��2.4Gģ��������⣩
  { PrintASCII(x+26,y,"OK");} 
  else
  {PrintASCII(x+26,y,"NO");} 
  
  
  
  //13.�Ŵſ��ؼ��
  OPEN_CLOSE_IRQ(IRQ_OPEN,DOOR_IRQ);
  x=40;
  y+=16;
  PrintASCII(x,y,"12.Door");
  delayms(1000);
  wake_flag=0;
  delayms(3000);
  if(wake_flag ==Wakeup_DOOR)
  {
    wake_flag=0;
    PrintASCII(x+14,y,"....Open");
  }
  else
  {
    wake_flag=0;
    PrintASCII(x+14,y,"....Close");
  } 
  OPEN_CLOSE_IRQ(IRQ_CLOSE,DOOR_IRQ);
    
   x=40;
  y+=16;
  PrintASCII(x,y,"13.");
  x+=6;
  PrintGB(x,y,"������");
  
  i=3;
  /*��ȡ��������ID��*/
  
  Mifare_Power_ON;
  //delayms(2000); 
  do
  {
    if(AMT_init()==0) //û��
    {
      i=3;
      break;
    } 
  }while(--i);
  //�ж϶������Ƿ����
  Mifare_Power_OFF;
  PrintASCII(x+15,y,"....");
  if(i == 0)
  { PrintASCII(x+20,y,"NO");} 
  else
  {PrintASCII(x+20,y,"OK");}
  //15.Ӳ�һ����
  x=40;
  y+=24;
  PrintASCII(x,y,"14.");
  x+=6;  
  PrintGB(x,y,"Ͷ����");
  open_coin_power(); 

  
  /* esflag = 0;
   tx_coin(5);
   timeoutCoin = 300000;	//5S
  while( esflag == 0 )
  {	  
    if( timeoutCoin == 0 )
    { break;}     //ͨ�ų�ʱ		 
    timeoutCoin--;  
  } */
  
  COIN_Power_OFF;
  /*if(timeoutCoin == 0)
  { PrintASCII(x+20,y,"NO");} 
  else
  {PrintASCII(x+20,y,"OK");}*/
  
  delayms(5000);
  OPEN_CLOSE_IRQ(IRQ_OPEN,KEY_IRQ);
  
}

  //ʹ��Ӳ�һ�-------------start------------- 
//  i=0;
//  EmptyRcvCoin();
//  USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
//  do
//  {
//    if(tx_coin(1)==0) //����ʹ��
//    {
//      if(rx_coin()==2)
//      {PrintASCII(x+15,y,"...OK");break;}
//    }        
//    i++;        
//  }while(i<3);  
//  if(i==3)
//  { PrintASCII(x+15,y,"...NO"); 
//  }
//  close_coin_power(); 
//  delayms(1000);
  
  ////14.������Ӳ�Ҽ��
  //OPEN_IRDA_IRQ();
  //x=40;
  //y+=16;
  //PrintASCII(x,y,"14.Coin");
  //delayms(1000);
  //wake_flag=0;
  //PrintASCII(x+14,y,"......");
  //delayms(3000);
  //if(wake_flag ==Wakeup_COIN)
  //{ PrintASCII(x+26,y,"OK");}
  //else
  //{ PrintASCII(x+26,y,"NO");}
  //CLOSE_IRDA_IRQ();
  
  

  
  //13.�������
  //14.�ܲ�ͨ���
  //18.�¹������
  

