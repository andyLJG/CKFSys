#ifndef _ADC_H
#define _ADC_H

#include "stm32f10x.h"
#include "delay_systick.h"

#define  ADCVALVEMAX   6  //6����ƽ��ֵ

#define  MAXLOTAGE     8100  //
#define  SECONDLOTAGE  7600  //
#define  THREELOTAGE   7100  //
#define  FOURLOTAGE    6600  //+600
#define  STDVLOTAGE    5800  //
#define  MINVLOTAGE    5600  //

////ADC2ת�����ƽ�
#define ADCCTRL_0               GPIO_ResetBits(GPIOB, GPIO_Pin_8)
#define ADCCTRL_1	        GPIO_SetBits(GPIOB, GPIO_Pin_8)


//ADC��ֵ
typedef struct
{   
  u8 length_mainvoltge;   //�Ѿ�   
  u8 eventotal;  
  u16 evenvalue;
  u16 main_voltage[ADCVALVEMAX]; 
}ADCValveInformation; 	

extern ADCValveInformation ADCinf;


extern u8 TestADC1(void);
extern unsigned char LowVoltage_Test(u8 type);

#endif 

