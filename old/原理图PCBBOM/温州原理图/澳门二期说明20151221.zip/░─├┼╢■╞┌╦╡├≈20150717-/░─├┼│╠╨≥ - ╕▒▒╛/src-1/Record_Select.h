#ifndef _RECORD_SELECT_
#define _RECORD_SELECT_

#include "stdio.h"
#include "string.h"
#include "stm32f10x_conf.h"
#include "hal.h"
#include "MemoryAssign.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Key.h"
#include "Count.h"
//#include "Coin.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
//#include "Gprs_online.h"
#include "stm32f10x_pwr.h"
#include "stm32f10x_wwdg.h"
#include "main.h"
#include "rate.h"
//#include "loader.h"
#include "spi_flash.h"
#include "fsmc_sram.h"
#include "IC_demo.h"
#include "rate_JM.h"
#include "ir_comm.h"

//��ѯ��¼ 
//void SelectRecordToPrint(uchar SelectCount);
void IAP_UpData(uchar flag);

void SelectRecordToPrint1(uchar SelectCount);

void SaveResetRecord(uchar *buffer,uchar count,uchar car);

void sendUpdataCommand(uchar flag);

uchar RequitUpdateProgram(u16 PageCount);

uchar recUpdataPro(uchar delay_wait,int data[]);

#endif