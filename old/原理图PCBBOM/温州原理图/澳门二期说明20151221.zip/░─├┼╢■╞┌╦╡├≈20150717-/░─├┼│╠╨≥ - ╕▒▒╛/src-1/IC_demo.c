#include <stdio.h>

#include "IC_demo.h"
#include "Smart_card.h"
#include "Do_Task.h"
#include "Gprs_online.h"
#include "lcd_12864.h"

//#define DD_DEBUG    //�������Ļ����Ϳ��ٿ���




#define INIT_FLAG 0x5E//2015-08-03 YW5D   

#define QUIT_TIME   0 //��ʾ��ʱ�� ���� ���˶�ú�����
#define WAITE_TIME  3

u8 frist_key_flag;
u8 second_key_flag;
u8 Sec_key_flag;
u8 Fri_key_flag;

unsigned char time[7],time1[7],time10[7],IAP_Night,LIST_UD[10];
uchar IP[16];
uchar PORT[5];

extern uchar HZ[];  
extern void PWR_EnterSLEEPMode(u32 SysCtrl_Set, u8 PWR_SLEEPEntry);
extern void GPIO_Configuration(void);

void sleepLcd1(void);

ErrorStatus HSEStartUpStatus;


void test_flash11(void)
{
	u8 buf1_0[4],nbuf10[4],nbuf30[4];
	  u8 buf1_1[4]; 
	  buf1_0[0]=0xD1;
	  buf1_0[1]=0xD2;
	  buf1_0[2]=0xD3;
	  buf1_0[3]=0xD4;
			
	  SPI_FLASH_Init(); 
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x300000,4);
	  
	  SPI_FLASH_BufferRead(buf1_1,0x100000,4);
	  SPI_FLASH_SectorErase(0x100000);
	   SPI_FLASH_BufferRead(buf1_1,0x100000,4); 
	  SPI_FLASH_BufferWrite(buf1_0, 0x100000, 4);	
	  SPI_FLASH_BufferRead(buf1_1,0x100000,4);
	  
	   buf1_0[0]=0xD5;
	  buf1_0[1]=0xD6;
	  buf1_0[2]=0xD7;
	  buf1_0[3]=0xD8;
	  
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x300000,4);
	  
	  SPI_FLASH_BufferRead(buf1_1,0x300000,4);
	  SPI_FLASH_SectorErase(0x300000);
	  
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x300000,4);
	  
		SPI_FLASH_BufferRead(buf1_1,0x100000,4);
	  SPI_FLASH_BufferRead(buf1_1,0x300000,4);	  
	  SPI_FLASH_BufferWrite(buf1_0, 0x300000, 4);	
	  
	  SPI_FLASH_BufferRead(buf1_1,0x300000,4);	
		SPI_FLASH_BufferRead(buf1_1,0x100000,4);  
	  SPI_FLASH_BufferRead(buf1_1,0x200000,4);
	  
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x300000,4);
          SPI_FLASH_BufferRead(nbuf30,0x300000,4);
	  
}


void test_flash(void)
{
	u8 buf1_0[4],nbuf10[4],nbuf30[4];
	  u8 buf1_1[4]; 
	  buf1_0[0]=0xD1;
	  buf1_0[1]=0xD2;
	  buf1_0[2]=0xD3;
	  buf1_0[3]=0xD4;
			
	  SPI_FLASH_Init(); 
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x110000,4);
	  
	  SPI_FLASH_BufferRead(buf1_1,0x100000,4);
	  SPI_FLASH_SectorErase(0x100000);
	   SPI_FLASH_BufferRead(buf1_1,0x100000,4); 
	  SPI_FLASH_BufferWrite(buf1_0, 0x100000, 4);	
	  SPI_FLASH_BufferRead(buf1_1,0x100000,4);
	  
	   buf1_0[0]=0xD5;
	  buf1_0[1]=0xD6;
	  buf1_0[2]=0xD7;
	  buf1_0[3]=0xD8;
	  
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x110000,4);
	  
	  SPI_FLASH_BufferRead(buf1_1,0x110000,4);
	  SPI_FLASH_SectorErase(0x110000);
	  
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x110000,4);
	  
		SPI_FLASH_BufferRead(buf1_1,0x100000,4);
	  SPI_FLASH_BufferRead(buf1_1,0x110000,4);	  
	  SPI_FLASH_BufferWrite(buf1_0, 0x110000, 4);	
	  
	  SPI_FLASH_BufferRead(buf1_1,0x110000,4);	
		SPI_FLASH_BufferRead(buf1_1,0x100000,4);  
	  SPI_FLASH_BufferRead(buf1_1,0x110000,4);
	  
	  SPI_FLASH_BufferRead(nbuf10,0x100000,4);
	  SPI_FLASH_BufferRead(nbuf30,0x110000,4);
          SPI_FLASH_BufferRead(nbuf30,0x110000,4);
	  
}


void INI_SYSFROM(void)
{
u32 Addr;
u16 i;
u8 flag_buffer[16],buffer[32],BCC;

		///////////////��ʾ ϵͳ��ʼ�� /////////////////////////////
		display_sysytem_init(); 	
		
		buffer[4]= 0x15;	//��			  
		buffer[3]= 0x08;	//��			  
		buffer[2]= 0x08;	//��			  
		buffer[1]= 0x08;	//ʱ			  
		buffer[0]= 0x08;	//��							  
		buffer[5]= mathweek(buffer[4],buffer[3],buffer[2]); 				  
		set_current_time(buffer); 			  
		
		/////////////////�ص�///////////////
		LED1_OFF;
		LED2_OFF;
		LED3_OFF;
		LED4_OFF;
		////////////////////////////////////	   
		INI_SYSLIST();//��ʼ��b1-b8�����洢�� 2015-07-27
		INI_SYSCARIMG();//����ͳ�ʼ��������������� 2015-04-16
		////////////////�������λ״̬��Ϣ//////////////////////
		buffer[0] = 1;
		I2C_WriteS_24C(SYS_RTC,buffer,1);//ʱ��ʵʱ���¿���
		I2C_WriteS_24C(SYS_LOCKCPC,buffer,1);//ʱ��ʵʱ���¿���
		for(i=0;i<16;i++)
		  buffer[i] = 0x00;
		I2C_WriteS_24C(SYS_SN,buffer,4);//��ˮ������
		I2C_WriteS_24C(car1_used_reference_info,buffer,16);//��λ��Ϣ
		I2C_WriteS_24C(car2_used_reference_info,buffer,16);
		I2C_WriteS_24C(car3_used_reference_info,buffer,16);
		I2C_WriteS_24C(car4_used_reference_info,buffer,16);
		
		I2C_WriteS_24C(car1_no_S_flag,buffer,4);
		I2C_WriteS_24C(car2_no_S_flag,buffer,4);
		I2C_WriteS_24C(car3_no_S_flag,buffer,4);
		I2C_WriteS_24C(car4_no_S_flag,buffer,4);
		
		I2C_WriteS_24C(car1_smartCard_momenry,buffer,4); //��λ���
		I2C_WriteS_24C(car2_smartCard_momenry,buffer,4);
		I2C_WriteS_24C(car3_smartCard_momenry,buffer,4);
		I2C_WriteS_24C(car4_smartCard_momenry,buffer,4);
		////////////////////////////////////////////////////////	  
		
		///////////////// FLASH���� ��ʼ����������ַ������/////////////////////////////
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count,buffer,4); //��ʼ��ַ

		I2C_WriteS_24C(SYS_SN,buffer,4);//���˼�¼��ˮ��
		I2C_WriteS_24C(SYS_FEESN,buffer,2);//������ˮ��
		I2C_WriteS_24C(SYS_WARSN,buffer,2);//������ˮ��
		
		buffer[0] = 0x00;
		buffer[1] = 0x0C;
		buffer[2] = 0x35;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count + 4,buffer,4); //������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count + 8,buffer,4); //����������
		///////////////////////////��ʼ�� EEPROM��ַ/////////////////////////////////// ���û��ʹ��
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(EEPROM_last_time_down_addr,buffer,2); //EEPROM �ϴ����ص�ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(addr_of_current_in_EEPROM,buffer,2); //EEPROM ��¼�洢��ǰ��ַ
		/////////////////////////////////FLASH ��ʼ�� ///////////////////////////////// ���ûʹ��
		buffer[0] = 0x00;
		I2C_WriteS_24C(full_of_FLASH_flag,buffer,1); //FLASH ������־
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		I2C_WriteS_24C(clear_4K_of_FLASH_addr,buffer,3); //FLASH 4K������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(FLASH_last_time_down_addr,buffer,3); //FLASH ��¼�ϴ����ص�ַ
		buffer[2] = 0x00;
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		I2C_WriteS_24C(addr_of_current_in_FLASH,buffer,3); //FLASH ��¼�洢��ǰ��ַ 	  

		buffer[0] = 0x12;
		buffer[1] = 0x34;
		buffer[2] = 0x56;
		buffer[3] = 0x78;	
		I2C_PageWrite_24C(mibiao_number,buffer,4);//��ʼ������ţ�2015-05-04
		///////////////////////////////������//////////////////////////////////////////
		//55002109643202033000240204991200
		buffer[0] = 0x00;
		buffer[1] = 0x21;
		buffer[2] = 0x09;
		buffer[3] = 100;
		buffer[4] = 50;
		buffer[5] = 0x02;
		buffer[6] = 0x03;
		buffer[7] = 0x30;
		buffer[8] = 0x00;
		buffer[9] = 0x24;
		buffer[10] = 0x02;
		buffer[11] = 0x04;
		buffer[12] = 0x99;
		buffer[13] = 0x12;
		buffer[14] = 0x30;
		buffer[15] = 0xF3;
		
		BCC = 0x00;
		for(i=0;i<15;i++)
		  BCC = BCC ^ buffer[i];
		buffer[15] = BCC;			 
			
		I2C_WriteS_24C(B_startTime_unit_of_hour,buffer,16);
		I2C_WriteS_24C(back_argument_of_charge,buffer,16);
		
		//////////////////////////////�ݴ泵λ����/////////////////////////////////////
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(car1_number_temporal,buffer,4);//�ݴ�1�ų�λ���� д������ʱ
		I2C_WriteS_24C(car2_number_temporal,buffer,4);
		I2C_WriteS_24C(car3_number_temporal,buffer,4);
		I2C_WriteS_24C(car4_number_temporal,buffer,4);
		
		///////////////////////��������ļ�¼����///////////////////////////////////////
		buffer[0] = 0x17;
		buffer[1] = 0xE0;
		I2C_WriteS_24C(Con_Fm_Record_112_Start_Addr,buffer,2);//��ʼ��ַ  112
		I2C_WriteS_24C(Con_Fm_Record_112_Cursor,buffer,2);//���¼��ַ�α�
		I2C_WriteS_24C(Con_Fm_Record_112_UDCSR,buffer,2);//GPRS ���ؼ�¼��ַ�α�
		I2C_WriteS_24C(Con_Fm_Record_112_UDCSR_P,buffer,2);//POS�� ���ؼ�¼��ַ�α�
		
		buffer[0] = 0x59;
		buffer[1] = 0x80;
		I2C_WriteS_24C(Con_Fm_Record_112_End_Addr,buffer,2);//������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(Con_Fm_Record_112_Count,buffer,2);//����
		I2C_WriteS_24C(Con_Fm_Record_112_Cursor_F,buffer,1);//�α�Խ���ı�־λ
		
		
		buffer[0] = 0x5A;
		buffer[1] = 0x00;
		I2C_WriteS_24C(Con_Fm_Record_16_Start_Addr,buffer,2);//��ʼ��ַ  16
		I2C_WriteS_24C(Con_Fm_Record_16_Cursor,buffer,2);//���¼��ַ�α�
		I2C_WriteS_24C(Con_Fm_Record_16_UDCSR,buffer,2);//GPRS ���ؼ�¼��ַ�α�
		I2C_WriteS_24C(Con_Fm_Record_16_UDCSR_P,buffer,2);//POS�� ���ؼ�¼��ַ�α�
		
		buffer[0] = 0x7F;
		buffer[1] = 0x80;
		I2C_WriteS_24C(Con_Fm_Record_16_End_Addr,buffer,2);//������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(Con_Fm_Record_16_Count,buffer,2);//����
		I2C_WriteS_24C(Con_Fm_Record_16_Cursor_F,buffer,1);//�α�Խ���ı�־λ
		
		///////////////////////FLASH����ļ�¼����//////////////////////////////////////
		buffer[0] = 0x0D;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		I2C_WriteS_24C(Con_Flash_Record_16_Start_Addr,buffer,3);//��ʼ��ַ	32
		I2C_WriteS_24C(Con_Flash_Record_16_Cursor,buffer,3);//���¼��ַ�α�
		I2C_WriteS_24C(Con_Flash_Record_16_UDCSR,buffer,3);//���ؼ�¼��ַ�α�
		I2C_WriteS_24C(Con_Flash_Record_16_UDCSR_P,buffer,3);//POS ���ؼ�¼��ַ�α�
		
		buffer[0] = 0x19;
		buffer[1] = 0x35;
		buffer[2] = 0x00;
		I2C_WriteS_24C(Con_Flash_Record_16_End_Addr,buffer,3);//������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(Con_Flash_Record_16_Count,buffer,3);//����
		I2C_WriteS_24C(Con_Flash_Record_16_Cursor_F,buffer,1);//�α�Խ���ı�־λ
		
		buffer[0] = 0x1A;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		I2C_WriteS_24C(Con_Flash_Record_112_Start_Addr,buffer,3);//��ʼ��ַ  16
		I2C_WriteS_24C(Con_Flash_Record_112_Cursor,buffer,3);//���¼��ַ�α�
		I2C_WriteS_24C(Con_Flash_Record_112_UDCSR,buffer,3);//���ؼ�¼��ַ�α�
		I2C_WriteS_24C(Con_Flash_Record_112_UDCSR_P,buffer,3);//POS ���ؼ�¼��ַ�α�
		
		buffer[0] = 0x6F;
		buffer[1] = 0x73;
		buffer[2] = 0x00;
		I2C_WriteS_24C(Con_Flash_Record_112_End_Addr,buffer,3);//������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(Con_Flash_Record_112_Count,buffer,3);//����
		I2C_WriteS_24C(Con_Flash_Record_112_Cursor_F,buffer,1);//�α�Խ���ı�־λ
		
		///////////////////////////////δ������¼��ʼ��/////////////////////////////////
		for(uchar i=0;i<8;i++)
		  buffer[i] = 0x00;
		I2C_WriteS_24C(car1_false_record,buffer,8);
		I2C_WriteS_24C(car2_false_record,buffer,8);
		I2C_WriteS_24C(car3_false_record,buffer,8);
		I2C_WriteS_24C(car4_false_record,buffer,8);
	   
		////////////////////////////��Կ��ʼ��//////////////////////////////////
		buffer[0]=0x07;
		buffer[1]=0x55;
		buffer[2]=0x83;
		buffer[3]=0x26;
		buffer[4]=0x62;
		buffer[5]=0x36;
		buffer[6] = buffer[0] ^ buffer[1] ^ buffer[2] ^ buffer[3] ^ buffer[4] ^ buffer[5];
		I2C_WriteS_24C(sysytem_public_key,buffer,7);  //���ܺ����в�������
		I2C_WriteS_24C(sysytem_public_key_back,buffer,7);  //���ܺ����в�������
		
		/////////////////////////////IP��ַ�Ͷ˿ں�/////////////////////////////
		for(i=0;i<6;i++)										
		  buffer[i] = 0x00;
		I2C_WriteS_24C(PSAM_ADRee,buffer,6);//��pasm��
		
		buffer[0] = 192;
		buffer[1] = 168;
		buffer[2] = 0;
		buffer[3] = 1;
		buffer[4] = 0x80;
		buffer[5] = 0x40;
		I2C_WriteS_24C(IPADrees,buffer,6);//��IP��
		
		//////////////////////////////δ������¼////////////////////////////////
		for(i=0;i<112;i++)									  
		  buffer[i] = 0x00;
		
		I2C_WriteS_24C(car1_false_record,buffer,112);
		I2C_WriteS_24C(car2_false_record,buffer,112);
		I2C_WriteS_24C(car3_false_record,buffer,112);
		I2C_WriteS_24C(car4_false_record,buffer,112);
		
		///////////////////////////���� �������ĳ�ʼ��/////////////////////////  30000��
		buffer[0] = 0x00;
		buffer[1] = 0x70;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count_day,buffer,4);//������������ �׵�ַ
		I2C_WriteS_24C(BackList_Cursor_day,buffer,4);//������������ �α��ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x73;
		buffer[2] = 0xA9;
		buffer[3] = 0x80;
		I2C_WriteS_24C(backList_Addr_and_Count_day + 4,buffer,4);//������������ ������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count_day + 8,buffer,4); //���������� ����   
		
		buffer[0] = 0x00;
		buffer[1] = 0x0C;
		buffer[2] = 0x40;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count_day + 12,buffer,4); //���������� �ڴ濪ʼ��ŵĵ�ַ
		
		///////////////////////////���� �������ĳ�ʼ��///////////////////////// 10960��
		buffer[0] = 0x00;
		buffer[1] = 0x73;
		buffer[2] = 0xA9;
		buffer[3] = 0x80;
		I2C_WriteS_24C(backList_Addr_and_Count_day_reduce,buffer,4);//������������ �׵�ַ
		I2C_WriteS_24C(BackList_Cursor_day_reduce,buffer,4);//������������ �α��ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x77;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count_day_reduce + 4,buffer,4);//������������ ������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count_day_reduce + 8,buffer,4); //���������� ����	 
		
		buffer[0] = 0x00;
		buffer[1] = 0x10;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(backList_Addr_and_Count_day_reduce + 12,buffer,4); //���������� �ڴ濪ʼ��ŵĵ�ַ 
		
		///////////////////////////////////////////////////////////////////////
		buffer[0] = 0x00;
		I2C_WriteS_24C((car1_value_comd),buffer,1);
		I2C_WriteS_24C((car2_value_comd),buffer,1);
		I2C_WriteS_24C((car3_value_comd),buffer,1);
		I2C_WriteS_24C((car4_value_comd),buffer,1);
		
		I2C_WriteS_24C((car1_write_comd),buffer,1);
		I2C_WriteS_24C((car2_write_comd),buffer,1);
		I2C_WriteS_24C((car3_write_comd),buffer,1);
		I2C_WriteS_24C((car4_write_comd),buffer,1);
		///////////////////////////////////////////////////////////////////////
		
		//////////////////////��� �ͣɣƣ��ңſ���ˢ��ʧ��ʱ��������Ϣ////////
		for(i=0;i<16;i++)
		  buffer[i] = 0x00;
		for(i=1;i<=4;i++)
		  save_mifare_NO(buffer,buffer,i);

		///////////////////////��� ����Flash�ı��////////////////////////////
		buffer[0] = 0x00;
		I2C_WriteS_24C(Flash_erased_sector_32_F,buffer,1);//�� ������ַ���α� ��־
		I2C_WriteS_24C(Flash_erased_sector_112_F,buffer,1);
		
		buffer[0] = 0x66;
		I2C_WriteS_24C(Flash_erased_sector_32_L,buffer,1);//�� ������ַ���α� ��־
		I2C_WriteS_24C(Flash_erased_sector_112_L,buffer,1);
		///////////////////////////////////////////////////////////////////////
							  
		I2C_WriteS_24C(LOW_VOLTAGE_F,buffer,1);//�͵�ѹ������¼ ���� ��1����д�ص�ַ��ȥ
		
		/////////////////////����ʱ������///////////////////////////////////////
		buffer[0] = 0x17;
		buffer[1] = 0x00;
		buffer[2] = 0x06;
		buffer[3] = 0x00;
		I2C_WriteS_24C(BACK_TIME,buffer,4);//���������ʱ��

		for(i=1;i<=4;i++)
		  WriteRecover(i,0);
		
		/////////////////////��¼���ͻ��Ƶ� ����////////////////////////////////ʵʱ����
		buffer[0] = 4;
		buffer[1] = 1;
		buffer[2] = 4;
		buffer[3] = 2;
		buffer[4] = 4;
		I2C_WriteS_24C(SendInterval,buffer,5);
		////////////////////////////////////////////////////////////////////////
			   
		//////////////////////////����ͨ ������������ �ϵ����//////////////////////////////
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(RequitPageCount,buffer,2);//ȫ��
		I2C_WriteS_24C(BackListAllCount,buffer,2);
		
		I2C_WriteS_24C(LNT_BACLK_RequitPage_DAY,buffer,2);//����
		I2C_WriteS_24C(LNT_BACLKALLCount_DAY,buffer,2);
		
		I2C_WriteS_24C(LNT_BACLK_RequitPage_Reduce,buffer,2);//����
		I2C_WriteS_24C(LNT_BACLK_ALLCount_Reduce,buffer,2);
		////////////////////////////////////////////////////////////////////////
		
		//////////////////////////�Է��� ����ʱ �ݴ�����////////////////////////
		buffer[0] = 0x00;																	   
		I2C_WriteS_24C(ReplenMoneryFlag,buffer,1);																		
		I2C_WriteS_24C(ReplenBlockFlag,buffer,1);																	  
		for(i=0;i<8;i++)																	   
		  buffer[i] = 0;																										 
		I2C_WriteS_24C(ReplenishmentNo,buffer,8);																	 
		I2C_WriteS_24C(ReplenishmentMonery,buffer,4);
		////////////////////////////////////////////////////////////////////////
		
		/////////////////////////////�Զ���λ ��ʱ ��¼/////////////////////////
		for(uchar i=0;i<32;i++)
		  buffer[i] = 0x00;
		I2C_WriteS_24C(ResetCar1Flag,buffer,1);
		I2C_WriteS_24C(ResetCar2Flag,buffer,1);
		I2C_WriteS_24C(ResetCar3Flag,buffer,1);
		I2C_WriteS_24C(ResetCar4Flag,buffer,1);
		
		I2C_WriteS_24C(ResetRecordCar1,buffer,32);
		I2C_WriteS_24C(ResetRecordCar2,buffer,32);
		I2C_WriteS_24C(ResetRecordCar3,buffer,32);
		I2C_WriteS_24C(ResetRecordCar4,buffer,32);
		////////////////////////////////////////////////////////////////////////
		
		/////////////////////////////�Է�����������ַ��ʼ��///////////////////// ÿ��4�ֽ�		  
		//�Է��� ������������ 7000��
		buffer[0] = 0x00;
		buffer[1] = 0x0C;
		buffer[2] = 0x35;
		buffer[3] = 0x00;
		I2C_WriteS_24C(MIFARE_BACLK_DAY_ADD_AC,buffer,4); //��ʼ��ַ
		I2C_WriteS_24C(MIFARE_BACLK_Cursor_day,buffer,4);//������������ �α��ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x0C;
		buffer[2] = 0xA2;
		buffer[3] = 0x60;
		I2C_WriteS_24C(MIFARE_BACLK_DAY_ADD_AC + 4,buffer,4); //������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(MIFARE_BACLK_DAY_ADD_AC + 8,buffer,4); //����������
		I2C_WriteS_24C(MIFARE_BACLK_ALLCount_DAY ,buffer,2);
		I2C_WriteS_24C(MIFARE_BACLK_RequitPage_DAY ,buffer,2);
		
		//�Է��� �ռ��������� 5992��
		buffer[0] = 0x00;
		buffer[1] = 0x0C;
		buffer[2] = 0xA2;
		buffer[3] = 0x60;
		I2C_WriteS_24C(MIFARE_BACLK_DAY_REDUC_AC,buffer,4); //��ʼ��ַ
		I2C_WriteS_24C(MIFARE_BACLK_Cursor_day_reduce,buffer,4);//������������ �α��ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x0D;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(MIFARE_BACLK_DAY_REDUC_AC + 4,buffer,4); //������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(MIFARE_BACLK_DAY_REDUC_AC + 8,buffer,4); //����������
		I2C_WriteS_24C(MIFARE_BACLK_ALLCount_Reduce ,buffer,2);
		I2C_WriteS_24C(MIFARE_BACLK_RequitPage_Reduce ,buffer,2);
		
		///////////////////////������ ���ڴ�ĵ�ַ//////////////////////////////
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		
		I2C_WriteS_24C(LNT_BaclkMoneryAddrAll,buffer,4); 
		I2C_WriteS_24C(LNT_BaclkMoneryAddrDay_Add,buffer,4);
		I2C_WriteS_24C(LNT_BaclkMoneryAddrDay_Reduce,buffer,4);
		
		I2C_WriteS_24C(MIFARE_BaclkMoneryAddrDay_Add,buffer,4);
		I2C_WriteS_24C(MIFARE_BaclkMoneryAddrDay_Reduce,buffer,4);		  

		///////////////////////����������� ��flash�ĳ�ʼ��/////////////////////
		buffer[0] = 0x00;
		buffer[1] = 0x77;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(UpdateProgramAddr,buffer,4);//����������� ��ʼ��ַ
		I2C_WriteS_24C(UpdateCoursor,buffer,4);//����������� �����α�
		
		buffer[0] = 0x00;
		buffer[1] = 0x7F;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(UpdateProgramAddr + 4,buffer,4);//����������� ������ַ
		
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(UpdateProgramAddr + 8,buffer,4);//����������� ����
		
		buffer[0] = 0x00;
		buffer[1] = 0x7F;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		I2C_WriteS_24C(UpdateFlagAddr,buffer,4);//������־ ��ַ  ���� 3  ��־ 4
		
		I2C_ReadS_24C(UpdateProgramAddr + 8,flag_buffer,4);
		I2C_ReadS_24C(UpdateFlagAddr,buffer,4);
		Addr = hcl(buffer,4);
		SPI_FLASH_BufferWrite(flag_buffer+1,Addr,3);//д������������
		
		buffer[0] = 0xA2;
		I2C_WriteS_24C(IAPBreakPointResume,buffer,1);//IAP�ϵ����� �ı�־
			   
		for(i=0;i<4;i++)
			{		
			flag_buffer[i] = 0x00;//������־
			}
		SPI_FLASH_BufferWrite(flag_buffer,Addr+3,4);//д������־
		 
		buffer[0] = 0x00;
		buffer[1] = 0x00;
		I2C_WriteS_24C(Update_RequitPage,buffer,2);//��������İ���
		I2C_WriteS_24C(Update_ALLCount,buffer,2);//Ӧ��������ܰ���
		
		buffer[0] = 0xA2;
		I2C_WriteS_24C(IAPUpdataClass,buffer,1);//ѡ���Զ�����
		buffer[0] = 0x04;
		buffer[1] = 0x00;
		I2C_WriteS_24C(IAPUpdataTime,buffer,2);//����ʱ�� 04:00
		
		buffer[0] = 0xA2;
		I2C_WriteS_24C(FreeClass,buffer,1);//����ѡ���Զ�����
		buffer[0] = 0x04;
		buffer[1] = 0x50;
		I2C_WriteS_24C(FreeUpdataTime,buffer,2);//����ʱ�� 04:50
		
		buffer[0] = 0xA2;
		I2C_WriteS_24C(LNTClass,buffer,1);//����ͨ ���������ط�ʽ �Զ�
		I2C_WriteS_24C(MIFAREClass,buffer,1);//�Է��� ���������ط�ʽ �Զ�
		////////////////////////////////////////////////////////////////////////
		//99 04 06 10 02 28 04 04 04 24
		buffer[0] = 0x99;
		buffer[1] = 0x04;
		buffer[2] = 0x06;
		buffer[3] = 0x10;
		buffer[4] = 0x02;
		buffer[5] = 0x28;
		buffer[6] = 0x04;
		buffer[7] = 0x04;
		buffer[8] = 0x04;
		buffer[9] = 0x24;
		I2C_WriteS_24C(LISTNET_ADD,buffer,16);//0-��־99 1- 2- 3-���ͼ��Ƶ�� 4- 5-Υ��ʱ��

		//////////////////////�¿���������־����////////////////////////////////
		buffer[0] = 0x00;
		for(i=0;i<4;i++)
			{
			I2C_WriteS_24C(MonthCarInERRORCar1+i,buffer,1);
			I2C_WriteS_24C(MonthCarOutERRORCar1+i,buffer,1);
			I2C_WriteS_24C(MonthCarCountERRORCar1+i,buffer,1);
			}
		goto_xy(0x02,16);
		print_str_16_16("flash...");	  //�汾��
		
		SPI_FLASH_BulkErase();
		
		for(i = 0;i< 16;i++)
		  buffer[i] = INIT_FLAG;//д�� �Ѿ���ʼ���� �ı�־
		I2C_WriteS_24C(initialize_EEPROM,buffer,16);
		//������λһ��
		GenerateSystemReset();
}

void IC_demo(void)
{
	u8 i,flag,buffer[112],LowVoltage,IQKEY;	
    carStation_reference_of_used CS_RF_US;    
    uchar BCC,read_mech_ID_flag,CommunicationFlag;
    long timeOut = 0;
    uchar Mater_Buf[3],block1_buffer[32],flag_buffer[16];
	//Rate_reference_ST *fee;
   
   	//get_rate_ref(fee);
    key_flag=0;
	
    ChipHalInit();			//Ƭ��Ӳ����ʼ��
    LCD_POWER_ON;   //PG13
    LCD_back_ON;    //PB13
    ChipOutHalInit();		//Ƭ��Ӳ����ʼ��
    HC244Wake_Close;
  
    NVIC_Configuration();         //NVICǶ��ʽ�жϹ���ϵͳ�ĳ�ʼ��open interrupt  
    IWDG_ReloadCounter();	
    
    /* Enable PWR and BKP clock */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);

	//INI_RX8025SA_RECOVER();
 	for(i;i<5;i++)
		{
		bushimny[i] = 0;   
		bukanmny[i] = 0;   		
		}	

//	FM24CL256_WR_RD_TESTING();
//	RX8025SA_READ_TEST();
//	Car_IMGIQ();

	////////////////////�������汾�ų�ʼ��////////////////////////////////
    buffer[0] = MATERVERSIONB_;
    buffer[1] = MATERVERSION;
    I2C_WriteS_24C(MATER_VER,buffer,2);
    #ifdef CAR
      buffer[0] = 0x02;
    #else
      buffer[0] = 0x04;
    #endif
    I2C_WriteS_24C(MATER_CAR,buffer,1);
        
    while(timeOut < 4)
		{
         I2C_ReadS_24C(initialize_EEPROM,buffer,16);            
         if(buffer[0] == INIT_FLAG && buffer[1] == INIT_FLAG && buffer[3] == INIT_FLAG && buffer[0] == INIT_FLAG && buffer[3] == INIT_FLAG && buffer[8] == INIT_FLAG)
            break;
         timeOut++;
		 }
	
    if(timeOut >= 4)
		INI_SYSFROM();
    else
		{
		buffer[0]= 0;
		//д����/�쳣ˢ���ı�־ 2015-08-06
		I2C_WriteS_24C(Car1_SwipNG+0,buffer,1);
		I2C_WriteS_24C(Car1_SwipNG+1,buffer,1);
		I2C_WriteS_24C(Car1_SwipNG+2,buffer,1);
		I2C_WriteS_24C(Car1_SwipNG+3,buffer,1);
		
        ////////////////////////////�ϵ��ʼ��//////////////////////////////////
        LCD_POWER_ON;
        LCD_back_ON;
        Smart_Power_ON;
        Smart_Power_OFF;
        Smart_Power_ON;
//        open_gprs_power();
//        GPRS_Power_ON;
        close_gprs_power();
        GPRS_Power_OFF;	
		NETSTATE = NETSTATE_CLOSE;//��ʼ������Ϊ�ر�״̬ 2015-04-29andyluo
		
        LED1_OFF;
        LED2_OFF;
        LED3_OFF;
        LED4_OFF;
        ////////////////////////////////////////////////////////////////////////
        GetCurrentTime();  
        display_logo();
        delay(KEYTIMEOUT_1S * 1);
#ifndef DD_DEBUG  
        LED1_ON;
        LED2_ON;
        LED3_ON;
        LED4_ON;
		
		SYS_MS.G3S =ON;//ʹ��3Gģ��
		SYS_MS.G24S =ON;//ʹ��2.4Gģ��

		
        #ifdef TWO_CAR
        display_Logo_1(2);
        #else
        display_Logo_1(4);
        #endif  
		timeOut = KEYTIMEOUT_1S;
		while(timeOut--) 
			{	
			if(key_flag)
				break;	
			}
		if(key_flag)
        {
        //delay(KEYTIMEOUT_1S * 3);
		key_flag = 0;
        /*************************
        //1.���ȼ��        
        //2.LED���
        //3.��ѹ���
        //4.���������
        //5.PSAM�����
        //6.ͨ��ģ����
        *************************/
        lcd_clear();

        uchar clow;
        clow = 1;        
        
        //1.���ȼ��
        buzz_check(clow++);
        Buzz_0;
        delay(KEYTIMEOUT_1S * 1);
        Buzz_1;
        delay(KEYTIMEOUT_1S * 1);
        
//		OPEN_EXTI9_5_IRQ(); 																		 
//		OPEN_EXTI15_10_IRQ();
        if(wake_flag)wake_flag = 0;               
        //2.LED���
        LED_check(clow++);
        LED1_ON;
        LED2_ON;
        LED3_ON;
        LED4_ON;
//        delay(KEYTIMEOUT_1S * 4);
		timeOut = KEYTIMEOUT_1S*21;
		while(timeOut--) 
			{	
			if(key_flag)
				break;	
			if(wake_flag)
				{
				wake_flag = 0;
		        LED1_OFF;
		        LED2_OFF;
		        LED3_OFF;
		        LED4_OFF;
				break;
				}
			}
		i =5;
		if(!timeOut)
			{
			dispaly(clow,i++,(HZ + gu));
			dispaly(clow,i++,(HZ + zhang));
			}
		key_flag = 0;
        //3.��ѹ���
        LowVoltage = LowVoltage_Test();
        Voltage_Check(LowVoltage,clow++);       
        delay(KEYTIMEOUT_1S *1);
		
		LED1_OFF;
		LED2_OFF;
		LED3_OFF;
		LED4_OFF;
        
        //4.���������
        timeOut = 0;
        read_mech_ID_flag = NO;
        while(timeOut < 3)
        {
            if(read_mech_ID() == 0x00)
            {
                read_mech_ID_flag = OK;
                break;
            }
            
            timeOut++;
        }
        display_reader_P(read_mech_ID_flag,clow++);

        delay(KEYTIMEOUT_1S * 1);
		clow = 0x01;

		//5.PSAM�����
		timeOut = 0;
		read_mech_ID_flag = NO;
		while(timeOut < 4)
		{
			if(read_PSAM() == 0x00)
			{
				read_mech_ID_flag = OK;
				break;
			}
			
			timeOut++;
		}		 
		display_PSAM(read_mech_ID_flag,clow++);

		Smart_Power_OFF;
		delay(KEYTIMEOUT_1S * 1);
		
        
//        if(clow > 4)
//        {
//            clow = 0x01;
//            lcd_clear();
//            LED_check(clow++);
//            Voltage_Check(LowVoltage,clow++);  
//            display_reader_P(read_mech_ID_flag,clow++);
//            
//        }
		//5.����	
		lcd_clear_h(clow);
        FROM_check(clow++);
		for(i=0;i<13;i++)buffer[i] = 0xA5;
		I2C_WriteS_24C(LinkNetWorkCount,buffer,13);
		for(i = 0;i<13;i++)buffer[i] = 0;
		I2C_ReadS_24C(LinkNetWorkCount,buffer,13);
		flag = 0;
		for(i=0;i<13;i++)
			{
			if(buffer[i] != 0xA5)
				{
				flag = 1;
				break;
				}
			}
		i = 5;
		if(!flag)
			{
			dispaly(clow-1,i++,(HZ + zheng));
			dispaly(clow-1,i++,(HZ + chang));
			}
		else
			{
			dispaly(clow-1,i++,(HZ + gu));
			dispaly(clow-1,i++,(HZ + zhang));
			}			
		//6.flash		
		lcd_clear_h(clow);
		FLASH_check(clow++);
		SPI_FLASH_Init();
		SPI_FLASH_SectorErase(0);  //��0����
		for(i = 0;i<13;i++)buffer[i] = 0xA5;
		SPI_FLASH_BufferWrite(buffer, 0, 13); //дFLASH
		for(i = 0;i<13;i++)buffer[i] = 0;
		SPI_FLASH_BufferRead(buffer, 0, 13);  //��FLASH
		flag = 0;
		for(i=0;i<13;i++)
			{
			if(buffer[i] != 0xA5)
				{
				flag = 1;
				break;
				}
			}
		i = 5;
		if(!flag)
			{
			dispaly(clow-1,i++,(HZ + zheng));
			dispaly(clow-1,i++,(HZ + chang));
			}
		else
			{
			dispaly(clow-1,i++,(HZ + gu));
			dispaly(clow-1,i++,(HZ + zhang));
			}			

		//7.2.4G-ck
		lcd_clear_h(clow);
		G24_check(clow++);
		flag = BT_CK();
		i = 5;
		if(!flag)
			{
			dispaly(clow-1,i++,(HZ + zheng));
			dispaly(clow-1,i++,(HZ + chang));
			}
		else
			{
			dispaly(clow-1,i++,(HZ + gu));
			dispaly(clow-1,i++,(HZ + zhang));
			}			
		
        Smart_Power_OFF;
        //8.ͨ��ģ����
        //��ʾͨ��ģ������...
		lcd_clear_h(clow);
        Communation_check(clow++);
        if(wake_flag)            
          wake_flag = 0;               
        IWDG_ReloadCounter();
        if(key_flag) 
          key_flag = 0;
//		CommunicationFlag =Initial_3G(10);
        CommunicationFlag = open_gprs();
        if(CommunicationFlag == OK)//�������ϵͳ��ǰ�汾 ����̨
        {
            int buf[16];
            for(int i=0;i<RxCounter;i++)
               RxBuffer[i]=0x00; 
            
            RxCounter = 0;
            f_receiveOK = 0;
            sendUpdataCommand(8);
            rec_IAP(4,buf);
			NETSTATE = NETSTATE_LINK;
			
        }
        Communation_OK(CommunicationFlag,clow-1);

		G3_PowerOFF_Mode();
        delay(KEYTIMEOUT_1S * 3);
        
#endif       
    	}
        
     
//        /////////////////////////�����������ڴ�/////////////////////////////////        
//        //��FLASH �������� ��SROM
//        read_Blacklist_to_Memory();        
        ////////////////////////////////////////////////////////////////////////   
        
        LowVoltage = LowVoltage_Test();
        if(LowVoltage != 0) 
			{
            uchar flag_buffer[16];
            I2C_ReadS_24C(LOW_VOLTAGE_F,flag_buffer,1);
            flag_buffer[0] = 0x00;
            I2C_WriteS_24C(LOW_VOLTAGE_F,flag_buffer,1);//�͵�ѹ������¼ ���� ��1����д�ص�ַ��ȥ
        	} 
        
        /////////////////////////��ģ���Դ�ر�/////////////////////////////////
        Smart_Power_OFF;
		if(Judge_MB_MODE()==1)
			GPRS_Power_OFF;
        LCD_POWER_ON;
        LCD_back_OFF; 
        //////////////////////////////////////////////////////////////////////// 

    }
    
    //д�� �������ʱ��
    GetCurrentTime(); 
    I2C_WriteS_24C(MaterRunTime,time,5);
    
    //д��������ʧ����������
    for(i=0;i<13;i++)
      buffer[i] = 0x00;
    I2C_WriteS_24C(LinkNetWorkCount,buffer,13);
    
    /////////////////////////����λ״̬�ָ�/////////////////////////////////                
    for(i=1;i<=4;i++)
		{
		I2C_ReadS_24C(0x10 * (i-1) ,buffer,1);
        if(buffer[0] == 0x66)
           light(i,OK);
        else
           light(i,NO);
		}
    ////////////////////////////////////////////////////////////////////////
       
    if(wake_flag)wake_flag = 0;               
     
    if(key_flag)key_flag = 0;

	IAP_Night = 1;
    IWDG_ReloadCounter();

//	buffer[0] = 0x01;
//	buffer[1] = 0x02;
//	buffer[2] = 0x00;
//	buffer[3] = 0x00;	
//	I2C_PageWrite_24C(mibiao_number,buffer,4);//��ʼ������ţ�2015-05-04
	for(i=0;i<CarCounter;i++)
	   CarBuffer[i]=0x00; 	
	CarCounter = 0;
	
//test_flash();

	open_ir_comm();
	UART4_IRQn_CTL(ON);//�򿪳����������ж� 2015-04-29
	Set_G24_BaseM();//����2.4Gģ����Ҫ���յĳ�������
	
	if(Judge_MB_MODE()==0)//�м������2G4��Դ 2015-04-30 andyluo
		{
		if(NETSTATE != NETSTATE_LINK)
			{
			lcd_clear();
			Communation_check(2);
			CommunicationFlag = open_gprs();
//			if(CommunicationFlag==OK)
				{
				Communation_OK(CommunicationFlag,2);
				}
			}
		open_ir_comm();
		UART4_IRQn_CTL(ON);//�򿪳����������ж� 2015-04-29
		Set_G24_BaseM();//����2.4Gģ����Ҫ���յĳ�������
		}
	else
		{
//		MBtoBase_Card();
		
		if(SYS_MS.INT_BASE == TRUE)
			{
			close_ir_comm();
			UART4_IRQn_CTL(OFF);
			}
		}
	//CMY_MF1A();
//	MBtoBase_Card();
//	INI_SYSLIST();//��ʽ��Ҫ����
	GetList_FlashtoSRAM();
//	Update_SYSList(0);
	for(i=0;i<10;i++)//LIST_UD[9] ��ʾ����SRAM
		LIST_UD[i] = 1;
	SYS_LIST.nowbx = 0;
	
while(1)
	{ 
//	sleepout1();
    key_flag = key_flagbk;
//	if(key_flag)
	if(key_flagbk)
		{
		sleepout1();
		key_flag = key_flagbk;	
        LowVoltage = LowVoltage_Test(); 
        frist_key_flag = key_flag;
        second_key_flag = 0;        
        Fri_key_flag = 1;
        Sec_key_flag = 0;
        key_flag = 0;
		key_flagbk = 0;
		Smart_Power_ON;//ÿһ�� ˢ�� ��Ҫ �ϵ�
        delay(KEYTIMEOUT_1S * 0.3);
//        delay(KEYTIMEOUT_1S * 0.15);
        if(key_flag)
			{
            frist_key_flag = 0;
            second_key_flag = key_flag;            
            Fri_key_flag = 0;
            Sec_key_flag = 1;
			}
        key_flag = 0;                   
        if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����
          LCD_back_ON;
        else
          LCD_back_OFF;		
        DISABLE_EXTI15_10_IRQ();      
        DISABLE_EXTI9_5_IRQ();        
        GetCurrentTime();         
        OPEN_EXTI9_5_IRQ();                                                                          
        OPEN_EXTI15_10_IRQ();
        lcd_clear();
        if(frist_key_flag>0)
			I2C_ReadS_24C(0x10 * (frist_key_flag-1) ,buffer,1);
		if(LowVoltage == 1 || (frist_key_flag>0 && buffer[0] == 0x66))
			{ 
			Smart_Power_ON;
//			GPRS_Power_OFF;   
			if(frist_key_flag > 0 && Fri_key_flag == 1)
				{
				Fri_key_flag = 0;
				switch(frist_key_flag)
					{ 
					case K1:
						#ifndef  CAR                  
						quit_key_flag = card_station_check(1); 
						#endif
						break;
					case K2: 
						quit_key_flag = card_station_check(2);
						break;
					case K3:
						quit_key_flag = card_station_check(3);
						break;
					case K4:
						#ifndef  CAR             
						quit_key_flag = card_station_check(4);              
						#endif
						break;
					default:
						break;
					}
				frist_key_flag = 0;
				}
			if(second_key_flag > 0 && Sec_key_flag == 1)
				{  
				//lcd_clear();
				//disptestbar();
				Sec_key_flag = 0;
				switch(second_key_flag)
					{ 
					case K1:
						#ifndef  CAR                 
						quit_key_flag = read_IC_card_amount(1);
                  		#endif
                 		break;
					case K2:
						quit_key_flag = read_IC_card_amount(2);
                  		break;
					case K3:
                 		quit_key_flag = read_IC_card_amount(3);
                  		break;
					case K4:
						#ifndef  CAR		                  
						quit_key_flag = read_IC_card_amount(4);
		                #endif
						break;
					default:
						break;
					}
				second_key_flag = 0;  
				}
			Smart_Power_OFF;
			if(quit_key_flag == 0x23)
				{
				if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����
                	LCD_back_ON;
				else
					LCD_back_OFF;
				write_card_error(0);
				delay(KEYTIMEOUT_1S*2);  
				}
			else if(quit_key_flag == 0x99)
			{
              if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����
                LCD_back_ON;
              else
                LCD_back_OFF;
              //������������
              //display_reader_P(0);
              uchar i;
               i = 3;
			  lcd_clear();
              dispaly(2,i++,(HZ + du));//��
              dispaly(2,i++,(HZ + ka));
              dispaly(2,i++,(HZ + qi_1));//��
              dispaly(2,i++,(HZ + gu));
              dispaly(2,i++,(HZ + zhang));                                
              delay(KEYTIMEOUT_1S*2);  
			  }             
          else if(quit_key_flag == 0x73)
		  	{
              if(count_Lcd_back())//�жϰ���������� �Ƿ� ����ʾ���ı����
                LCD_back_ON;
              else
                LCD_back_OFF;
              //������������
              MoneryException();
              delay(KEYTIMEOUT_1S*2);
          	}            
          Smart_Power_OFF;
          OPEN_EXTI9_5_IRQ();                                    
          OPEN_EXTI15_10_IRQ();   
		  key_flag = 0;
		  key_flagbk = 0;
        }
		if(LowVoltage == 1)
			{
			Send_LowVoltage_Record(0);//��ѹ	���� 
			}
        else
			{          
            voltage_flag=0;
            voltage_low();
    		Send_LowVoltage_Record(1);//�͵�ѹ                  
            delay(KEYTIMEOUT_1S*1);
			}        
//        if(key_flag||key_flagbk)continue;        
        lcd_clear();        
        LCD_POWER_OFF;
        lcd_res_0;
        LCD_back_OFF; 
        key_flag = 0;
		key_flagbk = 0;
    	}
	else if(wake_flag)
		{	
		sleepout1();
		lcd_clear();
		LCD_POWER_OFF;
		LCD_back_OFF; 
#if 1
        uchar SendHour,SendMin,Class,Hour,Min;            
        uchar RequitPage[2],BL_Count_buf[2];            
        u16 backList_count,AllBackListCount;
        wake_flag = 0x00;
		key_flag = 0;
		key_flagbk = 0;
		
		DISABLE_EXTI15_10_IRQ();	  
		DISABLE_EXTI9_5_IRQ();		  
		GetCurrentTime();		  
		OPEN_EXTI9_5_IRQ(); 																		 
		OPEN_EXTI15_10_IRQ();

		Update_SYSList(0);

#ifndef LPM_TEST
			//wake_flag--Coin_wakeup(1) ��ʾ�������ж�

			if(Judge_MB_MODE()==0)//�м����  
				{				 
//				if((time1[0]%7)==0)//ÿ7����
				if(SYS_MS.TIME32S!=time1[0])
					{
					IQ_CarState();//ÿ32����³�����״̬
					SYS_MS.TIME32S =time1[0];
					}
				if(key_flag)continue;
				Judge_CarTime_Illegal();//�г�λ�Ƿ�Υ��ͣ��
				}
			else//��ͨ���
				{//��һ��ˢ����ڶ���ˢ��
				MBtoBase_Card();//ÿ32����³�λˢ��״̬					
				}
			
			if(key_flag)continue;
#endif

			lcd_clear();
			LCD_POWER_OFF;
			LCD_back_OFF; 
			
            I2C_ReadS_24C(mibiao_number,Mater_Buf,3);//�����
            
            SendHour = (Mater_Buf[1] * 0x100 + Mater_Buf[2]) % 2;// 00:00 - 02:00
            SendMin = (Mater_Buf[1] * 0x100 + Mater_Buf[2]) % 60;// 00 - 59
            
            LowVoltage = LowVoltage_Test();   
            Send_LowVoltage_Record(!LowVoltage);//�͵�ѹ 
            
            if(time[1] == 0x23 && time[0] >= 0x55)
				{
			//AA150130161900 55002208643202033000240104991200 150201 55002208643202033000240104991200AB
				I2C_ReadS_24C(SYS_NETFEE,buffer+7,16);
				I2C_ReadS_24C(SYS_NETFEE+16,buffer+23,3);
				I2C_ReadS_24C(SYS_NETFEE+19,buffer+26,16);
				//������ʱ��
				if((buffer[23]==0)||(buffer[24]==0)||(buffer[25]==0))
					memcpy(flag_buffer,buffer+8,16);//���·�������
				else if((time[4]>buffer[23])||
					((buffer[23]==time[4])&&(time[3]>buffer[24]))||
					((buffer[23]==time[4])&&(buffer[24]==time[3])&&(time[2]>=buffer[25])))
					{
					memcpy(flag_buffer,buffer+27,16);
					BCC = 0x00;
					for(i=0;i<15;i++)
					  BCC = BCC ^ flag_buffer[i];
					flag_buffer[15] = BCC; 		 
					I2C_WriteS_24C(B_startTime_unit_of_hour,flag_buffer,16);
					I2C_WriteS_24C(back_argument_of_charge,flag_buffer,16);
					}
				else
					memcpy(flag_buffer,buffer+8,16);
				
				for(i=0;i<13;i++)
					buffer[i] = 0;
				I2C_WriteS_24C(LinkNetWorkCount,buffer,13);
				SYS_LIST.nowbx = 0;
				SYS_LIST.bagsum = 0;
				IAP_Night = 1;
				for(i=0;i<10;i++)//LIST_UD[9] ��ʾ����SRAM
					LIST_UD[i] = 1;				
				SYS_LIST.dayupflag = 0;//ÿ�ո��±�־ 2015-08-24
                }			
			if(time1[1] == 0 )
				{
				;
				}
//            I2C_ReadS_24C(IAPUpdataClass,buffer,1);//��������� ���� �ֶ�OR�Զ�
//            Class = buffer[0];
//            if(Class == 0xA2)//Զ������
           		{
                I2C_ReadS_24C(IAPUpdataTime,buffer,2);
                Hour = (((buffer[0]>>4)&0x0f)*10)+(buffer[0]&0x0f);
                Min = (((buffer[1]>>4)&0x0f)*10)+(buffer[1]&0x0f);
				Hour = 4;//�̶���3-5�㣻
				if(IAP_Night&&(time1[1] >= Hour-1)&&(time1[1] <= Hour+1)) 
                	{   
                    DISABLE_EXTI15_10_IRQ();      
                    DISABLE_EXTI9_5_IRQ();                   
                    IAP_UpData(1);      //�����Զ�����2015-05-19             
                    OPEN_EXTI9_5_IRQ();                                                                          
                    OPEN_EXTI15_10_IRQ();              
               	 	}                                             
            	}
            
//            I2C_ReadS_24C(FreeClass,buffer,1);//���ʸ��� ���� �ֶ�OR�Զ�
//            Class = buffer[0];
//            if(Class == 0xA2)//����Զ�̸���
            	{
                I2C_ReadS_24C(FreeUpdataTime,buffer,2);
                Hour = (((buffer[0]>>4)&0x0f)*10)+(buffer[0]&0x0f);
                Min = (((buffer[1]>>4)&0x0f)*10)+(buffer[1]&0x0f);
                if(time1[1] == Hour && time1[0] == Min)
                	{
                    //ʱ�� �� ���ʲ������趨
                    DownloadTimeAndFree(); //�����Զ�ʱ��ͷ��ʸ���2015-05-19
                	}
            	}            

            //���� ��flash ���в���
            if(time[1] == 0x06 && time[0] == 0x10)
            	{
                SendPage_Record();
                //���в���ǰ���Ѽ�¼�ȷ���
                if(ReturnRecordCount() == 0)
                	{
                    //��ʾ FLASH������
                    //FLASH_Erased();
                    Erased_sector();
                	}                               
				lcd_clear();
				LCD_POWER_OFF;
				LCD_back_OFF; 
            	}           
            
            for(int car = 1; car <= 4;car++)
            	{ 
                int min;
                read_car_reference_of_use_info(&CS_RF_US,car);//����λ״̬��Ϣ                
                min = CS_RF_US.max_stopTime_hour[0] * 60;
                min = min + CS_RF_US.max_stopTime_min[0];
                if(!min)min = 24*60;
                if(CS_RF_US.car_stop_way[0] != 0x00)
                	{             
                  //�������ж� ������ �����ͣ��ʱ��� �Զ���λ
                  if(ret_max_24hour(CS_RF_US.start_stopTime,SELECT) >= min)
                  {
                       reset_carStation(car); //��λ car��λ ״̬
                       int max_stop_time;	 
					   u8 momery_buffer[16];
					   u16 momery;
					   Rate_reference_ST RR_ST2;		   
                       max_stop_time = ret_max_24hour(CS_RF_US.start_stopTime,PARK_CARD);
					   momery = time_to_momery(CS_RF_US.start_stopTime);
					   momery_buffer[0] = 0x00; 												  
					   momery_buffer[1] = 0x00; 												 
					   momery_buffer[2] = momery / 256; 												  
					   momery_buffer[3] = momery % 256;

					   if(max_stop_time > 24 * 60)
                         max_stop_time = 24 * 60;
                       //�渴λ��¼
                          //������ж� ͣ�������¿� ���� ����ͨ��
                       get_rate_ref(&RR_ST2);                                         
                       block1_buffer[0] = 0xEE;//��¼ͷ        
                       
					   block1_buffer[1] = 0;
					   block1_buffer[2] = 1;
					   fll(RR_ST2.Max_Stop_Momery,block1_buffer+3,2);
//                       block1_buffer[1] = CS_RF_US.smartCard_SNR[0];                                           
//                       block1_buffer[2] = CS_RF_US.smartCard_SNR[1]; //��������                                          
//                       block1_buffer[3] = CS_RF_US.smartCard_SNR[2]; //��������                                        
//                       block1_buffer[4] = CS_RF_US.smartCard_SNR[3]; //��������                                        
                       block1_buffer[5] = CS_RF_US.smartCard_SNR[4]; //��������                                      
                       block1_buffer[6] = CS_RF_US.smartCard_SNR[5];                                      
                       block1_buffer[7] = CS_RF_US.smartCard_SNR[6];                                     
                       block1_buffer[8] = CS_RF_US.smartCard_SNR[7];                                      
                       block1_buffer[9] = time[4];//��                                     
                       block1_buffer[10] = CS_RF_US.start_stopTime[0];//��                                      
                       block1_buffer[11] = CS_RF_US.start_stopTime[1];//��                                      
                       block1_buffer[12] = CS_RF_US.start_stopTime[2];//ʱ                                    
                       block1_buffer[13] = CS_RF_US.start_stopTime[3];//��                                     
                       block1_buffer[14] = CS_RF_US.smartCard_momenry[1];                                       
                       block1_buffer[15] = CS_RF_US.smartCard_momenry[2];                                     
                       block1_buffer[16] = CS_RF_US.smartCard_momenry[3];                                    
                       block1_buffer[17] = momery_buffer[2];//0x00;                                    
                       block1_buffer[18] = momery_buffer[3];//0x00;                                   
                       block1_buffer[19] = ((car + CAR_CLASS)<<4) + 0x05;//�Զ���λ ��λΪcar 
                     	//2015-04-03���Ӹ�λʱ�Ľ����� andyluo                         
                                              
                       block1_buffer[20] = time[4];                                           
                       block1_buffer[21] = time[3];                                            
                       block1_buffer[22] = time[2];                                            
                       block1_buffer[23] = time[1];                                            
                       block1_buffer[24] = time[0];
                                            
                       block1_buffer[25] = ReadRecord(car);//����ͨ��¼��־
                       
                       for(int i=26;i<32;i++)                                              
                         block1_buffer[i] = 0xAA;                    
                       Save_Record(block1_buffer,32);
					   
                       Deal_SwipCardIMG(car-1,0);
					   
                       SaveResetRecord(block1_buffer,32,car);
                       //��λ����
                       light(car,NO);                       
                       
                       #ifdef TWO_CAR     	                                 
                       resetCarstation_success(CS_RF_US.smartCard_SNR,CS_RF_US.start_stopTime,max_stop_time,car - 1); //��ʾ car��λ ��λ�ɹ�                                         
                       #else
                       resetCarstation_success(CS_RF_US.smartCard_SNR,CS_RF_US.start_stopTime,max_stop_time,car); //��ʾ car��λ ��λ�ɹ�
                       #endif
                       
                       OPEN_EXTI9_5_IRQ();                                                                          
                       OPEN_EXTI15_10_IRQ();
                       
                       timeOut = KEYTIMEOUT_1S * 2;   
					   while(timeOut--) 
					   	{
						if(key_flag)
							{  
							key_flag = 0; 
							break; 
							} 
						}
                  }                
                }
            }
		if(key_flag||key_flagbk)continue;		 
		key_flag = 0;
		key_flagbk = 0;
        //��¼�ķ���
		lcd_clear();
        LCD_POWER_OFF;
        LCD_back_OFF;
		BCC = SendCarRecord();
		if(!BCC)//�ȷ����공�����߼�¼--2015-04-28
			RecordSendingMechanism();      
        if(key_flag||key_flagbk)continue;        
            
#endif
        }
	else
		sleepout1();

        LCD_POWER_OFF;
        lcd_res_0;           
        LCD_back_OFF;   
        
        Smart_Power_OFF;
		G3_PowerOFF_Mode();
		
		BCC = Judge_MB_MODE();
		if(BCC)//��������ر�2G4��Դ 2015-04-30 andyluo
			{
			close_ir_comm();
			}
//		else
			{
			
//			I2C_ReadS_24C(LISTNET_ADD,buffer,16);//0-��־99 1- 2- 3-���ͼ��Ƶ�� 4- 5-Υ��ʱ��
//			if((buffer[3]!=0x10)&&BCC)//���������ʵʱ��������
//				NETSTATE=NETSTATE_CLOSE;//�ر����� 2015-08-03
			
			key_flag = 0;
			key_flagbk = 0;
//			NETSTATE_FUN("*SLEEP#");		
			if(NETSTATE==NETSTATE_SLEEP)
				;
			else if(NETSTATE==NETSTATE_LINK)
				{
				NETSTATE_FUN("*SLEEP#");
				}
			else if(NETSTATE==NETSTATE_CLOSE)
				{
				close_gprs_power();
				}
			if(key_flag||key_flagbk)continue;		 
			}
#ifdef LPM_TEST        
		close_ir_comm();
#endif
		OPEN_EXTI9_5_IRQ(); 								   
		OPEN_EXTI15_10_IRQ();	
		key_flag = 0;
		key_flagbk = 0;
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG, DISABLE);
        goto_sleep();
        //PWR_EnterSLEEPMode(PWR_Regulator_LowPower, PWR_SLEEPEntry_WFI);
        PWR_EnterSTOPMode(PWR_Regulator_LowPower, PWR_STOPEntry_WFI);
      /* Configures system clock after wake-up from STOP: enable HSE, PLL and select 
        PLL as system clock source (HSE and PLL are disabled in STOP mode) */
        SYSCLKConfig_STOP();
        open_usart();
  ///////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////      
        IWDG_ReloadCounter();
           
    }          
}
    
    


void goto_sleep111(void)
{
   // ADC_InitTypeDef   ADC_InitStructure;
        GPIO_InitTypeDef  GPIO_InitStructure;
 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////          
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,  DISABLE);	
        
        Uart5_Close();
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, DISABLE); //�رմ���1ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, DISABLE); //�رմ���2ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, DISABLE); //�رմ���3ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,  DISABLE); //�رմ���4ʱ��  
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,  DISABLE); //�رմ���5ʱ��         
        
        SPI_Cmd(SPI_FLASH, DISABLE);
        RCC_APB2PeriphClockCmd(SPI_FLASH_CLK | SPI_FLASH_GPIO_CLK | SPI_FLASH_CS_GPIO_CLK, DISABLE);

        ADC_Cmd(ADC1,DISABLE);
        ADC_Cmd(ADC2,DISABLE);//ADC2
        ADC_Cmd(ADC3,DISABLE);//ADC3
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, DISABLE);
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, DISABLE); 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //FSMC_SRAM_DISABLE(); 
        //RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, DISABLE);
        
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;//��?3G??????
//	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;//��?3G??????
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//	GPIO_Init(GPIOA, &GPIO_InitStructure); 
	//	GPIO_Pin_0|��2.4G��Դ
	 GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	 GPIO_Init(GPIOA, &GPIO_InitStructure);
	 GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_10|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;//|GPIO_Pin_9|GPIO_Pin_11(3G����)
	 GPIO_Init(GPIOA, &GPIO_InitStructure);   
	 
	 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	 GPIO_Init(GPIOA, &GPIO_InitStructure); 
	 GPIO_SetBits(GPIOA, GPIO_Pin_9);
        

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
     	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_15;//��?3G??????
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOB, &GPIO_InitStructure);      
        
        
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_5|GPIO_Pin_6;//|GPIO_Pin_7;  //--LED|GPIO_Pin_4
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOC, &GPIO_InitStructure); 
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
        
        
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;////GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_3|-----LED
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOD, &GPIO_InitStructure); 
        GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14| GPIO_Pin_15;  //�Ѿ���Ϊ��ѹ�����
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOD, &GPIO_InitStructure); 
        
        
//////////////////////////////////////////////////////////////////////////////////////////////
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
     	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14 |GPIO_Pin_15;//|GPIO_Pin_13,GPIO_Pin_15��?3G??????
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOE, &GPIO_InitStructure);    
        
        
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        //////////////////////////////////////////////////////////////////////////////////////////////
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;///|GPIO_Pin_6|GPIO_Pin_7
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOF, &GPIO_InitStructure);
     	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;//GPIO_Pin_8|GPIO_Pin_9|
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOF, &GPIO_InitStructure);   
        
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////
 	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOG, &GPIO_InitStructure);
	
	if(Judge_MB_MODE()==0)//�м����  
     	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14;//|GPIO_Pin_15|GPIO_Pin_13,|GPIO_Pin_15
	else
		GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;//|GPIO_Pin_13,|GPIO_Pin_15
	//GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_12|GPIO_Pin_14|GPIO_Pin_15;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOG, &GPIO_InitStructure);     
        

//////////////////////////////////////////////////////////////////////////////// 
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, DISABLE);//dis
        
        ADC_Cmd(ADC1, DISABLE);
        ADC_Cmd(ADC2, DISABLE);    
        RCC_APB1PeriphResetCmd(RCC_APB1Periph_DAC, DISABLE);//dis
        RCC_APB1PeriphResetCmd(RCC_APB1Periph_DAC, DISABLE);
        
//        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB 

//                              | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD 
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD 

                              | RCC_APB2Periph_GPIOE | RCC_APB2Periph_GPIOF

                              | RCC_APB2Periph_GPIOG | RCC_APB2Periph_AFIO, DISABLE);//dis


  
  // Disable the Serial Wire Jtag Debug Port SWJ-DP

        //GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, DISABLE); //dis 
        GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE); //dis

//        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;

//        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;

//        GPIO_Init(GPIOA, &GPIO_InitStructure); 
////////////////////////////////////////////////////////////////////////////////
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_SRAM | RCC_AHBPeriph_FLITF, DISABLE);
    
    
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1 | RCC_AHBPeriph_DMA2 | RCC_AHBPeriph_CRC | RCC_AHBPeriph_SDIO, DISABLE);
        
    
}

/*����*/
void goto_sleep(void)
{
  // ADC_InitTypeDef   ADC_InitStructure;
  GPIO_InitTypeDef  GPIO_InitStructure;
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////          
  //1�ر����д��ڵĽ���       
  Uart5_Close();
  if(Judge_MB_MODE()==0)//�м����	
	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);//�رմ���1ʱ��(3G����)
  else
	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, DISABLE);//�رմ���1ʱ��(3G����)
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, DISABLE);//�رմ���2ʱ��
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, DISABLE);//�رմ���3ʱ��
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,  DISABLE);//�رմ���4ʱ��  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,  DISABLE);//�رմ���5ʱ��  
  
  //2FLASH
  SPI_Cmd(SPI_FLASH, DISABLE); 
  RCC_APB2PeriphClockCmd(SPI_FLASH_CLK | SPI_FLASH_GPIO_CLK | SPI_FLASH_CS_GPIO_CLK, DISABLE);
  //3ADC
  ADC_Cmd(ADC1,DISABLE);
  ADC_Cmd(ADC2,DISABLE);
  ADC_Cmd(ADC3,DISABLE);//ADC3
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, DISABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, DISABLE); 
  RCC_APB1PeriphResetCmd(RCC_APB1Periph_DAC, DISABLE);
  //  4FSMC (ע��)
  //  FSMC_SRAM_DISABLE(); 
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, DISABLE);	
  
  //GPIOA���Ž�IO����ΪAIN,�����������--huangfeng.
  //���ñ�׼�Ŀ⺯��,����͹���ģʽ(PWR_EnterSTOPMode��PWR_EnterSTANDBYMode����)
  //  GPIO_Pin_0|��2.4G��Դ
//  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//  GPIO_Init(GPIOA, &GPIO_InitStructure);
//  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_10|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;//|GPIO_Pin_9|GPIO_Pin_11(3G����)
//  GPIO_Init(GPIOA, &GPIO_InitStructure);   
  
  if(Judge_MB_MODE()==0)//�м����	
	  {
	  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	  GPIO_Init(GPIOA, &GPIO_InitStructure);
	  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_10|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;//|GPIO_Pin_9|GPIO_Pin_11(3G����)
	  GPIO_Init(GPIOA, &GPIO_InitStructure);   
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //
	  GPIO_Init(GPIOA, &GPIO_InitStructure);
	  }
  else
  	 {
	 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;  
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;  
	 GPIO_Init(GPIOA, &GPIO_InitStructure);  
   	 }


  
  //GPIOB���ţ�GPIO_PortSourceGPIOB, GPIO_PinSource5----32_PULES); 
  GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_6|GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_14|GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOB, &GPIO_InitStructure); 
  //GPIOC����	��8��13��14��15������Led4 - PC4  GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_9|GPIO_Pin_9||GPIO_Pin_7|GPIO_Pin_7
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_5|GPIO_Pin_6; 
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOC, &GPIO_InitStructure); 
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12;//GPIO_Pin_12;//GPIO_Pin_10|GPIO_Pin_11|
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOC, &GPIO_InitStructure);     
  
  //GPIOD����(Led3 - PD3)
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOD, &GPIO_InitStructure); 
  GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14| GPIO_Pin_15;  
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOD, &GPIO_InitStructure); 		
  //GPIOE����
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_All;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOE, &GPIO_InitStructure);
  
  //GPIOF����LED1 - PF6    LED2 - PF7
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOF, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOF, &GPIO_InitStructure); 
  
  //GPIOG���� 
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOG, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14;//|GPIO_Pin_15
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOG, &GPIO_InitStructure);
  
  //    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_All;
  //    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  //    GPIO_Init(GPIOG, &GPIO_InitStructure);
  
  
  //   RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, DISABLE);
  //	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, DISABLE);	 //����32S
  //	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, DISABLE);	 //����
  //  	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, DISABLE);	 //
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, DISABLE);
  //  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, DISABLE);	 
  //RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG, DISABLE);
  //	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,  DISABLE);	 //�ж�	  
  
  ////////////////////////////////////////////////////////////////////////////////
  
  // Disable the Serial Wire Jtag Debug Port SWJ-DP ����
  GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, DISABLE); // 
  
  
  //////////////////////////////////////////////////////////////////////////////// 
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_SRAM | RCC_AHBPeriph_FLITF, DISABLE);     
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1 | RCC_AHBPeriph_DMA2 | RCC_AHBPeriph_CRC | RCC_AHBPeriph_SDIO, DISABLE);
  //  RCC_APB1PeriphResetCmd(RCC_APB1Periph_ALL, DISABLE); //2014-1-21
  //  RCC_APB2PeriphResetCmd(RCC_APB2Periph_ALL, DISABLE);
  RCC_RTCCLKCmd(DISABLE);
  ////////////////////////////////////////////////////////////////////////////////   
  //RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);//dis     
  
}



void open_usart(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);//�򿪴���1ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);//�򿪴���2ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);//�򿪴���3ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,ENABLE);//�򿪴���4ʱ��  
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,ENABLE);//�򿪴���5ʱ�� 
}

void sleepLcd1(void)
{
 GPIO_InitTypeDef  GPIO_InitStructure;
 LCD_back_OFF;    
 LCD_POWER_OFF; 
 
 GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6;
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
 GPIO_Init(GPIOE, &GPIO_InitStructure);
 
 GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_8 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_11 | GPIO_Pin_12;
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
 GPIO_Init(GPIOG, &GPIO_InitStructure);
 
 GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_15;
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
 GPIO_Init(GPIOB, &GPIO_InitStructure);
 
 GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_1 | GPIO_Pin_1;
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
 GPIO_Init(GPIOC, &GPIO_InitStructure);
 
 db0_1;
 db1_1;
 db2_1;
 db3_1;
 db4_1;
 db5_1;
 db6_1;
 db7_1;
 
 lcd_cs_1;
}


void sleep_lcd(void)
{
 GPIO_InitTypeDef  GPIO_InitStructure;
 LCD_back_OFF;    
 LCD_POWER_OFF; 
 GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_13;
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
 GPIO_Init(GPIOG, &GPIO_InitStructure);
}

void sleepout1(void)
{
    //GPIO_Configuration();
    //ChipOutHalInit1();
    ChipHalInit();			//Ƭ��Ӳ����ʼ��
    ChipOutHalInit();		//Ƭ��Ӳ����ʼ��
}
//////////////////////////////////////////////////////////////////////////////////
/*----------------------------------------------------------------------
function name:   	unsigned char LowVoltage_Test(void)
describe:    	 	�͵�ѹ��ⷵ��:0Ϊ�� 1Ϊ��
input:   			
output:
date:			andyluo 2010-12-03 14:26:57
------------------------------------------------------------------------*/
unsigned char LowVoltage_Test(void)
{
////////////////////////////////PD4---PB14///////////////////////////////////////////
  GPIO_InitTypeDef GPIO_InitStructure;
  uchar flag;
  /*����MAX884��Դ����������Back batter Ctrl */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;		//��������
	GPIO_Init(GPIOB, &GPIO_InitStructure);

  if((GPIO_ReadInputData(GPIOB)&0x4000)==0x0000)
    {
      Delay(100);
     if((GPIO_ReadInputData(GPIOB)&0x4000)==0x0000)
      {
	 	//fault_record(0x10);
		flag =0;
      }
     else
 	 flag =1;
    }
  else
 	 flag =1;
  
  return flag; 
  
}                                                 
         
///////////////////////////////////////////////////////////////////////////////////////

uchar count_Lcd_back()
{
    uchar Begin_Hour;
    uchar Begin_Min;
    uchar End_Hour;
    uchar End_Min;
    uchar buffer[4];
    
    
    //������һ�� Զ������ �����ʱ��
     
     I2C_ReadS_24C(BACK_TIME,buffer,4);//���������ʱ��
     GetCurrentTime();  
    
     Begin_Hour = buffer[0];
     Begin_Min = buffer[1];
     End_Hour = buffer[2];
     End_Min = buffer[3];
     
    if(time[1] > Begin_Hour || time[1] < End_Hour)
      return 1;
    else if(time[1] == Begin_Hour && time[0] >= Begin_Min)
      return 1;
    else if(time[1] == End_Hour && time[0] <= End_Min)
      return 1;
    else
      return 0;
}

void read_IP()
{
    uchar buffer[6];
    
    uchar hundred;
    uchar ten;
    uchar ge;
    
    uchar i = 0;
	
	/**/
	//124.172.126.161 218.17.233.35
	buffer[0] = 218;
	buffer[1] = 17;
	buffer[2] = 233;
	buffer[3] = 35;
	buffer[4] = 0x96;//�Բ�˿�9655��9650-9660��
	buffer[5] = 0x50;//�Բ�˿�
//	buffer[4] = 0x33;//ʵ��˿�6055
//	buffer[5] = 0x66;//��������
#ifdef IP_OWN
	I2C_WriteS_24C(IPADrees,buffer,6);//
#endif
//	
//	buffer[0] = 'C';
//	buffer[1] = 'A';
//	buffer[2] = 'R';
//	buffer[3] = 'D';
//	buffer[4] = 0xff;
//	buffer[5] = 'C';
//	buffer[6] = 'A';
//	buffer[7] = 'R';
//	buffer[8] = 'D';
//	buffer[9] = 0xff;
//	I2C_WriteS_24C(APNuser_possword,buffer,32);

	
    I2C_ReadS_24C(IPADrees,buffer,6);//��IP��
    
    hundred = buffer[0] / 100;
    ten = buffer[0] / 10 % 10;
    ge = buffer[0] % 10;
    if(hundred > 0)
    {
        IP[i++] = hex_to_asic(hundred);
        IP[i++] = hex_to_asic(ten);
        
    }
    else if(ten > 0)
    {
        IP[i++] = hex_to_asic(ten);
    }
    else
    {}
    
    IP[i++] = hex_to_asic(ge);
        
    IP[i++] = 46;// .
    
    
    hundred = buffer[1] / 100;
    ten = buffer[1] / 10 % 10;
    ge = buffer[1] % 10;
    if(hundred > 0)
    {
        IP[i++] = hex_to_asic(hundred);
        IP[i++] = hex_to_asic(ten);
        
    }
    else if(ten > 0)
    {
        IP[i++] = hex_to_asic(ten);
    }
    else
    {}
    
    IP[i++] = hex_to_asic(ge);
        
    IP[i++] = 46;// .
    
    
    
    hundred = buffer[2] / 100;
    ten = buffer[2] / 10 % 10;
    ge = buffer[2] % 10;
    if(hundred > 0)
    {
        IP[i++] = hex_to_asic(hundred);
        IP[i++] = hex_to_asic(ten);
        
    }
    else if(ten > 0)
    {
        IP[i++] = hex_to_asic(ten);
    }
    else
    {}
    
    IP[i++] = hex_to_asic(ge);
        
    IP[i++] = 46;// .
    
    
    
    
    hundred = buffer[3] / 100;
    ten = buffer[3] / 10 % 10;
    ge = buffer[3] % 10;
    if(hundred > 0)
    {
        IP[i++] = hex_to_asic(hundred);
        IP[i++] = hex_to_asic(ten);
        
    }
    else if(ten > 0)
    {
        IP[i++] = hex_to_asic(ten);
    }
    else
    {}
    
    IP[i++] = hex_to_asic(ge);
    
    IP[i++] = '\0';
    
    
    
    //�˿ں� ��ȡ
    
    i = 0;
    
    PORT[i++] = hex_to_asic((buffer[4]>>4)&0x0f);
    PORT[i++] = hex_to_asic(buffer[4]&0x0f);
    PORT[i++] = hex_to_asic((buffer[5]>>4)&0x0f);
    PORT[i++] = hex_to_asic(buffer[5]&0x0f);
    
    PORT[i++] = '\0';
    
    
}

void SYSCLKConfig_STOP(void)
{
  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);

  /* Wait till HSE is ready */
  HSEStartUpStatus = RCC_WaitForHSEStartUp();

  if(HSEStartUpStatus == SUCCESS)
  {

#ifdef STM32F10X_CL
    /* Enable PLL2 */ 
    RCC_PLL2Cmd(ENABLE);

    /* Wait till PLL2 is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLL2RDY) == RESET)
    {
    }
#endif

    /* Enable PLL */ 
    RCC_PLLCmd(ENABLE);

    /* Wait till PLL is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {
    }

    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while(RCC_GetSYSCLKSource() != 0x08)
    {
    }
  }
}

