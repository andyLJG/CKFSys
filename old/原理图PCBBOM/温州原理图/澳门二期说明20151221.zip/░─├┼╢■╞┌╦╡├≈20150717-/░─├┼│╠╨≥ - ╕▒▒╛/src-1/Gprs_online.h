
#ifndef	_Gprs_online_H
#define		_Gprs_online_H	
void RxBuffer_to_sz1(void);
void test_jilu();
void FRIST_GPRS(unsigned char disp_hide);
void ONLINE_GPRS(void);
void MONITOR_GPRS(void);
void GPRS_CSQ(unsigned char hide);
void SEND_asic_2th(unsigned char bhex);
void uart_send_sombuf_asic(unsigned char *ptr,unsigned int k);

unsigned char hex_to_asic(unsigned char a);
#endif
