#ifndef	__FIFO_H__
#define	__FIFO_H__
#include "string.h"
#include "stm32f10x.h"


/****************************************************************/
#define	FIFO_BLOCK_NUM				(3)
#define	UART_SEL						USART2
#define	UART_IRQHandler				USART2_IRQHandler

/****************************************************************/

#define	FIFO_BLOCK_SIZE				(1024)

#define PACKET_SEQNO_INDEX      (1)
#define PACKET_SEQNO_COMP_INDEX (2)

#define PACKET_HEADER           (3)
#define PACKET_TRAILER          (2)
#define PACKET_OVERHEAD      (PACKET_HEADER + PACKET_TRAILER)
#define HEAD_SIZE                	(12)
#define PACKET_1K_SIZE          (1024)

#define FILE_NAME_LENGTH        (256)
#define FILE_SIZE_LENGTH        (16)

/*common cmd*/
#define SOH                     (0x01)  /* start of 128-byte data packet */
#define STX                     (0x02)  /* start of 1024-byte data packet */
#define EOT                     (0x04)  /* end of transmission */
#define ACK                     (0x06)  /* acknowledge */
#define NAK                     (0x15)  /* negative acknowledge */
#define CA                       (0x18)  /* two of these in succession aborts transfer */
#define CRC16                 (0x43)  /* 'C' == 0x43, request 16-bit CRC */
#define REQ                     (0x5A) /*Slaver ask for data down*/
#define WT                      (0x5B) /*Master is not ready for the data, need slaver waite!*/
#define OK                       (0x5E)
#define FAIL                    (0x5F)

#define ABORT1               (0x41)  /* 'A' == 0x41, abort by user */
#define ABORT2               (0x61)  /* 'a' == 0x61, abort by user */

/*the ram size of a FIFO is  (20+FIFO_BLOCK_SIZE*FIFO_BLOCK_NUM) bytes*/
typedef enum
{
	FifoWriteOK = 0,			/*Writing FIFO actions is OK*/
	FifoFull,				/*FIFO is no ram to be wrote and this writing action is aborted*/
	FifoAlmostFull,		/*FIFO is almost full but this writing actions is valid*/
	
	FifoReadOK,			/*Reading FIFO action is OK*/
	FifoEmpty,			/*FIFO is no data to be read and this reading action is aborted*/
	FifoAlmostEmpty		/*FIFO is almost empty but this reading actions is valid*/
}FIFO_InfoDef;

typedef struct{
	u32 packnum;	/*the file packs*/
	u32 index;
	u32 cnt;		/*send data counter*/
	u8 cmd;
	u8 sta;
	u8* pt;
	u8	head[HEAD_SIZE];/*A3210/B3210/C3210: A: bank ; B:file size; C: pack numbers*/
}Loader_TypeDef;

//Loader_TypeDef loader; //it define in the iapload.c file already!
 

ErrorStatus LoaderInit(u32 size, u32 num);	/*if you want use this FIFO, please run this function first and ONLY ONCE!*/
FIFO_InfoDef FIFO_write(u8* src);	
FIFO_InfoDef FIFO_read(u8* dst);
u32 FIFO_Status(void);

#endif
