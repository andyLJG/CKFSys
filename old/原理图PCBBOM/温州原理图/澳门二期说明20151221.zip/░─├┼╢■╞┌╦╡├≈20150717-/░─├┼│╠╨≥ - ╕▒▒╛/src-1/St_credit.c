#include "stm32f10x_conf.h"
#include "hal.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Count.h"
#include "Key.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include "Gprs_online.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_it.h"
#include "misc.h"
#include "math.h"
#include "Card.h"
#include "MemoryAssign.h"
#include "spi_flash.h"
#include "String.h"
//#include "Des.h"
#include "rate.h"
#include "coin.h"
#include "main.h"
const unsigned char shuju111[]={0x60,0x00,0x04,0x53,0x13,0x01,0x32,0x17,0x03};//����Ϊֻ��TRACK2��ģʽ
const unsigned char shuju112[]={0x60,0x00,0x04,0x53,0x1D,0x01,0x31,0x1A,0x03};//����Ϊ���������������

unsigned char id1[600];
unsigned char id2[30];
unsigned char kcode[8]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
unsigned char kcode1[16]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
unsigned char s[65];    //={0x01,0x23,0x45,0x67,0x89,0xab,0xcd,0xe7};
unsigned char d[65];    // ={0};
unsigned int xor,xor1;
u32 delaytime;
u32 i;
void SYS_DO_BUSY_ICON(u8 x1, u8 y1,u8 x2, u8 y2,u8 state);
extern u8 parking_station;
extern u8  zimo,chewei;
extern u8  jilu[20];
extern long Good_money;
u8 f_getmoney,f_openmachine,jishu2,OP_NS,CO_NS,Backup_NS;
u8  doint,LV_NS,BL_NS,day_flag,time_OK,GPRS_LINKing,CLOSE_GPRS,SCR_CK,QL_CK;
u8  gprs_user,gprs_busy,DPSIP,all_dawnload,gprs_refer,gprs_busy1,already_sleep,f_ConnSuccess,gprs_resetpower,Time_return,xxxx,gprs_busy2,f_referinit;
u16 x_StartTime_h,x_StartTime_min,x_EndTime_h,x_EndTime_min,x_StartWeek,x_EndWeek,x_Stime,x_Amount,x_MaxPark,x_MinPark,x_MinCost,f_execution,f_occupied,key_number,f_overmax;
u16 MinTime,LimitTime,LimitMoney,LimitMoney_CARD,LimitTime_CARD,BaseFee,length_heartjump,x_MAXParkingTime;
u16 f_sendsimulatedata,time_occpupied;
u16 purch_time,purch_money;
unsigned long left_time,left_money,global_u1time1;
//unsigned char loop1,loop2;
u8 jishu,jishu1,jishu10,SG_CSQ,BaseTime,FEE_SAT,FEE_END,BT_Value,SYS_Stateicon;
u8 f_enablecard,f_connectOK,f_receiveOK,f_quit,f_blacklight,f_closeIP;
u8 Creditcard_Readdata[300],Creditcard_Cardno[4];
unsigned int Use_mny_time[2];

u8 SCR_CK,NETSTATE;
extern u16 RxCounter;
extern unsigned char RxBuffer[2000];





void uart_send_som(unsigned char *ptr)
{ 
	USART_SendDataPacket(USART1 ,65535,ptr );
}

void uart_send_sombuf(unsigned char *ptr,unsigned int k)
{
	USART_SendDataPacket(USART1 ,k,ptr );
}
void uart_send(unsigned char a)
{
	unsigned char ptr[2];
	ptr[0] = a;
	ptr[1] = '\0';
	USART_SendDataPacket(USART1 ,1,ptr);
}





void SPI_FLASH_Init1(void)
{
  SPI_InitTypeDef  SPI_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;

  /* Enable SPI and GPIO clocks */
  RCC_APB2PeriphClockCmd(SPI_FLASH_CLK | SPI_FLASH_GPIO_CLK | SPI_FLASH_CS_GPIO_CLK1, ENABLE);

  /* Configure SPI pins: SCK, MISO and MOSI */
  GPIO_InitStructure.GPIO_Pin = SPI_FLASH_PIN_SCK | SPI_FLASH_PIN_MISO | SPI_FLASH_PIN_MOSI;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(SPI_FLASH_GPIO, &GPIO_InitStructure);

  /* Configure I/O for Flash Chip select */
  GPIO_InitStructure.GPIO_Pin = SPI_FLASH_CS1|GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(SPI_FLASH_CS_GPIO1, &GPIO_InitStructure);
//////////////////////////////////////////////////////////////////////////////////////////
 /* Configure I/O for Flash Chip select */
  GPIO_InitStructure.GPIO_Pin = SPI_FLASH_CS;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(SPI_FLASH_CS_GPIO, &GPIO_InitStructure);
  /* Deselect the FLASH: Chip Select high */
  SPI_FLASH_CS_HIGH();
///////////////////////////////////////////////////////////////////////////////////////////
  /* Deselect the FLASH: Chip Select high */
  ccard_CS1_HIGH;

  /* SPI configuration */
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_4;
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
  SPI_InitStructure.SPI_CRCPolynomial = 7;
  SPI_Init(SPI_FLASH, &SPI_InitStructure);

  /* Enable the SPI  */
  SPI_Cmd(SPI_FLASH, ENABLE);
}
/***********************************************
**������:FLASH_SPI_Config
**����:��ʼ������FLASH��SPI�ӿ�
**ע������:����FLASHʹ����SPI1�ӿ�
***********************************************/
void FLASH_SPI_Config(void)
{
    SPI_InitTypeDef  SPI_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA  |RCC_APB2Periph_GPIOB| 
            RCC_APB2Periph_AFIO |
            RCC_APB2Periph_SPI1,
            ENABLE);

    /* SCK, MISO and MOSI  A5=CLK,A6=MISO,A7=MOSI*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

      
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 ;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    /*  PC.13 ��Ƭѡ*/

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_SetBits(GPIOA, GPIO_Pin_4);//Ԥ��Ϊ��
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);    
	GPIO_SetBits(GPIOB, GPIO_Pin_2);//Ԥ��Ϊ��   
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;//ˢ���ź������
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
        GPIO_Init(GPIOB, &GPIO_InitStructure);        
    /* SPI1 configuration */
	SPI_Cmd(SPI1, DISABLE); 												//�����Ƚ���,���ܸı�MODE
    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;		//����ȫ˫��
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;							//��
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;						//8λ
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;								//CPOL=0 ʱ�����յ�
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;							//CPHA=0 ���ݲ����1��
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;								//����NSS
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_256;//2;		//2��Ƶ=36M
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;						//��λ��ǰ
    SPI_InitStructure.SPI_CRCPolynomial = 7;								//CRC7
    
	SPI_Init(SPI1, &SPI_InitStructure);
	//SPI_SSOutputCmd(SPI1, ENABLE); //ʹ��NSS�ſ���
    SPI_Cmd(SPI1, ENABLE); 
 
}

