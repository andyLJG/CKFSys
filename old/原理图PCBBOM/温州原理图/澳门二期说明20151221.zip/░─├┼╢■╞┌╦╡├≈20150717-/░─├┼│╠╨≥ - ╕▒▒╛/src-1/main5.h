#ifndef	__MAIN5_H__
#define	__MAIN5_H__

int main5(void);


#endif