
//ͨ��74HC139�Ŀ��ƽţ����ư�·74125ʵ�ְ�·������չ
#define HC139_A_OFF	        GPIO_ResetBits(GPIOB, GPIO_Pin_0)
#define HC139_A_ON	        GPIO_SetBits(GPIOB, GPIO_Pin_0)

#define HC139_B_OFF	        GPIO_ResetBits(GPIOB, GPIO_Pin_1)
#define HC139_B_ON	        GPIO_SetBits(GPIOB, GPIO_Pin_1)

#define HC139_E_B                 GPIO_ResetBits(GPIOB, GPIO_Pin_5)       
#define HC139_E_A                 GPIO_SetBits(GPIOB, GPIO_Pin_5)

//485�ķ��ͽ��տ��ƽ�
#define Max485_0_rec	        GPIO_ResetBits(GPIOC, GPIO_Pin_2)
#define Max485_0_send	        GPIO_SetBits(GPIOC, GPIO_Pin_2)

#define Max485_1_rec	        GPIO_ResetBits(GPIOC, GPIO_Pin_3)
#define Max485_1_send	        GPIO_SetBits(GPIOC, GPIO_Pin_3)

#define Max485_2_rec	        GPIO_ResetBits(GPIOC, GPIO_Pin_4)
#define Max485_2_send	        GPIO_SetBits(GPIOC, GPIO_Pin_4)

#define Max485_3_rec	        GPIO_ResetBits(GPIOC, GPIO_Pin_5)
#define Max485_3_send	        GPIO_SetBits(GPIOC, GPIO_Pin_5)

#define Max485_4_rec	        GPIO_ResetBits(GPIOC, GPIO_Pin_6)
#define Max485_4_send	        GPIO_SetBits(GPIOC, GPIO_Pin_6)

#define Max485_5_rec	        GPIO_ResetBits(GPIOC, GPIO_Pin_7)
#define Max485_5_send	        GPIO_SetBits(GPIOC, GPIO_Pin_7)

#define Max485_6_rec	        GPIO_ResetBits(GPIOC, GPIO_Pin_8)
#define Max485_6_send	        GPIO_SetBits(GPIOC, GPIO_Pin_8)

#define Max485_7_rec	        GPIO_ResetBits(GPIOC, GPIO_Pin_9)
#define Max485_7_send	        GPIO_SetBits(GPIOC, GPIO_Pin_9)
/////////////////////�̵������ƽ�/////////////////////

#define J_1_OFF	        GPIO_ResetBits(GPIOD, GPIO_Pin_7)
#define J_1_ON	        GPIO_SetBits(GPIOD, GPIO_Pin_7)

#define J_2_OFF	        GPIO_ResetBits(GPIOD, GPIO_Pin_6)
#define J_2_ON	        GPIO_SetBits(GPIOD, GPIO_Pin_6)

#define J_3_OFF	        GPIO_ResetBits(GPIOD, GPIO_Pin_5)
#define J_3_ON	        GPIO_SetBits(GPIOD, GPIO_Pin_5)

#define J_4_OFF	        GPIO_ResetBits(GPIOD, GPIO_Pin_8)
#define J_4_ON	        GPIO_SetBits(GPIOD, GPIO_Pin_8)

#define J_5_OFF	        GPIO_ResetBits(GPIOD, GPIO_Pin_9)
#define J_5_ON	        GPIO_SetBits(GPIOD, GPIO_Pin_9)

#define J_6_OFF	        GPIO_ResetBits(GPIOD, GPIO_Pin_10)
#define J_6_ON	        GPIO_SetBits(GPIOD, GPIO_Pin_10)

#define J_7_OFF	        GPIO_ResetBits(GPIOD, GPIO_Pin_9)
#define J_7_ON	        GPIO_SetBits(GPIOD, GPIO_Pin_9)

#define J_8_OFF	        GPIO_ResetBits(GPIOD, GPIO_Pin_8)
#define J_8_ON	        GPIO_SetBits(GPIOD, GPIO_Pin_8)


void Max485_0_ON(void);
void Max485_1_ON(void);
void Max485_2_ON(void);
void Max485_3_ON(void);
void Max485_4_ON(void);
void Max485_5_ON(void);
void Max485_6_ON(void);
void Max485_7_ON(void);