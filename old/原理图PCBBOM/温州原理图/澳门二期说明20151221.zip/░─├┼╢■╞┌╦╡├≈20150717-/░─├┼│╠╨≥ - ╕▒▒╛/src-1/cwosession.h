//-----------------------------------------------------------------------------
// Owner.......: (c) 2000, CALE AB, Sweden
// File Name...: cwosession.h
// Descriptions: Encapsulation of transport protocol and socket communication to the backoffice gateway.
// Created.....: 2006-05-16  Johan Johansson
//-----------------------------------------------------------------------------

#ifndef CWOSESSIONH
#define CWOSESSIONH

//-----------------------------------------------------------------------------
// INCLUDE FILES
//-----------------------------------------------------------------------------
#include "cdsdefines.h"


//maximum size of a temporary receive buffer
#define RECV_BUFFER_MAX_LENGTH 1024*1 //bytes

//Constants defined for the protocol
#define CWO_MSG_HEADER_LENGTH 13
#define CWO_MSG_FOOTER_LENGTH 2
#define CWO_MSG_PROTOCOL_VERSION 1
#define CWO_MSG_EXCEPTION 1
#define CWO_MSG_NO_EXCEPTION 0
#define CWO_MSG_TYPE_REQUEST 0
#define CWO_MSG_TYPE_RESPONSE 1

typedef enum
{
   cNoCompression    = 0,
   cZlibCompression  = 1,
}tCompressionAlgorithm;

// Log levels, where Debug is the lowest level. The levels are cumulative so when Info is
// set for a module in the config, Info and higher levels will be logged for that module.
// Info in config: Info + Warn + Error + Fatal will be logged.
typedef enum
{                 // Usage:
   cLevelDebug,   // Fine-grained detailed log messages for debugging purposes
   cLevelInfo,    // Interesting, informational events, like startup events or state changes
   cLevelWarn,    // Unexpected or potentially dangerous events, "almost errors"
   cLevelError,   // Error messages
   cLevelFatal,   // Fatal error messages, causing application to terminate/reboot of platform
   cLevelOff,     // To turn off all logging, in cwtconfig.xml: <logging defaultLogLevel="Off"></logging>
   cLevelOn,      // Will always be logged, internal use only (not supported in cwtconfig.xml)
   cLevelNofLevels
} tLogLevel;

//Public part

CDS_RETVAL SendRequestAndGetResponse(const unsigned short* sendBuffer,
                                     unsigned short** responseBuffer,
                                     tCompressionAlgorithm compAlgorithm,
                                     unsigned long readTimeout);

CDS_RETVAL CreateSession(const char* hostName, const char* hostPort, unsigned long connectionTimeout);

CDS_RETVAL DestroySession();

void* GetMemory(size_t size,const char* callerName);
void ReleaseMemory(void* pointer);


//Private part
CDS_RETVAL CreateRequestMessage(unsigned char* requestBuffer, 
                                   const unsigned char* payloadBuffer, 
                                   unsigned long requestLength, unsigned long compressedLength,
                                   unsigned long uncompressedLength,
                                   unsigned char compAlgorithm);

 
unsigned long GetMessageDataLengthFromHeader(const unsigned char* buffer, const unsigned long bufferLength);

CDS_RETVAL SocketSendAndRecv(const unsigned char* sendBuffer, 
                             unsigned long sendBufferLen, 
                             unsigned char** recvBuffer, 
                             unsigned long* recvBufferLen,
                             unsigned long readTimeout);

CDS_RETVAL ReadResponseMessage(const unsigned char* responseData, 
                               unsigned long responseLength, 
                               unsigned short** responseBuffer,
                               char* isException);

unsigned short CRCCITT(char *data_p, unsigned int length);

#endif //CWOSESSION_H
