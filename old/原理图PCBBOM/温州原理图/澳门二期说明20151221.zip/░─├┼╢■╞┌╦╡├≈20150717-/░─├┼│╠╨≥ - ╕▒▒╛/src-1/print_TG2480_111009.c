#include "stm32f10x_conf.h"
#include "hal.h"
#include "St_credit.h"
#include "St_wcdma.h"
#include "LCD_12864.h"
#include "I2C.h"
#include "Count.h"
#include "Key.h"
#include "SYS_DispMenu.h"
#include "Gprs.h"
#include "Gprs_online.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_it.h"
#include "misc.h"
#include "math.h"
#include "Card.h"
#include "MemoryAssign.h"

#include "String.h"
#include<stdio.h>
extern 	u8 SYSVision[11];

//ƱͷƱβ��������
u8  mibiao[3] = {12,15,47};//�����
u8  jiedao[32] = "shennan dadao"; //�ֵ���
// u8 time[5];//0�գ�1ʱ��2�֣�3��//int  time[5] = {12,10,43,10,11};//����ʱ���գ�ʱ���֣��£���

//��������ʱ���������
//u16  ExTime = 1643; //����ʱ�� ʱ��
//u16  amtpaid = 9;	 //������

//����Ʊ����Ϣ����
//u8 test_item[14]={0x00,0x5a,0x5b,0x5f,0x00,0x5a,0x5b,0x5f,0x00,0x5a,0x5b,0x5f,0x00,0x00};//���ַ��������

/*----------ע������������ÿһλ����0-99����ת�����ַ���----------------*/
//ϵͳƱ����Ϣ����
u8  Max_coins[4]={0,0,0},Present_coins[3]={0,0,0},cash_amnt[8]={0,0,0},card_amnt[8]={0,0,0};
u8  coin_amnt[8]={0},tran_times[3]={0,0},total_amnt[8]={0,0,0};
u8 ip[20]="115.25.197 68:5846";

//����Ʊ����Ϣ����
u8  coin_1[2]={0,0},coin_2[2]={0,0},coin_5[2]={0,0},coin_10[2]={0,0};//Ӳ��0.1-1��Ԫ����
u8  coin_amnt1[8]={0},coin_pcs[3]={0,0,6},coin_times[3]={0,0,5};//���������ܽ���Ǯ�Ҹ����������Ѵ���

u8  bill_1[2]={0,0},bill_2[2]={0,0},bill_5[2]={0,0},bill_10[2]={0,0};//ֽ��0.1-1��Ԫ����
u8  bill_amnt[8]={0},bill_pcs[3]={0,0,8},bill_times[3]={0,0,9}; //���������ܽ���Ǯ�Ҹ����������Ѵ���

u8  mifare_amnt[8]={0},mifare_times[3]={0,0,89};//�����������ܽ������Ѵ���

u8 tik_No;//Ʊ��ϵ�к�

//����˵����fram_flagԤ�����ݵ���ʼ��ַ��I2c_Buf�������ݵĴ洢��ַ��len��ȡ����
//void I2C_ReadS_24C(int fram_flag,char *I2c_Buf,char len); //�������ݺ���
//u16 get_time(void);//time[0]��time[1]ʱtime[2]��time[3]��time[4]��

/*--------------//ȡʱ�䣬����ţ��ֵ��Ų���------------------*/
void get_jiedao_Mib_time()
{
	//get_time();
	I2C_ReadS_24C(PakingMeterNumber_add, mibiao, 3);//0x01fd
	I2C_ReadS_24C(StreetNumber_add, jiedao, 32);//0X01A6		
}
/*-------------- //ȡ����Ʊ�ݲ���------------------*/
void get_test_para()
{
	//I2C_ReadS_24C(BatteryVoltageState_add, test_item, 14);//	0X1F84
	
}
/*--------------//ȡϵͳƱ�ݲ���------------------*/
void get_sys_para()
{
//	I2C_ReadS_24C(CoinAlarmNumber_add, Max_coins, 2);//			0X0059
//	I2C_ReadS_24C(CoinNumberGetmoney_add, Present_coins, 2);//	0X003E	
//	I2C_ReadS_24C(AllMoneyGetmoney_add, total_amnt, 4);//			0X006D
//	I2C_ReadS_24C(PaperMoneyGetmoney_add, cash_amnt, 4);//			0X0035
//	I2C_ReadS_24C(BankMoneyGetmoney_add, card_amnt, 4);//		0X0005
//	I2C_ReadS_24C(CoinMoneyGetmoney_add, coin_amnt, 4);//			0X0029
//	I2C_ReadS_24C(AllTimesGetmoney_add, tran_times, 3);//			0X006B
//	I2C_ReadS_24C(IP_Port_add, ip, 20);//						0X0161	 

}
/*--------------//ȡ����Ʊ�ݲ���------------------*/
void get_income_para() 
{
//	I2C_ReadS_24C(Coin0_1NumberGetmoney_add, coin_1, 2);//	0X004D
//	I2C_ReadS_24C(Coin0_2NumberGetmoney_add, coin_2, 2);//	0X004F 	
//	I2C_ReadS_24C(Coin0_5NumberGetmoney_add, coin_5, 2);//	0X0051
//	I2C_ReadS_24C(Coin1_0NumberGetmoney_add, coin_10, 2);//	0X0053
//	I2C_ReadS_24C(CoinMoneyGetmoney_add, coin_amnt1, 4);//	0X002C
//	I2C_ReadS_24C(CoinNumberGetmoney_add, coin_pcs, 3);//	0X003E
//	I2C_ReadS_24C(CoinTimesGetmoney_add, coin_times, 3);//	0X0026
	
//	I2C_ReadS_24C(Paper1_0NumberGetmoney_add, bill_1, 2);//	0X0088
//	I2C_ReadS_24C(Paper2_0NumberGetmoney_add, bill_2, 2);//	0X008A 	
//	I2C_ReadS_24C(Paper5_0NumberGetmoney_add, bill_5, 2);//	0X008C
//	I2C_ReadS_24C(Paper10NumberGetmoney_add, bill_10, 2);//	0X008E
//	I2C_ReadS_24C(PaperMoneyGetmoney_add, bill_amnt, 4);//	0X0038
//	I2C_ReadS_24C(PaperNumberGetmoney_add, bill_pcs, 3);//	0X0079
//	I2C_ReadS_24C(PaperTimesGetmoney_add, bill_times, 3);//	0X0032

//	I2C_ReadS_24C(BankMoneyGetmoney_add,mifare_amnt, 4);//	0X0008
//	I2C_ReadS_24C(BankTimesGetmoney_add,mifare_times, 3);//	0X0002

}


/*------------------��λ��ӡ��-----------------*/
void reset_printer(void)
{
	USART_SendData(UART4,0x1b);
    USART_SendData(UART4,0x40);
}

/*---------------��ӡ��������------------------*/
void double_strike_cmd(u8 k)
{
	if(k == 1)//����
	{
		USART_SendData(UART4,0x1b);//uart_send_char(0x1b);//
		USART_SendData(UART4,0x47);//uart_send_char(0x47);//
		USART_SendData(UART4,0x01);//uart_send_char(0x01);//double-strike on
	}

	if(k == 0)//��ͨ
	{
		USART_SendData(UART4,0x1b);//uart_send_char(0x1b);//
		USART_SendData(UART4,0x47);//uart_send_char(0x47);//
		USART_SendData(UART4,0x00);//uart_send_char(0x00);//double-strike off
	} 	
}

/*---------------��ӡ�����С����------------------*/
void set_character_size_cmd(u8 size)
{
	if(size == 1)
	{	
		USART_SendData(UART4,0x1d);//uart_send_char(0x1d);//
		USART_SendData(UART4,0x21);//uart_send_char(0x21);//
		USART_SendData(UART4,0x11);//uart_send_char(0x11);//2�������С
	}

	if(size == 0)
	{	
		USART_SendData(UART4,0x1d);//uart_send_char(0x1d);//
		USART_SendData(UART4,0x21);//uart_send_char(0x21);//
		USART_SendData(UART4,0x00);//uart_send_char(0x00);//���������С
	}
}


/*---------------���ڷ����ַ�������-------------*/
void uart_send_string(u8 *ptr)
{ 
	while(*ptr != '\0')  			 
  	{ 
	  USART_SendData(UART4,*ptr);//uart_send_char(*ptr);            				
    	  ++ptr; 
  	}
}
/*-----------------��ӡ�ַ��� + ��n��---------------*/
void print_and_horizontal(u8* str, unsigned char n)
{
	unsigned char  i = 0;
	uart_send_string(str);//���ʹ�ӡ�ַ���

	for(i = 0; i < n; i++)//��ӡ����n��
	{
		USART_SendData(UART4,0x0a);//USART_SendData(0x0a);
	}
}
/*-----------------��ֽ����-------------------------*/
void total_cut(void)
{
	USART_SendData(UART4,0x1b);//USART_SendData(0x1b);
	USART_SendData(UART4,0x69);//USART_SendData(0x69);//��ֽ
}

void print_normal(void)
{
	double_strike_cmd(0);//double_strike off
	set_character_size_cmd(0);//���������С
}
/*-----------------Ʊ�ݴ�ӡ--------------------------------
Ʊ�ݴ�ӡ����˵��:
ÿһ��Ʊ����3���ֹ��ɣ�Ʊͷ+Ʊ������+Ʊβ
������Ӧ��Ʊ�����ͺ����������Ʊ�ݵĴ�ӡ
---------------------------------------------------------*/

/*----------------Ʊͷ����---------------*/
void print1_mode(u8 PrintMode)
{
 	u8  pdno[7];
    u8  bill_SN[1];
	u8  tikno[14];
	u8  issdate[17];

//	I2C_ReadS_24C(SerialNo_add,bill_SN,1);
	tik_No = bill_SN[0];//Ʊ�ݺ�
		
	get_jiedao_Mib_time();

//--------����ţ�Ʊ�ݺ�ת���ַ���---------------//
	sprintf  (pdno, "%02x%02x%02x", *(mibiao+0),*(mibiao+1),*(mibiao+2));
	if(PrintMode == CoinMode)
		sprintf  (tikno, " %02X%02X%02X%02X%02X%02d", *(time+4), *(time+3), *(time+2), *(time+1), *(time+0), tik_No);//Coin
	else if(PrintMode == CashMode)
		sprintf  (tikno, "*%02X%02X%02X%02X%02X%02d", *(time+4), *(time+3), *(time+2), *(time+1), *(time+0), tik_No);//Cash
	else if(PrintMode == CreditMode)
		sprintf  (tikno, "#%02X%02X%02X%02X%02X%02d", *(time+4), *(time+3), *(time+2), *(time+1), *(time+0), tik_No);//Card
	else
		sprintf  (tikno, "%02X%02X%02X%02X%02X%02d", *(time+4), *(time+3), *(time+2), *(time+1), *(time+0), tik_No);//Card
//--------��������ʱ��ת���ַ���---------------//	
	sprintf  (issdate, "%02X/%02X/20%02X %02X:%02X", *(time+2), *(time+3), *(time+4), *(time+1), *(time+0));	
	
	double_strike_cmd(1);//double_strike on 
	print_and_horizontal("P&D No.    : ", 0);
	print_and_horizontal(pdno, 1); 	

	print_and_horizontal("Ticket No. : ", 0);
	print_and_horizontal(tikno, 1);

	print_and_horizontal("Issue Date : ", 0);
	print_and_horizontal(issdate, 1);

	print_and_horizontal("Loc./Stall#: ", 0);
	print_and_horizontal(jiedao, 1);
	
	print_normal();
}

/*----------------Ʊβ����---------------*/
void print2_mode( u32 ExTime, u32 amtpaid, u8 PrintMode)
{
	u8  tikno[14];
	u8  issdate[17];
	u8  ex_T[6],amt_paid[6],time3[7];
	u8  i = 0;

	//I2C_ReadS_24C(SerialNo_add,bill_SN,1);
	//tik_No = bill_SN[0];//Ʊ�ݺ�
	get_jiedao_Mib_time();

	if(PrintMode == CoinMode)
		sprintf  (tikno, " %02X%02X%02X%02X%02X%02d", *(time+4), *(time+3), *(time+2), *(time+1), *(time+0), tik_No);//Coin
	else if(PrintMode == CashMode)
		sprintf  (tikno, "*%02X%02X%02X%02X%02X%02d", *(time+4), *(time+3), *(time+2), *(time+1), *(time+0), tik_No);//Cash
	else if(PrintMode == CreditMode)
		sprintf  (tikno, "#%02X%02X%02X%02X%02X%02d", *(time+4), *(time+3), *(time+2), *(time+1), *(time+0), tik_No);//Card
	else
		sprintf  (tikno, "%02X%02X%02X%02X%02X%02d", *(time+4), *(time+3), *(time+2), *(time+1), *(time+0), tik_No);//Card

        //sprintf  (tikno, "*%02X%02X%02X%02X%02X%02d", *(time+4), *(time+3), *(time+2), *(time+1), *(time+0), tik_No);
//--------��������ʱ��ת���ַ���---------------//	
	sprintf  (issdate, "%02X/%02X/20%02X %02X:%02X", *(time+2), *(time+3), *(time+4), *(time+1), *(time+0));	

	//sprintf  (tikno, "*%02d%02d%02d%02d%02d%02d", *(time+4), *(time+3), *(time+0), *(time+1), *(time+2), tik_No);
	//sprintf  (issdate, "%02d/%02d/20%02d %02d:%02d", *time, *(time+3), *(time+4), *(time+1), *(time+2));
	math_time(ExTime,time3);	

	//sprintf  (ex_T, "%02d:%02d",ExTime/60,ExTime%60);
	sprintf  (ex_T, "%02d:%02d",time3[1],time3[0]);
	sprintf  (amt_paid, "%02d.%02d",amtpaid/100,amtpaid%100);
	
	double_strike_cmd(1);//double_strike on
	print_and_horizontal("PLACE THIS SIDE UP ON WINDOWN", 2);
	print_and_horizontal("---------------------------------", 1);
	print_and_horizontal(" DETACH & RETAIN TICKET", 1);
	print_and_horizontal("    Ramallah Municipality", 1);
	double_strike_cmd(0);//double_strike off

	print_and_horizontal("Ticket No. : ", 0);
	print_and_horizontal(tikno, 1);
	print_and_horizontal("Loc./Stall#: ", 0);
	print_and_horizontal(jiedao, 1);	

	for(i = 0; i < 6; i ++)//��ֹʱ���滻������ʼʱ��
	issdate[17 + i - 6] = ex_T[i];

	double_strike_cmd(1);//double_strike on
	print_and_horizontal("  Expiry               Amount ", 1);
	double_strike_cmd(0);//double_strike off
	print_and_horizontal("  ", 0);
	print_and_horizontal(issdate, 0);
	print_and_horizontal("     $", 0);
	print_and_horizontal(amt_paid, 2);
	double_strike_cmd(1);//double_strike on
	print_and_horizontal("CHECK TICKET IS VISIBLE AFTER", 1);
	print_and_horizontal("CLOSING CAR DOOR", 1);
	double_strike_cmd(0);//double_strike off
	USART_SendData(UART4,0x0a);//
	USART_SendData(UART4,0x0a);//
	USART_SendData(UART4,0x0a);//
	total_cut();
/*
	tik_No += 1;//Ʊ�ݺ���1Ϊ�´�׼��
	if(tik_No >= 100)
	{
		tik_No = 0;//Ʊ�ݺ�Ϊ0-99
	}		
	I2C_ByteWrite_24C(SerialNo_add,tik_No);*/
}

/*--------------����Ʊ��---------------------------------------------
 

---------------------------------------------------------------------*/
void Income_print()
{

	u8  c01[5],c02[5],c05[5],c10[5],d01[5],d02[5],d05[5],d10[5];
	u8  coinamny[12],coinpcs[8],cointimes[8], billamnt[12],billpcs[8],billtimes[8];
	u8  mifareamnt[12],mifaretimes[8];
	u32 tempmny;

	Printer_Start();

	get_income_para();//ȡ����

   ///*--------���˼�¼1,2,5,10��Ԫ�������ּ��ܼ�ת�����ַ���---------------//
   //DispMoney = (FMI2C_buf[0]<<24)+(FMI2C_buf[1]<<16)+(FMI2C_buf[2]<<8)+FMI2C_buf[3];
	sprintf  (c01, "%d", coin_1[1]+(coin_1[0]<<8)); //Ӳ��
	sprintf  (c02, "%d", coin_2[1]+coin_2[0]*256);
	sprintf  (c05, "%d", coin_5[1]+coin_5[0]*256);
	sprintf  (c10, "%d", coin_10[1]+coin_10[0]*256);

	sprintf  (d01, "%d", bill_1[1]+bill_1[0]*256);//ֽ��
	sprintf  (d02, "%d", bill_2[1]+bill_2[0]*256);
	sprintf  (d05, "%d", bill_5[1]+bill_5[0]*256);
	sprintf  (d10, "%d", bill_10[1]+bill_10[0]*256);
	
	tempmny =(bill_amnt[3] +(bill_amnt[2]<<8) + (bill_amnt[1]<<16) + (bill_amnt[0]<<24)) ;
	sprintf  (billamnt, "$%d.%02d ",(bill_amnt[3] +(bill_amnt[2]<<8) + (bill_amnt[1]<<16) + (bill_amnt[0]<<24))/100,(bill_amnt[3] +(bill_amnt[2]<<8) + (bill_amnt[1]<<16) + (bill_amnt[0]<<24))%100);//ֽ���ܶ�
	sprintf  (billpcs, "%dpcs",bill_pcs[1] + bill_pcs[0]*256);
	sprintf  (billtimes, "%d",bill_times[2] + bill_times[1]*256 + bill_times[0]*65536);
        
	tempmny =(coin_amnt1[0]<<24) +(coin_amnt1[1]<<16) +(coin_amnt1[2]<<8) +  coin_amnt1[3] ;
	sprintf  (coinamny, "$%d.%02d ",tempmny/100,tempmny%100); //Ӳ���ܶ�
	sprintf  (coinpcs, "%dpcs", coin_pcs[1] + coin_pcs[0]*256);
	sprintf  (cointimes, "%d", coin_times[2] + coin_times[1]*256 + coin_times[0]*65536);


	sprintf  (mifareamnt, "$%d.%02d ",(mifare_amnt[3] +(mifare_amnt[2]<<8) + (mifare_amnt[1]<<16) + (mifare_amnt[0]<<24))/100,(mifare_amnt[3] +(mifare_amnt[2]<<8) + (mifare_amnt[1]<<16) + (mifare_amnt[0]<<24))%100);//ֽ���ܶ�
	sprintf  (mifaretimes, "%d",mifare_times[2] + mifare_times[1]*256 + mifare_times[0]*65536);

	double_strike_cmd(1);//double_strike on
	print_and_horizontal("       Income Report", 1);
	//print_and_horizontal("        (Bill)", 1);//ֽ��-Bill Ӳ��-coin

	print1_mode(OtherMode);//Ʊͷ
	print_and_horizontal("-------------------------------", 1);	 //�ָ���

	USART_SendData(UART4,0x09);//uart_send_char(0x09);//�ճ�һ��ˮƽ�Ʊ���
	double_strike_cmd(1);//double_strike on
	//print_and_horizontal("   Audit Trail", 1);	//�˵���¼
	//print_and_horizontal(" ", 1);
	print_and_horizontal("        Audit Trail  ", 1);
	print_and_horizontal(" ", 1);
	print_and_horizontal("           (Bill)", 1);//ֽ��-Bill Ӳ��-coin
	double_strike_cmd(0);//double_strike off

	print_and_horizontal("$0.1: ", 0); //1���ּ�¼
	print_and_horizontal(d01, 0);//Ӳ��c01,ֽ��d01
	print_and_horizontal("pcs", 1);

	print_and_horizontal("$0.2: ", 0); //2���ּ�¼
	print_and_horizontal(d02, 0); //Ӳ��c02,ֽ��d02
	print_and_horizontal("pcs", 1);

	print_and_horizontal("$0.5: ", 0);//5���ּ�¼
	print_and_horizontal(d05, 0);  //Ӳ��c05,ֽ��d05
	print_and_horizontal("pcs", 1);

	print_and_horizontal("$1  : ", 0);//1��Ԫ��¼
	print_and_horizontal(d10, 0);  //Ӳ��c10,ֽ��d10
	print_and_horizontal("pcs", 1);

	print_and_horizontal("Total cash: ", 0); //����ܼ�
	print_and_horizontal(billamnt, 0);	
	print_and_horizontal(" ", 1);
	//print_and_horizontal("Total cash: ", 0); //�����ܼ�
	//print_and_horizontal(billpcs, 1);	

	print_and_horizontal("Total transactions:", 0);//�����ܼ�
	print_and_horizontal(billtimes, 0);
	print_and_horizontal(" times", 1); 	
	
	print_and_horizontal("           (Coin)", 1);//ֽ��-Bill Ӳ��-coin
	print_and_horizontal("$0.1: ", 0); //1���ּ�¼
	print_and_horizontal(c01, 0);//Ӳ��c01,ֽ��d01
	print_and_horizontal("pcs", 1);

	print_and_horizontal("$0.2: ", 0); //2���ּ�¼
	print_and_horizontal(c02, 0); //Ӳ��c02,ֽ��d02
	print_and_horizontal("pcs", 1);

	print_and_horizontal("$0.5: ", 0);//5���ּ�¼
	print_and_horizontal(c05, 0);  //Ӳ��c05,ֽ��d05
	print_and_horizontal("pcs", 1);

	print_and_horizontal("$1  : ", 0);//1��Ԫ��¼
	print_and_horizontal(c10, 0);  //Ӳ��c10,ֽ��d10
	print_and_horizontal("pcs", 1);

	print_and_horizontal("Total coin: ", 0); //����ܼ�
	print_and_horizontal(coinamny, 0);	
	print_and_horizontal(" ", 1);
	print_and_horizontal("Total coin: ", 0); //����ܼ�
	print_and_horizontal(coinpcs, 1);	

	print_and_horizontal("Total transactions:", 0);//�����ܼ�
	print_and_horizontal(cointimes, 0);
	print_and_horizontal(" times", 1); 	

	double_strike_cmd(0);//double_strike off
	
	USART_SendData(UART4,0x0a);//
	USART_SendData(UART4,0x0a);//
	USART_SendData(UART4,0x0a);//
	
	total_cut();//��ֽ
/*
	tik_No += 1;//Ʊ�ݺ���1Ϊ�´�׼��
	if(tik_No >= 100)
	{
		tik_No = 0;//Ʊ�ݺ�Ϊ0-99
	}	
	I2C_ByteWrite_24C(SerialNo_add,tik_No);*/
	
	Printer_Over();
}

/*----------------��ӡOK��FAULT����------------------------------------
��ڲ���˵��: 
char a ���ַ�����0x00��OK  0x5f��FAULT  
-------------------------------------------------------------------*/
void select_Ok_fault(u8 a)
{
	if(a == 0x00)
	{
		print_and_horizontal(" OK", 1);
	}
	else
	{
		print_and_horizontal(" FAULT", 1);
	}
}
/*----------------����Ʊ�ݺ���------------------------------------
 
-------------------------------------------------------------------*/
void Test_print()
{
	u8 printret[1];
		
	Printer_Start();
	
	//get_test_para(); //ȡ����

	double_strike_cmd(1);//double_strike on
	print_and_horizontal("            Test Report", 2);
	double_strike_cmd(0);//double_strike off

	print1_mode(OtherMode);//Ʊͷ
	
	USART_SendData(UART4,0x0a);//
	
	I2C_ReadS_24C(PrinterState_add, printret, 1);
	uart_send_string("	Paper      :");
	select_Ok_fault(printret[0]);
	if(printret[0] != Device_MNG)
		printret[0] = Device_OK;
	uart_send_string("	Printer    :");
	select_Ok_fault(printret[0]);
	I2C_ReadS_24C(BatteryVoltageState_add, printret, 1);
	uart_send_string("	Battery    :");
	select_Ok_fault(printret[0]);

	//uart_send_string("	AC power   :");
	//select_Ok_fault(*(test_item+9));
	I2C_ReadS_24C(CashBoxState_add, printret, 1);
	uart_send_string("	Cash box   :");
	select_Ok_fault(printret[0]);
	
	I2C_ReadS_24C(CoinBoxState_add, printret, 1);
	uart_send_string("	Coin box   :");
	select_Ok_fault(printret[0]);

	I2C_ReadS_24C(PaperMachineState_add, printret, 1);
	uart_send_string("	Cash moudle:");
	select_Ok_fault(printret[0]);

	I2C_ReadS_24C(CoinMachineState_add, printret, 1);
	uart_send_string("	Coin moudle:");
	select_Ok_fault(printret[0]);

	//I2C_ReadS_24C(WCDMAStateInformation_add, printret, 1);
	uart_send_string("	3G moudle  :");
	//select_Ok_fault(printret[0]);
	select_Ok_fault(gprs_user);

	I2C_ReadS_24C(CreditCardMachineState_add, printret, 1);
	uart_send_string("	Card moudle:");
	select_Ok_fault(printret[0]);
	/*
	uart_send_string("	Battery    :")
	select_Ok_fault(*(test_item+0));

	uart_send_string("	Battery    :")
	select_Ok_fault(*(test_item+0));

	uart_send_string("	Battery    :")
	select_Ok_fault(*(test_item+0));

	uart_send_string("	Battery    :")
	select_Ok_fault(*(test_item+0));
   */
	
	//print2_mode(ExTime, amtpaid);//Ʊβ
	USART_SendData(UART4,0x0a);//
	USART_SendData(UART4,0x0a);//
	USART_SendData(UART4,0x0a);//
	total_cut();
	
	Printer_Over();
}

/*----------------ϵͳ��ϢƱ�ݺ���----------------------------
 
--------------------------------------------------------------*/
void SytInfo_print()
{
	u8  Maxcoins[8],Presentcoins[8],cashamnt[12],cardamnt[12];
	u8  coinamnt[12],trantimes[7],totalamnt[12],DPS_IP[21],APNPR[60];
	
//	I2C_ReadS_24C(DPSIP_Port_add, DPS_IP, 20);//						0X0161	 
//	I2C_ReadS_24C(APN_USERNAME_PASSWORD_add,APNPR,60);	
	
	Printer_Start();
	
	get_sys_para();//ȡ����

	sprintf  (Maxcoins, "%d",Max_coins[1] + Max_coins[0]*256);
	sprintf  (Presentcoins, "%d",Present_coins[1] + Present_coins[0]*256);
	sprintf  (totalamnt,"%d.%02d",(total_amnt[3] +(total_amnt[2]<<8) + (total_amnt[1]<<16) + (total_amnt[0]<<24))/100,(total_amnt[3] +(total_amnt[2]<<8) + (total_amnt[1]<<16) + (total_amnt[0]<<24))%100);
	sprintf  (cashamnt, "%d.%02d",(cash_amnt[3] +(cash_amnt[2]<<8) + (cash_amnt[1]<<16) + (cash_amnt[0]<<24))/100,(cash_amnt[3] +(cash_amnt[2]<<8) + (cash_amnt[1]<<16) + (cash_amnt[0]<<24))%100);
	sprintf  (cardamnt, "%d.%02d",(card_amnt[3] +(card_amnt[2]<<8) + (card_amnt[1]<<16) + (card_amnt[0]<<24))/100,(card_amnt[3] +(card_amnt[2]<<8) + (card_amnt[1]<<16) + (card_amnt[0]<<24))%100);
	sprintf  (coinamnt, "%d.%02d",(coin_amnt[3] +(coin_amnt[2]<<8) + (coin_amnt[1]<<16) + (coin_amnt[0]<<24))/100,(coin_amnt[3] +(coin_amnt[2]<<8) + (coin_amnt[1]<<16) + (coin_amnt[0]<<24))%100);
	sprintf  (trantimes,"%d",*(tran_times+0)*65536 + *(tran_times+1)*256 + *(tran_times+2));

	double_strike_cmd(1);//double_strike on
	print_and_horizontal("         System Info  ", 1);
	print_and_horizontal("          ", 0);
	print_and_horizontal(SYSVision, 2);
	
	double_strike_cmd(0);//double_strike off

	print1_mode(OtherMode);//Ʊͷ
	print_and_horizontal("", 1);
	print_and_horizontal("", 1);	

	print_and_horizontal("  APN :", 0);
	print_and_horizontal(APNPR, 1);
	
	print_and_horizontal("  Rate:", 0);
	print_and_horizontal("Sectional type", 1);

	print_and_horizontal("  Max coins        :", 0);
	print_and_horizontal(Maxcoins, 1);

	print_and_horizontal("  Present coins    :", 0);
	print_and_horizontal(Presentcoins, 1);

	print_and_horizontal("  Total amount     :", 0);
	print_and_horizontal(totalamnt, 1);

	print_and_horizontal("  Total cash amount:", 0);
	print_and_horizontal(cashamnt, 1);

	print_and_horizontal("  Total card amount:", 0);
	print_and_horizontal(cardamnt, 1);

	print_and_horizontal("  Total coin amount:", 0);
	print_and_horizontal(coinamnt, 1);		

	print_and_horizontal("  Total transaction:", 0);
	print_and_horizontal(trantimes, 0);
	print_and_horizontal(" times", 1);
	
	print_and_horizontal("  IP of Server:                           ", 0);//
	print_and_horizontal(ip, 1);//	
	print_and_horizontal("  IP of DPS:                              ", 0);//
	print_and_horizontal(DPS_IP, 1);//	
	print_and_horizontal(" ", 4);

	//print2_mode(ExTime, amtpaid);//Ʊβ
	
	total_cut();
	Printer_Over();
}

/*----------------Municipality��ϢƱ�ݺ���---------------

--------------------------------------------------------*/
void Al_Mun_print(u32 amtpaid, u32 ExTime,u8 Print_Mode)
{
	u8  ex_T[6],amt_paid[6],time3[7];
    u32 amtpaidmny[1];
        

	amtpaidmny[0] = amtpaid;
        
	math_time(ExTime,time3);	
	
	sprintf  (ex_T, "%02d:%02d",time3[1],time3[0]);
	//sprintf  (ex_T, "%02d:%02d",ExTime/60,ExTime%60);
	sprintf  (amt_paid, "%02d.%02d",amtpaid/100,amtpaid%100);
	
	//if(Printer_Start() ==Device_MNG)
		//return Device_MNG;
	
	double_strike_cmd(1);//double_strike on
	print_and_horizontal("   AL_Bireh Municipaloty", 2);
	double_strike_cmd(0);//double_strike off
	
	print1_mode(Print_Mode);//Ʊͷ

	
	//USART_SendData(UART4,0x0a);//
	
	double_strike_cmd(1);//double_strike on
	print_and_horizontal("  Expiry Time     Amount Paid", 2);
	print_and_horizontal(" ", 0);
	set_character_size_cmd(1);//˫�������С
	
	print_and_horizontal(ex_T, 0);
	print_and_horizontal("   $", 0);
	print_and_horizontal(amt_paid, 2);
	print_normal();

	USART_SendData(UART4,0x0a);//
	print2_mode(ExTime, amtpaidmny[0],Print_Mode);//Ʊβ
	
	Printer_Over();
	return ;//Device_OK;
} 

/*
void print_menu(void)
{
	//serial_Init();//��ʼ������
	reset_printer();//��λ��ӡ��

	//Al_Mun_print( );
 	//SytInfo_print();
	//Test_print( );
	//Income_print(); 
	
	//while(1);
}*/

