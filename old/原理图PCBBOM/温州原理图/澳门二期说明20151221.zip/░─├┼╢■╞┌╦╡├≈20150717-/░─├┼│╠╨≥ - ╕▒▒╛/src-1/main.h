#ifndef	_Main_H
#define		_Main_H		   
//#include "common.h"

#define HC244Wake_Open  	      GPIOC->BSRR = 0x00400000//6
#define HC244Wake_Close         GPIOC->BSRR = 0x00000040  

#define Coin_wakeup			    1 
#define Door1_wakeup           	2 
#define Door2_wakeup          	3 
#define Door3_wakeup              4 
#define Door4_wakeup              5 
#define Cash_wakeup       			6 
#define Coindoor_wakeup          	7 
#define Coinbox_wakeup          	8 
#define Coinline_wakeup         	9 
#define Wakeup_32S		         	32

/*IC������*/
#define card_power_on  GPIOE->BSRR = 0x00000010  //4
#define card_power_off  GPIOE->BSRR = 0x00100000
#define card_power_set  GPIOA->BSRR=0x00000100   //8
#define card_power_lock GPIOA->BSRR=0x01000000
#define card_cs_on  GPIOB->BSRR = 0x00001000     //12
#define card_cs_off  GPIOB->BSRR = 0x10000000
#define POWER_change_OFF	GPIO_ResetBits(GPIOA, GPIO_Pin_8)   //8
#define POWER_change_ON	        GPIO_SetBits(GPIOA, GPIO_Pin_8)
extern u8 chewei10;
void wwdg(void);
unsigned char Openmachine_Test(void);
unsigned char CoinBox_Test(void);
unsigned char Backupbatter_Test(void);
void disp_statusled(void);
void IAP_Init(void);
#endif
