#include "stm32f10x_it.h"
#include "delay_systick.h" 
#include "touch_key.h"
#include "Hal.h"
#include "touch_key.h"
#include "I2C_Driver.h"
#include "spi_flash.h"
#include "ADC.h"
#include "LM240128C.h"  //����
#include "GPIO.h"
#include "mifare.h"
#include "MemoryAssign.h"
#include "fsmc_sram.h"
#include "MAIN.h"
#include "ir_comm.h"
#include "USART.h"
#include "St_wcdma.h"
#include "HW_check.h"  
#include "COIN.h" 
#include "blacklist.h"
#include "jiami.h"
#include "rate.h" 
#include "contact_card.h"  //�ܲ�ͨ
#include "save_record.h"
#include "report.h"
#include "IAP_Update.h"
#include "new_mifare.h"
#include "touch_key.h"
#include "AoMenTong.h"
#include "Menu.h"
#include "blacklist.h"

//�������İ汾�� v1.0
//huangfeng����v3.5
#define RCC_APB1Periph_ALL               ((uint32_t)0x3AFEC83F)
#define RCC_APB2Periph_ALL               ((uint32_t)0x0000FFFD) 
  
u8 space_HEX;//��λ
u8 networkid;
  u8 timeseroal;

  u8 AMT_READER_INIT=0;
MeterInformation MeterInfor; //�����Ϣ
FirstCardInfor FCardInfor;   //��һ�ο�����Ϣ
KEYInformation KeyInfor;     //��ǰ����ʵʱ�������
  u8 networkOKflag;
  u8 Coin_menu_flag;
  u8 Reaser_OK_flag;
  u32 string_ID;
/*--------------ϵͳ��ʼ�����--------start---------------*/
void check_system(void)
{
  unsigned char  tempbuf[16];
  unsigned char i,Flagtime;
  unsigned int  Address;	 
  Flagtime = 4;
  
  while(Flagtime --)
  {
    I2C_ReadS_24C(SYSflagAddr,tempbuf,16);	  //��ϵͳ��ʼ����־λ
    
    if((tempbuf[0]==SYSInitializeflag)&&(tempbuf[3]==SYSInitializeflag)&&(tempbuf[6]==SYSInitializeflag)
       &&(tempbuf[10]==SYSInitializeflag)&&(tempbuf[12]==SYSInitializeflag)&&(tempbuf[15]==SYSInitializeflag))		   //
    { 
      break;
    }									 
    if(Flagtime ==1)
    {  
      OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
      lcd_clear(); 
      PrintGB18(28,2,"��ӭ����");
      
//      PrintGB18(12,25,"�絥���շ�ϵͳ");
      PrintGB18(12,25,"ͣ���շ�ϵͳ"); 
      Display_Version(54,25,CURRENRTVER);      
      display_time(22,48);
      PrintGB18(0,80,"ϵͳ��ʼ��");
      
      LCD_REVERSRDISPON; //����       
      /////////////////�ص�///////////////
      //CMLED_OFF;
      //ERRLED_OFF;         
//      set_time();  //����ʱ��
      //////////////////////////////////
      //1\FLASH����
      //    SPI_FLASH_BulkErase(); 
      
      //1������¼��ε�ַ���ݣ��ܹ���25��������
      
      i=0;
      for(Address = MINFlashRecordAdd;Address<MAXFlashAlarmRecordAdd;)
      {  
        SPI_FLASH_SectorErase(Address); 
        Address += 0x10000;
        if(Address%0x20000)
        {i++;
        PrintASCII18(30+i*3,80,".");
        }
      }        
      ////////////////////////////////////////////
      for(i=0;i<16;i++)
      {
        tempbuf[i]=0x00;
      } 
      //2\40����λ���0010~0x01E0+������Ϣ+��һ�β忨����ֵ
      
      for(Address= SPACE1Addr;Address<=FirstCardAddr;)
      {  
        I2C_WriteS_24C(Address,tempbuf,16); 
        Address += 16;
      }          
      //4����ţ�\�������ʱ��,
      tempbuf[0]=METERTYPE; //�����������ǵ綯��
      tempbuf[1]=0x00;
      tempbuf[2]=0x00;
      tempbuf[3]=0x01;
      
      tempbuf[4]=0x17; //0x0
      tempbuf[5]=0;
      tempbuf[6]=0x06; 
      tempbuf[7]=0;       
      I2C_WriteS_24C(MeterNumberAddr,tempbuf,8); 
      
      //
      INI_SYSLIST();
    Initial_CPUBlackListAddr(0);   
    Initial_CPUBlackListAddr(1);   
    Initial_CPUBlackListAddr(2); 
      
      
      //
      tempbuf[0]=0x00; 
      tempbuf[1]=0x00;
      tempbuf[2]=0x00;
      I2C_WriteS_24C(MeterCoinTotalAddr,tempbuf,3);  //Ӳ���䵱ǰ������ 
      I2C_WriteS_24C(MeterCoinCountAddr,tempbuf,2);  //Ӳ���䵱ǰ������    
      //ϵͳ��Կ��ic�� CȨ�� 
      Restore_MF1A();  
      //5������
      Restore_Rate();   
      //6��������
//      Initial_BlackListAddr();
            //3��3G����
      //IP��ַ�ܶ˿ں��û��������� CARD CARD 122 224 201 54
      tempbuf[0]=218; 
      tempbuf[1]=17;
      tempbuf[2]=233;
      tempbuf[3]=35;
      tempbuf[4]=0X60;//124.172.126.161
      tempbuf[5]=0X00;  
//      tempbuf[0]=211; //211.162.124.93       3321
//      tempbuf[1]=162;
//      tempbuf[2]=124;
//      tempbuf[3]=93;
//      tempbuf[4]=0X33;
//      tempbuf[5]=0X21; 
      I2C_WriteS_24C(IPAddr,tempbuf,6); 
      tempbuf[0]=0x43;//card
      tempbuf[1]=0x41;
      tempbuf[2]=0x52;
      tempbuf[3]=0x44;
      tempbuf[4]=0xFF;
      
      tempbuf[5]=0x43;
      tempbuf[6]=0x41;
      tempbuf[7]=0x52;
      tempbuf[8]=0x44;
      tempbuf[9]=0xFF;
      tempbuf[10]=0xFF;
      I2C_WriteS_24C(UserPosswordAddr,tempbuf,32);

      //��¼���ͻ��Ʋ���
      tempbuf[0] = 0; //������¼
      tempbuf[1] = 1;
      tempbuf[2] = 4;
      tempbuf[3] = 5;
      tempbuf[4] = 0;
      tempbuf[5] = 0;
      I2C_WriteS_24C(SendTimeInterval,tempbuf,6);  

      //7\��¼
      
      Init_FRecordAddr(); 
      
      
      //����ʱ�䡢���ʡ�IAP���ֶ��Լ�ʱ�����
      tempbuf[0]=AUTO_UPDATE;//ʱ���Զ����±�־ 
      tempbuf[1]=0X23;
      tempbuf[2]=0X00;
      I2C_WriteS_24C(RateTimeUpdateClass,tempbuf,3); 
      
      tempbuf[0]=AUTO_UPDATE;//�������� 04:00      
      tempbuf[1]=0X03; 
      tempbuf[2]=0X00;     
      I2C_WriteS_24C(IAPUpdateClass,tempbuf,3); 
       //�ָ������� ��ַ
      save_restorecard(0,0,tempbuf); 
       //��¼���к�
      tempbuf[0] = 0x00;
      tempbuf[1] = 0x00;
      tempbuf[2] = 0x00;      
      I2C_WriteS_24C(RecordCount,tempbuf,3);  
      //������
       INI_SYSLIST();
       tempbuf[0]=0;
       I2C_WriteS_24C(Today_Update_OK,tempbuf,1); 
         
      //������¼���к�
      tempbuf[0] = 0x00;
      tempbuf[1] = 0x00;
      tempbuf[2] = 0x00;      
      I2C_WriteS_24C(ArarmRecordCount,tempbuf,3); 
      //8\�����걨��
      Init_Report();
      //��ʼ�����س����ַ       
      Initial_UpdateAddr();
      //9������һ�η��ϸ�ʽ��ʱ��ֵ//(�֡�Сʱ���ա��¡��ꡢ���ڡ���)	    
      tempbuf[0]=0x00; //15-01-01 08��00 
      tempbuf[1]=0x08;
      tempbuf[2]=0x01; 
      tempbuf[3]=0x01; 
      tempbuf[4]=0x15; 
      I2C_WriteS_24C(SaveLastTimeAddr,tempbuf,5);   
      
      //10\д��ʼ����־
      for(i=0;i<16;i++)
      { 
        tempbuf[i]=SYSInitializeflag;
      }
      I2C_WriteS_24C(SYSflagAddr,tempbuf,16);	
      PrintASCII18(71,80,"OK");       
      LCD_REVERSRDISPOFF; //���� 
      delayms(2000);      
      LCD_back_OFF; 
      lcd_clear();      
//      lcd_res_0; 
      LCD_POWER_OFF;
      SoftReset();	//������λ
      break;
    }
  }
}
/*--------------ϵͳ��ʼ�����--------end---------------*/

/*--�ж�ʱ���ȡ-------------*/
void judge_get_time(void)
{
  u8 i;
  u8 wrong=0;
  u8 LastTime_BCD[7]; //��ȡ֮ǰ��ʱ��ֵ
  
  //��ȡ���ڵ�ֵ
  i=1;
  do
  {
    wrong=GetCurrentTime();
    if(wrong==0)
      break; //��ʽ��ȷ������0X14-0X30��֮��
    if(i==3) 
      break;    
  }while(i++);  
  
  //��ʽ��ȷ  //ʱ�����ܳ���10����  oldtime=LastTime_BCD[1]*60+LastTime_BCD[0];
     // I2C_WriteS_24C(SaveLastTimeAddr,time_BCD,7); 
  if(wrong==0)
  {   
    I2C_WriteS_24C(SaveLastTimeAddr,time_BCD,7); 
  }
  //��ʽ����ȷ-------��ʾ���Գ���-------------
  else
  {
    I2C_ReadS_24C(SaveLastTimeAddr,LastTime_BCD,7);  //��ȡ֮ǰ��ֵ
    //���������ʱ�������¼(��������ʱ��--����--)   
//    make_record(Wakeup_32S,0,0xa1); 
    ///////////////д֮ǰ��ʱ��/////////////////////////////
    time_BCD[0] = LastTime_BCD[0];			//��
    time[0]=(((time_BCD[0]>>4)&0x0f)*10)+(time_BCD[0]&0x0f);
    time_BCD[1] = LastTime_BCD[1];			//ʱ
    time[1]=(((time_BCD[1]>>4)&0x0f)*10)+(time_BCD[1]&0x0f);
    time_BCD[2] = LastTime_BCD[2];			//��
    time[2]=(((time_BCD[2]>>4)&0x0f)*10)+(time_BCD[2]&0x0f);
    time_BCD[3] = LastTime_BCD[3];			//��
    time[3]=(((time_BCD[3]>>4)&0x0f)*10)+(time_BCD[3]&0x0f);
    time_BCD[4] = LastTime_BCD[4];			//��
    time[4]=(((time_BCD[4]>>4)&0x0f)*10)+(time_BCD[4]&0x0f);
    time_BCD[6] = LastTime_BCD[6];			//����
    time[6]=(((time_BCD[6]>>4)&0x0f)*10)+(time_BCD[6]&0x0f);
    //дʱ��оƬ
    set_current_time(time_BCD);     
  }  
}



/*��д��һ�β忨����Ϣ----------start-------------------*/
void ReadFCardInf(void)  //����Ϣ
{
  u8 buffer[6];
  
  I2C_ReadS_24C(FirstCardAddr,buffer,6);   //������  
  
  FCardInfor.type=buffer[0];	
  FCardInfor.cardNO[0]=buffer[1];
  FCardInfor.cardNO[1]=buffer[2];
  FCardInfor.cardNO[2]=buffer[3];
  FCardInfor.cardNO[3]=buffer[4];
  FCardInfor.space=buffer[5]; 
  
}

void WriteFCardInf(u8 type)  //д��Ϣ
{
  u8 buffer[6];
  
  if(type==NO_CONTACTPAY) //mifare��
  { 
    
    buffer[0]=NO_CONTACTPAY;//������
    buffer[1]=CardInfor.cardNO[0];//����
    buffer[2]=CardInfor.cardNO[1];//
    buffer[3]=CardInfor.cardNO[2];//
    buffer[4]=CardInfor.cardNO[3];//
    buffer[5]=space_HEX;//
  }
  else if(type==CONTACTPAY) //�ܲ�ͨ��
  {
    buffer[0]=CONTACTPAY;//������
    buffer[1]=TCardInfor.cardNO[0];//����
    buffer[2]=TCardInfor.cardNO[1];//
    buffer[3]=TCardInfor.cardNO[2];//
    buffer[4]=TCardInfor.cardNO[3];//
    buffer[5]=space_HEX;//
  }  
  else //���
  {
    buffer[0]=0;//������
    buffer[1]=0;//����
    buffer[2]=0;//
    buffer[3]=0;//
    buffer[4]=0;//
    buffer[5]=0;//    
  }   
  I2C_WriteS_24C(FirstCardAddr,buffer,6);   //д����    
}
/*��д��һ�β忨����Ϣ----------end-------------------*/



/*�������Ϣ*/
void ReadMeterInf(void)  //����Ϣ
{
  
  u8 buffer[16];
  
  I2C_ReadS_24C(MeterVerAddr,buffer,15);  
  
  MeterInfor.version=buffer[0];	//����汾�� 
  
  MeterInfor.space_range[0]=buffer[1]; //��λ��Χ(Ҫ��Ҫ�����ж��Ƿ�Ϸ�)
  MeterInfor.space_range[1]=buffer[2];
  
  MeterInfor.number[0]=buffer[3]; //�����
  MeterInfor.number[1]=buffer[4];
  MeterInfor.number[2]=buffer[5];  
  MeterInfor.number[3]=buffer[6]; 
  
  MeterInfor.close_Light[0]=buffer[7]; //�ر����ʱ��
  MeterInfor.close_Light[1]=buffer[8];
  MeterInfor.close_Light[2]=buffer[9]; //�ر����ʱ��
  MeterInfor.close_Light[3]=buffer[10];  
  
  MeterInfor.net_time[0]=buffer[11];
  MeterInfor.net_time[1]=buffer[12];
  MeterInfor.net_time[2]=buffer[13];
  MeterInfor.net_time[3]=buffer[14];
  
}



/*---�ϵ�(Ӳ�һ�--������---�ܲ�ͨ)--*/
u8 power_on_mechine(void)
{
  u8 poweron_mifare;
  u32 inicount;  
  /*�ر����е��ж�-----------*/ 
  
       if(jd_maxtime(0)==0) 
         return 0xFE;
  
  OPEN_CLOSE_IRQ(IRQ_CLOSE,ALL_IRQ);
  OPEN_CLOSE_IRQ(IRQ_OPEN,DOOR_IRQ);
  
  
  
  poweron_mifare=0;
  
  if(MeterInfor.cointotal[2]==0)  //û�����ϵ�         
  {
    open_coin_power();
  }           
  else
    display_lastinfor(0,112,0x36);    
  
  if(wakecoininf.coinmoney==0) //֮ǰû��ͶӲ�Ҳ��ϵ�
  {
    

    
    //��ʼ���ܲ�ͨ
    init_contactcard(); 
    poweron_mifare=1;
    
    // inicount=ZTIMEOUT_1S/2;
    //make_record_Alarm(Reader_NG_0,0,0,0xa0);
    
    
    
    
    if( Reaser_OK_flag==1)
    {
      
       poweron_mifare=0xFF; 
       
    }
    else
    {
      
      

   
      
     

    inicount=4; 
    while(inicount>1)
    {
    
    // if(AMT_init()==0)
    //  AMT_init();
    // delayms_keybreak(20);  
  //    AMT_init_2();
       break; 
       
    //  inicount--;
     
    }

    
    if(inicount==1)
    {
      make_record_Alarm(Reader_NG_0,0,0,0xa0);
    //  Reaser_OK_flag=1;
      poweron_mifare=0xFF; 
    }
     
    }
   
  }
  
  OPEN_CLOSE_IRQ(IRQ_OPEN,KEY_IRQ);

//EmptyRcvCoin(); //2015���Ρ�
 //delayms_keybreak(300);  //400��100̫�̣�
  return poweron_mifare;                             
} 

/*-------- ---����������---------------*/ 


int main(void)
{	 
  //(�֡�Сʱ���ա��¡��ꡢ���ڡ���)	
  u8 OI_flag,middle_data,LCD_KEY,jdtime;
  u8 oldspace_HEX,goto_program;//����������־
  u8 LowVoltage,delay_process;
//  u8 remain_maxtime;  //ʣ��ʱ ��>���ʱ�� 
  u8 coin_fault; //coin_ab                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        le,,power_on_coinӲ�һ�
  u8 mifare_able; //������
  u8 count_32s;
  u8 odd_32s,double_16s;
  u8 Pay_Type;//���Ÿ��
  u8 buffer[16];
  u8 middle_data_0; 
  u8 BUF_NET_LINK[1];

  u32 key_Count_0;
  Coin_menu_flag=0;
  Reaser_OK_flag=0;
  MeterInfor.Language[0]=Chinese;
  MeterInfor.Language[1]=Chinese;
  //1��Ӳ�����ֳ�ʼ��-----------start-------------------------------------------
  ChipHalInit();                             //Ƭ��Ӳ����ʼ�� 
  irDA_Power_OFF;
  WCDMA_Power_OFF; 
  LCD_POWER_OFF;
  Buzz_1;                                    //������       
  LED1_GOFF;//����
  LED1_ROFF;
  LED2_GOFF;
  LED2_ROFF;
  LED3_GOFF;
  LED3_ROFF;
  LED4_GOFF;
  LED4_ROFF;                 
  close_coin_power();                        //Ӳ�һ���Դ 
  Mifare_Power_OFF;                          //��������Դ
  Contact_Power_OFF;                         //�ܲ�ͨ��Դ
  Contact_Power_ON;
  LCD_POWER_ON;                              //LCD��Դ
  LCD_back_ON;                               //LCD����
  key_flag=0;
  string_ID=1;
  timeseroal=1;
  delayms(20); 
//  LCD_back_OFF;
  ChipOutHalInit();                          //Ƭ��Ӳ����ʼ��
  FSMC_SRAM_Init();
  /* Enable PWR and BKP clock */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
  //Ӳ�����ֳ�ʼ��-----------END-------------------------------------------------

  //2�������汾�ų�ʼ��-----------------start--------------------------------    
  if(METERTYPE==ELECTCARMETER)
  {
    MeterInfor.space_range[0]=1;  //30��λ
    MeterInfor.space_range[1]=30; 
  }
  else
  {
    /*MeterInfor.space_range[0]=1;  //4��λ
    MeterInfor.space_range[1]=4; */
    MeterInfor.space_range[0]=1;  //4��λ
    MeterInfor.space_range[1]=4; 
    
  }
  buffer[0] = MATERVERSION;  //����汾�� 
  buffer[1] = MeterInfor.space_range[0];  //��λ
  buffer[2] = MeterInfor.space_range[1];  
  I2C_WriteS_24C(MeterVerAddr,buffer,3); 
  //�������汾��
  
  buffer[1]=METERTYPE; //�������
  I2C_WriteS_24C(MATER_VER,buffer,2); 
  buffer[0] = 0x00;
  buffer[1] = 0x01;
  I2C_WriteS_24C(UpdateRequireCount,buffer,2); //��������İ���
  I2C_WriteS_24C(UpdateAllCount,buffer,2);   //Ӧ��������ܰ���  
  
  //�������汾�ų�ʼ��-----------------end--------------------------------  
      
  //2���ϵ�ʱ�ȼ���Ŵſ���PD3-----------start-------------------------------------
  if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_3)!=(uint8_t)Bit_RESET)
  {
    lcd_clear();
    Buzz_0;
//    ERRLED_ON;                                 //���ϵ�
     judge_get_time();    
     diaplay_fault(5);                           //��ʾӲ�������
//    make_record(Wakeup_32S,0,0xa1);          //�Ƿ��Ŵż�¼ 
    delayms(40);
    Buzz_1;                                  //����ʾ���������Ͳ�һֱ��
    while((GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_3)!=(uint8_t)Bit_RESET))
    { IWDG_ReloadCounter();} //ι��    
    //ERRLED_OFF;    
  }
  //�ϵ�ʱ�ȼ���Ŵſ���-----------end------------------------------------------  
 
  //3����ʾ���߽���-----------start---------------------------------------------  
  Buzz_0; 
  LED1_GON;//����
  LED1_RON;
  LED2_GON;
  LED2_RON;
  LED3_GON;
  LED3_RON;
  LED4_GON;
  LED4_RON;  
  delayms(20); 
  display_welcome();
  LED1_GOFF;//����
  LED1_ROFF;
  LED2_GOFF;
  LED2_ROFF;
  LED3_GOFF;
  LED3_ROFF;
  LED4_GOFF;
  LED4_ROFF;
  Buzz_1;
  //��ʾ���߽���--------------end-----------------------------------------------
   
  //3��Ӳ�����-----------start-------------------------------------------------
  key_flag=0;
 
  
  IWDG_ReloadCounter(); //ι�� 
  delayms_keybreak(3000); //
  
 // hardWare_Check();	
  
 /* if(key_flag==1) //�а���
  {  
    hardWare_Check();	//ϵͳӲ��ģ���� 
    //     set_time();  //����ʱ�� 
  }*/
  
  
  OPEN_CLOSE_IRQ(IRQ_CLOSE,ALL_IRQ);//�رհ���
  //Ӳ�����------------end-----------------------------------------------------

  //4��ϵͳ��ʼ�����----------start--------------------------------------------
  //TestADC1();
  IWDG_ReloadCounter(); //ι�� 
  check_system();         
  //ϵͳ��ʼ�����-------------end----------------------------------------------   
  
  //5����������ȡ��SRAM----------start------------------------------------------
  //   read_Blacklist_to_SRAM(); //û����                                                                                                                                                                                                                                                             
    read_Blacklist_to_SRAM(CPUBlackListByte);  
     //��������ȡ��SRAM--------------end------------------------------------------- 
  
   //6��ϵͳ�ָ�-----------------start-------------------------------------------
  ReadMeterInf();               //�������Ϣ 
  judge_get_time();
  process_32s(0);                //���������λ����ͣʱ��
  Read_SysFee(); //������
  count_nettime(MeterInfor.number[3]);
  //ϵͳ�ָ�-------------------end----------------------------------------------  
  
  //7����ʾ���߽���-----------start---------------------------------------------
  lcd_clear();  
  display_sleep(); 
  delayms(100); 
  //��ʾ���߽���--------------end-----------------------------------------------
 
  
  
  //7����ռ�¼���ݷ���ʧ�ܵĴ���---------start----------------------------- 
  buffer[0]=0;
  buffer[1]=0;
  buffer[2]=0;      
  I2C_WriteS_24C(FalseSendValTimes,buffer,3);  //���
  I2C_WriteS_24C(LOWPOWER,buffer,3);  //�������
  //������ݷ���ʧ�ܵĴ���---------end----------------------------- 
  
        
    networkOKflag=0;
  //8����������������0---------------------start--------------------------------
  goto_program=PROGRAMSLEEP;                        // ���߱�־
  EmptyRcvCoin();                        //���Ӳ������
  WriteFCardInf(0);                      //�����һ��ˢ����Ϣ
  wake_flag = 0; 
  odd_32s=0;
  double_16s =0;  
  if(key_flag==1) //�а���
  {
    touchkey_return(0); 
    key_flag=0;
  } 
  key_flag=0;
  
  OPEN_CLOSE_IRQ(IRQ_OPEN,ALL_IRQ);  //�����е��ж�
  IWDG_ReloadCounter(); //ι��  
  
  open_coin_power();
  
  EmptyRcvCoin();
  //COIN_Wake_ON;
 // process_32s(0); 
  //��������������0---------------------end-------------------------------------
  

  /*    buffer[0]=0x12;
      buffer[1]=0x34;
      buffer[2]=0x56;
      
      buffer[0]= (buffer[0]<<4)|buffer[1]>>4; 
      buffer[1]= (buffer[1]<<4)|buffer[2]>>4; */
  
  
  
        for(int j=0;j<16;j++)
        buffer[j]=0;
      //��λ�ó�λ	
        for(int i = 0; i < 30; i++)
        {
           WriteSpaceUsingInf(i,buffer);    
        }
        
 
  
  
   /* buffer[0]=0xb1;
     buffer[0]=hex_to_asic(buffer[0]&0x0F);
        buffer[0]=hex_to_asic(buffer[0]&0x0F);  */
     
  //������
  
 // fll_BCD(12321,buffer,3);
 // fll_BCD(12321,buffer,3) ;
//  Init_FRecordAddr();
/*  
  u8 buf1_0[4];
  u8 buf1_1[4]; 
  buf1_0[0]=0xD1;
  buf1_0[1]=0xD2;
  buf1_0[2]=0xD3;
  buf1_0[3]=0xD4;
        
  SPI_FLASH_Init(); 
  SPI_FLASH_BufferRead(buf1_1,0x100000,4);
  SPI_FLASH_SectorErase(0x100000);
   SPI_FLASH_BufferRead(buf1_1,0x100000,4); 
  SPI_FLASH_BufferWrite(buf1_0, 0x100000, 4);	
  SPI_FLASH_BufferRead(buf1_1,0x100000,4);
  
   buf1_0[0]=0xD5;
  buf1_0[1]=0xD6;
  buf1_0[2]=0xD7;
  buf1_0[3]=0xD8;
  
    SPI_FLASH_BufferRead(buf1_1,0x300000,4);
  SPI_FLASH_SectorErase(0x300000);
    SPI_FLASH_BufferRead(buf1_1,0x100000,4);
  SPI_FLASH_BufferRead(buf1_1,0x300000,4);    
  SPI_FLASH_BufferWrite(buf1_0, 0x300000, 4);	
  
  SPI_FLASH_BufferRead(buf1_1,0x300000,4);  
    SPI_FLASH_BufferRead(buf1_1,0x100000,4);  
  SPI_FLASH_BufferRead(buf1_1,0x200000,4);*/
  
  
 // I2C_ReadS_24C(FLASHCPURecordSaveCurrentAddr,buffer,3);//�����磬��ǰ����FLASH��¼�Ŀ�ʼ��ַ 
 // I2C_ReadS_24C(FLASHRecordSaveCurrentAddr,buffer,3);//�����磬��ǰ����FLASH��¼�Ŀ�ʼ��ַ 

 /* I2C_ReadS_24C(IPAddr,buffer,6); 
  buffer[0]=218; //211.162.124.93,8000 124.172.126.161  218.17.233.35
   buffer[1]=17;
  buffer[2]=233;
  buffer[3]=35;
  buffer[4]=0X60;//9638 
  buffer[5]=0X00; 
  I2C_WriteS_24C(IPAddr,buffer,6);*/

 // set_time_2();
  //  make_record_Alarm(Low_volt_0,0,0,0xa0);
  // ��������
  //Record_TXMechanism(0);
  // ������¼
 //Initial_BlackListAddr();//������
 // buffer[0]=(MeterInfor.number[2]&0X0F)%60; 
 //BackList_Mechanism( buffer[0]);
//   buffer[1]= MU509link_net();
 // poweron3G_module();
 //���������
 // char *s="0013DFB30014FF810022EBC4002303F400234C940023F164002435240024493400252134002539A4";
 /* u8 buf1_B_0[100] ={0x00,0x13,0xDF,0xB3,0x00,0x14,0xFF,0x81,0x00,0x22,0xEB,0xC4,0x00,0x23,0x03,0xF4,0x00,0x23,0x4C,0x94,0x00,0x23,0xF1,0x64,0x00,0x24,0x35,0x24,0x00,0x24,0x49,0x34,0x00,0x25,0x21,0x34,0x00,0x25,0x39,0xA4};
    u8 buf1_B_1[100]; 

  
  Initial_CPUBlackListAddr(0);//������     
  SPI_FLASH_Init(); 
  SPI_FLASH_BufferWrite(buf1_B_0, MINFlashCPUBlackAdd, 40);  
  
  u8 buf1_0[4];
    buf1_0[0] = 0x00;
  buf1_0[1] = 0x00;
  buf1_0[2] = 0x0A; 
  I2C_WriteS_24C(CPUBlackList_Count,buf1_0,3); 
  
  SPI_FLASH_BufferRead(buf1_B_1,MINFlashCPUBlackAdd,40);
  read_Blacklist_to_SRAM(CPUBlackListByte);  
    buf1_0[0] = 0x00;
   buf1_0[1] = 0x13;
  buf1_0[2] = 0xDF; 
    buf1_0[3] = 0xB3; 
    if(jd_blacklist(buf1_0)) 
    {
          delayms(ERROR_DELAY);
    }
    else
    {
        delayms(ERROR_DELAY);
    }
*/  
   // LCD_POWER_OFF; 
  
      /*        for(int i=0;i<16;i++)
      {
        buffer[i]=0x00;
      } 
      //2\40����λ���0010~0x01E0+������Ϣ+��һ�β忨����ֵ
    
 for(  unsigned int  Address= SPACE1Addr;Address<=FirstCardAddr;)
      {  
        I2C_WriteS_24C(Address,buffer,16); 
        Address += 16;
      }     
  
  
   buffer[0] = 0x01;
   I2C_WriteS_24C(Today_Update_OK,buffer,1); 
   I2C_WriteS_24C(Today_Update_OK+1,buffer,1); 
   I2C_WriteS_24C(Today_Update_OK+2,buffer,1); */
    

   /* INI_SYSLIST();
    Initial_CPUBlackListAddr(0);   
    Initial_CPUBlackListAddr(1);   
    Initial_CPUBlackListAddr(2);  
    BackList_Mechanism(0);
   */
   // TestADC1();


   /*  u8 buf1_0[4];
   //99944612 
   // 69539121
  //  999999227
   buf1_0[0] = 0x99;
    buf1_0[1] = 0x99;
    buf1_0[2] = 0x99; 
    buf1_0[3] = 0x28; 
    if(jd_blacklist(buf1_0)) 
    {
     buf1_0[0] = 0x09;
    }
    else
    {
   buf1_0[0] = 0x09;
    }
  */
 /*  u8 buf1_0[4];
  buf1_0[0]=0x45;
  buf1_0[1]=0x46;
   AscToBcd(buf1_0,2,buf1_0);*/
    
  

  my_volum_alarm();
  
  my_Net_Run(1); 
  
  
  while(1)
  {   
    /*1��32S�жϻ�������-------------start---------*/
    if(wake_flag==Wakeup_32S)		//16���ж�
    {       
      wake_flag=0;
      double_16s++;
      OPEN_CLOSE_IRQ(IRQ_CLOSE,T32S_IRQ);           
      judge_get_time();    
      ReadMeterInf();//�������Ϣ 
      
      
      I2C_ReadS_24C(LOWPOWER,buffer,3);
      if(double_16s==2) //����16S�жϲŽ��д���
      {  
        double_16s=0;        
        if(odd_32s)//��С���󣬻��Ǵ�С
          odd_32s=0;
        else
          odd_32s=1; 
        //���͵�ѹ
       // LowVoltage_Test(1);//û��
       if(buffer[0]==0)
         TestADC1();
        count_32s=process_32s(odd_32s);
        if(count_32s==1)     //�����ж���   
        {      
          odd_32s=2;       
        } 
        else if(count_32s==3) // û�а����ж�,���Ҵ�����ʱ��  
        {
          lcd_clear();     
          display_sleep();  
        }
        else
        {
          display_time(20,24);   //ֻ����ʱ��
        }         
      }
      else
      { 
        //  buffer[0]=(MeterInfor.number[3]&0X0F)%60;  //��  
        

     
      //  I2C_ReadS_24C(LOWPOWER,buffer,3); //��û���־
        if(buffer[0]==0)
        {          
         // IAPUpdate_Mechanism(MeterInfor.net_time+2);          //Զ������buffer[0] 
        //  RateTime_Mechanism(MeterInfor.net_time);          //���ʺ�ʱ�����buffer[0] 
         
         //����Լ��
          
         my_Net_Run(0); 
         
         
        I2C_ReadS_24C(NET_MAX_LINK_COUNT,BUF_NET_LINK,1); //��û���־
        if(BUF_NET_LINK[0]<=0x05) 
        {
           //������
          
          
          
           networkOKflag=0;
           Record_TXMechanism(0);         //buffer[0]��¼���ͻ���  
           
           Battery_alarm_RC(0);
           //****
           //BackList_Mechanism(0);  
        }
        
    
        WCDMA_Power_OFF;
        TERMON_3G_0;
        SLEEP_3G_0;       
        }        
      } 
      //ͳһ�ص�Դ
      

      goto_program=PROGRAMSLEEP;  // ���߱�־  
    } 
     /*1��32S�жϻ�������-------------end---------------*/
        
    
    /*3��������⻽������ ------start-----------*/  
    if(key_flag==1 || wakecoininf.wakecoin_flag == Wakeup_COIN)
    { 
      
      
    
      
        WCDMA_Power_OFF;
        TERMON_3G_0;
        SLEEP_3G_0;
        
      //2.1��������------------start---------------------- 
      //OPEN_CLOSE_IRQ(IRQ_CLOSE,T32SCOIN_IRQ);
        OPEN_CLOSE_IRQ(IRQ_CLOSE,T32S_IRQ);
      
        
      KeyInfor.times=0;
      judge_get_time();
      ReadMeterInf();//�������Ϣ
      FEE.reachmaxtime=0;
      
      if((GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_6)==(uint8_t)Bit_RESET) || wakecoininf.wakecoin_flag == Wakeup_COIN ) //���а���
      {
        
        
        
        LCD_REVERSRDISPOFF;
        //2.2��ѹ���------------start-----------------------     
        I2C_ReadS_24C(LOWPOWER,buffer,3); //��û���־     
        if(buffer[0]==0)
        {
          if(Read_SysFee()) //������
            LowVoltage=ERROR_RATE; //���ʳ��ֹ���
          else
            LowVoltage = 0; 
        }
        else
          LowVoltage=1;
        
        
        //�е�
        if(LowVoltage==0)
        { 
          if(wakecoininf.wakecoin_flag==Wakeup_COIN)//2015����
          {
            wakecoininf.wakecoin_flag=0;
            wakecoininf.coinwakework=1;
            KeyInfor.times=0;  //��0�ΰ���            
          } 
          else
          {
         
              KeyInfor.times=1;  //��һ�ΰ��� 
          
             wakecoininf.coinwakework=0;
          }  
          KeyInfor.firstvalue=0;
          KeyInfor.spacevalue=0; 
          KeyInfor.keyvalue=0; //��ǰ�İ���ֵ
          KeyInfor.oldspace=0;
//          coin_able=0;     //Ӳ�һ���û��ʹ�ܣ�ʹ��Ϊ1      
//          power_on_coin=0; //Ӳ�һ���û���ϵ磬�ϵ�Ϊ1
          mifare_able=0;  
          goto_program=PROGRAMSLEEP; 
          OI_flag=0;
          LCD_KEY=0; //���� 
          space_HEX=0;
          jdtime=0;
          wakecoininf.totalcoinmoney=0;
          wakecoininf.coinmoney=0;
          wakecoininf.coinCount=0;
          wakecoininf.BuyTime[0]=0;
          wakecoininf.BuyTime[1]=0;
          wakecoininf.RemainTime[0]=0;
          wakecoininf.RemainTime[1]=0;
          //------�а���ѭ�����----------------------------          
          //2.3����ɨ��------------------start-----------------   
          
          //��λѡ������ begin
          do
         // while(1); 
          {                    
            IWDG_ReloadCounter(); //ι��
            
            
            if(KeyInfor.times==0 && wakecoininf.coinwakework==1 )//Ӳ�һ��Ѳ���
            { 
              Backlight_Open_Close(); //�жϰ���������� �Ƿ� ����ʾ���ı����
              jdtime++;             
              lcd_clear();   
              display_wake(space_HEX,0); 
              display_lastinfor(0,112,0x46);   // �����복λ
              mifare_able= 0x05;

            }
        
            
            else
            {
              middle_data=key_value(KeyInfor.times);
             
              
         
              
              if(KeyInfor.keyvalue==KEY_Lamp) //
                jdtime=1;//���˱������jdtime=1;�Ͳ��ж�����ʱ�� 
              
              if(KeyInfor.times==1)
              {
                if(wakecoininf.coinwakework==0)
                {
                  if(middle_data==KEY_Lamp) //��һ�ΰ������˱������ֱ�ӽ���3s����ʱ����
                  {
                    
                    LCD_KEY=1;
                    KeyInfor.times=0;
                    mifare_able= 0x01;
                    
                  } 
                  else
                  {              
                    if(LCD_KEY==0)
                    { 
                     /* if((middle_data==KEY_0)||(middle_data==KEY_X)
                         ||(middle_data==0))
                        */
                      if((middle_data==KEY_X) )  
                        
                      {
                        goto_program=PROGRAMOVER; //��һ�ΰ���������Ч��(0���˳�����ɨ��ֵ)����������������
                        break; 
                      }
                    }
                    else 
                    {                  
                      jdtime=1;//��һ�ΰ��˱������jdtime=1;�Ͳ��ж�����ʱ��
                      //if((middle_data==KEY_X)||(middle_data==0))//(middle_data==KEY_0)
                        if((middle_data==KEY_X))//(middle_data==KEY_0)  
                      {
                        goto_program=PROGRADISPALY; 
                        
                        break;//ȡ����������ȡ��--���������棩
                      }
                      else
                        LCD_KEY=0;
                    }
                  }
                }
              } 
              
              else
              {               
                LCD_KEY=0;
                if(middle_data==KEY_X)//ȡ����������ȡ��--���������棩//Ҳֱ�ӽ���5S���������� 
                {
                  Buzz_0;
                      delayms(25);
                     Buzz_1;
                  OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
                  key_flag=0;
                  display_lastinfor(0,112,0x49);//ȡ����....             
                }
              }
              if(middle_data==ManagementMenuOrder)           
                { 
               space_HEX=0x00;
               mifare_able= 0x04;
              }
              else
                if(middle_data==KEY_Chinese)           
              { 
               space_HEX=0x00;
              // mifare_able= 0x01;
                 mifare_able= 0x01;
              }
              else
              if(middle_data==KEY_Instruct)           
              { 
                OI_flag=1;
                 key_flag=0;
                lcd_clear();
                display_OI(); 
           
                KeyInfor.keyvalue=KEY_Instruct;    //ע�� 
                space_HEX=0x00;
                mifare_able= 0x03;
              } 
              else
               if(middle_data==KEY_Management)           
              { 
                   //OI_flag=1;
                   //lcd_clear();
                   key_flag=0;
                   Buzz_0;
               
                   OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
                   Buzz_1;
                  //display_OI(); 
                   KeyInfor.keyvalue=KEY_X;    //ע��  
                  display_lastinfor(0,112,0x49);//ȡ����.... 
                  
                  mifare_able= 0x01;
              }
              else   if(middle_data==KEY_UP)     
              {
              mifare_able= 0x02;
              
              }
              else  if(middle_data==KEY_DOWN)     
              {
              mifare_able= 0x02;
              }
              
              //2.4û������Ƽ�-----------------start----------------------------
               // if((LCD_KEY==0)&&(KeyInfor.keyvalue!=KEY_X))
              if(((LCD_KEY==0)&&(KeyInfor.keyvalue!=KEY_X)&&(middle_data<=40)&&(middle_data>0)||middle_data==0))
              {            
                //2.4.1�жϳ�λBCDֵ����LCD��ʾ--------start----------------------              
                if(jdtime==0)
                {
                  Backlight_Open_Close(); //�жϰ���������� �Ƿ� ����ʾ���ı����
                  jdtime++;
                } 
               if(Coin_menu_flag==0) 
                 
                dispaly_space(&OI_flag); //remain_maxtime=��λ��ʣ��ʱ��<���ͣ��ʱ��
                
              else
              {
                // OI_flag=1;
                 dispaly_space(&OI_flag);
              }
                  
                //2.4.1�жϳ�λBCDֵ����LCD��ʾ-------------end--------------------             
                
                //2.4.2��һ���а���λֵ���ϵ�(Ӳ�һ�--������---�ܲ�ͨ)----start---------
                if(KeyInfor.firstvalue==1) //��һ���г�λֵ
                { 
                //  mifare_able=power_on_mechine(); //power_on_coin=�ϵ絽Ӳ�һ�
//                  mifare_able=1; //�ϵ��˶�������Ϊ1         
                  KeyInfor.firstvalue+=1; //�����ϵ�
                }
                //2.4.3��һ���а���λֵ���ϵ�(Ӳ�һ�--������---�ܲ�ͨ)----end-----------            
              /*  if(key_flag==1) //�а���
                // if(1)    
                { 
                  oldspace_HEX=space_HEX; //2014-9-1
//                  KeyInfor.times++;
                  if(KeyInfor.times==0 && LCD_KEY==1)
                    KeyInfor.times++;
                  else 
                    KeyInfor.times+=2;
                  continue;
                }   */ 
               
                
                if( KeyInfor.times==1)
                {
                  
     
                  
               if (space_HEX>0x03)
               {
                 
                 mifare_able=power_on_mechine();
                 
               }
               else
               {
        
                   if(METERTYPE==ELECTCARMETER)  
                   {
               key_Count_0=5000*4000;
               
                //  OPEN_CLOSE_IRQ(IRQ_OPEN,COIN_IRQ);
               // while(key_Count_0)
                while(0)   
                {
                  if (key_Count_0%(1000*4000)==0)
                  {
                  Print_time(key_Count_0/1000/4000);
                  }
                      
                      
               //     if(wakecoininf.coinwakework==1)//2015����
                  if(key_flag==2)     
                     {key_Count_0=0;
                       break;
                     }
                   if(IC_SWITCH_read==YESZBTCARD)
                   {
                       key_Count_0=0;
                       break;
                   
                   }
                  
                  
                   if(key_flag==1)
                   {
                       
                         middle_data_0=touchkey_scan(key_flag);
        
                       // if( key_value(KeyInfor.times)==KEY_Chinese)
                        if( middle_data_0==KEY_Chinese)    
                        {
                           if(MeterInfor.Language[0]==Chinese)
                      {
                        MeterInfor.Language[0]=Portugal;
                       // MeterInfor.Language[1]=Portugal;
                       }
                     else
                    {
        
                                   MeterInfor.Language[0]=Chinese;
                                 //  MeterInfor.Language[1]=Chinese;
                        }  
                          
                            key_flag=0;
                            dispaly_space(&OI_flag);
                           //  dispaly_space(0);
                             key_Count_0=4000*4000;
                        
                        }
                        
                     else
                     
                        {
                          
                       
                           if(MeterInfor.Language[0]==Chinese)
                        {
                       // MeterInfor.Language[0]=Portugal;
                        MeterInfor.Language[1]=Chinese;
                       }
                     else
                        {
        
                                //   MeterInfor.Language[0]=Chinese;
                                   MeterInfor.Language[1]=Portugal;
                        }  
                          
                          
                          
                           break;
                        }
                     
                   //KeyInfor.times++;
                   
                   }
                   
   
          

                   
                   
                   key_Count_0--;
                  //delayms(2);
                 }
                
                
                   }
                
                if(key_Count_0!=0)
                {
                KeyInfor.times++;  
                continue;
                
                 }
                else
                {
                //
                  //    if(key_flag==2)  
                    if(IC_SWITCH_read==YESZBTCARD)
                    {
                       init_contactcard(); 
                    }
                  else
                    if((space_HEX!=0x00)&&(key_flag!=2))  
                    {
                      mifare_able=power_on_mechine();
                    }
                }
                
               }
                 }
                else
                {
                  
                  
                     if(MeterInfor.Language[0]==Portugal)
            {
               
              KeyInfor.times=1;
               
                 if (space_HEX>0x03)
               {
                   
                      mifare_able=power_on_mechine();
                
               }
               else
               {
        
               key_Count_0=5000*4000;
                 if(METERTYPE!=ELECTCARMETER)
                      key_Count_0=1;  
                while(key_Count_0)
                {
                  
                          
                  // if(key_flag==1)
                      if(key_flag==1)
                   {
                     
                           break;

            
                   }
                   key_Count_0--;
                  //delayms(2);
                 }
                if(key_Count_0!=0)
                {
                KeyInfor.times++;  
                continue;
                
                 }
                else
                {
                //
              
                   if(space_HEX!=0x00)
                    {
                      mifare_able=power_on_mechine();
                    }
 
                 
                 
                }
               } 
               
               
               
               
               
               
               
            }
            else
            { 
                      KeyInfor.times=1;
                             if(space_HEX!=0x00)
                    {
                      mifare_able=power_on_mechine();
                    }
                     
            }
                  
                  
                  
                  
            
                      
                
  
                }
               
                
                //2.4.4Ӳ�һ��ϵ��ʹ��/����Ӳ�һ�����û�а�����Ӳ����û��������£�--start--------------       
               coin_fault=0;                            
              }           
              //2.4û������Ƽ�-----------------end----------------------------  
            }
            
             //��λѡ������ end
            
      
             
          /*  if((middle_data==KEY_X)
              ||
              (middle_data==KEY_Lamp )| |
                (middle_data==KEY_Chinese)||
                  (middle_data==KEY_UP)||
                    (middle_data==KEY_DOWN)||
              (middle_data==KEY_Instruct)||
            (middle_data==KEY_Management)
                    )   
                {}
                else
                {
                 //2.5---3s����ʱ-�жϣ��û���������������Ͷ�һ���ˢ����-------start------- 
            Pay_Type=count_down_3s(mifare_able,coin_fault,KeyInfor.keyvalue);            
            //2.5---3s����ʱ-�жϣ��û���������������Ͷ�һ���ˢ����--------end--------
                }*/
    
            
          if((mifare_able==0x01)&&(space_HEX!=0x00))
          {
          
               display_lastinfor(0,112,0x53); 
               
               
          //Pay_Type=count_down_3s(mifare_able,coin_fault,KeyInfor.keyvalue);   
          }
          else
          if((mifare_able==0xFF)&&(space_HEX!=0x00))
          {
          
               display_lastinfor(0,112,0x56); 
               
               
          //Pay_Type=count_down_3s(mifare_able,coin_fault,KeyInfor.keyvalue);   
          }
         
          if (space_HEX!=0x00)
           {
            
                Pay_Type=count_down_3s(mifare_able,coin_fault,KeyInfor.keyvalue);  
           }
          
           else
           {
            if (mifare_able==0x03)
             {
                 Pay_Type=count_down_3s(mifare_able,coin_fault,KeyInfor.keyvalue); 
             }
                   else
              if (mifare_able==0x02)
             {
             
                Pay_Type=0x52; 
             }else
                  if (mifare_able==0x04)
             {
             
                Pay_Type=0x52; 
             }
                  else
             if (mifare_able==0x05)
             {
            // Pay_Type=0x20;
           //  esflag=1;
                 Coin_menu_flag=1;
                Pay_Type=count_down_3s(mifare_able,coin_fault,KeyInfor.keyvalue); 
             //  Pay_Type=0x20; 
            //   space_HEX=0x02;
             //  wakecoininf.coinmoney=0x01;
             }
              else if (mifare_able==0x01)
             {
                 Pay_Type=count_down_3s(mifare_able,coin_fault,KeyInfor.keyvalue); 
             }
                 else if (mifare_able==0x00)
             {
                 Pay_Type=count_down_3s(mifare_able,coin_fault,KeyInfor.keyvalue); 
             }
             else
             {
              Pay_Type=0x52; 
                // Pay_Type=count_down_3s(mifare_able,coin_fault,KeyInfor.keyvalue); 
             }
              
             
            
           }
          
         /*  if((mifare_able!=0x02)&&(space_HEX!=0x00))
          {
             Pay_Type=count_down_3s(mifare_able,coin_fault,KeyInfor.keyvalue);  
          }
           
          else
          {
            if (mifare_able==0x01)
            {
              Pay_Type=count_down_3s(mifare_able,coin_fault,KeyInfor.keyvalue);  
            }
            else   if((mifare_able!=0x02)&&(space_HEX!=0x00))
            {
            
            }
              
            
           Pay_Type=0x52; 
          }*/
        

            AMT_READER_INIT=0;
            
            if(Pay_Type==0x10) //����
            {
              oldspace_HEX=space_HEX; //2014-9-1              
              //              KeyInfor.times++;
              if(KeyInfor.times==0 && LCD_KEY==1)
                KeyInfor.times++;
              else 
                KeyInfor.times+=2;
              continue;
            }
            
            else   if(Pay_Type==0x11) 
            {
            //
              Enter_MainMenu();
              Pay_Type=0x52;
            }
            
            //�������Ѵ���--------------------------------
            OPEN_CLOSE_IRQ(IRQ_CLOSE,ALL_IRQ);
            OPEN_CLOSE_IRQ(IRQ_OPEN,DOOR_IRQ);           
            key_flag=0;
            
            delay_process=0xff;
            
             Coin_menu_flag=0;
            if((Pay_Type==0x20)||(Pay_Type==0x22)) //Ӳ������ //0x22���һ��
            {
              IWDG_ReloadCounter(); //ι��
              lcd_clearxy18(0,80,112);   //�������ʾ���һ�仰 
              if((space_HEX>=MeterInfor.space_range[0])&&(space_HEX<=MeterInfor.space_range[1]));
              else
                space_HEX=oldspace_HEX;
              delay_process=coin_pay(space_HEX,Pay_Type,wakecoininf.coinmoney);
              EmptyRcvCoin();
            } 
            else if((Pay_Type==CONTACTPAY)||(Pay_Type==NO_CONTACTPAY)) //ˢ������
            {             
              IWDG_ReloadCounter(); //ι��
              lcd_clearxy18(0,80,112);   //�������ʾ���һ�仰 
              delay_process=two_typecard(Pay_Type);
            }
            else if(Pay_Type==0x52);//����ȡ��--����������       
            else//��ʱ����
            {
              Buzz_0;
              if(LCD_KEY==0) //���û���±���������һ�п���������ʾ����ʱ��
                display_lastinfor(0,112,0x19); //��ʱ
              close_coin_power();
              Mifare_Power_OFF;         
              Contact_Power_OFF;
             
              delayms(40);
              
              Buzz_1;         
              delay_process=ERROR_NOWAIT; 
              
            }  
            //��ʱ����-----------start-------
            if(delay_process==0xff);           
            else 
            {
              key_flag=0;
              OPEN_CLOSE_IRQ(IRQ_OPEN,KEY_IRQ);//�򿪰���                            
              if(delay_process==ERROR_NOWAIT)
              {
               // delayms_keybreak(ERROR_DELAY);
              } 
              else if(delay_process==0)
              {delayms_keybreak(DELAYTIME);}                
              else ; 
              key_flag=0;                      
            }
             //��ʱ����-----------end-------
            goto_program=PROGRADISPALY;   //�����������������
            break;
            //5\�ж��Ƿ��а�������Ͷ�ң��в忨����mifare����--------end------------
          }while(1);          
        }
        //2��ѹ���------------end------------------------
        
        //2�͵�ѹ-----------------start-------------------
        else    
        {        
          Buzz_0;            
          key_flag=0;
          wake_flag=0; 
          lcd_clear();
          diaplay_fault(4);
          Buzz_1; 
          //key_scan(0);
          touchkey_return(0);
          judge_get_time();
          
         // make_record(Wakeup_32S,0,0xa0); //�͵�ѹ��¼
          make_record_Alarm(Low_volt_0,0,0,0xa0);
          
          goto_program=PROGRADISPALY; //��ʾ���߽���
          LCD_KEY=0;
          delayms(DELAYTIME);
        }  
        //2�͵�ѹ-----------------end-------------------  
        
        /*��ʾ������-----------start------------------*/ 
        if(goto_program==PROGRADISPALY) //��һ�ΰ��˱���ʱ���Ͳ����룬ֱ������
        { 
          if(program_goto(goto_program,LCD_KEY)==1) //�а���
          {
            wake_flag=0;//�ٴν���---��ѭ����ⰴ������-- 
            continue; 
          }
        }
        /*��ʾ������------------end-----------------*/  
      }    
      //��һ�����а���-------------end----------------------     
    } 
    /*2��������⻽������ ------end-----------*/  
   
    
    //----�������߿���оƬ����------------------
    IWDG_ReloadCounter(); //ι��
//    if(key_flag==0)
//    {
//      Record_TXMechanism(0);         //buffer[0]��¼���ͻ���  
//    }   
    if(key_flag)
    { 
      wake_flag=0;
      continue;  
    }
    program_goto(PROGRAMSLEEP,0); 
  }
}



//----3s����ʱ(���ݶ�������Ӳ�һ��ĺû�)------------------------------
u8 count_down_3s(u8 mifare_able, u8 coin_OK ,u8 quitkey )
{
  u8 threetimes=0;  //���������3�λ���,lastcoin
  u8 cardenable;
  u16 cointemp;
  u32  maxtimeout;
  u32  mtime[5];
  //u16  interval_time;
  u8 falgeio;
 // char i;
  u8 inicount=4;
  u8  keyvlaue;
  u8  mifare_able_0;
    u8 coinbuffer[16];
  u16 ct_coin; //��ǰӲ�һ�����

  mifare_able_0=mifare_able;
  

         for(int i = 0; i < 4; i++)
        {
              CardInfor.cardNO[i]=0x00;
        }
  
  if(KeyInfor.keyvalue!=KEY_X) //�������˳���
  {
    if(( mifare_able==1)&&(space_HEX>=MeterInfor.space_range[0])) //�������õ�
    {
      mtime[0]=M_5S; 
      mtime[1]=M_4S; 
      mtime[2]=M_3S;
      mtime[3]=M_2S; 
      mtime[4]=M_1S;
    }

    else               //������û�򿪣��Ͳ���Ѱ��������ʱ�佫��ܳ�
    {
      
      if((space_HEX==0x00)&&(  key_flag==2))
      {
        
       mtime[0]=C_M_1S*15; 

       mtime[4]=C_M_1S; 
      
      }
      else
      { 
      mtime[0]=L_M_5S; 
      mtime[1]=L_M_4S; 
      mtime[2]=L_M_3S;
      mtime[3]=L_M_2S; 
      mtime[4]=L_M_1S; 
      
      }
      
      
 

    } 
      
  //  if((space_HEX==0x00))
    maxtimeout=mtime[0]+1; 

  }
  
  else
  {    
    maxtimeout=3; 
    Buzz_1; 
  }
  //5\�ж��Ƿ��а�������Ͷ�ң��в忨��
  


 // maxtimeout=M_1S*15+1;



  while(maxtimeout--)
  { 
    delayms(20);
    
    //4������
    /*if(maxtimeout==mtime[0]) 
      Print_time(5);
    else
    if(maxtimeout==mtime[1]) 
      Print_time(4);
    else if(maxtimeout==mtime[2])
      Print_time(3);
    else if(maxtimeout==mtime[3])
      Print_time(2);
    else if(maxtimeout==mtime[4])
      Print_time(1);
    else*/
    if (maxtimeout%mtime[4]==0) 
    {
      Print_time(maxtimeout/mtime[4]);
    } 
    if(maxtimeout==3)
    {
      //��ǰ�ǲ���˵������֮ǰ���а�������һ��ѭ��������
      if((KeyInfor.keyvalue==KEY_Instruct)&&(space_HEX>=MeterInfor.space_range[0]))
        return 0x10;
    }
    else if(maxtimeout==2) //��ʱ
    { 
      ////////////////////////////////////////
      OPEN_CLOSE_IRQ(IRQ_CLOSE,ALL_IRQ);
      OPEN_CLOSE_IRQ(IRQ_OPEN,DOOR_IRQ);
      key_flag=0;
      Print_time(0);
//      delayms(300);  //ע��  
      delayms_break(300);
      cointemp=rx_coin(); 
      if(cointemp==ONEMOP || cointemp==FIVEMOP)//֮ǰ��Ͷ�� 
      {
        wakecoininf.totalcoinmoney+=cointemp;
        if(FEE.reachmaxtime==0)
          wakecoininf.coinmoney+=cointemp;
        close_coin_power();
        Mifare_Power_OFF;
        if(space_HEX==0)//��û����
        {
         ADD_coin(wakecoininf.coinCount,wakecoininf.totalcoinmoney);
          return 0x50; //��ʱ
        
        }
        else
          return 0x22;
      }      
      else
      { 
        wakecoininf.totalcoinmoney+=0;
        close_coin_power();
        if(wakecoininf.totalcoinmoney)
        {
          if(space_HEX==0)//��û����
          {
            
            
           //wakecoininf.totalcoinmoney;//hex  
            //
            
     
            
            ADD_coin(wakecoininf.coinCount,wakecoininf.totalcoinmoney);
            
            return 0x50; //��ʱ
            
          //
          }
          else
            return 0x22;
        }
        if(KeyInfor.keyvalue!=KEY_X) //�������˳���
          return 0x50;
        else
          return 0x52; 
      } 
    } 
    
   //   display_lastinfor(0,112,0x53);   
    //�а���
    if((key_flag==1)&&(s_head==s_tail))
    {  
      
                      keyvlaue=touchkey_scan(key_flag);
        
                       // if( key_value(KeyInfor.times)==KEY_Chinese)
  
                       // if( touchkey_scan(key_flag)==KEY_Chinese)

                  if(keyvlaue==KEY_Chinese) 
                        {

                           if(MeterInfor.Language[0]==Chinese)
                      {
                        MeterInfor.Language[0]=Portugal;
                         MeterInfor.Language[1]=Portugal;
                       }
                       else
                       {
                         MeterInfor.Language[0]=Chinese;
                          MeterInfor.Language[1]=Chinese;
                       }
                     if(Coin_menu_flag==1) 
                     {
                         mifare_able_0=0x05;
                     }
                       
                      if (mifare_able_0==0x03)
                      {
                       maxtimeout=mtime[0]+1;
                       lcd_clear();  
                       display_OI();
                 
                      }  
                      else if (mifare_able_0==0x05)
                      {    
                           maxtimeout=mtime[0]+1;
                           lcd_clear();  
                           display_wake(space_HEX,2); 
                           
                                  
                           display_lastinfor(0,112,0x46);   // �����복λ
                      }
                      
                      else
                      {
                     
                        falgeio=1;
                        dispaly_space(&falgeio);
                        
                         if(mifare_able==0xFF)
                               display_lastinfor(0,112,0x56);      
                                else
                                display_lastinfor(0,112,0x53); 
                        
                      
                      }
                       
                        }else  if(keyvlaue==KEY_3) 
                         {
                           if(space_HEX==KEY_3)
                           {
                                
                              return 0x11;
                           }
                           else
                           {
                            return 0x10;
                           }
                           
                           
                           }
                            
                            else
                        {
                          return 0x10;
                        }
                        key_flag=0;
      
    }

    
    
    
    
    
    
    //1Ӳ��������    
    //if(s_head!=s_tail)

     if(esflag) 
      
    { //Ӳ�� -�ж�������
      //maxtimeout=mtime[0];
      Coin_menu_flag=1; 
      cointemp=rx_coin();
      
      if(MeterInfor.Language[0]==MeterInfor.Language[1])
        ;
        else
          MeterInfor.Language[0]=MeterInfor.Language[1];
      if(cointemp==ONEMOP || cointemp==FIVEMOP)//��Ͷ��
      {
        
           
        
           maxtimeout=mtime[0]+1;
        
            if(jd_maxtime(0)==0) 
            {
           //   coinbuffer ct_coin
              
    
              
                I2C_ReadS_24C(MeterCoinTotalAddr,coinbuffer,2);     //
                ct_coin=coinbuffer[0];
                ct_coin=(ct_coin<<8)+coinbuffer[1];
                ct_coin+=cointemp;    
                coinbuffer[0]=(ct_coin>>8)&0xff; 
                coinbuffer[1]=ct_coin&0xff;
                I2C_WriteS_24C(MeterCoinTotalAddr,coinbuffer,3);  
                
                
                I2C_ReadS_24C(MeterCoinCountAddr,coinbuffer,2);     //
                ct_coin=coinbuffer[0];
                ct_coin=(ct_coin<<8)+coinbuffer[1];
                ct_coin+=1;    
                coinbuffer[0]=(ct_coin>>8)&0xff; 
                coinbuffer[1]=ct_coin&0xff;
                I2C_WriteS_24C(MeterCoinCountAddr,coinbuffer,3);       
              
              //�����¼
             delayms(30);   
                 make_record_Alarm(Unown_coin,cointemp,0,0xa0);
                    maxtimeout=mtime[0]+1;
                    
          
            }
            else
            {
            
           
       
        
         
        wakecoininf.totalcoinmoney+=cointemp;
        wakecoininf.coinCount+=1;
        
        
        if(FEE.reachmaxtime==0)
          wakecoininf.coinmoney+=cointemp;
        Mifare_Power_OFF;
        Contact_Power_OFF;
        if(space_HEX==0)//��û����
        {
          Buzz_0;   
          delayms(20);    
          Buzz_1;
          FEE.reachmaxtime=coinmoney_to_time(0,wakecoininf.coinmoney);
          lcd_clear();   
          display_wake(space_HEX,2); 
          display_lastinfor(0,112,0x46);   // �����복λ
          //��ʾӲ�ҹ�����Ϣ
          display_coinInfor(space_HEX,wakecoininf.coinmoney,0);
     
          if(FEE.reachmaxtime==1) //�����е������ͣ����           
          {
            display_lastinfor(0,112,0x30); 
          }  
         
          
          
         
          
        }
        else
        {
          
        //  display_lastinfor(0,112,0x46);
          if(quitkey!=KEY_X)
            return 0x20;
          else
            return 0x22; //���һ��
        }
        
         }
      }
      else
      {
        wakecoininf.totalcoinmoney+=0;
        if(FEE.reachmaxtime==0)
          wakecoininf.coinmoney+=0;
      }
    }         
    //2�в忨�ܲ�ͨ��(���ҳ�λ��Ϊ0)
    if((IC_SWITCH_read==YESZBTCARD)&&(space_HEX>=MeterInfor.space_range[0])&&(jd_maxtime(0)!=0))
    {
      delayms(50);
      if(IC_SWITCH_read==YESZBTCARD)
      {        
        close_coin_power();
        Mifare_Power_OFF;    
        Contact_Power_ON;
        return CONTACTPAY;
      }
    }
    //3��mifare����----------start------------
    //1500000
     if((mifare_able==0xFF)||(Reaser_OK_flag==1) )
     {
       //delayms(16);   
     }
   // if((mifare_able==1)&&(space_HEX>=MeterInfor.space_range[0])&&((maxtimeout%2)==0))

     //if((mifare_able==1)&&(space_HEX>=MeterInfor.space_range[0]))
         
        if((mifare_able==1)&&(space_HEX>=MeterInfor.space_range[0]))         
    { 
      
      
    if(AMT_READER_INIT==0)  
    {
   
      
    while(inicount>1)
    {
    
     if(AMT_init()==0)
       break; 
       
      inicount--;
     
    }

    
    if(inicount==1)
    {
      make_record_Alarm(Reader_NG_0,0,0,0xa0);
      Reaser_OK_flag=1;
      
       display_lastinfor(0,112,0x56);
       mtime[0]=L_M_5S; 
       mtime[1]=L_M_4S; 
       mtime[2]=L_M_3S;
       mtime[3]=L_M_2S; 
       mtime[4]=L_M_1S;  
       maxtimeout= mtime[0];
       
       mifare_able =0xFF; 
    }
    else
    {
      
    AMT_READER_INIT=1;
    }
    
    
     }
      
      
      cardenable=newinquire_comd(1);
     //cardenable=0x50;
      if(cardenable==0x10)//ˢ��||(cardenable==0x20)
      {
        close_coin_power(); 
        Contact_Power_OFF;
        //b����Կ
       // Read_MF1A();
        return NO_CONTACTPAY;
      }
      else if(cardenable==0x30);//��Ӳ�һ�忨
      else if(cardenable==0x40)////������������,��Ͷ��  
      {              
        IWDG_ReloadCounter(); //ι��
        threetimes++;
       if(threetimes==2) 
       {  
        Mifare_Power_OFF;//�رյ�Դ
//        ERRLED_ON; 
        mifare_able=0;  
        
        mtime[0]=Min_5S;
        mtime[1]=Min_4S; 
        mtime[2]=Min_3S;
        mtime[3]=Min_2S;
        mtime[4]=Min_1S;
        
        maxtimeout=mtime[1]+1;
        if(coin_OK==0)
          display_lastinfor(0,112,0x13); 
        else
        { 
          PrintGB(50,112,"����������"); 
          //���ϼ�¼        
          //make_record(Wakeup_32S,0,0x06); //����������
        } 
       }    
      }      
      
    }
    //������------------end--------------   
  }
  return 0x50;
}


/*---------�����Ѵ���-------------*/
u8 two_typecard(u8 Pay_Type)
{
  u8  cardenable;
  u8  first_bushcard;
  u32  maxtimeout;
  u32  mtime[5];
  
  
  maxtimeout=M_5S; 
  cardenable=0x10;  //MIfare��
  
  //����ѭ��-----start---------
  do
  { 
    
    ReadFCardInf(); //��ȡ��һ�ε�ˢ����Ϣ
    
    //mifare������---------------start-------------------
    if(Pay_Type==NO_CONTACTPAY)
    {  
      //�ڶ���ˢ���ѿ�
      if((FCardInfor.space==space_HEX)&&( FCardInfor.type==NO_CONTACTPAY)
         &&(FCardInfor.cardNO[0]==CardInfor.cardNO[0])&&(FCardInfor.cardNO[1]==CardInfor.cardNO[1])
           &&(FCardInfor.cardNO[2]==CardInfor.cardNO[2])&&(FCardInfor.cardNO[3]==CardInfor.cardNO[3]))
      {
        //1\��Ҫ����ȡ�ó�λд��������Ϣ������飩������
        ReadErrSpacesInf(space_HEX);
        /////////////////////////////////////////////////////////////////////////////  
        ///2\֮ǰ��ͬһ�ſ�д������(������ˢ��)
     /*   if((ErrSpacesInfor.errorflag!=0)&&(ErrSpacesInfor.cardNO[0]==CardInfor.cardNO[0])&&(ErrSpacesInfor.cardNO[1]==CardInfor.cardNO[1])
           &&(ErrSpacesInfor.cardNO[2]==CardInfor.cardNO[2])&&(ErrSpacesInfor.cardNO[3]==CardInfor.cardNO[3]))
        {
          if(ErrSpacesInfor.space==space_HEX)
            first_bushcard=mifare_pay(cardenable,space_HEX,THIRDERROP);//�������ߴ�����
          else
          {    
            close_mifare(0x24);
            break;
          }
        }
        else*/
          first_bushcard=mifare_pay(cardenable,space_HEX,SECONDCONSUMEOP);//�ڶ������Ѳ���
      }
      //��һ��ˢ���ѿ�
      else       
      {
        //1\��Ҫ����ȡ�ó�λд��������Ϣ������飩������
        ReadErrSpacesInf(space_HEX);
        /////////////////////////////////////////////////////////////////////////////  
        ///2\֮ǰ��ͬһ�ſ�д������(������ˢ��)
       /* if((ErrSpacesInfor.errorflag!=0)&&(ErrSpacesInfor.cardNO[0]==CardInfor.cardNO[0])&&(ErrSpacesInfor.cardNO[1]==CardInfor.cardNO[1])
           &&(ErrSpacesInfor.cardNO[2]==CardInfor.cardNO[2])&&(ErrSpacesInfor.cardNO[3]==CardInfor.cardNO[3]))
        {
          if(ErrSpacesInfor.space==space_HEX)
            first_bushcard=mifare_pay(cardenable,space_HEX,THIRDERROP);//�������ߴ�����
          else
          {
            close_mifare(0x24);
            break;
          }
        }
        else
          */
          first_bushcard=mifare_pay(cardenable,space_HEX,FIRSTCHECKOP);//��һ�β�ѯ����
      }
    }
    //mifare������---------------end-------------------
    
    //�ܲ�ͨ������---------------start-------------------
    else //�ܲ�ͨ������
    {             
      first_bushcard=contact_pay(space_HEX);           
    }
    //�ܲ�ͨ������---------------end-------------------
  
    
    
    //��һ��ˢ�����أ��ȴ��ڶ���ˢ������
    if(first_bushcard==FIRSTCARD_Again)//��һ��ˢ��
    { 
      lcd_clear();   
      display_wake(space_HEX,1);
      OPEN_CLOSE_IRQ(IRQ_OPEN,KEY_IRQ);
      if(Pay_Type==NO_CONTACTPAY)//mifare������
      {
        display_lastinfor(0,112,0x25); //��ˢ��ͣ������
        //mtime[0]=M_5S;
        mtime[0]=M_3S; 
        mtime[1]=M_4S;
        mtime[2]=M_3S;
        mtime[3]=M_2S;
        mtime[4]=M_1S;
      }   
      else
      {
        display_lastinfor(0,112,0x42);  //��忨ͣ������
       // mtime[0]=ZTIMEOUT_5S;
        mtime[0]=ZTIMEOUT_3S; 
        mtime[1]=ZTIMEOUT_4S;
        mtime[2]=ZTIMEOUT_3S; 
        mtime[3]=ZTIMEOUT_2S;
        mtime[4]=ZTIMEOUT_1S;
      }       
      maxtimeout=mtime[0];
      Print_time(3);     
      //Сѭ��-----start---------
      while(--maxtimeout)
      { 
        if(Pay_Type==NO_CONTACTPAY)//mifare������
        {
          //cardenable=newinquire_comd(1); 
          cardenable= 0x10;
          if(cardenable==0x10)
          {   
            lcd_clearxy18(0,80,112);   //�������ʾ���һ�仰
            OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
            break; //����С��ѭ��
          } 
        }
        else//�ܲ�ͨ������
        {
          if(IC_SWITCH_read==YESZBTCARD)
          {  
            lcd_clearxy18(0,80,112);   //�������ʾ���һ�仰
            OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
            break; //����С��ѭ��
          }              
          
        }
        
         if(key_flag==1) //�а���
        { 
          //KeyInfor.keyvalue=key_scan(0x88);
          KeyInfor.keyvalue=touchkey_return(0x88);
          if(KeyInfor.keyvalue==KEY_X)//ȡ����
          {
            OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);          
            maxtimeout=1;         
            //display_lastinfor(0,112,0x49);//ȡ����....            
          }
        }//��ǰ����ֵ 
        
        
        //������
        if(maxtimeout==mtime[1])  
          Print_time(4);
        else if(maxtimeout==mtime[2]) 
          Print_time(3);
        else if(maxtimeout==mtime[3]) 
          Print_time(2);
        else if(maxtimeout==mtime[4]) 
          Print_time(1);
        else if(maxtimeout==1) //��ʱ
        { 
          Mifare_Power_OFF;
          Contact_Power_OFF;
          Buzz_0;
          OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
          Pay_Type=0; //������                
          Print_time(0); 
          if(KeyInfor.keyvalue!=KEY_X)//ȡ����)
            display_lastinfor(0,112,0x19); //��ʱ
          else
            display_lastinfor(0,112,0x49);//ȡ����....         
          delayms(40);
          Buzz_1;
          break; //����С��ѭ��
        }     
        
      }
      //Сѭ��-----end--------
    }
    //��һ��ˢ��-----------end------------
    
    //ˢmifare�����֣�ʧ��1���߿��ˡ�2������־��3�������۷�ʧ��0x80��,���˳��������ڵĽ���ͣ��5s����ʱ-----start--------------------
    else if((first_bushcard==ERROR_WAIT)||(first_bushcard==0x80))
    { 
      if(Pay_Type==NO_CONTACTPAY)//ˢmifare������
      {      
        mtime[0]=M_5S;
        mtime[1]=M_4S;
        mtime[2]=M_3S;
        mtime[3]=M_2S;
        mtime[4]=M_1S;
        
        maxtimeout=mtime[0];
        Print_time(5);
        //С��ѭ��--------start----------
        OPEN_CLOSE_IRQ(IRQ_OPEN,KEY_IRQ);
        
        while(maxtimeout--)
        {               
          cardenable=newinquire_comd(0); //3s����Ѱ��                 
          if(cardenable==0x10)
          {                   
            OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
            lcd_clearxy18(0,80,112);   //�������ʾ���һ�仰
            break;
          }
          
           if(key_flag==1) //�а���
          { 
            //          KeyInfor.keyvalue=key_scan(0x88);
            KeyInfor.keyvalue=touchkey_return(0x88);
            if(KeyInfor.keyvalue==KEY_X)//ȡ����
            {
              OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);          
              maxtimeout=1;         
              //            display_lastinfor(0,112,0x49);//ȡ����....            
            }
          }//��ǰ����ֵ 
          
          
          //������
          if(maxtimeout==mtime[1])  
            Print_time(4);
          else if(maxtimeout==mtime[2]) 
            Print_time(3);
          else if(maxtimeout==mtime[3]) 
            Print_time(2);
          else if(maxtimeout==mtime[4]) 
            Print_time(1);
          else if(maxtimeout==1) //��ʱ
          { 
            OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
            Buzz_0;
            Pay_Type=0;                 
            Print_time(0); 
            if(first_bushcard==0x80) //�ۿ������ʾ
              display_lastinfor(0,112,0x28); 
            else
            {
              if(KeyInfor.keyvalue!=KEY_X)//ȡ����)
                display_lastinfor(0,112,0x19); //��ʱ   
              else
                display_lastinfor(0,112,0x49);//ȡ����.... 
            }
            Mifare_Power_OFF;                 
            delayms(40);
            Buzz_1;
            break;
          }
        }
      }
      //С��ѭ��--------end---------
      //ˢmifare�����֣�ʧ��1���߿��ˡ�2������־��3������---------------------end----------------------------------------
      
      //���ܲ�ͨ�����֣��۷�ʧ��0x80��,���˳��������ڵĽ���ͣ��3s����ʱ-----start--------------------
      else //if((Pay_Type==CONTACTPAY)&&(first_bushcard==0x80))
      {           
        mtime[0]=ZTIMEOUT_5S;
        mtime[1]=ZTIMEOUT_4S;
        mtime[2]=ZTIMEOUT_3S; 
        mtime[3]=ZTIMEOUT_2S;
        mtime[4]=ZTIMEOUT_1S;
        maxtimeout=mtime[0];
        Print_time(5);
        //С��ѭ��--------start----------
        OPEN_CLOSE_IRQ(IRQ_OPEN,KEY_IRQ);
        while(maxtimeout--)
        {                
          if(IC_SWITCH_read==YESZBTCARD)
          {                   
            lcd_clearxy18(0,80,112);   //�������ʾ���һ�仰
            OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
            break;
          }  
          
           if(key_flag==1) //�а���
          { 
            //          KeyInfor.keyvalue=key_scan(0x88);
            KeyInfor.keyvalue=touchkey_return(0x88);
            if(KeyInfor.keyvalue==KEY_X)//ȡ����
            {
              OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);         
              maxtimeout=1;         
              //            display_lastinfor(0,112,0x49);//ȡ����....            
            }
          }//��ǰ����ֵ 
          
          //������
          if(maxtimeout==mtime[1])  
            Print_time(4);
          else if(maxtimeout==mtime[2]) 
            Print_time(3);
          else if(maxtimeout==mtime[3]) 
            Print_time(2);
          else if(maxtimeout==mtime[4]) 
            Print_time(1); 
          else if(maxtimeout==1) //��ʱ
          { 
            OPEN_CLOSE_IRQ(IRQ_CLOSE,KEY_IRQ);
            Buzz_0;
            Pay_Type=0;                 
            Print_time(0);                 
            display_lastinfor(0,112,0x28);
            Contact_Power_OFF;
            delayms(40);
            Buzz_1;
            break;
          }
        }
        //С��ѭ��--------end---------
      } 
      //ˢ�ܲ�ͨ�����ֿ۷�ʧ��---------------------end----------------------------
    }
    
    else if(first_bushcard==ERROR_CARD) //IC������
    {
      //Buzz_0;  
      lcd_clear();
      diaplay_fault(ERROR_CARD);
      Buzz_0;
      delayms(40);
       Buzz_1;
      delayms_keybreak(1000);
     
      return ERROR_NOWAIT;    
    }    
    else if(first_bushcard==ERROR_TIME) //ʱ�����
    {     
      Buzz_0; 
      lcd_clear();
//      diaplay_fault(2);
      delayms(40);
      Buzz_1;
      return ERROR_NOWAIT;
    }
     else if(first_bushcard==BLACKCARD) //ʱ�����
    {  
     return first_bushcard;
    }
    
    //��������˳���������-------start------------
    else
    {
      return first_bushcard;//��������ѭ��
    }
    //��������˳���������-------end---------------
    
    if(maxtimeout==1)  //ֻ��0x99ʱ��ʱʱ��������һ��ˢ����Ϣ
    { 
      WriteFCardInf(0); //�����һ��ˢ����Ϣ
      //      delayms(ERROR_DELAY); 
      break;  //��������ѭ��
    }
  }while(1);  
  //����ѭ��-----end---------
  return OVERTIME;
}



u8 program_goto(u8 flag ,u8 LCD_KEY)
{  
  u8 i;
  
  if(flag==2)
  {   
    MeterInfor.Language[0]=Chinese;
    MeterInfor.Language[1]=Chinese;
    key_flag=0;
    OPEN_CLOSE_IRQ(IRQ_OPEN,ALL_IRQ);    
    Mifare_Power_OFF;
    Contact_Power_OFF;  
    close_coin_power();      
    //ERRLED_OFF;      

    //c����λ״̬
    for(i=MeterInfor.space_range[0];i<=MeterInfor.space_range[1];i++)
    { 
      if(key_flag)
        return 1; 
      ReadSpaceUsingInf(i);       
    }        
    if(LCD_KEY==0) 
    {  
      lcd_clear();   
      display_sleep();  //���߽���  
    }
    else
    {
      LCD_KEY=0;
      lcd_clearxy18(73,80,0);//�������ʱ
    }   
  } 
  
  else  //�����������
  {  
    MeterInfor.Language[0]=Chinese;
    MeterInfor.Language[1]=Chinese;
    LCD_back_OFF; 
    irDA_Power_OFF;
    
  


    //ERRLED_OFF;
    //CMLED_OFF;
    key_flag=0; 
    OPEN_CLOSE_IRQ(IRQ_OPEN,ALL_IRQ);
    MeterInfor.sleepflag=1;
   
    sleep(); 
    //1.PWR_STOPEntry_WFI������ȴ��жϣ�ֻ���ں�ֹͣ���������У���PWR_STOPEntry_WFE������ȴ��¼� ���ں˺����趼ֹͣ����
    PWR_EnterSTOPMode(PWR_Regulator_LowPower, PWR_STOPEntry_WFI);
    //2.���ѷ��� ��ͨ�������ⲿ�жϽӿڻ��ѣ����Ѻ���Ҫ��������RCC�������������У�����PLL�رա�
    SYSCLKConfig_STOP();
    sleepout();  
    IWDG_ReloadCounter(); //ι��
    //ERRLED_OFF;
    //CMLED_OFF;
    MeterInfor.sleepflag=0;
    MeterInfor.Language[0]=Chinese;
    MeterInfor.Language[1]=Chinese;
    LCD_REVERSRDISPOFF; 
  }  
  return 0;
}







/*���Ѻ�����*/
void sleepout(void)
{    
  GPIO_Configuration();  
//  LCD_pin_init(); 
  I2C_GPIOB_Config();       //I2C 
  SPI_FLASH_Init();	    //Flash��ʼ��
  CCard_GPIOConfig();       //�����ܲ�ͨ	
  ChipOutHalInitsleep();   
}


			





/*����*/
void sleep(void)
{
  // ADC_InitTypeDef   ADC_InitStructure;
  GPIO_InitTypeDef  GPIO_InitStructure;
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////          
  //1�ر����д��ڵĽ���       
  AllUart_Close();
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, DISABLE);//�رմ���1ʱ��
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, DISABLE);//�رմ���2ʱ��
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, DISABLE);//�رմ���3ʱ��
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,  DISABLE);//�رմ���4ʱ��  
//  RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,  DISABLE);//�رմ���5ʱ��  
  //2FLASH
  SPI_Cmd(SPI_FLASH, DISABLE); 
  RCC_APB2PeriphClockCmd(SPI_FLASH_CLK | SPI_FLASH_GPIO_CLK | SPI_FLASH_CS_GPIO_CLK, DISABLE);
  //3ADC
  ADC_Cmd(ADC1,DISABLE);
  ADC_Cmd(ADC2,DISABLE);
  ADC_Cmd(ADC3,DISABLE);//ADC3
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, DISABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, DISABLE); 
  RCC_APB1PeriphResetCmd(RCC_APB1Periph_DAC, DISABLE);
  //  4FSMC (ע��)
  FSMC_SRAM_DISABLE(); 
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, DISABLE);	
  //GPIOA���Ž�IO����ΪAIN,�����������--huangfeng.
  //���ñ�׼�Ŀ⺯��,����͹���ģʽ(PWR_EnterSTOPMode��PWR_EnterSTANDBYMode����)
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOA, &GPIO_InitStructure);   
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;  |GPIO_Pin_11|GPIO_Pin_12
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;  
//  GPIO_Init(GPIOA, &GPIO_InitStructure);  
  
  //GPIOB���ţ�GPIO_PortSourceGPIOB, GPIO_PinSource5----32_PULES,GPIO_Pin_9--SP3243); |GPIO_Pin_12
  GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_6|GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_10|GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOB, &GPIO_InitStructure); 
  //GPIOC����	��8��13��14��15������|GPIO_Pin_12Ӳ�һ����� 
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_10|GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOC, &GPIO_InitStructure);	
  //GPIOD����(PD7--Ӳ��)|GPIO_Pin_6�����ж�;|GPIO_Pin_3Ӳ�һ�����
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_4|GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOD, &GPIO_InitStructure); 
  GPIO_InitStructure.GPIO_Pin  =GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14| GPIO_Pin_15;  
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOD, &GPIO_InitStructure); 		
  //GPIOE����
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOE, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14 |GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOE, &GPIO_InitStructure);	
  //GPIOF����
//  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//  GPIO_Init(GPIOF, &GPIO_InitStructure);
//  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//  GPIO_Init(GPIOF, &GPIO_InitStructure); 	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;  
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;  
  GPIO_Init(GPIOF, &GPIO_InitStructure);
  
  //GPIOG���� PG14---KEYLED���̵�|GPIO_Pin_15
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOG, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOG, &GPIO_InitStructure);
  
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, DISABLE);
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, DISABLE);	 //����32S
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, DISABLE);	 //����
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, DISABLE);	 //�Ŵ�
  //  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, DISABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, DISABLE);	 
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG, DISABLE);//2014-1-21 LCD��Դ
  //	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,  DISABLE);	 //�ж�	  
  
  ////////////////////////////////////////////////////////////////////////////////
  
  // Disable the Serial Wire Jtag Debug Port SWJ-DP ����
  GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, DISABLE); // 
  //////////////////////////////////////////////////////////////////////////////// 
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_SRAM | RCC_AHBPeriph_FLITF, DISABLE);     
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1 | RCC_AHBPeriph_DMA2 | RCC_AHBPeriph_CRC | RCC_AHBPeriph_SDIO, DISABLE);
  RCC_APB1PeriphResetCmd(RCC_APB1Periph_ALL, DISABLE); //2014-1-21
  RCC_APB2PeriphResetCmd(RCC_APB2Periph_ALL, DISABLE);
  RCC_RTCCLKCmd(DISABLE);
  ////////////////////////////////////////////////////////////////////////////////   
  //RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);//dis     
  
}



/*�������ڵ���������ͣ��ģʽ����֮������ϵͳʱ�ӡ�ʹ��HSE��PLL������
PLL��Ϊϵͳʱ��Դ��*/
void SYSCLKConfig_STOP(void)
{
  ErrorStatus HSEStartUpStatus;
  
  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);
  
  /* Wait till HSE is ready */
  HSEStartUpStatus = RCC_WaitForHSEStartUp();
  
  if(HSEStartUpStatus == SUCCESS)
  {
    
#ifdef STM32F10X_CL
    /* Enable PLL2 */ 
    RCC_PLL2Cmd(ENABLE);
    
    /* Wait till PLL2 is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLL2RDY) == RESET)
    {
    }
#endif
    
    /* Enable PLL */ 
    RCC_PLLCmd(ENABLE);
    
    /* Wait till PLL is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {
    }
    
    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
    
    /* Wait till PLL is used as system clock source */
    while(RCC_GetSYSCLKSource() != 0x08)
    {
    }
  }
}




