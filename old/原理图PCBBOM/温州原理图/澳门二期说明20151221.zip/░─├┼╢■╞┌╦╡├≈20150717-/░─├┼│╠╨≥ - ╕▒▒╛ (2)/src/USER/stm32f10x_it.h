/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.h 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   This file contains the headers of the interrupt handlers.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STM32F10x_IT_H
#define __STM32F10x_IT_H

#define  COINL   240
#define  GSML   2000

#ifdef __cplusplus
 extern "C" {
#endif 

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */


extern u8 key_flag;   	  
extern u8 wake_flag;

//extern u16 RxCounter_3G;                   //�������ݵĸ���
//extern u8  RxBuffer_3G[2000];	            //��������
//extern u8  RxState_3G;			    //('*'����ʱ=0x66) ���������ݱ�־λ 
extern u8   esflag_3G;
extern u16   s_head_3G,s_tail_3G; 
extern u8   recv_3G[2000];
extern u8   RxState_3G;		//('*'����ʱ=0x66) ���������ݱ�־λ
extern u16  RxCounter_3G;              //�������ݵĸ���

/*uart2Ӳ�һ�*/
extern u8   esflag;
extern u8   OK_flag_3G;
extern u8   OK_flag_POS;
extern u8   s_head,s_tail; 
extern u8   recvcoin[COINL];	 

/*uart3�жϽ��գ�������ģ��*/
extern u16 RxCounter_Card;                //���տ����ݵĸ���
extern u8  RxBuffer_Card[120];	          //���濨����
extern u8  RxState_Card;	          //(0x66) �����꿨���ݱ�־λ

void NMI_Handler(void);
void HardFault_Handler(void);
void MemManage_Handler(void);
void BusFault_Handler(void);
void UsageFault_Handler(void);
void SVC_Handler(void);
void DebugMon_Handler(void);
void PendSV_Handler(void);
void SysTick_Handler(void);
void EXTI15_10_IRQHandler(void);
void EXTI9_5_IRQHandler(void);
void EXTI3_IRQHandler(void);
#ifdef __cplusplus
}
#endif

#endif /* __STM32F10x_IT_H */

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
