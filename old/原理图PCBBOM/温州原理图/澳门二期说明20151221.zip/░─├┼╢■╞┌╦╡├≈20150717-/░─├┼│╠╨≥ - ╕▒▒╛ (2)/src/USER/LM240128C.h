#ifndef	_LM240128C_H
#define _LM240128C_H 
#include "delay_systick.h"

#define DSPBATTERYBMP   1
#define DSPBATTERYPOINT   0


#define LCDCENTERDISP   		0xFE//��ʾ����
#define LCDRIGHTDISP   			0xFD//��ʾ�Ҷ���
#define LCDLEFTDISP   			0xFC//��ʾ�����

#define LCD_REVERSRDISPON   	zimo_invert =1 //������ʾ��
#define LCD_REVERSRDISPOFF   	zimo_invert =0 //������ʾ��

#define  D0X 9
#define  DX  10
#define  DY  10


/*--------------LM240128C�������ŵĶ���------------------*/
#define db0_1  GPIO_SetBits(GPIOC, GPIO_Pin_0)
#define db0_0  GPIO_ResetBits(GPIOC, GPIO_Pin_0)

#define db1_1  GPIO_SetBits(GPIOC, GPIO_Pin_1)
#define db1_0  GPIO_ResetBits(GPIOC, GPIO_Pin_1)

#define db2_1  GPIO_SetBits(GPIOE, GPIO_Pin_2)
#define db2_0  GPIO_ResetBits(GPIOE, GPIO_Pin_2)

#define db3_1  GPIO_SetBits(GPIOE, GPIO_Pin_3)
#define db3_0  GPIO_ResetBits(GPIOE, GPIO_Pin_3)

#define db4_1  GPIO_SetBits(GPIOE, GPIO_Pin_4)
#define db4_0  GPIO_ResetBits(GPIOE, GPIO_Pin_4)

#define db5_1  GPIO_SetBits(GPIOE, GPIO_Pin_5)
#define db5_0  GPIO_ResetBits(GPIOE, GPIO_Pin_5)

#define db6_1  GPIO_SetBits(GPIOE, GPIO_Pin_6)
#define db6_0  GPIO_ResetBits(GPIOE, GPIO_Pin_6)

#define db7_1  GPIO_SetBits(GPIOG, GPIO_Pin_7)
#define db7_0  GPIO_ResetBits(GPIOG, GPIO_Pin_7)

#define lcd_rd_1  GPIO_SetBits(GPIOG, GPIO_Pin_8)
#define lcd_rd_0  GPIO_ResetBits(GPIOG, GPIO_Pin_8)

#define lcd_wr_1  GPIO_SetBits(GPIOG, GPIO_Pin_9)
#define lcd_wr_0  GPIO_ResetBits(GPIOG, GPIO_Pin_9)

#define lcd_rs_1  GPIO_SetBits(GPIOB, GPIO_Pin_15)
#define lcd_rs_0  GPIO_ResetBits(GPIOB, GPIO_Pin_15)

#define lcd_res_1  GPIO_SetBits(GPIOG, GPIO_Pin_11)
#define lcd_res_0  GPIO_ResetBits(GPIOG, GPIO_Pin_11)

#define lcd_cs_1  GPIO_SetBits(GPIOG, GPIO_Pin_12)
#define lcd_cs_0  GPIO_ResetBits(GPIOG, GPIO_Pin_12)

//ȡ��
#define LCD_back_ONOFF  GPIOB->ODR ^= (1<<13);
//#define LCD_back_ONOFF  {GPIOB->ODR ^= (1<<13);GPIOG->ODR ^= (1<<14);} //PG14

#define LCD_back_OFF   GPIO_SetBits(GPIOB, GPIO_Pin_13)
#define LCD_back_ON    GPIO_ResetBits(GPIOB, GPIO_Pin_13)

#define LCD_POWER_ON	GPIO_ResetBits(GPIOG, GPIO_Pin_13)//��ʾ����Դ���ƽŴ򿪡��ر�
#define LCD_POWER_OFF	GPIO_SetBits(GPIOG, GPIO_Pin_13)
/*--------------LM240128C�������ŵĶ���------------------*/

extern void LCD_pin_init(void);

//// ------------------  ������ģ�����ݽṹ���� ------------------------ //
typedef struct                // ������ģ���ݽṹ
{
       unsigned char Index[2];               // ������������
       char Msk[24];                       // ����������
}typFNT_GB12;

extern  typFNT_GB12 GB_12[];

typedef struct                // ������ģ���ݽṹ
{
       unsigned char Index;               // ������������
       char Msk[36];                       // ����������
}typFNT_GB9;

extern  typFNT_GB9 GB_9[];


typedef struct                // ������ģ���ݽṹ
{
       unsigned char Index[2];               // ������������
       char Msk[54];                       // ����������
}typFNT_GB18;

extern  typFNT_GB18 GB_18[];


typedef struct                // ������ģ���ݽṹ
{
  unsigned char Index[2];               // ������������   
  char Msk[32];                       // ����������
      
}typFNT_GB16;

extern  typFNT_GB16 GB_16[];

// ------------------  ������ģ�����ݽṹ���� ------code------------------ //

extern uchar zimo_invert;
extern void lcd_clear(void);
extern void lcd_clearxy(u8 x, u8 xx, u8 y); //y���� ��xx-x��;
extern void lcd_clearxy18(u8 x, u8 xx, u8 y); //y���� ��xx-x��
extern void LCD_INIT(void);
extern void display_space2(void);
extern void display_BCD(u8 x,u8 y,u8 a); //0x00-0xff
extern void display_byte(u8 x,u8 y,u8 a,u8 tpye);

extern void PrintASCII(uchar x, uchar y, uchar *pstr);
extern void PrintASCII16(uchar x, uchar y, uchar *pstr); 
extern void PrintASCII9(uchar x, uchar y, u8 n);
extern void PrintASCII18(uchar x, uchar y, uchar *pstr); 
//extern void PrintGB(uchar x,uchar  y, uchar *pstr);
void Draw_Line(uint x1,uint y1,uint x2,uint y2);
extern void PrintGB(unsigned char x,unsigned char y,char * sentence);
extern void PrintGB18(unsigned char x,unsigned char y,char * sentence);
extern void Display_HZ18(unsigned char x,unsigned char y,uchar index[2]);
extern void display_time(uchar x,uchar y);
extern void display_grid_0(u8 lastnum ,u8 y , u8 line, u8 ymax);
extern void display_meternum(unsigned char x,unsigned char y);
extern void display_space(void);
extern void Display_HZ18_ABCD(unsigned char x,unsigned char y,uchar index[2]);
extern void Display_money(unsigned char x,unsigned char y,unsigned long money,u8 displaytype);
extern void Display_time(unsigned char x,unsigned char y,unsigned long money);
extern void display_sleep(void);
extern void display_wake(u8 space,u8 flag);
extern void display_oneline_0(u8 x, u8 y,u8 minspace, u8 maxspace );
extern void display_wake_0(u8 space,u8 flag);
extern void PrintASCII16_amt(uchar x, uchar y, uchar *pstr,u8 length) ;

extern void Display_money_DY(unsigned char x,unsigned char y,unsigned long money,u8 displaytype);
extern void display_head();
extern void display_head_0(void);
extern void display_Infor(u8 space,u8 money, u8 less, u8 dsptype); //
extern void display_Infor_0(u8 space,u8 money, u8 less, u8 dsptype); 
extern void display_coinInfor(u8 space,u8 money, u8 less) ;
//extern void display_total(u8 type,u32 money);
extern void display_consume(u8 type,u8 parkingmoney,u32 money);
extern void display_lastinfor(u8 x,u8 y,u8 type);
extern void display_cardnum(u8 x,u8 y,u8 cardtype);
extern void display_functioncard(u8 card_type);
extern void ShowBMP_ABCD(uchar x,uchar y,uchar width,uchar high,uchar bmp[]);
extern void diaplay_fault(u8 type);
extern void display_OI(void);
extern void display_FBushCard(u8 type, u32 money);
extern void Disp_ChineseWord(u8 hang,u8 lie,char * sentence);
extern void Print_time(u8 timers);
extern void display_battery(u8 distype);
extern void Disp_EnglishStr(u8 hang, u8 lie, u8 *pstr) ;
extern u8 dispaly_space(u8 *disflag);
extern void display_welcome(void);
extern void CT_fb_off_gb_off(void);
extern void CT_fb_on_gb_off(void);
extern void display_grid_ABCD(u8 lastnum ,u8 y , u8 line, u8 ymax);
extern void Display_Version(unsigned char x,unsigned char y,u8 current_update);
extern void display_lastinfor_AMT(u8 x,u8 y,u8 type,u8 sencond);
extern void Display_money_BT(unsigned char x,unsigned char y,unsigned long money,u8 displaytype);
#endif