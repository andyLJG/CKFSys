#include "stm32f10x_it.h"
#include "delay_systick.h" 
#include "Hal.h"
#include "touch_key.h"
#include "I2C_Driver.h"
#include "spi_flash.h"
#include "ADC.h"
#include "LM240128C.h"  //����
#include "GPIO.h"
#include "mifare.h"
#include "MemoryAssign.h"
#include "fsmc_sram.h"
#include "MAIN.h"
#include "ir_comm.h"
#include "USART.h"
#include "St_wcdma.h"
#include "HW_check.h"  
#include "COIN.h" 
#include "blacklist.h"
#include "jiami.h"
#include "rate.h" 
#include "contact_card.h"  //�ܲ�ͨ
#include "save_record.h"
#include "report.h"
#include "IAP_Update.h"
 

ADCValveInformation ADCinf;

//ADC����
void ADC_Configuration(void)
{
  ADC_InitTypeDef   ADC_InitStructure;
  GPIO_InitTypeDef  GPIO_InitStructure;
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE); 
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE);  
  /* PC2*/
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
  /* ADC1 */
  ADC_InitStructure.ADC_Mode               = ADC_Mode_Independent;		//����ģʽ
  ADC_InitStructure.ADC_ScanConvMode       = ENABLE;						//������ͨ��ģʽ
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;						//����ת��
  ADC_InitStructure.ADC_ExternalTrigConv   = ADC_ExternalTrigConv_None;	//ת������������
  ADC_InitStructure.ADC_DataAlign          = ADC_DataAlign_Right;			//�Ҷ���
  ADC_InitStructure.ADC_NbrOfChannel       = 1;							//ɨ��ͨ����
  ADC_Init(ADC1, &ADC_InitStructure);	                                 
  ADC_RegularChannelConfig(ADC1, ADC_Channel_13, 1, ADC_SampleTime_55Cycles5);	//ͨ��1X,����ʱ��Ϊ55.5����,1��������ͨ����1��
  ADC_Cmd   (ADC1, ENABLE);             /* Enable ADC1                        */
  ADC_SoftwareStartConvCmd(ADC1,ENABLE);/* Start ADC1 Software Conversion     */ //ʹ��ת����ʼ
  
}

//�ر�ADC
void ADC_DISABLE(void)
{
  ///////////////////////////////////////////////////////////////////////////// 
  ADCCTRL_0;  
  ADC_Cmd   (ADC1, DISABLE);             /* Enable ADC1                        */
  ADC_SoftwareStartConvCmd(ADC1,DISABLE);/* Start ADC1 Software Conversion     */ //ʹ��ת����ʼ   
  /////////////////////////////////////////////////////////////////////////////
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, DISABLE);
}

void my_Net_Run(u8 flage_net_link)
{
     u8 require_buff[3];
    if (flage_net_link==1) 
    {
      
    }
    else if (flage_net_link==0) 
    {
        if ((time[1]==0x00)&&(time[0]>=0x01)&&(time[0]<=0x02))
        {
               flage_net_link=1;
        }
    }
    else
    {
     flage_net_link=0;
    }

      
     if (flage_net_link==1)    
    {
      
      for(int i = 0; i < 3; i++)
      {
             require_buff[0]=0x00;
             require_buff[1]=0x00;
             require_buff[2]=0x00;
             I2C_WriteS_24C(Today_Update_OK,require_buff,3); 
      }
      
      
       require_buff[0]=0x00;
       I2C_WriteS_24C(NET_MAX_LINK_COUNT,require_buff,1); 
      
    }


}
void my_volum_alarm(void)
{
    u8 buffer[3];
    buffer[0]=0;//��1��û���־
    buffer[1]=0;//û���־
    buffer[2]=0;//û�����
    I2C_WriteS_24C(LOWPOWER,buffer,3);  //���   

  for(int i = 0; i < 5; i++)
  {
    TestADC1();
  }
  


}
/*ADC1���*/
u8 TestADC1(void)
{
  u8 i,flag; 
  u8 buffer[3];
  u16 adc;
  u32 outtime;
  
  ADCCTRL_1;
  outtime=50;
  while(--outtime)
  {
    //    if(outtime<=1) 
    //      break;
    if(key_flag || wakecoininf.wakecoin_flag == Wakeup_COIN)
    {
      ADCCTRL_0;
      return 2;
    }
  }
  //����ADC  
  ADC_Configuration();        
  outtime=100000;
  while(--outtime)
  {
    if(outtime<=1) 
    {
      ADC_DISABLE();
      return 2;
    }
    if(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC)==SET)
    {
      adc=ADC_GetConversionValue(ADC1);
      ADC_DISABLE(); 
      break;
    }
    if(key_flag || wakecoininf.wakecoin_flag == Wakeup_COIN)
    {
      ADC_DISABLE();
      return 2;
    }
  } 
  
 //  adc=adc*(14600)/4096;//ADC�Ĳο���ѹ��3.3V��12λ��ADC(2��12�η�=4096)
  //1755
    adc=adc*(14370)/4096; //֮ǰ�㷨  
  ////////////////////////////////////////////////////////////////////
  if(ADCinf.length_mainvoltge>=ADCVALVEMAX)
  {
    ADCinf.length_mainvoltge=0;    
  }  
  ADCinf.main_voltage[ADCinf.length_mainvoltge]=adc;  
  ADCinf.length_mainvoltge++;  
  if(ADCinf.eventotal<ADCVALVEMAX)
    ADCinf.eventotal++;  
  
  ADCinf.evenvalue= ADCinf.main_voltage[0]; //û��ȥ�������С
  if(ADCinf.eventotal)
  {
    for(i=1;i<ADCinf.eventotal;i++)
    {
      ADCinf.evenvalue+= ADCinf.main_voltage[i];
    }  
    ADCinf.evenvalue=ADCinf.evenvalue/ADCinf.eventotal;
  }
  
  //
  
  if(ADCinf.evenvalue<STDVLOTAGE)
    flag=1; //û�� 
  else
    flag=0; //�� 
  // flag=0; //�� 
  //�е� 
  if(flag==0)
  {
    buffer[0]=0;//��1��û���־
    buffer[1]=0;//û���־
    buffer[2]=0;//û�����
    I2C_WriteS_24C(LOWPOWER,buffer,3);  //���   
  }
  //û��
  else 
  {
    I2C_ReadS_24C(LOWPOWER,buffer,3);
    if(buffer[1]==0)//֮ǰ���е�
    {      
      buffer[0]=0; //
      buffer[1]=1; //
      buffer[2]=1; //û������ۼӴ���3��������û��
    }
    else //֮ǰ��û��
    {
      if(buffer[2]>=4) 
      {
        buffer[2]=0;
        if(buffer[0]<5)
          buffer[0]++;//��2��û�� ���Ͳ�������¼  
        //          if(buffer[0]==1)//�͵�ѹ������¼
        //         make_alarmrecord(Alarm_OP,LowVoltage_Record,1); 
        
         make_record_Alarm(Low_volt_0,0,0,0xa0);
      }
      else
        buffer[2]++;
      
       // buffer[1]=1; 
    }      
    I2C_WriteS_24C(LOWPOWER,buffer,3);  //д
  }   

  return flag;
}

/**************************************************************
��MAX884ȡ����	
***************************************************************
function name:   	unsigned char LowVoltage_Test(void)
describe:    	 	�͵�ѹ��ⷵ��:0Ϊ�� 1Ϊ��
input:   		MAX884оƬLBO����PB14�����ѹ���	
output:
date:			huangfeng 2013.5.18
------------------------------------------------------------------------*/
unsigned char LowVoltage_Test(u8 type)
{  
  u8 flag;
  u8 buffer[3];
  
  
  //  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
  //  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;		//��������
  //  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
  if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14)==0)
  {
    delay_ms(10);
    if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14)==0)      
    { flag=1;}  //�͵�ѹ	
    else
      flag=0;
  }
  else
    flag=0; 
  
  if(type==1)
  {
    //�е� 
    if(flag==0)
    {
      buffer[0]=0;//��1��û���־
      buffer[1]=0;//û���־
      buffer[2]=0;//û�����
      I2C_WriteS_24C(LOWPOWER,buffer,3);  //���   
    }
    //û��
    else 
    {
      I2C_ReadS_24C(LOWPOWER,buffer,3);
      if(buffer[1]==0)//֮ǰ���е�
      {      
        buffer[0]=0; //��һ��û��
        buffer[1]=1; //û��
        buffer[2]=1; //û������ۼӴ���3��������û��
      }
      else //֮ǰ��û��
      {
        if(buffer[2]>=4) 
        {
          buffer[2]=0;
          if(buffer[0]<5)
            buffer[0]++;//��2��û�� ���Ͳ�������¼  
          //          if(buffer[0]==1)//�͵�ѹ������¼
          //           make_alarmrecord(Alarm_OP,LowVoltage_Record,1); 
        }
        else
          buffer[2]++;
        
        buffer[1]=1; 
      }      
      I2C_WriteS_24C(LOWPOWER,buffer,3);  //д
    }
  }
  //�ϵ���͵�ѹ
  else if(type==2)
  {
    //�е� 
    if(flag==0)
    {
      buffer[0]=0;//��1��û���־
      buffer[1]=0;//û���־
      buffer[2]=0;//û�����     
    }
    //û��
    else 
    {
      buffer[0]=1; //��һ��û��
      buffer[1]=1; //û��
      buffer[2]=1; //û������ۼӴ���3��������û��
      //      make_alarmrecord(Alarm_OP,LowVoltage_Record,1);
    }
    I2C_WriteS_24C(LOWPOWER,buffer,3);  //д
    
  }
  return flag;
}

