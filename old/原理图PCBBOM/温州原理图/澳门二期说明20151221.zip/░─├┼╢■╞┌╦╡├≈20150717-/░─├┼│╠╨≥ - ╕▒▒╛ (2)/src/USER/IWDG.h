#ifndef __IWDG_H
#define __IWDG_H
#include "stm32f10x.h"
extern void IWDG_Configuration(void);

#endif

