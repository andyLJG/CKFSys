#ifndef  _jiami_H
#define  _jiami_H

extern u8   system0_number[];
extern void MF1key_main(unsigned char * mimakey);

#endif
