#include "stm32f10x_it.h"
#include "delay_systick.h" 
#include "Hal.h"
#include "touch_key.h"
#include "I2C_Driver.h"
#include "spi_flash.h"
#include "ADC.h"
#include "LM240128C.h"  //����
#include "GPIO.h"
#include "mifare.h"
#include "MemoryAssign.h"
#include "fsmc_sram.h"
#include "MAIN.h"
#include "ir_comm.h"
#include "USART.h"
//#include "St_wcdma.h"
#include "HW_check.h"  
#include "COIN.h" 
#include "blacklist.h"
#include "jiami.h" //huangfeng 
#include "rate.h" //huangfeng 
#include "contact_card.h"  //�ܲ�ͨ
#include "save_record.h"
#include "report.h"


DayReport   DReport;
MonthReport MReport;
YearReport  YReport;

/*��ʼ���������ݣ����㣩*/
void Init_Report(void)
{
  u8  i;
  u8 tempbuf[16];
  
  for(i=0;i<16;i++)
  { 
    tempbuf[i]=0;
  }
  I2C_WriteS_24C(DayReport_Addr,tempbuf,3);
  I2C_WriteS_24C(DayReport_COINAddr,tempbuf,16);    
  I2C_WriteS_24C(DayReport_UNCONTACTAddr,tempbuf,8);
  for(i=0;i<16;i++)
  { 
    tempbuf[i]=0;
  }
  I2C_WriteS_24C(MonthReport_Addr,tempbuf,3);    
  I2C_WriteS_24C(MonthReport_COINAddr,tempbuf,16);
  I2C_WriteS_24C(MonthReport_UNCONTACTAddr,tempbuf,8);
  for(i=0;i<16;i++)
  { 
    tempbuf[i]=0;
  }
  I2C_WriteS_24C(YearReport_Addr,tempbuf,3);
  I2C_WriteS_24C(YearReport_COINAddr,tempbuf,16);
  I2C_WriteS_24C(YearReport_UNCONTACTAddr,tempbuf,8); 
}

//��������
void read_report(void)
{
  u8  i;
  u8 buffer[16];  
  
  
  //�ձ�������
  I2C_ReadS_24C(DayReport_Addr,buffer,3);
  for(i=0;i<3;i++)
  {
    DReport.TimeBCD[i]=buffer[i];
  }
  //�����
  if((time_BCD[2]==DReport.TimeBCD[2])&&(time_BCD[3]==DReport.TimeBCD[1])&&(time_BCD[4]==DReport.TimeBCD[0]))
  {    
    I2C_ReadS_24C( DayReport_COINAddr,buffer,8);
    DReport.COINtimes[0]=buffer[0];//4���ֽ��ܽ��״���
    DReport.COINtimes[1]=buffer[1];
    DReport.COINtimes[2]=buffer[2];
    DReport.COINtimes[3]=buffer[3];    
    DReport.COINmoney[0]=buffer[4];//4���ֽ��ܽ�� 
    DReport.COINmoney[1]=buffer[5];
    DReport.COINmoney[2]=buffer[6];
    DReport.COINmoney[3]=buffer[7];
    I2C_ReadS_24C( DayReport_CONTACTAddr,buffer,8);    
    DReport.CONTACTtimes[0]=buffer[0];
    DReport.CONTACTtimes[1]=buffer[1];
    DReport.CONTACTtimes[2]=buffer[2];
    DReport.CONTACTtimes[3]=buffer[3];    
    DReport.CONTACTmoney[0]=buffer[4];
    DReport.CONTACTmoney[1]=buffer[5];
    DReport.CONTACTmoney[2]=buffer[6];
    DReport.CONTACTmoney[3]=buffer[7];
    I2C_ReadS_24C( DayReport_UNCONTACTAddr,buffer,8); 
    DReport.UNCONTACTtimes[0]=buffer[0];
    DReport.UNCONTACTtimes[1]=buffer[1];
    DReport.UNCONTACTtimes[2]=buffer[2];
    DReport.UNCONTACTtimes[3]=buffer[3];    
    DReport.UNCONTACTmoney[0]=buffer[4];
    DReport.UNCONTACTmoney[1]=buffer[5];
    DReport.UNCONTACTmoney[2]=buffer[6];
    DReport.UNCONTACTmoney[3]=buffer[7];
  }    
  else  //�����
  {    
    DReport.TimeBCD[0]=time_BCD[4];
    DReport.TimeBCD[1]=time_BCD[3];
    DReport.TimeBCD[2]=time_BCD[2];
    DReport.COINtimes[0]=0;//4���ֽ��ܽ��״���
    DReport.COINtimes[1]=0;
    DReport.COINtimes[2]=0;
    DReport.COINtimes[3]=0;    
    DReport.COINmoney[0]=0;//4���ֽ��ܽ�� 
    DReport.COINmoney[1]=0;
    DReport.COINmoney[2]=0;
    DReport.COINmoney[3]=0; 
    DReport.CONTACTtimes[0]=0;
    DReport.CONTACTtimes[1]=0;
    DReport.CONTACTtimes[2]=0;
    DReport.CONTACTtimes[3]=0;    
    DReport.CONTACTmoney[0]=0;
    DReport.CONTACTmoney[1]=0;
    DReport.CONTACTmoney[2]=0;
    DReport.CONTACTmoney[3]=0;
    DReport.UNCONTACTtimes[0]=0;
    DReport.UNCONTACTtimes[1]=0;
    DReport.UNCONTACTtimes[2]=0;
    DReport.UNCONTACTtimes[3]=0;    
    DReport.UNCONTACTmoney[0]=0;
    DReport.UNCONTACTmoney[1]=0;
    DReport.UNCONTACTmoney[2]=0;
    DReport.UNCONTACTmoney[3]=0;
  } 
  
   //�걨������
  I2C_ReadS_24C(YearReport_Addr,buffer,3);
  for(i=0;i<3;i++)
  {
    YReport.TimeBCD[i]=buffer[i];
  }
  //�����
  if(time_BCD[4]==YReport.TimeBCD[0])
  {    
    I2C_ReadS_24C( YearReport_COINAddr,buffer,8);
    YReport.COINtimes[0]=buffer[0];//4���ֽ��ܽ��״���
    YReport.COINtimes[1]=buffer[1];
    YReport.COINtimes[2]=buffer[2];
    YReport.COINtimes[3]=buffer[3];    
    YReport.COINmoney[0]=buffer[4];//4���ֽ��ܽ�� 
    YReport.COINmoney[1]=buffer[5];
    YReport.COINmoney[2]=buffer[6];
    YReport.COINmoney[3]=buffer[7];
    I2C_ReadS_24C( YearReport_CONTACTAddr,buffer,8);    
    YReport.CONTACTtimes[0]=buffer[0];
    YReport.CONTACTtimes[1]=buffer[1];
    YReport.CONTACTtimes[2]=buffer[2];
    YReport.CONTACTtimes[3]=buffer[3];    
    YReport.CONTACTmoney[0]=buffer[4];
    YReport.CONTACTmoney[1]=buffer[5];
    YReport.CONTACTmoney[2]=buffer[6];
    YReport.CONTACTmoney[3]=buffer[7];
    I2C_ReadS_24C( YearReport_UNCONTACTAddr,buffer,8); 
    YReport.UNCONTACTtimes[0]=buffer[0];
    YReport.UNCONTACTtimes[1]=buffer[1];
    YReport.UNCONTACTtimes[2]=buffer[2];
    YReport.UNCONTACTtimes[3]=buffer[3];    
    YReport.UNCONTACTmoney[0]=buffer[4];
    YReport.UNCONTACTmoney[1]=buffer[5];
    YReport.UNCONTACTmoney[2]=buffer[6];
    YReport.UNCONTACTmoney[3]=buffer[7];
  }    
  else  //�����
  {    
    YReport.TimeBCD[0]=time_BCD[4];
    YReport.TimeBCD[1]=time_BCD[3];
    YReport.TimeBCD[2]=time_BCD[2];
    YReport.COINtimes[0]=0;//4���ֽ��ܽ��״���
    YReport.COINtimes[1]=0;
    YReport.COINtimes[2]=0;
    YReport.COINtimes[3]=0;    
    YReport.COINmoney[0]=0;//4���ֽ��ܽ�� 
    YReport.COINmoney[1]=0;
    YReport.COINmoney[2]=0;
    YReport.COINmoney[3]=0; 
    YReport.CONTACTtimes[0]=0;
    YReport.CONTACTtimes[1]=0;
    YReport.CONTACTtimes[2]=0;
    YReport.CONTACTtimes[3]=0;    
    YReport.CONTACTmoney[0]=0;
    YReport.CONTACTmoney[1]=0;
    YReport.CONTACTmoney[2]=0;
    YReport.CONTACTmoney[3]=0;
    YReport.UNCONTACTtimes[0]=0;
    YReport.UNCONTACTtimes[1]=0;
    YReport.UNCONTACTtimes[2]=0;
    YReport.UNCONTACTtimes[3]=0;    
    YReport.UNCONTACTmoney[0]=0;
    YReport.UNCONTACTmoney[1]=0;
    YReport.UNCONTACTmoney[2]=0;
    YReport.UNCONTACTmoney[3]=0;
  }   
  
  
  //���α�������(�ϴ����ص�ʱ��)
  I2C_ReadS_24C(MonthReport_Addr,buffer,3);
  for(i=0;i<3;i++)
  {
    MReport.TimeBCD[i]=buffer[i];
  }  
  I2C_ReadS_24C( MonthReport_COINAddr,buffer,8);
  MReport.COINtimes[0]=buffer[0];//4���ֽ��ܽ��״���
  MReport.COINtimes[1]=buffer[1];
  MReport.COINtimes[2]=buffer[2];
  MReport.COINtimes[3]=buffer[3];    
  MReport.COINmoney[0]=buffer[4];//4���ֽ��ܽ�� 
  MReport.COINmoney[1]=buffer[5];
  MReport.COINmoney[2]=buffer[6];
  MReport.COINmoney[3]=buffer[7];
  I2C_ReadS_24C( MonthReport_CONTACTAddr,buffer,8);    
  MReport.CONTACTtimes[0]=buffer[0];
  MReport.CONTACTtimes[1]=buffer[1];
  MReport.CONTACTtimes[2]=buffer[2];
  MReport.CONTACTtimes[3]=buffer[3];    
  MReport.CONTACTmoney[0]=buffer[4];
  MReport.CONTACTmoney[1]=buffer[5];
  MReport.CONTACTmoney[2]=buffer[6];
  MReport.CONTACTmoney[3]=buffer[7];
  I2C_ReadS_24C( MonthReport_UNCONTACTAddr,buffer,8); 
  MReport.UNCONTACTtimes[0]=buffer[0];
  MReport.UNCONTACTtimes[1]=buffer[1];
  MReport.UNCONTACTtimes[2]=buffer[2];
  MReport.UNCONTACTtimes[3]=buffer[3];    
  MReport.UNCONTACTmoney[0]=buffer[4];
  MReport.UNCONTACTmoney[1]=buffer[5];
  MReport.UNCONTACTmoney[2]=buffer[6];
  MReport.UNCONTACTmoney[3]=buffer[7];
     
 
  
}




/*��������*/
void save_report(u8 money,u8 type)
{
  u8  i;
  u8  current_time[3];  //����ǰ�ǣ��գ��£��꣩����
  u8  currenttimes[4]; //4���ֽڵĴ���
  u8  currentmoney[4]; //4���ֽڵ�Ǯ
  u8  buffer[16];
  u16 add_Day,add_Month,add_Year;
  u16 add_Day1,add_Year1;//add_Month1,
  u16 add_Day2,add_Year2;//add_Month2,
  u32 FDtimes,FDmoney; 
  
  
  //Ӳ������
  if(type==COINPAY)
  {
    add_Day=DayReport_COINAddr;
    add_Month=MonthReport_COINAddr;
    add_Year=YearReport_COINAddr;
    
    add_Day1=DayReport_CONTACTAddr; //ҲҪ�����
    //add_Month1=MonthReport_CONTACTAddr;
    add_Year1=YearReport_CONTACTAddr;
    
    add_Day2=DayReport_UNCONTACTAddr;
    //add_Month2=MonthReport_UNCONTACTAddr;
    add_Year2=YearReport_UNCONTACTAddr;
  }
  //�ܲ�ͨ����
  else if(type==CONTACTPAY)
  {    
    add_Day=DayReport_CONTACTAddr;
    add_Month=MonthReport_CONTACTAddr;
    add_Year=YearReport_CONTACTAddr;
    
    add_Day1=DayReport_COINAddr;
   // add_Month1=MonthReport_COINAddr;
    add_Year1=YearReport_COINAddr;
    
    add_Day2=DayReport_UNCONTACTAddr;
   // add_Month2=MonthReport_UNCONTACTAddr;
    add_Year2=YearReport_UNCONTACTAddr;
  } 
  //MIfare���� 
  else
  {    
    add_Day=DayReport_UNCONTACTAddr;
    add_Month=MonthReport_UNCONTACTAddr;
    add_Year=YearReport_UNCONTACTAddr;
    
    add_Day1=DayReport_COINAddr;
   // add_Month1=MonthReport_COINAddr;
    add_Year1=YearReport_COINAddr;
    
    add_Day2=DayReport_CONTACTAddr;
    //add_Month2=MonthReport_CONTACTAddr;
    add_Year2=YearReport_CONTACTAddr;
  }    
 //1�����ձ�������
  I2C_ReadS_24C(DayReport_Addr,buffer,3);
  current_time[0]=buffer[0]; //������
  current_time[1]=buffer[1];
  current_time[2]=buffer[2];
//1\�ж����Ƿ����time_BCD
  if((time_BCD[2]==current_time[2])&&(time_BCD[3]==current_time[1])&&(time_BCD[4]==current_time[0]))
  {
    I2C_ReadS_24C(add_Day,buffer,8);
    for(i=0;i<4;i++)
    {currenttimes[i]=buffer[i];}
    FDtimes=hcl(currenttimes,4);	 //�ϲ�4���ֽ��ܽ��״���
    for(i=0;i<4;i++)
    {currentmoney[i]=buffer[i+4];} 
    FDmoney=hcl(currentmoney,4);	 //�ϲ�4���ֽ��ܽ��
    FDtimes+=1;
    FDmoney+=money;    
  }  
  else  //�����
  {
    //���ҵ����֮ǰ����������ձ�������
    FDtimes=0;
    FDmoney=0;
    fll(FDtimes,currenttimes,4);
    fll(FDmoney,currentmoney,4);
    I2C_WriteS_24C(add_Day1,currenttimes,4);//д�����������ˢ�����ܲ�ͨ�����ݣ�
    I2C_WriteS_24C(add_Day1+4,currentmoney,4);
    I2C_WriteS_24C(add_Day2,currenttimes,4);//д����
    I2C_WriteS_24C(add_Day2+4,currentmoney,4);
    
    FDtimes=1; //�����ڿ�ʼ
    FDmoney=money;
    buffer[0]=time_BCD[4];//������ʱ��
    buffer[1]=time_BCD[3];
    buffer[2]=time_BCD[2];
    I2C_WriteS_24C(DayReport_Addr,buffer,3);     //д���� 
    
  }
  fll(FDtimes,currenttimes,4);
  fll(FDmoney,currentmoney,4);
  I2C_WriteS_24C(add_Day,currenttimes,4);//д���磨Ӳ�ұ�������д�룩
  I2C_WriteS_24C(add_Day+4,currentmoney,4);
  //2�������걨������
  I2C_ReadS_24C(YearReport_Addr,buffer,3);
  current_time[0]=buffer[0]; //������
  current_time[1]=buffer[1];
  current_time[2]=buffer[2];
  //2\�ж����Ƿ����
  if(time_BCD[4]==current_time[0]) 
  {
    I2C_ReadS_24C(add_Year,buffer,8);
    for(i=0;i<4;i++)
    {currenttimes[i]=buffer[i];}
    FDtimes=hcl(currenttimes,4);	 //�ϲ�4���ֽ��ܽ��״���
    for(i=0;i<4;i++)
    {currentmoney[i]=buffer[i+4];} 
    FDmoney=hcl(currentmoney,4);	 //�ϲ�4���ֽ��ܽ��
    FDtimes+=1;
    FDmoney+=money;      
  } 
  else
  {
    //���ҵ����֮ǰ����������ձ�������
    FDtimes=0;
    FDmoney=0;
    fll(FDtimes,currenttimes,4);
    fll(FDmoney,currentmoney,4);
    I2C_WriteS_24C(add_Year1,currenttimes,4);//д����
    I2C_WriteS_24C(add_Year1+4,currentmoney,4);
    I2C_WriteS_24C(add_Year2,currenttimes,4);//д����
    I2C_WriteS_24C(add_Year2+4,currentmoney,4);
    
    FDtimes=1;
    FDmoney=money;
    buffer[0]=time_BCD[4];//������ʱ��
    buffer[1]=time_BCD[3];
    buffer[2]=time_BCD[2];
    I2C_WriteS_24C(YearReport_Addr,buffer,3);     //д����    
  } 
  fll(FDtimes,currenttimes,4);
  fll(FDmoney,currentmoney,4);
  I2C_WriteS_24C(add_Year,currenttimes,4);//д����
  I2C_WriteS_24C(add_Year+4,currentmoney,4); 
  
  //3���ɵ��α�������(�ϴ����ص�ʱ��)
  I2C_ReadS_24C(MonthReport_Addr,buffer,3);
  current_time[0]=buffer[0]; //������
  current_time[1]=buffer[1];
  current_time[2]=buffer[2];
  
  if(current_time[0]==0)
  {
    buffer[0]=time_BCD[4];//������ʱ��
    buffer[1]=time_BCD[3];
    buffer[2]=time_BCD[2];
    I2C_WriteS_24C(MonthReport_Addr,buffer,3);     //д����   
  }   
  I2C_ReadS_24C(add_Month,buffer,8);
  for(i=0;i<4;i++)
  {currenttimes[i]=buffer[i];}
  FDtimes=hcl(currenttimes,4);	 //�ϲ�4���ֽ��ܽ��״���
  for(i=0;i<4;i++)
  {currentmoney[i]=buffer[i+4];} 
  FDmoney=hcl(currentmoney,4);	 //�ϲ�4���ֽ��ܽ��
  FDtimes+=1;
  FDmoney+=money; 
  fll(FDtimes,currenttimes,4);
  fll(FDmoney,currentmoney,4);
  I2C_WriteS_24C(add_Month,currenttimes,4);//д����
  I2C_WriteS_24C(add_Month+4,currentmoney,4);
} 
  

/*������α�������*/

void clear_MonthReport(void)
{
  u8 i;
  u8 buffer[16]; 
  
  buffer[0]=time_BCD[4];//������ʱ��
  buffer[1]=time_BCD[3];
  buffer[2]=time_BCD[2];
  I2C_WriteS_24C(MonthReport_Addr,buffer,3);     //д���� 
  
  for(i=0;i<16;i++)
  {buffer[i]=0;}   
  I2C_WriteS_24C(MonthReport_COINAddr,buffer,16); //��������ͽ��
  I2C_WriteS_24C(MonthReport_UNCONTACTAddr,buffer,8); 
    
}
  
//  //2\�ж����Ƿ����
//  if((time_BCD[3]==current_time[1])&&(time_BCD[4]==current_time[2])) 
//  {
//    I2C_ReadS_24C(add_Month,buffer,8);
//    for(i=0;i<4;i++)
//    {currenttimes[i]=buffer[i];}
//    FDtimes=hcl(currenttimes,4);	 //�ϲ�4���ֽ��ܽ��״���
//    for(i=0;i<4;i++)
//    {currentmoney[i]=buffer[i+4];} 
//    FDmoney=hcl(currentmoney,4);	 //�ϲ�4���ֽ��ܽ��
//    FDtimes+=1;
//    FDmoney+=money;      
//  } 
//  else
//  {
//    //���ҵ����֮ǰ����������ձ�������
//    FDtimes=0;
//    FDmoney=0;
//    fll(FDtimes,currenttimes,4);
//    fll(FDmoney,currentmoney,4);
//    I2C_WriteS_24C(add_Month1,currenttimes,4);//д����
//    I2C_WriteS_24C(add_Month1+4,currentmoney,4);
//    I2C_WriteS_24C(add_Month2,currenttimes,4);//д����
//    I2C_WriteS_24C(add_Month2+4,currentmoney,4);
//    
//    FDtimes=1;
//    FDmoney=money;
//    buffer[0]=time_BCD[3];    
//    I2C_WriteS_24C(MonthReport_Addr,buffer,1);     //д����         
//  } 
//  fll(FDtimes,currenttimes,4);
//  fll(FDmoney,currentmoney,4);
//  I2C_WriteS_24C(add_Month,currenttimes,4);//д����
//  I2C_WriteS_24C(add_Month+4,currentmoney,4);
  
  
  
  


