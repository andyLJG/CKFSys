/**
  ******************************************************************************
  * @file    FSMC/SRAM/fsmc_sram.c 
  * @author  MCD Application Team
  * @version V3.1.2
  * @date    09/28/2009
  * @brief   This file provides a set of functions needed to drive the 
  *          IS61WV51216BLL SRAM memory mounted on STM3210E-EVAL board.
  ********************************************************************* 
*                               ˵�� 
*sram�ͺ�:IS62WV51216BLL 
*���ӷ�ʽ:FSMC 
*��С:1M�ֽ�.512K * 16 
huangfeng
//  FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &p;
//  FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &p;        
//  FSMC_NORSRAMStructInit(&FSMC_NORSRAMInitStructure);
**********************************************************************/  
/* Includes ------------------------------------------------------------------*/ 
#include "fsmc_sram.h"
#include "stm32f10x_fsmc.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define Bank1_SRAM3_ADDR    ((uint32_t)0x68000000)
#define WRITE_READ_ADDR              0x8000	  
/**
  * @brief  Configures the FSMC and GPIOs to interface with the SRAM memory.
  *         This function must be called before any write/read operation
  *         on the SRAM.
  * @param  None 
  * @retval None
  */
void FSMC_SRAM_Init(void)
{
  FSMC_NORSRAMInitTypeDef  FSMC_NORSRAMInitStructure;
  FSMC_NORSRAMTimingInitTypeDef  p;
  GPIO_InitTypeDef GPIO_InitStructure; 
  
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, ENABLE);
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOG | RCC_APB2Periph_GPIOE |
                         RCC_APB2Periph_GPIOF, ENABLE);	
  
  FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &p;
  FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &p;        
  FSMC_NORSRAMStructInit(&FSMC_NORSRAMInitStructure);
  
  /*-- GPIO Configuration ------------------------------------------------------*/
  /* SRAM Data lines configuration */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_8 | GPIO_Pin_9 |
                                GPIO_Pin_10 | GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOD, &GPIO_InitStructure); 
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 |
                                GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | 
                                GPIO_Pin_15;
  GPIO_Init(GPIOE, &GPIO_InitStructure);
  
  /* SRAM Address lines configuration */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | 
                                GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_12 | GPIO_Pin_13 | 
                                GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_Init(GPIOF, &GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | 
                                GPIO_Pin_4 | GPIO_Pin_5;
  GPIO_Init(GPIOG, &GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13; 
  GPIO_Init(GPIOD, &GPIO_InitStructure);
   
  /* NOE and NWE configuration */  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 |GPIO_Pin_5;
  GPIO_Init(GPIOD, &GPIO_InitStructure);
  
  /* NE3 configuration */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10; 
  GPIO_Init(GPIOG, &GPIO_InitStructure);
  
  /* NBL0, NBL1 configuration */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1; 
  GPIO_Init(GPIOE, &GPIO_InitStructure);    
/*-- FSMC Configuration ---------------------huangfeng---------------------------------*/
  p.FSMC_AddressSetupTime = 0;			   //��ַ����ʱ��	//0
  p.FSMC_AddressHoldTime = 0;			  //��ַ����ʱ��
  p.FSMC_DataSetupTime = 2;				 //���ݽ���ʱ��	  //2
  p.FSMC_BusTurnAroundDuration = 0;		 //���߻ָ�ʱ��
  p.FSMC_CLKDivision = 0;				 //ʱ�ӷ�Ƶ
  p.FSMC_DataLatency = 0;				 //���ݱ���ʱ��
  p.FSMC_AccessMode = FSMC_AccessMode_A;

//     p.FSMC_AddressSetupTime = 2;                                        /*��ַ����ʱ������*/                                                                                         
//        p.FSMC_AddressHoldTime = 2;                                        /*��ַ�ĳ���ʱ��*/
//        p.FSMC_DataSetupTime = 10;                                        /*�趨����ʱ������*/
//        p.FSMC_BusTurnAroundDuration = 0;                        /*����ת��ʱ��*/
//        p.FSMC_CLKDivision = 1;                                                /*CLKʱ������źŵ�HCLK��������ʾʱ��???*/
//        p.FSMC_DataLatency = 0;                                                /*ָ���ڻ�õ�һ������ǰ��ʱ������*/
//        p.FSMC_AccessMode = FSMC_AccessMode_A;
  
  FSMC_NORSRAMInitStructure.FSMC_Bank = FSMC_Bank1_NORSRAM3;	 //SRAM��BANK1
  FSMC_NORSRAMInitStructure.FSMC_DataAddressMux = FSMC_DataAddressMux_Disable;	//���������ַ�߲�����
  FSMC_NORSRAMInitStructure.FSMC_MemoryType = FSMC_MemoryType_SRAM;			//�洢������SRAM
  FSMC_NORSRAMInitStructure.FSMC_MemoryDataWidth = FSMC_MemoryDataWidth_16b;   //���ݿ���Ϊ16λ
  FSMC_NORSRAMInitStructure.FSMC_BurstAccessMode = FSMC_BurstAccessMode_Disable;  //ʹ���첽дģʽ����ֹͻ��ģʽ
  FSMC_NORSRAMInitStructure.FSMC_WaitSignalPolarity = FSMC_WaitSignalPolarity_Low;//����Ա������ֻ��ͻ��ģʽ����Ч���ȴ��źż���Ϊ��
  FSMC_NORSRAMInitStructure.FSMC_WrapMode = FSMC_WrapMode_Disable;	   //��ֹ�Ƕ���ͻ��ģʽ
  FSMC_NORSRAMInitStructure.FSMC_WaitSignalActive = FSMC_WaitSignalActive_BeforeWaitState;	  //����Ա���ý���ͻ��ģʽ����Ч��NWAIT�ź���ʲôʱ�ڲ���
  FSMC_NORSRAMInitStructure.FSMC_WriteOperation = FSMC_WriteOperation_Enable; 	//дʹ��
  FSMC_NORSRAMInitStructure.FSMC_WaitSignal = FSMC_WaitSignal_Disable;	//����Ա������ֻ��ͻ��ģʽ����Ч������NWAIT�ź�
  FSMC_NORSRAMInitStructure.FSMC_ExtendedMode = FSMC_ExtendedMode_Disable;	//��ֹ��չģʽ����չģʽ����ʹ�ö����Ķ���дģʽ
  FSMC_NORSRAMInitStructure.FSMC_WriteBurst = FSMC_WriteBurst_Disable;	//��ֹͻ��д����
  FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &p;   //���ö�дʱ��
  FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &p;	  //����дʱ��

  FSMC_NORSRAMInit(&FSMC_NORSRAMInitStructure); 


  
  
  /* Enable FSMC Bank1_SRAM Bank */
  FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM3, ENABLE);  
}

///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
/**
  * @brief  Configures the FSMC and GPIOs to interface with the SRAM memory.
  *         This function must be called before any write/read operation
  *         on the SRAM.
  * @param  None 
  * @retval None
  */
void FSMC_SRAM_DISABLE(void)
{
  /* DISable FSMC Bank1_SRAM Bank */
  FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM3,DISABLE);  
}
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
/**
  *                           д�����ݰ� 
*����:pBuffer:����ָ�� 
*     WriteAddr:д�����ݵ�ַ 
*     NumHalfwordToWrite:���ݳ���,��λ����,��2�ֽ� 
*����:�� 
  */
void FSMC_SRAM_WriteBuffer16(uint16_t* pBuffer, uint32_t WriteAddr, uint32_t NumHalfwordToWrite)
{
  for(; NumHalfwordToWrite != 0; NumHalfwordToWrite--) /* while there is data to write */
  {
    /* Transfer data to the memory */
    *(uint16_t *) (Bank1_SRAM3_ADDR + WriteAddr) = *pBuffer++;
    
    /* Increment the address*/  
    WriteAddr += 2;
  }   
}

void FSMC_SRAM_WriteBuffer(uint8_t* pBuffer, uint32_t WriteAddr, uint32_t NumHalfwordToWrite)
{
   uint16_t yyyy;
  for(; NumHalfwordToWrite != 0; NumHalfwordToWrite--) /* while there is data to write */
  {
    /* Transfer data to the memory */
    yyyy=(*pBuffer<<8)+*(pBuffer+1);
//    *(uint16_t *) (Bank1_SRAM3_ADDR + WriteAddr) = *pBuffer++;
    *(uint16_t *)(Bank1_SRAM3_ADDR + WriteAddr) = yyyy;
    pBuffer+=2;   
    /* Increment the address*/  
    WriteAddr+=2;

/*    BOARD_SRAM->HalfWord[0] = 0x1111+WriteAddr;
    BOARD_SRAM->HalfWord[1] = 0x1111+WriteAddr+2; 
    BOARD_SRAM->HalfWord[2] = 0x1111+WriteAddr+4;    */
  }
}

/**
 *����:pBuffer:������ݵ�ָ�� 
*     ReadAddr:��ȡ���ݵ�ַ 
*     NumHalfwordToRead:��ȡ���ݳ���,��λ����,��2�ֽ� 
*����:�� 
  */
void FSMC_SRAM_ReadBuffer16(uint16_t* pBuffer, uint32_t ReadAddr, uint32_t NumHalfwordToRead)
{

  for(; NumHalfwordToRead != 0; NumHalfwordToRead--) /* while there is data to read */
  {
    /* Read a half-word from the memory */
    *pBuffer++ =*(__IO uint16_t*) (Bank1_SRAM3_ADDR + ReadAddr);    
    /* Increment the address*/  
    ReadAddr += 2;
  }  
}

void FSMC_SRAM_ReadBuffer(uint8_t* pBuffer, uint32_t ReadAddr, uint32_t NumHalfwordToRead)
{
  uint16_t yyyy;
  for(; NumHalfwordToRead != 0; NumHalfwordToRead--) /* while there is data to read */
  {
    /* Read a half-word from the memory */
    yyyy=*(__IO uint16_t*) (Bank1_SRAM3_ADDR + ReadAddr);
  //  *pBuffer++ =yyyy;
    *pBuffer=(yyyy>>8)&0xff;
    pBuffer++;
    *pBuffer=yyyy&0xff; 
    pBuffer++;    
    /* Increment the address*/  
    ReadAddr += 2;
  }  
}

