#ifndef _new_coin_H
#define _new_coin_H

#include "stm32f10x.h"
#include "delay_systick.h"
#include "stm32f10x_it.h"


//Ӳ�һ���Դ 
#define COIN_Power_ON       GPIO_SetBits(GPIOB, GPIO_Pin_9)
#define COIN_Power_OFF      GPIO_ResetBits(GPIOB, GPIO_Pin_9)

#define	COINHOSTADDR	0x01 
#define COINSLAVEADDR	0x02