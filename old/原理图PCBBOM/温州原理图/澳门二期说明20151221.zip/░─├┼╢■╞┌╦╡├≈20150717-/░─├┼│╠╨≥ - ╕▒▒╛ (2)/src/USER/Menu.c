#include "stm32f10x_it.h"
#include "delay_systick.h" 
#include "Hal.h"
#include "touch_key.h"
#include "I2C_Driver.h"
#include "spi_flash.h"
#include "ADC.h"
#include "LM240128C.h"  //����
#include "GPIO.h"
#include "mifare.h"
#include "MemoryAssign.h"
#include "fsmc_sram.h"
#include "MAIN.h"
#include "ir_comm.h"
#include "USART.h"
#include "St_wcdma.h"
#include "HW_check.h"  
#include "COIN.h" 
#include "blacklist.h"
#include "jiami.h"
#include "rate.h" 
#include "contact_card.h"  //�ܲ�ͨ
#include "save_record.h"
#include "report.h"
#include "IAP_Update.h"
#include "touch_key.h"
//#include "Menu.h"
#include "Menu.h"
#include "stm32f10x.h"
#include "rate.h"
#include "St_wcdma.h"
#define LCDCENTERDISP   		0xFE//��ʾ����
#define LCDRIGHTDISP   			0xFD//��ʾ�Ҷ���
#define LCDLEFTDISP   			0xFC//��ʾ�����

RxPOS_2_dot_4_G  RxPOSdot;  


u8 disp_MainMenu(void)
{
  u32 key_Count_1;
  u8 Disp_Count_0;
  u8 Key_Word_6[6];
  u8 Key_Put_Count_0;
 // u8 Key_Word_6_define[6]={0x01,0x02,0x03,0x04,0x05,0x06};
   u8 Key_Word_6_define[6]={0x01,0x02,0x03,0x04,0x01,0x02};
  Disp_Count_0=5;

 
               key_flag=0;
               Key_Put_Count_0=0;

                lcd_clear();	
		Disp_ChineseWord(3,10,"����");
		CT_fb_on_gb_off();
		Disp_EnglishStr(3,20,"6-");
            
		CT_fb_off_gb_off();
		Disp_ChineseWord(3,26,"λ����:");	
                
               
                
                   if(METERTYPE!=ELECTCARMETER)   
                     display_lastinfor(0,112,0x59); 
                
                while(Disp_Count_0--)
                {
                 key_Count_1=1000*5000+1;
          
                 Print_time(Disp_Count_0+1);
             	 while(key_Count_1--)
                {
                  if(key_flag) 
                  {
                  
                  KeyInfor.keyvalue=touchkey_return(1); 
                  //��ȡֵ 01 10
                   if((  KeyInfor.keyvalue>=KEY_1)&&(  KeyInfor.keyvalue<KEY_0))
                  {  
                     Key_Word_6[Key_Put_Count_0++]=KeyInfor.keyvalue;
                     key_flag=0;
                     CT_fb_on_gb_off();
	             Disp_EnglishStr(5,20+(Key_Put_Count_0)*3,"*");
           
                     //KeyInfor.keyvalue=0;
                     Disp_Count_0=5;
                     break;
                 } 
                 else if(  KeyInfor.keyvalue==KEY_X)
                  {   
                      return 2;
                  }
                else if(  KeyInfor.keyvalue==KEY_Lamp)
                  {   
                     // return 2;
                    LCD_back_ONOFF;
                  }else
                     if(  KeyInfor.keyvalue==KEY_Chinese)   
                     {
                          if(METERTYPE!=ELECTCARMETER) 
                                return 2;
                             
                     }
                               
                             

                  }
                  
                  if (Key_Put_Count_0==6)
                  {
                   Disp_Count_0=0;
                   break;
                  }
               
                
                }
         
                }//
                
                if(Key_Put_Count_0!=6)
                {
                   return 2;
                } 
                
                for(int i = 0; i < 6; ++i)
                {
                  if(Key_Word_6[i]!=Key_Word_6_define[i])
                  {
                   return 1;
                  }
                }
                 return 0;
                
                
            

}
void SetMaxHour(void)
{
  u32 key_Count_1;
  u8 Disp_Count_0;
  u8 fee_value[1];
  u8 MAXTIME=0;
     lcd_clear();	
     Disp_ChineseWord(3,10,"����");
     CT_fb_on_gb_off();
	Disp_EnglishStr(3,20,"1-");
  	CT_fb_off_gb_off();
     Disp_ChineseWord(3,26,"λ���ͣ��Сʱ��:");
     

                   if(METERTYPE!=ELECTCARMETER) 
                   {
                     display_lastinfor(0,112,0x5B); 
                     display_BCD(35,60,MAXTIME);
                   }
                    
        
     Disp_Count_0=5;
     while(Disp_Count_0--)
                {
                 key_Count_1=1000*5000+1;
          
                 Print_time(Disp_Count_0+1);
             	 while(key_Count_1--)
                {
                  if(key_flag) 
                  {
                  Disp_Count_0=5;
                  key_flag=0;   
                  KeyInfor.keyvalue=touchkey_return(1); 
                  //��ȡֵ 01 10
                   if((  KeyInfor.keyvalue>=KEY_1)&&(  KeyInfor.keyvalue<KEY_0))
                  {  
                 
                    
                     CT_fb_on_gb_off();
	             //Disp_EnglishStr(5,20+3,KeyInfor.keyvalue);
                    // Disp_EnglishStr(5,20+3,KeyInfor.keyvalue);
                   
                     
                      if(METERTYPE!=ELECTCARMETER)   
                      {
                         if((KeyInfor.keyvalue==KEY_1) ||(KeyInfor.keyvalue==KEY_2))
                         {
                         
                      
                        
                        if(KeyInfor.keyvalue==KEY_1) 
                        {
                          if (MAXTIME>=9)
                          {
                            
                          }
                          else
                          {    
                            MAXTIME= MAXTIME+1;
                          }
                   
                        }
                        else if(KeyInfor.keyvalue==KEY_2) 
                        {
                          
                            if (MAXTIME==0)
                          {
                            
                          }
                          else
                          {    
                            MAXTIME= MAXTIME-1;
                          }
                   
                        }
                        
                        display_BCD(35,60,MAXTIME);
                        fee_value[0]=MAXTIME; 
                        Write_SysFee(fee_value,1);  
                        CT_fb_off_gb_off(); 
                        Disp_ChineseWord(7,LCDCENTERDISP, "���óɹ�");     
                        
                      }
                    
                      }
                   
                      else
                      {
                        display_BCD(35,60,KeyInfor.keyvalue);
                        fee_value[0]=KeyInfor.keyvalue; 
                        Write_SysFee(fee_value,1);  
                        CT_fb_off_gb_off(); 
                        Disp_ChineseWord(7,LCDCENTERDISP, "���óɹ�");     
                        
                        
                      }
                     
                     
                         
                         break; 
          
                   //
                    
                   
                 } 
                 else if(  KeyInfor.keyvalue==KEY_X)
                  {  
                      Disp_Count_0=0;
                        break;
                  }
                else if(  KeyInfor.keyvalue==KEY_Lamp)
                  {   
                     
                    LCD_back_ONOFF;
                    
                  }else
                     if(  KeyInfor.keyvalue==KEY_Chinese)   
                     {
                                    if(METERTYPE!=ELECTCARMETER) 
                                    {
                                      Disp_Count_0=0;
                                      break; 
                                    }
                            
                             
                     }
                               
                             

                  }
                  
   
               
                
                }
         
                }//
     
     
     
     
           
     
                       

}
void SetFee(u8 order_para)
{ 
  u8 fee_value[3];
  
        lcd_clear();
        Disp_ChineseWord(3,LCDCENTERDISP, "���óɹ�");
        switch(order_para)
        {
        case 0x01:
          fee_value[0] =1;
          fee_value[1] =60;
          fee_value[2] =1;
           Disp_EnglishStr(5,30,fee_STR_1);
          break; 
        case 0x02:
          fee_value[0] =1;
          fee_value[1] =30;
          fee_value[2] =2;
            Disp_EnglishStr(5,30,fee_STR_2);
          break; 
       case 0x03:
          fee_value[0] =1;
          fee_value[1] =10;  
          fee_value[2] =3;
          Disp_EnglishStr(5,30,fee_STR_3);
          break; 
   
        }
        
       // 
        I2C_WriteS_24C(NET_FEE_PARA,fee_value,3);  
        delayms(30);
        Write_SysFee(fee_value,0); 
        delayms(30); 
         
        make_record_Alarm(FEESET_0,fee_value[2],0,0xa0); 
        delayms_keybreak(1200);  

        Read_SysFee();

}

u8 disp_FeeMenu(void)
{
  u32 key_Count_1;
  u8 Disp_Count_0;


  Disp_Count_0=5;

 

                
                while(Disp_Count_0--)
                {
                 key_Count_1=1000*5000+1;
          
                 Print_time(Disp_Count_0+1);
             	 while(key_Count_1--)
                {
                  if(key_flag) 
                  {
                  
                   KeyInfor.keyvalue=touchkey_return(1); 
                  
                   key_flag=0;
                  
                  
                            switch(KeyInfor.keyvalue)
                          {
                            case 0x01:
                                   SetFee(0x01);
                                    lcd_clear();
                                  disp_MainMenu_Fee();
                                 Disp_Count_0=5;
                             // return 2;
                              break;
                             case 0x02:
                              SetFee(0x02);
                                     lcd_clear();
                                  disp_MainMenu_Fee();
                                 Disp_Count_0=5;
                             // return 2;
                              break; 
                             case 0x03:
                               SetFee(0x03);
                               lcd_clear();
                                  disp_MainMenu_Fee();
                                 Disp_Count_0=5;
                               
                              // return 2;
                              break; 
                              
                               case 0x04:
                              //  SetFee(0x03);
                                 
                                 
                                 SetMaxHour();
                                    lcd_clear();
                                  disp_MainMenu_Fee();
                                 Disp_Count_0=5;
                                 
                              //  return 2;
                              break;      
       
                            case KEY_X:
                                return 1;
                                break;
                             case KEY_Chinese:
                               
                                 if(METERTYPE!=ELECTCARMETER) 
                                return 1;
                                break;  
                          default:
                            
                                 display_lastinfor(0,112,0x5A); 
                                 Disp_Count_0=5;
                             break; 
                             
                               

                  }
                  
                    
               
                
                }
         
                }//
                
 }

    return 0;

 
}
void disp_Menu(void)
{  
	lcd_clear();	
	//Refresh_SYSallicon();
	//Disp_SysTime(1,LCDCENTERDISP,TIME_B);	
	Disp_ChineseWord(1,LCDCENTERDISP,"ϵͳ����");
}

void disp_MenuFee(void)
{  

	Disp_ChineseWord(1,LCDCENTERDISP,"����ѡ��");
}
void disp_mainmenu1(void)
{  		
	//Disp_EnglishStr(3,0,"1.PDA");
	Disp_EnglishStr(2,0,"1.");
	Disp_ChineseWord(2,6,"��Ϣ��ѯ");
}
void disp_mainmenuFee1(void)
{  		

	Disp_EnglishStr(2,0,"1.");
         Disp_EnglishStr(2,6,fee_STR_1); 
}
void disp_mainmenuFee2(void)
{  		

	Disp_EnglishStr(3,0,"2.");
        Disp_EnglishStr(3,6,fee_STR_2);
}

void disp_mainmenuFee3(void)
{  	
	Disp_EnglishStr(4,0,"3.");
        Disp_EnglishStr(4,6,fee_STR_3);
}
void disp_mainmenuFee4(void)
{  	
	Disp_EnglishStr(5,0,"4.");
        Disp_ChineseWord(5,6,"���ͣ��Сʱ��");
}

void disp_mainmenu2(void)
{  		
	//Disp_EnglishStr(3,0,"1.PDA");
	Disp_EnglishStr(3,0,"2.");
        //Disp_EnglishStr(4,0,"PO");

	Disp_ChineseWord(3,6,"�ֳֻ�ͨ��");
}
void disp_mainmenu3(void)
{  	
	Disp_EnglishStr(4,0,"3.");
	Disp_ChineseWord(4,6,"ϵͳ����");
}
void disp_mainmenu4(void)
{  	
	Disp_EnglishStr(5,0,"4.");
	Disp_ChineseWord(5,6,"��������");
}
void disp_MainMenu_1(void)
{
	disp_Menu();
	//CT_fb_on_gb_off();
	disp_mainmenu1();
	//CT_fb_off_gb_off();
	disp_mainmenu2();
	disp_mainmenu3();
        disp_mainmenu4(); 
	
}
void disp_MainMenu_Fee(void)
{
  disp_MenuFee();
  disp_mainmenuFee1();
  disp_mainmenuFee2();
  disp_mainmenuFee3();
  disp_mainmenuFee4();
}
u8 Wait_2_dot_4(void)
{
     u32 key_Count_1;
     u8 Disp_Count_0;
     Disp_Count_0=5; 
     unsigned char buff[64];
       u8 data[16];  
       
     u8 resule_ack_l;
     
           if(METERTYPE!=ELECTCARMETER)   
                     display_lastinfor(0,112,0x59); 
     
             while(Disp_Count_0--)
                {
                 //key_Count_1=1000;
                 Print_time(Disp_Count_0+1);
                  IWDG_ReloadCounter();
                 key_Count_1=950;
             	 while(key_Count_1--)
                 {
                   
                       if(key_flag) 
                         {
                           key_flag=0;
                           KeyInfor.keyvalue=touchkey_return(1); 
                         
                          if( KeyInfor.keyvalue==KEY_X)
                           {
                             return 3;
                           }
                              if( KeyInfor.keyvalue==KEY_Chinese)
                           {     if(METERTYPE!=ELECTCARMETER)   
                             return 3;
                           }
                          
                          
                         }
                       
                        /* if(OK_flag_POS)
                          {   
                             OK_flag_POS=0;

                              return 1;
                         }*/
                       
                        resule_ack_l= rev_ack_new(buff);
                       if (resule_ack_l==0)
                       {
                       
                       }
                       else
                       {
                         
                         
                       //�յ����� buff
                        switch(resule_ack_l)
                        {   
                        
                        case 0xF0:
                          
                                 lcd_clear();	
                                  Disp_ChineseWord(4,LCDCENTERDISP,"��¼������"); 
                                 Buzz_0;
                                 delayms(20); 
                                 Buzz_1; 
                                // download(0);
                                 //download_new();
                                 UpRecordFlag=PART_FH_UP;
                                 if(download_new() == 0x01)
                                 {
                                    Disp_ChineseWord(4,LCDCENTERDISP,"��¼���سɹ�"); 
                                 }
                                 else
                                 {
                                      Disp_ChineseWord(4,LCDCENTERDISP,"��¼����ʧ��"); 
                                 }
                               
                             
                                  delayms(2500);
                                  Disp_Count_0=5;
                                  lcd_clear();	
                                  Disp_ChineseWord(4,LCDCENTERDISP,"ͨ����"); 
                                  break; 
                          case 0xF1:
                              // set_time_2();
                            
                                data[4]=buff[5];	  //��
                                data[3]=buff[6];	  //��
                                data[2]=buff[7];	  //��
                                data[1]=buff[8];	  //ʱ
                                data[0]=buff[9];	  //��				
                                data[6]=mathweek(buff[5],buff[6],buff[7]);	//��������
                     
                                 set_current_time(data);
                              //  set_time_2();
                                 judge_get_time();
                                 lcd_clear();	
                                 Buzz_0;
                                 delayms(20); 
                                 Buzz_1; 
                                 Disp_ChineseWord(4,LCDCENTERDISP,"ʱ�����óɹ�"); 
                                
                                
                                  delayms(2500);
                                  Disp_Count_0=5;
                                  lcd_clear();	
                                  Disp_ChineseWord(4,LCDCENTERDISP,"ͨ����");
                                  

                               break; 
                          case 0xF2:
                                 
                                data[0]=buff[5];	  //��
                                data[1]=buff[6];	  //��
                                data[2]=buff[7];	  //��
                                data[3]=buff[8];	  //ʱ
                               // data[4]=buff[11];
                               // data[5]=buff[12];
                                 set_current_MeterNo(data);
                                
                                 lcd_clear();	
                                 Buzz_0;
                                 delayms(20); 
                                 Buzz_1; 
                                // Disp_ChineseWord(3,LCDCENTERDISP,"ʱ�����óɹ�"); 
                               //   Disp_EnglishStr(3,LCDCENTERDISP,"IP");
                                  Disp_ChineseWord(4,LCDCENTERDISP,"�豸�����óɹ�"); 
                                
                                
                                  delayms(2500);
                                  Disp_Count_0=5;
                                  lcd_clear();	
                                  Disp_ChineseWord(4,LCDCENTERDISP,"ͨ����");  
                               break; 
                              case 0xF4:
                             //  IPCard_Process();//
                             
                                data[0]=buff[6];	  //��
                               // data[1]=buff[7];	  //��
                              //  data[2]=buff[8];	  //��
                               // data[3]=buff[9];	  //ʱ
                               // data[4]=buff[11];
                              //  data[5]=buff[12];
                      
                              //  RSTCard_ProcessOne(data[0]); 	
                              //  Init_FRecordAddr();
                                
                                 lcd_clear();	
                                 Buzz_0;
                                 delayms(20); 
                                 Buzz_1; 
                                // Disp_ChineseWord(3,LCDCENTERDISP,"ʱ�����óɹ�"); 
                               //   Disp_EnglishStr(3,LCDCENTERDISP,"IP");
                                  Disp_ChineseWord(4,LCDCENTERDISP,"��λ�ɹ�"); 
                                
                                
                                  delayms(2500);
                                  Disp_Count_0=5;
                                  lcd_clear();	
                                  Disp_ChineseWord(4,LCDCENTERDISP,"ͨ����");
                               break;        
                        case 0xF5:
                             //  IPCard_Process();//
                             
                                data[0]=buff[6];	  //��
                                data[1]=buff[7];	  //��
                                data[2]=buff[8];	  //��
                                data[3]=buff[9];	  //ʱ
                                data[4]=buff[11];
                                data[5]=buff[12];
                                set_current_IP(data);
                                
                                 lcd_clear();	
                                 Buzz_0;
                                 delayms(20); 
                                 Buzz_1; 
                                // Disp_ChineseWord(3,LCDCENTERDISP,"ʱ�����óɹ�"); 
                               //   Disp_EnglishStr(3,LCDCENTERDISP,"IP");
                                  Disp_ChineseWord(4,LCDCENTERDISP,"�������óɹ�"); 
                                
                                
                                  delayms(2500);
                                  Disp_Count_0=5;
                                  lcd_clear();	
                                  Disp_ChineseWord(4,LCDCENTERDISP,"ͨ����");
                               break;      
                            
                          default:
                          break;
                          
                        
                        
                        }
                   

                         
                       }
                       
     
                 
                 }
                }
             

       return 1;//��ʱ

	
}

void Update_RTC(u8 locs)
{/*
  
u8 timenew[7],timenewH[7],buffer[2],i,j,ckflag;
u32 tln,tlnold,subv;

	I2C_ReadS_24C(SYS_RTC,buffer,1);//ʱ��ʵʱ���¿��� 1-�� 0-��
	if(locs>30)//��¼ʱ�����ж�
		{
		if(buffer[0]==0)return;//δ����ʵʱ����
		}
	i = locs;
	for(j=0;j<5;j++)
		timenew[4-j] = (asic_to_hex(recv_3G[i+j*3])<<4)+asic_to_hex(recv_3G[i+j*3+1]);
	//time[4]-time[0]//YYMMDDHHMM
	ckflag = JD_TIMECK(timenew,1);
	if(ckflag==OK)
		{		
		for(i=0;i<6;i++)
			 timenewH[i] = BCDtoHex(timenew[i]);
		GetCurrentTime();
		if(timenewH[1]==0)
			tln = 24*60+timenewH[0];
		else
			tln = timenewH[1]*60+timenewH[0];
		if(time1[1]==0)
			tlnold = 24*60+time1[0];
		else
			tlnold = time1[1]*60+time1[0];
		if(tln>tlnold)
			subv = tln-tlnold;
		else
			subv = tlnold-tln;

		ckflag=0;
		if((timenew[4]!=time[4])||(timenew[3]!=time[3])||(timenew[2]!=time[2]))
			ckflag=1;		
		else if(subv>2)//����ʱ�� RTC
			ckflag=1;
		if(ckflag)
			set_current_time(timenew); 			
		}	
	return;*/
}
u8 Main_Menu_Enter(void)
{
  
  
  u32 key_Count_1;
  u8 Disp_Count_0;
  u8 Open_result,feeret;

 // u8 Key_Put_Count_0;

  Disp_Count_0=5;

 
               key_flag=0;
          //   Key_Put_Count_0=0;

                   
                disp_MainMenu_1();  
                if(METERTYPE!=ELECTCARMETER)   
                    display_lastinfor(0,112,0x59); 
                while(Disp_Count_0--)
                {
                   
                // key_Count_1=1000*3000+1;
                  key_Count_1=1000*10000+1;
                 Print_time(Disp_Count_0+1);
             	 while(key_Count_1--)
                {
                  if (key_Count_1==1000*10000) 
                  {
                    key_Count_1=key_Count_1-10000*50;
                    IWDG_ReloadCounter();
                  }
                  
                         if(key_flag) 
                         {
                          KeyInfor.keyvalue=touchkey_return(1); 
                           key_flag=0;
                          switch(KeyInfor.keyvalue)
                          {
                            case KEY_Lamp:
                           
                                LCD_back_ONOFF;
  
                                Disp_Count_0=5;  
                                disp_MainMenu_1(); 
                               break;
                            
                            case 0x01:
                                lcd_clear();

                                Inquire_MSG();
               
                               //  delayms(3000);
                                for(int i = 0; i < 5; i++)
                                {
                                   Print_time(5-i);
                                     delayms_keybreak(600);
                                      if(key_flag)
                                         break;
                                }
                                
                                key_flag=0;
                              
  
                               // InquireCard_Process(); 
                                Disp_Count_0=5;  
                                disp_MainMenu_1(); 
                               break;
                            case 0x02:
                              
                                lcd_clear();
                                Disp_ChineseWord(4,LCDCENTERDISP,"������");
                                Open_result=BT_CK();
                                lcd_clear();
                               if (Open_result==1)
                               {
                                 //��ʧ��
                                    Disp_ChineseWord(4,LCDCENTERDISP,"ͨ�Ź���");
                                    delayms(2500);
                                    Disp_Count_0=5;  
                                    lcd_clear();
                                  
                                    disp_MainMenu_1();     
                                  
                                  
                               }
                               else if (Open_result==0)
                               {//�ɹ�������ȴ�����
                                 
                                  Disp_ChineseWord(4,LCDCENTERDISP,"ͨ����");
                                 // USART_ITConfig(UART4, USART_IT_RXNE, ENABLE); 
                                  Open_result=Wait_2_dot_4();
                                  if(Open_result==2)  
                                  {//
                                      return 1;
                                      
                                 /*   irDA_Power_OFF;
                                    key_Count_1=1000*10000+1;
                                    lcd_clear();   
                                    disp_MainMenu_1();  
                                    if(METERTYPE!=ELECTCARMETER)   
                                     display_lastinfor(0,112,0x59); */
                                          
                                  }
                                  else   if(Open_result==1)  
                                  {
                                    //��ʱ
                                     Disp_Count_0=5;  
                                     disp_MainMenu_1();
                                     
                                  }
                                   else   if(Open_result==3)  
                                  {
                                    //��ʱ
                                    
                                    //�ص�
                                    
                                    
                                    //
                                    
                                   //  close_ir_comm();
                                    
                                    // open_ir_comm();
                                     Disp_Count_0=5;  
                                     disp_MainMenu_1();
                                     
                                  }
                               }
                                

                                
                            
                                break;
                           
                            case 0x03:
                            
                                hardWare_Check();
                                Disp_Count_0=5;  
                                disp_MainMenu_1(); 
                            break;
                            
                              case 0x04:
                            
                                lcd_clear();
                                disp_MainMenu_Fee();
                                feeret= disp_FeeMenu();
                               
                               switch(feeret)
                               {
                               case 0x00:
                                
                                 
                                 break; 
                               case 0x01:
                                 
                                 break;                              
                                 
                               default:
                                 break;
                                 
                               
                                 
                               }
                               
                                key_flag=0;
                         
                                  Disp_Count_0=5;  
                                     disp_MainMenu_1();
                               // Inquire_MSG();
                               // delayms(3000);
                               
                            break;
                            
                            case KEY_X:
                                return 1;
                                break;
                             case KEY_Chinese:
                               
                                 if(METERTYPE!=ELECTCARMETER) 
                                return 1;
                                break;     
                                
                            default:
                              
                                 display_lastinfor(0,112,0x52); 
                                 Disp_Count_0=5;
                               //  delayms(2500);
                             break;    
                         
                          }
                          

                         
                         
                         }
                  
                  
                  
                 
                }
         
                }//
                
                
   
    if  (Disp_Count_0==0xFF)           
    {
       return 1;
    }
    else
    {
       return 0;
    }
      


     

}

void Enter_MainMenu(void)//// 1 + 2 ȷ�� + ȷ��
{  
  u8 result_0,result_1;
  Mifare_Power_OFF;
   while(1) 
   {
       IWDG_ReloadCounter();
       result_0= disp_MainMenu();
       
      //result_0=0; 
       if (result_0==1)
       {//�������
        lcd_clear();	 
        Disp_ChineseWord(3,LCDCENTERDISP,"�������");
	Disp_ChineseWord(5,LCDCENTERDISP,"������");
        delayms(2500);
       
       }
       else   if (result_0==0)
       {
         //��������
         
          result_1=Main_Menu_Enter();
          if(result_1==1)
          {
            break;
          }
         
         
       }
       else   if (result_0==2)
       {
         //ȡ��
         break;
         
       }
       
 
   }

	
}

