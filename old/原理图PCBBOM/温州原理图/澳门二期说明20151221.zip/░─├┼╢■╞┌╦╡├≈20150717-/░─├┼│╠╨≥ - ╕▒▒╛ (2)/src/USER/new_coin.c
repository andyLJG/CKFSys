//uchar cctalk_tx_data[20]  ;	
//uchar cctalk_rx_data[30]  ;	
//
///*cctalkӲ�һ���������*/
//void sent_cctalk_data(uchar x)
//{	
//  USART_Putc(UART5,x);  //USART2   
//}
//
///*cctalkӲ�һ���ʱ*/
//void cctalk_delay(uint t)
//{	
//  while(--t);
//  return;  
//} 
//
////��������
//void tx_cctalk(unsigned char header,unsigned char len)
//{	
//  unsigned char i,j;
//  unsigned char k = 0;
//  //unsigned int timeout;
//  unsigned int cheak_sum = 0;	//��У��						
//  unsigned char cheak_result = 0;						
//  
//  u8 cctalk_data[20];
//  
//  cctalk_data[0] = COINSLAVEADDR;				
//  cctalk_data[1] = len;						
//  cctalk_data[2] = COINHOSTADDR;					
//  cctalk_data[3] = header;	
//  
//  cheak_sum
//  for(i = 0; i < len; i++)
//  {	
//    cctalk_data[i + 4] = cctalk_tx_data[i];
//  }
//  j=i+4;
//  for(k = 0; k < j; k++)
//  {
//    cheak_sum = cheak_sum + cctalk_data[k];
//  }
//  
//  cheak_result = 256 - (uchar)(cheak_sum - (cheak_sum / 256) * 256);
//  cctalk_data[i+4] = cheak_result;	
//  
//  for(k = 0;k < (i+5);k ++)
//  {
//    sent_cctalk_data(cctalk_data[k]);	
//  }
//  
//  return;
//}