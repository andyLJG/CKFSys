#ifndef  _AoMenTong_H
#define  _AoMenTong_H
#include "delay_systick.h" 

/*typedef struct 
{
  u8  RxBuffer_Card[120];
  u8  RXBCC_Card;
  u8  RxState_Card;
  u16 RxCounter_Card; 
} RxMifareCard; 

extern RxMifareCard  RxReadCard;      //���տ����ݵĸ���
*/
/*���������������*/
extern  u8 TimeSerial;
extern  u8  AMT_Consum_Data[160];
extern unsigned char AMT_init(void);	
extern unsigned char AMT_detect(u8 special)	;
extern unsigned char AMT_Precpay(u8 moneyarr[4],u8 timeseroal_0);
extern unsigned char AMT_pay(void);
extern unsigned char Save_AMT_Rc(u8 order);
extern unsigned char AMT_init_2(void);		


#endif