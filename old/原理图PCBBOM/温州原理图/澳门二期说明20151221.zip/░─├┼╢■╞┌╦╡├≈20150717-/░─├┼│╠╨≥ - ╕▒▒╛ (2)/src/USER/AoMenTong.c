#include "stm32f10x_it.h"
#include "touch_key.h"
#include "delay_systick.h" 
#include "I2C_Driver.h"	
#include "mifare.h"
#include "USART.h"
#include "jiami.h" //huangfeng 
#include "MemoryAssign.h" 
#include "LM240128C.h"  //����
#include "ir_comm.h"
#include "MAIN.h"
#include "spi_flash.h"
#include "ADC.h" 
#include "save_record.h"
#include "rate.h"
#include "coin.h"
#include "blacklist.h"
#include "contact_card.h"  //�ܲ�ͨ
#include "save_record.h"
#include "report.h"
#include "new_mifare.h"
#include "AoMenTong.h"
#include "save_record.h"   
 u8 TimeSerial=0;
//RxMifareCard  RxReadCard; 
  u8  AMT_Consum_Data[160];
//���Ͷ�������������
void AMT_TX(u8 num, u8 *command)
{ 
  u8 i;
  u8 BCC;
  
  SP3243_ON;
  
  //BCC=command[1];
  BCC=0xBA;
 
  USART_Putc(USART3, 0xBA); 
  //USART_Putc(USART3, command[1]); //����
  
  for(i=1;i<=num;i++)
  {  
    USART_Putc(USART3, command[i]);
    BCC^= command[i];  
  } 
  USART_Putc(USART3, BCC);
  
}


/*----------------------------------------------------------------------
����:    AMT_init()	(�¿���ʼ��)
����:    �Զ���ģ����г�ʼ��. 
input:   ��
output:  ״ֵ̬ 0-OK ,1- error
------------------------------------------------------------------------*/


unsigned char AMT_init(void)			  
{
  u8 command[10];  
  u32 timeout;

  /*����-------------��ʼ------------*/
  command[1]=0x09;  //����
  command[2]=0x10;			
  command[3]=0x01;
  
  command[4]=0x31;
  command[5]=0x32;     
  command[6]=0x33;
  command[7]=0x34;
  command[8]=0x35;
  command[9]=0x36;
  
  /*����-------------����------------*/ 
  RxReadCard.RXBCC_Card=0;
  
  
  
  
  RxReadCard.RxBuffer_Card[1]=0;
  RxReadCard.RxCounter_Card=0;   
  RxReadCard.RxState_Card =0; 

  RxCounter_Card=0;
  RxState_Card = 0;
  
   AMT_TX(command[1],command); 
  //timeout =TIMEOUT_1S;		  //��һ��ʱ���ڽ�����
  //2014-2-14
  //timeout =TIMEOUT_1S/2;		  //��һ��ʱ���ڽ�����
  // timeout =TIMEOUT_1S;	
  //6870673
    
  timeout =TIMEOUT_1S/4;	

  while(--timeout  )
  {
    //У��ֵ0x66�ɹ�
    if(RxReadCard.RxState_Card == 0x66)
    { 
      RxReadCard.RxState_Card = 0;
      if(RxReadCard.RxBuffer_Card[2] == 0x10)	   //������
      {        
      	     return 0;  		
      }      
      else  	
        return 1;       //ʧ�� 
    }
   else if(RxReadCard.RxState_Card == 0x55) 
     return 1;       //ʧ�� 
  }
  return 1;
  
} 
unsigned char AMT_init_2(void)			  
{
  u8 command[10];  
  u32 timeout;

  /*����-------------��ʼ------------*/
  command[1]=0x09;  //����
  command[2]=0x10;			
  command[3]=0x01;
  
  command[4]=0x31;
  command[5]=0x32;     
  command[6]=0x33;
  command[7]=0x34;
  command[8]=0x35;
  command[9]=0x36;
  
  /*����-------------����------------*/ 
  RxReadCard.RXBCC_Card=0;
  
  
  
  
  RxReadCard.RxBuffer_Card[1]=0;
  RxReadCard.RxCounter_Card=0;   
  RxReadCard.RxState_Card =0; 

  RxCounter_Card=0;
  RxState_Card = 0;
  
   AMT_TX(command[1],command); 
  //timeout =TIMEOUT_1S;		  //��һ��ʱ���ڽ�����
  //2014-2-14
  //timeout =TIMEOUT_1S/2;		  //��һ��ʱ���ڽ�����
  // timeout =TIMEOUT_1S;	
  //6870673
    
  //timeout =TIMEOUT_1S/4;	
  timeout=1;
  while(--timeout  )
  {
    //У��ֵ0x66�ɹ�
    if(RxReadCard.RxState_Card == 0x66)
    { 
      RxReadCard.RxState_Card = 0;
      if(RxReadCard.RxBuffer_Card[2] == 0x10)	   //������
      {        
      	     return 0;  		
      }      
      else  	
        return 1;       //ʧ�� 
    }
   else if(RxReadCard.RxState_Card == 0x55) 
     return 1;       //ʧ�� 
  }
  return 1;
  
} 
/*----------------------------------------------------------------------
����:    AMT_detect()	(Ѱ��)
����:    ����Ƿ��п�. 
input:   ��
output:  ״ֵ̬ 0-OK ,1- error
------------------------------------------------------------------------*/

unsigned char AMT_detect(u8 special)			  
{
  u8 command[3];  
  u32 timeout;
  /*����-------------��ʼ------------*/
  command[1]=0x02;  //����
  command[2]=0x20;			
  
  /*����-------------����------------*/ 
  RxReadCard.RXBCC_Card=0;
 
  RxReadCard.RxBuffer_Card[1]=0;//��ֵ
  RxReadCard.RxCounter_Card=0;   //������
  RxReadCard.RxState_Card =0; //������
  
  RxCounter_Card=0;
  RxState_Card = 0;
  //timeout =TIMEOUT_1S;		  //��һ��ʱ���ڽ�����
  //2014-2-14
  
   AMT_TX(command[1],command); 
   
 // timeout =TIMEOUT_1S/2;		  //��һ��ʱ���ڽ�����
    if(special==0)
  { 
    timeout =MTIMEOUT_1S;  //�ȴ�ʱ������  
  }
  else  if(special==1)
  {  
    //timeout =MTIMEOUT_1S/2;
     timeout =MTIMEOUT_1S;
  }
  else
  {   
    timeout=1;
  }
    
  while(--timeout  )
  {
    //У��ֵ0x66�ɹ�
    if(RxReadCard.RxState_Card == 0x66)
    { 
      RxReadCard.RxState_Card = 0;
      if(RxReadCard.RxBuffer_Card[2] == 0x20)	   //������
      { 
        
        return 0; 	
        
      }      
      else  	
        return 1;       //ʧ�� 
    }
   else if(RxReadCard.RxState_Card == 0x55) 
     return 1;       //ʧ�� 
  }
  return 1;
  
} 
/*----------------------------------------------------------------------
����:    AMT_Precpay()	(Ѱ��)
����:    Ԥ����. 
input:   ��
output:  ״ֵ̬ 0-OK ,1- error
------------------------------------------------------------------------*/

unsigned char AMT_Precpay(u8 moneyarr_1[4],u8 timeseroal_0)			  
{
  u8 command[22];  
  u32 timeout;
 // u8 datearr[4];
 // u8 timearr[3];
  
  //��õ�ǰʱ��
  judge_get_time();
     
  
  
  /*����-------------��ʼ------------*/
  command[1]=0x13;  //����
  command[2]=0x21;// ����
  //���
  command[3]=moneyarr_1[0];
  command[4]=moneyarr_1[1];
  command[5]=moneyarr_1[2];
  command[6]=moneyarr_1[3];
    //����
  /*command[7]=0x20;
  command[8]=0x15;
  command[9]=0x08;
  command[10]=0x15;
  //ʱ�� 
  command[11]=0x14;
  command[12]=0x46;
  command[13]=0x20;*/
  

  command[7]=0x20;
  command[8]=time_BCD[4];
  command[9]=time_BCD[3];
  command[10]=time_BCD[2];
  //ʱ�� 
  command[11]=time_BCD[1];
  command[12]=time_BCD[0];
 // command[13]=0x08;
 // command[13]=TimeSerial;
  command[13]=hex_to_bcd(timeseroal_0);
  
 // command[13]=time_BCD[5];//��
   if (StopBeginTime[0]==0)
   {
      StopBeginTime[0]=1;
      StopBeginTime[1]=command[8];
      StopBeginTime[2]=command[9];
      StopBeginTime[3]=command[10];
      StopBeginTime[4]=command[11];
      StopBeginTime[5]=command[12];
     
   }
   
  
  
  command[14]=0x88;
  command[15]=0x88;

  command[16]=0x99;
  command[17]=0x99;
  
 // command[18]=0x77;
 // command[19]=0x77;
  //2015-10-29 edit
  command[18]=0x88;
  command[19]=0x88;  

  if (TimeSerial>=60)
  {
   TimeSerial=TimeSerial%60;
   TimeSerial=TimeSerial+1;
  }
  
  /*����-------------����------------*/ 
  RxReadCard.RXBCC_Card=0;
  
  AMT_TX(command[1],command);
    
  RxReadCard.RxBuffer_Card[1]=0;
  RxReadCard.RxCounter_Card=0;   
  RxReadCard.RxState_Card =0; 
  
  RxCounter_Card=0;
  RxState_Card = 0;
  //timeout =TIMEOUT_1S;		  //��һ��ʱ���ڽ�����
  //2014-2-14
  timeout =TIMEOUT_1S/2;	
  //��һ��ʱ���ڽ�����
//  timeout =TIMEOUT_1S/64;	
  while(--timeout  )
  {
    //У��ֵ0x66�ɹ�


    if(RxReadCard.RxState_Card == 0x66)
    { 
      RxReadCard.RxState_Card = 0;
      if(RxReadCard.RxBuffer_Card[2] == 0x21)	   //������
      { 
        
        return 0;

      }      
      else  	
        return 1;       //ʧ�� 
    }
   else if(RxReadCard.RxState_Card == 0x55) 
     return 1;       //ʧ�� 
  }
  return 1;
  
} 

/*----------------------------------------------------------------------
����:    AMT_pay()	(Ѱ��)
����:    ����. 
input:   ��
output:  ״ֵ̬ 0-OK ,1- error
------------------------------------------------------------------------*/

unsigned char AMT_pay(void)			  

{
  u8 command[3];  
  u32 timeout;

  /*����-------------��ʼ------------*/
  command[1]=0x02;  //����
  command[2]=0x22;			

  
  /*����-------------����------------*/ 
  RxReadCard.RXBCC_Card=0;
  
  AMT_TX(command[1],command);
  
  
  RxReadCard.RxBuffer_Card[1]=0;
  RxReadCard.RxCounter_Card=0;   
  RxReadCard.RxState_Card =0; 
  
  RxCounter_Card=0;
  RxState_Card = 0;
  //timeout =TIMEOUT_1S;		  //��һ��ʱ���ڽ�����
  //2014-2-14
  //timeout =TIMEOUT_1S*2;		  //��һ��ʱ���ڽ�����
    timeout =TIMEOUT_1S/2;	
  while(--timeout  )
  {
    //У��ֵ0x66�ɹ�
    if(RxReadCard.RxState_Card == 0x66)
    { 
      RxReadCard.RxState_Card = 0;
      if(RxReadCard.RxBuffer_Card[2] == 0x22)	   //������
      { 
        
        return 0; 	
        
      }      
      else  	
        return 1;      
    }
   else if(RxReadCard.RxState_Card == 0x55) 
     return 1;      
  }
  return 1;
  
} 
void AMT_pay_MAC(void)	
{
    u8  MAC_Data[190];
    int i,site=0;
    u32 str0;

    u8 you_hui=0x00;
    u8 ji_fen=0x00; 
    
    for(int i = 0; i < 190; i++)
   {
      MAC_Data[i]=0xDD; 
   }
      
    
    
    
   MAC_Data[0]=0x01;
   MAC_Data[1]=0x06;
   
  /* MAC_Data[2]=(string_ID>>8)&0xFF;
   MAC_Data[3]=(string_ID>>4)&0xFF;
   MAC_Data[4]=string_ID&0xFF; */

   


   fll_BCD(string_ID,MAC_Data+2,3);
   string_ID++;
   if(string_ID>999999) 
     string_ID=1;
   
  // string_ID=(string_ID+1)%1000000 ;
   
   
   
   
   site=161;
   MAC_Data[5]=AMT_Consum_Data[(site-1)/2];
   site=site+2;
   MAC_Data[6]=AMT_Consum_Data[(site-1)/2];
   site=165;
   MAC_Data[7]=AMT_Consum_Data[(site-1)/2];
   site=site+2;
   MAC_Data[8]=AMT_Consum_Data[(site-1)/2]; 
   
   
   /*for( i = 0; i < 4; i++)
   {
       MAC_Data[9+i]=0x00;
   }
   site=169;
   MAC_Data[13]=AMT_Consum_Data[(site-1)/2];*/
 
   
   for( i = 0; i < 5; i++)
   {
       MAC_Data[9+i]=  AMT_Consum_Data[102+i];
   }
   
   
   
     MAC_Data[14]=0x00;
     MAC_Data[15]=0x01;
     
     
       MAC_Data[14]=0x00;
     MAC_Data[15]=0x01;  
   
     site=13;
     for( i = 0; i < 4; i++)
     {
  
       MAC_Data[16+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     }
     
      
    
     //����
 /*site=5;
 
     for( i = 0; i < 4; i++)
     {
  
       MAC_Data[20+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     }  */
     
       for( i = 0; i < 4; i++)
       {
          MAC_Data[20+i]=   AMT_Consum_Data[91+i];  
       }
     
     
     
     site=113;
     for( i = 0; i < 4; i++)
     {
  
       MAC_Data[24+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     } 
     
       site=21;
      MAC_Data[28]=AMT_Consum_Data[(site-1)/2]; 
      
     //������ 
     site=23;
     MAC_Data[29]=0x00;
     for( i = 0; i < 2; i++)
     {
       MAC_Data[30+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     }  
      str0=hcl(MAC_Data+30,2);
      fll_BCD(str0,MAC_Data+30,2);
      
      
      
     
      site=27;
      MAC_Data[32]=AMT_Consum_Data[(site-1)/2];   
      
      
      site=41;
      site=site+2; 
     for( i = 0; i < 3; i++)
     {
       MAC_Data[33+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     }  
      str0=hcl(MAC_Data+33,3);
      fll_BCD(str0,MAC_Data+33,3);
     
     
       site=171;
       site=site+2; 
     for( i = 0; i < 3; i++)
     {
       MAC_Data[36+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     } 
     

       
       site=171;
       site=site+2; 
     for( i = 0; i < 3; i++)
     {
       MAC_Data[39+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     } 
      str0=hcl(MAC_Data+39,3);
      fll_BCD(str0,MAC_Data+39,3);
      
      

     for( i = 0; i < 3; i++)
     {
       MAC_Data[42+i]=(you_hui>>((2-i)*4)); 
     } 
     
     
     
      for( i = 0; i < 3; i++)
     {
       MAC_Data[45+i]=(ji_fen>>((2-i)*4)); 
     } 
      
     
      site=51;
     for( i = 0; i < 7; i++)
     {
       MAC_Data[48+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     } 
     
        site=49;
        MAC_Data[55]=AMT_Consum_Data[(site-1)/2];  
        
       
      site=65;
     for( i = 0; i < 7; i++)
     {
       MAC_Data[56+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     }  
     

      site=79+2;
     for( i = 0; i < 3; i++)
     {
       MAC_Data[63+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     } 
        str0=hcl(MAC_Data+63,3);
       fll_BCD(str0,MAC_Data+63,3);
     
     
      site=87+2;
     for( i = 0; i < 3; i++)
     {
       MAC_Data[66+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     }    
     
     
     
        site=95;
     MAC_Data[69]=AMT_Consum_Data[(site-1)/2];  
     
     
     
         site=97;
     for( i = 0; i < 2; i++)
     {
       MAC_Data[70+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     } 
     
       
         site=101;
     for( i = 0; i < 4; i++)
     {
       MAC_Data[72+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     }    
     
     
     
     //
     
     
       site=109;
      MAC_Data[76] =0x00;
      
      
     for( i = 0; i < 2; i++)
     {
       MAC_Data[77+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     }    
       str0=hcl(MAC_Data+77,2);
       fll_BCD(str0,MAC_Data+77,2);
     
      
     site=161;
     for( i = 0; i < 2; i++)
     {
       MAC_Data[79+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     }    
      //����
      for( i = 0; i < 7; i++)
     {
       MAC_Data[81+i]=0x00; 
       site=site+2;
     } 
     
     //76 --
     
     
       site=76;
      for( i = 0; i < 11 ; i++)
     {
         MAC_Data[site+i]=  (MAC_Data[site+i]<<4)|MAC_Data[site+1+i]>>4; 
     }  
     
     MAC_Data[87]=0xCC;
     
     
     
     
     
     
     ///
       u8  shoukuan_fangshi=0x00;
       MAC_Data[88]=shoukuan_fangshi; 
     
       u8  jiazhi_leixing=0x11;
       MAC_Data[89]=jiazhi_leixing; 
       
           
      site=29;
     for( i = 0; i < 5; i++)
     {
       MAC_Data[90+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     } 
      
        site=39;
     MAC_Data[95]=AMT_Consum_Data[(site-1)/2]; 
     
     
     
     
     //��λ
     

       str0=hcl(AMT_Consum_Data+((41-1)/2),4)-hcl(AMT_Consum_Data+((171-1)/2),4);

       fll_BCD(str0,MAC_Data+96,4);
       
 
       
      site=109;
     for( i = 0; i < 2; i++)
     {
       MAC_Data[100+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     }    

      str0=hcl(MAC_Data+100,2);
      fll_BCD(str0,MAC_Data+100,2);
     
          
        site=179;
     
     if (AMT_Consum_Data[(site-1)/2]==0x02)

       MAC_Data[102]=0x06;
     else 
             MAC_Data[102]=0x00;
     
     
     
      site=121;
     for( i = 0; i < 6; i++)
     {
       MAC_Data[103+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     } 
     
     
     
       u8  update_OK=0x01;
       MAC_Data[109]=update_OK; 
          
          
       site=121;
     for( i = 0; i < 9; i++)
     {
       MAC_Data[110+i]=0x00; 
       site=site+2;
     } 
     
     
      MAC_Data[119]=0x00; 
     //TAC
     site=153;
     for( i = 0; i < 4; i++)
     {
       MAC_Data[120+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     }  
     
     //MAC
     
    //������������
     
    
     
      for( i = 0; i < 124-87 ; i++)
     {
         MAC_Data[87+i]= MAC_Data[87+1+i] ; 
     }  
     

     
     //�������ϲ���������д��� 
     
     
     //     site=23;
    /* MAC_Data[29]=0x00;
     for( i = 0; i < 2; i++)
     {
       MAC_Data[30+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     }  
      str0=hcl(MAC_Data+30,2);
      fll_BCD(str0,MAC_Data+30,2);*/
 
     
     
     
      site=29;
      for(int i = 0; i < 123-site ; i++)
     {
         MAC_Data[site+i]=  (MAC_Data[site+i]<<4)|MAC_Data[site+1+i]>>4; 
     } 
        
      MAC_Data[122]=MAC_Data[122]&0xF0;
     
     
      
     
   /*   u8  MAC_Data_0[160] ;
     
      Save_FlashRecord(MAC_Data,CPURecord); 
     
     for(int i = 0; i <30 ; i++)
     {
           MAC_Data_0[i] = MAC_Data[112+i];
      
     }
     delayms(10);
     Save_FlashRecord(MAC_Data_0,CPURecord); 
     
     */
     
   // make_Stope_record_2(Consume_OP,AOT_Record,BuyTime_Record,space_HEX);
  //����tac 
 

  u8  command[160];
  u32 timeout;
  char count_0=3;
 // u8  Mac [4];
  //
       //command[1]=125+4+1;
       command[1]=123+4+1+1;
       command[2]=0x12;
       
       
       for( i = 0; i < 4; i++)
       {
          command[3+i]=   AMT_Consum_Data[91+i];  
       }
       
     /*  command[3]=0x12;   
       command[4]=0x12;         
       command[5]=0x12;  
       command[6]=0x12; */        
       
      // for( i = 0; i <125; ++i)
        for( i = 0; i <123; ++i)  
       {
         command[7+i]=MAC_Data[i];
       } 
       command[123+7]=0xAA;
       
       
    /*
      u8  MAC_Data_0[160] ;
     
      Save_FlashRecord(command,CPURecord); 
     
     for(int i = 0; i <40; i++)
     {
           MAC_Data_0[i] = command[112+i];
     }
   //   MAC_Data_0[i]=0xAA; 
     delayms(10);
     Save_FlashRecord(MAC_Data_0,CPURecord); 
     
     */
       
      for( i = 0; i < 4; i++)
     {
       
       AMT_Consum_Data[95+i]=0x00;
       
     }     
       
       //
       
   while(count_0--)    
   {
 
 
     
  
  RxReadCard.RXBCC_Card=0;
  RxReadCard.RxBuffer_Card[1]=0;
  RxReadCard.RxCounter_Card=0;   
  RxReadCard.RxState_Card =0; 

  RxCounter_Card=0;
  RxState_Card = 0;
  
  AMT_TX(command[1],command); 
  timeout =TIMEOUT_1S/4;	
  while(--timeout  )
  {
    //У��ֵ0x66�ɹ�
    if(RxReadCard.RxState_Card == 0x66)
    { 
      RxReadCard.RxState_Card = 0;
      if(RxReadCard.RxBuffer_Card[2] == 0x12)	   //������
      {  //

        for(int i = 0; i < 4; i++)
        {
          // Mac[i]=RxReadCard.RxBuffer_Card[4+i];
           AMT_Consum_Data[95+i]=RxReadCard.RxBuffer_Card[4+i];
        }
        
        count_0=0;
        break;
            
        
      }      

    }     //ʧ�� 
  }

    }
        
         ///**/
    //
        for( i = 0; i < 3; i++)
        {
              AMT_Consum_Data[99+i]=MAC_Data[2+i];
        }
   
   
}





unsigned char Save_AMT_Rc(u8 order)
{char i;

if (order==0x00)
{

//for(i=0;i<71;i++)
for(i=0;i<76;i++)
{
AMT_Consum_Data[i]=RxReadCard.RxBuffer_Card[i+4];

}

}
else if(order==0x01)
{
for(i=0;i<4;i++)
{
//AMT_Consum_Data[71+i]=RxReadCard.RxBuffer_Card[i+4];
AMT_Consum_Data[76+i]=RxReadCard.RxBuffer_Card[i+4];

}

AMT_Consum_Data[80]=0x99;
AMT_Consum_Data[81]=0x99;
/*
AMT_Consum_Data[82]=0x77;
AMT_Consum_Data[83]=0x77;*/
//
AMT_Consum_Data[82]=0x88;
AMT_Consum_Data[83]=0x88;

AMT_Consum_Data[84]=0x01;


         AMT_Consum_Data[85]=(FeeVlue>>24)&0xFF;
         AMT_Consum_Data[86]=(FeeVlue>>16)&0xFF;
         AMT_Consum_Data[87]=(FeeVlue>>8)&0xFF;
         AMT_Consum_Data[88]=(FeeVlue)&0xFF;
         
         AMT_Consum_Data[89]=AMT_card_type;
         AMT_Consum_Data[90]=FeeVlue_atm_times;
         
         
             
         AMT_Consum_Data[91]=CardInfor.cardNO[0];
         AMT_Consum_Data[92]=CardInfor.cardNO[1];     
         AMT_Consum_Data[93]=CardInfor.cardNO[2];
         AMT_Consum_Data[94]=CardInfor.cardNO[3]; 
         
         for(int i = 0; i < 4; i++)
         {
            AMT_Consum_Data[2+i]=CardInfor.cardNO[i];
         }
         
        // MAC
         
         
         //������ˮ�� 3
         
         //PASM��4  
         /*
       site=121 ;  
       for( i = 0; i < 6; i++)
     {
       MAC_Data[103+i]=AMT_Consum_Data[(site-1)/2]; 
       site=site+2;
     } */
         for(int i = 0; i < 5; i++)
         {
                AMT_Consum_Data[102+i]=AMT_Consum_Data[61+i];    
         }
         
           
    
         
     //���ݴ��
     //����mac 
      AMT_pay_MAC();
       
  
         


}

    return 1;   
}




