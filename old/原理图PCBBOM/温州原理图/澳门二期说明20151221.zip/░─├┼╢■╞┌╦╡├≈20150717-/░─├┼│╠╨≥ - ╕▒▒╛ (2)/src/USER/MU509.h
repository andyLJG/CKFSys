#ifndef	_MU509_H
#define	_MU509_H

#include "stm32f10x_it.h"
//����ģ���ϵ�
#define TERMON_3G_1   GPIO_SetBits(GPIOA, GPIO_Pin_11)  
#define TERMON_3G_0   GPIO_ResetBits(GPIOA, GPIO_Pin_11)
//���߽�
#define SLEEP_3G_1    GPIO_SetBits(GPIOA, GPIO_Pin_12)
#define SLEEP_3G_0    GPIO_ResetBits(GPIOA, GPIO_Pin_12) 
////��λ�ţ�û���õ���
//#define RESET_3G_1    GPIO_SetBits(GPIOB, GPIO_Pin_12)
//#define RESET_3G_0    GPIO_ResetBits(GPIOB, GPIO_Pin_12)

#define DOUBLEDISPALY3GON   1
#define DOUBLEDISPALY3GOFF   0
#define AUTOREPORT3GON      1
#define AUTOREPORT3GOFF     0
#define CFUN3GON      1
#define CFUN3GOFF     0
//3Gģ����Ͽ�����
#define ERROR3GSTART  1
#define ERROR3GSIM    2
#define ERROR3GCREG   3
#define ERROR3GPASSWORD   4
#define ERROR3GLINK   5
#define KEYOP_RETURN 0X10

//3Gģ��״̬
#define  UNKNOWN           0    /*GPRS�嵱ǰ״̬----δ֪״̬*/
#define  RW_OK             1    /*GPRS�嵱ǰ״̬----GPRSģ��ɶ�д*/
#define  RegGprs_OK        2    /*GPRS�嵱ǰ״̬----ע��gprs���ɹ�*/
#define  TCPLink_OK        3    /*GPRS�嵱ǰ״̬----TCPLink�ɹ�*/


//���������Ϣ
typedef struct
{
  //3Gģ�����---start----------------
  u8 gsmstatus;   //״̬
  //����
  u8 esflag;//���յ�����
  u8 s_head;	
  u8 s_tail;  
  
  //3Gģ�����---end----------------      
}G3Information; 

extern G3Information  G3Module; 

extern u8 gg_3G;
extern u8 RxBuffer_3G[GSML];

//AT����
extern u8 ATE_G3(u8 onoff) ;
extern u8 ATI_G3(void);
extern u8 CPIN_G3(void);
extern u8 CSQ_G3(void) ;
extern u8 CREG_G3(void);
extern u8 USERPASSWORD_G3(void);
extern u8 TCPLink_G3(u8 linkflag);
extern u8 InquireLink_G3(void); 
extern u8 TCPCLOSE_G3(u8 linkflag);
extern u8 CURC_G3(u8 open);
extern u8 CFUN_G3(u8 open);
extern u8 DataSend_G3(u8 *str); 
extern u8 ReadGsmString_AMT(u16 timeout);
//3Gģ�����
extern void EmptyRcv3G(void);
extern void send_string_ATCMD(u8 *rt);
extern u8 ReadGsmString(u16 timeout);
extern u8 MU509link_net(void);
extern u8 TCPLink_G3_0(u8 linkflag)  ;
#endif
