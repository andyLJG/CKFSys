#ifndef	    _IAP_Update_H
#define	    _IAP_Update_H


extern void Initial_UpdateAddr(void);
extern void IAPUpdate_Mechanism(u8 *min);

#endif