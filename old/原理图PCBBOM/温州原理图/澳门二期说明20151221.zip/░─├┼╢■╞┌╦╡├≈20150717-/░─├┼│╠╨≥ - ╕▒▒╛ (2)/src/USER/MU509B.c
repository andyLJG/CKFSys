//Ӳ���汾��CDMA����06-11-06.PCB
//Ӳ���ص㣺����RAM���������ÿ�����gprs���
#include "stm32f10x_it.h"
#include "delay_systick.h" 
#include "Hal.h"
#include "touch_key.h"
#include "I2C_Driver.h"
#include "spi_flash.h"
#include "ADC.h"
#include "LM240128C.h"  //����
#include "GPIO.h"
#include "mifare.h"
#include "MemoryAssign.h"
#include "fsmc_sram.h"
#include "MAIN.h"
#include "ir_comm.h"
#include "USART.h"
#include "St_wcdma.h"
#include "HW_check.h"  
#include "COIN.h" 
#include "blacklist.h"
#include "jiami.h"
#include "rate.h" 
#include "contact_card.h"  //�ܲ�ͨ
#include "save_record.h"
#include "report.h"
#include "IAP_Update.h"
#include "stm32f10x_conf.h"
#include "MemoryAssign.h"
#include <string.h>
#include <stdlib.h>
#include "MU509.h"
#include "I2C_Driver.h"



//�������MU509B--huangfeng--------20150526----------------------
u8 gg_3G;
u8 R3Gp;
u8 RxBuffer_3G[GSML];





/***�����3G����********/
void EmptyRcv3G(void)   //
{     
  do
  {   
    esflag_3G=0;  
    delay_ms(5); //5ms��ʱ
  } while(esflag_3G);
  s_head_3G=0;
  s_tail_3G=0;
  //����
   recv_3G[0] = 0; 
   RxBuffer_3G[0]=0;
   RxBuffer_3G[1]=0;
}

/**********************************************************
***********��G3ģ���Ƿ������ݷ��͹���*********************
***********************************************************/
u8 Read3GChar(void)   //�˺����ж��Ƿ������ݴ�����
{       
  
  u16 s_tailc; 
  //  do
  //  {   
  esflag_3G=0;	
  s_tailc=s_tail_3G;      
  if(s_tailc==s_head_3G)
  {   
    if(esflag_3G==0) 
    {
      s_tail_3G=s_tailc; 
      return 0;
    }  
  }
  gg_3G=recv_3G[s_tailc];
  s_tailc++;
  if(s_tailc==GSML)  
    s_tailc=0;          
  //  }while(esflag_3G);
  s_tail_3G=s_tailc; 
  return 1;
}

u8 ReadGsmString_AMT(u16 timeout) 
{   
  
  RxCounter_3G=0;  
  
  while(--timeout)
  {  
    if(Read3GChar())
    {   
      esflag_3G=1;
      RxBuffer_3G[RxCounter_3G]=gg_3G;
      if(RxCounter_3G<(GSML-1))        
      {  
        RxCounter_3G++;
        
       /* if(gg_3G==0x0a)  
          break;
        */
        if(gg_3G==0x0A) 
        {
          if(RxCounter_3G>5)
          {
        
           if((RxBuffer_3G[RxCounter_3G-3]==0x0D)&&
            (RxBuffer_3G[RxCounter_3G-2]==0x0A)&&  
            (RxBuffer_3G[RxCounter_3G-1]==0x0D)) 
           {
             break;
           }
          }
        
        }
      }
    }
    else
    {   
      delayms_keybreak(50);  //500          
    }
    if(key_flag)      
      return 2;
  }
  
  RxBuffer_3G[RxCounter_3G]=0;
  if(RxCounter_3G)
    return 0;
  else
    return 1;
}

u8 ReadGsmString(u16 timeout) 
{   
  
  
   while(--timeout)
   {
   if(OK_flag_3G)
   {   
     OK_flag_3G=0;
     RxBuffer_3G[0]='O';
     RxBuffer_3G[1]='K';
     return 1;
   }
    delayms_keybreak(1); 
    if(key_flag)
      return 0;

   }
    return 0;
/*  RxCounter_3G=0;  
  
  while(--timeout)
  {  
    if(Read3GChar())
    {   
      esflag_3G=1; 
      RxBuffer_3G[RxCounter_3G]=gg_3G;
      if(RxCounter_3G<(GSML-1))        
      {  
        RxCounter_3G++;
        
        if(gg_3G==0x0a)  
          break;//
        
      }
    }
    else
    {   
      delayms_keybreak(50);  //500          
    }
    if(key_flag)      
      return 2;
  }
  
  RxBuffer_3G[RxCounter_3G]=0;
  if(RxCounter_3G)
    return 0;
  else
    return 1;
  */
  
}



/*------------------------------------------------------------------------------------------------------------*/
void send_string_ATCMD(u8 *rt)     //����ATָ���
{  
  send_string_3G(rt);
  USART_Putc(USART1,0x0d);//�س�����
  USART_Putc(USART1,0x0a);
}



//MU509�������
/********�򿪻��߹رջ���************/
u8 ATE_G3(u8 onoff)    
{    
  u8 flag;
  char j=0;
  u32 timeout;
  
  do
  {
    IWDG_ReloadCounter();
    EmptyRcv3G();
    if(onoff==DOUBLEDISPALY3GON)
    //  send_string_ATCMD("ATE1");
        send_string_ATCMD("ATE1");
    else 
      send_string_ATCMD("ATE0"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)    //ATE1  
      {
        if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))//O0K
        { 
          
          return 0;
        }
        else if( ( RxBuffer_3G[0] == 'E' ) && ( RxBuffer_3G[1] == 'R' ) )
        {        
          break;
        }
        
      }
      else if(flag==2)
        return KEYOP_RETURN;
    //  else
      //  break;
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

/********��ѯ�汾��************
ATI

Manufacturer: huawei
Model: MU509
Revision: 11.813.01.13.00
IMEI: 355897043277102

OK
-------------------------------------*/
u8 ATI_G3(void)  
{  
  u8 flag;  
  char j=0;
  u32 timeout; 
  
   // EmptyRcv3G(); 
  do
  {
    IWDG_ReloadCounter();
    EmptyRcv3G();   
    send_string_ATCMD("ATI");
  //   send_string_ATCMD("AT+CGMM"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {      
      flag=ReadGsmString(READWAITONETIME);
      
    //  flag=ReadGsmString_AMT(READWAITONETIME);  
      if(flag==1)
      {
        if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))
         //   if((RxBuffer_3G[3]=='C')&&(RxBuffer_3G[4]=='G')&&(RxBuffer_3G[5]=='M')&&(RxBuffer_3G[6]=='M'))     
        { 
          return 0;
        }
      }
      else if(flag==2)
        return KEYOP_RETURN;
    //  else
    //    break; 

        
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

/*��ȡSIM ��ǰ�ļ�Ȩ״̬ AT+CPIN?**********************
AT+CPIN? 
+CPIN: READY 
OK
**********************/
u8 CPIN_G3(void)  
{  
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_ATCMD("AT+CPIN?");   
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)        
      {
      //  if((RxBuffer_3G[0]=='+')&&(RxBuffer_3G[4]=='N'))//+CPIN: READY 
        if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))
        { 
          return 0;
        }
       /* else if((RxBuffer_3G[0]=='+')&&(RxBuffer_3G[5]=='E'))//+CME ERROR: SIM busy
        {
          delayms_break(1000);//��ʱ
          break;
        }*/
      }
      else if(flag==2)
        return KEYOP_RETURN; 
     /* else
      {
        break;
      } */
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

/*��ѯ�ź�ֵ AT+CSQ**********************
AT+CSQ
+CSQ��20,99 test_mu509c_modem
OK
**********************/
u8 CSQ_G3(void)  
{  
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_ATCMD("AT+CSQ"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)  
      {
       // if((RxBuffer_3G[0]=='+')&&(RxBuffer_3G[1]=='C')&&(RxBuffer_3G[3]=='Q'))//+CPIN: READY 
       if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))
        { 
          return 0;
        }
      }
      else if(flag==2)
        return KEYOP_RETURN; 
      else
      {
       // break;
      }      
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

/*//��ѯ��ǰ����ע��״�� AT+CREG? **********************
AT+CREG? 
+CREG: 0,1
OK
**********************/
u8 CREG_G3(void)
{  
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_ATCMD("AT+CREG?"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)
      {
      //  if((RxBuffer_3G[0]=='+')&&(RxBuffer_3G[1]=='C')&&(RxBuffer_3G[4]=='G'))//+CPIN: READY 
        if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))
        { 
         // if(RxBuffer_3G[9]=='1' || RxBuffer_3G[9]=='5' )
           if(recv_3G[20]=='1' || recv_3G[20]=='5' )
            return 0;
          else
          {
            delayms_break(1000);//��ʱ
            break;
          }
        } 
      }
      else if(flag==2)
        return KEYOP_RETURN; 
    //  else
      //  break;      
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

//AT^IPINIT="3GNET","CARD","CARD"(TCP/UDP��ʼ������һ��CARDΪ�û�����//�ڶ���Ϊ���롣)
//OK����
//+CME ERROR: The network has been opened already
//+CME ERROR: The network has been opened already
u8 USERPASSWORD_G3(void)
{ 
  u8 flag;  
  char j=0;
  u32 timeout;
  
  
  do
  {
    IWDG_ReloadCounter();
    EmptyRcv3G();   
    send_string_3G("AT^IPINIT=\"3GNET\",\"");
    send_string_3G(NET.Username);
    send_string_3G("\",\""); 
    send_string_3G(NET.Password);  
    send_string_ATCMD("\"");
    
    //    send_string_ATCMD("AT^IPINIT=\"3GNET\",\"CARD\",\"CARD\""); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITTWOTIME);
      if(flag==1)      
      {
        if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))//OK
        { 
          return 0;
        } 
        else if((RxBuffer_3G[0]=='+')&&(RxBuffer_3G[5]=='E')
                &&(RxBuffer_3G[24]=='h')&&(RxBuffer_3G[33]=='o')
                  )////+CME ERROR: The network has been opened already
        {
          return 0;
        }
      }
      else if(flag==2)
        return KEYOP_RETURN;      
    //  else
      //  break;      
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

//����IP����AT^IPOPEN=1,"TCP","183.15.131.174",7000,2000
//+CME ERROR: The network has not been opened yet
//+CME ERROR: The link has been established already

u8 TCPLink_G3(u8 linkflag)  
{	
  u8 flag;
  char j=0;
  u32 timeout;
  
  
  do
  {
    IWDG_ReloadCounter();
    EmptyRcv3G(); 
    
    send_string_3G("AT^IPOPEN=1,\"TCP\",\"");
    send_string_3G(NET.Address);
    send_string_3G("\","); 
    send_string_3G(NET.Port); 
    send_string_3G(",");
    send_string_ATCMD(NET.Port);  
    //    send_string_ATCMD("AT^IPOPEN=1,\"TCP\",\"124.172.126.161\",7600,7600"); 
   //   send_string_ATCMD("AT^IPOPEN=1,\"TCP\",\"218.17.233.35\",6000,6000"); 

    timeout=WAITATCMDTIME;
    while(--timeout)
    {      
      flag=ReadGsmString(READWAITTWOTIME);
      if(flag==1)   
      {
        if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))//OK
        { 
          return 0;
        }  else   if((recv_3G[51]=='E')
                     &&(recv_3G[52]=='R')
                      &&(recv_3G[53]=='R')
                       &&(recv_3G[54]=='O')
                        &&(recv_3G[55]=='R')      
                       )//CME ERROR
        { 
          return 1;
        } 
        else if((RxBuffer_3G[0]=='+')&&(RxBuffer_3G[5]=='E')
                &&(RxBuffer_3G[21]=='h')&&(RxBuffer_3G[30]=='e')
                  
                  )////+CME ERROR: The link has been established already
        {
          return 0;
        }
      }
      else if(flag==2) 
        return KEYOP_RETURN;
     // else
       // break;      
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

u8 TCPLink_G3_0(u8 linkflag)  
{	
  u8 flag;
  char j=0;
  u32 timeout;
  
  
  do
  {
    IWDG_ReloadCounter();
    EmptyRcv3G(); 
    
    send_string_3G("AT^IPOPEN=1,\"TCP\",\"");
   // send_string_3G(NET.Address);
    send_string_3G("218.17.233.35");
    send_string_3G("\","); 
   // send_string_3G(NET.Port);
    send_string_3G("6000");
    send_string_3G(",");
    //send_string_ATCMD(NET.Port);  
    send_string_3G("6000");
    //    send_string_ATCMD("AT^IPOPEN=1,\"TCP\",\"124.172.126.161\",7600,7600"); 
   //   send_string_ATCMD("AT^IPOPEN=1,\"TCP\",\"218.17.233.35\",6000,6000"); 

    timeout=WAITATCMDTIME;
    while(--timeout)
    {      
      flag=ReadGsmString(READWAITTWOTIME);
      if(flag==1)   
      {
        if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))//OK
        { 
          return 0;
        }  else   if((recv_3G[51]=='E')
                     &&(recv_3G[52]=='R')
                      &&(recv_3G[53]=='R')
                       &&(recv_3G[54]=='O')
                        &&(recv_3G[55]=='R')      
                       )//CME ERROR
        { 
          return 1;
        } 
        else if((RxBuffer_3G[0]=='+')&&(RxBuffer_3G[5]=='E')
                &&(RxBuffer_3G[21]=='h')&&(RxBuffer_3G[30]=='e')
                  
                  )////+CME ERROR: The link has been established already
        {
          return 0;
        }
      }
      else if(flag==2) 
        return KEYOP_RETURN;
     // else
       // break;      
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

//������
//+CME ERROR: The network has not been opened yet
u8 TCPCLOSE_G3(u8 linkflag)  
{	
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_ATCMD("AT^IPCLOSE=1"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)  
      {
        if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))//OK
        { 
          return 0;
        }       
      }
      else if(flag==2) 
        return KEYOP_RETURN;
      //else
       // break;       
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

//��ѯ��������״��
//^IPCLOSE:1,0,0,0,0
u8 InquireLink_G3(void)  
{	
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_ATCMD("AT^IPCLOSE?"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)
      {
       // if((RxBuffer_3G[1]=='I')&&(RxBuffer_3G[3]=='C')&&(RxBuffer_3G[8]==':'))//OK
        if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))//OK
        { 
          if(RxBuffer_3G[24]=='1')            
            return 0;
          if(RxBuffer_3G[24]=='0')            
            return 2;          
        }       
      }
      else  if(flag==2)
        return KEYOP_RETURN;
      else
        break;       
    }
    j++; 
  }while(j<=0);
  
  return 1;
}


//��������^IPSEND:1 OK
u8 DataSend_G3(u8 *str) 
{	
  u8 flag;
  char j=0;
  u32 timeout;
  
 
  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G();    
    send_string_3G("AT^IPSEND=1,\"");
    send_string_3G(str);    
    send_string_ATCMD("\"");
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {
      
      flag=ReadGsmString(READWAITTWOTIME);
      if(flag==1)
      {
        if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))//OK
        { 
          return 0;
        } 
        //        else if((RxBuffer_3G[0]=='+')&&(RxBuffer_3G[5]=='E')
        //                &&(RxBuffer_3G[24]=='h')&&(RxBuffer_3G[33]=='o')
        //                )////+CME ERROR: The network has been opened already
        //        {
        //        return 0;
        //        }
      }
      else if(flag==2)
        return KEYOP_RETURN;
      else
        break; 
    }
    j++; 
  }while(j<=4);
  
  return 1;
}

//^IPSTATE: 1,0,0
//���ܻ��õ���AT����

//1.�򿪻��߹ر������ϱ�����
u8 CURC_G3(u8 open)
{  
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G(); 
    if(open==AUTOREPORT3GOFF)
      send_string_ATCMD("AT^CURC=0"); 
    else
      send_string_ATCMD("AT^CURC=1"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {      
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)
      {
        if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))//OK
        { 
          return 0;
        }       
      }
      else if(flag==2)
        return KEYOP_RETURN; 
      else
        break;
    }
    j++; 
  }while(j<=4);
  
  return 1;
  
}

//1.�򿪻��߹ر�3G����
u8 CFUN_G3(u8 open)
{  
  
  u8 flag;
  char j=0;
  u32 timeout;
  

  do
  { 
    IWDG_ReloadCounter();
    EmptyRcv3G(); 
    if(open==CFUN3GON)
      send_string_ATCMD("AT^CFUN=1"); 
    else
      send_string_ATCMD("AT^CFUN=0"); 
    
    timeout=WAITATCMDTIME;
    while(--timeout)
    {    
      flag=ReadGsmString(READWAITONETIME);
      if(flag==1)
      {
        if((RxBuffer_3G[0]=='O')&&(RxBuffer_3G[1]=='K'))//OK
        { 
          return 0;
        }       
      }
      else if(flag==2)
        return KEYOP_RETURN; 
      
      else
        break;        
    }
    j++; 
  }while(j<=4);
  
  return 1;
  
}



/*---------------------------3Gģ�����---------------------------------------*/
//1��3Gģ���ϵ�
void poweron3G_module(void)
{  
  WCDMA_Power_OFF;
 // TERMON_3G_0;
  delayms_break(500);
  //WCDMA_Power_ON;
  //delayms_break(50);
  WCDMA_Power_ON;
  TERMON_3G_0;
  SLEEP_3G_1;
  delayms_break(500);
  //���� 
  TERMON_3G_1;
  delayms_break(600);
  TERMON_3G_0;

  delayms_break(1000);

  NET.poweron=WCDMAPWRON;
}
//1��3Gģ��MU509����+CME ERROR: Normal error
u8 MU509link_net(void)
{  
  u8 flag,times;
  u8 firsterror;
  
  // if(InquireLink_G3())
    if(1)  
  {
  

  //3Gģ���ϵ�
  Read_IP();  
  poweron3G_module();
  networkid=1;
  if(key_flag)
    return KEYOP_RETURN;
  //��ȡIP��ַ������

  
  //AT����
  delayms_break(1000);  
  flag=ATE_G3(DOUBLEDISPALY3GON);//1

  if(flag==0)
  {
   ;
  }     
  else if(flag==KEYOP_RETURN)
    return KEYOP_RETURN;
  else
  {
    firsterror=ERROR3GSTART;
    return firsterror;
  }
  
      delayms_break(1000);
  /*
 flag=ATI_G3();//2
  if(flag==0)
  {;
  }    
  else if(flag==KEYOP_RETURN)
    return KEYOP_RETURN;
  else
  {
    firsterror=ERROR3GSTART; 
    return firsterror;
  }
  
   delayms_break(1000);*/
  flag=CPIN_G3();//3
  if(flag==0)
  {
    ;
  }    
  else if(flag==KEYOP_RETURN)
    return KEYOP_RETURN;
  else
  {
    firsterror=ERROR3GSIM; 
    return ERROR3GSIM;
  }  
  delayms_break(1000);
  
  /*flag=CSQ_G3();//4
  if(flag==KEYOP_RETURN)
    return KEYOP_RETURN;*/
  
  //ѭ��
  times=0;
  while(key_flag==0)
  { delayms_break(1000);
    flag=CREG_G3(); //5
    if(flag==0)
      break;  
    else if(flag==KEYOP_RETURN)
      return KEYOP_RETURN;
    else
    {
      if(times>=5)
        return ERROR3GCREG;
      times++;
    }
  }
  
   delayms_break(1000);
  
  
  flag=USERPASSWORD_G3(); //6
  if(flag==0)
  {
    ; 
  } 
  else if(flag==KEYOP_RETURN)
    return KEYOP_RETURN;
  else
    firsterror=ERROR3GPASSWORD;
  
 // for(int k = 0; k < 3; k++)
  {
      
    flag=TCPLink_G3(1);
  //  if(flag==0) break;
    
  }
  
  //flag=TCPLink_G3(1);  //7
  
  
      if(flag==0)
      {
         networkOKflag=1;
         return 0;  
      }
     
  else if(flag==KEYOP_RETURN)
    return KEYOP_RETURN; 
  else
    return ERROR3GLINK;
  
   }
  else
  {
       return 0;  
  }
}



//while(1)
//  {
//    ATE_G3(DOUBLEDISPALY3GON);
//    delayms(1000);  
//    ATI_G3();
//    delayms(1000);
//    CPIN_G3();
//    delayms(1000);
//    
//    CSQ_G3();
//    delayms(1000);
//    while(1)
//    {
//      if(CREG_G3()==0)
//        break;
//    }
//    delayms(1000);
//    USERPASSWORD_G3();
//    delayms(1000); 
//    InquireLink_G3();
//    delayms(1000);
//    TCPLink_G3(1);
//    delayms(1000); 
//    InquireLink_G3();
//    delayms(1000);
//    DataSend_G3("huangfeng");
//    TCPCLOSE_G3(1);
//    delayms(1000); 
//    InquireLink_G3();
//    delayms(1000); 
//    TCPCLOSE_G3(1);
//    
//  }
//
//^IPSTATE: 1,0,2
//
//^IPSTATE: 7,0,2



////^SYSSTART
////
////^ECCLIST: "911","112"
////
////^ECCLIST: "911","112"
////
////^ECCLIST: "911","112"